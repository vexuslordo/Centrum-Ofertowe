"""Przegląd różnic cen w tle, bez przycisku zapisu do Allegro."""

from collections.abc import Callable
from decimal import Decimal
from pathlib import Path
from threading import Event
from typing import cast

from PySide6.QtCore import (
    QAbstractTableModel,
    QModelIndex,
    QPersistentModelIndex,
    QSortFilterProxyModel,
    Qt,
    QTimer,
    Signal,
)
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.cenniki import CennikDTO
from vexlab.przypadki_uzycia.porownanie_cen_allegro import (
    PorownajCennikAllegro,
    PorownanieCeny,
    RaportPorownaniaCen,
)

Indeks = QModelIndex | QPersistentModelIndex
WYNIKI = (
    "Różnica",
    "Bez zmian",
    "Brak oferty",
    "Wiele ofert",
    "Nieaktywna",
    "Inna waluta",
    "Do sprawdzenia",
)


def ocena_ceny(p: PorownanieCeny) -> tuple[str, str]:
    if p.wynik == "Bez zmian":
        return "Cena zgodna", "zielony"
    if p.wynik == "Różnica" and p.roznica:
        if Decimal(p.roznica) > 0:
            return "Za niska cena", "czerwony"
        return "Cena wyższa", "pomaranczowy"
    return p.wynik, "sprawdz"


def kolor_oceny(wariant: str) -> QColor:
    ciemny = QApplication.palette().color(QApplication.palette().ColorRole.Base).lightness() < 128
    kolory = {
        "zielony": ("#62D6A8", "#137448"),
        "czerwony": ("#FF969E", "#B42339"),
        "pomaranczowy": ("#F4C375", "#935600"),
        "sprawdz": ("#AFC3E9", "#435E89"),
    }
    return QColor(kolory[wariant][0 if ciemny else 1])


class ModelPorownaniaCen(QAbstractTableModel):
    def __init__(self) -> None:
        super().__init__()
        self.pozycje: tuple[PorownanieCeny, ...] = ()

    def ustaw(self, pozycje: tuple[PorownanieCeny, ...]) -> None:
        self.beginResetModel()
        self.pozycje = pozycje
        self.endResetModel()

    def rowCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else len(self.pozycje)

    def columnCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else 8

    def headerData(
        self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole
    ) -> object:
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return (
                "SKU",
                "Produkt z cennika",
                "ID Allegro",
                "Stan oferty",
                "Cennik brutto / netto",
                "Allegro brutto",
                "Różnica",
                "Wynik",
            )[section]
        return None

    def data(self, index: Indeks, role: int = Qt.ItemDataRole.DisplayRole) -> object:
        if not index.isValid() or not 0 <= index.row() < len(self.pozycje):
            return None
        p = self.pozycje[index.row()]
        ocena, wariant = ocena_ceny(p)
        if role == Qt.ItemDataRole.ForegroundRole and index.column() in (5, 6, 7):
            return kolor_oceny(wariant)
        if role == Qt.ItemDataRole.UserRole:
            return p
        if role in (Qt.ItemDataRole.ToolTipRole, Qt.ItemDataRole.AccessibleTextRole):
            return f"{ocena} • SKU: {p.sku} • ID: {p.ident or '—'}\n{p.powod}"
        if role == Qt.ItemDataRole.DisplayRole:
            return (
                p.sku,
                p.nazwa,
                p.ident or "—",
                p.stan or "—",
                f"Brutto: {p.docelowa} {p.waluta_docelowa}\nNetto: {p.netto} (VAT 23%)"
                if p.docelowa
                else "—",
                f"{p.obecna} {p.waluta_obecna}" if p.obecna else "—",
                f"{p.roznica} {p.waluta_docelowa}\n{p.procent}%" if p.roznica else "—",
                ocena,
            )[index.column()]
        return None


class FiltrPorownaniaCen(QSortFilterProxyModel):
    def __init__(self, model: ModelPorownaniaCen) -> None:
        super().__init__()
        self.model, self.fraza, self.wynik = model, "", ""
        self.setSourceModel(model)

    def ustaw(self, fraza: str, wynik: str) -> None:
        self.beginFilterChange()
        self.fraza, self.wynik = fraza.strip().casefold(), wynik
        self.endFilterChange()

    def filterAcceptsRow(self, row: int, parent: QModelIndex | QPersistentModelIndex) -> bool:
        p = self.model.pozycje[row]
        return (
            not self.wynik or p.wynik == self.wynik
        ) and self.fraza in f"{p.sku} {p.nazwa} {p.ident}".casefold()

    def lessThan(self, left: Indeks, right: Indeks) -> bool:
        if left.column() in (4, 5, 6):
            a_row, b_row = self.model.pozycje[left.row()], self.model.pozycje[right.row()]
            values = {
                4: (a_row.docelowa, b_row.docelowa),
                5: (a_row.obecna, b_row.obecna),
                6: (a_row.roznica, b_row.roznica),
            }
            a, b = values[left.column()]
            return (not bool(a), Decimal(a or "0")) < (not bool(b), Decimal(b or "0"))
        return str(left.data()).casefold() < str(right.data()).casefold()


class StronaPorownaniaCen(QWidget):
    postep = Signal(int, str, int, int)

    def __init__(
        self,
        serwis: PorownajCennikAllegro,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
    ) -> None:
        super().__init__()
        self.serwis, self.uruchom, self.sesja = serwis, uruchom, sesja
        self.raport: RaportPorownaniaCen | None = None
        self._sesja_raportu: SesjaAllegro | None = None
        self._sledzona_sesja = sesja()
        self._trwa = False
        self._anulowalne = False
        self._generacja = 0
        self._stop = Event()
        self._wybierz: CennikDTO | None = None
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        title = etykieta("Porównaj ceny z Allegro")
        title.setObjectName("tytulStronyAllegro")
        layout.addWidget(title)
        opis = etykieta(
            "Cena docelowa: pełne brutto, VAT 23%. "
            "To podgląd różnic — ceny w Allegro pozostają bez zmian."
        )
        opis.setWordWrap(True)
        layout.addWidget(opis)
        row = QHBoxLayout()
        self.cennik = QComboBox()
        self.cennik.setAccessibleName("Cennik do porównania z Allegro")
        self.odswiez = QPushButton("Odśwież cenniki")
        self.porownaj = QPushButton("Porównaj z Allegro")
        self.porownaj.setObjectName("primary")
        self.stop = QPushButton("Zatrzymaj")
        for widget in (self.cennik, self.odswiez, self.porownaj, self.stop):
            row.addWidget(widget, 1 if widget is self.cennik else 0)
        layout.addLayout(row)
        metrics = QHBoxLayout()
        self.liczniki = []
        for name, kolor in (
            ("Różnice", "zloty"),
            ("Bez zmian", "zielony"),
            ("Wymagają sprawdzenia", "fioletowy"),
        ):
            frame = QFrame()
            frame.setObjectName("kpiAllegro")
            frame.setProperty("wariantAllegro", kolor)
            box = QVBoxLayout(frame)
            box.setContentsMargins(14, 8, 14, 8)
            box.setSpacing(3)
            box.addWidget(etykieta(name))
            licznik = etykieta("—")
            licznik.setObjectName("licznikAllegro")
            self.liczniki.append(licznik)
            box.addWidget(licznik)
            metrics.addWidget(frame)
        layout.addLayout(metrics)
        filters = QHBoxLayout()
        self.filtr = QComboBox()
        self.filtr.addItem("Wszystkie pozycje", "")
        for name in WYNIKI:
            self.filtr.addItem(name, name)
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj po SKU, nazwie lub ID Allegro…")
        self.eksport = QPushButton("Eksportuj widoczne do CSV…")
        for element in (self.filtr, self.szukaj, self.eksport):
            filters.addWidget(element, 1 if element is self.szukaj else 0)
        layout.addLayout(filters)
        legenda = etykieta(
            "<span style='color:#D34453'>●</span> Za niska — poniżej cennika &nbsp; "
            "<span style='color:#249B70'>●</span> Cena zgodna &nbsp; "
            "<span style='color:#BF872F'>●</span> Wyższa od cennika &nbsp; "
            "● Pozostałe — sprawdź powód"
        )
        legenda.setTextFormat(Qt.TextFormat.RichText)
        legenda.setWordWrap(True)
        layout.addWidget(legenda)
        self.model = ModelPorownaniaCen()
        self.proxy = FiltrPorownaniaCen(self.model)
        self.tabela = QTableView()
        self.tabela.setModel(self.proxy)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setShowGrid(False)
        self.tabela.setSortingEnabled(True)
        self.tabela.sortByColumn(0, Qt.SortOrder.AscendingOrder)
        self.tabela.verticalHeader().hide()
        self.tabela.verticalHeader().setDefaultSectionSize(56)
        self.tabela.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for col, width in ((0, 140), (2, 110), (3, 100), (4, 210), (5, 130), (6, 135), (7, 145)):
            self.tabela.setColumnWidth(col, width)
        layout.addWidget(self.tabela, 1)
        self.szczegoly = etykieta("Wybierz cennik i porównaj ceny swojego konta.")
        self.szczegoly.setWordWrap(True)
        layout.addWidget(self.szczegoly)
        self.pasek = QProgressBar()
        self.pasek.hide()
        layout.addWidget(self.pasek)
        self.info = etykieta("Nie pobrano danych Allegro.")
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(200)
        self.timer.timeout.connect(self._filtruj)
        self.szukaj.textChanged.connect(lambda: self.timer.start())
        self.filtr.currentIndexChanged.connect(self._filtruj)
        self.cennik.currentIndexChanged.connect(self._reset)
        self.odswiez.clicked.connect(self.odswiez_cenniki)
        self.porownaj.clicked.connect(self.porownaj_ceny)
        self.stop.clicked.connect(lambda: self._stop.set())
        self.eksport.clicked.connect(self.eksportuj)
        self.tabela.selectionModel().currentRowChanged.connect(self._szczegoly)
        self.postep.connect(self._postep)
        self._stan()

    def _stan(self) -> None:
        for w in (self.cennik, self.odswiez, self.porownaj):
            w.setEnabled(not self._trwa)
        self.porownaj.setEnabled(not self._trwa and self.cennik.currentData() is not None)
        self.stop.setVisible(self._trwa and self._anulowalne)
        self.eksport.setEnabled(
            not self._trwa
            and self.raport is not None
            and self.proxy.rowCount() > 0
            and self.sesja() is self._sesja_raportu
        )

    def _reset(self) -> None:
        self.raport = None
        self._sesja_raportu = None
        self.model.ustaw(())
        self.szczegoly.setText("Porównaj wybrany cennik z Allegro.")
        for label in self.liczniki:
            label.setText("—")
        self._stan()

    def polaczenie(self) -> None:
        if self.sesja() is not self._sledzona_sesja:
            self._sledzona_sesja = self.sesja()
            self.zmiana_polaczenia()

    def zmiana_polaczenia(self) -> None:
        self._stop.set()
        self._generacja += 1
        self._trwa = False
        self.pasek.hide()
        self._reset()
        self.info.setText("Połączenie Allegro zmieniło się. Porównaj ceny ponownie.")

    def _zadanie(
        self, fn: Callable[[], object], ok: Callable[[object], None], *, anulowanie: bool = False
    ) -> None:
        self._generacja += 1
        nr = self._generacja
        self._trwa = True
        self._anulowalne = anulowanie
        self.pasek.setRange(0, 0)
        self.pasek.show()
        self._stan()

        def sukces(w: object) -> None:
            if nr != self._generacja:
                return
            self._trwa = False
            self.pasek.hide()
            ok(w)
            self._stan()

        def blad(_kod: str, tekst: str) -> None:
            if nr != self._generacja:
                return
            self._trwa = False
            self.pasek.hide()
            self.info.setText(tekst)
            self._stan()

        self.uruchom(fn, sukces, blad)

    def odswiez_cenniki(self) -> None:
        if self._trwa:
            return
        previous = self.cennik.currentData()
        self._reset()

        def gotowe(w: object) -> None:
            rows = cast(tuple[CennikDTO, ...], w)
            self.cennik.clear()
            for c in rows:
                if not c.archiwalny:
                    self.cennik.addItem(
                        f"{c.nazwa} • {c.rok} • {c.producent or 'bez producenta'}", c
                    )
            target = self._wybierz or previous
            znaleziono = False
            if isinstance(target, CennikDTO):
                for i in range(self.cennik.count()):
                    if self.cennik.itemData(i).id == target.id:
                        self.cennik.setCurrentIndex(i)
                        znaleziono = True
                        break
            self.info.setText(
                "Wybierz cennik i kliknij Porównaj z Allegro."
                if self.cennik.count()
                else "Brak cenników. Wczytaj cennik w zakładce Cenniki."
            )
            if self._wybierz is not None:
                self._wybierz = None
                if znaleziono:
                    QTimer.singleShot(0, self.porownaj_ceny)
                else:
                    self.info.setText(
                        "Wybrany cennik nie jest już dostępny. Wybierz cennik ponownie."
                    )

        self._zadanie(self.serwis.lista, gotowe)

    def wybierz_cennik(self, c: CennikDTO) -> None:
        self._wybierz = c
        if not self._trwa:
            self.odswiez_cenniki()

    def porownaj_ceny(self) -> None:
        if self._trwa:
            return
        s, c = self.sesja(), self.cennik.currentData()
        if s is None:
            self.info.setText("Najpierw połącz konto w Ustawienia → Integracje → Allegro.")
            return
        if not isinstance(c, CennikDTO):
            self.info.setText("Wybierz cennik.")
            return
        self._reset()
        self._stop = stop = Event()
        nr = self._generacja + 1
        self.info.setText("Pobieranie cen z Allegro…")

        def gotowe(w: object) -> None:
            if self.sesja() is not s:
                self.zmiana_polaczenia()
                return
            self.raport = cast(RaportPorownaniaCen, w)
            self._sesja_raportu = s
            self.model.ustaw(self.raport.pozycje)
            counts = [
                sum(p.wynik == name for p in self.raport.pozycje)
                for name in ("Różnica", "Bez zmian")
            ]
            for label, value in zip(
                self.liczniki, (*counts, len(self.raport.pozycje) - sum(counts)), strict=True
            ):
                label.setText(str(value))
            self._filtruj()

        self._zadanie(
            lambda: self.serwis.porownaj(
                s, c, stop.is_set, lambda etap, n, total: self.postep.emit(nr, etap, n, total)
            ),
            gotowe,
            anulowanie=True,
        )

    def _postep(self, nr: int, etap: str, n: int, total: int) -> None:
        if nr == self._generacja and self._trwa:
            self.info.setText(f"{etap}: {n} z {total}")
            self.pasek.setRange(0, max(1, total))
            self.pasek.setValue(n)

    def _filtruj(self) -> None:
        self.proxy.ustaw(self.szukaj.text(), self.filtr.currentData() or "")
        if self.raport is not None:
            self.info.setText(
                f"Konto: {self.raport.login} • {self.raport.srodowisko} • "
                f"Odczyt UTC: {self.raport.odczytano} • "
                f"Widoczne: {self.proxy.rowCount()} z {len(self.raport.pozycje)}"
            )
        self._stan()

    def _szczegoly(self, index: QModelIndex, previous: QModelIndex) -> None:
        p = index.data(Qt.ItemDataRole.UserRole)
        self.szczegoly.setText(
            p.powod if isinstance(p, PorownanieCeny) else "Wybierz pozycję, aby zobaczyć powód."
        )

    def eksportuj(self) -> None:
        if self._trwa or self.raport is None or self.sesja() is not self._sesja_raportu:
            return
        cel, _ = QFileDialog.getSaveFileName(
            self, "Zapisz raport cen", "porownanie-cen-allegro.csv", "CSV (*.csv)"
        )
        if not cel:
            return
        if self.raport is None or self.sesja() is not self._sesja_raportu:
            self.info.setText("Połączenie zmieniło się. Porównaj ceny przed eksportem.")
            return
        raport = self.raport
        rows = tuple(
            cast(PorownanieCeny, self.proxy.index(i, 0).data(Qt.ItemDataRole.UserRole))
            for i in range(self.proxy.rowCount())
        )
        self._zadanie(
            lambda: self.serwis.eksportuj(Path(cel), raport, rows),
            lambda n: self.info.setText(f"Zapisano raport: {n} pozycji."),
        )
