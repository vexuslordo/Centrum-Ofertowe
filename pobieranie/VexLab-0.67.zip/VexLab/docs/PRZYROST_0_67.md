# VexLab 0.67 — zamówienia Allegro, tylko odczyt

1. W Ustawienia → Integracje → Allegro zaznacz Odczyt zamówień.
2. W aplikacji Allegro udostępnij allegro:api:order:read. Użyj Zmień uprawnienia
   i zatwierdź nowe połączenie. Dotychczasowe funkcje nie wymagają tej opcji.
3. Wejdź w Sprzedaż → Zamówienia, wybierz 7/30/90 dni zakupu i Pobierz.
4. Filtruj osobno status zakupu i realizacji; szukaj po numerze, kupującym,
   SKU lub nazwie pozycji. Liczniki dotyczą aktualnego wyniku filtrowania.
5. Wybierz wiersz: szczegóły pokazują pozycje, kwotę, typ płatności,
   zapłaconą kwotę i dostawę. Odśwież szczegóły pobiera aktualny odczyt.

Wyniki dotyczą tylko połączonego konta/środowiska i wybranego zakresu.
Zakres oraz odczyt pokazano jako UTC. Statusy zachowują osobne kody Allegro,
bez utożsamiania gotowości do obsługi, płatności, wysyłki i zwrotu pieniędzy.
Przy braku dostępu pojawi się instrukcja uprawnień. Po błędzie lub przerwaniu
nie pokazujemy częściowej listy jako kompletnej. Do 20 000 zamówień w odczycie;
większy zakres wymaga zawężenia. Możesz pracować w innych zakładkach.

Nie zmieniamy zamówień na Allegro. Dane klientów są tylko w pamięci, czyszczone
przy zmianie konta i zamknięciu programu; nie trafiają do lokalnej bazy.
PrestaShop/Subiekt nadal odłożone. Reguły Po terminie/Indywidualne i wspólne
mapowania statusów są kolejnymi krokami po ustaleniu ich znaczenia.

Testy wykorzystują syntetyczne zamówienia i transport; nie odczytywano
rzeczywistych klientów. GUI sprawdzane Linux offscreen, nie natywny Windows.
Paczka nadal pomija zrzuty ekranu, zachowuje obraz referencyjny i logo.
