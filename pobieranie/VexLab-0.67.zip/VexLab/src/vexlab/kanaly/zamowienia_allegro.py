"""GET checkout-forms; ostrożne DTO i komunikaty bez danych klienta."""

from decimal import Decimal, InvalidOperation
from typing import Any
from urllib.parse import urlencode
from uuid import UUID

from vexlab.kanaly.allegro import AllegroAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.zamowienia_allegro import (
    PozycjaZamowienia,
    StronaZamowien,
    ZamowienieAllegro,
)


def _tekst(d: dict[str, Any], key: str, limit: int = 1000) -> str:
    value = d.get(key)
    if value is None:
        value = ""
    if not isinstance(value, str) or len(value) > limit:
        raise ValueError("tekst")
    return value


def _obiekt(d: dict[str, Any], key: str) -> dict[str, Any]:
    value = d.get(key) or {}
    if not isinstance(value, dict):
        raise ValueError("obiekt")
    return value


def _kwota(d: dict[str, Any]) -> str:
    if not d:
        return ""
    v, waluta = _tekst(d, "amount", 20), _tekst(d, "currency", 3)
    n = Decimal(v)
    if not n.is_finite() or not 0 <= n <= 999999999 or len(waluta) != 3:
        raise ValueError("kwota")
    return f"{v} {waluta}"


def mapuj_zamowienie(d: dict[str, Any]) -> ZamowienieAllegro:
    try:
        ident = _tekst(d, "id", 36)
        if str(UUID(ident)) != ident:
            raise ValueError("id")
        buyer = _obiekt(d, "buyer")
        payment, delivery = _obiekt(d, "payment"), _obiekt(d, "delivery")
        items = d.get("lineItems")
        if not isinstance(items, list) or not 1 <= len(items) <= 1000:
            raise ValueError("pozycje")
        rows = []
        for item in items:
            offer = _obiekt(item, "offer")
            n = item["quantity"]
            if type(n) is not int or not 1 <= n <= 1000000:
                raise ValueError("ilosc")
            rows.append(
                PozycjaZamowienia(
                    _tekst(offer, "name"),
                    _tekst(_obiekt(offer, "external"), "id"),
                    n,
                    _kwota(_obiekt(item, "price")),
                )
            )
        address = _obiekt(delivery, "address")
        adres = "\n".join(
            v
            for v in (
                " ".join(filter(None, (_tekst(address, "firstName"), _tekst(address, "lastName")))),
                _tekst(address, "companyName"),
                _tekst(address, "street"),
                " ".join(filter(None, (_tekst(address, "zipCode"), _tekst(address, "city")))),
                _tekst(address, "countryCode"),
            )
            if v
        )
        pickup = _obiekt(delivery, "pickupPoint")
        if pickup:
            a = _obiekt(pickup, "address")
            punkt = "\n".join(
                filter(
                    None,
                    (
                        _tekst(pickup, "name"),
                        _tekst(pickup, "id"),
                        _tekst(a, "street"),
                        " ".join(filter(None, (_tekst(a, "zipCode"), _tekst(a, "city")))),
                        _tekst(a, "countryCode"),
                    ),
                )
            )
            adres = (adres + "\n\n" if adres else "") + "Punkt odbioru:\n" + punkt
        return ZamowienieAllegro(
            ident,
            _tekst(buyer, "login", 200),
            _tekst(d, "status", 100),
            _tekst(_obiekt(d, "fulfillment"), "status", 100),
            _kwota(_obiekt(_obiekt(d, "summary"), "totalToPay")),
            _tekst(payment, "type", 100),
            _kwota(_obiekt(payment, "paidAmount")),
            _tekst(_obiekt(delivery, "method"), "name"),
            adres,
            tuple(rows),
            _tekst(d, "updatedAt", 100),
        )
    except (KeyError, ValueError, TypeError, AttributeError, InvalidOperation):
        raise BladAllegro(
            "ZAMOWIENIA", "Niepoprawna odpowiedź zamówienia Allegro. Nie zapisano danych klienta."
        ) from None


class ZamowieniaAllegroAPI(AllegroAPI):
    def _odczytaj(self, s: SesjaAllegro, path: str) -> dict[str, Any]:
        try:
            return self._get(s.srodowisko, s.token, path)
        except BladAllegro as exc:
            if exc.kod == "UPRAWNIENIA" or "403" in str(exc):
                raise BladAllegro(
                    "UPRAWNIENIA",
                    "Brak dostępu do zamówień. Włącz allegro:api:order:read w aplikacji Allegro, "
                    "zaznacz Odczyt zamówień i połącz konto ponownie.",
                ) from None
            raise

    def strona_zamowien(self, s: SesjaAllegro, od: str, do: str, offset: int) -> StronaZamowien:
        if not 0 <= offset <= 20000:
            raise BladAllegro("ZAKRES", "Niepoprawna strona zamówień.")
        query = urlencode(
            {
                "limit": 100,
                "offset": offset,
                "lineItems.boughtAt.gte": od,
                "lineItems.boughtAt.lte": do,
            }
        )
        d = self._odczytaj(s, "/order/checkout-forms?" + query)
        rows, total, count = d.get("checkoutForms"), d.get("totalCount"), d.get("count")
        if (
            not isinstance(rows, list)
            or len(rows) > 100
            or type(total) is not int
            or type(count) is not int
            or count != len(rows)
            or total < count
        ):
            raise BladAllegro("ZAMOWIENIA", "Niepełna odpowiedź listy zamówień Allegro.")
        return StronaZamowien(tuple(mapuj_zamowienie(r) for r in rows), total)

    def szczegoly_zamowienia(self, s: SesjaAllegro, ident: str) -> ZamowienieAllegro:
        try:
            if str(UUID(ident)) != ident:
                raise ValueError("id")
        except ValueError:
            raise BladAllegro("ID", "Niepoprawny numer zamówienia.") from None
        row = mapuj_zamowienie(self._odczytaj(s, "/order/checkout-forms/" + ident))
        if row.id != ident:
            raise BladAllegro("ID", "Odpowiedź dotyczy innego zamówienia.")
        return row
