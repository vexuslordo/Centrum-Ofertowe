"""Lista zamówień w pamięci, filtry po rzeczywistych kodach i odczyt szczegółów w tle."""

from collections.abc import Callable
from threading import Event
from typing import cast

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QPersistentModelIndex, Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSplitter,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.zamowienia_allegro import (
    OdczytajZamowieniaAllegro,
    RaportZamowien,
    ZamowienieAllegro,
)

Indeks = QModelIndex | QPersistentModelIndex


class ModelZamowien(QAbstractTableModel):
    def __init__(self) -> None:
        super().__init__()
        self.rows: tuple[ZamowienieAllegro, ...] = ()

    def ustaw(self, rows: tuple[ZamowienieAllegro, ...]) -> None:
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def rowCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else 6

    def headerData(
        self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole
    ) -> object:
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return (
                "Numer zamówienia",
                "Kupujący",
                "Status zakupu",
                "Realizacja",
                "Kwota",
                "Aktualizacja UTC",
            )[section]
        return None

    def data(self, index: Indeks, role: int = Qt.ItemDataRole.DisplayRole) -> object:
        if not index.isValid() or not 0 <= index.row() < len(self.rows):
            return None
        r = self.rows[index.row()]
        if role == Qt.ItemDataRole.UserRole:
            return r
        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.ToolTipRole):
            return (r.id, r.kupujacy, r.status, r.realizacja or "—", r.kwota or "—", r.kiedy)[
                index.column()
            ]
        return None


class StronaZamowien(QWidget):
    postep = Signal(int, int, int)

    def __init__(
        self,
        uc: OdczytajZamowieniaAllegro,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
    ) -> None:
        super().__init__()
        self.uc, self.uruchom, self.sesja = uc, uruchom, sesja
        self.raport: RaportZamowien | None = None
        self._sesja = sesja()
        self._nr, self._trwa = 0, False
        self._stop = Event()
        box = QVBoxLayout(self)
        box.setContentsMargins(12, 10, 12, 10)
        title = QLabel("Zamówienia Allegro")
        title.setObjectName("tytulStronyAllegro")
        box.addWidget(title)
        opis = QLabel(
            "Tylko odczyt • dane klientów w pamięci do zamknięcia programu lub zmiany konta"
        )
        opis.setWordWrap(True)
        box.addWidget(opis)
        top = QHBoxLayout()
        self.dni = QComboBox()
        for n in (7, 30, 90):
            self.dni.addItem(f"Ostatnie {n} dni zakupu", n)
        self.dni.setCurrentIndex(1)
        self.pobierz = QPushButton("Pobierz / odśwież zamówienia")
        self.pobierz.setObjectName("primary")
        self.stop = QPushButton("Zatrzymaj")
        for w in (self.dni, self.pobierz, self.stop):
            top.addWidget(w)
        top.addStretch()
        box.addLayout(top)
        self.liczniki = QLabel("Nie pobrano zamówień.")
        box.addWidget(self.liczniki)
        filters = QHBoxLayout()
        self.status, self.realizacja = QComboBox(), QComboBox()
        self.status.addItem("Wszystkie statusy zakupu", "")
        self.realizacja.addItem("Wszystkie statusy realizacji", "")
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Numer zamówienia, kupujący, SKU lub nazwa pozycji…")
        for widget in (self.status, self.realizacja, self.szukaj):
            filters.addWidget(widget, 1 if widget is self.szukaj else 0)
        box.addLayout(filters)
        split = QSplitter()
        self.model = ModelZamowien()
        self.tabela = QTableView()
        self.tabela.setModel(self.model)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.verticalHeader().hide()
        self.tabela.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for i in range(1, 6):
            self.tabela.setColumnWidth(i, 145)
        split.addWidget(self.tabela)
        right = QWidget()
        rbox = QVBoxLayout(right)
        self.detale = QPlainTextEdit()
        self.detale.setReadOnly(True)
        self.detale.setUndoRedoEnabled(False)
        self.detale.setPlaceholderText(
            "Wybierz zamówienie, aby zobaczyć pozycje, płatność i dostawę."
        )
        self.odswiez_szczegoly = QPushButton("Odśwież szczegóły z Allegro")
        rbox.addWidget(self.detale)
        rbox.addWidget(self.odswiez_szczegoly)
        split.addWidget(right)
        split.setSizes([1000, 350])
        box.addWidget(split, 1)
        self.progress = QProgressBar()
        self.progress.hide()
        box.addWidget(self.progress)
        self.info = QLabel(
            "Połącz Allegro z uprawnieniem odczytu zamówień, następnie pobierz listę."
        )
        self.info.setWordWrap(True)
        self.info.setTextFormat(Qt.TextFormat.PlainText)
        box.addWidget(self.info)
        self.pobierz.clicked.connect(self.pobierz_liste)
        self.stop.clicked.connect(lambda: self._stop.set())
        self.status.currentIndexChanged.connect(self.filtruj)
        self.realizacja.currentIndexChanged.connect(self.filtruj)
        self.szukaj.textChanged.connect(self.filtruj)
        self.tabela.selectionModel().currentRowChanged.connect(lambda *_: self._wybor())
        self.odswiez_szczegoly.clicked.connect(self.szczegoly)
        self.postep.connect(self._postep)
        self._stan()

    def _stan(self) -> None:
        self.pobierz.setEnabled(not self._trwa and self.sesja() is not None)
        self.dni.setEnabled(not self._trwa)
        self.stop.setVisible(self._trwa)
        self.odswiez_szczegoly.setEnabled(not self._trwa and self.tabela.currentIndex().isValid())

    def polaczenie(self) -> None:
        if self.sesja() is not self._sesja:
            self._sesja = self.sesja()
            self._nr += 1
            self._stop.set()
            self._trwa = False
            self.raport = None
            self.szukaj.clear()
            self.model.ustaw(())
            self.detale.clear()
            self.liczniki.setText("Nie pobrano zamówień.")
            self.progress.hide()
            self.info.setText("Zmieniono połączenie. Pobierz zamówienia aktualnego konta.")
        self._stan()

    def _zadanie(self, fn: Callable[[], object], ok: Callable[[object], None]) -> None:
        self._nr += 1
        nr, s = self._nr, self.sesja()
        self._trwa = True
        self.progress.setRange(0, 0)
        self.progress.show()
        self._stan()

        def gotowe(value: object) -> None:
            if nr != self._nr or self.sesja() is not s:
                return
            self._trwa = False
            self.progress.hide()
            ok(value)
            self._stan()

        def blad(kod: str, tekst: str) -> None:
            if nr != self._nr or self.sesja() is not s:
                return
            self._trwa = False
            self.progress.hide()
            if self.raport is None:
                self.liczniki.setText("Nie pobrano pełnej listy zamówień.")
            self.info.setText(tekst)
            self._stan()

        self.uruchom(fn, gotowe, blad)

    def pobierz_liste(self) -> None:
        if self._trwa or self.sesja() is None:
            return
        self.polaczenie()
        s = self.sesja()
        if s is None:
            return
        self._stop = stop = Event()
        self.raport = None
        self.model.ustaw(())
        self.detale.clear()
        self.liczniki.setText("Pobieranie…")
        nr = self._nr + 1
        dni = int(self.dni.currentData())

        def gotowe(value: object) -> None:
            self.raport = cast(RaportZamowien, value)
            for combo, attr, title in (
                (self.status, "status", "Wszystkie statusy zakupu"),
                (self.realizacja, "realizacja", "Wszystkie statusy realizacji"),
            ):
                combo.blockSignals(True)
                combo.clear()
                combo.addItem(title, "")
                for name in sorted(
                    {getattr(r, attr) for r in self.raport.pozycje if getattr(r, attr)}
                ):
                    combo.addItem(name, name)
                combo.blockSignals(False)
            self.filtruj()

        self._zadanie(
            lambda: self.uc.pobierz(
                s,
                dni,
                stop.is_set,
                lambda n, total: self.postep.emit(nr, n, total),
            ),
            gotowe,
        )

    def _postep(self, nr: int, n: int, total: int) -> None:
        if nr == self._nr and self._trwa:
            self.progress.setRange(0, max(1, total))
            self.progress.setValue(n)
            self.info.setText(f"Pobrano zamówień: {n} z {total}")

    def filtruj(self) -> None:
        if self.raport is None:
            return
        status, realizacja, text = (
            self.status.currentData(),
            self.realizacja.currentData(),
            self.szukaj.text().strip().casefold(),
        )
        rows = tuple(
            r
            for r in self.raport.pozycje
            if (not status or r.status == status)
            and (not realizacja or r.realizacja == realizacja)
            and text
            in (
                r.id + " " + r.kupujacy + " " + " ".join(p.sku + " " + p.nazwa for p in r.pozycje)
            ).casefold()
        )
        self.model.ustaw(rows)
        self.detale.clear()
        self.liczniki.setText(
            f"Widoczne: {len(rows)} • Gotowe do obsługi (READY_FOR_PROCESSING): "
            f"{sum(r.status == 'READY_FOR_PROCESSING' for r in rows)} • "
            f"Nowe (NEW): {sum(r.realizacja == 'NEW' for r in rows)}"
        )
        self.info.setText(
            f"Allegro • {self.raport.login} • {self.raport.srodowisko} • "
            f"Zakupy UTC: {self.raport.od[:10]} – {self.raport.do[:10]} • "
            f"Odczyt UTC: {self.raport.odczytano}"
        )
        self._stan()

    def _pokaz(self, r: ZamowienieAllegro) -> None:
        self.detale.setPlainText(
            f"Allegro • konto: {self.raport.login if self.raport else ''}\n"
            f"Numer: {r.id}\n"
            f"Kupujący: {r.kupujacy}\n"
            f"Status zakupu: {r.status}\n"
            f"Realizacja: {r.realizacja or '—'}\n"
            f"\n"
            f"Wartość zamówienia: {r.kwota or '—'}\n"
            f"Typ płatności: {r.platnosc or '—'}\n"
            f"Zapłacono: {r.zaplacono or 'brak danych'}\n"
            f"\n"
            f"Dostawa: {r.dostawa or '—'}\n"
            f"{r.adres}\n"
            f"\n"
            f"Pozycje:\n"
            f""
            + "\n".join(
                f"{p.nazwa}\nSKU: {p.sku or '—'} • {p.ilosc} szt. • {p.cena}\n" for p in r.pozycje
            )
        )

    def _wybor(self) -> None:
        r = self.tabela.currentIndex().data(Qt.ItemDataRole.UserRole)
        if isinstance(r, ZamowienieAllegro):
            self._pokaz(r)
        self._stan()

    def szczegoly(self) -> None:
        s, r = self.sesja(), self.tabela.currentIndex().data(Qt.ItemDataRole.UserRole)
        if self._trwa or s is None or not isinstance(r, ZamowienieAllegro):
            return
        self._zadanie(
            lambda: self.uc.szczegoly(s, r.id),
            lambda value: (
                self._pokaz(cast(ZamowienieAllegro, value))
                if self.tabela.currentIndex().data(Qt.ItemDataRole.UserRole) == r
                else None
            ),
        )
