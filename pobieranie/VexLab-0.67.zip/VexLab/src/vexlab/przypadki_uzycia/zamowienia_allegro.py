"""Odczyt zamówień konta. Bez lokalnej kopii danych klientów i operacji zapisu."""

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol

from vexlab.przypadki_uzycia.allegro import BladAllegro, CzasMonotoniczny, SesjaAllegro


@dataclass(frozen=True)
class PozycjaZamowienia:
    nazwa: str
    sku: str
    ilosc: int
    cena: str


@dataclass(frozen=True)
class ZamowienieAllegro:
    id: str
    kupujacy: str
    status: str
    realizacja: str
    kwota: str
    platnosc: str
    zaplacono: str
    dostawa: str
    adres: str
    pozycje: tuple[PozycjaZamowienia, ...]
    kiedy: str


@dataclass(frozen=True)
class StronaZamowien:
    pozycje: tuple[ZamowienieAllegro, ...]
    razem: int


@dataclass(frozen=True)
class RaportZamowien:
    konto: str
    login: str
    srodowisko: str
    od: str
    do: str
    odczytano: str
    pozycje: tuple[ZamowienieAllegro, ...]


class APIZamowien(Protocol):
    def strona_zamowien(self, s: SesjaAllegro, od: str, do: str, offset: int) -> StronaZamowien: ...
    def szczegoly_zamowienia(self, s: SesjaAllegro, ident: str) -> ZamowienieAllegro: ...


class OdczytajZamowieniaAllegro:
    def __init__(self, api: APIZamowien, czas: CzasMonotoniczny) -> None:
        self.api, self.czas = api, czas

    def _sesja(self, s: SesjaAllegro) -> None:
        if self.czas.teraz() >= s.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto Allegro ponownie.")
        if s.aplikacja is None or not s.aplikacja.odczyt_zamowien:
            raise BladAllegro(
                "ZAMOWIENIA",
                "W Integracje → Allegro włącz Odczyt zamówień i połącz konto ponownie.",
            )

    def pobierz(
        self,
        s: SesjaAllegro,
        dni: int,
        stop: Callable[[], bool],
        postep: Callable[[int, int], None],
    ) -> RaportZamowien:
        self._sesja(s)
        if dni not in (7, 30, 90):
            raise BladAllegro("ZAKRES", "Wybierz 7, 30 lub 90 dni.")
        teraz = datetime.now(UTC)
        od, do = ((teraz - timedelta(days=dni)).isoformat(), teraz.isoformat())
        rows: list[ZamowienieAllegro] = []
        seen = set()
        total = None
        while True:
            self._sesja(s)
            if stop():
                raise BladAllegro("ANULOWANO", "Anulowano pobieranie zamówień.")
            page = self.api.strona_zamowien(s, od, do, len(rows))
            if total is None:
                total = page.razem
            if not 0 <= total <= 20000 or page.razem != total:
                raise BladAllegro(
                    "ODCZYT",
                    "Lista zamówień zmieniła się lub przekracza 20 000. "
                    "Wybierz krótszy zakres i pobierz ponownie.",
                )
            for row in page.pozycje:
                if row.id in seen:
                    raise BladAllegro(
                        "ODCZYT", "Powtórzone zamówienie podczas stronicowania. Pobierz ponownie."
                    )
                seen.add(row.id)
                rows.append(row)
            postep(len(rows), total)
            if len(rows) == total:
                break
            if not page.pozycje or len(rows) > total:
                raise BladAllegro("ODCZYT", "Niepełna lista zamówień. Pobierz ponownie.")
        if stop():
            raise BladAllegro("ANULOWANO", "Anulowano pobieranie zamówień.")
        return RaportZamowien(
            s.konto.id,
            s.konto.login,
            s.srodowisko.value,
            od,
            do,
            datetime.now(UTC).isoformat(timespec="seconds"),
            tuple(rows),
        )

    def szczegoly(self, s: SesjaAllegro, ident: str) -> ZamowienieAllegro:
        self._sesja(s)
        return self.api.szczegoly_zamowienia(s, ident)
