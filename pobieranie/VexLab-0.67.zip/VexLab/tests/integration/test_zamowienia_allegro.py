import json
from contextlib import suppress
from dataclasses import replace
from urllib.parse import parse_qs, urlsplit
from uuid import UUID

import pytest

from tests.integration.test_zapis_szkicu_allegro import Czas
from vexlab.kanaly.allegro import AllegroAPI
from vexlab.kanaly.zamowienia_allegro import ZamowieniaAllegroAPI, mapuj_zamowienie
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    BladAllegro,
    KontoAllegro,
    OdpowiedzAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro, StronaZamowien


def raw(n=1):
    return {
        "id": str(UUID(int=n)),
        "buyer": {"login": "kupujacy_testowy"},
        "status": "READY_FOR_PROCESSING",
        "fulfillment": {"status": "NEW"},
        "summary": {"totalToPay": {"amount": "123.00", "currency": "PLN"}},
        "payment": {"type": "CASH_ON_DELIVERY"},
        "delivery": {"method": {"name": "Dostawa testowa"}, "address": {"city": "Miasto testowe"}},
        "lineItems": [
            {
                "offer": {"name": "Część testowa", "external": {"id": "00123"}},
                "quantity": 2,
                "price": {"amount": "61.50", "currency": "PLN"},
            }
        ],
        "updatedAt": "2026-11-18T10:00:00Z",
    }


def sesja():
    return SesjaAllegro(
        KontoAllegro("konto", "test"),
        SrodowiskoAllegro.SANDBOX,
        "fixture",
        10000,
        aplikacja=AplikacjaAllegro("id", "fixture", SrodowiskoAllegro.SANDBOX, False, True),
    )


class API:
    def __init__(self):
        self.calls = []
        self.change = False
        self.duplicate = False

    def strona_zamowien(self, s, od, do, offset):
        self.calls.append(offset)
        return StronaZamowien(
            (mapuj_zamowienie(raw(1 if not offset or self.duplicate else 2)),),
            3 if offset and self.change else 2,
        )

    def szczegoly_zamowienia(self, s, ident):
        return mapuj_zamowienie(raw())


def test_pelne_stronicowanie_kontekst_i_oddzielna_platnosc():
    api, s = API(), sesja()
    r = OdczytajZamowieniaAllegro(api, Czas()).pobierz(s, 30, lambda: False, lambda *a: None)
    assert api.calls == [0, 1] and len(r.pozycje) == 2 and r.konto == "konto"
    assert r.pozycje[0].platnosc == "CASH_ON_DELIVERY" and r.pozycje[0].zaplacono == ""
    assert r.pozycje[0].pozycje[0].sku == "00123"


@pytest.mark.parametrize("mode", ["zmiana", "duplikat", "anulowanie", "uprawnienia", "wygasla"])
def test_nie_pokazuje_niepelnych_lub_cudzych_danych(mode):
    api, s = API(), sesja()
    api.change = mode == "zmiana"
    api.duplicate = mode == "duplikat"
    if mode == "uprawnienia":
        s = replace(s, aplikacja=replace(s.aplikacja, odczyt_zamowien=False))
    if mode == "wygasla":
        s = replace(s, wygasa=1)
    with pytest.raises(BladAllegro):
        OdczytajZamowieniaAllegro(api, Czas()).pobierz(
            s, 30, lambda: mode == "anulowanie", lambda *a: None
        )


class Transport:
    def __init__(self):
        self.calls = []
        self.forbidden = False

    def wyslij(self, method, url, headers, body):
        self.calls.append((method, url, body))
        assert method == "GET" and body is None
        if self.forbidden:
            return OdpowiedzAllegro(403, b"{}")
        if urlsplit(url).query:
            return OdpowiedzAllegro(
                200, json.dumps({"checkoutForms": [raw()], "count": 1, "totalCount": 1}).encode()
            )
        return OdpowiedzAllegro(200, json.dumps(raw()).encode())


def test_kanal_tylko_get_i_zakres_zakupow():
    t, s = Transport(), sesja()
    api = ZamowieniaAllegroAPI(t)
    assert api.strona_zamowien(s, "od", "do", 0).razem == 1
    q = parse_qs(urlsplit(t.calls[0][1]).query)
    assert q["limit"] == ["100"] and q["lineItems.boughtAt.gte"] == ["od"]
    assert api.szczegoly_zamowienia(s, raw()["id"]).id == raw()["id"]
    t.forbidden = True
    with pytest.raises(BladAllegro, match="order:read"):
        api.strona_zamowien(s, "od", "do", 0)


def test_blad_mapowania_nie_wypisuje_danych_klienta():
    d = raw()
    d["id"] = "niepoprawny"
    with pytest.raises(BladAllegro) as err:
        mapuj_zamowienie(d)
    assert "kupujacy_testowy" not in str(err.value)


def test_scope_zamowien_tylko_po_wlaczeniu():
    class Auth:
        def __init__(self):
            self.scope = ""

        def wyslij(self, method, url, headers, body):
            self.scope = parse_qs(body.decode())["scope"][0]
            return OdpowiedzAllegro(
                200,
                json.dumps(
                    {
                        "device_code": "x",
                        "user_code": "x",
                        "verification_uri_complete": "https://allegro.pl.allegrosandbox.pl/device?code=x",
                        "expires_in": 600,
                        "interval": 5,
                    }
                ).encode(),
            )

    t = Auth()
    # OAuth request can fail response validation after scope was captured.
    for wlaczone in (False, True):
        with suppress(BladAllegro):
            AllegroAPI(t).rozpocznij(replace(sesja().aplikacja, odczyt_zamowien=wlaczone))
        assert ("allegro:api:order:read" in t.scope) == wlaczone


def test_uprawnienie_zamowien_zachowane_w_magazynie_i_stary_format(tmp_path):
    from tests.integration.test_sekrety_allegro import SzyfratorTestowy
    from vexlab.adaptery.sekrety_allegro import SekretyAllegro
    from vexlab.przypadki_uzycia.allegro import ZapamietaneAllegro

    path = tmp_path / "polaczenie.dpapi"
    crypto = SzyfratorTestowy()
    store = SekretyAllegro(path, crypto)
    data = ZapamietaneAllegro(sesja().aplikacja, sesja().konto, "fixture-refresh")
    store.zapisz(data)
    assert store.odczytaj().aplikacja.odczyt_zamowien is True
    decoded = json.loads(crypto.odszyfruj(path.read_bytes()))
    del decoded["odczyt_zamowien"]
    path.write_bytes(crypto.zaszyfruj(json.dumps(decoded).encode()))
    assert store.odczytaj().aplikacja.odczyt_zamowien is False


def test_punkt_odbioru_nie_jest_pomijany_w_szczegolach():
    data = raw()
    data["delivery"]["pickupPoint"] = {
        "id": "PUNKT-TEST",
        "name": "Punkt testowy",
        "address": {"street": "Ulica testowa 1", "city": "Miasto"},
    }
    order = mapuj_zamowienie(data)
    assert "PUNKT-TEST" in order.adres and "Ulica testowa 1" in order.adres
    assert order.zaplacono == "" and order.platnosc == "CASH_ON_DELIVERY"
