from dataclasses import replace

from tests.integration.test_zamowienia_allegro import API, Czas, sesja
from vexlab.gui.zamowienia_allegro import StronaZamowien
from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro


def test_lista_filtry_szczegoly_i_wyczyszczenie_po_zmianie_konta(qtbot):
    uc, jobs, s = OdczytajZamowieniaAllegro(API(), Czas()), [], [sesja()]
    w = StronaZamowien(uc, lambda *args: jobs.append(args), lambda: s[0])
    qtbot.addWidget(w)
    w.show()
    w.pobierz.click()
    fn, ok, error = jobs.pop(0)
    ok(fn())
    assert w.model.rowCount() == 2 and "Widoczne: 2" in w.liczniki.text()
    w.tabela.selectRow(0)
    assert "Część testowa" in w.detale.toPlainText()
    assert "CASH_ON_DELIVERY" in w.detale.toPlainText()
    w.szukaj.setText("00123")
    assert w.model.rowCount() == 2
    w.szukaj.setText("brak")
    assert w.model.rowCount() == 0 and not w.detale.toPlainText()
    s[0] = replace(s[0], konto=replace(s[0].konto, id="inne"))
    w.polaczenie()
    assert w.raport is None and w.model.rowCount() == 0


def test_spozniony_wynik_nie_odslania_danych_po_wylogowaniu(qtbot):
    jobs, s = [], [sesja()]
    w = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()), lambda *a: jobs.append(a), lambda: s[0]
    )
    qtbot.addWidget(w)
    w.pobierz_liste()
    fn, ok, error = jobs.pop(0)
    result = fn()
    s[0] = None
    w.polaczenie()
    ok(result)
    assert w.raport is None and w.model.rowCount() == 0 and not w.detale.toPlainText()


def test_stop_odczytu_nie_pokazuje_czesciowej_listy(qtbot):
    import pytest

    from vexlab.przypadki_uzycia.allegro import BladAllegro

    jobs = []
    s = sesja()
    w = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()), lambda *a: jobs.append(a), lambda: s
    )
    qtbot.addWidget(w)
    w.pobierz_liste()
    w.stop.click()
    fn, ok, error = jobs.pop(0)
    with pytest.raises(BladAllegro) as e:
        fn()
    error(e.value.kod, str(e.value))
    assert not w.model.rowCount() and "Anulowano" in w.info.text()
