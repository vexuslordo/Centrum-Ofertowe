"""Zewnętrzny punkt składania GUI, katalogu i jawnej diagnostyki CLI."""

import argparse
import json
import sys
from importlib.metadata import version
from pathlib import Path
from uuid import uuid4

from vexlab.adaptery.srodowisko import CzytnikWersjiSystemowych, ZegarSystemowy
from vexlab.przypadki_uzycia.diagnostyka import DiagnozujSrodowisko
from vexlab.rdzen.kontrakty import BladTechniczny, IdKorelacji


def zloz_diagnostyke() -> DiagnozujSrodowisko:
    return DiagnozujSrodowisko(ZegarSystemowy(), CzytnikWersjiSystemowych())


def uruchom_gui(katalog_danych: Path | None = None) -> int:
    # Jawne importy dopiero dla startu GUI; diagnostyka nie uruchamia Qt.
    from PySide6.QtCore import QSettings, QStandardPaths
    from PySide6.QtWidgets import QApplication, QMessageBox

    from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
    from vexlab.adaptery.czytnik_importu import CzytnikTabel
    from vexlab.adaptery.eksport_csv import EksportCSV
    from vexlab.adaptery.import_sqlite import ImportSQLite
    from vexlab.adaptery.katalog_sqlite import KatalogSQLite
    from vexlab.adaptery.paczki_zip import CzytnikZIP, ProfileJSON
    from vexlab.adaptery.pamiec_profili import PamiecProfiliJSON
    from vexlab.adaptery.podglad_zdjec import ObrazHTTPS
    from vexlab.adaptery.preferencje import PreferencjeQt, nazwa_uzytkownika_systemu
    from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
    from vexlab.adaptery.zdjecia_lokalne import LokalneZdjecia
    from vexlab.adaptery.zdjecia_seryjne_sqlite import MagazynZdjecSeryjnychSQLite
    from vexlab.adaptery.zdjecia_shopify import TransportHTTPS, ZdjeciaShopify
    from vexlab.gui.okno import OknoVexLab
    from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
    from vexlab.przypadki_uzycia.eksport import EksportujKatalog
    from vexlab.przypadki_uzycia.galeria import GaleriaProduktow
    from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
    from vexlab.przypadki_uzycia.katalog import KatalogProduktow
    from vexlab.przypadki_uzycia.media import PobierzZdjecia
    from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek
    from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
    from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
    from vexlab.przypadki_uzycia.producenci import RejestrProducentow
    from vexlab.przypadki_uzycia.szkice import SzkiceOfert
    from vexlab.przypadki_uzycia.zdjecia_seryjne import PobierzZdjeciaSeryjnie

    app = QApplication(sys.argv)
    app.setApplicationName("VexLab")
    app.setOrganizationName("VexLab")
    app.setApplicationVersion(version("vexlab"))
    if katalog_danych is None:
        katalog_danych = Path(
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppLocalDataLocation)
        )
    try:
        powloka = PowlokaAplikacji(
            PreferencjeQt(
                QSettings(str(katalog_danych / "preferencje.ini"), QSettings.Format.IniFormat)
            ),
            nazwa_uzytkownika_systemu(),
            app.applicationVersion(),
        )
    except BladTechniczny as blad:
        QMessageBox.critical(None, "VexLab — błąd uruchomienia", str(blad))
        return 1
    repozytorium = KatalogSQLite(katalog_danych / "katalog.sqlite3")
    importer = ImportujProdukty(CzytnikTabel(), ImportSQLite(repozytorium.plik), repozytorium)
    media = PobierzZdjecia(ZdjeciaShopify(TransportHTTPS()))
    okno = OknoVexLab(
        powloka,
        KatalogProduktow(repozytorium, repozytorium),
        RejestrProducentow(repozytorium),
        EksportujKatalog(EksportCSV()),
        importer,
        media,
        GaleriaProduktow(repozytorium, LokalneZdjecia()),
        PodgladPaczek(
            CzytnikZIP(), ProfileJSON(), PamiecProfiliJSON(katalog_danych / "profile_paczek")
        ),
        SzkiceOfert(SzkiceSQLite(repozytorium.plik), KatalogProduktow(repozytorium, repozytorium)),
        BibliotekaCennikow(CennikiSQLite(repozytorium.plik), importer),
        PodgladZdjec(ObrazHTTPS(TransportHTTPS())),
        PobierzZdjeciaSeryjnie(media, MagazynZdjecSeryjnychSQLite(repozytorium.plik)),
    )
    okno.show()
    return app.exec()


def main() -> int:
    parser = argparse.ArgumentParser(description="VexLab — lokalny katalog i powłoka aplikacji")
    parser.add_argument(
        "--diagnostyka", action="store_true", help="Odczytaj wersje środowiska bez uruchamiania GUI"
    )
    parser.add_argument(
        "--katalog-danych",
        type=Path,
        help="Katalog lokalnej bazy i preferencji; domyślnie katalog danych użytkownika",
    )
    argumenty = parser.parse_args()
    if not argumenty.diagnostyka:
        return uruchom_gui(argumenty.katalog_danych)
    id_korelacji = IdKorelacji(uuid4())
    try:
        raport = zloz_diagnostyke().wykonaj(id_korelacji)
    except BladTechniczny as blad:
        print(
            json.dumps({"blad": str(blad), "id_korelacji": str(id_korelacji)}, ensure_ascii=False)
        )
        return 1
    print(
        json.dumps(
            {
                "zakres": "diagnostyka_techniczna",
                "id_korelacji": str(raport.id_korelacji),
                "czas": raport.czas.isoformat(),
                "python": raport.wersje.python,
                "pyside6": raport.wersje.pyside6,
                "sqlite": raport.wersje.sqlite,
            },
            ensure_ascii=False,
        )
    )
    return 0
