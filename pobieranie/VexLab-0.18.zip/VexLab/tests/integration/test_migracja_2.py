import hashlib
import shutil
import sqlite3
from contextlib import closing
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.katalog_sqlite import SCHEMAT, KatalogSQLite
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.rdzen.kontrakty import BladTechniczny

STARY_SCHEMAT = Path(__file__).resolve().parents[1] / "fixtures" / "schemat_1.sql"


def utworz_v1(plik: Path) -> tuple:
    sql = STARY_SCHEMAT.read_text(encoding="utf-8")
    dane = (
        str(uuid4()),
        "Produkt testowy sprzed aktualizacji",
        "TEST-STARY",
        "test-stary",
        "Opis",
        7,
    )
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.execute(sql)
        conn.execute(
            "CREATE TABLE migracje (wersja INTEGER PRIMARY KEY, suma_sha256 TEXT NOT NULL, "
            "zastosowano_utc TEXT NOT NULL)"
        )
        conn.execute(
            "INSERT INTO migracje VALUES (1, ?, '2026-11-02T00:00:00+00:00')",
            (hashlib.sha256(sql.encode()).hexdigest(),),
        )
        conn.execute("INSERT INTO produkty VALUES (?, ?, ?, ?, ?, ?)", dane)
        conn.execute("PRAGMA user_version=1")
    return dane


def test_schemat_1_z_rozdanego_zip_nie_zostal_zmieniony() -> None:
    assert STARY_SCHEMAT.read_text(encoding="utf-8") == SCHEMAT


def test_migracja_zachowuje_dane_i_tworzy_odtwarzalna_kopie(tmp_path: Path) -> None:
    plik = tmp_path / "katalog.sqlite3"
    dane = utworz_v1(plik)
    repo = KatalogSQLite(plik)
    produkty = KatalogProduktow(repo, repo).wyszukaj()
    assert len(produkty) == 1
    assert str(produkty[0].id) == dane[0]
    assert (produkty[0].nazwa, produkty[0].sku, produkty[0].opis, produkty[0].wersja) == (
        dane[1],
        dane[2],
        dane[4],
        dane[5],
    )
    assert produkty[0].producent_id is None
    assert repo.lista_producentow() == []
    kopie = list((tmp_path / "kopie_migracji").glob("*.sqlite3"))
    assert len(kopie) == 1
    with closing(sqlite3.connect(kopie[0])) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 1
        assert conn.execute("SELECT * FROM produkty").fetchone() == dane
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    with closing(sqlite3.connect(plik)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 10
        assert conn.execute("SELECT producent_id FROM produkty").fetchone()[0] is None
        assert conn.execute("SELECT wersja FROM migracje ORDER BY wersja").fetchall() == [
            (1,),
            (2,),
            (3,),
            (4,),
            (5,),
            (6,),
            (7,),
            (8,),
            (9,),
            (10,),
        ]
    odtworzony = tmp_path / "odtworzony" / "katalog.sqlite3"
    odtworzony.parent.mkdir()
    shutil.copy2(kopie[0], odtworzony)
    nowe_repo = KatalogSQLite(odtworzony)
    assert KatalogProduktow(nowe_repo, nowe_repo).wyszukaj() == produkty
    # Kolejne otwarcie schematu 2 nie generuje następnej kopii migracji.
    assert repo.wyszukaj("")
    assert list((tmp_path / "kopie_migracji").glob("*.sqlite3")) == kopie


def test_przerwana_migracja_przywraca_schemat_1_z_danymi(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    plik = tmp_path / "katalog.sqlite3"
    dane = utworz_v1(plik)
    oryginal = sqlite3.connect

    class Przerwanie(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("ALTER TABLE produkty"):
                raise sqlite3.OperationalError("Symulacja przerwania migracji")
            return super().execute(sql, parameters)

    with monkeypatch.context() as context:
        context.setattr(sqlite3, "connect", lambda *a, **kw: oryginal(*a, **kw, factory=Przerwanie))
        with pytest.raises(BladTechniczny):
            KatalogSQLite(plik).wyszukaj("")
    with closing(oryginal(plik)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 1
        assert conn.execute("SELECT * FROM produkty").fetchone() == dane
        assert (
            conn.execute("SELECT name FROM sqlite_master WHERE name='producenci'").fetchall() == []
        )
        assert conn.execute("SELECT wersja FROM migracje").fetchall() == [(1,)]
    assert len(list((tmp_path / "kopie_migracji").glob("*.sqlite3"))) == 1


def test_brak_mozliwosci_kopii_blokuje_migracje_bez_zmiany_bazy(tmp_path: Path) -> None:
    plik = tmp_path / "katalog.sqlite3"
    dane = utworz_v1(plik)
    (tmp_path / "kopie_migracji").write_text("istniejący plik")
    with pytest.raises(BladTechniczny):
        KatalogSQLite(plik).wyszukaj("")
    with closing(sqlite3.connect(plik)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 1
        assert conn.execute("SELECT * FROM produkty").fetchone() == dane
