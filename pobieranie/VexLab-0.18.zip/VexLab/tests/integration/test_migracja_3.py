import hashlib
import sqlite3
from contextlib import closing
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.katalog_sqlite import MIGRACJA_2, KatalogSQLite, suma_migracji_2
from vexlab.rdzen.kontrakty import BladTechniczny

FIXTURE = Path(__file__).resolve().parents[1] / "fixtures" / "schemat_2.sql"


def stara_baza(plik):
    with closing(sqlite3.connect(plik)) as c, c:
        c.executescript(FIXTURE.read_text())
        pid = str(uuid4())
        c.execute("INSERT INTO producenci VALUES (?, 'Producent sprzed migracji', 0, 3)", (pid,))
        c.execute(
            "INSERT INTO produkty VALUES (?, 'Stary', '0007', '0007', 'Opis', 5, ?)",
            (str(uuid4()), pid),
        )
        return c.execute("SELECT * FROM produkty").fetchall()


def test_schemat2_z_paczki_i_zachowanie_danych_oraz_odtwarzalna_kopia(tmp_path):
    plik = tmp_path / "katalog.sqlite3"
    stare = stara_baza(plik)
    assert suma_migracji_2() == hashlib.sha256("\n".join(MIGRACJA_2).encode()).hexdigest()
    repo = KatalogSQLite(plik)
    assert repo.wyszukaj("")[0].sku == "0007"
    with closing(sqlite3.connect(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 10
        assert (
            c.execute(
                "SELECT id,nazwa,sku,sku_klucz,opis,wersja,producent_id FROM produkty"
            ).fetchall()
            == stare
        )
        assert c.execute("SELECT count(*) FROM import_robocze").fetchone()[0] == 0
        assert c.execute("PRAGMA foreign_key_check").fetchall() == []
    kopie = list((tmp_path / "kopie_migracji").glob("*.sqlite3"))
    assert len(kopie) == 1
    with closing(sqlite3.connect(kopie[0])) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 2
        assert (
            c.execute(
                "SELECT id,nazwa,sku,sku_klucz,opis,wersja,producent_id FROM produkty"
            ).fetchall()
            == stare
        )
    assert repo.wyszukaj("")
    assert list((tmp_path / "kopie_migracji").glob("*.sqlite3")) == kopie


def test_awaria_migracji3_zostawia_schemat2_i_kopie(tmp_path, monkeypatch):
    plik = tmp_path / "katalog.sqlite3"
    stare = stara_baza(plik)
    orig = sqlite3.connect

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("CREATE TABLE import_robocze"):
                raise sqlite3.OperationalError("Test awarii")
            return super().execute(sql, parameters)

    with monkeypatch.context() as m:
        m.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
        with pytest.raises(BladTechniczny):
            KatalogSQLite(plik).wyszukaj("")
    with closing(orig(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 2
        assert (
            c.execute(
                "SELECT id,nazwa,sku,sku_klucz,opis,wersja,producent_id FROM produkty"
            ).fetchall()
            == stare
        )
        assert c.execute("SELECT name FROM sqlite_master WHERE name='importy'").fetchall() == []
        assert c.execute("SELECT wersja FROM migracje").fetchall() == [(1,), (2,)]
    assert len(list((tmp_path / "kopie_migracji").glob("*.sqlite3"))) == 1


def test_brak_kopii_nie_pozwala_na_migracje3(tmp_path):
    plik = tmp_path / "katalog.sqlite3"
    stare = stara_baza(plik)
    (tmp_path / "kopie_migracji").write_text("blokada")
    with pytest.raises(BladTechniczny):
        KatalogSQLite(plik).wyszukaj("")
    with closing(sqlite3.connect(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 2
        assert (
            c.execute(
                "SELECT id,nazwa,sku,sku_klucz,opis,wersja,producent_id FROM produkty"
            ).fetchall()
            == stare
        )


def test_niezgodny_checksum3_blokuje_otwarcie(tmp_path):
    plik = tmp_path / "katalog.sqlite3"
    repo = KatalogSQLite(plik)
    assert repo.wyszukaj("") == []
    with closing(sqlite3.connect(plik)) as c, c:
        c.execute("UPDATE migracje SET suma_sha256='niezgodna' WHERE wersja=3")
    with pytest.raises(BladTechniczny, match="Nie potwierdzono"):
        repo.wyszukaj("")
