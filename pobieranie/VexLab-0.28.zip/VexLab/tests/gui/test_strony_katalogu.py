import csv
import sqlite3
from contextlib import closing
from threading import get_ident
from uuid import UUID

import pytest
from PySide6.QtCore import QItemSelection, QItemSelectionModel, QSettings, Qt
from PySide6.QtWidgets import QFileDialog, QMessageBox

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.rdzen.kontrakty import BladTechniczny


def czekaj(qtbot, w):
    qtbot.waitUntil(lambda: not w._zadania and not w._katalog_trwa and not w._wybor_trwa)


@pytest.fixture
def okno(qtbot, tmp_path, monkeypatch):
    repo = KatalogSQLite(tmp_path / "baza.sqlite3")
    repo.wyszukaj("")
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.executemany(
            "INSERT INTO produkty(id,nazwa,sku,sku_klucz,opis,wersja) VALUES(?,?,?,?,?,1)",
            [
                (str(UUID(int=i + 1)), f"Produkt {i:04}", f"SKU-{i:04}", f"sku-{i:04}", "opis")
                for i in range(350)
            ],
        )
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), ImportSQLite(repo.plik), repo),
    )
    qtbot.addWidget(w, before_close_func=lambda w: czekaj(qtbot, w))
    monkeypatch.setattr(QMessageBox, "information", lambda *a: QMessageBox.StandardButton.Ok)
    w.show()
    qtbot.waitUntil(lambda: w._katalog_wczytany and not w._zadania)
    w.przejdz("Produkty")
    yield w
    czekaj(qtbot, w)
    w.close()


def test_tabela_ma_tylko_strone_a_sortowanie_i_filtr_dzialaja_globalnie(qtbot, okno, monkeypatch):
    assert len(okno.model.produkty) == 100
    assert okno.liczba_produktow.text() == "350"
    watki = []
    stary = okno.odczyt_katalogu.strona

    def odczytaj(*args):
        watki.append(get_ident())
        return stary(*args)

    monkeypatch.setattr(okno.odczyt_katalogu, "strona", odczytaj)
    okno._paski_stron[1].nastepna.click()
    czekaj(qtbot, okno)
    assert okno.model.produkty[0].sku == "SKU-0100"
    okno.filtr.sort(1, Qt.SortOrder.DescendingOrder)
    czekaj(qtbot, okno)
    assert okno._strona == 0 and okno.model.produkty[0].sku == "SKU-0349"
    okno.szukaj.setText("sku-0001")
    czekaj(qtbot, okno)
    assert [p.sku for p in okno.model.produkty] == ["SKU-0001"]
    assert watki and all(w != get_ident() for w in watki)


def test_wybor_miedzy_stronami_i_ppm_poza_grupa_zachowuje_jasny_zakres(qtbot, okno, monkeypatch):
    tabela = okno.tabela_produktow
    tabela.selectRow(0)
    pierwszy = okno._zaznaczone_w_tabeli(tabela)[0].id
    okno._zmien_strone(1)
    czekaj(qtbot, okno)
    rect = tabela.visualRect(okno.filtr.index(0, 1))
    qtbot.mouseClick(
        tabela.viewport(),
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.ControlModifier,
        rect.center(),
    )
    assert len(okno._zaznaczone_w_tabeli(tabela)) == 2
    assert pierwszy in {p.id for p in okno._zaznaczone_w_tabeli(tabela)}
    monkeypatch.setattr(okno.menu_kontekstowe_produktow, "popup", lambda *a: None)
    okno._menu_produktow_pod_mysza(tabela.visualRect(okno.filtr.index(1, 1)).center())
    assert [p.sku for p in okno._zaznaczone_w_tabeli(tabela)] == ["SKU-0101"]
    tabela.clearSelection()
    assert not okno._zaznaczone_w_tabeli(tabela)


def test_zaznacz_wszystkie_i_eksport_obejmuja_wszystkie_strony(qtbot, okno, tmp_path, monkeypatch):
    okno.tabela_select_all()
    czekaj(qtbot, okno)
    assert len(okno._zaznaczone_w_tabeli(okno.tabela_produktow)) == 350
    assert len(okno.model.produkty) == 100
    okno._zmien_strone(3)
    czekaj(qtbot, okno)
    assert len(okno._zaznaczone_w_tabeli(okno.tabela_produktow)) == 350
    assert len(okno.model.produkty) == 50
    cel = tmp_path / "wyniki.csv"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **kw: (str(cel), ""))
    okno.eksportuj_wyniki()
    czekaj(qtbot, okno)
    with cel.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f, delimiter=";"))
    assert len(rows) == 351
    okno.odznacz_wszystkie.trigger()
    assert not okno._zaznaczone_w_tabeli(okno.tabela_produktow)


def test_usuniecie_ostatniej_strony_koryguje_numer_i_nie_usuwa_pozostalych(
    qtbot, okno, monkeypatch
):
    okno._zmien_strone(3)
    czekaj(qtbot, okno)
    wybor = QItemSelection(okno.filtr.index(0, 0), okno.filtr.index(49, 7))
    okno.tabela_produktow.selectionModel().select(
        wybor,
        QItemSelectionModel.SelectionFlag.ClearAndSelect | QItemSelectionModel.SelectionFlag.Rows,
    )
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    okno.usun_zaznaczony()
    czekaj(qtbot, okno)
    assert okno._strona == 2 and len(okno.model.produkty) == 100
    assert okno.liczba_produktow.text() == "300"
    assert len(okno.katalog.wyszukaj()) == 300


def test_blad_odczytu_wszystkich_nie_wybiera_czesciowego_zestawu(qtbot, okno, monkeypatch):
    def awaria(*args):
        raise BladTechniczny("Brak odczytu wszystkich wyników")

    monkeypatch.setattr(okno.odczyt_katalogu, "wszystkie_wyniki", awaria)
    okno.tabela_select_all()
    czekaj(qtbot, okno)
    assert not okno._zaznaczone_w_tabeli(okno.tabela_produktow)
    assert "Brak odczytu" in okno.status.text()
    assert len(okno.model.produkty) == 100


def test_usun_wszystkie_wyniki_obejmuje_takze_inne_strony(qtbot, okno, monkeypatch):
    okno._zmien_strone(1)
    czekaj(qtbot, okno)
    potwierdzenia = []

    def zgoda(*args):
        potwierdzenia.append(args[2])
        return QMessageBox.StandardButton.Yes

    monkeypatch.setattr(QMessageBox, "question", zgoda)
    okno.usun_wyniki()
    czekaj(qtbot, okno)
    assert any("350" in tekst for tekst in potwierdzenia)
    assert okno._strona == 0 and not okno.model.produkty
    assert okno.liczba_produktow.text() == "0"
    assert not okno.katalog.wyszukaj()
