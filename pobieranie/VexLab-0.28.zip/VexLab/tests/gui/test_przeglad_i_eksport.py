import csv
from collections.abc import Iterator
from pathlib import Path

import pytest
from PySide6.QtCore import QSettings, Qt
from PySide6.QtWidgets import QFileDialog
from pytestqt.qtbot import QtBot

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow


@pytest.fixture
def okno(qtbot: QtBot, tmp_path: Path) -> Iterator[OknoVexLab]:
    repo = KatalogSQLite(tmp_path / "katalog.sqlite3")
    rejestr = RejestrProducentow(repo)
    a = rejestr.dodaj(DaneProducenta("Producent testowy A"))
    b = rejestr.dodaj(DaneProducenta("Producent testowy B"))
    katalog = KatalogProduktow(repo, repo)
    katalog.dodaj(DaneProduktu("Żółty produkt", "A-Z", "Pełny opis\nDruga linia", a.id))
    katalog.dodaj(DaneProduktu("Alfa", "A-A", producent_id=a.id))
    katalog.dodaj(DaneProduktu("Beta", "B-B", producent_id=b.id))
    katalog.dodaj(DaneProduktu("Bez przypisania", "BEZ"))
    rejestr.edytuj(b.id, b.wersja, DaneProducenta(b.nazwa, False))
    ustawienia = QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)
    widget = OknoVexLab(
        PowlokaAplikacji(PreferencjeQt(ustawienia), "testowy", "test"),
        katalog,
        rejestr,
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), ImportSQLite(repo.plik), repo),
    )
    qtbot.addWidget(widget, before_close_func=lambda w: qtbot.waitUntil(lambda: not w._zadania))
    widget.show()
    qtbot.waitUntil(lambda: widget._katalog_wczytany and not widget._zadania)
    yield widget
    qtbot.waitUntil(lambda: not widget._zadania)
    widget.close()


def test_filtry_lacza_nazwe_sku_i_producenta_oraz_dzialaja_na_obu_ekranach(
    qtbot,
    okno: OknoVexLab,
) -> None:
    a = next(p for p in okno.producenci.lista() if p.nazwa.endswith("A"))
    combo = okno._filtry_producenta[0]
    combo.setCurrentIndex(combo.findData(str(a.id)))
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.filtr.rowCount() == 2
    assert okno._filtry_producenta[1].currentData() == str(a.id)
    okno.szukaj.setText("żÓŁTY")
    qtbot.waitUntil(lambda: not okno._zadania)
    assert [p.sku for p in okno.widoczne_produkty()] == ["A-Z"]
    okno.szukaj.setText("B-B")
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.filtr.rowCount() == 0
    assert "Brak wyników" in okno.info_produktow.text()
    assert not okno.eksportuj_przycisk.isEnabled()
    okno.wyczysc_filtry()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.filtr.rowCount() == 4
    assert all(c.currentData() == "wszyscy" for c in okno._filtry_producenta)


def test_filtr_bez_producenta_i_nieaktywnego(qtbot, okno: OknoVexLab) -> None:
    combo = okno._filtry_producenta[0]
    combo.setCurrentIndex(combo.findData("brak"))
    qtbot.waitUntil(lambda: not okno._zadania)
    assert [p.sku for p in okno.widoczne_produkty()] == ["BEZ"]
    b = next(p for p in okno.producenci.lista() if not p.aktywny)
    indeks = combo.findData(str(b.id))
    assert "nieaktywny" in combo.itemText(indeks)
    combo.setCurrentIndex(indeks)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert [p.sku for p in okno.widoczne_produkty()] == ["B-B"]


def test_odswiezenie_zachowuje_filtr_sortowanie_i_zaznaczony_produkt(
    qtbot: QtBot, okno: OknoVexLab
) -> None:
    a = next(p for p in okno.producenci.lista() if p.nazwa.endswith("A"))
    combo = okno._filtry_producenta[0]
    combo.setCurrentIndex(combo.findData(str(a.id)))
    qtbot.waitUntil(lambda: not okno._zadania)
    okno.filtr.sort(1, Qt.SortOrder.DescendingOrder)
    qtbot.waitUntil(lambda: not okno._zadania)
    okno.tabela_produktow.setCurrentIndex(okno.filtr.index(0, 1))
    wybrany = okno._produkt_z_indeksu(okno.tabela_produktow.currentIndex())
    rejestr = okno.producenci
    rejestr.edytuj(a.id, a.wersja, DaneProducenta("Zmieniona nazwa"))
    okno.odswiez()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert combo.currentData() == str(a.id)
    assert combo.currentText() == "Zmieniona nazwa"
    assert okno.filtr.rowCount() == 2
    assert okno.filtr.sortOrder() == Qt.SortOrder.DescendingOrder
    aktualny = okno._produkt_z_indeksu(okno.tabela_produktow.currentIndex())
    assert aktualny.id == wybrany.id


def test_podglad_pelnego_opisu_jest_tylko_do_odczytu_i_pozwala_przejsc_do_edycji(
    qtbot: QtBot, okno: OknoVexLab
) -> None:
    okno.szukaj.setText("A-Z")
    qtbot.waitUntil(lambda: not okno._zadania)
    okno.pokaz_szczegoly(okno.filtr.index(0, 1))
    dialog = okno.szczegoly
    assert dialog is not None
    assert dialog.nazwa.text() == "Żółty produkt"
    assert dialog.opis.toPlainText() == "Pełny opis\nDruga linia"
    assert dialog.producent.text() == "Producent testowy A"
    assert dialog.nazwa.isReadOnly() and dialog.opis.isReadOnly()
    qtbot.mouseClick(dialog.przycisk_edycji, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: okno.formularz is not None)
    assert okno.szczegoly is None
    assert okno.formularz.sku.text() == "A-Z"


def test_enter_w_tabeli_otwiera_podglad(qtbot: QtBot, okno: OknoVexLab) -> None:
    okno.przejdz("Produkty")
    tabela = okno.tabela_produktow
    tabela.setCurrentIndex(okno.filtr.index(0, 1))
    tabela.setFocus()
    okno.activateWindow()
    qtbot.waitUntil(tabela.hasFocus)
    qtbot.keyClick(tabela, Qt.Key.Key_Return)
    qtbot.waitUntil(lambda: okno.szczegoly is not None)
    assert okno.formularz is None


def test_csv_odpowiada_widocznym_wynikom_i_sortowaniu(
    qtbot: QtBot, okno: OknoVexLab, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    a = next(p for p in okno.producenci.lista() if p.nazwa.endswith("A"))
    okno._zmien_filtr_producenta(str(a.id))
    qtbot.waitUntil(lambda: not okno._zadania)
    okno.filtr.sort(1, Qt.SortOrder.DescendingOrder)
    qtbot.waitUntil(lambda: not okno._zadania)
    cel = tmp_path / "lista.csv"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **kw: (str(cel), ""))
    okno.eksportuj_wyniki()
    qtbot.waitUntil(lambda: not okno._zadania)
    with cel.open(encoding="utf-8-sig", newline="") as plik:
        rows = list(csv.reader(plik, delimiter=";"))
    assert [row[1] for row in rows[1:]] == ["A-Z", "A-A"]
    assert "Wyeksportowano 2" in okno.status.text()


def test_zmiana_filtrow_po_zleceniu_nie_rozszerza_eksportu(
    qtbot: QtBot, okno: OknoVexLab, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    okno._zmien_filtr_producenta("brak")
    qtbot.waitUntil(lambda: not okno._zadania)
    cel = tmp_path / "snapshot.csv"

    def wybierz(*args, **kwargs):
        okno.wyczysc_filtry()
        return str(cel), ""

    monkeypatch.setattr(QFileDialog, "getSaveFileName", wybierz)
    okno.eksportuj_wyniki()
    qtbot.waitUntil(lambda: not okno._zadania)
    with cel.open(encoding="utf-8-sig", newline="") as plik:
        rows = list(csv.reader(plik, delimiter=";"))
    assert len(rows) == 2
    assert rows[1][1] == "BEZ"
    assert okno.filtr.rowCount() == 4


def test_anulowanie_nie_tworzy_zadania_a_istniejacy_plik_nie_jest_nadpisywany(
    qtbot: QtBot, okno: OknoVexLab, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **kw: ("", ""))
    okno.eksportuj_wyniki()
    assert not okno._zadania
    cel = tmp_path / "istniejacy.csv"
    cel.write_text("zachowaj")
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **kw: (str(cel), ""))
    okno.eksportuj_wyniki()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert cel.read_text() == "zachowaj"
    assert "już istnieje" in okno.status.text()
    assert okno.model.rowCount() == 4


def test_awaria_odczytu_blokuje_eksport_i_brak_producenta_nie_resetuje_filtra(
    qtbot,
    okno: OknoVexLab,
) -> None:
    a = next(p for p in okno.producenci.lista() if p.nazwa.endswith("A"))
    okno._zmien_filtr_producenta(str(a.id))
    qtbot.waitUntil(lambda: not okno._zadania)
    okno._wczytaj_filtry(())
    assert okno._filtry_producenta[0].currentData() == str(a.id)
    okno._blad_odczytu(okno._numer_odczytu, "Błąd odczytu")
    assert not okno.eksportuj_przycisk.isEnabled()
    okno.eksportuj_wyniki()
    assert "Odśwież katalog" in okno.status.text()
    assert not okno._zadania
