# VexLab — instrukcje dla agentów

Wersja pakietu: 0.18, 2026-11-06. Status: projekt do przeglądu; nie jest potwierdzeniem wdrożenia ani zatwierdzeniem nowych decyzji.

## 1. Zakres i moc instrukcji

Ten plik określa sposób pracy w przyszłym repozytorium VexLab. Polecenie kontynuowania tworzenia programu z 2026-11-02 rozszerza poprzednie etapy 1–2 o minimalny lokalny katalog Produktów i powłokę GUI. Właściciel wybrał obowiązkowe, unikalne SKU bez rozróżniania wielkości liter (ADR-019/020). Przyrost 0.3 dodaje Producenta i opcjonalne pojedyncze przypisanie wybrane przez właściciela (ADR-022), z migracją 1→2 i kopią. Przyrost 0.4 dodaje filtry, podgląd i eksport CSV istniejących pól (ADR-024), bez zmiany domeny i schematu 2. Przyrost 0.5 wdraża lokalny import XLSX/CSV i trwałe pozycje Do poprawy według ADR-026/027, z migracją do schematu 3. Przyrost 0.6 (ADR-029/030/031) dodaje źródłowe sugerowane ceny sprzedaży z walutą/netto-brutto, uzupełnianie ich braków po SKU, wielokrotny wybór i edycję producenta/opisu, potwierdzane usuwanie z kopią oraz zdjęcia po SKU w formularzu pojedynczego Produktu przez publiczny katalog Shopify. Schemat 4 z kopią. EAN i płatne AI nie są wdrożone; budżet OpenAI nie został zaakceptowany. Domeny i producenci wyłącznie danymi użytkownika, bez seedów. Integracje z ADR-023 są odłożone. Przyrost 0.7 (ADR-032) dodaje lokalną galerię istniejącego Produktu: pliki, podgląd, kolejność i usuwanie z kopią oraz kontrolą wersji, bez migracji schematu 4. Bieżące możliwości opisuje README; pozostałe propozycje modelowe nadal wymagają decyzji. Nie tworzyć instalatora Windows ani fikcyjnych integracji bez odrębnego zakresu.

Projekt jest planowany od zera. Nie szukać dawnych decyzji ani nie uzależniać pracy od poprzedniej dokumentacji. Nie traktować zdań oznaczonych jako propozycje jak zgody na zmianę modelu. Podczas przyszłej pracy w repozytorium zachowywać zmiany użytkownika.

## 2. Czytanie dokumentacji i rozstrzyganie rozbieżności

Kolejność analizy: ten plik, [README](README.md), [konstytucja](ARCHITECTURE_CONSTITUTION.md), [model](DOMAIN_MODEL.md), [rejestr decyzji](ADR_INDEX.md), [system UI](UI_UX_DESIGN_SYSTEM.md), [roadmapa](ROADMAP.md). Kolejność czytania nie nadaje nowej propozycji pierwszeństwa przed zatwierdzoną decyzją.

W całym pakiecie obowiązują statusy:

| Oznaczenie | Znaczenie | Skutek dla agenta |
|---|---|---|
| WYMAGANIE | Wynika bezpośrednio z polecenia i rozmowy źródłowej | Zachować; zgłaszać sprzeczności |
| PROPOZYCJA | Nowy szczegół projektowy, reguła lub parametr | Nie implementować jako zatwierdzony bez decyzji właściciela |
| NIEUSTALONE | Brak źródła lub potwierdzenia | Nie dopowiadać znaczenia |
| KONFLIKT | Dwie zasady wymagają rozstrzygnięcia | Opisać obie strony, wpływ i rekomendację |

Zatwierdzenie musi mieć wskazaną osobę, datę, zakres i odnośnik do decyzji. Samo wygenerowanie pliku, jego obecność w repozytorium lub zapis słowa „musi” nie stanowią dowodu zatwierdzenia propozycji. Nowy plan korzysta wyłącznie z własnego rejestru ADR-001 i kolejnych numerów; nie wymaga odtwarzania dawnych decyzji.

## 3. Obowiązkowa analiza przed kodowaniem

Przed zmianą ustalić:

1. Jaki scenariusz użytkownika ma się zmienić i po czym poznamy sukces.
2. Które z 16 pojęć domenowych biorą udział; kto jest właścicielem każdego zmienianego pola.
3. Które niezmienniki są potwierdzone, a które dopiero proponowane.
4. Jaka jest granica agregatu i transakcji; czy potrzebny jest efekt zewnętrzny.
5. Jakie porty przypadków użycia są potrzebne i jak odizolować zewnętrzne DTO.
6. Które warstwy zostaną zmienione i jakie importy pojawią się po zmianie.
7. Jakie są konsekwencje dla migracji, odtworzenia danych, testów i dostępności UI.
8. Czy zadanie wymaga decyzji z rejestru otwartych zagadnień.

Jeżeli zadanie dotyka niezatwierdzonego modelu, najpierw przygotować konkretną propozycję: scenariusz, zmieniane pojęcia, alternatywy, przykładowe dane syntetyczne, niezmienniki oraz kryteria akceptacji. Kontynuować niezależne prace, ale nie utrwalać spornej relacji w schemacie SQLite ani publicznym API.

## 4. Nienaruszalne wymagania

- Najpierw model domenowy, potem integracje. Produkt jest niezależny od Allegro, PrestaShop, Subiekt GT i innych dostawców.
- Oferta prezentuje Produkt. Nie jest drugim, konkurencyjnym katalogiem produktów.
- Producent, Dostawca i PodmiotGPSR są odrębnymi rolami. KanałSprzedaży i KontoSprzedażowe są odrębnymi pojęciami. Przewoźnik nie jest KanałemSprzedaży.
- W dokumentach i komunikatach stosować określenie „Środek komunikacji”.
- Python, PySide6, SQLite; Clean Architecture i DDD. Warstwy: `rdzen`, `domena`, `przypadki_uzycia`, `adaptery`, `kanaly`, `gui`.
- Domena nie importuje PySide6, SQLite, klientów HTTP ani modeli zewnętrznych API. GUI nie zawiera reguł biznesowych i nie wykonuje SQL.
- Integracja tłumaczy modele zewnętrzne na wspólny model; nie tworzy własnego Produktu, Klienta ani Zamówienia jako konkurencyjnego źródła prawdy.
- Nowa instalacja ma zero rekordów biznesowych. Testowe podmioty, konta i cenniki występują wyłącznie w izolowanych fixture'ach; żaden mechanizm startu nie zasila nimi produkcji.

## 5. Granice kodu i styl pracy

Dokładny kontrakt importów opisuje konstytucja; technicznie wdrożono go dla etapu 2 w [ADR-001](docs/adr/ADR-001-granice-warstw.md). Nie spłaszczać sześciu warstw do jednego łańcucha i nie dodawać importu infrastruktury do GUI dla wygody. Połączenie implementacji portów wykonuje wyłącznie zewnętrzny punkt składania aplikacji.

Nazwy modułów i identyfikatorów w kodzie: proponowane polskie nazwy bez znaków diakrytycznych, np. `KontoSprzedazowe`; terminy ekranowe i dokumentacyjne zachowują polską pisownię. Format identyfikatorów domenowych, biblioteka dostępu do bazy i instalator Windows pozostają otwarte. Wersje developerskie, uv i backend pakietu Python opisuje [ADR-011](docs/adr/ADR-011-srodowisko.md). Nie wprowadzać ich pod pretekstem formatowania.

Stosować małe, typowane funkcje i jawne zależności. Nie przechwytywać wszystkich wyjątków bez klasyfikacji. Nie używać globalnego połączenia SQLite, globalnego kontenera usług ani mutowalnego singletonu domeny. Nie przemycać reguł domenowych do `rdzen`, dekoratorów, sygnałów Qt lub mapperów ORM.

Zmiana powinna mieć jeden cel. Nie dołączać masowego formatowania niezwiązanych plików, wymiany stosu ani refaktoryzacji całego projektu. Przed edycją sprawdzić zastane zmiany użytkownika; zachować je. Nie usuwać plików i danych, by uzyskać zielone testy.

## 6. Standard testowania i kontroli

Konfiguracja etapów 1–2 już istnieje. Z katalogu repozytorium: `uv sync --frozen`, następnie `uv run --frozen python scripts/check.py` i osobno sieciowy `uv run --frozen python scripts/audit.py`. Pełne instrukcje zawiera README. Poszczególne narzędzia można również wywołać przez `uv run`:

```powershell
python -m pytest
python -m ruff check .
python -m ruff format --check .
python -m mypy src
lint-imports
python -m bandit -r src
python -m pip_audit
```

Nie przedstawiać testów fundamentu jako dowodu działania aplikacji biznesowej. `lint-imports` jest poleceniem narzędzia import-linter; wymaga zainstalowanego środowiska i kontraktów. Audyt środowiska musi odpowiadać zależnościom dystrybuowanego produktu; osobno sprawdzać zależności developerskie.

| Rodzaj zmiany | Wymagane dowody |
|---|---|
| Reguła domenowa | Test pozytywny, graniczny, odrzucenie niepoprawnego stanu; bez Qt i bazy |
| Przypadek użycia | Sukces, błąd portu, brak częściowego zapisu, współbieżna edycja, jeśli dotyczy |
| Repozytorium SQLite | Test na rzeczywistej tymczasowej bazie: mapowanie, transakcja, ograniczenia |
| Migracja | Przejście ze wspieranych wersji, przerwanie, kopia i odtworzenie |
| Integracja | Mapowanie, timeout, duplikat, limit wywołań, odmowa autoryzacji, nieznany wynik |
| GUI | Klawiatura, fokus, stany błędu i pustki, DPI i oba motywy |
| Granice warstw | Kontrakty import-linter oraz przegląd dynamicznych zależności |

Nie dodawać testów wyłącznie powtarzających implementację. Nie wyłączać globalnie ostrzeżeń ruff/mypy/bandit. Wyjątek wymaga lokalnego uzasadnienia, właściciela, zakresu i terminu ponownej oceny. Brak sieci dla pip-audit oznacza brak wyniku, a nie brak podatności.

## 7. Bezpieczeństwo i praca z danymi

Nie umieszczać tokenów, haseł, danych klientów i pełnych odpowiedzi API w kodzie, fixture'ach, logach, zrzutach ekranu i zgłoszeniach. Sekrety mają być dostarczane przez port magazynu sekretów; jego implementacja Windows pozostaje propozycją. Baza zawiera co najwyżej odwołanie do sekretu, nigdy domyślny token.

Przed zmianą schematu opisać kompatybilność, procedurę kopii i przywracania oraz zachowanie przy awarii. Nie zakładać, że migracja „w dół” zawsze jest możliwa bez utraty danych. Nie uruchamiać testów na bazie użytkownika. Nie wykonywać rzeczywistych publikacji ofert i wysyłki wiadomości w testach automatycznych.

## 8. Zakończenie zadania

Raport podaje: co się zmieniło, jakie wymagania spełniono, jakie sprawdzenia wykonano, czego nie udało się sprawdzić i jakie decyzje nadal blokują dalszy krok. Dokumentacja musi być aktualizowana razem z zachowaniem aplikacji. Nie deklarować „gotowe do produkcji” wyłącznie na podstawie lintowania.

Przegląd zmiany ma potwierdzić: brak nowego konkurencyjnego modelu, właściwego właściciela danych, kierunek zależności, test niezmiennika, bezpieczeństwo danych oraz zgodność z centralnym Design Systemem. Szczegóły, które nie mają potwierdzenia, pozostają jawnie oznaczone.

## 9. Obowiązujący wzorzec wyglądu UI-REF-01

WYMAGANIE użytkownika: program ma wyglądać jak [załączony ekran](assets/UI_REFERENCE.png). Dokładny kontrakt: [UI_UX_DESIGN_SYSTEM, sekcje 15–23](UI_UX_DESIGN_SYSTEM.md). Wzorzec określa ciemną granatową powłokę, niebieskie akcje, boczne menu, cztery KPI, tabelę produktów, ostatnie operacje, statystyki, szybkie akcje, dwie karty integracji i pasek stanu. Nie zastępować go dowolnym dashboardem ani klasycznym formularzem Qt.

Przed implementacją ekranu sporządzić mapę widocznych opcji do przypadków użycia i modeli odczytu. Zachować nazwy i kolejność menu. Wszystkie wymienione na wzorcu funkcje są zakresem planu: Cenniki, media, opisy AI, tworzenie i szkice ofert, masowa edycja, zmiana/synchronizacja cen, układy/szablony, Allegro, PrestaShop, synchronizacja, kolejka, raporty i historia.

Zrzut nie ustala nowych niezmienników domeny. Nie przypisywać ceny i stanu bezpośrednio Produktowi tylko dlatego, że są kolumnami tabeli. Nie zmieniać listy 16 głównych bytów bez osobnej decyzji. Profile, logotypy i wersje z obrazu nie ustanawiają tożsamości firmy, wersji Pythona, limitu API ani modelu licencji.

Wymagania kontroli:

- Ctrl+K otwiera globalne wyszukiwanie; wszystkie ikony mają nazwy dostępności.
- „Masowa edycja” i „Edycja masowa” uruchamiają wspólny proces; kreatory układu i szablonów współdzielą edytor.
- Import, ceny, publikacja, AI i synchronizacja nie wykonują się w wątku GUI; ich przebieg jest widoczny jako Operacja.
- AI generuje propozycję, którą użytkownik zatwierdza. Nie publikuje samodzielnie i nie otrzymuje sekretów ani danych klientów przez przypadek.
- Dane ekranowe, nazwy producentów, `vexlabs`, domena sklepu, statystyki i daty nie trafiają do produkcyjnych seedów. Dane demonstracyjne wyłącznie w testach wizualnych.
- Widoczne „Połączono” i sukces Operacji wymagają rzeczywistego dowodu stanu. Testować częściowe połączenie i nieznany wynik.
- Odbiór ma obejmować porównanie z UI-REF-01 przy 1536×1024, a następnie testy responsywności, obu motywów, DPI i pustej bazy. Sama obecność przycisków nie jest ukończeniem funkcjonalności.

Wdrożono pierwszą powłokę UI i lokalny katalog (ADR-020/021); pełny odbiór wzorca pozostaje otwarty. Zgodnie z [ADR-018](docs/adr/ADR-018-nazwa-i-uzytkownik.md) nazwa aplikacji to VexLab, a nagłówek profilu wyświetla nazwę użytkownika. Obraz nadal obowiązuje dla kompozycji i opcji; jego tekst marki i demonstracyjny profil zastępuje nowe polecenie.

Poprawka 0.7.1: Zdjęcia i media ma odrębny widok (miniatury i otwieranie galerii), bez aliasu do strony Produkty.

Przyrost 0.8: właściciel zaakceptował ADR-033 odpowiedzią „tak” 2026-11-03. Opcjonalne dopasowania zero–wiele są wartościami Produktu (marka/model, opcjonalne roczniki i wariant). Wdrożono edycję i podgląd oraz schemat 5 z kopią. Bez zgadywania z nazw i bez mapowań API platform. Istniejące migracje 1–4 i ich sumy zachować.

Przyrost 0.9 (ADR-034): jawne mapowanie kolumn motocykla w imporcie XLSX/CSV, jedno dopasowanie na wiersz. Surowe wartości zachowywane w Do poprawy (schemat 6 z kopią). Bez odgadywania z tytułów i scalania SKU. Migracje 1–5 i ich sumy zachować.

WYMAGANIE właściciela z 2026-11-03: przy kandydacie do wersji 1.0 wykonać szczegółowy audyt techniczny i audyt przyjazności/intuicyjności interfejsu z perspektywy użytkownika. Plan: [AUDYT_1_0_PLAN](docs/AUDYT_1_0_PLAN.md). Audyt jest zaplanowany, nie wykonany; testy przyrostów nie zastępują go. Wyniki, poprawki i ponowna weryfikacja wymagają odrębnych dowodów.

Poprawka 0.9.1: Masowa edycja ma własny widok wyboru produktów, licznik i akcję wspólnej zmiany. Nie zastępować osobnych obszarów pracy aliasem strony Produkty; wspólny proces może mieć różne wejścia. Zachować niezależne zaznaczenia i poprawkę zbiorczego odtwarzania wyboru z 0.6.1. Schemat 6 bez zmian.

WYMAGANIE właściciela 2026-11-03: poza cennikami obsłużyć paczki gotowych ofert w ZIP (ADR-036). Przed wdrożeniem ustalić strukturę na reprezentatywnej paczce; nie zgadywać formatu plików, SKU i mapowania Produkt/Oferta. Wymaganie nie upoważnia do publikacji ani wykonania treści archiwum. Funkcja niewdrożona.

Doprecyzowanie właściciela 2026-11-03: różne układy producentów oraz ustawienia ofert to dane użytkownika, nie kod. Paczka Evotech jest przykładem kontraktu, nie seedem/domysłem dla wszystkich paczek. Nie zaszywać banerów, URL-i, kategorii, nazw kont/cenników ani treści. Oddzielić profil odczytu, układ per oferta i konfigurację publikacji. Analiza: docs/ANALIZA_PACZKI_OFERT_EVOTECH.md.

Przyrost 0.10 (ADR-037): podgląd listy rekordów JSON w ZIP i zewnętrzne pliki profili użytkownika. Bez trwałego modelu Oferty, migracji lub publikacji. Pełny cel wskazany przez właściciela to ZIP → Allegro z wymaganymi ustawieniami pobieranymi/dobieranymi przez program i API; podgląd jest dopiero pierwszym etapem. Nie zaszywać producenta, nazw plików, struktury sekcji lub ustawień konta.

Jawne polecenie właściciela 2026-11-03 zastępuje wcześniejszą paletę niebieską: dostarczone logo VexLabs z transparentnym tłem, granat/turkus/fiolet i złote akcenty. Zachować układ i opcje UI-REF-01, nie zmieniać obrazu referencyjnego. Zasób logo w src/vexlab/gui/zasoby/vexlabs.png. Nazwa aplikacji i katalogu danych nadal VexLab.

Wymagania właściciela wdrożone w 0.10.1: gotowy ZIP z profilem użytkownika otwiera oferty automatycznie, bez ręcznego mapowania; mapowanie ukryte w konfiguracji zaawansowanej. Nie zaszywać producenta/plików w kodzie. Po podglądzie jednym przyciskiem można dodać Produkty (SKU, nazwa, tekst opisu, opcjonalny producent) do lokalnego katalogu istniejącym atomowym importerem; znane SKU bez nadpisania, błędne do Do poprawy. Zdjęcia/ceny/EAN/układ pozostają danymi oferty w paczce, nie są automatycznie polami Produktu. Schemat 6 bez zmian. Raport: docs/POPRAWKA_0_10_1.md.

Przyrost 0.11 (ADR-038): zaakceptowane zapamiętywanie układów w profile_paczek w katalogu danych użytkownika, rozpoznawanie po strukturze, nie producencie/nazwie pliku. Brak wymogu profilu w każdym ZIP po jednorazowym nauczeniu. Niejednoznaczność → wybór; bez zgadywania. Edytor techniczny jako osobne okno zaawansowane. Modernizacja wizualna wspólnych kontrolek przy zachowaniu układu/menu i palety logo, bez nowej biblioteki UI. Schemat 6 bez zmian.

Wymagania cenowe 2026-11-04 (ADR-039): Cena bazowa z aktualnego cennika producenta; Allegro i PrestaShop z rzeczywistych odczytów API właściwego konta/oferty. Kanał >= bazowej zielony, poniżej czerwony. Braki/stare/nieporównywalne dane neutralne; nie zgadywać walut/VAT. Odczyty i porównania nie są wdrożone w 0.11.

Doprecyzowanie 0.11: właściciel zlecił czyszczenie listy Do poprawy. Usuwanie wskazanych wersji wpisów import_robocze z potwierdzeniem, spójną kopią bazy i atomową transakcją; bez usuwania Produktów, plików źródłowych i historii importy. Bez migracji.


Przyrost 0.12: właściciel 2026-11-05 zatwierdził ADR-035 (zakres ZIP)
odpowiedzią „tak” i „działamy”. Jeden szkic wskazuje jeden Produkt,
Produkt ma wiele szkiców. Trwała treść użytkownika, brak seedów. Migracja
6→7 z kopią, zachować migracje 1–6 i sumy. Zapis Produktów i szkiców
atomowy; istniejące Produkty bez nadpisania. Usuwanie powiązanego Produktu
blokowane. Edycja tytułu/HTML szkicu nie zmienia Produktu lub sekcji.
Cel późniejszy: wysyłka do szkiców Allegro; publikacja osobno. API nadal
niewdrożone. Raport docs/PRZYROST_0_12.md.


Przyrost 0.13 — jawne polecenie właściciela zastępuje ograniczenie 0.12
o niezmienności sekcji: wizualny opis i przeciąganie układu (ADR-040).
Edycja zmienia pełny opis i sekcje jednego szkicu atomowo, bez zmiany
Produktu, metadanych i odcisku importu. Otwarcie/anulowanie bez przepisania
źródła. Treść i układ wyłącznie użytkownika. Schemat 7 bez migracji.
HTML nie pobiera zasobów. Galeria pokazuje adresy bez zdalnych miniatur.


Poprawka 0.13.1 na polecenie właściciela: usuwanie wielu lokalnych szkiców
oraz wszystkich wyników bieżącego filtra. Zakres uchwycony przed
potwierdzeniem, domyślnie Nie, jedna kopia i atomowy zapis z kontrolą
wersji wszystkich wskazanych wpisów. Produkty i zdalne szkice bez zmian.
Schemat 7 bez migracji. Raport docs/POPRAWKA_0_13_1.md.


Przyrost 0.14: właściciel 2026-11-05 wymaga wyglądu inspirowanego Windows
11 z zachowaniem układu i wszystkich funkcji. Wspólny QSS i paleta Qt,
spójne kontrolki, płaskie menu, nowa typografia i kolory ikon zależne od
motywu. Logo i brand granat/turkus/fiolet/złoto zachowane. Bez wymiany
stosu, natywnego Mica, zmian bazy/modelu i danych użytkownika. Schemat 7.
Raport docs/PRZYROST_0_14.md. Audyt kandydata 1.0 nadal zaplanowany.


Poprawka 0.14.1 — polecenie właściciela: kolorowe ikony funkcji menu
oraz znaki Allegro/PrestaShop, lokalne zasoby z licencją. Nazwy, kolejność,
zwijanie i działanie zachowane. Wyłącznie prezentacja, bez zmiany danych,
modelu i schematu 7. Raport docs/POPRAWKA_0_14_1.md.


Przyrost 0.15 — jawne polecenie właściciela zastępuje wielorzędowy pasek
Produktów: cztery główne przyciski, pozostałe akcje w Więcej akcji i pod
prawym przyciskiem myszy. Współdzielone QAction, warunki wyboru i te same
procesy zapisu/usuwania. PPM w grupie zachowuje wybór, poza grupą wybiera
kliknięty wiersz, na pustym miejscu usuwa zaznaczenie. Shift+F10/Menu
zachowuje bieżący wybór. Schemat 7 bez migracji, bez zmian modelu/danych.
Pozostały układ i funkcje zachowane. Raport docs/PRZYROST_0_15.md.


Poprawka 0.15.1: właściciel zlecił krótsze etykiety menu Produktów.
Tekst skrócony, zakres usuwania i eksportu wyjaśniany dymkami. Bez zmiany
sygnałów, przypadków użycia, bazy lub danych. Schemat 7 bez migracji.
Dystrybucja przez zatwierdzoną gałąź pobieranie/vexlab-0.15 na GitHub.
Raport docs/POPRAWKA_0_15_1.md.


Przyrost 0.16 — polecenia właściciela 2026-11-05: Cenniki mają własną
bibliotekę dokumentów z nazwą, producentem, rokiem i wydaniem. Zapis źródła
nie tworzy Produktów; wybrane pozycje dodawane z PPM → Dodaj do katalogu.
Usuwanie dokumentów po potwierdzeniu i kopii pozostawia Produkty. Schemat 8,
zachować definicje i sumy migracji 1–7 (ADR-041). Z Produktów usunięto
przycisk importu kierujący do Cenników. Zdjęcia HTTPS w edytorze szkicu oraz
podgląd całej oferty z układem sekcji, przez port i odczyt w tle (ADR-042).
To zastępuje wcześniejsze ograniczenie braku pobierania obrazów w edytorze;
pozostały HTML nadal nie pobiera zasobów. Bez udawania integracji Allegro.
Raport docs/PRZYROST_0_16.md.


Przyrost 0.17 — właściciel 2026-11-06 zaakceptował pięć usprawnień Cenników
(ADR-043): podgląd obok listy, statusy Nowy / W katalogu / Inna cena /
Do poprawy, porównanie ceny z zapisaną ceną bazową w Decimal i ustawienie
Aktualny/Archiwalny per producent. Trzy główne akcje i menu/PPM. Ustawienie
nie nadpisuje cen Produktów; nie zgadywać walut/VAT, bez producenta brak
aktualnego cennika. Schemat 9 z kopią, zachować migracje 1–8 i ich sumy.
Szczegóły i ograniczenia: docs/PRZYROST_0_17.md.


Poprawka 0.17.1 (ADR-044), zgłoszenie właściciela 2026-11-06: jawny
wariant usuwania Produktów z powiązanymi lokalnymi szkicami po dodatkowym
potwierdzeniu ich liczby, domyślnie Nie. Domyślna blokada pozostaje;
rozszerzony zapis tylko po drugim potwierdzeniu, w jednej transakcji
z kontrolą ID/wersji szkiców i Produktów oraz kopią. Bez operacji w
kanałach sprzedaży. Wyraźne ostrzeżenie przy błędzie. Schemat 9 bez migracji.
Raport docs/POPRAWKA_0_17_1.md.


Kierunek właściciela 2026-11-06: przyszły katalog z Subiekta tylko do
odczytu; ZIP ofert nie tworzy Produktów w Subiekcie ani lokalnym katalogu.
Rozdzielenie importu ofert i katalogu wymaga osobnego etapu/modelu powiązań;
nie jest wdrożone w 0.17.1. Obecne dane zachować. Plan zużycia dysku:
stronicowanie, zdjęcia na żądanie, limitowany/czyszczony cache i retencja
kopii do dopracowania; konkretne limity nieustalone. Szczegóły w ROADMAP.md.


Przyrost 0.18 (ADR-045), polecenie właściciela 2026-11-06: opcjonalny
EAN-8/EAN-13 w mapowaniu i zapisanym cenniku, Do poprawy, formularzu
Produktu, szczegółach i eksporcie CSV. Tekst, zachowane zera, kontrola
cyfry kontrolnej, bez generowania i unikalności EAN; SKU nadal kluczem.
Schemat 10 z kopią, zachować migracje 1–9. Brak EAN jest poprawny.
Przyszły odczyt katalogu z Subiekta i rozdzielenie ZIP pozostają osobnym
etapem bez zapisów w Subiekcie. Raport docs/PRZYROST_0_18.md.


WYMAGANIE właściciela 2026-11-06: w przyszłej integracji Allegro zakładka
Szkice ma pobierać rzeczywiste szkice z wybranego konta, pokazywać ich treść
oraz pozwalać na edycję i zapis przez API bez otwierania strony Allegro.
Rozróżnić lokalne i zdalne szkice, obsłużyć aktualność, konto i konflikty.
Zapis szkicu nie publikuje oferty. Zaplanowane w ROADMAP.md, niewdrożone.

WYMAGANIE właściciela 2026-11-06: zaplanować wspólny widok zamówień
Allegro i PrestaShop z rozwijanymi filtrami statusów i rzeczywistymi
licznikami według dostarczonego wzorca. Filtrowanie po kanale i koncie,
szczegóły oraz aktualność odczytu; mapowania statusów danymi użytkownika.
Nie zgadywać znaczenia Indywidualne ani reguły Po terminie. Ręczne tworzenie
zamówień wymaga doprecyzowania. Szczegóły w ROADMAP.md; niewdrożone.

Przyrost 0.18 uzupełnia ADR-046: bazowa z wybranego aktualnego cennika,
aktualizacja z historią poprzednika i atomowym przejęciem statusu, jawne Nowy,
kliknięcie przyczyny Do poprawy, reset kreatora, precyzja kwot XLSX,
szybkie akcje w preferencjach i seryjne zdjęcia zaznaczenia po SKU.
Adres producenta danymi użytkownika; publiczny Shopify, bez zaszytego Evotech.
Jedna kopia na serię, limit nowych zdjęć, anulowanie między żądaniami.
Audyt bieżącego kodu: docs/AUDYT_TECHNICZNY_0_18.md; audyt UX 1.0 nadal osobno.

Przyrost 0.19 (ADR-047), kontynuacja właściciela po 0.18: profile układów
cenników jako dane użytkownika w profile_cennikow, rozpoznawanie po pełnych
nagłówkach/kolejności, kilka dopasowań wymaga wyboru. Propozycje podstawowych
kolumn dla nowych układów, bez zgadywania ceny/VAT/waluty/producenta.
I/O w tle, walidacja mapowania wspólna z importerem. Producent widoczny,
mapowanie i próbka zwijane; zapisy profilu/cennika/katalogu rozdzielone.
Zgoda na cache formuł tylko dla bieżącego pliku. Schemat 10 bez zmian.
Raport docs/PRZYROST_0_19.md; nie oznacza wdrożenia integracji ani audytu UX.

Przyrost 0.20 (ADR-048) zastępuje obowiązkowe lokalne powiązanie szkicu
z Produktem z ADR-035/0.12. Nowe szkice ZIP mają brak produkt_id i wersji
Produktu; dawne relacje zachować. Nie tworzyć kartotek z paczki i nie
udostępniać dawnego przycisku dodawania Produktów z ZIP. Zapis atomowy,
deduplikacja i własna wersja szkicu pozostają. Schemat 11 z kopią;
opublikowane migracje 1–10 i sumy bez zmian. Starych danych nie usuwać.
Właściciel potwierdził 2026-11-06 **Subiekt GT**, wyłącznie odczyt katalogu.
Konektor nie jest wdrożony; plan docs/SUBIEKT_GT_ODCZYT_PLAN.md. Nie wybierać
mechanizmu dostępu/licencji/sekretów bez przygotowania. Raport docs/PRZYROST_0_20.md.

Poprawka 0.20.1 — bezpośrednie polecenie właściciela: grupy bocznego menu
są rozwijanymi belkami. Kliknięcie nie nawiguje; kolejność i ikony zachowane.
Ręczne rozwinięcie zapamiętywane w preferencjach, nawigacja odsłania aktywną
grupę. Globalny tryb ikon zachowuje poprzedni wybór grup. Schemat 11 bez zmian.
Raport docs/POPRAWKA_0_20_1.md; nie zmienia zakresu integracji.

Dodatkowy zakres 0.20.1 z polecenia właściciela: SzczegolyPaczki (także z listy
szkiców) pokazuje zdjęcia w galerii i sekcjach zamiast URL-i. Wspólny port
PodgladZdjec/ObrazyOferty, asynchroniczne odczyty, ograniczony cache w pamięci,
bez zapisu obrazów w bazie/dysku. Bezpieczny tekst przeniesiony do wspólnego
modułu tekst_podgladu; nadal blokuje zasoby HTML. Zamknięcie zatrzymuje kolejkę
podglądu i ignoruje spóźniony wynik. Dane użytkownika i schemat 11 bez zmian.

Poprawka 0.20.2 na polecenie właściciela: kolorowe belki nawigacji w palecie
logo, warianty jasne/ciemne i stany interakcji. Belki 13 px zaokrąglenia,
zakładki/Dashboard i przycisk zwijania 12 px. Tylko prezentacja; kolejność,
ikony, stan grup, baza i funkcje zachowane. Raport docs/POPRAWKA_0_20_2.md.

Poprawka 0.20.3 — właściciel zaakceptował dopracowanie menu: subtelne
zwinięte belki, silniejszy akcent po rozwinięciu, większe odstępy po grupie,
wspólne marginesy i brak wymuszania szerokości poza viewport nawigacji.
Nie przywracać poziomego przesuwania menu; zachować responsywne szerokości
belek i zakładek, tryb ikon i dotychczasowe funkcje. Schemat 11 bez zmian.
Raport docs/POPRAWKA_0_20_3.md.

Poprawka 0.20.4 — polecenie właściciela 2026-11-07: natywny pasek tytułu
ma podążać za motywem. Adapter DWM podłączony w bootstrapie, kolory z Design
Systemu; Windows 11 obsługuje kolor nagłówka, Windows 10 ciemny wariant
systemowy. Zachować systemowe przyciski, ramkę i obsługę okien. Bez zmian
danych, zależności lub schematu 11. Raport docs/POPRAWKA_0_20_4.md.

Przyrost 0.21 — kontynuacja roadmapy na polecenie właściciela 2026-11-07:
miniatury katalogu na żądanie, bez pełnego odczytu BLOB przy starcie GUI.
Port ograniczonej partii ID/wersja, osobna metadana ma_zdjecia w DTO,
odczyt w tle i ograniczony cache Qt (ADR-049). Zachować zakres zaznaczeń,
operacje masowe i pomijanie istniejących zdjęć w serii. Schemat 11 bez
migracji; stronicowanie samych rekordów i konektor GT nadal niewdrożone.

Przyrost 0.22 — kontynuacja roadmapy 2026-11-07: stronicowany odczyt
katalogu w SQLite (100/250/500), globalny filtr/sortowanie i liczniki.
Zaznaczenia według ID/wersji są niezależne od strony oraz widoku. Pełne
wyniki pobierane tylko na jawną akcję; odświeżenie dodatkowo aktualizuje
jawnie zaznaczone rekordy. Nie zawężać eksportu/usuwania wszystkich do strony.
Schemat 11 bez migracji. ADR-050 i docs/PRZYROST_0_22.md. Konektor GT nadal
niewdrożony; przygotowanie nie jest dowodem jego działania.

Przyrost 0.23 — kontynuacja roadmapy 2026-11-07: strony pozycji Cenników
100/250/500, lekki indeks globalnych ocen i ograniczony odczyt JSON SQLite.
Duplikaty wykrywać w całym dokumencie, nie tylko stronie. Wybór między
stronami i dodanie wyłącznie wskazanych indeksów zachowane; przeliczenie
wyboru przed zapisem pozwala wybrać jedną z duplikowanych pozycji.
Schemat 11 bez migracji. ADR-051 i docs/PRZYROST_0_23.md.
Właściciel potwierdził: baza GT na serwerze, klient GT na laptopie.
Nie zgadywać sposobu autoryzacji, instancji, schematu ani licencji Sfery.


Przyrost 0.24 (2026-11-07): port OdczytKatalogu i serwis przeglądania
wydzielone od lokalnych komend. Ustawienia → Subiekt GT — przygotowanie
połączenia → Sprawdź środowisko / Kopiuj raport: ręczny odczyt lokalnych
metadanych Windows w tle. Nie testuje serwera, Sfery ani licencji.
Brak konektora GT, migracji i nowych zależności. Licencja Sfery nieustalona.
ADR-052 i docs/PRZYROST_0_24.md. Zachować dotychczasową edycję lokalną;
przyszłe źródło GT wymaga zewnętrznej tożsamości i blokady komend zapisu.


2026-11-08 — właściciel potwierdził brak Sfery, wskazał S2S e-mo, następnie
wybrał docelową integrację bez pośredników i odłożenie GT. Nie uznawać
wcześniejszej propozycji bezpośredniego SQL za ostateczny wybór mechanizmu.
Teraz priorytet Allegro; właściciel ma aplikację produkcyjną.
Przyrost 0.25/ADR-053: sesja Device Flow wyłącznie w pamięci, /me i lista
szkiców INACTIVE. Edycja/zapis zdalnych szkiców nadal kolejny krok, bez
publikacji. Nie utrwalać sekretów pod pretekstem zapamiętywania sesji.
Raport i instrukcja: docs/PRZYROST_0_25.md.


Przyrost 0.26 — polecenie właściciela 2026-11-08: konfiguracja Allegro
w Ustawienia → Integracje, z zapamiętaniem na Windows. Zastępuje zakaz
utrwalania z sesji 0.25 w tym jawnym zakresie. ADR-054: port MagazynAllegro,
DPAPI bieżącego użytkownika, wyłącznie szyfrogram, odnowienie tokenu oraz /me
przed sukcesem. Rozłącz i zapomnij usuwa zapis; zamknięcie go zachowuje.
Schemat 11 i zależności bez zmian. Raport docs/PRZYROST_0_26.md.
Allegro jest docelowym wspólnym obszarem wszystkich operacji kanału: nowe
zamówienia i ich obsługa, szkice, aktywne oferty, ceny/stany i dalsze działania
udostępniane przez API. Tylko konfiguracja konta jest w Ustawieniach. Nie
utożsamiać panelu Allegro z samą listą szkiców. Te przyszłe procesy i wspólna
filtracja zamówień po Allegro/PrestaShop wymagają kolejnych implementacji;
nie dodawać udawanych statystyk lub działań w tym przyroście.


Poprawka 0.26.1 — polecenie właściciela 2026-11-08: Ustawienia → Integracje
to wspólne miejsce konfiguracji Allegro, Subiekta GT i przyszłych integracji.
Osobne zakładki, zachowana diagnostyka i zapamiętywanie Allegro. Skrót
z Allegro wybiera jego zakładkę. GT nadal odłożony; nie dodawać fikcyjnych
połączeń. Schemat 11 i zależności bez zmian. docs/POPRAWKA_0_26_1.md.


Przyrost 0.27 — polecenie właściciela 2026-11-08: przyciski jak na nowym
screenie referencyjnym. Niebieskie główne akcje, ciemne pomocnicze, ikony,
zaokrąglenia i karty szybkich akcji z opisem. To zastępuje złote wypełnienie
przycisków; logo, układ i grupy menu zachowane. Nie kopiować liczb/kont
z demonstracji. Nie włączać niewdrożonych funkcji. Menu nowej oferty oraz
odczyt Allegro prowadzą wyłącznie do już zaimplementowanych procesów.
Schemat 11 bez zmian. Szczegóły docs/PRZYROST_0_27.md.


Przyrost 0.28 — właściciel 2026-11-08 zaakceptował podział Ustawień:
Ogólne / Integracje / Dane i kopie / O programie. W Integracjach lista usług
ze stanem i konfiguracja obok; Dane aplikacji Allegro zwijane, akcje zależne
od rzeczywistego stanu połączenia. Nie zastępować obszarów pracy ustawieniami
konta. GT i PrestaShop nadal w przygotowaniu. Kopia dotychczasowa, diagnostyka
istniejącym przypadkiem użycia. Schemat 11 i zależności bez zmian.
Szczegóły docs/PRZYROST_0_28.md.
