"""Miniatury widocznych wierszy: jedna partia I/O naraz, ograniczona pamięć."""

from collections import OrderedDict
from typing import cast
from uuid import UUID

from PySide6.QtCore import QEvent, QObject, Qt, QTimer
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import QTableView, QWidget

from vexlab.gui.katalog import ModelProduktow
from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.katalog import KatalogProduktow, ProduktDTO

Klucz = tuple[UUID, int]


class MiniaturyKatalogu(QObject):
    LIMIT_WPISOW = 128
    LIMIT_BAJTOW = 8 * 1024 * 1024

    def __init__(
        self,
        parent: QWidget,
        model: ModelProduktow,
        tabele: list[QTableView],
        katalog: KatalogProduktow,
        uruchom: Uruchom,
    ) -> None:
        super().__init__(parent)
        self.model, self.tabele, self.katalog, self.uruchom = model, tabele, katalog, uruchom
        self.cache: OrderedDict[Klucz, tuple[QIcon | None, int, str]] = OrderedDict()
        self.bajty = 0
        self.generacja = 0
        self.trwa = False
        self.aktywne = True
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self._odczytaj)
        model.ikona_miniatury = self.ikona
        model.opis_miniatury = self.opis
        model.modelReset.connect(self.reset)
        for tabela in tabele:
            tabela.viewport().installEventFilter(self)
            tabela.verticalScrollBar().valueChanged.connect(self.zaplanuj)
            tabela.horizontalScrollBar().valueChanged.connect(self.zaplanuj)
            tabela.model().layoutChanged.connect(self.zaplanuj)
            tabela.model().rowsRemoved.connect(self.zaplanuj)
            tabela.model().rowsInserted.connect(self.zaplanuj)

    def eventFilter(self, obiekt: QObject, zdarzenie: QEvent) -> bool:
        if zdarzenie.type() in (QEvent.Type.Show, QEvent.Type.Resize, QEvent.Type.Paint):
            self.zaplanuj()
        return False

    def zaplanuj(self) -> None:
        if self.aktywne and not self.timer.isActive():
            self.timer.start()

    def reset(self) -> None:
        self.generacja += 1
        self.cache.clear()
        self.bajty = 0
        self.zaplanuj()

    def zamknij(self) -> None:
        self.aktywne = False
        self.timer.stop()
        self.cache.clear()
        self.bajty = 0

    def ikona(self, produkt: ProduktDTO) -> QIcon | None:
        klucz = (produkt.id, produkt.wersja)
        if klucz not in self.cache:
            return None
        self.cache.move_to_end(klucz)
        return self.cache[klucz][0]

    def opis(self, produkt: ProduktDTO) -> str:
        wpis = self.cache.get((produkt.id, produkt.wersja))
        if wpis is not None:
            return wpis[2]
        return "Ładowanie zdjęcia…" if produkt.ma_zdjecia else "Brak zdjęcia."

    def widoczne(self) -> tuple[Klucz, ...]:
        wynik: dict[Klucz, None] = {}
        for tabela in self.tabele:
            if not tabela.isVisible() or tabela.isColumnHidden(0):
                continue
            model = tabela.model()
            # Widoki mają wspólny proxy model; UserRole zwraca stabilny klucz.
            poczatek = max(0, tabela.rowAt(0))
            koniec = tabela.rowAt(tabela.viewport().height() - 1)
            if koniec < 0:
                koniec = model.rowCount() - 1
            for wiersz in range(poczatek, min(koniec + 1, poczatek + 64)):
                klucz = model.index(wiersz, 0).data(Qt.ItemDataRole.UserRole)
                if klucz is not None:
                    wynik[cast(Klucz, klucz)] = None
        return tuple(wynik)

    def _odczytaj(self) -> None:
        if not self.aktywne or self.trwa:
            return
        partia = tuple(k for k in self.widoczne() if k not in self.cache)[:32]
        if not partia:
            return
        numer = self.generacja
        self.trwa = True

        def zakoncz(dane: dict[UUID, bytes], blad: str = "") -> None:
            self.trwa = False
            if not self.aktywne:
                return
            if numer == self.generacja:
                for klucz in partia:
                    self._dodaj(klucz, dane.get(klucz[0]), blad)
                if self.model.rowCount():
                    self.model.dataChanged.emit(
                        self.model.index(0, 0),
                        self.model.index(self.model.rowCount() - 1, 0),
                        [Qt.ItemDataRole.DecorationRole, Qt.ItemDataRole.ToolTipRole],
                    )
            self.zaplanuj()

        self.uruchom(
            lambda: self.katalog.pobierz_miniatury(partia),
            lambda wynik: zakoncz(cast(dict[UUID, bytes], wynik)),
            lambda kod, komunikat: zakoncz({}, "Nie udało się odczytać zdjęcia. Odśwież katalog."),
        )

    def _dodaj(self, klucz: Klucz, dane: bytes | None, blad: str) -> None:
        ikona = None
        koszt = 0
        opis = blad or "Zdjęcie zmieniło się lub zostało usunięte. Odśwież katalog."
        if dane and not blad:
            pixmap = QPixmap()
            if len(dane) <= 512 * 1024 and pixmap.loadFromData(dane):
                pixmap = pixmap.scaled(
                    128,
                    128,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
                ikona = QIcon(pixmap)
                koszt = pixmap.width() * pixmap.height() * 4 + len(dane)
                opis = "Zdjęcie produktu."
            else:
                opis = "Nieprawidłowa miniatura. Sprawdź galerię produktu."
        if klucz in self.cache:
            self.bajty -= self.cache.pop(klucz)[1]
        self.cache[klucz] = ikona, koszt, opis
        self.bajty += koszt
        while len(self.cache) > self.LIMIT_WPISOW or self.bajty > self.LIMIT_BAJTOW:
            self.bajty -= self.cache.popitem(last=False)[1][1]
