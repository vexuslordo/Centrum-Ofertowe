"""Umieszcza istniejące kontrolki Allegro w panelach jednej zakładki."""

from typing import TYPE_CHECKING, cast

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QBoxLayout,
    QDialogButtonBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.elementy_paneli_ofert import WierszUstawienia, sekcja_panelu
from vexlab.gui.wiersze_nowych_ofert import WierszNowejOferty
from vexlab.gui.zaznaczanie_przygotowania import ZaznaczaniePrzygotowania

if TYPE_CHECKING:
    from vexlab.gui.centrum_nowych_ofert import CentrumNowychOfert
    from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow


class OsadzonePrzygotowanie:
    def __init__(self, centrum: "CentrumNowychOfert") -> None:
        self.centrum = centrum
        self.dialog: DialogNowychSzkicow | None = None
        self.przeniesione: list[QWidget] = []
        self._postep_host: QWidget | None = None
        self.wybor: ZaznaczaniePrzygotowania | None = None
        self.opisy: dict[str, WierszUstawienia] = {}
        self.proxy: list[tuple[QPushButton, QPushButton]] = []
        self.akcje_menu: list[QAction] = []
        self.ustawienia = QToolButton()
        self.ustawienia.setText("Ustawienia paczki")
        self.ustawienia.setCheckable(True)
        self.ustawienia.setChecked(True)
        self.ustawienia.toggled.connect(centrum.uklad.lewy.setVisible)
        self.ustawienia.setParent(centrum.page)
        self.ustawienia.hide()
        action = centrum.uklad.menu.addAction("Panel ustawień")
        action.setCheckable(True)
        action.setChecked(True)
        action.toggled.connect(self.ustawienia.setChecked)
        self.ustawienia.toggled.connect(action.setChecked)

    def _przenies(self, widget: QWidget, layout: QBoxLayout) -> None:
        layout.addWidget(widget)
        widget.show()
        self.przeniesione.append(widget)

    def _praca_zmieniona(self, *_: object) -> None:
        self.centrum.odswiez(wymus=True)

    def _ustaw_lewy_panel(self, d: "DialogNowychSzkicow") -> None:
        u = self.centrum.uklad
        host = QWidget()
        outer = QVBoxLayout(host)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(10)
        dane = sekcja_panelu("01", "Ustawienia paczki", outer)
        form = cast(QHBoxLayout, d.formularz.layout())
        form.setDirection(QBoxLayout.Direction.TopToBottom)
        self._przenies(d.formularz, dane)
        d.ilosc.setMaximumWidth(16777215)
        form.setSpacing(5)
        if d.katalog_uzytkownika is not None:
            producer_label = d.formularz.findChild(QLabel, "etykietaProducentaPanel")
            if producer_label is None:
                producer_label = QLabel("Producent lokalny *")
                producer_label.setObjectName("etykietaProducentaPanel")
            form.insertWidget(2, producer_label)
            producer_label.show()
            form.insertWidget(3, d.producent_lokalny)
            d.producent_lokalny.show()
            self.przeniesione.append(d.producent_lokalny)
            self._przenies(d.zapis_lokalny, dane)
            self._przenies(d.info_katalogu, dane)
        for field in (d.waluta, d.producent_lokalny, d.ilosc):
            field.setFixedHeight(32)
        d.info_katalogu.setWordWrap(True)
        for i in range(form.count()):
            item = form.itemAt(i)
            field_label = item.widget() if item else None
            if isinstance(field_label, QLabel):
                field_label.setProperty("etykietaPolaOfert", True)
        d.info_katalogu.setObjectName("opisZapisuOfert")
        d.producent_lokalny.setPlaceholderText("Wybierz lub wpisz producenta…")
        producer_edit = d.producent_lokalny.lineEdit()
        if producer_edit is not None:
            producer_edit.setPlaceholderText("Wybierz lub wpisz producenta…")
        dane.setSpacing(6)
        allegro = sekcja_panelu("02", "Ustawienia Allegro", outer)
        for key, widget, name, icon in (
            ("gpsr", d.sprzedaz_przycisk, "GPSR i dostawa", "uzytkownik"),
            ("vat", d.vat_przycisk, "VAT według krajów", "plik"),
            ("przelicznik", d.przelicznik_przycisk, "Przelicznik cen", "zmiana_cen"),
            ("kategoria", d.produkt_przycisk, "Produkt z katalogu", "oferta"),
            ("parametry", d.parametry_masowe, "Parametry", "ustawienia"),
        ):
            row = WierszUstawienia(widget, name, icon)
            allegro.addWidget(row)
            self.przeniesione.append(widget)
            self.opisy[key] = row
            if key == "kategoria":
                d.nowy_przycisk.setText("Nowy produkt w Allegro…")
                d.nowy_przycisk.setToolTip(
                    "Produktu nie ma w katalogu Allegro? Wybierz kategorię i przygotuj "
                    "jego nową definicję. Utworzenie nastąpi dopiero po końcowym sprawdzeniu "
                    "i potwierdzeniu wysyłki szkiców."
                )
                d.nowy_przycisk.setObjectName("masowaAkcjaOfert")
                d.nowy_przycisk.setIcon(ikona("dodaj"))
                d.nowy_przycisk.setFixedHeight(32)
                self._przenies(d.nowy_przycisk, allegro)
        allegro.setSpacing(6)
        self._przenies(d.automatyczny_dobor, allegro)
        d.automatyczny_dobor.setText("Automatyczny dobór")
        self._przenies(d.kompletny, allegro)
        d.kompletny.setText("Dane do publikacji")
        masowa = sekcja_panelu("03", "Masowa edycja", outer)
        masowa.setSpacing(6)
        for name, icon, target, reason in (
            ("Przypisz GPSR", "uzytkownik", d.sprzedaz_przycisk, ""),
            ("Ustaw VAT", "plik", d.vat_przycisk, ""),
            (
                "Masowa zmiana kategorii",
                "oferta",
                None,
                "Masowa zmiana kategorii nie jest wdrożona. Dobierz produkt w Kategorie Allegro.",
            ),
            ("Masowe parametry", "ustawienia", d.parametry_masowe, ""),
            (
                "Masowe zdjęcia",
                "media",
                None,
                "Masowa zmiana galerii nie jest wdrożona. Zdjęcia są w danych paczki.",
            ),
        ):
            button = QPushButton(name)
            button.setIcon(ikona(icon))
            button.setIconSize(QSize(14, 14))
            button.setObjectName("masowaAkcjaOfert")
            button.setFixedHeight(32)
            if target is None:
                button.setEnabled(False)
                button.setToolTip(reason)
            else:
                button.clicked.connect(target.click)
                self.proxy.append((button, target))
            masowa.addWidget(button)
        d.duplikaty_przycisk.setIcon(ikona("szukaj"))
        d.duplikaty_przycisk.setObjectName("masowaAkcjaOfert")
        d.duplikaty_przycisk.setFixedHeight(32)
        self._przenies(d.duplikaty_przycisk, masowa)
        for button in (d.masowa, d.popraw_przycisk):
            action = u.menu.addAction(button.text())
            action.triggered.connect(button.click)
            self.akcje_menu.append(action)
        for control in self.przeniesione:
            control.setMinimumWidth(0)
            control.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        u.kontrolki_layout.addWidget(host)
        u.wskazowka.hide()
        u.import_group.hide()

    def osadz(self, dialog: "DialogNowychSzkicow") -> None:
        if self.dialog is dialog:
            return
        if self.dialog is not None:
            raise ValueError("Najpierw zakończ obecne przygotowanie.")
        self.dialog = dialog
        c, page, u = self.centrum, self.centrum.page, self.centrum.uklad
        self._recznie_wlaczone = page.recznie.isEnabled()
        dialog.setWindowFlags(Qt.WindowType.Widget)
        cast(QVBoxLayout, dialog.layout()).setContentsMargins(0, 0, 0, 0)
        dialog.tytul_przygotowania.hide()
        self._ustaw_lewy_panel(dialog)
        dialog.karty_ustawien.hide()
        dialog.pasek_wyboru.hide()
        self._przenies(dialog.opis_konta, u.konto)
        self._przenies(dialog.zakres, u.konto)
        # Natywna operacja zachowuje swój model postępu, lecz tylko wspólny
        # pasek stopki jest widoczny. show() zadania nie odsłoni drugiego paska.
        self._postep_host = QWidget(dialog)
        self._postep_host.hide()
        dialog.pasek.setParent(self._postep_host)
        dialog.pasek.setObjectName("postepPrzygotowania")
        dialog.pasek.setFixedHeight(8)
        dialog.pasek.setTextVisible(False)
        dialog.pasek.hide()
        self._przenies(dialog.info, u.operacja)
        self._przenies(dialog.podsumowanie, u.operacja)
        dialog.podsumowanie.hide()
        self._przenies(dialog.pasek_akcji, u.akcje)
        u.narzedzia.addWidget(dialog.filtr)
        dialog.filtr.show()
        self.przeniesione.append(dialog.filtr)
        # Dodatkowe działania są dostępne w tym samym menu nagłówka.
        u.menu.addMenu(dialog.menu_dzialan).setText("Działania Allegro")
        actions = cast(QHBoxLayout, dialog.pasek_akcji.layout())
        actions.addWidget(dialog.anuluj)
        actions.addWidget(dialog.utworz_przycisk)
        dialog.utworz_przycisk.setMinimumHeight(36)
        dialog.utworz_przycisk.setMinimumWidth(210)
        dialog.pracuj_w_programie.hide()
        dialog.notatka_szkicu.hide()
        close = dialog.przyciski_zamkniecia.button(QDialogButtonBox.StandardButton.Close)
        close.setText("Zakończ przygotowanie")
        action = u.menu.addAction(close.text())
        action.triggered.connect(close.click)
        self.akcje_menu.append(action)
        dialog.przyciski_zamkniecia.hide()
        dialog.anuluj.setText("Wstrzymaj")
        dialog.utworz_przycisk.setIcon(ikona("wyslij", "#FFFFFF"))
        dialog.utworz_przycisk.setIconSize(QSize(17, 17))
        dialog.pomoc_wysylki.hide()
        c.panel.tryb_przygotowania(True)
        u.tresc.addWidget(dialog)
        u.tresc.setCurrentWidget(dialog)
        dialog.show()
        page.recznie.setEnabled(False)
        page.przygotuj_allegro.hide()
        page.zapisz_szkice.setText("Zapisz źródłową paczkę lokalnie")
        page.zapisz_szkice.setToolTip("Zapisuje dane z ZIP przed poprawkami w przygotowaniu.")
        page.info.hide()
        c.hint.hide()
        dialog.status_delegowany = True
        delegate = WierszNowejOferty(
            dialog.tabela,
            tytul=1,
            sku=0,
            status=4,
            ean=lambda row: dialog.oferty[row].ean,
            oznaczenie=c.odznaka_wiersza,
        )
        dialog.tabela.setItemDelegateForColumn(1, delegate)
        dialog.tabela.setItemDelegateForColumn(4, delegate)
        dialog._pokaz_wyniki()
        self.wybor = ZaznaczaniePrzygotowania(dialog.tabela, dialog.zaznacz_widoczne)
        dialog.tabela.setColumnHidden(0, True)
        dialog.tabela.setColumnHidden(5, True)  # ID pozostaje w danych i panelu szczegółów.
        for col, width in ((2, 115), (3, 105), (4, 150), (6, 55), (7, 76)):
            dialog.tabela.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.Fixed)
            dialog.tabela.setColumnWidth(col, width)
        header = dialog.tabela.horizontalHeaderItem(1)
        if header is not None:
            header.setText("Produkt / SKU / EAN")
        dialog.filtr_prezentacji = c.pasuje_do_filtrow
        dialog.tabela.currentCellChanged.connect(c.pokaz_panel)
        dialog.filtr.currentIndexChanged.connect(c.filtruj)
        dialog.praca_zmieniona.connect(self._praca_zmieniona)
        dialog.wybor_zmieniony.connect(self.odswiez_wyglad)
        dialog.pasek.valueChanged.connect(self.odswiez_wyglad)
        c.odswiez(wymus=True)

    def odswiez_wyglad(self, *_: object) -> None:
        d = self.dialog
        if d is None or len(self.opisy) != 5:
            return
        scope = d.zakres_wysylki() or tuple(
            i for i in range(len(d.oferty)) if not d.tabela.isRowHidden(i)
        )
        ready = sum(d._mozna_wyslac(i) for i in scope if i < len(d.plany))
        if (
            d.katalog_uzytkownika is not None
            and d.zapis_lokalny.isChecked()
            and not d.producent_lokalny.currentText().strip()
        ):
            ready = 0
        poprawione = any(i in d._odrzucenia for i in d.wybrane())
        d.utworz_przycisk.setText(
            f"Wyślij poprawione ({ready})…"
            if poprawione
            else f"Wyślij {ready} szkiców Allegro"
            if ready
            else "Wyślij szkice Allegro"
        )
        d.anuluj.setVisible(True)
        for button, target in self.proxy:
            button.setEnabled(target.isEnabled() and not d.trwa and not d.nieaktualny)
        settings = [d._ustawienia(i) for i in scope if i < len(d.oferty)]
        for key, field in (("gpsr", "sprzedaz"), ("vat", "vat"), ("przelicznik", "przelicznik")):
            n = sum(getattr(item, field) is not None for item in settings)
            text = (
                "Skonfigurowane"
                if settings and n == len(settings)
                else f"{n}/{len(settings)}"
                if n
                else "Nie ustawiono"
            )
            self.opisy[key].ustaw(text, bool(settings) and n == len(settings))
        plans = [d.plany[i] for i in scope if i < len(d.plany)]
        known = bool(plans) and len(plans) == len(scope)
        new = bool(settings) and all(u.nowy and u.kategoria for u in settings)
        matched = bool(settings) and all(u.produkt for u in settings)
        category = known and all(p.produkt and p.produkt.kategoria for p in plans)
        self.opisy["kategoria"].ustaw(
            "Nowy produkt" if new else "Z katalogu" if matched or category else "Do wyboru",
            bool(category),
        )
        self.opisy["parametry"].ustaw(
            "Sprawdzone"
            if known and all(not p.bledy for p in plans)
            else "Ustawiono"
            if any(u.wartosci or u.zrodla for u in settings)
            else "Do ustawienia",
            known and all(not p.bledy for p in plans),
        )
        if d.trwa:
            maximum = d.pasek.maximum()
            value = max(0, d.pasek.value())
            self.centrum.postep.setRange(0, max(1, maximum))
            self.centrum.postep.setValue(value)
            self.centrum.uklad.postep_tytul.setText(d.etap_postepu)
            self.centrum.uklad.licznik.setText(f"{value} / {maximum} przetworzonych")
            self.centrum.uklad.procent.setText(
                f"{round(100 * max(0, d.pasek.value()) / maximum)}%" if maximum > 0 else "…"
            )

    def zakoncz(self, dialog: "DialogNowychSzkicow") -> None:
        if self.dialog is not dialog:
            return
        c, page, u = self.centrum, self.centrum.page, self.centrum.uklad
        producer_label = dialog.formularz.findChild(QLabel, "etykietaProducentaPanel")
        if producer_label is not None:
            producer_label.hide()
        dialog.filtr_prezentacji = None
        dialog.tabela.currentCellChanged.disconnect(c.pokaz_panel)
        dialog.filtr.currentIndexChanged.disconnect(c.filtruj)
        dialog.praca_zmieniona.disconnect(self._praca_zmieniona)
        dialog.wybor_zmieniony.disconnect(self.odswiez_wyglad)
        dialog.pasek.valueChanged.disconnect(self.odswiez_wyglad)
        dialog.pasek.hide()
        dialog.pasek.setParent(dialog)
        if self._postep_host is not None:
            self._postep_host.deleteLater()
            self._postep_host = None
        u.menu.removeAction(dialog.menu_dzialan.menuAction())
        for widget in self.przeniesione:
            widget.hide()
            widget.setParent(dialog)
        self.przeniesione.clear()
        self.opisy.clear()
        self.proxy.clear()
        for action in self.akcje_menu:
            u.menu.removeAction(action)
            action.deleteLater()
        self.akcje_menu.clear()
        u.tresc.setCurrentWidget(page.tabela)
        u.tresc.removeWidget(dialog)
        dialog.hide()
        dialog.setParent(page)
        self.dialog = None
        self.wybor = None
        u.wyczysc_kontrolki()
        u.wskazowka.show()
        u.import_group.show()
        c.panel.tryb_przygotowania(False)
        page.recznie.setEnabled(self._recznie_wlaczone)
        page.przygotuj_allegro.setVisible(page.allegro_dostepne)
        page.zapisz_szkice.setText("Zapisz szkice lokalnie")
        page.zapisz_szkice.setToolTip("")
        page.info.show()
        c.odswiez(wymus=True)
