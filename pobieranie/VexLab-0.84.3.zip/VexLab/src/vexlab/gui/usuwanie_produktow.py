"""Jawny wybór kopii tylko przy usuwaniu lokalnych produktów."""

from PySide6.QtWidgets import QCheckBox, QMessageBox, QWidget


def potwierdz_usuwanie(parent: QWidget, liczba: int) -> bool | None:
    dialog = QMessageBox(parent)
    dialog.setWindowTitle("Usuń lokalne produkty")
    dialog.setIcon(QMessageBox.Icon.Warning)
    dialog.setText(f"Usunąć {liczba} lokalnych produktów?")
    dialog.setInformativeText(
        "Usunięte zostaną ich ceny, zdjęcia i powiązania importu. "
        "Producenci, cenniki i pozostałe dane słownikowe pozostaną.\n\n"
        "Bez nowej kopii nie będzie można cofnąć usunięcia z tego okna. "
        "Istniejące kopie bazy pozostaną zachowane."
    )
    kopia = QCheckBox("Zachowaj kopię bazy przed usunięciem (zalecane)", dialog)
    kopia.setChecked(True)
    dialog.setCheckBox(kopia)
    dialog.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    dialog.button(QMessageBox.StandardButton.Yes).setText("Usuń produkty")
    dialog.button(QMessageBox.StandardButton.No).setText("Anuluj")
    dialog.setDefaultButton(QMessageBox.StandardButton.No)
    if dialog.exec() != QMessageBox.StandardButton.Yes:
        return None
    return kopia.isChecked()
