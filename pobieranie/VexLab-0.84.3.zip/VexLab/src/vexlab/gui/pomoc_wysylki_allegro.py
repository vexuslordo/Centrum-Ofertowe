"""Wskazówki do źródłowych wyników. Nie ustala gotowości i nie ponawia zapisu."""

import re
from dataclasses import dataclass

from vexlab.przypadki_uzycia.nowe_szkice_allegro import USTAWIENIA_DO_SPRAWDZENIA, WynikTworzenia


def wskazowka_wyniku(stan: str, komunikat: str = "") -> str:
    if "inną wersję danych" in komunikat:
        return "Wybierz Sprawdź blokadę i ponów. Najpierw sprawdzimy poprzednie ID i konto Allegro."
    if stan == USTAWIENIA_DO_SPRAWDZENIA:
        return (
            "Oferta jest już utworzona. Sprawdź wskazane ustawienia w Allegro "
            "lub kliknij „Sprawdź wyniki wysyłki”. Nie twórz jej ponownie."
        )
    if stan in {"Wynik nieznany", "Wymaga sprawdzenia", "Przetwarzanie"}:
        return "Kliknij „Sprawdź wyniki wysyłki”. Nie twórz tej oferty ponownie."
    if stan == "Odrzucono" and "HTTP 429" in komunikat:
        return "Allegro ograniczyło liczbę żądań. Odczekaj przed kolejną wysyłką."
    if stan == "Odrzucono" and any(k in komunikat for k in ("HTTP 401", "HTTP 403")):
        return "Sprawdź połączenie i uprawnienia konta w Ustawienia → Integracje → Allegro."
    if stan == "Odrzucono" and "numer katalogowy" in komunikat.casefold():
        match = re.search(
            r"change the value to ['\"`]([^'\"`]{1,256})['\"`]", komunikat, re.IGNORECASE
        )
        wartosc = (" Wartość wskazana przez Allegro: " + match[1] + ".") if match else ""
        return (
            "Kliknij „Popraw wybrane…”. W parametrze Numer katalogowy części "
            "wybierz źródło ręczne i wpisz wartość wymaganą przez Allegro. "
            "SKU pozostaje osobnym kodem Twojej oferty." + wartosc
        )
    if stan in {"Do poprawy", "Odrzucono"}:
        return "Kliknij „Popraw wybrane…”, uzupełnij wskazane pola i kliknij „Sprawdź paczkę”."
    if stan == "Szkic do poprawy":
        return "Szkic jest już w Allegro. Uzupełnij wskazane dane w Allegro; nie twórz go ponownie."
    if stan == "Wstrzymano" and komunikat.startswith(
        "Nie wysłano: Błąd zapisu katalogu lokalnego:"
    ):
        return (
            "Popraw problem bazy albo odznacz zapis produktów w bazie lokalnej "
            "w Ustawieniach paczki i ponów wysyłkę."
        )
    if stan == "Wstrzymano":
        return "Sprawdź przyczynę zatrzymania i wynik poprzedniej oferty przed wznowieniem."
    if stan in {"Nie wysłano", "Nie sprawdzono", "Anulowano"}:
        return (
            "Kliknij „Sprawdź paczkę”, popraw ewentualne braki "
            "i wybierz „Utwórz zaznaczone szkice”."
        )
    return ""


@dataclass(frozen=True)
class PomocWysylki:
    tytul: str
    powod: str
    kroki: str
    akcja: str = ""
    przycisk: str = ""


def pomoc_wysylki(w: WynikTworzenia) -> PomocWysylki:
    """Wynik i ID mają pierwszeństwo przed słowami znalezionymi w komunikacie."""
    stan, powod = w.stan, w.komunikat
    if w.odczytany_szkic:
        return PomocWysylki(
            "Szkic istnieje — porównaj dane",
            powod,
            "Otwórz szkic w Allegro po wskazanym ID i porównaj wymienione pola. "
            "Następnie kliknij Sprawdź wyniki wysyłki. Nie twórz tej oferty ponownie.",
            "wynik",
            "Sprawdź wyniki wysyłki",
        )
    if "inną wersję danych" in powod:
        return PomocWysylki(
            "Blokada poprzedniej próby",
            powod,
            wskazowka_wyniku(stan, powod),
            "blokada",
            "Sprawdź blokadę i ponów…",
        )
    if stan in {"Wynik nieznany", "Wymaga sprawdzenia", "Przetwarzanie"}:
        return PomocWysylki(
            "Nie wiadomo jeszcze, czy szkic został utworzony",
            powod,
            wskazowka_wyniku(stan, powod),
            "wynik",
            "Sprawdź wyniki wysyłki",
        )
    if w.ident or stan in {
        "Utworzono szkic",
        "Szkic kompletny",
        "Szkic do poprawy",
        USTAWIENIA_DO_SPRAWDZENIA,
        "Już na Allegro",
    }:
        steps = (
            wskazowka_wyniku(stan, powod)
            if stan in {"Szkic do poprawy", USTAWIENIA_DO_SPRAWDZENIA}
            else ""
        ) or (
            "Szkic/oferta jest już w Allegro. Nie wysyłaj jej drugi raz. "
            "Otwórz zakładkę Allegro i odszukaj ją po ID lub SKU. Sprzedaż uruchomisz osobno."
        )
        return PomocWysylki(
            "Oferta jest już w Allegro", powod, steps, "szczegoly", "Szczegóły wysyłki"
        )
    if stan == "Gotowa do utworzenia":
        return PomocWysylki(
            "Gotowa do wysłania — jeszcze nie wysłano",
            powod,
            "1. Sprawdź dopasowany produkt i cenę.\n"
            "2. Kliknij „Utwórz szkic…”, przeczytaj podsumowanie i potwierdź wysyłkę.\n"
            "3. Zapis potwierdzi status „Utworzono szkic” lub „Szkic kompletny” oraz ID Allegro.",
            "utworz",
            "Utwórz szkic…",
        )
    if stan == "Odrzucono" and "HTTP 429" in powod:
        return PomocWysylki(
            "Limit żądań Allegro",
            powod,
            "Odczekaj zgodnie z komunikatem Allegro. Nie ponawiaj wysyłki wielokrotnie. "
            "Przed kolejną próbą sprawdź raport i poprzedni wynik.",
            "szczegoly",
            "Szczegóły wysyłki",
        )
    if stan == "Odrzucono" and any(k in powod for k in ("HTTP 401", "HTTP 403")):
        return PomocWysylki(
            "Sprawdź dostęp do konta Allegro",
            powod,
            "Kliknij „Pracuj w programie”, potem Ustawienia → Integracje → Allegro. "
            "Sprawdź konto, połączenie i zgodę na zapis ofert. Po przywróceniu dostępu "
            "otwórz przygotowanie ponownie i kliknij „Sprawdź paczkę”.",
            "szczegoly",
            "Szczegóły wysyłki",
        )
    if stan in {"Do poprawy", "Odrzucono"}:
        where = []
        text = powod.casefold()
        if any(k in text for k in ("gpsr", "dostaw", "delivery", "warunk", "responsible")):
            where.append("GPSR, dostawa i warunki: przycisk „GPSR, dostawa i warunki…”.")
        if any(k in text for k in ("parametr", "parameter", "numer katalogowy")):
            where.append(
                "Parametry produktu: „Popraw wybrane…” → „Parametry produktu…”. "
                "Wpisz wartość wymaganą w pełnym komunikacie Allegro."
            )
        if any(k in text for k in ("tytuł", "title", "cenę", "cena", "price", "ilość", "quantity")):
            where.append("Tytuł, cena lub ilość: „Edytuj dane…” albo „Popraw wybrane…”.")
        if any(k in text for k in ("ean", "gtin", "wybierz produkt", "produktu allegro")):
            where.append(
                "Dopasowanie: „Wybierz produkt Allegro…”. Sprawdź zgodność z Twoim produktem."
            )
        if any(k in text for k in ("zdję", "image", "opis", "description")):
            where.append(
                "Zdjęcia lub opis: popraw dane źródłowej oferty/paczki i wczytaj ją ponownie. "
                "Edycja tytułu i ceny nie zmienia zdjęć ani opisu."
            )
        steps = "\n".join(where)
        if "numer katalogowy" in text:
            steps = wskazowka_wyniku(stan, powod) + "\n" + steps
        steps = (steps + "\n" if steps else "") + (
            "Po poprawieniu danych kliknij „Sprawdź paczkę”. Dopiero po usunięciu braków "
            "wybierz „Wyślij poprawione szkice…” i potwierdź podsumowanie."
        )
        if not where:
            steps = (
                "Pełny powód znajduje się powyżej. " + wskazowka_wyniku(stan, powod) + "\n" + steps
            )
        return PomocWysylki(
            "Oferta wymaga poprawy przed wysyłką", powod, steps, "popraw", "Popraw wybrane…"
        )
    if stan == "Wstrzymano" and powod.startswith("Nie wysłano: Błąd zapisu katalogu lokalnego:"):
        return PomocWysylki(
            "Wysyłkę zatrzymał zapis lokalny",
            powod,
            "Tej pozycji nie wysłano do Allegro. Popraw wskazany problem bazy i ponów wysyłkę "
            "albo w Ustawieniach paczki odznacz „Zapisz produkty z paczki w bazie lokalnej”, "
            "jeśli chcesz wysłać bez zapisu produktów. Następnie wybierz wysyłkę i potwierdź "
            "podsumowanie. Istniejące produkty pozostaną. Pozycje z niepewnym wynikiem "
            "nadal wymagają sprawdzenia; nie twórz ich ponownie.",
            "zapis_lokalny",
            "Ustawienia zapisu lokalnego",
        )
    if stan == "Wstrzymano":
        return PomocWysylki(
            "Seria została wstrzymana",
            powod,
            "Sprawdź pełny powód oraz wynik poprzedniej pozycji. Jeśli poprzedni wynik jest "
            "nieznany, najpierw użyj „Sprawdź wyniki wysyłki”. "
            "Nie twórz ponownie niepewnych ofert.",
            "szczegoly",
            "Szczegóły wysyłki",
        )
    if stan in {"Nie sprawdzono", "Nie wysłano", "Anulowano"}:
        return PomocWysylki(
            "Ta pozycja nie została wysłana",
            powod or "Nie ma potwierdzonego zapisu w Allegro.",
            "1. Kliknij „Sprawdź paczkę”.\n2. Popraw wskazane braki i sprawdź ponownie.\n"
            "3. Przy statusie gotowości wybierz „Utwórz zaznaczone szkice…” i potwierdź wysyłkę.",
            "sprawdz",
            "Sprawdź paczkę",
        )
    return PomocWysylki(
        stan or "Wybierz ofertę",
        powod,
        "Przeczytaj pełny komunikat. Jeśli wynik zapisu nie jest pewny, sprawdź wyniki "
        "wysyłki przed kolejną próbą.",
        "szczegoly",
        "Szczegóły wysyłki",
    )
