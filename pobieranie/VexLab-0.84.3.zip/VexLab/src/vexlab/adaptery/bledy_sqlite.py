"""Bezpieczne przyczyny awarii bazy, bez SQL, ścieżek i danych rekordów."""

import errno
import sqlite3


def opis_awarii_bazy(blad: sqlite3.Error | OSError) -> str:
    if isinstance(blad, OSError):
        if blad.errno == errno.ENOSPC:
            return "Brak miejsca na dysku. Zwolnij miejsce na bazę i jej kopię."
        if blad.errno in {errno.EACCES, errno.EPERM, errno.EROFS}:
            return "Brak uprawnień zapisu. Sprawdź dostęp do katalogu danych i kopii."
        return "Nie można uzyskać dostępu do plików. Sprawdź dysk i katalog danych."
    kod = getattr(blad, "sqlite_errorcode", 0) & 255
    if kod in {sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED}:
        return "Baza jest zajęta. Zamknij drugą instancję VexLab i ponów operację."
    if kod == sqlite3.SQLITE_FULL:
        return "Brak miejsca na dysku. Zwolnij miejsce na bazę i jej kopię."
    if kod in {sqlite3.SQLITE_READONLY, sqlite3.SQLITE_PERM, sqlite3.SQLITE_AUTH}:
        return "Brak uprawnień zapisu. Sprawdź dostęp do katalogu danych i kopii."
    if kod == sqlite3.SQLITE_CANTOPEN:
        return "Nie można otworzyć pliku bazy. Sprawdź dostęp do katalogu danych i kopii."
    if kod in {sqlite3.SQLITE_CORRUPT, sqlite3.SQLITE_NOTADB}:
        return "Nieprawidłowy plik bazy. Zachowaj go i sprawdź możliwość odtworzenia kopii."
    if kod == sqlite3.SQLITE_IOERR:
        return "Błąd odczytu lub zapisu dysku. Sprawdź nośnik i wolne miejsce."
    return f"Błąd bazy SQLite (kod {kod}). Wymagana jest diagnostyka katalogu lokalnego."
