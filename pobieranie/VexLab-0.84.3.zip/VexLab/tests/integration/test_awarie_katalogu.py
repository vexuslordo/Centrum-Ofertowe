import errno
import sqlite3

import pytest

from tests.integration.test_katalog_uzytkownika import produkt, serwis
from vexlab.adaptery.bledy_sqlite import opis_awarii_bazy
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.rdzen.kontrakty import BladTechniczny


@pytest.mark.parametrize(
    "kod, fragment",
    [
        (sqlite3.SQLITE_BUSY, "zajęta"),
        (sqlite3.SQLITE_LOCKED, "zajęta"),
        (sqlite3.SQLITE_FULL, "Brak miejsca"),
        (sqlite3.SQLITE_READONLY, "uprawnień"),
        (sqlite3.SQLITE_CANTOPEN, "otworzyć"),
        (sqlite3.SQLITE_CORRUPT, "Nieprawidłowy"),
        (sqlite3.SQLITE_IOERR | (7 << 8), "dysku"),
        (sqlite3.SQLITE_ERROR, "kod 1"),
    ],
)
def test_bezpieczny_opis_sqlite_bez_tresci_rekordow(kod, fragment):
    blad = sqlite3.OperationalError("SELECT sekret FROM prywatna_tabela /tajna/sciezka")
    blad.sqlite_errorcode = kod
    tekst = opis_awarii_bazy(blad)
    assert fragment in tekst
    assert "sekret" not in tekst and "tajna" not in tekst and "SELECT" not in tekst


def test_awaria_kopii_ma_przyczyne_i_nie_zapisuje_produktow(tmp_path, monkeypatch):
    local, repo = serwis(tmp_path)

    def brak_miejsca(*args):
        raise OSError(errno.ENOSPC, "sekret", "/prywatna/sciezka")

    monkeypatch.setattr(repo, "_kopia_spojna", brak_miejsca)
    with pytest.raises(BladTechniczny, match="Nie utworzono kopii.*Brak miejsca") as exc:
        local.importuj((produkt(),))
    assert "sekret" not in str(exc.value) and "prywatna" not in str(exc.value)
    assert not KatalogProduktow(repo, repo).wyszukaj()
    assert not local.producenci()
