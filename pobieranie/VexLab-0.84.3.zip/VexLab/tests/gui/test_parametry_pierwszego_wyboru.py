from dataclasses import replace

from PySide6.QtCore import QItemSelectionModel
from PySide6.QtWidgets import QDialog

from tests.gui.test_nowe_szkice_allegro import panel, wykonaj


def test_pierwsze_otwarcie_parametrow_dla_calej_niesprawdzonej_paczki(
    qtbot, nowe_produkty_fixture, monkeypatch
):
    offer = nowe_produkty_fixture[4]
    w, jobs = panel(
        qtbot, nowe_produkty_fixture, tuple(replace(offer, sku=f"TEST-{i}") for i in range(200))
    )
    w.tabela.setCurrentCell(-1, -1, QItemSelectionModel.SelectionFlag.NoUpdate)
    w.zaznacz_widoczne()
    opened = []
    monkeypatch.setattr(
        QDialog, "exec", lambda d: opened.append(d.windowTitle()) or QDialog.DialogCode.Rejected
    )
    assert len(w.wybrane()) == 200
    w.parametry_masowe.click()
    assert len(jobs) == 1
    w.tabela.setCurrentCell(150, 0, QItemSelectionModel.SelectionFlag.NoUpdate)
    wykonaj(jobs)
    assert len(opened) == 1, w.info.text()
    assert nowe_produkty_fixture[1].calls.count("nowy") == 1
    assert not w.plany and "POST" not in nowe_produkty_fixture[1].calls


def test_zmiana_zaznaczenia_podczas_pobierania_nie_otwiera_formularza(
    qtbot, nowe_produkty_fixture, monkeypatch
):
    offer = nowe_produkty_fixture[4]
    w, jobs = panel(qtbot, nowe_produkty_fixture, (offer, replace(offer, sku="DRUGI")))
    w.zaznacz_widoczne()
    opened = []
    monkeypatch.setattr(QDialog, "exec", lambda d: opened.append(d) or QDialog.DialogCode.Rejected)
    w.parametry_masowe.click()
    w.tabela.clearSelection()
    w.tabela.selectRow(1)
    wykonaj(jobs)
    assert not opened and "Wybierz ponownie" in w.info.text()
    assert not w.plany and "POST" not in nowe_produkty_fixture[1].calls


def test_zmiana_ustawien_podczas_pobierania_nie_otwiera_formularza(
    qtbot, nowe_produkty_fixture, monkeypatch
):
    offer = nowe_produkty_fixture[4]
    w, jobs = panel(qtbot, nowe_produkty_fixture, (offer, replace(offer, sku="DRUGI")))
    w.zaznacz_widoczne()
    opened = []
    monkeypatch.setattr(QDialog, "exec", lambda d: opened.append(d) or QDialog.DialogCode.Rejected)
    w.parametry_masowe.click()
    w.ustawienia[1] = replace(w.ustawienia[1], kategoria="456")
    wykonaj(jobs)
    assert not opened and "Wybierz ponownie" in w.info.text()
