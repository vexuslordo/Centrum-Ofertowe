from PySide6.QtWidgets import QMessageBox, QWidget

from tests.gui.test_nowe_szkice_allegro import wykonaj
from tests.integration.test_katalog_uzytkownika import serwis
from vexlab.gui.import_produktow_uzytkownika import ImportProduktowUzytkownika
from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.przypadki_uzycia.katalog import KatalogProduktow


def test_reczny_producent_automatyczny_produkt_i_powiazanie_po_potwierdzeniu(
    qtbot, tmp_path, nowe_szkice_fixture, monkeypatch
):
    service, api, _r, session, offer, settings = nowe_szkice_fixture
    local, repo = serwis(tmp_path)
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = DialogNowychSzkicow(
        parent, service, session, (offer,), lambda *a: jobs.append(a), katalog_uzytkownika=local
    )
    d.kompletny.setChecked(False)
    d.waluta.setCurrentIndex(d.waluta.findData("PLN"))
    d.ustawienia[0] = settings
    d.show()
    d.przygotuj()
    wykonaj(jobs)
    d.tworz()
    assert "producenta" in d.info_katalogu.text() and "POST" not in api.calls
    d.producent_lokalny.setEditText("Producent użytkownika")
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    d.tworz()
    assert not KatalogProduktow(repo, repo).wyszukaj() and local.producenci() == ()
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    d.tworz()
    wykonaj(jobs)
    rows = KatalogProduktow(repo, repo).wyszukaj()
    assert len(rows) == 1 and rows[0].producent_nazwa == "Producent użytkownika"
    assert rows[0].sku == offer.sku and rows[0].ean == offer.ean and rows[0].ma_zdjecia
    assert rows[0].cena_sugerowana.kwota == offer.cena
    from vexlab.adaptery.katalog_allegro_sqlite import KatalogAllegroSQLite

    linked = KatalogAllegroSQLite(repo.plik).powiazane_oferty(session, (rows[0].id,))
    assert linked[0].ident == d.wyniki[0].ident
    assert api.calls.count("POST") == 1
    d.odswiez_producentow_lokalnych()
    wykonaj(jobs)
    assert d.producent_lokalny.findText("Producent użytkownika") >= 0
    d.reject()


def test_import_podglad_anulowanie_i_zapis(qtbot, tmp_path, monkeypatch):
    from tests.integration.test_katalog_uzytkownika import produkt

    local, repo = serwis(tmp_path)
    local.importuj((produkt(),))
    row = KatalogProduktow(repo, repo).wyszukaj()[0]
    plik = tmp_path / "produkty.zip"
    local.eksportuj(plik, (row.id,))
    target, repo2 = serwis(tmp_path, "nowy.sqlite3")
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = ImportProduktowUzytkownika(parent, target, plik, lambda *a: jobs.append(a))
    d.show()
    d.odczytaj()
    wykonaj(jobs)
    assert d.tabela.rowCount() == 1 and not KatalogProduktow(repo2, repo2).wyszukaj()
    mini = d.tabela.cellWidget(0, 0)
    assert mini.width() == mini.height() == 64 and not mini.obraz.isNull()
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    d.importuj()
    assert not KatalogProduktow(repo2, repo2).wyszukaj()
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    d.importuj()
    wykonaj(jobs)
    rows = KatalogProduktow(repo2, repo2).wyszukaj()
    assert len(rows) == 1 and rows[0].ma_zdjecia and rows[0].producent_nazwa == row.producent_nazwa
    assert "dodano 1" in d.info.text()
    d.reject()


def test_blad_zapisu_lokalnego_blokuje_post(qtbot, tmp_path, nowe_szkice_fixture):
    service, api, _r, session, offer, settings = nowe_szkice_fixture
    local, _repo = serwis(tmp_path)
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = DialogNowychSzkicow(
        parent, service, session, (offer,), lambda *a: jobs.append(a), katalog_uzytkownika=local
    )
    d.kompletny.setChecked(False)
    d.waluta.setCurrentIndex(d.waluta.findData("PLN"))
    d.ustawienia[0] = settings
    d.przygotuj()
    wykonaj(jobs)
    d.wyslij(False)
    wykonaj(jobs)
    assert d.wyniki[0].stan == "Do poprawy"
    assert "producenta" in d.wyniki[0].komunikat
    assert "POST" not in api.calls
    d.reject()


def test_nieznany_wynik_allegro_nie_usuwa_produktu_uzytkownika(
    qtbot, tmp_path, nowe_szkice_fixture
):
    service, api, _r, session, offer, settings = nowe_szkice_fixture
    local, repo = serwis(tmp_path)
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = DialogNowychSzkicow(
        parent, service, session, (offer,), lambda *a: jobs.append(a), katalog_uzytkownika=local
    )
    d.kompletny.setChecked(False)
    d.waluta.setCurrentIndex(d.waluta.findData("PLN"))
    d.ustawienia[0] = settings
    d.producent_lokalny.setEditText("Zapisany producent")
    d.przygotuj()
    wykonaj(jobs)
    api.awaria = "timeout"
    d.wyslij(False)
    wykonaj(jobs)
    assert len(KatalogProduktow(repo, repo).wyszukaj()) == 1
    assert local.producenci() == ("Zapisany producent",)
    assert api.calls.count("POST") == 1
    d.reject()


def test_wylaczenie_zapisu_paczki_pozwala_wyslac_bez_producenta_lokalnego(
    qtbot, tmp_path, nowe_szkice_fixture, monkeypatch
):
    service, api, _r, session, offer, settings = nowe_szkice_fixture
    local, repo = serwis(tmp_path)
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = DialogNowychSzkicow(
        parent, service, session, (offer,), lambda *a: jobs.append(a), katalog_uzytkownika=local
    )
    d.kompletny.setChecked(False)
    d.waluta.setCurrentIndex(d.waluta.findData("PLN"))
    d.ustawienia[0] = settings
    d.show()
    d.przygotuj()
    wykonaj(jobs)
    plany = d.plany
    assert d.zapis_lokalny.isChecked()
    d.zapis_lokalny.setChecked(False)
    assert not d.producent_lokalny.isEnabled()
    assert d.plany == plany
    assert "Bez zapisu" in d.info_katalogu.text()
    pytania = []

    def potwierdz(*args):
        pytania.append(args[2])
        return QMessageBox.StandardButton.Yes

    monkeypatch.setattr(QMessageBox, "question", potwierdz)
    d.tworz()
    wykonaj(jobs)
    assert api.calls.count("POST") == 1
    assert "Bez zapisywania produktów" in pytania[0]
    assert not KatalogProduktow(repo, repo).wyszukaj()
    assert local.producenci() == ()
    d.zapis_lokalny.setChecked(True)
    assert d.producent_lokalny.isEnabled()
    d.reject()


def test_awaria_bazy_potem_jawne_wylaczenie_zapisu_pozwala_wyslac(
    qtbot, tmp_path, nowe_szkice_fixture, monkeypatch
):
    import errno

    service, api, _r, session, offer, settings = nowe_szkice_fixture
    local, repo = serwis(tmp_path)
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = DialogNowychSzkicow(
        parent, service, session, (offer,), lambda *a: jobs.append(a), katalog_uzytkownika=local
    )
    d.kompletny.setChecked(False)
    d.waluta.setCurrentIndex(d.waluta.findData("PLN"))
    d.ustawienia[0] = settings
    d.producent_lokalny.setEditText("Test")
    d.przygotuj()
    wykonaj(jobs)

    def brak_miejsca(*args):
        raise OSError(errno.ENOSPC, "sekret")

    monkeypatch.setattr(repo, "_kopia_spojna", brak_miejsca)
    d.wyslij(False)
    wykonaj(jobs)
    assert "POST" not in api.calls
    assert d.wyniki[0].stan == "Wstrzymano"
    assert "Brak miejsca" in d.wyniki[0].komunikat
    assert "odznacz" in d.pomoc_wysylki.kroki.toPlainText()
    assert d.zapis_lokalny.isChecked()
    d.zapis_lokalny.setChecked(False)
    monkeypatch.setattr(QMessageBox, "question", lambda *args: QMessageBox.StandardButton.Yes)
    d.tworz()
    wykonaj(jobs)
    assert api.calls.count("POST") == 1
    assert not KatalogProduktow(repo, repo).wyszukaj()
    d.reject()
