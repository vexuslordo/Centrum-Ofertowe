import pytest
from PySide6.QtWidgets import QMessageBox, QWidget

from tests.gui.test_ceny_masowa_media import okno  # noqa: F401
from vexlab.gui.usuwanie_produktow import potwierdz_usuwanie


@pytest.mark.parametrize("kopia", [True, False])
def test_wybor_kopii_i_domyslne_anulowanie(qtbot, monkeypatch, kopia):
    parent = QWidget()
    qtbot.addWidget(parent)

    def odpowiedz(dialog):
        assert dialog.checkBox().isChecked()
        assert dialog.defaultButton() == dialog.button(QMessageBox.StandardButton.No)
        assert "Producenci, cenniki" in dialog.informativeText()
        dialog.checkBox().setChecked(kopia)
        return QMessageBox.StandardButton.Yes

    monkeypatch.setattr(QMessageBox, "exec", odpowiedz)
    assert potwierdz_usuwanie(parent, 200) is kopia


def test_anulowanie_nie_zwraca_zgody_na_usuniecie(qtbot, monkeypatch):
    parent = QWidget()
    qtbot.addWidget(parent)
    monkeypatch.setattr(QMessageBox, "exec", lambda _: QMessageBox.StandardButton.No)
    assert potwierdz_usuwanie(parent, 1) is None


@pytest.mark.parametrize("zachowaj", [True, False])
def test_wybor_trafia_do_usuwania_zaznaczonych(qtbot, okno, monkeypatch, zachowaj):  # noqa: F811
    monkeypatch.setattr("vexlab.gui.okno.potwierdz_usuwanie", lambda *args: zachowaj)
    komunikaty = []
    monkeypatch.setattr(QMessageBox, "information", lambda *args: komunikaty.append(args[2]))
    okno.tabela_select_all()
    qtbot.waitUntil(lambda: not okno._zadania)
    okno.usun_zaznaczony()
    qtbot.waitUntil(lambda: not okno._zadania and not okno._usuwanie)
    assert not okno.katalog.wyszukaj()
    assert len(okno.producenci.lista()) == 1
    kopie = list((okno.importer.magazyn.plik.parent / "kopie_usuwania").glob("*.sqlite3"))
    assert len(kopie) == int(zachowaj)
    assert ("Kopia bazy:" if zachowaj else "Nie utworzono kopii bazy.") in komunikaty[0]
