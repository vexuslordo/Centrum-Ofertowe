from dataclasses import replace

import pytest
from PySide6.QtWidgets import QLabel, QMessageBox

from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from vexlab.gui.pomoc_wysylki_allegro import pomoc_wysylki
from vexlab.przypadki_uzycia.nowe_szkice_allegro import WynikTworzenia


@pytest.mark.parametrize(
    "stan, ident",
    [
        ("Wynik nieznany", ""),
        ("Wymaga sprawdzenia", ""),
        ("Przetwarzanie", ""),
        ("Odrzucono", "123"),
        ("Utworzono szkic", "123"),
        ("Szkic do poprawy", "123"),
        ("Już na Allegro", "123"),
    ],
)
def test_niepewny_lub_utworzony_wynik_nie_zacheca_do_ponownego_tworzenia(stan, ident):
    result = pomoc_wysylki(WynikTworzenia("SKU", stan, "Brak parametru EAN; HTTP 403", ident))
    assert result.akcja not in {"popraw", "utworz", "sprawdz"}
    assert "ponownie" in result.kroki or "drugi raz" in result.kroki


@pytest.mark.parametrize(
    "powod, fragment",
    [
        ("Uzupełnij GPSR, dostawę i warunki", "GPSR, dostawa"),
        ("Tytuł: 12–75 znaków", "Edytuj dane"),
        ("Uzupełnij dodatnią cenę brutto", "Edytuj dane"),
        ("Brak EAN: wybierz produkt z Katalogu Allegro", "Wybierz produkt Allegro"),
        ("Wymagane 1–16 zdjęć", "dane źródłowej"),
        ("Brak opisu oferty", "dane źródłowej"),
        ("Wymagany parametr: kolor", "Parametry produktu"),
    ],
)
def test_wskazowka_odsyla_do_rzeczywistego_miejsca_poprawki(powod, fragment):
    help = pomoc_wysylki(WynikTworzenia("SKU", "Do poprawy", powod))
    assert fragment in help.kroki and help.powod == powod
    assert "Sprawdź paczkę" in help.kroki


def test_pelny_powod_i_wskazowka_widoczne_bez_otwierania_raportu(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    long = "Pełny powód z Allegro " + "0123456789" * 400
    w.wyniki = (WynikTworzenia(w.oferty[0].sku, "Odrzucono", long),)
    before = len(jobs)
    w._pokaz_wyniki()
    assert w.pomoc_wysylki.tresc.toPlainText() == long
    assert "Popraw wybrane" in w.pomoc_wysylki.kroki.toPlainText()
    assert long in w.tabela.item(0, 4).toolTip()
    assert len(jobs) == before


def test_rekomendowana_poprawka_wybiera_wlasciwy_wiersz(qtbot, nowe_szkice_fixture, monkeypatch):
    *_, offer, _ = nowe_szkice_fixture
    w, jobs = panel(qtbot, nowe_szkice_fixture, (offer, replace(offer, sku="DRUGI")))
    w.wyniki = (
        WynikTworzenia(offer.sku, "Utworzono szkic", "Zapisano", "123"),
        WynikTworzenia("DRUGI", "Odrzucono", "Brak parametru koloru"),
    )
    w._pokaz_wyniki()
    assert w._wiersz_pomocy == 1
    calls = []
    monkeypatch.setattr(w, "popraw_wybrane", lambda: calls.append(w.wybrane()))
    w.pomoc_wysylki.przycisk.click()
    assert calls == [(1,)]
    assert not jobs


def test_gotowa_nie_oznacza_wyslana_a_przycisk_zachowuje_potwierdzenie(
    qtbot, nowe_szkice_fixture, monkeypatch
):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    text = " ".join(label.text() for label in w.tabela.cellWidget(0, 4).findChildren(QLabel))
    assert "Jeszcze nie wysłano" in text
    asked = []

    def odmow(*args, **kwargs):
        asked.append(True)
        return QMessageBox.StandardButton.No

    monkeypatch.setattr(QMessageBox, "question", odmow)
    before = len(jobs)
    w.pomoc_wysylki.przycisk.click()
    assert asked and len(jobs) == before
    assert not w.wyniki[0].ident


def test_blad_calej_operacji_nie_zostawia_pozornej_gotowosci(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    jobs[-1][2]("ODCZYT", "Brak dostępu do danych Allegro")
    assert "Brak dostępu" in w.pomoc_wysylki.tresc.toPlainText()
    assert "Nie udało się" in w.pomoc_wysylki.tytul.text()
    assert w.pomoc_wysylki.przycisk.text() == "Sprawdź paczkę"
    w.przygotuj()
    assert not w._blad_operacji
    assert not w.pomoc_wysylki.przycisk.isVisible()


def test_nieaktualna_sesja_nie_pozwala_uruchomic_akcji_pomocy(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    before = len(jobs)
    w.zmiana_sesji()
    assert not w.pomoc_wysylki.przycisk.isVisible()
    w._akcja_pomocy("utworz")
    assert len(jobs) == before
    assert "konto" in w.pomoc_wysylki.kroki.toPlainText()


def test_przy_braku_wyboru_panel_pokazuje_blad_przed_gotowa_oferta(qtbot, nowe_szkice_fixture):
    *_, offer, _ = nowe_szkice_fixture
    w, _ = panel(qtbot, nowe_szkice_fixture, (offer, replace(offer, sku="BLAD")))
    w.wyniki = (
        WynikTworzenia(offer.sku, "Gotowa do utworzenia", "Gotowa"),
        WynikTworzenia("BLAD", "Do poprawy", "Brak poprawnej ceny"),
    )
    w._pokaz_wyniki()
    assert w._wiersz_pomocy == 1
    assert "BLAD" in w.pomoc_wysylki.tytul.text()


def test_gotowa_oferta_wskazuje_brak_producenta_lokalnego(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    w.katalog_uzytkownika = object()  # Tylko obecność wymagania w UI, bez operacji katalogu.
    w.zapis_lokalny.setChecked(True)
    w._odswiez_pomoc()
    assert "Producent lokalny" in w.pomoc_wysylki.kroki.toPlainText()
    assert "producenta lokalnego" in w.pomoc_wysylki.przycisk.text()
    before = len(jobs)
    w.pomoc_wysylki.przycisk.click()
    assert len(jobs) == before
    w.producent_lokalny.setEditText("Producent użytkownika")
    assert w.pomoc_wysylki.przycisk.text() == "Utwórz szkic…"


def test_poprawka_z_panelu_zachowuje_wybor_wielu_ofert(qtbot, nowe_szkice_fixture, monkeypatch):
    *_, offer, _ = nowe_szkice_fixture
    w, _ = panel(qtbot, nowe_szkice_fixture, (offer, replace(offer, sku="DRUGI")))
    w.wyniki = tuple(WynikTworzenia(o.sku, "Odrzucono", "Brak parametru") for o in w.oferty)
    w._pokaz_wyniki()
    w.tabela.selectAll()
    calls = []
    monkeypatch.setattr(w, "popraw_wybrane", lambda: calls.append(w.wybrane()))
    w.pomoc_wysylki.przycisk.click()
    assert calls == [(0, 1)]


def test_podczas_operacji_i_po_bledzie_nie_twiedzimy_ze_nic_nie_wyslano(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    label = w.tabela.cellWidget(0, 4).findChild(QLabel, "opisGotowosci")
    assert "Jeszcze nie wysłano" in label.text()
    w._zadanie(lambda: None, lambda _: None)
    assert "Trwa operacja" in label.text() and "Jeszcze nie wysłano" not in label.text()
    jobs[-1][2]("SIEC", "Utracono połączenie")
    assert "Sprawdź wynik" in label.text() and "Jeszcze nie wysłano" not in label.text()


def test_odczytany_szkic_z_roznica_tresci_nie_jest_opisywany_jako_nieznany():
    result = WynikTworzenia("SKU", "Wymaga sprawdzenia", "Do porównania: tytuł", "123", True)
    help = pomoc_wysylki(result)
    assert help.tytul == "Szkic istnieje — porównaj dane"
    assert "Nie twórz" in help.kroki


def test_blad_lokalny_ma_wlasciwa_wskazowke_ale_id_i_unknown_nadal_chronione():
    powod = "Nie wysłano: Błąd zapisu katalogu lokalnego: Brak miejsca na dysku."
    pomoc = pomoc_wysylki(WynikTworzenia("TEST", "Wstrzymano", powod))
    assert pomoc.akcja == "zapis_lokalny" and "odznacz" in pomoc.kroki
    for stan, ident in [("Wynik nieznany", ""), ("Wstrzymano", "123")]:
        pomoc = pomoc_wysylki(WynikTworzenia("TEST", stan, powod, ident))
        assert pomoc.akcja != "zapis_lokalny"
