"""Producenci na pasku pochodzą wyłącznie z rejestru użytkownika."""

from uuid import uuid4

from pytestqt.qtbot import QtBot

from vexlab.gui.filtry_katalogu import FiltryKatalogu
from vexlab.przypadki_uzycia.producenci import ProducentDTO


def test_pusty_rejestr_nie_dodaje_marek(qtbot: QtBot) -> None:
    pasek = FiltryKatalogu()
    qtbot.addWidget(pasek)
    assert list(pasek.przyciski) == ["wszyscy"]
    assert [a.text() for a in pasek.menu_producentow.actions()] == [
        "Wszyscy producenci",
        "Bez producenta",
    ]


def test_dodanie_zmiana_i_usuniecie_producenta_odswieza_przyciski(qtbot: QtBot) -> None:
    pasek = FiltryKatalogu()
    qtbot.addWidget(pasek)
    ident = uuid4()
    producent = ProducentDTO(ident, "Moja marka", True, 1)
    pasek.ustaw((producent,), "wszyscy", "", None, None)
    with qtbot.waitSignal(pasek.producent) as sygnal:
        pasek.przyciski[str(ident)].click()
    assert sygnal.args == [str(ident)]
    pasek.ustaw((ProducentDTO(ident, "Nowa nazwa", True, 2),), str(ident), "", None, None)
    assert pasek.przyciski[str(ident)].text() == "Nowa nazwa"
    assert pasek.przyciski[str(ident)].isChecked()
    pasek.ustaw((), "wszyscy", "", None, None)
    assert list(pasek.przyciski) == ["wszyscy"]


def test_nadmiar_producentow_trafia_do_menu(qtbot: QtBot) -> None:
    pasek = FiltryKatalogu()
    qtbot.addWidget(pasek)
    producenci = tuple(ProducentDTO(uuid4(), f"Marka {i}", True, 1) for i in range(7))
    pasek.ustaw(producenci, str(producenci[-1].id), "", None, None)
    assert len(pasek.przyciski) == 6
    assert [a.text() for a in pasek.menu_producentow.actions()][2:] == ["Marka 5", "Marka 6"]
    assert pasek.wiecej.isChecked()
    with qtbot.waitSignal(pasek.producent) as sygnal:
        pasek.menu_producentow.actions()[-1].trigger()
    assert sygnal.args == [str(producenci[-1].id)]
