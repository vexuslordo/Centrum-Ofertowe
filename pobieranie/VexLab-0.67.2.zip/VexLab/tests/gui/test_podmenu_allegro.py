from PySide6.QtCore import QSettings

from tests.gui.test_allegro import Serwis
from tests.integration.test_zamowienia_allegro import API, Czas, sesja
from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro


def test_zamowienia_w_allegro_bez_osobnej_pozycji_i_zachowane_filtry(qtbot, tmp_path):
    repo = CennikiSQLite(tmp_path / "db.sqlite3")
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "p.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
        allegro=Serwis(),
        zamowienia=OdczytajZamowieniaAllegro(API(), Czas()),
    )
    qtbot.addWidget(w, before_close_func=lambda _: qtbot.waitUntil(lambda: not w._zadania))
    w.show()
    qtbot.waitUntil(lambda: not w._zadania and w._katalog_wczytany)
    w.strona_allegro.sesja = sesja()
    assert "Zamówienia" not in w.przyciski_menu and "Zamówienia" not in w.strony
    tabs = w.allegro_podmenu
    assert [tabs.tabText(i) for i in range(tabs.count())] == ["Oferty", "Zamówienia"]
    w.przejdz("Zamówienia")
    assert w.stos.currentWidget() is tabs and tabs.currentWidget() is w.strona_zamowien
    assert w.przyciski_menu["Allegro"].isChecked()
    w.strona_zamowien.pobierz.click()
    qtbot.waitUntil(lambda: not w._zadania)
    assert w.strona_zamowien.model.rowCount() == 2
    w.strona_zamowien.szukaj.setText("00123")
    report = w.strona_zamowien.raport
    tabs.setCurrentIndex(0)
    tabs.setCurrentIndex(1)
    assert w.strona_zamowien.raport is report and w.strona_zamowien.szukaj.text() == "00123"
    assert not w._zadania
    w.przejdz("Allegro")
    assert tabs.currentIndex() == 0
    w.close()
