from PySide6.QtCore import QSettings

from tests.integration.test_zamowienia_presta import Transport
from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.kanaly.prestashop import PrestaAPI
from vexlab.kanaly.zamowienia_presta import ZamowieniaPrestaAPI
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.przypadki_uzycia.prestashop import PolaczPresta
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.przypadki_uzycia.zamowienia_presta import OdczytajZamowieniaPresta


def test_dashboard_presta_pobiera_po_polaczeniu_i_czysci_po_zmianie_sklepu(qtbot, tmp_path):
    repo, transport = CennikiSQLite(tmp_path / "catalog.sqlite3"), Transport()
    window = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "p.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
        presta=PolaczPresta(PrestaAPI(transport)),
        zamowienia_presta=OdczytajZamowieniaPresta(ZamowieniaPrestaAPI(transport)),
    )
    qtbot.addWidget(
        window, before_close_func=lambda _: qtbot.waitUntil(lambda: not window._zadania)
    )
    window.show()
    qtbot.waitUntil(lambda: not window._zadania)
    page = window.strona_presta
    page.adres.setText("https://fixture.example/")
    page.klucz.setText("a" * 32)
    page.polacz.click()
    qtbot.waitUntil(lambda: not window._zadania)
    assert window.dashboard._tabele["zamowienia"].rowCount() == 1
    assert window.dashboard._tabele["zamowienia"].item(0, 1).text() == "PrestaShop"
    assert window.dashboard.karty["zamowienia"].liczba.text() == "1"
    assert window.dashboard.karty["obrot"].liczba.text() == "123,00 PLN"
    page.adres.setText("https://inny.example/")
    assert window.dashboard._tabele["zamowienia"].rowCount() == 0
    assert not window._presta_zamowienia_timer.isActive()
