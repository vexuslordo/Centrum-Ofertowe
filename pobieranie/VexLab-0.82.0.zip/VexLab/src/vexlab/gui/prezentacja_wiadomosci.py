"""Prezentacja rozmów: bez interpretowania HTML i adresów pochodzących z wiadomości."""

from html import escape
from typing import Any

from PySide6.QtCore import (
    QDateTime,
    QEvent,
    QModelIndex,
    QPersistentModelIndex,
    QRect,
    QSize,
    Qt,
    QTimer,
    QUrl,
)
from PySide6.QtGui import QColor, QFont, QPainter, QPalette, QResizeEvent
from PySide6.QtWidgets import QStyle, QStyledItemDelegate, QStyleOptionViewItem, QTextBrowser

from vexlab.przypadki_uzycia.wiadomosci_allegro import WatekAllegro, WiadomoscAllegro

STATUSY = {
    "DELIVERED": "Dostarczona",
    "VERIFYING": "Weryfikowana",
    "BLOCKED": "Zablokowana",
    "INTERACTING": "W toku",
    "DISMISSED": "Odrzucona",
}


def data_wiadomosci(value: str) -> str:
    dt = QDateTime.fromString(value, Qt.DateFormat.ISODateWithMs)
    return dt.toLocalTime().toString("dd.MM.yyyy · HH:mm") if dt.isValid() else "Brak daty"


class DelegatRozmow(QStyledItemDelegate):
    def sizeHint(
        self, option: QStyleOptionViewItem, index: QModelIndex | QPersistentModelIndex
    ) -> QSize:
        return QSize(0, 104)

    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        row = index.data(Qt.ItemDataRole.UserRole)
        if not isinstance(row, WatekAllegro):
            super().paint(painter, option, index)
            return
        painter.save()
        painter.setClipRect(option.rect)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = option.rect.adjusted(2, 3, -2, -3)
        dark = option.palette.color(QPalette.ColorRole.Text).lightness() > 128
        active = bool(option.state & QStyle.StateFlag.State_Selected)
        hover = bool(option.state & QStyle.StateFlag.State_MouseOver)
        background = (
            ("#0D264C" if active else "#142239" if hover else "#0E192B")
            if dark
            else ("#DBEAFE" if active else "#EFF6FF" if hover else "#F6F8FC")
        )
        painter.setPen(QColor("#3B82F6" if active else "#1D304B" if dark else "#DAE3EF"))
        painter.setBrush(QColor(background))
        painter.drawRoundedRect(r, 10, 10)
        if active:
            painter.fillRect(QRect(r.left(), r.top() + 10, 3, r.height() - 20), QColor("#3B82F6"))
        avatar = QRect(r.left() + 10, r.top() + 12, 32, 32)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#314875" if dark else "#C9DAF5"))
        painter.drawEllipse(avatar)
        font = QFont(option.font)
        font.setPixelSize(12)
        font.setWeight(QFont.Weight.DemiBold)
        painter.setFont(font)
        painter.setPen(option.palette.color(QPalette.ColorRole.Text))
        painter.drawText(avatar, Qt.AlignmentFlag.AlignCenter, (row.login[:1] or "?").upper())
        x, width = avatar.right() + 10, max(0, r.width() - 62)
        title = option.fontMetrics.elidedText(
            row.login or "Rozmówca", Qt.TextElideMode.ElideRight, max(0, width - 48)
        )
        painter.drawText(
            QRect(x, r.top() + 10, width - 44, 18), Qt.AlignmentFlag.AlignVCenter, title
        )
        font.setPixelSize(10)
        font.setWeight(QFont.Weight.Normal)
        painter.setFont(font)
        muted = QColor("#91A5C8" if dark else "#526580")
        painter.setPen(muted)
        timestamp = data_wiadomosci(row.ostatnia).split(" · ")[-1]
        painter.drawText(
            QRect(r.right() - 48, r.top() + 10, 40, 18), Qt.AlignmentFlag.AlignRight, timestamp
        )
        preview = index.data(int(Qt.ItemDataRole.UserRole) + 1)
        subject, snippet = preview if isinstance(preview, tuple) and len(preview) == 2 else ("", "")
        for y, text in (
            (32, subject or "Otwórz rozmowę"),
            (50, snippet or "Treść dostępna po wybraniu rozmowy"),
        ):
            short = option.fontMetrics.elidedText(str(text), Qt.TextElideMode.ElideRight, width)
            painter.drawText(QRect(x, r.top() + y, width, 17), Qt.AlignmentFlag.AlignVCenter, short)
        painter.setPen(QColor("#F97316"))
        painter.drawText(
            QRect(x, r.top() + 73, width, 16), Qt.AlignmentFlag.AlignRight, "a  Allegro"
        )
        if not row.przeczytany:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor("#06B6D4"))
            painter.drawEllipse(r.left() + 24, r.top() + 55, 7, 7)
        if option.state & QStyle.StateFlag.State_HasFocus:
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QColor("#60A5FA"))
            painter.drawRoundedRect(r.adjusted(1, 1, -1, -1), 10, 10)
        painter.restore()


class WidokRozmowy(QTextBrowser):
    def __init__(self) -> None:
        super().__init__()
        self._rows: tuple[WiadomoscAllegro, ...] = ()
        self._scroll_timer = QTimer(self)
        self._scroll_timer.setSingleShot(True)
        self._scroll_timer.timeout.connect(self._koniec)
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setReadOnly(True)
        self.setUndoRedoEnabled(False)
        self.setPlaceholderText("Wybierz rozmowę z listy po lewej, aby odczytać wiadomości.")
        self.document().setDocumentMargin(18)

    def loadResource(self, type: int, name: QUrl | str) -> Any:
        # Nie pobieramy żadnych zasobów, także gdy zmieni się zachowanie dokumentu Qt.
        return None

    def clear(self) -> None:
        self._rows = ()
        self._scroll_timer.stop()
        super().clear()

    def ustaw(self, rows: tuple[WiadomoscAllegro, ...]) -> None:
        self._rows = rows
        self._renderuj()
        self._scroll_timer.start(0)

    def _koniec(self) -> None:
        if self._rows:
            self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        if hasattr(self, "_rows") and self._rows:
            self._scroll_timer.start(0)

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.PaletteChange and hasattr(self, "_rows") and self._rows:
            self._renderuj()

    def _renderuj(self) -> None:
        dark = self.palette().color(QPalette.ColorRole.Base).lightness() < 128
        text = "#E2E8F0" if dark else "#172235"
        muted = "#94A3B8" if dark else "#526580"
        blocks = []
        for row in reversed(self._rows):
            color = (
                ("#172235" if row.rozmowca else "#0E3A7B")
                if dark
                else ("#F1F5F9" if row.rozmowca else "#E6F0FF")
            )
            body = escape(row.tekst).replace("\n", "<br>")
            subject = f"<p><b>{escape(row.temat)}</b></p>" if row.temat else ""
            files = ""
            if row.zalaczniki:
                files = (
                    "<p>Załączniki (bez pobierania): " + escape(", ".join(row.zalaczniki)) + "</p>"
                )
            if row.dodatkowe_zalaczniki:
                files += "<p>Dodatkowe załączniki dostępne na Allegro.</p>"
            role = "Rozmówca" if row.rozmowca else "Twoje konto"
            status = STATUSY.get(row.status, row.status)
            spacer = '<td width="14%"></td>'
            start = spacer if not row.rozmowca else ""
            end = spacer if row.rozmowca else ""
            blocks.append(
                f'<table width="100%" cellspacing="0" cellpadding="12"><tr>{start}'
                f'<td width="86%" bgcolor="{color}">'
                f'<p><b>{escape(row.autor)}</b> <span style="color:{muted}"> · {role}</span></p>'
                f'<p style="font-size:11px;color:{muted}">{escape(data_wiadomosci(row.kiedy))}'
                f' · {escape(status)}</p>{subject}<p style="white-space:pre-wrap">{body}</p>'
                f'<span style="color:{muted}">{files}</span></td>{end}</tr></table><p></p>'
            )
        self.setHtml(
            f'<html><body style="color:{text};font-size:13px">' + "".join(blocks) + "</body></html>"
        )
