"""Przestrzeń pracy Allegro i odrębny panel konfiguracji połączenia."""

from dataclasses import replace
from typing import cast

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QShowEvent
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.obszar_allegro import ObszarAllegro
from vexlab.gui.producenci import Uruchom
from vexlab.gui.propozycja_szkicu_allegro import EdytorPropozycjiAllegro
from vexlab.gui.szkic_allegro import PodgladSzkicuAllegro
from vexlab.gui.ustawienia import SekcjaRozwijana
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KodUrzadzenia,
    PolaczAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StatusOfertyAllegro,
    StronaSzkicowAllegro,
    SzczegolySzkicuAllegro,
)
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.propozycje_szkicow import PropozycjeSzkicow
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import ZapiszSzkicAllegro


class StronaAllegro(QWidget):
    stan = Signal(str)
    ustawienia_zadane = Signal()
    nowa_oferta_zadana = Signal()
    oferty_odczytane = Signal()

    def __init__(
        self,
        serwis: PolaczAllegro,
        uruchom: Uruchom,
        zdjecia: PodgladZdjec | None = None,
        propozycje: PropozycjeSzkicow | None = None,
        zapis_szkicu: ZapiszSzkicAllegro | None = None,
    ) -> None:
        super().__init__()
        self.serwis, self.uruchom = serwis, uruchom
        self.zapis_szkicu = zapis_szkicu
        self.propozycje = propozycje
        self.edytor: EdytorPropozycjiAllegro | None = None
        self.zdjecia = zdjecia
        self.podglad: PodgladSzkicuAllegro | None = None
        self._panel_trwa = False
        self._panel_oczekuje = False
        self._panel_generacja = 0
        self._panel_operacja = 0
        self._panel_timer = QTimer(self)
        self._panel_timer.setSingleShot(True)
        self._panel_timer.timeout.connect(self._wczytaj_panel)
        self.aplikacja: AplikacjaAllegro | None = None
        self.kod: KodUrzadzenia | None = None
        self.sesja: SesjaAllegro | None = None
        self.generacja = 0
        self.trwa = False
        self.dysk_trwa = False
        self.zapamietane = False
        self._zmiana_uprawnien = False
        self.koniec = 0.0
        self.odstep = 5
        self.status_listy: StatusOfertyAllegro | None = StatusOfertyAllegro.SZKIC
        self.offset = 0
        self.lacznie = 0
        self.ostatnia_strona: StronaSzkicowAllegro | None = None
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self._sprawdz)
        self.wygasanie = QTimer(self)
        self.wygasanie.setInterval(1000)
        self.wygasanie.timeout.connect(self._waznosc)
        layout = QVBoxLayout(self)
        self.status_konta = QLabel("Konto niepołączone. Połącz je w Ustawieniach.")
        self.status_konta.setObjectName("statusPolaczeniaAllegro")
        self.status_konta.setTextFormat(Qt.TextFormat.PlainText)
        self.status_konta.setWordWrap(True)
        self.panel_polaczenia = QWidget()
        auth = QVBoxLayout(self.panel_polaczenia)
        auth.setContentsMargins(0, 0, 0, 0)
        naglowek = QLabel("Allegro — połączenie konta")
        naglowek.setObjectName("tytul")
        naglowek.setWordWrap(True)
        auth.addWidget(naglowek)
        self.info = QLabel("Konto niepołączone.")
        self.info.setTextFormat(Qt.TextFormat.PlainText)
        self.info.setWordWrap(True)
        self.info.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        auth.addWidget(self.info)
        self.dane_aplikacji = SekcjaRozwijana("Dane aplikacji")
        auth.addWidget(self.dane_aplikacji)
        form = QFormLayout()
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.srodowisko = QComboBox()
        for s in SrodowiskoAllegro:
            self.srodowisko.addItem(s.value, s)
        form.addRow("Środowisko", self.srodowisko)
        self.klient = QLineEdit()
        self.klient.setMaxLength(512)
        self.klient.setAccessibleName("Client ID aplikacji Allegro")
        form.addRow("Client ID", self.klient)
        self.sekret = QLineEdit()
        self.sekret.setMaxLength(1024)
        self.sekret.setEchoMode(QLineEdit.EchoMode.Password)
        self.sekret.setAccessibleName("Client Secret aplikacji Allegro")
        form.addRow("Client Secret", self.sekret)
        self.zgoda_zapis = QCheckBox("Zezwól na zapis i tworzenie szkiców")
        self.zgoda_zapis.setToolTip(
            "Wymaga offers:write w aplikacji Allegro i ponownego połączenia konta."
        )
        self.dane_aplikacji.wnetrze.addLayout(form)
        self.podpowiedz = QLabel(
            "Aplikacja Allegro musi obsługiwać Device Flow (aplikacja bez dostępu do "
            "przeglądarki). Do tej wersji potrzebne są uprawnienia odczytu profilu "
            "i ofert: allegro:api:profile:read oraz allegro:api:sale:offers:read. "
            "Opcjonalny zapis szkiców wymaga dodatkowo allegro:api:sale:offers:write. "
            "Po zmianie tej opcji użyj Zmień uprawnienia i potwierdź zgodę w Allegro."
        )
        self.podpowiedz.setWordWrap(True)
        self.dane_aplikacji.wnetrze.addWidget(self.podpowiedz)
        auth.addWidget(self.zgoda_zapis)
        self.zmien_zgode = QPushButton("Zmień uprawnienia")
        self.zmien_zgode.setToolTip(
            "Potwierdź nowy zakres dostępu w Allegro. Dane aplikacji pozostaną zapisane."
        )
        self.zmien_zgode.clicked.connect(self.zmien_uprawnienia)
        auth.addWidget(self.zmien_zgode, 0, Qt.AlignmentFlag.AlignLeft)
        self.zapamietaj = QCheckBox("Zapamiętaj połączenie")
        self.zapamietaj.setAccessibleName("Zapamiętaj połączenie na tym komputerze")
        self.zapamietaj.setChecked(serwis.mozna_zapamietac)
        self.zapamietaj.setEnabled(serwis.mozna_zapamietac)
        auth.addWidget(self.zapamietaj)
        self.ochrona = QLabel(
            "Windows zabezpieczy dane połączenia dla Twojego użytkownika systemu."
            if serwis.mozna_zapamietac
            else "Zapamiętywanie jest dostępne na Windows. "
            "Tutaj połączenie trwa do zamknięcia programu."
        )
        self.ochrona.setWordWrap(True)
        auth.addWidget(self.ochrona)
        self.ponow = QPushButton("Wznów zapisane połączenie")
        self.ponow.clicked.connect(self.przywroc)
        auth.addWidget(self.ponow, 0, Qt.AlignmentFlag.AlignLeft)
        buttons = QVBoxLayout()
        self.polacz = QPushButton("Połącz konto")
        self.polacz.setObjectName("primary")
        self.polacz.clicked.connect(self.rozpocznij)
        self.otworz = QPushButton("Otwórz zgodę w Allegro")
        self.otworz.setObjectName("primary")
        self.otworz.clicked.connect(self._otworz)
        self.otworz.setEnabled(False)
        self.rozlacz = QPushButton("Rozłącz i zapomnij")
        self.rozlacz.clicked.connect(self.rozlacz_i_zapomnij)
        self.rozlacz.setEnabled(False)
        for b in (self.polacz, self.otworz, self.rozlacz):
            buttons.addWidget(b, 0, Qt.AlignmentFlag.AlignLeft)
        auth.addLayout(buttons)
        self.odswiez = QPushButton("Pobierz szkice")
        self.odswiez.clicked.connect(lambda: self.pobierz(0))
        self.poprzednia = QPushButton("Poprzednia")
        self.poprzednia.clicked.connect(lambda: self.pobierz(self.offset - 50))
        self.nastepna = QPushButton("Następna")
        self.nastepna.clicked.connect(lambda: self.pobierz(self.offset + 50))
        self.podglad_przycisk = QPushButton("Podgląd pełnego opisu")
        self.podglad_przycisk.clicked.connect(self.pokaz_szkic)
        self.zakres = QLabel("Nie pobrano ofert.")
        self.zakres.setWordWrap(True)
        self.tabela = QTableWidget(0, 10)
        self.tabela.setWordWrap(False)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tabela.itemSelectionChanged.connect(self._przyciski)
        self.tabela.itemSelectionChanged.connect(self._wybor_panelu)
        self.tabela.cellActivated.connect(lambda *_: self.pokaz_szkic())
        self.tabela.setAccessibleName("Oferty na połączonym koncie Allegro")
        self.obszar = ObszarAllegro(
            self.tabela,
            self.status_konta,
            self.odswiez,
            self.podglad_przycisk,
            self.poprzednia,
            self.nastepna,
            self.zakres,
            self.zdjecia,
            self.uruchom,
        )
        self.obszar.propozycje_dostepne = propozycje is not None
        self.obszar.edytuj_propozycje.connect(self.przygotuj_edycje)
        self.obszar.status_zadany.connect(self._zmien_status_listy)
        self.obszar.ustawienia.connect(self.ustawienia_zadane.emit)
        self.obszar.pomoc.connect(self._pomoc_allegro)
        self.obszar.nowa.connect(self.nowa_oferta_zadana.emit)
        self.obszar.szczegoly.connect(self.pokaz_szkic)
        layout.addWidget(self.obszar)
        self.zgoda_zapis.toggled.connect(self._przyciski)
        self._przyciski()

    def _pomoc_allegro(self) -> None:
        if not QDesktopServices.openUrl(QUrl("https://allegro.pl/pomoc/dla-sprzedajacych")):
            self.obszar.uwaga.setText("Nie można otworzyć pomocy Allegro w przeglądarce.")

    def _komunikat(self, tekst: str) -> None:
        self.info.setText(tekst)
        self.status_konta.setText("● Połączono poprawnie" if self.sesja is not None else tekst)
        self.status_konta.setToolTip(tekst)
        self.status_konta.setProperty("polaczono", self.sesja is not None)
        self.status_konta.style().unpolish(self.status_konta)
        self.status_konta.style().polish(self.status_konta)

    def _przyciski(self) -> None:
        self.polacz.setEnabled(
            not self.trwa and self.aplikacja is None and self.sesja is None and not self.zapamietane
        )
        self.odswiez.setEnabled(self.sesja is not None and self.aplikacja is None and not self.trwa)
        for b in self.obszar.taby.values():
            b.setEnabled(self.odswiez.isEnabled())
        self.obszar.edytuj_propozycje_przycisk.setEnabled(
            self.odswiez.isEnabled() and self.propozycje is not None and self._wybrany_szkic()
        )
        self.podglad_przycisk.setEnabled(
            self.odswiez.isEnabled() and bool(self.tabela.selectedItems())
        )
        self.poprzednia.setEnabled(self.odswiez.isEnabled() and self.offset > 0)
        self.nastepna.setEnabled(
            self.odswiez.isEnabled() and self.offset + 50 < self.lacznie and self.offset < 9950
        )
        editable = self.aplikacja is None and self.sesja is None and not self.trwa
        for w in (self.klient, self.sekret, self.srodowisko):
            w.setEnabled(editable and not self.zapamietane)
        aplikacja = self.sesja.aplikacja if self.sesja is not None else None
        mozna_zmienic = (
            aplikacja is not None
            and self.aplikacja is None
            and not self.trwa
            and not self.dysk_trwa
        )
        self.zgoda_zapis.setEnabled((editable and not self.zapamietane) or mozna_zmienic)
        self.zmien_zgode.setVisible(aplikacja is not None and not self._zmiana_uprawnien)
        self.zmien_zgode.setEnabled(
            mozna_zmienic
            and aplikacja is not None
            and self.zgoda_zapis.isChecked() != aplikacja.zapis_szkicow
        )
        self.zapamietaj.setEnabled(
            editable and not self.zapamietane and self.serwis.mozna_zapamietac
        )
        self.ponow.setEnabled(editable and self.serwis.mozna_zapamietac)
        self.rozlacz.setEnabled(
            not self.dysk_trwa
            and (self.aplikacja is not None or self.sesja is not None or self.zapamietane)
        )

        self.polacz.setVisible(
            self.aplikacja is None and self.sesja is None and not self.zapamietane
        )
        self.otworz.setVisible(self.kod is not None)
        self.ponow.setVisible(self.zapamietane and self.sesja is None and self.aplikacja is None)
        self.rozlacz.setVisible(
            self.aplikacja is not None or self.sesja is not None or self.zapamietane
        )
        self.rozlacz.setText(
            "Anuluj"
            if self.aplikacja is not None
            else ("Rozłącz i zapomnij" if self.zapamietane else "Rozłącz")
        )
        self.zapamietaj.setVisible(self.sesja is None and not self.zapamietane)
        self.ochrona.setVisible(self.sesja is None and not self.zapamietane)

    def rozpocznij(self) -> None:
        if not self.polacz.isEnabled():
            return
        if not self.klient.text().strip() or not self.sekret.text():
            self.dane_aplikacji.ustaw_otwarte(True)
            self._komunikat("Uzupełnij dane aplikacji, aby połączyć konto.")
            (self.klient if not self.klient.text().strip() else self.sekret).setFocus()
            return
        a = AplikacjaAllegro(
            self.klient.text().strip(),
            self.sekret.text(),
            cast(SrodowiskoAllegro, self.srodowisko.currentData()),
            self.zgoda_zapis.isChecked(),
        )
        self.sekret.clear()
        self._rozpocznij(a)

    def zmien_uprawnienia(self) -> None:
        if not self.zmien_zgode.isEnabled() or self.sesja is None or self.sesja.aplikacja is None:
            return
        self._zmiana_uprawnien = True
        self._anuluj_panel()
        self._rozpocznij(replace(self.sesja.aplikacja, zapis_szkicow=self.zgoda_zapis.isChecked()))

    def _rozpocznij(self, a: AplikacjaAllegro) -> None:
        self.aplikacja = a
        self.generacja += 1
        gen = self.generacja
        self.trwa = True
        self.rozlacz.setEnabled(True)
        self._komunikat("Pobieranie kodu zgody z Allegro…")
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            self.trwa = False
            self.kod = cast(KodUrzadzenia, wynik)
            self.koniec = self.serwis.teraz() + self.kod.waznosc
            self.odstep = self.kod.odstep
            self.otworz.setEnabled(True)
            self._komunikat(
                f"Otwórz zgodę w Allegro i zatwierdź konto. Kod: {self.kod.kod_uzytkownika}"
            )
            self.timer.start(self.odstep * 1000)
            self._przyciski()

        self.uruchom(lambda: self.serwis.rozpocznij(a), gotowe, lambda k, m: self._blad(gen, k, m))

    def _otworz(self) -> None:
        if (
            self.kod is not None
            and self.otworz.isEnabled()
            and not QDesktopServices.openUrl(QUrl(self.kod.adres))
        ):
            self._komunikat("Nie można otworzyć przeglądarki. Spróbuj ponownie.")

    def _sprawdz(self) -> None:
        a, kod, gen = self.aplikacja, self.kod, self.generacja
        if a is None or kod is None or self.trwa:
            return
        if self.serwis.teraz() >= self.koniec:
            self._blad(gen, "WYGASLA", "Kod zgody wygasł. Połącz konto ponownie.")
            return
        self.trwa = True

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            sesja = cast(SesjaAllegro, wynik)
            if (
                self._zmiana_uprawnien
                and self.sesja is not None
                and (
                    sesja.konto.id != self.sesja.konto.id
                    or sesja.srodowisko != self.sesja.srodowisko
                )
            ):
                self._anuluj_zmiane("Wybrano inne konto. Uprawnienia nie zostały zmienione.")
                return
            self.aplikacja, self.kod = None, None
            self.otworz.setEnabled(False)
            if not (self.zapamietane if self._zmiana_uprawnien else self.zapamietaj.isChecked()):
                self._polaczono(sesja, False)
                return
            self.dysk_trwa = True
            self._komunikat("Zapamiętywanie połączenia…")
            self._przyciski()

            def zapisano(_: object) -> None:
                if gen == self.generacja:
                    self.dysk_trwa = False
                    self._polaczono(sesja, True)

            def blad_zapisu(k: str, m: str) -> None:
                if gen == self.generacja:
                    self.dysk_trwa = False
                    if self._zmiana_uprawnien:
                        self._anuluj_zmiane("Nie zapisano nowych uprawnień. " + m)
                        return
                    self._polaczono(sesja, False)
                    self._komunikat("Połączono tylko do zamknięcia programu. " + m)

            self.uruchom(lambda: self.serwis.zapamietaj(sesja), zapisano, blad_zapisu)

        self.uruchom(
            lambda: self.serwis.sprawdz(a, kod.kod), gotowe, lambda k, m: self._blad(gen, k, m)
        )

    def _polaczono(self, sesja: SesjaAllegro, zapisano: bool) -> None:
        self._zmiana_uprawnien = False
        self.sesja = sesja
        if sesja.aplikacja is not None:
            self.zgoda_zapis.setChecked(sesja.aplikacja.zapis_szkicow)
        self.obszar.ustaw_konto(sesja.konto.login)
        self.dane_aplikacji.ustaw_otwarte(False)
        self.trwa = False
        self.zapamietane = zapisano
        self._komunikat(
            f"Połączono: {sesja.konto.login} • {sesja.srodowisko.value}. "
            + (
                "Połączenie zapamiętane."
                if zapisano
                else "Połączenie tylko do zamknięcia programu."
            )
        )
        self.stan.emit(f"Allegro: {sesja.konto.login}")
        self.wygasanie.start()
        self._przyciski()
        self.pobierz(0)

    def przywroc(self) -> None:
        if self.trwa or not self.serwis.mozna_zapamietac:
            return
        if self.podglad is not None:
            self.podglad.close()
        self._anuluj_panel()
        self.generacja += 1
        gen = self.generacja
        self.trwa, self.dysk_trwa = True, True
        self.sesja = None
        self.ostatnia_strona = None
        self.obszar.ustaw_konto(None)
        self.obszar.wyczysc()
        self.tabela.setRowCount(0)
        self.wygasanie.stop()
        self.stan.emit("Allegro: sprawdzanie połączenia")
        self._komunikat("Wznawianie zapisanego połączenia…")
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            self.trwa, self.dysk_trwa = False, False
            sesja = cast(SesjaAllegro | None, wynik)
            if sesja is None:
                self.zapamietane = False
                self.anuluj()
                return
            if sesja.aplikacja is not None:
                self.klient.setText(sesja.aplikacja.klient)
                self.zgoda_zapis.setChecked(sesja.aplikacja.zapis_szkicow)
            self.srodowisko.setCurrentIndex(self.srodowisko.findData(sesja.srodowisko))
            self._polaczono(sesja, True)

        def blad(kod: str, komunikat: str) -> None:
            if gen != self.generacja:
                return
            self.trwa, self.dysk_trwa = False, False
            self.zapamietane = True  # Także uszkodzony zapis można jawnie usunąć.
            self.anuluj()
            self._komunikat(
                "Nie udało się wznowić połączenia. "
                + komunikat
                + " Ponów próbę lub wybierz Rozłącz i zapomnij."
            )

        self.uruchom(self.serwis.przywroc, gotowe, blad)

    def _anuluj_zmiane(self, komunikat: str) -> None:
        self.generacja += 1
        self.timer.stop()
        self.aplikacja, self.kod = None, None
        self.trwa = self._zmiana_uprawnien = False
        self.otworz.setEnabled(False)
        if self.sesja is not None and self.sesja.aplikacja is not None:
            self.zgoda_zapis.setChecked(self.sesja.aplikacja.zapis_szkicow)
        self._komunikat(komunikat)
        self._przyciski()

    def rozlacz_i_zapomnij(self) -> None:
        if self._zmiana_uprawnien and not self.dysk_trwa:
            self._anuluj_zmiane("Anulowano zmianę uprawnień. Dotychczasowe połączenie zachowane.")
            return
        if self.dysk_trwa:
            return
        if not self.zapamietane:
            self.anuluj()
            return
        self.anuluj()
        self.trwa, self.dysk_trwa = True, True
        self._komunikat("Usuwanie zapisanego połączenia…")
        self._przyciski()
        gen = self.generacja

        def gotowe(_: object) -> None:
            if gen == self.generacja:
                self.trwa, self.dysk_trwa, self.zapamietane = False, False, False
                self._komunikat("Rozłączono. Zapisane połączenie zostało usunięte.")
                self._przyciski()

        def blad(k: str, m: str) -> None:
            if gen == self.generacja:
                self.trwa, self.dysk_trwa = False, False
                self._komunikat(m)
                self._przyciski()

        self.uruchom(self.serwis.zapomnij, gotowe, blad)

    def _blad(self, gen: int, kod: str, komunikat: str) -> None:
        if gen != self.generacja:
            return
        self.trwa = False
        if self.aplikacja is not None and kod in {"OCZEKIWANIE", "WOLNIEJ"}:
            if kod == "WOLNIEJ":
                self.odstep = min(3600, self.odstep + 5)
            self.timer.start(self.odstep * 1000)
            return
        if self._zmiana_uprawnien:
            self._anuluj_zmiane("Nie zmieniono uprawnień. " + komunikat)
            return
        if self.aplikacja is None and self.zapamietane and kod in {"WYGASLA", "AUTORYZACJA"}:
            self.przywroc()
            return
        if self.aplikacja is not None or kod in {"WYGASLA", "AUTORYZACJA"}:
            self.anuluj()
        self._komunikat(komunikat)
        if kod in {"KONFIGURACJA", "APLIKACJA"}:
            self.dane_aplikacji.ustaw_otwarte(True)
        self._przyciski()

    def _zmien_status_listy(self, status: object) -> None:
        if self.trwa or self._zmiana_uprawnien or self.sesja is None:
            return
        self.status_listy = cast(StatusOfertyAllegro | None, status)
        self.obszar.ustaw_status_listy(self.status_listy)
        self.obszar.szukaj.clear()
        self.pobierz(0)

    def _szczegoly_oferty(self, sesja: SesjaAllegro, ident: str) -> SzczegolySzkicuAllegro:
        if self.status_listy == StatusOfertyAllegro.SZKIC:
            return self.serwis.szkic(sesja, ident)
        return self.serwis.oferta(sesja, ident)

    def pobierz(self, offset: int = 0) -> None:
        sesja, gen = self.sesja, self.generacja
        if sesja is None or self.trwa or self._zmiana_uprawnien:
            return
        self.trwa = True
        status = self.status_listy
        self._anuluj_panel()
        # Poprzednia strona nie udaje aktualnego wyniku po nieudanym odczycie.
        self.obszar.wyczysc()
        self.ostatnia_strona = None
        self.tabela.setRowCount(0)
        self.lacznie = 0
        self.zakres.setText("Pobieranie ofert…")
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            strona = cast(StronaSzkicowAllegro, wynik)
            self.trwa = False
            self.offset, self.lacznie = strona.offset, strona.lacznie
            self.ostatnia_strona = strona
            self.tabela.setRowCount(len(strona.szkice))
            for row, p in enumerate(strona.szkice):
                self.tabela.setItem(row, 0, QTableWidgetItem(p.id))
                self.tabela.setItem(row, 1, QTableWidgetItem(p.tytul))
            self.obszar.ustaw_strone(strona)
            self.zakres.setText(
                f"{strona.offset + 1}–{strona.offset + len(strona.szkice)} z {strona.lacznie}"
                if strona.szkice
                else "Brak ofert na tej stronie."
            )
            if strona.lacznie > 10000:
                self.zakres.setText(self.zakres.text() + " • Limit przeglądania tej wersji: 10 000")
            self._przyciski()
            self.oferty_odczytane.emit()

        def blad(kod: str, komunikat: str) -> None:
            if gen == self.generacja:
                self.zakres.setText("Nie pobrano ofert. " + komunikat)
            self._blad(gen, kod, komunikat)

        self.uruchom(
            lambda: (
                self.serwis.szkice(sesja, offset)
                if status == StatusOfertyAllegro.SZKIC
                else self.serwis.oferty(sesja, status, offset)
            ),
            gotowe,
            blad,
        )

    def _wybrany_szkic(self) -> bool:
        row = self.tabela.currentRow()
        strona = self.ostatnia_strona
        return (
            strona is not None
            and 0 <= row < len(strona.szkice)
            and not self.tabela.isRowHidden(row)
            and strona.szkice[row].status == StatusOfertyAllegro.SZKIC
        )

    def przygotuj_edycje(self) -> None:
        sesja, gen = self.sesja, self.generacja
        if (
            sesja is None
            or self.trwa
            or self._zmiana_uprawnien
            or self.propozycje is None
            or not self._wybrany_szkic()
        ):
            return
        if self.edytor is not None:
            self.edytor.raise_()
            return
        item = self.tabela.item(self.tabela.currentRow(), 0)
        if item is None:
            return
        ident = item.text()
        propozycje = self.propozycje
        self.trwa = True
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja or self.sesja is not sesja:
                return
            self.trwa = False
            dialog = EdytorPropozycjiAllegro(
                self,
                cast(SzczegolySzkicuAllegro, wynik),
                sesja,
                propozycje,
                self.serwis,
                lambda: None if self._zmiana_uprawnien else self.sesja,
                self.uruchom,
                self.zdjecia,
                self.zapis_szkicu,
            )
            self.edytor = dialog

            def zamknieto() -> None:
                if self.edytor is dialog:
                    self.edytor = None
                dialog.deleteLater()
                if dialog.zapisany and self.sesja is sesja and not self.trwa:
                    self.pobierz(self.offset)

            dialog.finished.connect(zamknieto)
            dialog.show()
            self._przyciski()

        def odczyt() -> SzczegolySzkicuAllegro:
            wynik = self.serwis.szkic(sesja, ident)
            propozycje.rozpocznij(sesja, wynik)
            return wynik

        self.uruchom(odczyt, gotowe, lambda k, m: self._blad(gen, k, m))

    def _wybor_panelu(self) -> None:
        self._panel_generacja += 1
        self._panel_timer.start(180)

    def _wczytaj_panel(self) -> None:
        sesja = self.sesja
        item = self.tabela.item(self.tabela.currentRow(), 0)
        if (
            not self.isVisible()
            or sesja is None
            or self._zmiana_uprawnien
            or self.trwa
            or item is None
            or self.tabela.isRowHidden(self.tabela.currentRow())
        ):
            return
        if self._panel_trwa:
            self._panel_oczekuje = True
            return
        ident, gen, wybor = item.text(), self.generacja, self._panel_generacja
        self._panel_trwa = True
        self._panel_operacja += 1
        operacja = self._panel_operacja

        def zakoncz() -> None:
            self._panel_trwa = False
            if self._panel_oczekuje:
                self._panel_oczekuje = False
                self._panel_timer.start(0)

        def gotowe(wynik: object) -> None:
            if gen != self.generacja or operacja != self._panel_operacja:
                return
            zakoncz()
            if wybor == self._panel_generacja:
                self.obszar.pokaz_szczegoly(cast(SzczegolySzkicuAllegro, wynik))

        def blad(kod: str, komunikat: str) -> None:
            if gen != self.generacja or operacja != self._panel_operacja:
                return
            zakoncz()
            if wybor == self._panel_generacja:
                self.obszar.uwaga.setText("Nie pobrano szczegółów: " + komunikat)
                if kod in {"WYGASLA", "AUTORYZACJA"}:
                    self._blad(gen, kod, komunikat)

        self.uruchom(lambda: self._szczegoly_oferty(sesja, ident), gotowe, blad)

    def _anuluj_panel(self) -> None:
        self._panel_timer.stop()
        self._panel_generacja += 1
        self._panel_operacja += 1
        self._panel_trwa = self._panel_oczekuje = False

    def pokaz_szkic(self) -> None:
        sesja, gen = self.sesja, self.generacja
        item = self.tabela.item(self.tabela.currentRow(), 0)
        if sesja is None or self.trwa or self._zmiana_uprawnien or item is None:
            return
        ident = item.text()
        if self.podglad is not None:
            self.podglad.close()
        self.trwa = True
        self._komunikat("Pobieranie szczegółów oferty…")
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            self.trwa = False
            self.obszar.pokaz_szczegoly(cast(SzczegolySzkicuAllegro, wynik))
            self.podglad = PodgladSzkicuAllegro(
                self, cast(SzczegolySzkicuAllegro, wynik), sesja, self.zdjecia, self.uruchom
            )
            self.podglad.finished.connect(lambda _: setattr(self, "podglad", None))
            self.podglad.show()
            self._komunikat("Pobrano podgląd oferty z Allegro.")
            self._przyciski()

        self.uruchom(
            lambda: self._szczegoly_oferty(sesja, ident), gotowe, lambda k, m: self._blad(gen, k, m)
        )

    def _waznosc(self) -> None:
        if (
            self.sesja is not None
            and self.serwis.teraz() >= self.sesja.wygasa
            and not self.trwa
            and not self._zmiana_uprawnien
        ):
            if self.zapamietane:
                self.przywroc()
                return
            self.anuluj()
            self._komunikat("Sesja wygasła. Połącz konto ponownie.")

    def anuluj(self) -> None:
        self._zmiana_uprawnien = False
        self.obszar.ustaw_konto(None)
        self._anuluj_panel()
        self.obszar.wyczysc()
        if self.podglad is not None:
            self.podglad.close()
        self.generacja += 1
        self.timer.stop()
        self.wygasanie.stop()
        self.aplikacja, self.kod, self.sesja = None, None, None
        self.sekret.clear()
        self.trwa = False
        self.otworz.setEnabled(False)
        self.rozlacz.setEnabled(False)
        self.tabela.setRowCount(0)
        self.offset, self.lacznie = 0, 0
        self.ostatnia_strona = None
        self.zakres.setText("Nie pobrano ofert.")
        self._komunikat("Konto niepołączone. Połącz je w Ustawieniach.")
        self.stan.emit("Allegro: niepołączone")
        self._przyciski()

    def showEvent(self, event: QShowEvent) -> None:
        super().showEvent(event)
        self._wybor_panelu()
