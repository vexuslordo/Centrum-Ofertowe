"""Plan, walidacja i jawne tworzenie INACTIVE; bez publikacji i lokalnych Produktów."""

import json
import re
from collections.abc import Callable
from dataclasses import dataclass, field, replace
from decimal import Decimal, InvalidOperation
from hashlib import sha256
from typing import Protocol
from urllib.parse import urlsplit
from uuid import UUID

from vexlab.domena.produkt import NieprawidlowyProdukt, sprawdz_ean
from vexlab.przypadki_uzycia.allegro import BladAllegro, CzasMonotoniczny, SesjaAllegro
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad


def skrot(dane: object) -> str:
    return sha256(json.dumps(dane, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def adres_zdjecia(url: str) -> bool:
    try:
        u = urlsplit(url)
        return (
            u.scheme == "https"
            and bool(u.hostname)
            and "." in (u.hostname or "")
            and not u.username
            and not u.password
            and u.port in {None, 443}
            and not re.fullmatch(r"[0-9.]+", u.hostname or "")
            and not any(c.isspace() for c in url)
            and len(url) <= 4096
        )
    except ValueError:
        return False


@dataclass(frozen=True)
class ParametrSzkicu:
    id: str
    nazwa: str
    typ: str
    wymagany: bool
    slownik: tuple[tuple[str, str], ...] = ()
    produktowy: bool = False
    wymagany_produkt: bool = field(default=False, repr=False)


@dataclass(frozen=True)
class ProduktSzkicu:
    id: str
    nazwa: str
    kategoria: str
    parametry: tuple[ParametrSzkicu, ...] = ()


@dataclass(frozen=True)
class UstawieniaSzkicu:
    waluta: str
    ilosc: int
    produkt: str = ""
    cena: str = ""
    wartosci: tuple[tuple[str, str], ...] = ()
    nowy: bool = field(default=False, repr=False)
    kategoria: str = field(default="", repr=False)
    zrodla: tuple[tuple[str, str], ...] = field(default=(), repr=False)


@dataclass(frozen=True)
class PlanNowegoSzkicu:
    oferta: OfertaPodglad
    ustawienia: UstawieniaSzkicu
    konto: str
    srodowisko: str
    czas: float
    produkt: ProduktSzkicu | None
    bledy: tuple[str, ...]


@dataclass(frozen=True)
class ProbaTworzenia:
    zrodlo: str
    tresc: str
    status: int = 0
    ident: str = ""
    operacja: str = ""


@dataclass(frozen=True)
class WynikTworzenia:
    sku: str
    stan: str
    komunikat: str
    ident: str = ""


class RejestrTworzenia(Protocol):
    def odczytaj(self, klucz: str) -> ProbaTworzenia | None: ...
    def rozpocznij(self, klucz: str, proba: ProbaTworzenia) -> None: ...
    def zapisz(self, klucz: str, proba: ProbaTworzenia) -> None: ...
    def usun(self, klucz: str) -> None: ...


@dataclass(frozen=True)
class KategoriaSzkicu:
    id: str
    nazwa: str


class APINowychSzkicow(Protocol):
    def kategorie(self, s: SesjaAllegro, fraza: str) -> tuple[KategoriaSzkicu, ...]: ...
    def nowy_produkt(
        self, s: SesjaAllegro, kategoria: str, odswiez: bool = False
    ) -> ProduktSzkicu: ...
    def potwierdz_nowy(
        self,
        s: SesjaAllegro,
        ident: str,
        nazwa: str,
        kategoria: str,
        parametry: list[dict[str, object]],
    ) -> bool: ...
    def znajdz_produkty(
        self, s: SesjaAllegro, fraza: str, gtin: bool = False
    ) -> tuple[ProduktSzkicu, ...]: ...
    def produkt_szkicu(self, s: SesjaAllegro, ident: str) -> ProduktSzkicu: ...
    def wyslij_zdjecie(self, s: SesjaAllegro, url: str) -> str: ...
    def utworz_szkic(self, s: SesjaAllegro, dane: dict[str, object]) -> ProbaTworzenia: ...
    def znajdz_szkic(self, s: SesjaAllegro, external: str) -> dict[str, object] | None: ...
    def odczytaj_szkic(self, s: SesjaAllegro, ident: str) -> dict[str, object]: ...
    def operacja_tworzenia(self, s: SesjaAllegro, ident: str, operacja: str) -> bool: ...


def odcisk_zdalny(d: dict[str, object], nowy: bool = False) -> str:
    """Normalizacja pól żądania: dodatkowe pola odpowiedzi nie wpływają na wynik."""
    try:
        product = d["productSet"]
        if not isinstance(product, list):
            raise ValueError("productSet")
        first = product[0]
        if not isinstance(first, dict) or not isinstance(first["product"], dict):
            raise ValueError("product")
        selling, stock = d["sellingMode"], d["stock"]
        if not isinstance(selling, dict) or not isinstance(selling["price"], dict):
            raise ValueError("price")
        if not isinstance(stock, dict):
            raise ValueError("stock")
        price = selling["price"]
        external, publication = d["external"], d["publication"]
        if not isinstance(external, dict) or not isinstance(publication, dict):
            raise ValueError("publication")
        return skrot(
            {
                "name": d["name"],
                "product": "NOWY" if nowy else first["product"]["id"],
                "external": external["id"],
                "status": publication["status"],
                "amount": str(Decimal(str(price["amount"])).normalize()),
                "currency": price["currency"],
                "available": stock["available"],
                "unit": stock.get("unit", "UNIT"),
                "images": d["images"],
                "description": d["description"],
            }
        )
    except (ValueError, KeyError, IndexError, TypeError, InvalidOperation):
        raise BladAllegro(
            "ODPOWIEDZ", "Niepełna odpowiedź szkicu; nie potwierdzono treści."
        ) from None


class NoweSzkiceAllegro:
    def __init__(
        self, api: APINowychSzkicow, rejestr: RejestrTworzenia, czas: CzasMonotoniczny
    ) -> None:
        self.api, self.rejestr, self.czas = api, rejestr, czas

    def _sesja(self, s: SesjaAllegro) -> None:
        if self.czas.teraz() >= s.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")

    def przygotuj(self, s: SesjaAllegro, o: OfertaPodglad, u: UstawieniaSzkicu) -> PlanNowegoSzkicu:
        self._sesja(s)
        bledy = list(o.problemy)
        if not o.sku.strip() or len(o.sku) > 256:
            bledy.append("Brak poprawnego SKU (do 256 znaków).")
        if not 12 <= len(o.tytul) <= 75 or len(o.tytul.split()) < 3:
            bledy.append("Tytuł: 12–75 znaków i co najmniej 3 słowa.")
        try:
            cena = Decimal((u.cena or o.cena).replace(",", "."))
            if (
                not cena.is_finite()
                or not 0 < cena <= Decimal("999999999")
                or cena != cena.quantize(Decimal("0.01"))
            ):
                raise ValueError("cena")
        except (ValueError, InvalidOperation):
            bledy.append("Uzupełnij dodatnią cenę brutto (do 2 miejsc po przecinku).")
        if not re.fullmatch(r"[A-Z]{3}", u.waluta):
            bledy.append("Wybierz walutę ceny brutto.")
        if type(u.ilosc) is not int or not 0 <= u.ilosc <= 10000000:
            bledy.append("Ilość musi być liczbą całkowitą 0–10 000 000.")
        urls = self._zdjecia(o)
        if not o.zdjecia or len(urls) > 16 or not all(adres_zdjecia(url) for url in urls):
            bledy.append("Wymagane 1–16 poprawnych zdjęć HTTPS w galerii/opisie.")
        if not o.sekcje and not o.opis.strip():
            bledy.append("Brak opisu oferty.")
        if u.nowy and u.zrodla:
            wartosci = dict(u.wartosci)
            for ident_parametru, zrodlo in u.zrodla:
                if zrodlo not in {"sku", "ean"}:
                    bledy.append("Nieprawidłowe źródło parametru produktu.")
                    continue
                wartosci[ident_parametru] = o.sku if zrodlo == "sku" else o.ean
                if zrodlo == "ean" and o.ean:
                    try:
                        sprawdz_ean(o.ean)
                    except NieprawidlowyProdukt:
                        bledy.append(
                            "Nieprawidłowa cyfra kontrolna EAN wybranego jako źródło parametru."
                        )
            u = replace(u, wartosci=tuple(wartosci.items()))
        produkt = None
        try:
            if u.nowy:
                produkt = replace(self.api.nowy_produkt(s, u.kategoria), nazwa=o.tytul)
                self._parametry(produkt, u, True)
                self._parametry(produkt, u)
                return self._plan(s, o, u, produkt, bledy)
            ident = u.produkt
            if not ident:
                if not re.fullmatch(r"(?:[0-9]{8}|[0-9]{13})", o.ean):
                    raise BladAllegro("PRODUKT", "Brak EAN: wybierz produkt z Katalogu Allegro.")
                try:
                    sprawdz_ean(o.ean)
                except NieprawidlowyProdukt:
                    raise BladAllegro(
                        "PRODUKT", "EAN ma niepoprawną cyfrę kontrolną. Wybierz produkt ręcznie."
                    ) from None
                candidates = self.api.znajdz_produkty(s, o.ean, True)
                if len(candidates) != 1:
                    raise BladAllegro(
                        "PRODUKT", "Brak jednoznacznego produktu Allegro. Wybierz go ręcznie."
                    )
                ident = candidates[0].id
            UUID(ident)
            produkt = self.api.produkt_szkicu(s, ident)
            self._parametry(produkt, u)
        except ValueError:
            bledy.append("Nieprawidłowy identyfikator produktu Allegro.")
        except BladAllegro as exc:
            if exc.kod in {"AUTORYZACJA", "UPRAWNIENIA", "WYGASLA", "LIMIT", "SIEC"}:
                raise
            bledy.append(str(exc))
        return self._plan(s, o, u, produkt, bledy)

    def _plan(
        self,
        s: SesjaAllegro,
        o: OfertaPodglad,
        u: UstawieniaSzkicu,
        produkt: ProduktSzkicu | None,
        bledy: list[str],
    ) -> PlanNowegoSzkicu:
        try:
            opis = self._opis(o, {url: url for url in self._zdjecia(o)})
            if len(json.dumps(opis, ensure_ascii=False).encode()) > 40000:
                bledy.append("Opis przekracza 40 000 bajtów.")
        except BladAllegro as exc:
            bledy.append(str(exc))
        return PlanNowegoSzkicu(
            o, u, s.konto.id, s.srodowisko.value, self.czas.teraz(), produkt, tuple(bledy)
        )

    @staticmethod
    def _parametry(
        p: ProduktSzkicu, u: UstawieniaSzkicu, produktowe: bool = False
    ) -> list[dict[str, object]]:
        wartosci = dict(u.wartosci)
        wynik: list[dict[str, object]] = []
        for req in p.parametry:
            czy_produktowy = req.produktowy or (u.nowy and req.wymagany_produkt)
            if czy_produktowy != produktowe:
                continue
            value = wartosci.get(req.id, "").strip()
            if not value:
                if req.wymagany or (produktowe and req.wymagany_produkt):
                    raise BladAllegro("PARAMETRY", "Uzupełnij parametr: " + req.nazwa)
                continue
            if req.typ == "dictionary":
                if value not in dict(req.slownik):
                    raise BladAllegro("PARAMETRY", "Wybierz wartość słownikową: " + req.nazwa)
                wynik.append({"id": req.id, "valuesIds": [value]})
            elif req.typ in {"integer", "float", "string"}:
                if req.typ != "string":
                    try:
                        n = Decimal(value)
                        if not n.is_finite() or (req.typ == "integer" and n != n.to_integral()):
                            raise ValueError("liczba")
                    except (ValueError, InvalidOperation):
                        raise BladAllegro(
                            "PARAMETRY", "Nieprawidłowa liczba: " + req.nazwa
                        ) from None
                wynik.append({"id": req.id, "values": [value]})
            else:
                raise BladAllegro("PARAMETRY", "Nieobsługiwany typ parametru: " + req.nazwa)
        return wynik

    @staticmethod
    def _zdjecia(o: OfertaPodglad) -> tuple[str, ...]:
        return tuple(
            dict.fromkeys(
                (*o.zdjecia, *(e.adres for sekcja in o.sekcje for e in sekcja if e.typ == "obraz"))
            )
        )

    @staticmethod
    def _opis(o: OfertaPodglad, urls: dict[str, str]) -> dict[str, object]:
        if not o.sekcje:
            return {"sections": [{"items": [{"type": "TEXT", "content": o.opis}]}]}
        sekcje = []
        for sekcja in o.sekcje:
            if not 1 <= len(sekcja) <= 2:
                raise BladAllegro("OPIS", "Sekcja opisu musi zawierać 1–2 elementy.")
            items = []
            for e in sekcja:
                if e.typ == "tekst":
                    items.append({"type": "TEXT", "content": e.tekst})
                elif e.typ == "obraz" and e.adres in urls:
                    items.append({"type": "IMAGE", "url": urls[e.adres]})
                else:
                    raise BladAllegro("OPIS", "Niepoprawny element opisu.")
            sekcje.append({"items": items})
        return {"sections": sekcje}

    @staticmethod
    def klucz(s: SesjaAllegro, sku: str) -> str:
        return skrot([s.srodowisko.value, s.konto.id, sku.strip().casefold()])

    def _kontekst(self, s: SesjaAllegro, p: PlanNowegoSzkicu) -> None:
        self._sesja(s)
        if (p.konto, p.srodowisko) != (s.konto.id, s.srodowisko.value):
            raise BladAllegro("KONTO", "Plan dotyczy innego konta lub środowiska.")
        if p.bledy or p.produkt is None:
            raise BladAllegro("PLAN", "Najpierw popraw i sprawdź tę pozycję.")

    def _zrodlo(self, p: PlanNowegoSzkicu) -> str:
        dane = [repr(p.oferta), repr(p.ustawienia), repr(p.produkt)]
        if p.ustawienia.nowy:
            dane.extend(
                [
                    "NOWY",
                    p.ustawienia.kategoria,
                    repr(tuple((r.id, r.wymagany_produkt) for r in p.produkt.parametry))
                    if p.produkt
                    else "",
                ]
            )
        return skrot(dane)

    def utworz(
        self, s: SesjaAllegro, p: PlanNowegoSzkicu, anulowano: Callable[[], bool]
    ) -> WynikTworzenia:
        self._kontekst(s, p)
        o, u = p.oferta, p.ustawienia
        if s.aplikacja is None or not s.aplikacja.zapis_szkicow:
            raise BladAllegro(
                "UPRAWNIENIA", "Zmień uprawnienia konta: wymagana zgoda na zapis szkiców."
            )
        k = self.klucz(s, o.sku)
        if self.rejestr.odczytaj(k) is not None:
            return self.sprawdz(s, p)
        if anulowano():
            return WynikTworzenia(o.sku, "Anulowano", "Nie wysłano żądania tworzenia.")
        if p.produkt is None:
            raise BladAllegro("PLAN", "Brak wybranego produktu.")
        if u.nowy:
            self.api.nowy_produkt(s, u.kategoria, True)
        swiezy = self.przygotuj(s, o, replace(u, produkt=p.produkt.id))
        if swiezy.bledy or swiezy.produkt != p.produkt:
            raise BladAllegro(
                "PLAN",
                "Dane lub wymagania produktu zmieniły się. Sprawdź plan ponownie. "
                + "; ".join(swiezy.bledy),
            )
        urls = {}
        for url in self._zdjecia(o):
            self._sesja(s)
            if anulowano():
                return WynikTworzenia(
                    o.sku, "Anulowano", "Nie utworzono szkicu; część zdjęć mogła zostać przesłana."
                )
            urls[url] = self.api.wyslij_zdjecie(s, url)
        if p.produkt is None:
            raise BladAllegro("PLAN", "Brak wybranego produktu Allegro.")
        dane: dict[str, object] = {
            "name": o.tytul,
            "productSet": [{"product": {"id": p.produkt.id}}],
            "category": {"id": p.produkt.kategoria},
            "parameters": self._parametry(p.produkt, u),
            "stock": {"available": u.ilosc, "unit": "UNIT"},
            "sellingMode": {
                "format": "BUY_NOW",
                "price": {
                    "amount": str(Decimal((u.cena or o.cena).replace(",", "."))),
                    "currency": u.waluta,
                },
            },
            "images": list(dict.fromkeys(urls[url] for url in o.zdjecia)),
            "description": self._opis(o, urls),
            "external": {"id": "vexlab-" + k},
            "publication": {"status": "INACTIVE", "republish": False},
        }
        if u.nowy:
            dane["productSet"] = [
                {
                    "product": {
                        "name": o.tytul,
                        "category": {"id": p.produkt.kategoria},
                        "parameters": self._parametry(p.produkt, u, True),
                        "images": list(dict.fromkeys(urls[url] for url in o.zdjecia)),
                    }
                }
            ]
        proba = ProbaTworzenia(self._zrodlo(p), odcisk_zdalny(dane, u.nowy))
        if anulowano():
            return WynikTworzenia(o.sku, "Anulowano", "Nie wysłano żądania tworzenia.")
        self._sesja(s)
        self.rejestr.rozpocznij(k, proba)
        # Od tej chwili awaria nie może pozwolić na ponowienie POST.
        try:
            if self.api.znajdz_szkic(s, "vexlab-" + k) is not None:
                return WynikTworzenia(
                    o.sku,
                    "Wymaga sprawdzenia",
                    "Istnieje oferta o tym kluczu. Nie utworzono kolejnej.",
                )
            self._sesja(s)
            if anulowano():
                self.rejestr.usun(k)
                return WynikTworzenia(o.sku, "Anulowano", "Nie wysłano żądania tworzenia.")
        except BladAllegro:
            self.rejestr.usun(k)  # Nie wysłano POST.
            raise
        try:
            przyjecie = self.api.utworz_szkic(s, dane)
        except BladAllegro as exc:
            if exc.kod == "ODRZUCONO":
                self.rejestr.usun(k)
            raise
        self.rejestr.zapisz(
            k,
            ProbaTworzenia(
                proba.zrodlo, proba.tresc, przyjecie.status, przyjecie.ident, przyjecie.operacja
            ),
        )
        if przyjecie.status == 202:
            return WynikTworzenia(
                o.sku,
                "Przetwarzanie",
                "Allegro przyjęło zlecenie. Sprawdź wynik później.",
                przyjecie.ident,
            )
        return self.sprawdz(s, p)

    def sprawdz(self, s: SesjaAllegro, p: PlanNowegoSzkicu) -> WynikTworzenia:
        self._kontekst(s, p)
        k = self.klucz(s, p.oferta.sku)
        proba = self.rejestr.odczytaj(k)
        if proba is None:
            return WynikTworzenia(p.oferta.sku, "Nie wysłano", "Brak zarejestrowanej próby.")
        if proba.zrodlo != self._zrodlo(p):
            raise BladAllegro(
                "KONFLIKT",
                "Dla tego SKU zapisano inną wersję danych. Nie utworzono kolejnej oferty.",
            )
        if proba.operacja and not self.api.operacja_tworzenia(s, proba.ident, proba.operacja):
            return WynikTworzenia(
                p.oferta.sku,
                "Przetwarzanie",
                "Sprawdź wynik później; nie ponawiaj tworzenia.",
                proba.ident,
            )
        d = (
            self.api.odczytaj_szkic(s, proba.ident)
            if proba.ident
            else self.api.znajdz_szkic(s, "vexlab-" + k)
        )
        if d is None:
            return WynikTworzenia(
                p.oferta.sku,
                "Wynik nieznany",
                "Nie znaleziono szkicu. Ponowienie pozostaje zablokowane.",
            )
        if p.produkt is None:
            raise BladAllegro("PLAN", "Brak wybranego produktu.")
        parametry = d.get("parameters", [])
        if not isinstance(parametry, list):
            raise BladAllegro("ODPOWIEDZ", "Brak prawidłowych parametrów odczytanej oferty.")
        for oczekiwany in self._parametry(p.produkt, p.ustawienia):
            actual = next(
                (v for v in parametry if isinstance(v, dict) and v.get("id") == oczekiwany["id"]),
                None,
            )
            field = "valuesIds" if "valuesIds" in oczekiwany else "values"
            if actual is None or actual.get(field) != oczekiwany[field]:
                raise BladAllegro(
                    "KONFLIKT", "Odczytane parametry różnią się od planu. Zachowano blokadę."
                )
        if d.get("category") != {"id": p.produkt.kategoria}:
            kategoria = d.get("category")
            if not isinstance(kategoria, dict) or kategoria.get("id") != p.produkt.kategoria:
                raise BladAllegro("KONFLIKT", "Odczytana kategoria różni się od planu.")
        if p.ustawienia.nowy:
            zestaw = d.get("productSet")
            first = zestaw[0] if isinstance(zestaw, list) and zestaw else None
            prod = first.get("product") if isinstance(first, dict) else None
            ident_prod = prod.get("id") if isinstance(prod, dict) else None
            publikacja = prod.get("publication") if isinstance(prod, dict) else None
            if isinstance(publikacja, dict) and publikacja.get("status") in {
                "NOT_LISTED",
                "REMOVED",
            }:
                raise BladAllegro(
                    "KONFLIKT", "Produkt nie został przyjęty do katalogu. Nie ponawiaj."
                )
            if not isinstance(ident_prod, str) or not self.api.potwierdz_nowy(
                s,
                ident_prod,
                p.oferta.tytul,
                p.produkt.kategoria,
                self._parametry(p.produkt, p.ustawienia, True),
            ):
                raise BladAllegro(
                    "KONFLIKT",
                    "Nie potwierdzono nowego produktu Katalogu Allegro. "
                    "Sprawdź wynik; nie ponawiaj.",
                )
        if odcisk_zdalny(d, p.ustawienia.nowy) != proba.tresc:
            raise BladAllegro(
                "KONFLIKT",
                "Odczytana oferta nie odpowiada wysłanym danym INACTIVE. Zachowano blokadę.",
            )
        ident = d.get("id")
        if not isinstance(ident, str) or not ident.isascii() or not ident.isdigit():
            raise BladAllegro("ODPOWIEDZ", "Brak prawidłowego ID utworzonego szkicu.")
        # Brak metadanych akceptacji po awarii nadal nie dowodzi zakończenia operacji.
        if proba.status not in {201, 202} or (proba.status == 202 and not proba.operacja):
            return WynikTworzenia(
                p.oferta.sku,
                "Wymaga sprawdzenia",
                "Znaleziono zgodny szkic, ale nie potwierdzono zakończenia zlecenia.",
                ident,
            )
        uwagi = []
        validation = d.get("validation")
        groups = [d.get("warnings")]
        if isinstance(validation, dict):
            groups.extend((validation.get("warnings"), validation.get("errors")))
        for group in groups:
            if isinstance(group, list):
                for error in group[:10]:
                    if isinstance(error, dict):
                        uwagi.append(
                            str(error.get("userMessage") or error.get("code") or "Uwaga walidacji")[
                                :300
                            ]
                        )
        return WynikTworzenia(
            p.oferta.sku,
            "Utworzono szkic",
            "Potwierdzono odczytem INACTIVE; gotowość do sprzedaży wymaga osobnej weryfikacji. "
            + "; ".join(uwagi),
            ident,
        )
