from dataclasses import replace

import pytest
from PySide6.QtWidgets import QMessageBox, QWidget

from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow, zapisz_raport
from vexlab.przypadki_uzycia.nowe_szkice_allegro import WynikTworzenia


def panel(qtbot, fixture, oferty=None):
    service, api, repo, s, o, u = fixture
    jobs = []
    parent = QWidget()
    qtbot.addWidget(parent)
    w = DialogNowychSzkicow(parent, service, s, oferty or (o,), lambda *args: jobs.append(args))
    w._parent_test = parent
    w.waluta.setCurrentIndex(w.waluta.findData("PLN"))
    for i in range(len(w.oferty)):
        w.ustawienia[i] = u
    w.show()
    return w, jobs


def wykonaj(jobs):
    funkcja, sukces, blad = jobs[-1]
    try:
        wynik = funkcja()
    except Exception as e:
        raise AssertionError("Błąd zadania testowego") from e
    sukces(wynik)


def test_plan_wymaga_potwierdzenia_z_domyslnym_nie(qtbot, nowe_szkice_fixture, monkeypatch):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    api = nowe_szkice_fixture[1]
    w.przygotuj()
    assert not w.utworz_przycisk.isEnabled() and w.trwa
    wykonaj(jobs)
    assert w.utworz_przycisk.isEnabled() and "POST" not in api.calls
    potwierdzenia = []

    def odmowa(*args):
        potwierdzenia.append(args)
        return QMessageBox.StandardButton.No

    monkeypatch.setattr(QMessageBox, "question", odmowa)
    w.tworz()
    assert len(jobs) == 1 and potwierdzenia[-1][-1] == QMessageBox.StandardButton.No
    assert "INACTIVE" in potwierdzenia[-1][2] and "testowy" in potwierdzenia[-1][2]
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    w.tworz()
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Utworzono szkic" and w.eksport.isEnabled()
    w.wyslij(True)
    wykonaj(jobs)
    assert api.calls.count("POST") == 1
    w.waluta.setCurrentIndex(w.waluta.findData("EUR"))
    assert not w.plany and not w.utworz_przycisk.isEnabled()


def test_powtorzone_sku_i_bledna_cena_maja_raport_przed_wysylka(qtbot, nowe_szkice_fixture):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(
        qtbot,
        nowe_szkice_fixture,
        (o, replace(o, sku="test-1"), replace(o, sku="INNY", cena="brak")),
    )
    w.przygotuj()
    wykonaj(jobs)
    assert len(w.wyniki) == 3 and all(p.bledy for p in w.plany)
    assert "Powtórzone" in w.wyniki[0].komunikat
    assert "cenę" in w.wyniki[2].komunikat
    assert not w.utworz_przycisk.isEnabled()


@pytest.mark.parametrize("zmiana", [False, True])
def test_anulowanie_i_zmiana_sesji_blokuja_dalsza_serie(qtbot, nowe_szkice_fixture, zmiana):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    w.wyslij(False)
    if zmiana:
        w.zmiana_sesji()
    else:
        w.reject()
        assert w.isVisible() and w.trwa
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Wstrzymano"
    assert "POST" not in nowe_szkice_fixture[1].calls
    if zmiana:
        assert not w.utworz_przycisk.isEnabled() and w.eksport.isEnabled()
    w.reject()


def test_nieznany_wynik_wstrzymuje_reszte_i_pozwala_zachowac_raport(qtbot, nowe_szkice_fixture):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(qtbot, nowe_szkice_fixture, (o, replace(o, sku="DRUGI")))
    w.przygotuj()
    wykonaj(jobs)
    nowe_szkice_fixture[1].awaria = "timeout"
    w.wyslij(False)
    wykonaj(jobs)
    assert [x.stan for x in w.wyniki] == ["Wymaga sprawdzenia", "Wstrzymano"]
    assert nowe_szkice_fixture[1].calls.count("POST") == 1
    assert w.eksport.isEnabled()


def test_raport_chroni_arkusz_i_nie_nadpisuje_pliku(tmp_path):
    p = tmp_path / "raport.csv"
    zapisz_raport(p, (WynikTworzenia("=CMD()", "Utworzono", "+niebezpieczne", "123"),))
    tekst = p.read_text(encoding="utf-8-sig")
    assert "'=CMD()" in tekst and "'+niebezpieczne" in tekst
    with pytest.raises(FileExistsError):
        zapisz_raport(p, ())
    assert p.read_text(encoding="utf-8-sig") == tekst


def test_wejscie_z_paczki_w_oknie_glownym_nie_wysyla_bez_potwierdzenia(
    qtbot, tmp_path, nowe_szkice_fixture
):
    from PySide6.QtCore import QSettings

    from vexlab.adaptery.czytnik_importu import CzytnikTabel
    from vexlab.adaptery.eksport_csv import EksportCSV
    from vexlab.adaptery.import_sqlite import ImportSQLite
    from vexlab.adaptery.katalog_sqlite import KatalogSQLite
    from vexlab.adaptery.paczki_zip import CzytnikZIP, ProfileJSON
    from vexlab.adaptery.preferencje import PreferencjeQt
    from vexlab.gui.okno import OknoVexLab
    from vexlab.przypadki_uzycia.allegro import PolaczAllegro
    from vexlab.przypadki_uzycia.eksport import EksportujKatalog
    from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
    from vexlab.przypadki_uzycia.katalog import KatalogProduktow
    from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek
    from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
    from vexlab.przypadki_uzycia.producenci import RejestrProducentow

    serwis, api, _, sesja, o, _ = nowe_szkice_fixture
    repo = KatalogSQLite(tmp_path / "local.sqlite3")
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), ImportSQLite(repo.plik), repo),
        paczki=PodgladPaczek(CzytnikZIP(), ProfileJSON()),
        allegro=PolaczAllegro(api, api),
        nowe_szkice=serwis,
    )
    qtbot.addWidget(w, before_close_func=lambda _: qtbot.waitUntil(lambda: not w._zadania))
    w.show()
    qtbot.waitUntil(lambda: not w._zadania)
    w.strona_allegro.sesja = sesja
    w.strona_paczek.oferty = (o,)
    w.strona_paczek.przygotuj_allegro.setEnabled(True)
    w.strona_paczek.przygotuj_allegro.click()
    assert w.dialog_nowych_szkicow is not None
    assert not w.dialog_nowych_szkicow.utworz_przycisk.isEnabled()
    assert "POST" not in api.calls
    assert w.model.rowCount() == 0
    w.dialog_nowych_szkicow.reject()
    assert w.dialog_nowych_szkicow is None


def test_katalog_jest_czytany_poza_watkiem_gui(qtbot, nowe_szkice_fixture):
    from threading import get_ident

    from PySide6.QtCore import QThreadPool

    from vexlab.gui.zadania import Zadanie

    w, _ = panel(qtbot, nowe_szkice_fixture)
    api = nowe_szkice_fixture[1]
    watki = []
    oryginal = api.produkt_szkicu

    def odczyt(*args):
        watki.append(get_ident())
        return oryginal(*args)

    api.produkt_szkicu = odczyt
    zadania = []
    pool = QThreadPool()

    def uruchom(f, sukces, blad):
        z = Zadanie(f)
        zadania.append(z)
        z.sygnaly.wynik.connect(sukces)
        z.sygnaly.blad.connect(blad)
        pool.start(z)

    w.uruchom = uruchom
    w.przygotuj()
    qtbot.waitUntil(lambda: not w.trwa)
    pool.waitForDone()
    assert watki and all(t != get_ident() for t in watki)
    assert w.utworz_przycisk.isEnabled()


@pytest.mark.parametrize("motyw", ["dark", "light"])
def test_nowy_produkt_kategoria_i_wspolne_parametry_bez_nadpisywania_cen(
    qtbot, qapp, nowe_produkty_fixture, monkeypatch, motyw
):
    from PySide6.QtWidgets import QCheckBox, QComboBox, QDialog, QPushButton

    from vexlab.gui.design_system import zastosuj_motyw
    from vexlab.przypadki_uzycia.powloka import Motyw

    zastosuj_motyw(qapp, Motyw.CIEMNY if motyw == "dark" else Motyw.JASNY)

    o = nowe_produkty_fixture[4]
    oferty = (o, replace(o, sku="DRUGI", cena="999.99", ean=""))
    w, jobs = panel(qtbot, nowe_produkty_fixture, oferty)
    # Przed wyborem nowej ścieżki brak wskazanego UUID.
    for i in range(2):
        w.ustawienia[i] = replace(w.ustawienia[i], nowy=False, kategoria="", zrodla=())
    w.tabela.selectRow(0)

    def wybierz_kategorie(d):
        assert "kategorię" in d.windowTitle()
        razem = d.findChild(QCheckBox)
        assert not razem.isChecked()
        search = next(b for b in d.findChildren(QPushButton) if b.text() == "Znajdź kategorie")
        search.click()
        assert w.trwa
        wykonaj(jobs)
        wybor = d.findChild(QComboBox)
        assert not wybor.currentData()
        wybor.setCurrentIndex(1)
        razem.setChecked(True)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", wybierz_kategorie)
    w.nowy_produkt()
    wykonaj(jobs)
    assert all(p.ustawienia.nowy for p in w.plany)
    assert "Nowy produkt" in w.tabela.item(0, 2).text()
    assert all("Kod producenta" in p.bledy[0] for p in w.plany)

    def uzupelnij(d):
        # Słownik stanu i dwa jawne źródła z paczki; cena tylko bieżącego wiersza.
        from PySide6.QtWidgets import QLineEdit

        cena = d.findChildren(QLineEdit)[0]
        cena.setText("111.11")
        combos = d.findChildren(QComboBox)
        for c in combos:
            if "Kod producenta" in c.accessibleName():
                c.setCurrentIndex(c.findData("sku"))
            elif "EAN" in c.accessibleName():
                c.setCurrentIndex(c.findData(""))
            else:
                c.setCurrentIndex(c.findData("11323_1"))
        razem = d.findChild(QCheckBox)
        assert not razem.isChecked()
        razem.setChecked(True)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", uzupelnij)
    w.uzupelnij()
    wykonaj(jobs)
    assert all(not p.bledy for p in w.plany)
    assert [p.ustawienia.cena or p.oferta.cena for p in w.plany] == ["111.11", "999.99"]
    assert [dict(p.ustawienia.wartosci)["kod"] for p in w.plany] == [o.sku, "DRUGI"]
    potwierdzenia = []
    monkeypatch.setattr(
        QMessageBox, "question", lambda *a: potwierdzenia.append(a) or QMessageBox.StandardButton.No
    )
    w.tworz()
    assert "NOWYCH PRODUKTÓW" in potwierdzenia[0][2]
    assert potwierdzenia[0][-1] == QMessageBox.StandardButton.No
    assert "POST" not in nowe_produkty_fixture[1].calls
    assert w.nowy_przycisk.isEnabled()


def test_zbiorowa_kategoria_nie_nadpisuje_dopasowanego_produktu(qtbot, nowe_produkty_fixture):
    o = nowe_produkty_fixture[4]
    w, jobs = panel(qtbot, nowe_produkty_fixture, (o, replace(o, sku="INNY")))
    w.ustawienia[1] = replace(
        w.ustawienia[1], produkt=nowe_produkty_fixture[1].produkt.id, nowy=False
    )
    w._zastosuj_kategorie(0, "123", True)
    wykonaj(jobs)
    assert w.plany[0].ustawienia.nowy
    assert not w.plany[1].ustawienia.nowy
    assert w.plany[1].ustawienia.produkt
