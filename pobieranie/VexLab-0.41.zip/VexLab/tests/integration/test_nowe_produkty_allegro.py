"""Nowy produkt nie wymaga istniejącego UUID; nieznany skutek nie jest ponawiany."""

from copy import deepcopy
from dataclasses import replace

import pytest

from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import NoweSzkiceAllegro, skrot

from .test_nowe_szkice_allegro import Transport, odpowiedz


def test_nowy_produkt_i_szkic_jednym_post_i_odczyt_po_restarcie(nowe_produkty_fixture):
    service, api, repo, s, o, u = nowe_produkty_fixture
    p = service.przygotuj(s, o, u)
    assert not p.bledy and p.produkt.id == ""
    assert service.utworz(s, p, lambda: False).stan == "Utworzono szkic"
    d = api.przeslane
    assert "id" not in d["productSet"][0]["product"]
    assert api.katalog == {
        "name": o.tytul,
        "category": {"id": "123"},
        "parameters": [{"id": "kod", "values": [o.sku]}, {"id": "ean", "values": [o.ean]}],
        "images": d["images"],
    }
    assert d["parameters"] == [{"id": "11323", "valuesIds": ["11323_1"]}]
    assert d["publication"] == {"status": "INACTIVE", "republish": False}
    assert "szukaj" not in api.calls and "produkt" not in api.calls
    assert "nowy-swiezy" in api.calls and "katalog-GET" in api.calls
    restarted = NoweSzkiceAllegro(api, repo, api)
    assert restarted.utworz(s, p, lambda: False).stan == "Utworzono szkic"
    assert api.calls.count("POST") == 1


@pytest.mark.parametrize(
    "zmiany",
    [
        {"zrodla": ()},
        {"kategoria": ""},
        {"zrodla": (("kod", "inne"),)},
        {"zrodla": (("kod", "sku"), ("ean", "ean"))},
    ],
)
def test_braki_kategorii_parametrow_lub_bledny_ean_blokuja_wysylke(nowe_produkty_fixture, zmiany):
    service, api, _, s, o, u = nowe_produkty_fixture
    if zmiany.get("kategoria") == "":
        api.nowy_produkt = lambda *a: (_ for _ in ()).throw(
            BladAllegro("KATEGORIA", "Wybierz kategorię")
        )
    if zmiany.get("zrodla") == (("kod", "sku"), ("ean", "ean")):
        o = replace(o, ean="5901234123458")
    p = service.przygotuj(s, o, replace(u, **zmiany))
    assert p.bledy
    with pytest.raises(BladAllegro):
        service.utworz(s, p, lambda: False)
    assert "POST" not in api.calls and "zdjecie" not in api.calls


@pytest.mark.parametrize("async_mode", [False, True])
def test_202_i_timeout_nowego_produktu_nie_ponawiaja_post(nowe_produkty_fixture, async_mode):
    service, api, _, s, o, u = nowe_produkty_fixture
    api.async_mode = async_mode
    api.awaria = "" if async_mode else "timeout"
    p = service.przygotuj(s, o, u)
    if async_mode:
        assert service.utworz(s, p, lambda: False).stan == "Przetwarzanie"
        api.zakonczona = False
        assert service.utworz(s, p, lambda: False).stan == "Przetwarzanie"
        api.zakonczona = True
        assert service.sprawdz(s, p).stan == "Utworzono szkic"
    else:
        with pytest.raises(BladAllegro):
            service.utworz(s, p, lambda: False)
        assert service.utworz(s, p, lambda: False).stan == "Wymaga sprawdzenia"
    assert api.calls.count("POST") == 1


@pytest.mark.parametrize("blad", ["parametry", "NOT_LISTED", "id", "nazwa"])
def test_niezgodny_lub_nieprzyjety_produkt_nie_jest_sukcesem(nowe_produkty_fixture, blad):
    service, api, _, s, o, u = nowe_produkty_fixture
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    d = next(iter(api.wyniki.values()))
    if blad == "parametry":
        api.katalog["parameters"] = []
    elif blad == "nazwa":
        api.katalog["name"] = "Inny produkt"
    elif blad == "id":
        d["productSet"][0]["product"]["id"] = None
    else:
        d["productSet"][0]["product"]["publication"]["status"] = blad
    with pytest.raises(BladAllegro):
        service.utworz(s, p, lambda: False)
    assert api.calls.count("POST") == 1


def test_stare_odciski_prob_040_pozostaja_zgodne(nowe_szkice_fixture):
    service, _, _, s, o, u = nowe_szkice_fixture
    p = service.przygotuj(s, o, u)
    assert (
        repr(u) == "UstawieniaSzkicu(waluta='PLN', ilosc=1, produkt='', cena='', "
        "wartosci=(('11323', '11323_1'),))"
    )
    assert (
        repr(p.produkt.parametry[0])
        == "ParametrSzkicu(id='11323', nazwa='Stan', typ='dictionary', wymagany=True, "
        "slownik=(('11323_1', 'Nowy'),), produktowy=False)"
    )
    assert service._zrodlo(p) == skrot([repr(o), repr(u), repr(p.produkt)])


def test_kategorie_i_wymagania_z_api_cache_ogranicza_odczyty(nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    t = Transport(
        odpowiedz(
            200,
            {
                "matchingCategories": [
                    {"id": "123", "name": "Lusterka", "parent": {"id": "1", "name": "Motoryzacja"}}
                ]
            },
        ),
        odpowiedz(
            200,
            {
                "id": "123",
                "name": "Lusterka",
                "leaf": True,
                "options": {"productCreationEnabled": True},
            },
        ),
        odpowiedz(
            200,
            {
                "parameters": [
                    {
                        "id": "kod",
                        "name": "Kod producenta",
                        "type": "string",
                        "requiredForProduct": True,
                        "options": {"describesProduct": True},
                    }
                ]
            },
        ),
    )
    api = NoweSzkiceAPI(t)
    assert api.kategorie(s, "Lusterka")[0].nazwa == "Motoryzacja / Lusterka"
    p = api.nowy_produkt(s, "123")
    assert p.parametry[0].wymagany_produkt and p.parametry[0].produktowy
    for _ in range(200):
        assert api.nowy_produkt(s, "123") == p
    assert len(t.calls) == 3


@pytest.mark.parametrize(
    "data",
    [
        {"id": "123", "name": "Kategoria", "leaf": False},
        {
            "id": "123",
            "name": "Kategoria",
            "leaf": True,
            "options": {"productCreationEnabled": False},
        },
    ],
)
def test_kategoria_nielisciowa_lub_zakaz_tworzenia(nowe_szkice_fixture, data):
    api = NoweSzkiceAPI(Transport(odpowiedz(200, data)))
    with pytest.raises(BladAllegro):
        api.nowy_produkt(nowe_szkice_fixture[3], "123")


def test_potwierdzenie_katalogu_weryfikuje_uuid_nazwe_kategorie_i_parametry(nowe_szkice_fixture):
    _, fake, _, s, o, _ = nowe_szkice_fixture
    d = {
        "id": fake.produkt.id,
        "name": o.tytul,
        "category": {"id": "123"},
        "parameters": [{"id": "kod", "values": [o.sku]}],
    }
    cases = [d, {**d, "name": "Inny"}, {**d, "category": {"id": "999"}}, {**d, "parameters": []}]
    api = NoweSzkiceAPI(Transport(*(odpowiedz(200, c) for c in cases)))
    args = (s, fake.produkt.id, o.tytul, "123", d["parameters"])
    assert api.potwierdz_nowy(*args)
    assert not any(api.potwierdz_nowy(*args) for _ in range(3))


@pytest.mark.parametrize("blad", ["ACTIVE", "id", "extra", "category", "images", "schedule", None])
def test_transport_dopuszcza_tylko_jawna_definicje_i_inactive(monkeypatch, blad):
    from vexlab.adaptery import allegro_http

    product = {
        "name": "Testowy produkt do motocykla",
        "category": {"id": "123"},
        "parameters": [],
        "images": ["https://a.allegroimg.com/test.jpg"],
    }
    d = {
        "publication": {"status": "INACTIVE", "republish": False},
        "productSet": [{"product": product}],
    }
    if blad == "ACTIVE":
        d["publication"]["status"] = "ACTIVE"
    elif blad == "schedule":
        d["publication"]["startingAt"] = "later"
    elif blad == "id":
        product["id"] = "c9e39cae-9cb6-11e9-a2a3-2a2ae2dbcce4"
    elif blad == "extra":
        product["other"] = True
    elif blad == "category":
        product["category"] = {"id": "../bad"}
    elif blad == "images":
        product["images"] = []
    reached = []

    def opener(*args):
        reached.append(True)
        raise BladAllegro("TEST", "Przejście do transportu")

    monkeypatch.setattr(allegro_http, "build_opener", opener)
    import json

    with pytest.raises(BladAllegro):
        allegro_http.HTTPSAllegro().wyslij(
            "POST",
            "https://api.allegro.pl/sale/product-offers",
            {},
            json.dumps(deepcopy(d)).encode(),
        )
    assert bool(reached) == (blad is None)


def test_definicja_produktu_przechodzi_przez_rzeczywisty_mapper_api(nowe_szkice_fixture):
    import json

    _, fake, repo, sesja, o, u = nowe_szkice_fixture

    class Kanal:
        def __init__(self):
            self.calls = []
            self.dane = None

        def wyslij(self, metoda, url, naglowki, dane):
            self.calls.append((metoda, url))
            if url.endswith("/sale/categories/123"):
                return odpowiedz(200, {"id": "123", "name": "Części", "leaf": True})
            if url.endswith("/parameters"):
                return odpowiedz(
                    200,
                    {
                        "parameters": [
                            {
                                "id": "kod",
                                "name": "Kod producenta",
                                "type": "string",
                                "requiredForProduct": True,
                                "options": {"describesProduct": True},
                            },
                        ]
                    },
                )
            if url.endswith("/sale/images"):
                return odpowiedz(201, {"location": "https://a.allegroimg.com/obraz.jpg"})
            if "/sale/offers?" in url:
                return odpowiedz(200, {"offers": [], "totalCount": 0})
            if metoda == "POST":
                self.dane = json.loads(dane)
                return odpowiedz(201, {"id": "12345678"})
            if url.endswith("/sale/product-offers/12345678"):
                return odpowiedz(
                    200,
                    {
                        **self.dane,
                        "id": "12345678",
                        "productSet": [
                            {
                                "product": {
                                    "id": fake.produkt.id,
                                    "publication": {"status": "PROPOSED"},
                                }
                            }
                        ],
                    },
                )
            if url.endswith("/sale/products/" + fake.produkt.id):
                return odpowiedz(
                    200, {"id": fake.produkt.id, **self.dane["productSet"][0]["product"]}
                )
            pytest.fail("Nieprzewidziane żądanie: " + url)

    kanal = Kanal()
    service = NoweSzkiceAllegro(NoweSzkiceAPI(kanal), repo, fake)
    p = service.przygotuj(
        sesja, replace(o, ean=""), replace(u, nowy=True, kategoria="123", zrodla=(("kod", "sku"),))
    )
    assert not p.bledy
    assert service.utworz(sesja, p, lambda: False).stan == "Utworzono szkic"
    assert kanal.dane["productSet"][0]["product"]["parameters"] == [
        {"id": "kod", "values": [o.sku]}
    ]
    assert sum(m == "POST" and url.endswith("/sale/product-offers") for m, url in kanal.calls) == 1
