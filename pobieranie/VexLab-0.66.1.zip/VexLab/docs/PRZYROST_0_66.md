# VexLab 0.66 — własny układ cennika

W Nowy cennik wybierz plik. W sekcji Własne pola cennika kliknij
„+ Dodaj pole”, wpisz własną nazwę i wskaż kolumnę z pliku. Możesz np.
samodzielnie dodać „Model wydechu” oraz „Motocykl”. Nazwę produktu nadal
wybierasz niezależnie w polu Nazwa. Pola nie są scalane z nazwą lub opisem.

Wybierz Profil → Zapamiętaj układ… i nadaj mu własną nazwę, np. „Wydechy”.
Profil zapisuje się w danych użytkownika, w podfolderze profile_cennikow.
Przy zgodnej strukturze następnego pliku będzie dostępny na liście profili.
Nie ma wbudowanych producentów, typów produktów ani profilu Wydechy.
Możesz tworzyć inne układy i nazwy pól, usuwać pola oraz mapować je osobno.

Po sprawdzeniu danych własne pola zobaczysz w osobnych kolumnach podglądu,
a po Zapisz cennik — w tabeli zachowanego dokumentu. Kolumny mogą wymagać
przewinięcia tabeli w prawo. Wartości pozostają w bazie użytkownika także
po restarcie. Starsze cenniki i profile działają jak wcześniej.

To pola dokumentu cennika: nie tworzą automatycznie dopasowania motocykla,
nie zmieniają modelu Produktu i nie są wysyłane do Allegro. Dodanie pozycji
do katalogu pozostawia te pola w źródłowym cenniku. Do 20 pól własnych.
PrestaShop/Subiekt bez zmian. Testy na syntetycznych danych, GUI Linux offscreen.
