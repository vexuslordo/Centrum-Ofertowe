# ADR-084 — utworzenie szkicu a potwierdzenie jego ustawień

Status: polecenie właściciela 2026-11-17. Oferta i ustawienia istnieją w Allegro,
ale komunikat KONFLIKT GPSR sugeruje nieudaną wysyłkę.

Potwierdzone 201 lub zakończone 202 oraz zgodny odczyt ID/core INACTIVE
potwierdzają utworzenie szkicu. Niepotwierdzone GPSR/dostawa/warunki/VAT
otrzymują wynik „Utworzono — sprawdź ustawienia”, z ID i nazwami konkretnych
pól. Wynik wliczany do zapisanych, z osobnym licznikiem ustawień do sprawdzenia;
nie potwierdza kompletności do sprzedaży. Nie wstrzymuje kolejnych pozycji.
Jawne błędy validation Allegro zachowują pierwszeństwo Szkic do poprawy.
Brak akceptacji żądania albo niezgodność ID/core nadal pozostaje niepewnym
wynikiem/konfliktem i blokuje dalszą serię oraz ponowny POST.

Przy nowym wyniku przycisk tworzenia wyłączony dla tej pozycji; dostępny
odczyt wyniku. Trwały rejestr nadal gwarantuje brak powtórnego POST po
restarcie. Lokalny Produkt może otrzymać potwierdzone powiązanie z ID oferty.

Porównanie ustawień akceptuje UUID różniące się wielkością liter,
równe czasy dni/godzin/minut/sekund ISO bez miesięcy/lat, NFC i CRLF/LF
w informacjach bezpieczeństwa oraz pusty opcjonalny odnośnik zamiast null.
Nie ignoruje innego ID, zmienionej treści, brakujących wymaganych pól ani
obcej gwarancji/osoby. Brak danych nie oznacza zgodności. Raport nie
umieszcza pełnej treści instrukcji lub danych adresowych w komunikacie.
Schemat 12 i format trwałego rejestru pozostają bez zmian.
