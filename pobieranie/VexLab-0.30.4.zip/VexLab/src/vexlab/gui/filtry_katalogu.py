"""Skróty producentów, wyszukiwanie i jawne filtry wspólnego katalogu."""

from collections import Counter

from PySide6.QtCore import QEvent, QSize, Qt, Signal
from PySide6.QtGui import QPalette, QResizeEvent
from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QComboBox,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QLayout,
    QLineEdit,
    QMenu,
    QPushButton,
    QToolButton,
    QVBoxLayout,
    QWidget,
    QWidgetAction,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.katalog import nazwa_wyboru_producenta
from vexlab.przypadki_uzycia.producenci import ProducentDTO


class FiltryKatalogu(QWidget):
    producent = Signal(str)
    fraza = Signal(str)
    filtry = Signal(object, object)
    reset = Signal()
    tryb = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self.wariant_ukladu = -1
        self.producenci: tuple[ProducentDTO, ...] = ()
        self.uklad = QGridLayout(self)
        self.uklad.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.uklad.setContentsMargins(0, 0, 0, 0)
        self.uklad.setSpacing(8)
        self.pasek_producentow = QWidget()
        self.pasek_producentow.setFixedHeight(44)
        self.wybor_producenta = "wszyscy"
        brands = self.pasek_producentow
        brands.setObjectName("filtryProducentow")
        chips = QHBoxLayout(brands)
        chips.setContentsMargins(0, 0, 0, 0)
        chips.setSpacing(6)
        self.grupa = QButtonGroup(self)
        self.przyciski: dict[str, QPushButton] = {}
        self.chips = chips
        wszystkie = QPushButton("Wszystkie")
        wszystkie.setProperty("chipProducenta", True)
        wszystkie.setCheckable(True)
        wszystkie.setAccessibleName("Wszyscy producenci")
        self.grupa.addButton(wszystkie)
        self.przyciski["wszyscy"] = wszystkie
        chips.addWidget(wszystkie)
        wszystkie.clicked.connect(lambda: self.producent.emit("wszyscy"))
        self.wiecej = QToolButton()
        self.wiecej.setObjectName("menuAkcji")
        self.wiecej.setText("Więcej")
        self.wiecej.setAccessibleName("Pozostali producenci")
        self.wiecej.setCheckable(True)
        self.wiecej.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.menu_producentow = QMenu(self.wiecej)
        self.wiecej.setMenu(self.menu_producentow)
        chips.addWidget(self.wiecej)
        chips.addStretch()
        self.narzedzia = QWidget()
        tools = QHBoxLayout(self.narzedzia)
        tools.setContentsMargins(0, 0, 0, 0)
        tools.setSpacing(6)
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj…")
        self.szukaj.setAccessibleName("Szukaj produktów po nazwie, SKU lub EAN")
        self.szukaj.setClearButtonEnabled(True)
        self.szukaj.setFixedSize(186, 36)
        self.szukaj.textChanged.connect(self.fraza.emit)
        tools.addWidget(self.szukaj, 1)
        self.przycisk_filtrow = QToolButton()
        self.przycisk_filtrow.setCheckable(True)
        self.przycisk_filtrow.setAccessibleName("Dodatkowe filtry katalogu")
        self.przycisk_filtrow.setToolTip("Filtruj po zdjęciu i cenie")
        self.przycisk_filtrow.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.menu_filtrow = QMenu(self.przycisk_filtrow)
        self.przycisk_filtrow.setMenu(self.menu_filtrow)
        form_widget = QWidget()
        form_layout = QVBoxLayout(form_widget)
        form = QFormLayout()
        self.zdjecia = QComboBox()
        self.cena = QComboBox()
        for combo, opis in ((self.zdjecia, "zdjęcia"), (self.cena, "ceny")):
            for text, value in (("Wszystkie", None), (f"Z {opis}", True), (f"Bez {opis}", False)):
                combo.addItem(text, value)
        self.zdjecia.setItemText(1, "Ze zdjęciem")
        self.zdjecia.setItemText(2, "Bez zdjęcia")
        self.cena.setItemText(1, "Z ceną")
        self.cena.setItemText(2, "Bez ceny")
        form.addRow("Zdjęcia", self.zdjecia)
        form.addRow("Cena", self.cena)
        form_layout.addLayout(form)
        apply = QPushButton("Zastosuj")
        apply.setObjectName("primary")
        apply.clicked.connect(self._zastosuj)
        form_layout.addWidget(apply)
        a = QWidgetAction(self.menu_filtrow)
        a.setDefaultWidget(form_widget)
        self.menu_filtrow.addAction(a)
        self.menu_filtrow.addAction("Wyczyść wszystkie filtry", self.reset.emit)
        tools.addWidget(self.przycisk_filtrow)
        self.przycisk_filtrow.setFixedSize(36, 36)
        self.przycisk_filtrow.setProperty("kompaktowyFiltr", True)
        self.tryby = QButtonGroup(self)
        self.kafelki = QToolButton()
        self.lista = QToolButton()
        for przelacznik, nazwa in ((self.kafelki, "kafelki"), (self.lista, "lista")):
            przelacznik.setCheckable(True)
            przelacznik.setFixedSize(36, 36)
            przelacznik.setProperty("kompaktowyFiltr", True)
            przelacznik.setAccessibleName(f"Widok: {nazwa}")
            przelacznik.setToolTip(f"Widok: {nazwa}")
            self.tryby.addButton(przelacznik)
            przelacznik.clicked.connect(lambda checked=False, n=nazwa: self.tryb.emit(n))
            tools.addWidget(przelacznik)
        self.lista.setChecked(True)
        self._ikony()
        self.ustaw((), "wszyscy", "", None, None)
        self._rozmiesc()

    def _ikony(self) -> None:
        dark = QApplication.palette().color(QPalette.ColorRole.Window).lightness() < 128
        kolor = "#B7C9E0" if dark else "#355273"
        for b, n in (
            (self.przycisk_filtrow, "filtr"),
            (self.kafelki, "widok_kafelki"),
            (self.lista, "widok_lista"),
        ):
            b.setIcon(ikona(n, kolor))
            b.setIconSize(QSize(18, 18))
        if not hasattr(self, "ikona_szukania"):
            self.ikona_szukania = self.szukaj.addAction(
                ikona("szukaj", kolor), QLineEdit.ActionPosition.LeadingPosition
            )
        else:
            self.ikona_szukania.setIcon(ikona("szukaj", kolor))

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() in (
            QEvent.Type.PaletteChange,
            QEvent.Type.ApplicationPaletteChange,
        ) and hasattr(self, "lista"):
            self._ikony()

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        self._rozmiesc()

    def _rozmiesc(self) -> None:
        buttons = (*self.przyciski.values(), self.wiecej)
        for b in buttons:
            b.ensurePolished()
        base = self.przyciski["wszyscy"].sizeHint().width() + self.wiecej.sizeHint().width() + 6
        miejsce = self.width() - self.narzedzia.sizeHint().width() - 16
        wariant = int(miejsce >= base)
        if not wariant:
            miejsce = self.width()
        szerokosc = base
        for ident, b in self.przyciski.items():
            if ident == "wszyscy":
                continue
            potrzebne = b.sizeHint().width() + 6
            miesci_sie = szerokosc + potrzebne <= miejsce
            b.setVisible(miesci_sie)
            if miesci_sie:
                szerokosc += potrzebne
        self.pasek_producentow.setFixedWidth(szerokosc)
        self._odswiez_menu_producentow()
        if wariant == self.wariant_ukladu:
            return
        self.wariant_ukladu = wariant
        self.uklad.removeWidget(self.pasek_producentow)
        self.uklad.removeWidget(self.narzedzia)
        if wariant:
            self.uklad.addWidget(self.pasek_producentow, 0, 0, Qt.AlignmentFlag.AlignVCenter)
            self.uklad.addWidget(self.narzedzia, 0, 2, Qt.AlignmentFlag.AlignRight)
        else:
            self.uklad.addWidget(self.pasek_producentow, 0, 0, 1, 3, Qt.AlignmentFlag.AlignLeft)
            self.uklad.addWidget(self.narzedzia, 1, 0, 1, 3, Qt.AlignmentFlag.AlignRight)
        self.uklad.setColumnStretch(0, 0)
        self.uklad.setColumnStretch(1, 1)
        self.uklad.setColumnStretch(2, 0)

    def _zastosuj(self) -> None:
        self.filtry.emit(self.zdjecia.currentData(), self.cena.currentData())
        self.menu_filtrow.hide()

    def ustaw(
        self,
        producenci: tuple[ProducentDTO, ...],
        wybor: str,
        fraza: str,
        zdjecia: bool | None,
        cena: bool | None,
    ) -> None:
        nazwy = Counter(p.nazwa.casefold() for p in producenci)
        if self.producenci != producenci:
            for ident, b in tuple(self.przyciski.items()):
                if ident != "wszyscy":
                    self.grupa.removeButton(b)
                    self.chips.removeWidget(b)
                    b.deleteLater()
                    del self.przyciski[ident]
            for i, producent in enumerate(producenci[:5]):
                ident = str(producent.id)
                b = QPushButton(nazwa_wyboru_producenta(producent, nazwy))
                b.setProperty("chipProducenta", True)
                b.setCheckable(True)
                b.setAccessibleName(f"Producent: {producent.nazwa}")
                b.setToolTip(producent.nazwa + (" (nieaktywny)" if not producent.aktywny else ""))
                b.clicked.connect(lambda checked=False, pid=ident: self.producent.emit(pid))
                self.grupa.addButton(b)
                self.przyciski[ident] = b
                self.chips.insertWidget(i + 1, b)
            self.producenci = producenci
        self.grupa.setExclusive(False)
        for ident, b in self.przyciski.items():
            b.setChecked(ident == wybor)
        self.grupa.setExclusive(True)
        self.wybor_producenta = wybor
        self.szukaj.blockSignals(True)
        self.szukaj.setText(fraza)
        self.szukaj.blockSignals(False)
        for combo, value in ((self.zdjecia, zdjecia), (self.cena, cena)):
            combo.setCurrentIndex(combo.findData(value))
        self.przycisk_filtrow.setChecked(zdjecia is not None or cena is not None)
        self._rozmiesc()

    def _odswiez_menu_producentow(self) -> None:
        nazwy = Counter(p.nazwa.casefold() for p in self.producenci)
        ukryci = tuple(
            p
            for p in self.producenci
            if str(p.id) not in self.przyciski or self.przyciski[str(p.id)].isHidden()
        )
        self.wiecej.setChecked(
            self.wybor_producenta == "brak"
            or any(str(p.id) == self.wybor_producenta for p in ukryci)
        )
        self.menu_producentow.clear()
        for tekst, ident in (
            ("Wszyscy producenci", "wszyscy"),
            ("Bez producenta", "brak"),
            *((nazwa_wyboru_producenta(p, nazwy), str(p.id)) for p in ukryci),
        ):
            a = self.menu_producentow.addAction(tekst)
            a.setCheckable(True)
            a.setChecked(ident == self.wybor_producenta)
            a.triggered.connect(lambda checked=False, pid=ident: self.producent.emit(pid))
