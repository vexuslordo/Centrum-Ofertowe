# Poprawka 0.74.3 — dostawa bez logotypów

Na wyraźne polecenie właściciela wycofano znaki przewoźników w karcie Dostawa.
Przywrócono dokładnie panel zamówienia z wersji 0.74: podpis i nazwę metody
z rzeczywistych danych Allegro, bez dodatkowego wiersza z logo.

Usunięto niewykorzystywany komponent rozpoznawania znaków, jego testy i dodane
w 0.74.1 zasoby przewoźników. Istniejące znaki Allegro i PrestaShop w programie
pozostały bez zmian. Pozostałe poprawki 0.74.1–0.74.2 zachowano, w tym odstępy
walidacji i usunięcie panelu pod tabelą. Bez zmian API, logiki i danych.

Sprawdzenie: istniejące testy panelu i widoku zamówień, statyczne kontrole,
świeżo rozpakowany ZIP. Ręczny odbiór Windows/DPI pozostaje do wykonania.
