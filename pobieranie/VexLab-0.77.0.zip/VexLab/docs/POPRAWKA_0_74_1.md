# Poprawka 0.74.1 — uporządkowane panele i znaki dostaw

## Przygotowanie ofert

Lewy panel ma trzy uporządkowane sekcje z numerami, równymi marginesami,
polami 32 px i wyrównaną kolumną statusów. Zapis lokalny jest informacją,
a nie nieaktywnym polem wyboru; nadal jest wymagany w dotychczasowej konfiguracji.
Przyciski i pola mają niebieskie najechanie i widoczny fokus. Nieaktywne akcje
pozostają przygaszone. Nie zmieniono komend ani ich warunków dostępności.

Prawy panel ma wyrównane etykiety i czytelne wyniki kontroli: OK, Sprawdź,
Nie sprawdzono lub Nie dotyczy. Nieznane dane nie oznaczają sukcesu.
Przycisk Wskazówki przygotowania usunięto z panelu szczegółów. Na wyraźne polecenie właściciela nie ma też dodatkowej sekcji pod tabelą.
Pełne powody i wskazówki pozostają w istniejących Szczegółach wysyłki,
bez zmniejszania wysokości listy. Stopka wysyłki bez zmian.

## Cenniki

Panel szczegółów ma jednolite, jaśniejsze granatowo-szare tło i wydzielone
podsumowanie. Usunięto osobne ciemne tło przewijanego wnętrza. W pustym stanie
jest jeden komunikat zamiast pustego zdjęcia i rzędów myślników. Dane pojawiają
się po wyborze pozycji; akcje zachowują istniejące warunki i zakres wyboru.
Pozostają pełny opis, cena bazowa, historia wydań, źródło i dodatkowe pola.

## Dostawa zamówienia

Lokalne znaki InPost, DPD, DHL, UPS, FedEx, ORLEN Paczka oraz Allegro One
w karcie Dostawa. Rozpoznanie wyłącznie po nazwie metody z bieżącego zamówienia;
nieznana firma otrzymuje neutralną ikonę paczki. Zmiana/wyczyszczenie wyboru
usuwa poprzedni znak. Brak sieci podczas wyświetlania i brak nowych zapisów API.
Źródła i adaptacje: src/vexlab/gui/zasoby/przewoznicy/ZRODLA.md.

## Weryfikacja

Testy paneli, rozpoznania dostaw i rzeczywistych lokalnych SVG, pełne kontrole
projektu w osobnych procesach GUI, oba motywy i cztery rozdzielczości. Sprawdzono
renderowaną zmianę koloru przy najechaniu. Ręczny odbiór na Windows/DPI pozostaje
do wykonania. Brak zmian przypadków użycia, API, schematu i danych użytkownika.
