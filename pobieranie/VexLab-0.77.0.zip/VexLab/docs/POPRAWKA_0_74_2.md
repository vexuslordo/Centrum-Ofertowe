# Poprawka 0.74.2 — marginesy walidacji

Na polecenie właściciela poprawiono odstępy w prawym panelu przygotowania ofert.
Treść przewijana ma własny prawy margines 14 px, a walidacja dodatkowe marginesy
wewnętrzne. Wyniki są wyrównane do początku jednej kolumny zamiast do samej
krawędzi przewijania. Wiersze mają pionowe odstępy i wewnętrzne odsunięcie tekstu.

Usunięto redundantne podpowiedzi, które powtarzały widoczne „Nie sprawdzono”.
Podpowiedzi z dodatkowymi informacjami pozostają. Treść, kolory i reguły statusów
oraz funkcje bez zmian. Nie przywrócono panelu pod tabelą. Sprawdzenie obejmuje
oba motywy, cztery rozdzielczości i istniejące testy GUI. Ręczny odbiór na Windows
pozostaje do wykonania.
