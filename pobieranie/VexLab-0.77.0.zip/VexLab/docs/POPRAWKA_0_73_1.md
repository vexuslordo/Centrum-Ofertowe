# Poprawka 0.73.1 — panele przygotowania ofert

Na polecenie właściciela dopracowano lewy panel ustawień i akcji masowych,
prawy panel produktu oraz poziomą stopkę postępu według dostarczonych zbliżeń.
Zachowano dotychczasowe obiekty przycisków i warunki dostępności. Na węższym
obszarze akcje stopki przechodzą do drugiego wiersza. Panele pozostają przewijane.

Prawy panel zawiera zdjęcie, nazwę, status, zwarte pola i wyniki kontroli.
Cztery przyciski: edycja wybranej pozycji, istniejący lokalny podgląd Allegro,
historia poprzedniego i aktualnego wyniku bieżącej sesji oraz strona producenta.
Historia jest dostępna tylko dla zachowanych wyników sesji; nie jest pełną
trwałą historią produktu. Adres producenta pochodzi wyłącznie z jednoznacznego
aktywnego wpisu użytkownika; brak poprawnego HTTP(S) wyłącza przycisk.
Podgląd nie otwiera nieistniejącej publicznej strony szkicu.

Netto prezentowane jest tylko przy jawnej stawce PL w aktualnych ustawieniach.
Brak stawki oznacza „—”; nie przyjmujemy domyślnie 23%. Widok nie zmienia cen.
Niezaimplementowane masowe zdjęcia i masowa zmiana kategorii są oznaczone
jako niedostępne z wyjaśnieniem. Nie uruchamiają zastępczej operacji.
Pozostałe istniejące akcje pozostają w panelach lub menu Więcej działań.

Zmiany obejmują prezentację GUI. API, przypadki użycia serii, zapis katalogu,
struktury danych, ochrona przed duplikacją i kontynuacja po błędzie SKU bez zmian.

Weryfikacja: testy GUI i statyczne kontrole projektu; renderowanie obu motywów
przy 1366×768, 1920×1080, 2560×1440 i 3440×1440. Pełny zestaw uruchamiany
z --osobne-procesy-gui z powodu opisanego w 0.73 błędu Qt w jednym procesie.
Nie wykonano rzeczywistych zapisów Allegro ani ręcznego odbioru na Windows/DPI.
