# VexLab 0.70.1 — co zrobić, aby oferta została przesłana

Polecenie właściciela 2026-11-20: przy niewysłanej ofercie i błędzie pokazać
pełny powód oraz konkretne dalsze kroki. Wyłącznie prezentacja i nawigacja
w istniejącym procesie przygotowania Allegro; bez zmian API, modeli, rejestru
prób, reguł gotowości lub potwierdzania zapisu.

## Widoczne wskazówki

Pod tabelą jest stały panel. Po lewej pełny, kopiowalny komunikat, po prawej
oddzielnie instrukcja „Co zrobić i gdzie poprawić”. Długi błąd nie zasłania
instrukcji: oba pola przewijają się niezależnie, treść nie jest obcinana.
Po wybraniu wiersza panel dotyczy tego wiersza. Bez wyboru pierwszeństwo ma
widoczna oferta wymagająca uwagi, a dopiero potem gotowa lub już zapisana.
Filtrowanie nie pozostawia akcji dla ukrytego wiersza.

Przycisk we wskazówce otwiera istniejącą poprawkę, kontrolę paczki, kontrolę
wyniku lub sprawdzenie blokady. Wybiera wskazany wiersz, jeśli nie jest już
zaznaczony. Jeśli jest częścią zaznaczenia wielu ofert, zachowuje ten wybór.
Dotychczasowe sprawdzanie edytowalności nadal chroni całą grupę. Wysłanie
zawsze przechodzi przez istniejące podsumowanie i potwierdzenie z domyślnym Nie.
Samo wyświetlenie wskazówki nie wykonuje odczytu API ani zapisu oferty.

Instrukcje obejmują:

- nieprzeprowadzone sprawdzenie lub niewysłaną pozycję — Sprawdź paczkę,
  popraw braki, dopiero potem utwórz szkice;
- tytuł, cenę i ilość — Edytuj dane lub Popraw wybrane;
- parametry/numer katalogowy — właściwy formularz parametrów i wartość
  wskazaną przez Allegro, jeśli wystąpiła w komunikacie;
- GPSR, dostawę i warunki — istniejący formularz sprzedaży;
- EAN/dopasowanie — Wybierz produkt Allegro;
- zdjęcia/opis — popraw źródłową ofertę/paczkę i wczytaj ponownie, ponieważ
  dotychczasowa edycja tytułu/ceny nie edytuje tych pól;
- brak lokalnego producenta przy wymaganym zapisie katalogowym — wskazuje
  pole Producent lokalny i pozwala przejść do niego fokusem;
- HTTP 401/403 — połączenie i zgoda na zapis w Ustawienia → Integracje → Allegro;
- HTTP 429 — odczekanie zgodnie z komunikatem i kontrola poprzedniego wyniku;
- blokadę innej wersji danych — istniejące Sprawdź blokadę i ponów;
- nieznany wynik/przetwarzanie — sprawdzenie wyniku przed kolejnym tworzeniem;
- już zapisaną ofertę — odnalezienie po ID/SKU w Allegro, bez ponownego tworzenia.

To wskazówki na podstawie źródłowego statusu i tekstu błędu, nie nowa walidacja.
Nieznana przyczyna pozostawia pełny komunikat oraz ogólną instrukcję, bez
zgadywania wymaganych wartości. Status/ID chronione mają pierwszeństwo przed
rozpoznawaniem słów w błędzie. Niespójny wynik z ID nie otrzymuje zalecenia
utworzenia nowej oferty.

## Gotowość a zapis

Samotny zielony znak zastępuje znak z tekstem **Gotowa do wysłania / Jeszcze
nie wysłano**. To tylko wynik przygotowania. Podczas operacji tekst zmienia się
na **Gotowość sprawdzona / Trwa operacja — poczekaj**. Po błędzie całej operacji,
gdy pozostał wcześniejszy wynik gotowości, pokazuje **Sprawdź wynik operacji**:
nie twierdzimy, że żądanie nie zostało wysłane.

Błąd całej operacji jest osobno pokazany w panelu, bez przypisywania go jako
nowego wyniku biznesowego każdej ofercie. Akcje nie działają podczas operacji
ani po zmianie sesji. Raport i stany natywne zachowują oryginalne wartości.

## Szczegóły wysyłki

Raport otrzymał osobne kolumny **Pełny powód** i **Co zrobić / gdzie poprawić**.
Podpowiedź w kolumnie wyniku również zawiera instrukcję. Pełny tekst i zalecenia
pozostają dostępne w szczegółach oraz w istniejącym formularzu poprawiania.
Dotychczasowy eksport raportu, filtry, zaznaczanie i kontrole ponowienia działają
jak wcześniej. Szkic i uruchomienie sprzedaży nadal są osobnymi działaniami.

Testy: pełne długie komunikaty, właściwy wiersz i grupa, priorytet błędów,
blokady wyników nieznanych/istniejących ID, powrót do lokalnego producenta,
stan trwającej operacji, błąd globalny i zmiana sesji oraz zachowanie potwierdzenia.
Syntetyczne podglądy obu motywów: `scripts/capture_pomoc_wysylki_0701.py`.
Brak prawdziwych żądań tworzenia w testach i brak danych demonstracyjnych na starcie.
