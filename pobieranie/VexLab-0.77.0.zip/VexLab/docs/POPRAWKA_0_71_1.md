# 0.71.1 — przygotowanie szkiców do wysyłki

Polecenie właściciela z 20.11.2026: z widoku paczki ma być jasny dostęp do
przygotowania szkiców i uzupełniania danych przed wysyłką.

Dotychczasowy przycisk już otwierał przygotowanie całej paczki, jednak dopisek
„gotowe: 0” sugerował, że nie można go użyć przed pierwszą walidacją.

- Główna akcja: **Przygotuj szkice do wysyłki…**, bez mylącego zera w przycisku.
- Po otwarciu przygotowania: **Wróć do przygotowania szkiców…**.
- Panel walidacji ma dodatkowy przycisk **Ustawienia i przygotowanie szkiców…**,
  otwierający tę samą istniejącą akcję dla całej paczki.
- Nad tabelą podano kolejny krok: uzupełnij ustawienia i kliknij Sprawdź paczkę.
- Dotychczasowy zapis lokalny ma podpis **Zapisz szkice lokalnie**.
- Przy pierwszym otwarciu przygotowanie jest pokazywane i aktywowane tak samo
  jak przy powrocie do niego. Istniejące okno jest wykorzystywane ponownie.

## Jak przygotować oferty

1. Wczytaj paczkę ZIP i wybierz Przygotuj szkice do wysyłki.
2. W istniejącym oknie ustaw walutę, ilość, producenta lokalnego oraz dane Allegro:
   produkt/dopasowanie, parametry, GPSR/dostawę/warunki i VAT według potrzeb.
3. Kliknij Sprawdź paczkę. Popraw pozycje według podanych przyczyn i wskazówek.
4. Wybierz istniejącą akcję tworzenia gotowych szkiców i potwierdź zakres oraz konto.
   Powstaną szkice; uruchomienie sprzedaży pozostaje osobną akcją.

Zero gotowych przed kontrolą nie blokuje otwarcia ustawień. Filtry nadal
zmieniają tylko widok. Nie zmieniono API, modeli, serwisów, walidacji, potwierdzeń,
obsługi duplikatów ani niepewnych wyników. Nie dodano automatycznej wysyłki.
Nie pomija się wymaganego połączenia konta ani trwającego odczytu/zapisu paczki.

Regresja GUI przechodzi od paczki z zerem gotowych przez otwarcie istniejącego
okna, ustawienia i sprawdzenie do powrotu do tego samego okna. Żaden z tych
kroków nie wykonuje POST. Testy używają izolowanego portu testowego.
