# Poprawka 0.73.2 — zwarte statusy stopki

Poprawiono przydział wolnego miejsca w siatce stopki. Grupa czterech statusów
ma naturalną szerokość, równe odstępy 6 px i jest wyrównana do lewej obok
bloku postępu (330 px). Wolne miejsce oddziela całą grupę od akcji po prawej,
zamiast rozsuwać poszczególne statusy. Na wąskim obszarze akcje nadal mogą
przejść do drugiego wiersza. Komunikat o wczytaniu ZIP jest nad tabelą.

Wyłącznie geometria widoku: bez zmian obliczeń, API, komend i zakresu wysyłki.
Sprawdzenie: oba motywy i cztery rozdzielczości, testy istniejącej tabeli,
osadzonego przygotowania i panelu walidacji; statyczne kontrole projektu.
Ręczny odbiór na Windows nie został wykonany.

Lewy panel ma pola o wysokości 28 px, mniejsze odstępy między sekcjami
i kolejność waluta → producent → ilość. Pełne opisy skróconych przycisków
pozostają w podpowiedziach. Statusy i wartości nadal są rzeczywiste.
