"""Przebieg serii: osobny wynik SKU, bez ponawiania niepewnego zapisu."""

import re
from collections.abc import Callable
from dataclasses import dataclass, replace

from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.duplikaty_allegro import SprawdzDuplikatyAllegro, opis_duplikatow
from vexlab.przypadki_uzycia.katalog_uzytkownika import KatalogUzytkownika
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    USTAWIENIA_DO_SPRAWDZENIA,
    NoweSzkiceAllegro,
    PlanNowegoSzkicu,
    WynikTworzenia,
)
from vexlab.rdzen.kontrakty import BladTechniczny

ZAPISANE = frozenset(
    {
        "Utworzono szkic",
        "Szkic kompletny",
        "Szkic do poprawy",
        USTAWIENIA_DO_SPRAWDZENIA,
    }
)


def zatrzymuje_serie(blad: BladAllegro) -> bool:
    """Awaria wspólnego dostępu lub trwałości; nie błąd danych pojedynczej oferty."""
    if blad.kod in {
        "WYGASLA",
        "AUTORYZACJA",
        "UPRAWNIENIA",
        "LIMIT",
        "SIEC",
        "NIEZNANY",
        "REJESTR",
        "KONTO",
    }:
        return True
    statuses = (int(code) for code in re.findall(r"\bHTTP\s+(\d{3})\b", str(blad)))
    return any(code in {401, 403, 429} or code >= 500 for code in statuses)


def kategoria_bledu(blad: BladAllegro) -> str:
    if blad.kod == "ODRZUCONO":
        return "Odrzucono"
    if blad.kod in {"PLAN", "WALIDACJA", "PRODUKT", "PARAMETRY", "ZDJECIE", "GPSR", "VAT"}:
        return "Do poprawy"
    return "Wymaga sprawdzenia"


@dataclass(frozen=True)
class ZlecenieSeriiSzkicow:
    sesja: SesjaAllegro
    plany: tuple[PlanNowegoSzkicu, ...]
    indeksy: tuple[int, ...]
    poprzednie: tuple[WynikTworzenia, ...]
    do_utworzenia: frozenset[int]
    producent: str
    sprawdzenie: bool


@dataclass(frozen=True)
class ObserwatorSeriiSzkicow:
    stop: Callable[[], bool]
    nieaktualne: Callable[[], bool]
    postep: Callable[[int, str], None]
    lokalny_komunikat: Callable[[str], None]
    katalog_zmieniony: Callable[[], None]


class WyslijSerieSzkicow:
    def __init__(
        self,
        serwis: NoweSzkiceAllegro,
        katalog: KatalogUzytkownika | None,
        duplikaty: SprawdzDuplikatyAllegro | None,
    ) -> None:
        self.serwis, self.katalog, self.duplikaty = serwis, katalog, duplikaty

    def _katalog(
        self,
        z: ZlecenieSeriiSzkicow,
        o: ObserwatorSeriiSzkicow,
    ) -> dict[str, str]:
        if self.katalog is None or z.sprawdzenie or not z.do_utworzenia:
            return {}
        plany = tuple(p for i, p in enumerate(z.plany) if i in z.do_utworzenia)
        report, problemy = self.katalog.z_ofert_czesciowo(plany, z.producent, o.stop, o.postep)
        if report is not None:
            o.lokalny_komunikat(report.tekst)
            o.katalog_zmieniony()
        return dict(problemy)

    def _oferta(
        self,
        z: ZlecenieSeriiSzkicow,
        p: PlanNowegoSzkicu,
        o: ObserwatorSeriiSzkicow,
    ) -> WynikTworzenia:
        if (
            not z.sprawdzenie
            and self.duplikaty is not None
            and self.serwis.rejestr.odczytaj(self.serwis.klucz(z.sesja, p.oferta.sku)) is None
        ):
            items = self.duplikaty.sprawdz(z.sesja, (p.oferta,))[0]
            if items:
                return WynikTworzenia(
                    p.oferta.sku, "Już na Allegro", opis_duplikatow(items), items[0].ident
                )
        wynik = (
            self.serwis.sprawdz(z.sesja, p)
            if z.sprawdzenie
            else self.serwis.utworz(z.sesja, p, o.stop)
        )
        if self.katalog is not None and wynik.ident and wynik.stan in ZAPISANE:
            try:
                self.katalog.powiaz(
                    p.oferta.sku, z.sesja.konto.id, z.sesja.srodowisko.value, wynik.ident
                )
            except (BladScenariuszaKatalogu, BladTechniczny) as exc:
                o.lokalny_komunikat(
                    "Oferta zapisana w Allegro; powiązanie lokalne wymaga poprawy: " + str(exc)
                )
        return wynik

    def _blad(
        self, z: ZlecenieSeriiSzkicow, p: PlanNowegoSzkicu, exc: BladAllegro
    ) -> WynikTworzenia:
        ident = ""
        try:
            proba = self.serwis.rejestr.odczytaj(self.serwis.klucz(z.sesja, p.oferta.sku))
            if proba is not None:
                ident = proba.ident
        except (BladAllegro, OSError):
            pass  # Wynik zdalny pozostaje niepewny; nie ponawiamy POST.
        return WynikTworzenia(p.oferta.sku, kategoria_bledu(exc), str(exc), ident)

    def wykonaj(
        self,
        z: ZlecenieSeriiSzkicow,
        o: ObserwatorSeriiSzkicow,
    ) -> tuple[WynikTworzenia, ...]:
        powod = ""
        try:
            lokalne_bledy = self._katalog(z, o)
        except BladScenariuszaKatalogu as exc:
            lokalne_bledy = {
                p.oferta.sku: str(exc) for i, p in enumerate(z.plany) if i in z.do_utworzenia
            }
        except BladTechniczny as exc:
            lokalne_bledy = {}
            powod = "Błąd zapisu katalogu lokalnego: " + str(exc)
        wynik = []
        for i, p in enumerate(z.plany):
            o.postep(i + 1, p.oferta.sku)
            if i not in z.indeksy:
                wynik.append(
                    z.poprzednie[i]
                    if i < len(z.poprzednie)
                    else WynikTworzenia(p.oferta.sku, "Pominięto", "Poza zakresem wysyłki.")
                )
            elif i < len(z.poprzednie) and (
                (not z.sprawdzenie and i not in z.do_utworzenia)
                or (
                    z.sprawdzenie
                    and z.poprzednie[i].stan in {"Odrzucono", "Do poprawy"}
                    and self.serwis.rejestr.odczytaj(self.serwis.klucz(z.sesja, p.oferta.sku))
                    is None
                )
            ):
                wynik.append(z.poprzednie[i])
            elif o.stop() or powod:
                reason = (
                    "Zmieniło się połączenie z kontem Allegro. Otwórz paczkę ponownie."
                    if o.nieaktualne()
                    else "Zatrzymano serię na Twoje polecenie."
                    if o.stop()
                    else powod
                )
                wynik.append(WynikTworzenia(p.oferta.sku, "Wstrzymano", "Nie wysłano: " + reason))
            elif p.bledy or p.oferta.sku in lokalne_bledy:
                error = lokalne_bledy.get(p.oferta.sku) or "; ".join(p.bledy)
                wynik.append(WynikTworzenia(p.oferta.sku, "Do poprawy", error))
            else:
                try:
                    wynik.append(self._oferta(z, p, o))
                    # Niepewny wynik dotyczy tego SKU. Jego rejestr i blokada pozostają.
                except BladAllegro as exc:
                    wynik.append(self._blad(z, p, exc))
                    if zatrzymuje_serie(exc):
                        powod = f"Problem wspólny podczas oferty {p.oferta.sku}: {exc}"
        if not z.sprawdzenie:
            self._przeliczniki(z, o, wynik, powod)
        return tuple(wynik)

    def _przeliczniki(
        self,
        z: ZlecenieSeriiSzkicow,
        o: ObserwatorSeriiSzkicow,
        wyniki: list[WynikTworzenia],
        powod: str,
    ) -> None:
        for i in z.indeksy:
            if i >= len(z.plany) or i >= len(wyniki) or not z.plany[i].ustawienia.przelicznik:
                continue
            if o.stop() or o.nieaktualne():
                break
            if not wyniki[i].ident or wyniki[i].stan not in ZAPISANE | {"Przetwarzanie"}:
                continue
            if powod:
                wyniki[i] = replace(
                    wyniki[i],
                    komunikat=wyniki[i].komunikat
                    + " Przelicznik cen wymaga sprawdzenia po wznowieniu połączenia. "
                    + powod,
                )
                continue
            o.postep(i + 1, "Przelicznik cen · " + z.plany[i].oferta.sku)
            try:
                wyniki[i] = self.serwis.dokoncz_przelicznik(z.sesja, z.plany[i], o.stop)
            except BladAllegro as exc:
                wyniki[i] = replace(
                    wyniki[i], komunikat=wyniki[i].komunikat + " Przelicznik cen: " + str(exc)
                )
                if zatrzymuje_serie(exc):
                    powod = str(exc)
