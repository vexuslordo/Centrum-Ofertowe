"""Checkboxy są prezentacją istniejącego zaznaczenia wierszy, nie drugim wyborem."""

from collections.abc import Callable

from PySide6.QtCore import (
    QEvent,
    QItemSelectionModel,
    QModelIndex,
    QObject,
    QPersistentModelIndex,
    Qt,
)
from PySide6.QtGui import QKeyEvent, QMouseEvent, QPainter
from PySide6.QtWidgets import (
    QStyle,
    QStyledItemDelegate,
    QStyleOptionButton,
    QStyleOptionViewItem,
    QTableWidget,
    QTableWidgetItem,
)
from shiboken6 import isValid


class _CheckboxWiersza(QStyledItemDelegate):
    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        if option.widget is None:
            return
        style = option.widget.style()
        style.drawControl(QStyle.ControlElement.CE_ItemViewItem, option, painter, option.widget)
        box = QStyleOptionButton()
        box.rect = option.rect.adjusted(
            10, (option.rect.height() - 16) // 2, -10, -(option.rect.height() - 16) // 2
        )
        box.state = QStyle.StateFlag.State_Enabled | (
            QStyle.StateFlag.State_On
            if option.state & QStyle.StateFlag.State_Selected
            else QStyle.StateFlag.State_Off
        )
        style.drawPrimitive(
            QStyle.PrimitiveElement.PE_IndicatorCheckBox, box, painter, option.widget
        )


class ZaznaczaniePrzygotowania(QObject):
    def __init__(self, table: QTableWidget, zaznacz: Callable[[], None]) -> None:
        super().__init__(table)
        self.table = table
        self.zaznacz = zaznacz
        self.kolumna = table.columnCount()
        table.insertColumn(self.kolumna)
        header = QTableWidgetItem("☐")
        header.setToolTip("Zaznacz / odznacz wszystkie widoczne oferty")
        table.setHorizontalHeaderItem(self.kolumna, header)
        table.setColumnWidth(self.kolumna, 38)
        table.horizontalHeader().moveSection(self.kolumna, 0)
        self.delegat = _CheckboxWiersza(table)
        table.setItemDelegateForColumn(self.kolumna, self.delegat)
        table.viewport().installEventFilter(self)
        table.installEventFilter(self)
        table.horizontalHeader().sectionClicked.connect(self._wszystkie)
        table.itemSelectionChanged.connect(self._odswiez)

    def _odswiez(self) -> None:
        if not isValid(self.table):
            return
        rows = [i for i in range(self.table.rowCount()) if not self.table.isRowHidden(i)]
        selected = self.table.selectionModel()
        all_selected = bool(rows) and all(selected.isRowSelected(i) for i in rows)
        item = self.table.horizontalHeaderItem(self.kolumna)
        if item is not None:
            item.setText("☑" if all_selected else "☐")
        self.table.viewport().update()

    def _wszystkie(self, col: int) -> None:
        if col != self.kolumna:
            return
        rows = [i for i in range(self.table.rowCount()) if not self.table.isRowHidden(i)]
        if rows and all(self.table.selectionModel().isRowSelected(i) for i in rows):
            self.table.clearSelection()
        else:
            self.zaznacz()
        self._odswiez()

    def _wiersz(self, row: int) -> None:
        index = self.table.model().index(row, self.kolumna)
        flags = QItemSelectionModel.SelectionFlag
        self.table.selectionModel().select(index, flags.Toggle | flags.Rows)
        self.table.selectionModel().setCurrentIndex(index, flags.NoUpdate)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if not isValid(self.table):
            return False
        if isinstance(event, QMouseEvent) and obj is self.table.viewport():
            index = self.table.indexAt(event.position().toPoint())
            if index.isValid() and index.column() == self.kolumna:
                left = event.button() == Qt.MouseButton.LeftButton
                if left and event.type() == QEvent.Type.MouseButtonPress:
                    self._wiersz(index.row())
                    return True
                if left and event.type() == QEvent.Type.MouseButtonRelease:
                    return True
        if (
            obj is self.table
            and isinstance(event, QKeyEvent)
            and event.type() == QEvent.Type.KeyPress
            and event.key() == Qt.Key.Key_Space
            and self.table.currentColumn() == self.kolumna
            and self.table.currentRow() >= 0
        ):
            self._wiersz(self.table.currentRow())
            return True
        return False
