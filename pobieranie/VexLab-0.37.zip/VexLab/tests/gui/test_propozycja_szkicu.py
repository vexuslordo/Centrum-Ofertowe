from dataclasses import replace

from PySide6.QtWidgets import QMessageBox

from vexlab.adaptery.propozycje_szkicow_json import PropozycjeJSON
from vexlab.gui.propozycja_szkicu_allegro import EdytorPropozycjiAllegro
from vexlab.przypadki_uzycia.allegro import (
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    SzczegolySzkicuAllegro,
)
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu
from vexlab.przypadki_uzycia.propozycje_szkicow import PropozycjeSzkicow
from vexlab.rdzen.kontrakty import BladTechniczny


def utworz(qtbot):
    s = SesjaAllegro(KontoAllegro("1", "fixture"), SrodowiskoAllegro.SANDBOX, "token", 5000)
    d = SzczegolySzkicuAllegro(
        "123",
        "Tytuł",
        "SKU",
        "10",
        "PLN",
        1,
        "1",
        (),
        ((ElementPodgladu("tekst", "<p>Źródło &amp; <b>bez zmian</b></p>"),),),
    )
    sesje, calls = [s], []

    class Allegro:
        aktualny = d

        def szkic(self, sesja, id):
            calls.append(id)
            return self.aktualny

    def uruchom(fn, ok, blad):
        try:
            wynik = fn()
        except BladTechniczny as exc:
            blad(getattr(exc, "kod", "TECHNICZNY"), str(exc))
        else:
            ok(wynik)

    api = Allegro()
    w = EdytorPropozycjiAllegro(
        None, d, s, PropozycjeSzkicow(PropozycjeJSON()), api, lambda: sesje[0], uruchom
    )
    qtbot.addWidget(w)
    w.show()
    return w, api, sesje, calls


def test_otwarcie_zapis_i_wczytanie_nie_dotykaja_api_i_nie_przepisuja_html(qtbot, tmp_path):
    w, api, sesje, calls = utworz(qtbot)
    oryginal = w.baza.sekcje
    assert w.propozycja().sekcje == oryginal and not w._zmieniona()
    w.tytul.setText("Moja propozycja")
    w.zapisz_do(tmp_path / "propozycja.json")
    assert not calls and not w.zapis_api.isEnabled()
    assert "lokalną" in w.komunikat.text() and not w._zmieniona()
    w.tytul.setText("Jeszcze inna")
    w.wczytaj_z(tmp_path / "propozycja.json")
    assert w.tytul.text() == "Moja propozycja"
    assert w.propozycja().sekcje == oryginal and not calls
    w.reject()


def test_blad_zapisu_konflikt_i_rozlaczenie_zachowuja_tresc(qtbot, tmp_path):
    w, api, sesje, calls = utworz(qtbot)
    w.tytul.setText("Niezapisane zmiany")
    cel = tmp_path / "istnieje.json"
    cel.write_text("nie nadpisuj")
    w.zapisz_do(cel)
    assert w.tytul.text() == "Niezapisane zmiany" and not w.trwa
    assert cel.read_text() == "nie nadpisuj"
    api.aktualny = replace(api.aktualny, tytul="Zmieniono zewnętrznie")
    w.sprawdz_aktualnosc()
    assert calls == ["123"] and "zmieniła" in w.komunikat.text()
    assert w.tytul.text() == "Niezapisane zmiany"
    sesje[0] = None
    w.sprawdz_aktualnosc()
    assert calls == ["123"] and "Połącz" in w.komunikat.text()
    w.ostatni_zapis = w.propozycja()
    w.reject()


def test_odmowa_odrzucenia_zachowuje_otwarty_edytor(qtbot, monkeypatch):
    w, api, sesje, calls = utworz(qtbot)
    w.tytul.setText("Niezapisany tytuł")
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    w.reject()
    assert w.isVisible() and w.tytul.text() == "Niezapisany tytuł"
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    with qtbot.waitSignal(w.finished):
        w.close()
    assert not w.isVisible()
