"""Robocza edycja zdalnego szkicu; lokalny plik i sprawdzenie aktualności przez GET."""

from collections.abc import Callable
from pathlib import Path
from typing import cast

from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.edytor_opisu import EdytorOpisu
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    PolaczAllegro,
    SesjaAllegro,
    SzczegolySzkicuAllegro,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.propozycje_szkicow import PropozycjaSzkicu, PropozycjeSzkicow


class EdytorPropozycjiAllegro(QDialog):
    def __init__(
        self,
        parent: QWidget | None,
        szczegoly: SzczegolySzkicuAllegro,
        sesja: SesjaAllegro,
        propozycje: PropozycjeSzkicow,
        allegro: PolaczAllegro,
        aktualna_sesja: Callable[[], SesjaAllegro | None],
        uruchom: Uruchom,
        zdjecia: PodgladZdjec | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Propozycja edycji szkicu Allegro")
        self.resize(1120, 800)
        self.serwis, self.allegro, self.sesja, self.uruchom = (
            propozycje,
            allegro,
            aktualna_sesja,
            uruchom,
        )
        self.zdjecia, self.szczegoly = zdjecia, szczegoly
        self.baza = propozycje.rozpocznij(sesja, szczegoly)
        self.ostatni_zapis = self.baza
        self.trwa = False
        self.layout_glowny = QVBoxLayout(self)
        self.layout_glowny.addWidget(
            etykieta(
                f"{sesja.srodowisko.value} • Konto: {sesja.konto.login} • Szkic: {szczegoly.id}"
            )
        )
        self.layout_glowny.addWidget(
            etykieta(
                "Propozycja zmian — zapisujesz lokalny plik roboczy. Allegro pozostaje bez zmian."
            )
        )
        form = QFormLayout()
        self.tytul = QLineEdit(szczegoly.tytul)
        self.tytul.setMaxLength(1000)
        self.tytul.setAccessibleName("Roboczy tytuł szkicu Allegro")
        form.addRow("Tytuł", self.tytul)
        self.layout_glowny.addLayout(form)
        self.opis = self._nowy_opis(self.baza)
        self.layout_glowny.addWidget(self.opis, 1)
        self.komunikat = etykieta("Zapis w Allegro jest w przygotowaniu.")
        self.layout_glowny.addWidget(self.komunikat)
        buttons = QHBoxLayout()
        self.zapisz = QPushButton("Zapisz propozycję do pliku…")
        self.zapisz.clicked.connect(self._wybierz_zapis)
        self.wczytaj = QPushButton("Wczytaj propozycję…")
        self.wczytaj.clicked.connect(self._wybierz_odczyt)
        self.sprawdz = QPushButton("Sprawdź aktualność w Allegro")
        self.sprawdz.clicked.connect(self.sprawdz_aktualnosc)
        self.zapis_api = QPushButton("Zapisz w Allegro")
        self.zapis_api.setEnabled(False)
        self.zapis_api.setToolTip(
            "Zapis zmian w Allegro nie jest jeszcze dostępny. Możesz zachować lokalną propozycję."
        )
        self.zamknij = QPushButton("Zamknij")
        self.zamknij.clicked.connect(self.reject)
        for b in (self.zapisz, self.wczytaj, self.sprawdz, self.zapis_api, self.zamknij):
            buttons.addWidget(b)
        self.layout_glowny.addLayout(buttons)
        self.finished.connect(lambda _: self.opis.obrazy.zamknij())
        self.tytul.textChanged.connect(self._tytul_podgladu)

    def _tytul_podgladu(self, value: str) -> None:
        self.opis.tytul = value

    def _nowy_opis(self, p: PropozycjaSzkicu) -> EdytorOpisu:
        oferta = OfertaPodglad(
            0, self.szczegoly.sku, p.tytul, "", "", "", "", self.szczegoly.zdjecia, p.sekcje, ()
        )
        return EdytorOpisu(
            oferta,
            self,
            self.zdjecia,
            self.uruchom,
            podpis_zdjec="Zdjęcia szkicu Allegro",
            instrukcja="Edytuj tekst i układ sekcji. Zmiany pozostają lokalną propozycją.",
        )

    def propozycja(self) -> PropozycjaSzkicu:
        return self.serwis.zmien(self.baza, self.tytul.text(), self.opis.wynik_sekcji())

    def _zmieniona(self) -> bool:
        try:
            return self.propozycja() != self.ostatni_zapis
        except BladAllegro:
            return True

    def _mozna_zastapic(self) -> bool:
        if not self._zmieniona():
            return True
        return (
            QMessageBox.question(
                self,
                "Niezapisana propozycja",
                "Odrzucić niezapisane zmiany propozycji?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            == QMessageBox.StandardButton.Yes
        )

    def _zajetosc(self, trwa: bool) -> None:
        self.trwa = trwa
        for w in (self.tytul, self.opis, self.zapisz, self.wczytaj, self.sprawdz):
            w.setEnabled(not trwa)

    def _blad(self, kod: str, opis: str) -> None:
        self._zajetosc(False)
        self.komunikat.setText(opis)

    def _wybierz_zapis(self) -> None:
        cel, _ = QFileDialog.getSaveFileName(
            self, "Zapisz propozycję", "", "Propozycja szkicu (*.json)"
        )
        if cel:
            sciezka = Path(cel)
            self.zapisz_do(sciezka if sciezka.suffix else sciezka.with_suffix(".json"))

    def zapisz_do(self, cel: Path) -> None:
        if self.trwa:
            return
        try:
            p = self.propozycja()
        except BladAllegro as exc:
            self.komunikat.setText(str(exc))
            return
        self._zajetosc(True)

        def gotowe(_: object) -> None:
            self.ostatni_zapis = p
            self._zajetosc(False)
            self.komunikat.setText("Zapisano lokalną propozycję. Nie zmieniono szkicu w Allegro.")

        self.uruchom(lambda: self.serwis.zapisz(cel, p), gotowe, self._blad)

    def _wybierz_odczyt(self) -> None:
        if not self._mozna_zastapic():
            return
        zrodlo, _ = QFileDialog.getOpenFileName(
            self, "Wczytaj propozycję", "", "Propozycja szkicu (*.json)"
        )
        if zrodlo:
            self.wczytaj_z(Path(zrodlo))

    def wczytaj_z(self, zrodlo: Path) -> None:
        if self.trwa:
            return
        self._zajetosc(True)

        def gotowe(wynik: object) -> None:
            p = cast(PropozycjaSzkicu, wynik)
            nowy = self._nowy_opis(p)
            self.layout_glowny.replaceWidget(self.opis, nowy)
            self.opis.obrazy.zamknij()
            self.opis.deleteLater()
            self.opis = nowy
            self.tytul.setText(p.tytul)
            self.ostatni_zapis = p
            self._zajetosc(False)
            self.komunikat.setText("Wczytano lokalną propozycję; szkic Allegro bez zmian.")

        self.uruchom(lambda: self.serwis.wczytaj(zrodlo, self.baza), gotowe, self._blad)

    def sprawdz_aktualnosc(self) -> None:
        if self.trwa:
            return
        sesja = self.sesja()
        if sesja is None or (sesja.konto.id, sesja.srodowisko) != (
            self.baza.konto_id,
            self.baza.srodowisko,
        ):
            self.komunikat.setText("Połącz właściwe konto i środowisko. Zachowano propozycję.")
            return
        self._zajetosc(True)

        def odczyt() -> None:
            aktualny = self.allegro.szkic(sesja, self.baza.oferta_id)
            self.serwis.sprawdz_aktualnosc(self.baza, aktualny)

        def gotowe(_: object) -> None:
            self._zajetosc(False)
            if self.sesja() is not sesja:
                self.komunikat.setText(
                    "Sesja zmieniła się podczas odczytu. Sprawdź aktualność ponownie."
                )
            else:
                self.komunikat.setText(
                    "Treść źródłowa jest zgodna z odczytem. Nie zapisano nic w Allegro."
                )

        self.uruchom(odczyt, gotowe, self._blad)

    def reject(self) -> None:
        if not self.trwa and self._mozna_zastapic():
            super().reject()

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.trwa or not self._mozna_zastapic():
            event.ignore()
        else:
            super().reject()
            event.accept()
