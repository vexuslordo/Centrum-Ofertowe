"""Jeden widok przygotowania: rzeczywiste widgety, zakres i cykl życia bez POST."""

from dataclasses import replace

import pytest
from PySide6.QtWidgets import QVBoxLayout, QWidget

from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.gui.paczki_ofert import StronaPaczek


@pytest.fixture
def osadzone(qtbot, nowe_szkice_fixture):
    service, api, _, session, offer, settings = nowe_szkice_fixture
    root = QWidget()
    qtbot.addWidget(root)
    box = QVBoxLayout(root)
    page = StronaPaczek(None, lambda *a: None, root, allegro_dostepne=True)
    box.addWidget(page)
    root.resize(1366, 768)
    root.show()
    offers = (offer, replace(offer, sku="DRUGI", ean="bad"))
    page._pokaz(offers)
    jobs = []
    dialog = DialogNowychSzkicow(root, service, session, offers, lambda *a: jobs.append(a))
    dialog.kompletny.setChecked(False)
    dialog.waluta.setCurrentIndex(dialog.waluta.findData("PLN"))
    for i in range(2):
        dialog.ustawienia[i] = settings
    page.centrum.czytaj_kontekst = lambda: (dialog, session)
    page.centrum.osadzenie.osadz(dialog)

    def finish(_):
        page.centrum.czytaj_kontekst = lambda: (None, session)
        page.centrum.osadzenie.zakoncz(dialog)

    dialog.finished.connect(finish)
    yield page, dialog, api, jobs, offers
    dialog.reject()


def sprawdz(dialog, jobs):
    dialog.sprawdz_przycisk.click()
    function, success, _ = jobs[-1]
    success(function())


def test_jedna_tabela_i_te_same_ustawienia_bez_osobnego_okna(osadzone):
    page, dialog, api, jobs, _ = osadzone
    assert not dialog.isWindow() and dialog.parentWidget() is page.centrum.split
    assert page.centrum.split.widget(0) is dialog
    assert dialog.tabela.isVisible() and not page.tabela.isVisible()
    assert page.centrum.tabela_widoku is dialog.tabela
    page.centrum.osadzenie.ustawienia.setChecked(True)
    assert dialog.waluta.isVisible() and dialog.karty_ustawien.isVisible()
    sprawdz(dialog, jobs)
    page.centrum.odswiez(wymus=True)
    assert page.centrum.kpi["gotowe"].liczba.text() == "1"
    assert page.centrum.kpi["bledy"].liczba.text() == "1"
    assert "POST" not in api.calls


def test_filtr_nie_znika_po_aktualizacji_wynikow_i_ogranicza_zakres(osadzone):
    page, dialog, api, jobs, _ = osadzone
    sprawdz(dialog, jobs)
    page.centrum.odswiez(wymus=True)
    page.centrum._filtr("ean")
    assert dialog.tabela.isRowHidden(0) and not dialog.tabela.isRowHidden(1)
    dialog.wszystkie.click()
    assert dialog.zakres_wysylki() == (1,)
    # Bez timera KPI: każda przebudowa stosuje ten sam filtr synchronicznie.
    dialog._pokaz_wyniki()
    assert dialog.zakres_wysylki() == (1,) and dialog.tabela.isRowHidden(0)
    page.centrum._filtr("wszystkie")
    page.centrum.szukaj.setText("DRUGI")
    dialog._pokaz_plan()
    assert dialog.tabela.isRowHidden(0) and not dialog.tabela.isRowHidden(1)
    assert "POST" not in api.calls


def test_poprawione_dane_w_kpi_i_panelu_bez_nadpisania_zrodla_zip(osadzone):
    page, dialog, api, jobs, original = osadzone
    dialog.oferty = (
        replace(original[0], cena="999", tytul="Poprawiony tytuł produktu"),
        original[1],
    )
    sprawdz(dialog, jobs)
    page.centrum.odswiez(wymus=True)
    dialog.tabela.setCurrentCell(0, 1)
    assert page.centrum.stany[0].gotowa
    assert page.centrum.panel.nazwa.text() == "Poprawiony tytuł produktu"
    assert "999" in page.centrum.panel.pola["Cena"].text()
    assert page.oferty is original and page.oferty[0].cena != "999"
    assert "POST" not in api.calls


def test_zakonczenie_przywraca_podglad_i_zwalnia_polaczenie_filtra(osadzone):
    page, dialog, _, _, original = osadzone
    dialog.reject()
    assert page.centrum.osadzenie.dialog is None
    assert page.centrum.split.widget(0) is page.tabela
    assert page.tabela.isVisible() and not dialog.isVisible()
    assert dialog.filtr_prezentacji is None
    assert page.tabs.isTabEnabled(0) and page.oferty is original
