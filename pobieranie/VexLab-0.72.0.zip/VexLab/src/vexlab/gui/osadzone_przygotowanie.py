"""Osadzenie istniejącego przygotowania w paczce, bez kopiowania jego logiki."""

from typing import TYPE_CHECKING, cast

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QBoxLayout, QDialogButtonBox, QToolButton, QVBoxLayout, QWidget

from vexlab.gui.wiersze_nowych_ofert import WierszNowejOferty

if TYPE_CHECKING:
    from vexlab.gui.centrum_nowych_ofert import CentrumNowychOfert
    from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow


class OsadzonePrzygotowanie:
    def __init__(self, centrum: "CentrumNowychOfert", toolbar: QBoxLayout) -> None:
        self.centrum = centrum
        self.dialog: DialogNowychSzkicow | None = None
        self.ustawienia = QToolButton()
        self.ustawienia.setText("Ustawienia paczki")
        self.ustawienia.setCheckable(True)
        self.ustawienia.setChecked(True)
        self.ustawienia.hide()
        toolbar.addWidget(self.ustawienia)
        self.ustawienia.toggled.connect(self._ustawienia)
        self.karty: QWidget | None = None

    def _ustawienia(self, widoczne: bool) -> None:
        if self.karty is not None:
            self.karty.setVisible(widoczne)

    def _akcja_pomocy(self, akcja: str) -> None:
        if akcja == "producent" and self.dialog is not None:
            self.ustawienia.setChecked(True)
            self.dialog.producent_lokalny.setFocus()

    def osadz(self, dialog: "DialogNowychSzkicow") -> None:
        if self.dialog is dialog:
            return
        if self.dialog is not None:
            raise ValueError("Najpierw zakończ obecne przygotowanie.")
        self.dialog = dialog
        c, page = self.centrum, self.centrum.page
        self._recznie_wlaczone = page.recznie.isEnabled()
        dialog.setWindowFlags(Qt.WindowType.Widget)
        native = cast(QVBoxLayout, dialog.layout())
        native.setContentsMargins(0, 0, 0, 0)
        dialog.tytul_przygotowania.hide()
        self.karty = dialog.karty_ustawien
        self.ustawienia.setChecked(page.height() >= 850)
        self._ustawienia(self.ustawienia.isChecked())
        self.ustawienia.show()
        dialog.pomoc_wysylki.ustaw_pionowo()
        dialog.pomoc_wysylki.akcja.connect(self._akcja_pomocy)
        cast(QVBoxLayout, c.panel.layout()).insertWidget(1, dialog.pomoc_wysylki)
        c.panel.tryb_przygotowania(True)
        dialog.pracuj_w_programie.hide()  # Pozostałe moduły są dostępne w nawigacji aplikacji.
        dialog.notatka_szkicu.hide()
        close = dialog.przyciski_zamkniecia.button(QDialogButtonBox.StandardButton.Close)
        close.setText("Zakończ przygotowanie")
        page.tabela.hide()
        old = c.split.replaceWidget(0, dialog)
        if old is not None:
            old.setParent(page)
            old.hide()
        dialog.show()
        page.tabs.setCurrentIndex(1)
        page.tabs.setTabEnabled(0, False)
        page.recznie.setEnabled(False)
        page.przygotuj_allegro.hide()
        page.zapisz_szkice.setText("Zapisz źródłową paczkę lokalnie")
        page.zapisz_szkice.setToolTip(
            "Zapisuje dane wczytane z ZIP, przed zmianami w przygotowaniu."
        )
        page.opis_paczek.hide()
        page.opis_szkicow_lokalnych.hide()
        page.info.hide()
        c.hint.hide()
        delegate = WierszNowejOferty(dialog.tabela, tytul=1, sku=0, status=4)
        dialog.tabela.setItemDelegateForColumn(1, delegate)
        dialog.tabela.setColumnHidden(0, True)
        header = dialog.tabela.horizontalHeaderItem(1)
        if header is not None:
            header.setText("Produkt / SKU")
        dialog.filtr_prezentacji = c.pasuje_do_filtrow
        dialog.tabela.currentCellChanged.connect(c.pokaz_panel)
        dialog.filtr.currentIndexChanged.connect(c.filtruj)
        c.odswiez(wymus=True)

    def zakoncz(self, dialog: "DialogNowychSzkicow") -> None:
        if self.dialog is not dialog:
            return
        c, page = self.centrum, self.centrum.page
        dialog.filtr_prezentacji = None
        dialog.tabela.currentCellChanged.disconnect(c.pokaz_panel)
        dialog.filtr.currentIndexChanged.disconnect(c.filtruj)
        dialog.pomoc_wysylki.akcja.disconnect(self._akcja_pomocy)
        dialog.pomoc_wysylki.hide()
        dialog.pomoc_wysylki.setParent(dialog)
        old = c.split.replaceWidget(0, page.tabela)
        if old is not None:
            old.hide()
            old.setParent(page)
        self.dialog = None
        self.karty = None
        self.ustawienia.hide()
        page.tabela.show()
        c.panel.tryb_przygotowania(False)
        page.tabs.setTabEnabled(0, True)
        page.recznie.setEnabled(self._recznie_wlaczone)
        page.przygotuj_allegro.setVisible(page.allegro_dostepne)
        page.zapisz_szkice.setText("Zapisz szkice lokalnie")
        page.zapisz_szkice.setToolTip("")
        page.opis_paczek.show()
        page.opis_szkicow_lokalnych.show()
        page.info.show()
        c.hint.show()
        c.odswiez(wymus=True)
