# ADR-067 — VAT według krajów w przygotowaniu szkiców

Polecenie właściciela 2026-11-13: możliwość dodania lub pobrania VAT dla
obsługiwanych krajów Allegro. GET /sale/tax-settings?category.id=... zwraca
kraje i dopuszczalne wartości, subjects i exemptions. Nie jest listą
aktywnych rynków konta ani wskazaniem właściwej stawki konkretnego towaru.
Użytkownik jawnie wybiera kraje, stawki, przedmiot i ewentualne zwolnienie.
Nie zaszywać stawek procentowych ani aktywować rynków przez ustawienie VAT.

Oddzielny formularz VAT dla zaznaczonej grupy jednej kategorii: lista stawek
API lub wpisanie ręczne, walidowane z aktualną listą kategorii przed POST.
Możliwy GET własnej oferty po ID i przejęcie jej taxSettings po kontroli
kategorii oraz dostępnych opcji. Bez rekomendowania stawek, przeliczania
cen brutto/netto lub ustalania reguł OSS. Kwoty i SKU/EAN pozostają własne.

VAT jako opcjonalne DTO w UstawieniaSzkicu z repr=False, odcisk dopisany
wyłącznie gdy skonfigurowany. Brak VAT zachowuje stare odciski i payload.
POST nadal INACTIVE/republish=false; GET potwierdza przesłane taxSettings,
brak lub różnica nie są sukcesem. Unknown/202 i trwała blokada ponowień
pozostają. Bez migracji SQLite, nowego głównego bytu lub nowych scope.

Formularz pokazuje się przed GET, status i ponowienie w tle, anulowanie
ignoruje spóźnione odpowiedzi. Błąd lub brak list nie wywołuje zgadywania
stawek. Dla mieszanych kategorii przygotować osobne grupy. Źródło kontraktu:
Swagger Allegro /sale/tax-settings, OfferTaxSettings/OfferTaxRate i poradnik
D7Kj9gw4xFA, sekcja „Opcje faktury i stawki VAT”.
