"""Ręczne tworzenie treści Oferty z tym samym lokalnym zapisem co paczki."""

from dataclasses import replace
from pathlib import Path
from typing import cast

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLineEdit,
    QMenu,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.opis_na_stronie import OpisNaStronie
from vexlab.gui.podglad_oferty import ObrazyOferty, PodgladOferty
from vexlab.gui.producenci import Uruchom
from vexlab.gui.przeciaganie_ofert import PrzeciaganieZdjecia, StrefaUpuszczania
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.nowe_szkice_allegro import adres_zdjecia
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.reczna_oferta import przygotuj_reczna
from vexlab.przypadki_uzycia.szkice import SzkiceOfert
from vexlab.przypadki_uzycia.zdjecia_ofert import PlikiZdjecOfert, lokalne_zdjecie


class RecznaOferta(QDialog):
    zmieniono = Signal()
    wysylka_zadana = Signal(object)

    def __init__(
        self,
        parent: QWidget,
        szkice: SzkiceOfert,
        uruchom: Uruchom,
        zdjecia: PodgladZdjec | None = None,
        allegro: bool = True,
        pliki_zdjec: PlikiZdjecOfert | None = None,
    ) -> None:
        super().__init__(parent)
        self.pliki_zdjec = pliki_zdjec
        self.lokalne: tuple[str, ...] = ()
        self.szkice, self.uruchom = szkice, uruchom
        self.trwa = False
        self.setWindowTitle("Utwórz ofertę ręcznie")
        ekran = self.screen().availableGeometry()
        width, height = max(320, ekran.width() - 48), max(320, ekran.height() - 72)
        self.setMinimumSize(min(800, width), min(560, height))
        self.resize(min(1160, width), min(800, height))
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        title = etykieta("Nowa oferta")
        title.setObjectName("tytulStronyAllegro")
        layout.addWidget(title)
        layout.addWidget(
            etykieta(
                "Uzupełnij dane, dodaj zdjęcia i opis. "
                "Ustawienia Allegro wybierzesz w następnym kroku."
            )
        )
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        page = QWidget()
        content = QVBoxLayout(page)
        content.setSpacing(18)
        scroll.setWidget(page)
        layout.addWidget(scroll, 1)
        self.obszar_formularza = scroll
        dane = QGroupBox("Dane oferty")
        form = QFormLayout(dane)
        content.addWidget(dane)
        self.sku, self.tytul, self.ean, self.cena = (QLineEdit() for _ in range(4))
        self.sku.setMaxLength(100)
        self.tytul.setMaxLength(75)
        self.ean.setMaxLength(13)
        self.cena.setMaxLength(30)
        for label, field in (
            ("Tytuł *", self.tytul),
            ("SKU / sygnatura *", self.sku),
            ("EAN", self.ean),
            ("Cena brutto", self.cena),
        ):
            field.setAcceptDrops(False)
            field.setAccessibleName(label)
            form.addRow(label, field)
        self.ean.setPlaceholderText("Opcjonalnie")
        self.cena.setPlaceholderText("Walutę wybierzesz w ustawieniach Allegro")
        gallery = StrefaUpuszczania()
        gallery.setAccessibleName("Przeciągnij zdjęcia z dysku do oferty")
        gallery.pliki.connect(self._importuj_pliki)
        content.addWidget(gallery)
        gallery_layout = QVBoxLayout(gallery)
        gallery_layout.addWidget(etykieta("Zdjęcia"))
        tools = QHBoxLayout()
        self.dysk = QPushButton("Dodaj zdjęcia…")
        self.dysk.setEnabled(pliki_zdjec is not None)
        self.dysk.clicked.connect(self.dodaj_pliki)
        tools.addWidget(self.dysk)
        link = QPushButton("Dodaj przez link")
        tools.addWidget(link)
        self.lista_plikow = etykieta("Przeciągnij pliki tutaj • maks. 16 zdjęć")
        tools.addWidget(self.lista_plikow, 1)
        self.wyczysc_pliki = QPushButton("Usuń wszystkie")
        self.wyczysc_pliki.setEnabled(False)
        self.wyczysc_pliki.clicked.connect(self.usun_pliki)
        tools.addWidget(self.wyczysc_pliki)
        gallery_layout.addLayout(tools)
        self.galeria = QPlainTextEdit()
        self.galeria.setAcceptDrops(False)
        self.galeria.setAccessibleName("Adresy zdjęć oferty")
        self.galeria.setMaximumHeight(85)
        self.galeria.setPlaceholderText("Wklej adresy HTTPS zdjęć — każdy w osobnym wierszu")
        self.galeria.hide()
        link.clicked.connect(lambda: self.galeria.setVisible(not self.galeria.isVisible()))
        gallery_layout.addWidget(self.galeria)
        self.miniatury = ObrazyOferty(self, zdjecia, uruchom, miniatury=True)
        self.finished.connect(lambda _: self.miniatury.zamknij())
        self._kolejnosc: tuple[str, ...] = ()
        self._przeciagania: list[PrzeciaganieZdjecia] = []
        self.pola_miniatur = QWidget()
        self.miniatury_layout = QHBoxLayout(self.pola_miniatur)
        self.miniatury_layout.setContentsMargins(4, 4, 4, 4)
        self.pasek_zdjec = QScrollArea()
        self.pasek_zdjec.setWidgetResizable(True)
        self.pasek_zdjec.setWidget(self.pola_miniatur)
        self.pasek_zdjec.setFixedHeight(135)
        self.pasek_zdjec.hide()
        gallery_layout.addWidget(self.pasek_zdjec)
        empty = OfertaPodglad(1, "", "", "", "", "", "", (), (), ())
        self.opis = OpisNaStronie(empty, self, zdjecia, uruchom)
        content.addWidget(self.opis)
        content.addStretch()
        self.finished.connect(lambda _: self.opis.zamknij())
        self.opis.pliki_zadane.connect(self._importuj_pliki)
        self.opis.dodaj_zdjecia_zadane.connect(self.dodaj_pliki)
        self.opis.podglad_zadany.connect(self.pokaz_podglad)
        for field in (self.sku, self.tytul, self.ean, self.cena):
            field.textChanged.connect(self._dane_podgladu)
        self.galeria.textChanged.connect(self._galeria)
        self.info = etykieta(
            "Szkic możesz zapisać i dokończyć później. Sprzedaż uruchomisz osobno."
        )
        layout.addWidget(self.info)
        buttons = QHBoxLayout()
        self.zapis = QPushButton("Zapisz szkic")
        self.przygotuj = QPushButton("Dalej — ustawienia Allegro")
        self.przygotuj.setObjectName("primary")
        self.przygotuj.setVisible(allegro)
        self.zamknij = QPushButton("Zamknij")
        buttons.addStretch()
        for b in (self.zapis, self.przygotuj, self.zamknij):
            buttons.addWidget(b)
        layout.addLayout(buttons)
        self.zapis.clicked.connect(lambda: self.zapisz(False))
        self.przygotuj.clicked.connect(lambda: self.zapisz(True))
        self.zamknij.clicked.connect(self.reject)

    def _dane_podgladu(self) -> None:
        self.opis.tytul = self.tytul.text()
        self.opis.oferta = replace(
            self.opis.oferta,
            sku=self.sku.text(),
            tytul=self.tytul.text(),
            ean=self.ean.text(),
            cena=self.cena.text(),
        )

    def usun_pliki(self) -> None:
        self.lokalne = ()
        self._kolejnosc = ()
        self.galeria.clear()
        self._galeria()

    def usun_zdjecie(self, url: str) -> None:
        self.lokalne = tuple(u for u in self.lokalne if u != url)
        self.galeria.blockSignals(True)
        self.galeria.setPlainText(
            "\n".join(u for u in self.galeria.toPlainText().splitlines() if u.strip() != url)
        )
        self.galeria.blockSignals(False)
        self._galeria()

    def glowne_zdjecie(self, url: str) -> None:
        self._kolejnosc = (url,) + tuple(u for u in self._adresy() if u != url)
        self._galeria()

    def dodaj_pliki(self) -> None:
        if self.trwa or self.pliki_zdjec is None:
            return
        files, _ = QFileDialog.getOpenFileNames(
            self, "Dodaj zdjęcia oferty", "", "Zdjęcia (*.jpg *.jpeg *.png *.webp)"
        )
        if not files:
            self.opis.anuluj_dodawanie()
            return
        self._importuj_pliki(tuple(Path(f) for f in files))

    def _importuj_pliki(self, value: object) -> None:
        if self.trwa or self.pliki_zdjec is None:
            return
        files = cast(tuple[Path, ...], value)
        if len(self._adresy()) + len(files) > 16:
            self.info.setText("W ofercie może być maksymalnie 16 zdjęć.")
            self.opis.anuluj_dodawanie()
            return
        store = self.pliki_zdjec
        self.trwa = True
        self.setEnabled(False)
        self.info.setText("Przygotowanie zdjęć…")

        def ok(w: object) -> None:
            self.trwa = False
            self.setEnabled(True)
            refs = cast(tuple[str, ...], w)
            self.lokalne = tuple(dict.fromkeys((*self.lokalne, *refs)))
            self._galeria()
            self.opis.przyjmij_pliki(refs)
            self.info.setText("Zdjęcia dodane. Przeciągnij je do opisu.")

        def error(k: str, text: str) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.opis.anuluj_dodawanie()
            self.info.setText(text)

        self.uruchom(lambda: store.importuj(files), ok, error)

    def _adresy(self) -> tuple[str, ...]:
        urls = tuple(
            dict.fromkeys(
                (
                    *self.lokalne,
                    *(
                        line.strip()
                        for line in self.galeria.toPlainText().splitlines()
                        if line.strip()
                    ),
                )
            )
        )
        return tuple(u for u in self._kolejnosc if u in urls) + tuple(
            u for u in urls if u not in self._kolejnosc
        )

    def _galeria(self) -> None:
        self._kolejnosc = self._adresy()
        urls = tuple(u for u in self._kolejnosc if adres_zdjecia(u) or lokalne_zdjecie(u))[:16]
        self.opis.oferta = replace(self.opis.oferta, zdjecia=urls)
        self.opis.set_galeria(urls)
        self.pasek_zdjec.setVisible(bool(urls))
        self.wyczysc_pliki.setEnabled(bool(urls))
        self.lista_plikow.setText(f"Zdjęcia: {len(urls)}/16 • przeciągnij do opisu")
        self._przeciagania.clear()
        while self.miniatury_layout.count():
            item = self.miniatury_layout.takeAt(0)
            widget = item.widget() if item is not None else None
            if widget is not None:
                widget.hide()
                widget.deleteLater()
        for i, url in enumerate(urls, 1):
            host = QWidget()
            col = QVBoxLayout(host)
            col.setContentsMargins(2, 2, 2, 2)
            mini = self.miniatury.obraz(url)
            self._przeciagania.append(PrzeciaganieZdjecia(mini, url))
            col.addWidget(mini)
            tools = QHBoxLayout()
            tools.addWidget(etykieta("Główne" if i == 1 else str(i)))
            more = QToolButton()
            more.setText("…")
            more.setAccessibleName(f"Działania zdjęcia {i}")
            menu = QMenu(more)
            menu.addAction("Ustaw jako główne").triggered.connect(
                lambda _checked=False, u=url: self.glowne_zdjecie(u)
            )
            menu.addAction("Dodaj do opisu").triggered.connect(
                lambda _checked=False, u=url: self.opis.dodaj_zdjecie(u)
            )
            menu.addAction("Usuń z galerii").triggered.connect(
                lambda _checked=False, u=url: self.usun_zdjecie(u)
            )
            more.setMenu(menu)
            more.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            tools.addWidget(more)
            col.addLayout(tools)
            self.miniatury_layout.addWidget(host)
        self.miniatury_layout.addStretch()

    def pokaz_podglad(self) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Podgląd oferty")
        dialog.resize(self.size())
        layout = QVBoxLayout(dialog)
        obrazy = ObrazyOferty(dialog, self.miniatury.serwis, self.uruchom)
        widok = PodgladOferty(obrazy)
        oferta = replace(self.opis.oferta, opis=self.opis.opis(), sekcje=self.opis.wynik_sekcji())
        widok.pokaz(
            oferta,
            oferta.sekcje,
            metadane=f"SKU: {oferta.sku} • EAN: {oferta.ean or '—'} • Cena: {oferta.cena or '—'}",
        )
        layout.addWidget(widok)
        close = QPushButton("Wróć do edycji")
        close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        dialog.finished.connect(lambda _: obrazy.zamknij())
        dialog.exec()

    def zapisz(self, allegro: bool) -> None:
        if self.trwa:
            return
        try:
            oferta = przygotuj_reczna(
                self.sku.text(),
                self.tytul.text(),
                self.ean.text(),
                self.cena.text(),
                self.opis.opis(),
                self._adresy(),
                self.opis.wynik_sekcji(),
            )
            plan = self.szkice.zaplanuj((oferta,), "Utworzono ręcznie")
            if plan.bledy:
                raise ValueError("; ".join(plan.bledy))
        except ValueError as exc:
            self.info.setText(str(exc))
            return
        self.trwa = True
        self.setEnabled(False)
        self.info.setText("Zapisywanie szkicu…")

        def ok(w: object) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.info.setText("Szkic zapisany lokalnie. Znajdziesz go w zakładce Szkice.")
            self.zmieniono.emit()
            self.accept()
            if allegro:
                self.wysylka_zadana.emit((oferta,))

        def blad(kod: str, text: str) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.info.setText(text)

        self.uruchom(lambda: self.szkice.zapisz(plan), ok, blad)

    def reject(self) -> None:
        if not self.trwa:
            super().reject()
