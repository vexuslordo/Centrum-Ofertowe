from dataclasses import replace

from PySide6.QtCore import QItemSelectionModel
from PySide6.QtWidgets import QCheckBox, QDialog

from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from vexlab.gui.masowa_paczka_allegro import MasowaPaczkaAllegro


def select(w, rows):
    w.tabela.clearSelection()
    for row in rows:
        w.tabela.selectionModel().select(
            w.tabela.model().index(row, 0),
            QItemSelectionModel.SelectionFlag.Select | QItemSelectionModel.SelectionFlag.Rows,
        )
    w.tabela.setCurrentCell(rows[0], 0, QItemSelectionModel.SelectionFlag.NoUpdate)


def test_edycja_wybranego_zakresu_z_podgladem_i_ilosciami(qtbot, nowe_szkice_fixture, monkeypatch):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(qtbot, nowe_szkice_fixture, (o, replace(o, sku="2"), replace(o, sku="3")))
    select(w, (0, 2))

    def edit(d):
        assert len(d.pozycje) == 2 and not d.zastosuj.isEnabled()
        d.ceny.setChecked(True)
        d.wartosc.setText("500")
        d.liczby.setChecked(True)
        d.ilosc.setValue(7)
        d.sprawdz()
        assert d.zastosuj.isEnabled()
        d.wartosc.setText("600")
        assert not d.zastosuj.isEnabled()
        d.sprawdz()
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(MasowaPaczkaAllegro, "exec", edit)
    w.edytuj_masowo()
    wykonaj(jobs)
    assert [p.ustawienia.cena for p in w.plany] == ["600.00", "", "600.00"]
    assert [p.ustawienia.ilosc for p in w.plany] == [7, 1, 7]
    assert "POST" not in nowe_szkice_fixture[1].calls


def test_wspolne_parametry_tylko_zaznaczone_i_zmieniane(qtbot, nowe_produkty_fixture, monkeypatch):
    o = nowe_produkty_fixture[4]
    w, jobs = panel(qtbot, nowe_produkty_fixture, (o, replace(o, sku="2"), replace(o, sku="3")))
    w.przygotuj()
    wykonaj(jobs)
    select(w, (0, 2))

    def edit(d):
        checks = d.findChildren(QCheckBox)
        assert not any(c.isChecked() for c in checks)
        next(c for c in checks if "Stan" in c.text()).setChecked(True)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", edit)
    w.uzupelnij(True)
    wykonaj(jobs)
    assert [dict(p.ustawienia.wartosci)["kod"] for p in w.plany] == [o.sku, "2", "3"]
    assert "POST" not in nowe_produkty_fixture[1].calls


def test_wysylka_wylacznie_zaznaczonych_i_filtr_nie_wybiera_ukrytych(qtbot, nowe_szkice_fixture):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(
        qtbot, nowe_szkice_fixture, (o, replace(o, sku="2"), replace(o, sku="3", cena="brak"))
    )
    w.przygotuj()
    wykonaj(jobs)
    w.filtr.setCurrentIndex(1)
    w.zaznacz_widoczne()
    assert w.wybrane() == (0, 1)
    select(w, (1,))
    w.wyslij(False)
    wykonaj(jobs)
    assert [r.stan for r in w.wyniki] == ["Gotowa do utworzenia", "Utworzono szkic", "Do poprawy"]
    assert nowe_szkice_fixture[1].calls.count("POST") == 1
