from copy import deepcopy
from dataclasses import replace
from uuid import UUID

import pytest

from tests.integration.test_nowe_szkice_allegro import Transport, odpowiedz
from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import pola_sprzedazy, sprawdz_ustawienia


def test_zapis_kompletnego_szkicu_i_sygnatura_sku(sprzedaz_fixture):
    service, api, _, s, o, u, _ = sprzedaz_fixture
    original = api.utworz_szkic

    def post(s, dane):
        r = original(s, dane)
        d = next(iter(api.wyniki.values()))
        # Publiczny GET ma id producenta bez type; dodatkowe pola nie blokują weryfikacji.
        d["productSet"][0]["responsibleProducer"].pop("type")
        d["validation"] = {"errors": [], "warnings": [], "validatedAt": "2026-11-13T10:00:00Z"}
        return r

    api.utworz_szkic = post
    p = service.przygotuj(s, o, u)
    assert not p.bledy
    assert service.utworz(s, p, lambda: False).stan == "Szkic kompletny"
    d = api.przeslane
    fields, gpsr = pola_sprzedazy(u.sprzedaz)
    assert all(d[k] == v for k, v in fields.items())
    assert all(d["productSet"][0][k] == v for k, v in gpsr.items())
    assert d["external"] == {"id": o.sku}
    assert d["publication"] == {"status": "INACTIVE", "republish": False}
    assert service.utworz(s, p, lambda: False).stan == "Szkic kompletny"
    assert api.calls.count("POST") == 1


@pytest.mark.parametrize(
    "pole,wartosc",
    [
        ("producent", ""),
        ("osoba", ""),
        ("bezpieczenstwo", ""),
        ("bezpieczenstwo", "x" * 5001),
        ("dostawa", "bad"),
        ("czas", "PT2H"),
        ("zwroty", ""),
        ("reklamacje", ""),
        ("gwarancja", ""),
        ("kraj", ""),
        ("kod", "12345"),
        ("wojewodztwo", ""),
        ("faktura", ""),
    ],
)
def test_braki_nie_pozwalaja_wyslac(sprzedaz_fixture, pole, wartosc):
    service, api, _, s, o, u, _ = sprzedaz_fixture
    bad = replace(u.sprzedaz, **{pole: wartosc})
    assert sprawdz_ustawienia(bad)
    p = service.przygotuj(s, o, replace(u, sprzedaz=bad))
    assert p.bledy
    with pytest.raises(BladAllegro):
        service.utworz(s, p, lambda: False)
    assert "POST" not in api.calls and "zdjecie" not in api.calls


def test_usuniety_lub_obcy_id_blokuje_preflight(sprzedaz_fixture):
    service, api, _, s, o, u, refs = sprzedaz_fixture
    api.slowniki_sprzedazy = lambda *a, **kw: replace(refs, producenci=())
    p = service.przygotuj(s, o, u)
    with pytest.raises(BladAllegro, match="nie istnieje"):
        service.utworz(s, p, lambda: False)
    assert "POST" not in api.calls


@pytest.mark.parametrize(
    "pole",
    [
        "delivery",
        "location",
        "payments",
        "afterSalesServices",
        "safetyInformation",
        "responsibleProducer",
        "responsiblePerson",
    ],
)
def test_niezapisane_pole_nie_jest_sukcesem_i_nie_ponawia_post(sprzedaz_fixture, pole):
    service, api, _, s, o, u, _ = sprzedaz_fixture
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    d = next(iter(api.wyniki.values()))
    if pole in d:
        d[pole] = None
    else:
        d["productSet"][0][pole] = None
    with pytest.raises(BladAllegro, match="GPSR"):
        service.utworz(s, p, lambda: False)
    assert api.calls.count("POST") == 1


def test_slowniki_calego_konta_strony_cache_i_brak_domyslnych_danych(sprzedaz_fixture):
    _, _, _, s, _, _, refs = sprzedaz_fixture
    groups = [
        refs.producenci,
        refs.osoby,
        refs.dostawy,
        refs.zwroty,
        refs.reklamacje,
        refs.gwarancje,
    ]
    keys = [
        "responsibleProducers",
        "responsiblePersons",
        "shippingRates",
        "returnPolicies",
        "impliedWarranties",
        "warranties",
    ]
    replies = [
        odpowiedz(
            200,
            {
                key: [{"id": r.id, "name": r.nazwa} for r in rows],
                **({"totalCount": len(rows)} if i < 2 else {}),
            },
        )
        for i, (key, rows) in enumerate(zip(keys, groups, strict=True))
    ]
    t = Transport(*replies)
    api = NoweSzkiceAPI(t)
    assert api.slowniki_sprzedazy(s) == refs
    assert api.slowniki_sprzedazy(s) == refs and len(t.calls) == 6
    assert all(m == "GET" for m, *_ in t.calls)
    assert "limit=100" in t.calls[0][1] and "/return-policies?limit=60" in t.calls[3][1]


def test_paginacja_gpsr_nie_ucina_listy(sprzedaz_fixture):
    _, _, _, s, _, _, _ = sprzedaz_fixture
    first = {"id": str(UUID(int=101)), "name": "Pierwszy"}
    second = {"id": str(UUID(int=102)), "name": "Drugi"}
    replies = [
        odpowiedz(200, {"responsibleProducers": [first], "totalCount": 2}),
        odpowiedz(200, {"responsibleProducers": [second], "totalCount": 2}),
        odpowiedz(200, {"responsiblePersons": [], "totalCount": 0}),
    ]
    replies += [
        odpowiedz(200, {key: []})
        for key in ["shippingRates", "returnPolicies", "impliedWarranties", "warranties"]
    ]
    api = NoweSzkiceAPI(Transport(*replies))
    assert len(api.slowniki_sprzedazy(s).producenci) == 2


def test_brak_scope_wskazuje_sposob_nadania(sprzedaz_fixture):
    s = sprzedaz_fixture[3]
    with pytest.raises(BladAllegro, match="settings:read"):
        NoweSzkiceAPI(Transport(odpowiedz(403, {}))).slowniki_sprzedazy(s)


def test_transport_dopuszcza_komplet_i_blokuje_obce_pola(sprzedaz_fixture, monkeypatch):
    import json

    from vexlab.adaptery import allegro_http

    service, api, _, s, o, u, _ = sprzedaz_fixture
    service.utworz(s, service.przygotuj(s, o, u), lambda: False)
    calls = []

    def opener(*a):
        calls.append(True)
        raise BladAllegro("TEST", "Dopuszczono transport")

    monkeypatch.setattr(allegro_http, "build_opener", opener)
    d = api.przeslane
    with pytest.raises(BladAllegro):
        allegro_http.HTTPSAllegro().wyslij(
            "POST", "https://api.allegro.pl/sale/product-offers", {}, json.dumps(d).encode()
        )
    assert calls
    calls.clear()
    bad = deepcopy(d)
    bad["publication"]["status"] = "ACTIVE"
    with pytest.raises(BladAllegro):
        allegro_http.HTTPSAllegro().wyslij(
            "POST", "https://api.allegro.pl/sale/product-offers", {}, json.dumps(bad).encode()
        )
    assert not calls


def test_czesciowy_odczyt_nie_blokuje_innych_list_i_nie_jest_pelnym_cache(sprzedaz_fixture):
    _, _, _, s, _, _, refs = sprzedaz_fixture
    replies = [
        odpowiedz(
            200,
            {
                "responsibleProducers": [{"id": refs.producenci[0].id, "name": "Producent"}],
                "totalCount": 1,
            },
        ),
        odpowiedz(200, {"responsiblePersons": [], "totalCount": 0}),
        odpowiedz(200, {"shippingRates": [{"id": refs.dostawy[0].id, "name": "Cennik"}]}),
        odpowiedz(200, {"returnPolicies": []}),
        odpowiedz(200, {"impliedWarranties": []}),
        odpowiedz(500, {}),
    ]
    t = Transport(*replies, odpowiedz(403, {}))
    api = NoweSzkiceAPI(t)
    result = api.slowniki_sprzedazy(s, True, True)
    assert len(result.producenci) == len(result.dostawy) == 1
    assert dict(result.bledy)["gwarancje"] and api._slowniki is None
    with pytest.raises(BladAllegro):
        api.slowniki_sprzedazy(s)
    assert len(t.calls) == 7


def test_blad_nieuzywanej_gwarancji_nie_blokuje_ale_blad_wybranego_producenta_blokuje(
    sprzedaz_fixture,
):
    from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import sprawdz_slowniki

    u = sprzedaz_fixture[5].sprzedaz
    refs = sprzedaz_fixture[-1]
    partial = replace(refs, gwarancje=(), bledy=(("gwarancje", "Błąd gwarancji"),))
    sprawdz_slowniki(u, partial)
    with pytest.raises(BladAllegro, match="Błąd producenta"):
        sprawdz_slowniki(
            u, replace(partial, producenci=(), bledy=(("producenci", "Błąd producenta"),))
        )
