"""Dane użytkownika do przygotowania kompletnego szkicu, bez publikacji."""

import re
from dataclasses import dataclass
from uuid import UUID

from vexlab.przypadki_uzycia.allegro import BladAllegro

CZASY = ("PT0S", "PT24H", "P2D", "P3D", "P4D", "P5D", "P7D", "P10D", "P14D", "P21D", "P30D", "P60D")
WOJEWODZTWA = (
    "DOLNOSLASKIE",
    "KUJAWSKO_POMORSKIE",
    "LUBELSKIE",
    "LUBUSKIE",
    "LODZKIE",
    "MALOPOLSKIE",
    "MAZOWIECKIE",
    "OPOLSKIE",
    "PODKARPACKIE",
    "PODLASKIE",
    "POMORSKIE",
    "SLASKIE",
    "SWIETOKRZYSKIE",
    "WARMINSKO_MAZURSKIE",
    "WIELKOPOLSKIE",
    "ZACHODNIOPOMORSKIE",
)


@dataclass(frozen=True)
class WyborSprzedazy:
    id: str
    nazwa: str
    opis: str = ""


@dataclass(frozen=True)
class SlownikiSprzedazy:
    producenci: tuple[WyborSprzedazy, ...]
    osoby: tuple[WyborSprzedazy, ...]
    dostawy: tuple[WyborSprzedazy, ...]
    zwroty: tuple[WyborSprzedazy, ...]
    reklamacje: tuple[WyborSprzedazy, ...]
    gwarancje: tuple[WyborSprzedazy, ...]
    bledy: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class UstawieniaSprzedazy:
    producent: str = ""
    osoba: str = ""  # 'nie_dotyczy' to jawny wybór użytkownika
    bezpieczenstwo: str = ""
    dostawa: str = ""
    czas: str = ""
    zwroty: str = ""
    reklamacje: str = ""
    gwarancja: str = ""  # 'brak' = jawny brak dodatkowej gwarancji
    kraj: str = ""
    miasto: str = ""
    kod: str = ""
    wojewodztwo: str = ""
    faktura: str = ""


def sprawdz_ustawienia(u: UstawieniaSprzedazy) -> tuple[str, ...]:
    bledy = []
    for nazwa, ident, pomijane in (
        ("producenta GPSR", u.producent, ""),
        ("osobę odpowiedzialną GPSR lub Nie dotyczy", u.osoba, "nie_dotyczy"),
        ("cennik dostaw", u.dostawa, ""),
        ("warunki zwrotów", u.zwroty, ""),
        ("warunki reklamacji", u.reklamacje, ""),
        ("gwarancję lub Brak dodatkowej gwarancji", u.gwarancja, "brak"),
    ):
        try:
            if not ident or ident != pomijane:
                UUID(ident)
        except (ValueError, AttributeError):
            bledy.append("Wybierz " + nazwa + ".")
    if not u.bezpieczenstwo.strip() or len(u.bezpieczenstwo) > 5000:
        bledy.append("Informacje o bezpieczeństwie: wymagany własny tekst do 5000 znaków.")
    if u.czas not in CZASY:
        bledy.append("Wybierz czas wysyłki.")
    if not re.fullmatch(r"[A-Z]{2}", u.kraj):
        bledy.append("Podaj dwuliterowy kod kraju nadania.")
    if not u.miasto.strip() or len(u.miasto) > 50:
        bledy.append("Podaj miejscowość nadania (do 50 znaków).")
    if (
        not u.kod.strip()
        or len(u.kod) > 12
        or (u.kraj == "PL" and not re.fullmatch(r"[0-9]{2}-[0-9]{3}", u.kod))
    ):
        bledy.append("Podaj poprawny kod pocztowy nadania.")
    if u.kraj == "PL" and u.wojewodztwo not in WOJEWODZTWA:
        bledy.append("Wybierz województwo nadania.")
    if u.faktura not in {"VAT", "VAT_MARGIN", "WITHOUT_VAT", "NO_INVOICE"}:
        bledy.append("Wybierz rodzaj faktury.")
    return tuple(bledy)


def sprawdz_slowniki(u: UstawieniaSprzedazy, s: SlownikiSprzedazy) -> None:
    for ident, lista, zwolnienie, pole in (
        (u.producent, s.producenci, "", "producenci"),
        (u.osoba, s.osoby, "nie_dotyczy", "osoby"),
        (u.dostawa, s.dostawy, "", "dostawy"),
        (u.zwroty, s.zwroty, "", "zwroty"),
        (u.reklamacje, s.reklamacje, "", "reklamacje"),
        (u.gwarancja, s.gwarancje, "brak", "gwarancje"),
    ):
        if ident != zwolnienie and ident not in {w.id for w in lista}:
            if pole in dict(s.bledy):
                raise BladAllegro("USTAWIENIA", dict(s.bledy)[pole])
            raise BladAllegro(
                "USTAWIENIA",
                "Wybrane ustawienie nie istnieje na tym koncie. Pobierz listy ponownie.",
            )


def pola_sprzedazy(u: UstawieniaSprzedazy) -> tuple[dict[str, object], dict[str, object]]:
    bledy = sprawdz_ustawienia(u)
    if bledy:
        raise BladAllegro("USTAWIENIA", "; ".join(bledy))
    gpsr: dict[str, object] = {
        "responsibleProducer": {"type": "ID", "id": u.producent},
        "responsiblePerson": {"id": u.osoba} if u.osoba != "nie_dotyczy" else None,
        "safetyInformation": {"type": "TEXT", "description": u.bezpieczenstwo.strip()},
    }
    after: dict[str, object] = {
        "returnPolicy": {"id": u.zwroty},
        "impliedWarranty": {"id": u.reklamacje},
    }
    if u.gwarancja != "brak":
        after["warranty"] = {"id": u.gwarancja}
    location = {"city": u.miasto.strip(), "countryCode": u.kraj, "postCode": u.kod.strip()}
    if u.kraj == "PL":
        location["province"] = u.wojewodztwo
    return (
        {
            "delivery": {"handlingTime": u.czas, "shippingRates": {"id": u.dostawa}},
            "location": location,
            "payments": {"invoice": u.faktura},
            "afterSalesServices": after,
        },
        gpsr,
    )


def potwierdz_pola(d: dict[str, object], u: UstawieniaSprzedazy) -> bool:
    oczekiwane, gpsr = pola_sprzedazy(u)

    def zawiera(actual: object, expected: object) -> bool:
        if isinstance(expected, dict):
            return isinstance(actual, dict) and all(
                zawiera(actual.get(k), v) for k, v in expected.items()
            )
        return actual == expected

    if not all(zawiera(d.get(k), v) for k, v in oczekiwane.items()):
        return False
    after = d.get("afterSalesServices")
    if u.gwarancja == "brak" and isinstance(after, dict) and after.get("warranty") is not None:
        return False
    produkty = d.get("productSet")
    first = produkty[0] if isinstance(produkty, list) and len(produkty) == 1 else None
    if not isinstance(first, dict):
        return False
    for key, value in gpsr.items():
        if key == "responsibleProducer":
            value = {"id": u.producent}  # odpowiedź nie ma dyskryminatora type
        if not zawiera(first.get(key), value):
            return False
    return True
