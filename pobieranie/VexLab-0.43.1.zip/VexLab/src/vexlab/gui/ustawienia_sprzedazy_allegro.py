"""Jedno okno GPSR/dostawy/warunków dla wskazanej grupy ofert."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import (
    CZASY,
    WOJEWODZTWA,
    SlownikiSprzedazy,
    UstawieniaSprzedazy,
    WyborSprzedazy,
    sprawdz_slowniki,
    sprawdz_ustawienia,
)


class DaneSprzedazyAllegro(QDialog):
    def __init__(
        self,
        parent: QWidget,
        slowniki: SlownikiSprzedazy,
        ustawienia: UstawieniaSprzedazy | None,
        liczba: int,
        pobierz: Callable[[], SlownikiSprzedazy] | None = None,
        uruchom: Uruchom | None = None,
        aktualne: Callable[[], bool] | None = None,
    ) -> None:
        super().__init__(parent)
        self.wynik: UstawieniaSprzedazy | None = None
        self._pobierz, self._uruchom, self._aktualne = pobierz, uruchom, aktualne
        self._zamkniete = self._laduje = False
        self._mozna_zapisac = pobierz is None
        self._slowniki = slowniki
        self.finished.connect(self._zakoncz)

        u = ustawienia or UstawieniaSprzedazy()
        self.setWindowTitle(f"GPSR, dostawa i warunki • {liczba} ofert")
        self.resize(850, 730)
        layout = QVBoxLayout(self)
        layout.addWidget(
            etykieta(
                f"Wspólne ustawienia dla {liczba} wskazanych ofert. "
                "SKU, EAN, ceny i ilości pozostają osobne."
            )
        )
        self.status = etykieta(
            "Pobieranie ustawień konta Allegro…" if pobierz else "Ustawienia konta Allegro"
        )
        layout.addWidget(self.status)
        self.odswiez = QPushButton("Pobierz listy ponownie")
        self.odswiez.setVisible(pobierz is not None)
        self.odswiez.clicked.connect(self.pobierz_listy)
        layout.addWidget(self.odswiez)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)

        def page(nazwa: str) -> QFormLayout:
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            host = QWidget()
            form = QFormLayout(host)
            form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
            form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
            scroll.setWidget(host)
            self.tabs.addTab(scroll, nazwa)
            return form

        def wybor(
            nazwa: str,
            rows: tuple[WyborSprzedazy, ...],
            current: str,
            wyjatek: tuple[str, str] | None = None,
        ) -> QComboBox:
            box = QComboBox()
            box.setAccessibleName(nazwa)
            box.setMinimumContentsLength(20)
            box.setSizeAdjustPolicy(
                QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
            )
            box.addItem("Wybierz…", "")
            if wyjatek:
                box.addItem(*wyjatek)
            for w in rows:
                box.addItem(w.nazwa + (" • " + w.opis if w.opis else ""), w.id)
                box.setItemData(box.count() - 1, w.opis, 3)
            box.setCurrentIndex(max(0, box.findData(current)))
            return box

        gpsr = page("1. GPSR")
        self.producent = wybor("Producent GPSR", slowniki.producenci, u.producent)
        self.osoba = wybor(
            "Osoba odpowiedzialna w UE",
            slowniki.osoby,
            u.osoba,
            ("Nie dotyczy — producent nie wymaga dodatkowej osoby", "nie_dotyczy"),
        )
        gpsr.addRow("Producent GPSR *", self.producent)
        gpsr.addRow("Osoba odpowiedzialna w UE *", self.osoba)
        self.bezpieczenstwo = QPlainTextEdit(u.bezpieczenstwo)
        self.bezpieczenstwo.setAccessibleName("Informacje o bezpieczeństwie produktu")
        self.bezpieczenstwo.setPlaceholderText(
            "Wklej ostrzeżenia i instrukcje bezpieczeństwa właściwe dla tych "
            "produktów (do 5000 znaków)."
        )
        self.bezpieczenstwo.setMinimumHeight(180)
        gpsr.addRow("Informacje o bezpieczeństwie *", self.bezpieczenstwo)
        gpsr.addRow(
            etykieta(
                "Dane pochodzą z rejestrów Twojego konta Allegro. Parametr "
                "kategorii „Producent” to osobne pole. Brakujący wpis dodaj w "
                "ustawieniach Allegro, potem pobierz listy ponownie."
            )
        )
        dostawa = page("2. Dostawa")
        self.dostawa = wybor("Cennik dostaw", slowniki.dostawy, u.dostawa)
        dostawa.addRow("Cennik dostaw *", self.dostawa)
        times = tuple(
            WyborSprzedazy(v, label)
            for v, label in zip(
                CZASY,
                (
                    "Natychmiast",
                    "24 godziny",
                    "2 dni",
                    "3 dni",
                    "4 dni",
                    "5 dni",
                    "7 dni",
                    "10 dni",
                    "14 dni",
                    "21 dni",
                    "30 dni",
                    "60 dni",
                ),
                strict=True,
            )
        )
        self.czas = wybor("Czas wysyłki", times, u.czas)
        dostawa.addRow("Czas wysyłki *", self.czas)
        self.kraj = QLineEdit(u.kraj)
        self.kraj.setMaxLength(2)
        self.kraj.setPlaceholderText("np. PL")
        self.miasto = QLineEdit(u.miasto)
        self.miasto.setMaxLength(50)
        self.kod = QLineEdit(u.kod)
        self.kod.setMaxLength(12)
        self.wojewodztwo = wybor(
            "Województwo nadania",
            tuple(WyborSprzedazy(v, v.replace("_", " ").title()) for v in WOJEWODZTWA),
            u.wojewodztwo,
        )
        for label, widget in (
            ("Kraj nadania *", self.kraj),
            ("Miejscowość *", self.miasto),
            ("Kod pocztowy *", self.kod),
            ("Województwo (Polska) *", self.wojewodztwo),
        ):
            widget.setAccessibleName(label)
            dostawa.addRow(label, widget)
        warunki = page("3. Warunki sprzedaży")
        self.zwroty = wybor("Warunki zwrotów", slowniki.zwroty, u.zwroty)
        self.reklamacje = wybor("Warunki reklamacji", slowniki.reklamacje, u.reklamacje)
        self.gwarancja = wybor(
            "Gwarancja", slowniki.gwarancje, u.gwarancja, ("Brak dodatkowej gwarancji", "brak")
        )
        self.faktura = wybor(
            "Rodzaj faktury",
            tuple(
                WyborSprzedazy(v, label)
                for v, label in (
                    ("VAT", "Faktura VAT"),
                    ("VAT_MARGIN", "Faktura VAT marża"),
                    ("WITHOUT_VAT", "Faktura bez VAT"),
                    ("NO_INVOICE", "Nie wystawiam faktury"),
                )
            ),
            u.faktura,
        )
        for label, widget in (
            ("Zwroty *", self.zwroty),
            ("Reklamacje *", self.reklamacje),
            ("Gwarancja *", self.gwarancja),
            ("Faktura *", self.faktura),
        ):
            warunki.addRow(label, widget)
        self.info = etykieta("Wypełnij trzy zakładki. Zapis ustawień nie uruchamia sprzedaży.")
        layout.addWidget(self.info)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText(f"Zastosuj do {liczba} ofert")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        self.zastosuj = buttons.button(QDialogButtonBox.StandardButton.Save)
        self.zastosuj.setEnabled(self._mozna_zapisac)
        self._oczekiwane = {
            key: getattr(u, attr)
            for key, attr in (
                ("producenci", "producent"),
                ("osoby", "osoba"),
                ("dostawy", "dostawa"),
                ("zwroty", "zwroty"),
                ("reklamacje", "reklamacje"),
                ("gwarancje", "gwarancja"),
            )
        }
        if pobierz is not None:
            QTimer.singleShot(0, self.pobierz_listy)
        buttons.accepted.connect(self.zapisz)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _zakoncz(self, _wynik: int) -> None:
        self._zamkniete = True

    def pobierz_listy(self) -> None:
        if self._zamkniete or self._laduje or self._pobierz is None or self._uruchom is None:
            return
        self._laduje = True
        self._mozna_zapisac = False
        self.zastosuj.setEnabled(False)
        self.odswiez.setEnabled(False)
        self.status.setText("Pobieranie ustawień konta Allegro… Możesz przeglądać zakładki.")

        def zywe() -> bool:
            if self._zamkniete:
                return False
            if self._aktualne is not None and not self._aktualne():
                self._laduje = False
                self.status.setText(
                    "Sesja konta zmieniła się. Zamknij formularz i otwórz go ponownie."
                )
                return False
            return True

        def sukces(w: object) -> None:
            if not zywe():
                return
            result = cast(SlownikiSprzedazy, w)
            self._laduje = False
            self._slowniki = result
            groups = (
                ("producenci", self.producent, "Producenci GPSR", None),
                (
                    "osoby",
                    self.osoba,
                    "Osoby odpowiedzialne",
                    ("Nie dotyczy — producent nie wymaga dodatkowej osoby", "nie_dotyczy"),
                ),
                ("dostawy", self.dostawa, "Cenniki dostaw", None),
                ("zwroty", self.zwroty, "Zwroty", None),
                ("reklamacje", self.reklamacje, "Reklamacje", None),
                ("gwarancje", self.gwarancja, "Gwarancje", ("Brak dodatkowej gwarancji", "brak")),
            )
            messages = []
            errors: dict[str, list[str]] = {}
            for key, box, label, special in groups:
                ident = str(box.currentData() or self._oczekiwane.get(key, ""))
                box.clear()
                box.addItem("Wybierz…", "")
                if special:
                    box.addItem(*special)
                rows = getattr(result, key)
                for value in rows:
                    box.addItem(value.nazwa + (" • " + value.opis if value.opis else ""), value.id)
                box.setCurrentIndex(max(0, box.findData(ident)))
                error = dict(result.bledy).get(key)
                if error:
                    errors.setdefault(error, []).append(label)
                elif not rows:
                    messages.append(label + ": brak zapisanych pozycji na koncie Allegro.")
                if not error:
                    self._oczekiwane.pop(key, None)
            messages = [
                ", ".join(labels) + ": " + error for error, labels in errors.items()
            ] + messages
            self._mozna_zapisac = True
            self.zastosuj.setEnabled(True)
            self.odswiez.setEnabled(True)
            self.status.setText(
                "\n".join(messages)
                if messages
                else "Listy pobrane. Wybierz ustawienia w trzech zakładkach."
            )

        def blad(kod: str, opis: str) -> None:
            if not zywe():
                return
            self._laduje = False
            self.odswiez.setEnabled(True)
            self.status.setText(
                "Nie pobrano ustawień: " + opis + "\nUżyj „Pobierz listy ponownie”."
            )

        self._uruchom(self._pobierz, sukces, blad)

    def zapisz(self) -> None:
        if not self._mozna_zapisac or self._laduje:
            self.info.setText(
                "Najpierw pobierz listy ustawień konta. Wpisane dane pozostają w formularzu."
            )
            return
        u = UstawieniaSprzedazy(
            str(self.producent.currentData()),
            str(self.osoba.currentData()),
            self.bezpieczenstwo.toPlainText().strip(),
            str(self.dostawa.currentData()),
            str(self.czas.currentData()),
            str(self.zwroty.currentData()),
            str(self.reklamacje.currentData()),
            str(self.gwarancja.currentData()),
            self.kraj.text().strip().upper(),
            self.miasto.text().strip(),
            self.kod.text().strip(),
            str(self.wojewodztwo.currentData()),
            str(self.faktura.currentData()),
        )
        bledy = sprawdz_ustawienia(u)
        if bledy:
            self.info.setText("\n".join(bledy))
            return
        try:
            sprawdz_slowniki(u, self._slowniki)
        except BladAllegro as exc:
            self.info.setText(str(exc))
            return
        self.wynik = u
        self.accept()
