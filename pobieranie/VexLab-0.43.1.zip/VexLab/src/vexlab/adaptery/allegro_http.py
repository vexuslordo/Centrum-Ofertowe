"""HTTPS wyłącznie do ustalonych hostów Allegro, bez przekierowań i logów treści."""

import json
import re
import time
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener
from uuid import UUID

from vexlab.przypadki_uzycia.allegro import BladAllegro, OdpowiedzAllegro


def _sprzedaz(pola: dict[str, Any]) -> None:
    fields = {"delivery", "location", "payments", "afterSalesServices"}
    if fields.intersection(pola):
        if not fields.issubset(pola):
            raise ValueError("niepełne ustawienia")
        delivery = pola["delivery"]
        if (
            not isinstance(delivery, dict)
            or set(delivery) != {"handlingTime", "shippingRates"}
            or delivery["handlingTime"]
            not in {
                "PT0S",
                "PT24H",
                "P2D",
                "P3D",
                "P4D",
                "P5D",
                "P7D",
                "P10D",
                "P14D",
                "P21D",
                "P30D",
                "P60D",
            }
        ):
            raise ValueError("delivery")
        for ref in (
            delivery["shippingRates"],
            pola["afterSalesServices"].get("returnPolicy"),
            pola["afterSalesServices"].get("impliedWarranty"),
        ):
            if not isinstance(ref, dict) or set(ref) != {"id"}:
                raise ValueError("id")
            UUID(ref["id"])
        after = pola["afterSalesServices"]
        if (
            not {"returnPolicy", "impliedWarranty"}
            <= set(after)
            <= {"returnPolicy", "impliedWarranty", "warranty"}
        ):
            raise ValueError("after")
        if "warranty" in after:
            if set(after["warranty"]) != {"id"}:
                raise ValueError("warranty")
            UUID(after["warranty"]["id"])
        if set(pola["payments"]) != {"invoice"} or pola["payments"]["invoice"] not in {
            "VAT",
            "VAT_MARGIN",
            "WITHOUT_VAT",
            "NO_INVOICE",
        }:
            raise ValueError("invoice")
        location = pola["location"]
        if (
            not {"city", "countryCode", "postCode"}
            <= set(location)
            <= {"city", "countryCode", "postCode", "province"}
        ):
            raise ValueError("location")
    product = pola["productSet"][0]
    gpsr = {"responsibleProducer", "responsiblePerson", "safetyInformation"}
    if gpsr.intersection(product):
        if not gpsr.issubset(product):
            raise ValueError("GPSR")
        producer = product["responsibleProducer"]
        if set(producer) != {"type", "id"} or producer["type"] != "ID":
            raise ValueError("producer")
        UUID(producer["id"])
        person = product["responsiblePerson"]
        if person is not None:
            if not isinstance(person, dict) or set(person) != {"id"}:
                raise ValueError("person")
            UUID(person["id"])
        safety = product["safetyInformation"]
        if (
            not isinstance(safety, dict)
            or set(safety) != {"type", "description"}
            or safety["type"] != "TEXT"
            or not isinstance(safety["description"], str)
            or not 1 <= len(safety["description"]) <= 5000
        ):
            raise ValueError("safety")


class CzasSystemowy:
    def teraz(self) -> float:
        return time.monotonic()


class BezPrzekierowan(HTTPRedirectHandler):
    def redirect_request(
        self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str
    ) -> Any:
        return None


class HTTPSAllegro:
    def wyslij(
        self, metoda: str, url: str, naglowki: dict[str, str], dane: bytes | None
    ) -> OdpowiedzAllegro:
        u = urlsplit(url)
        hosty = {
            "allegro.pl",
            "api.allegro.pl",
            "upload.allegro.pl",
            "upload.allegro.pl.allegrosandbox.pl",
            "allegro.pl.allegrosandbox.pl",
            "api.allegro.pl.allegrosandbox.pl",
        }
        if (
            u.scheme != "https"
            or u.netloc not in hosty
            or u.fragment
            or metoda not in {"GET", "POST", "PATCH"}
        ):
            raise BladAllegro("ADRES", "Niedozwolony adres integracji Allegro.")
        if metoda == "POST" and u.path not in {"/auth/oauth/device", "/auth/oauth/token"}:
            try:
                pola = json.loads(dane or b"")
                if not isinstance(pola, dict) or u.query:
                    raise ValueError("pola")
                if u.netloc in {"upload.allegro.pl", "upload.allegro.pl.allegrosandbox.pl"}:
                    if (
                        u.path != "/sale/images"
                        or set(pola) != {"url"}
                        or not isinstance(pola["url"], str)
                        or not pola["url"].startswith("https://")
                    ):
                        raise ValueError("upload")
                elif u.netloc in {"api.allegro.pl", "api.allegro.pl.allegrosandbox.pl"}:
                    if u.path != "/sale/product-offers" or pola.get("publication") != {
                        "status": "INACTIVE",
                        "republish": False,
                    }:
                        raise ValueError("publication")
                    if not set(pola) <= {
                        "name",
                        "productSet",
                        "category",
                        "parameters",
                        "stock",
                        "sellingMode",
                        "images",
                        "description",
                        "external",
                        "publication",
                        "delivery",
                        "location",
                        "payments",
                        "afterSalesServices",
                    }:
                        raise ValueError("pola")
                    produkty = pola.get("productSet")
                    if (
                        not isinstance(produkty, list)
                        or len(produkty) != 1
                        or not {"product"}
                        <= set(produkty[0])
                        <= {
                            "product",
                            "responsibleProducer",
                            "responsiblePerson",
                            "safetyInformation",
                        }
                    ):
                        raise ValueError("productSet")
                    gpsr = produkty[0]
                    if "responsibleProducer" in gpsr and (
                        not isinstance(gpsr["responsibleProducer"], dict)
                        or set(gpsr["responsibleProducer"]) != {"type", "id"}
                        or gpsr["responsibleProducer"].get("type") != "ID"
                    ):
                        raise ValueError("GPSR")
                    if "safetyInformation" in gpsr and (
                        not isinstance(gpsr["safetyInformation"], dict)
                        or set(gpsr["safetyInformation"]) != {"type", "description"}
                        or gpsr["safetyInformation"].get("type") != "TEXT"
                    ):
                        raise ValueError("GPSR")
                    _sprzedaz(pola)

                    produkt = produkty[0]["product"]
                    if set(produkt) == {"id"}:
                        UUID(produkt["id"])
                    elif set(produkt) == {"name", "category", "parameters", "images"}:
                        if (
                            not isinstance(produkt["name"], str)
                            or not 12 <= len(produkt["name"]) <= 75
                            or set(produkt["category"]) != {"id"}
                            or not re.fullmatch(r"[0-9]{1,100}", produkt["category"]["id"])
                            or not isinstance(produkt["parameters"], list)
                            or not isinstance(produkt["images"], list)
                            or not 1 <= len(produkt["images"]) <= 16
                            or not all(
                                isinstance(v, str) and v.startswith("https://")
                                for v in produkt["images"]
                            )
                        ):
                            raise ValueError("nowy produkt")
                    else:
                        raise ValueError("product")
                else:
                    raise ValueError("host")
            except (ValueError, UnicodeError, TypeError, KeyError, AttributeError):
                raise BladAllegro(
                    "POLA",
                    "Dozwolone wyłącznie zdjęcia i nowe szkice INACTIVE z "
                    "UUID lub jawną definicją produktu Allegro.",
                ) from None
        if metoda == "PATCH":
            if (
                not u.netloc.startswith("api.")
                or u.query
                or not re.fullmatch(r"/sale/product-offers/[0-9]{1,100}", u.path)
            ):
                raise BladAllegro("ADRES", "Niedozwolony zapis Allegro.")
            try:
                pola = json.loads(dane or b"")
                sku = pola.get("external") if isinstance(pola, dict) else None
                tylko_sku = (
                    isinstance(pola, dict)
                    and set(pola) == {"external"}
                    and isinstance(sku, dict)
                    and set(sku) == {"id"}
                    and isinstance(sku["id"], str)
                    and 0 < len(sku["id"]) <= 100
                )
                if not tylko_sku and (
                    not isinstance(pola, dict)
                    or not pola
                    or not set(pola) <= {"name", "description"}
                ):
                    raise ValueError("pola")
            except (ValueError, UnicodeError):
                raise BladAllegro("POLA", "Niedozwolone pola zapisu Allegro.") from None
        opener = build_opener(ProxyHandler(), HTTPSHandler(), BezPrzekierowan())
        req = Request(url, data=dane, headers=naglowki, method=metoda)
        try:
            try:
                response = opener.open(req, timeout=20)  # nosec B310: HTTPS i stała lista hostów
            except HTTPError as exc:
                response = exc
            with response:
                body = response.read(2 * 1024 * 1024 + 1)
                if len(body) > 2 * 1024 * 1024:
                    raise BladAllegro("ROZMIAR", "Odpowiedź Allegro przekracza limit rozmiaru.")
                retry = response.headers.get("Retry-After", "")
                odstep = int(retry) if re.fullmatch(r"[0-9]{1,9}", retry) else 5
                return OdpowiedzAllegro(
                    response.code, body, response.headers.get("Location", ""), odstep
                )
        except (URLError, OSError, TimeoutError):
            raise BladAllegro(
                "SIEC", "Brak odpowiedzi Allegro. Sprawdź połączenie i spróbuj ponownie."
            ) from None
