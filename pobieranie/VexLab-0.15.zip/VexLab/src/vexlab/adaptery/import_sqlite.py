"""Atomowy zapis paczki i trwałego bufora korekt w tej samej bazie katalogu."""

import json
import sqlite3
from dataclasses import replace
from pathlib import Path
from uuid import UUID, uuid4

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.domena.produkt import KonfliktEdycji, Produkt
from vexlab.przypadki_uzycia.importowanie import (
    CenaImportu,
    PozycjaImportu,
    UzupelnienieCeny,
    WynikImportu,
    blad,
)
from vexlab.przypadki_uzycia.katalog import DaneDopasowania, DaneProduktu, _dopasowania
from vexlab.rdzen.kontrakty import BladTechniczny


class ImportSQLite(KatalogSQLite):
    @staticmethod
    def _surowe_dopasowania(dane: DaneProduktu) -> str:
        return json.dumps(
            [[d.marka, d.model, d.rok_od, d.rok_do, d.wariant] for d in dane.dopasowania or ()],
            ensure_ascii=False,
        )

    @staticmethod
    def _wczytaj_dopasowania(tekst: str) -> tuple[DaneDopasowania, ...]:
        try:
            wartosci = json.loads(tekst)
            if not isinstance(wartosci, list) or any(
                not isinstance(w, list) or len(w) != 5 or any(not isinstance(x, str) for x in w)
                for w in wartosci
            ):
                raise ValueError("Nieprawidłowa struktura")
            return tuple(DaneDopasowania(*w) for w in wartosci)
        except (ValueError, TypeError) as exc:
            raise BladTechniczny(
                "Nie można odczytać dopasowań pozycji Do poprawy. Zachowaj kopię bazy."
            ) from exc

    @staticmethod
    def _dodaj_importowany(conn: sqlite3.Connection, p: PozycjaImportu) -> UUID:
        produkt = Produkt(
            uuid4(),
            p.dane.nazwa.strip(),
            p.dane.sku.strip(),
            p.dane.opis,
            producent_id=p.dane.producent_id,
            dopasowania=_dopasowania(p.dane.dopasowania or ()),
        )
        KatalogSQLite._sprawdz_przypisanie(conn, produkt, None)
        conn.execute(
            "INSERT INTO produkty (id,nazwa,sku,sku_klucz,opis,wersja,producent_id) "
            "VALUES (?,?,?,?,?,?,?)",
            (
                str(produkt.id),
                produkt.nazwa,
                produkt.sku,
                produkt.klucz_sku,
                produkt.opis,
                1,
                str(produkt.producent_id) if produkt.producent_id else None,
            ),
        )

        KatalogSQLite._zapisz_dopasowania(conn, produkt)
        if p.cena is not None:
            try:
                cena = p.cena.sprawdz()
            except ValueError as exc:
                raise blad(str(exc)) from exc
            if cena is not None:
                conn.execute(
                    "INSERT INTO ceny_sugerowane VALUES (?,?,?,?,?)",
                    (
                        str(produkt.id),
                        format(cena.kwota, "f"),
                        cena.waluta,
                        cena.rodzaj,
                        f"{p.zrodlo} / {p.arkusz} / {p.wiersz}",
                    ),
                )
        return produkt.id

    def zatwierdz_paczke(
        self, pozycje: tuple[PozycjaImportu, ...], wybrane: frozenset[UUID]
    ) -> WynikImportu:
        if not pozycje or len({p.paczka for p in pozycje}) != 1:
            raise blad("Nieprawidłowa paczka.")
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            if conn.execute(
                "SELECT 1 FROM importy WHERE id=?", (str(pozycje[0].paczka),)
            ).fetchone():
                raise blad("Ta paczka została już zapisana. Odśwież katalog i listę Do poprawy.")
            wynik = WynikImportu(len(wybrane), len(pozycje) - len(wybrane))
            conn.execute(
                "INSERT INTO importy VALUES (?,?,?,?,?)",
                (
                    str(pozycje[0].paczka),
                    pozycje[0].zrodlo,
                    pozycje[0].arkusz,
                    wynik.dodane,
                    wynik.odlozone,
                ),
            )
            for p in pozycje:
                if p.id in wybrane:
                    pid = self._dodaj_importowany(conn, p)
                    self._powiaz(conn, p, pid, "dodano")
                else:
                    conn.execute(
                        "INSERT INTO import_robocze VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (
                            str(p.id),
                            str(p.paczka),
                            p.wiersz,
                            p.dane.nazwa,
                            p.dane.sku,
                            p.dane.opis,
                            str(p.dane.producent_id) if p.dane.producent_id else None,
                            p.powod,
                            p.wersja,
                            p.cena.tekst if p.cena else "",
                            p.cena.waluta if p.cena else "",
                            p.cena.rodzaj if p.cena else "",
                            self._surowe_dopasowania(p.dane),
                        ),
                    )
        return wynik

    def oczekujace(self) -> tuple[PozycjaImportu, ...]:
        with self._polaczenie() as conn:
            rows = conn.execute(
                "SELECT r.*,i.zrodlo,i.arkusz FROM import_robocze r "
                "JOIN importy i ON r.paczka=i.id ORDER BY r.paczka,r.wiersz"
            ).fetchall()
        return tuple(
            PozycjaImportu(
                UUID(r["id"]),
                UUID(r["paczka"]),
                r["zrodlo"],
                r["arkusz"],
                r["wiersz"],
                DaneProduktu(
                    r["nazwa"],
                    r["sku"],
                    r["opis"],
                    UUID(r["producent_id"]) if r["producent_id"] else None,
                    self._wczytaj_dopasowania(r["dopasowania_json"]),
                ),
                r["powod"],
                r["wersja"],
                CenaImportu(r["cena_tekst"], r["cena_waluta"], r["cena_rodzaj"])
                if r["cena_tekst"] or r["cena_waluta"]
                else None,
            )
            for r in rows
        )

    @staticmethod
    def _sprawdz_wersje(conn: sqlite3.Connection, p: PozycjaImportu) -> None:
        row = conn.execute("SELECT wersja FROM import_robocze WHERE id=?", (str(p.id),)).fetchone()
        if row is None or row[0] != p.wersja:
            raise blad("Pozycja została zmieniona lub rozstrzygnięta. Odśwież listę Do poprawy.")

    def usun_oczekujace(self, pozycje: tuple[PozycjaImportu, ...]) -> Path:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            for p in pozycje:
                self._sprawdz_wersje(conn, p)
            kopia = self._kopia_spojna("kopie_importow")
            conn.executemany(
                "DELETE FROM import_robocze WHERE id=?",
                ((str(p.id),) for p in pozycje),
            )
        return kopia

    def popraw(self, pozycja: PozycjaImportu) -> None:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            self._sprawdz_wersje(conn, pozycja)
            p = replace(pozycja, powod="Poprawiono ręcznie — wymaga zatwierdzenia")
            conn.execute(
                "UPDATE import_robocze SET nazwa=?,sku=?,opis=?,producent_id=?,powod=?,"
                "cena_tekst=?,cena_waluta=?,cena_rodzaj=?,dopasowania_json=?,"
                "wersja=wersja+1 WHERE id=?",
                (
                    p.dane.nazwa,
                    p.dane.sku,
                    p.dane.opis,
                    str(p.dane.producent_id) if p.dane.producent_id else None,
                    p.powod,
                    p.cena.tekst if p.cena else "",
                    p.cena.waluta if p.cena else "",
                    p.cena.rodzaj if p.cena else "",
                    self._surowe_dopasowania(p.dane),
                    str(p.id),
                ),
            )

    def rozstrzygnij(self, pozycja: PozycjaImportu, produkt: UUID | None) -> None:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            self._sprawdz_wersje(conn, pozycja)
            if produkt is None:
                pid = self._dodaj_importowany(conn, pozycja)
                self._powiaz(conn, pozycja, pid, "dodano")
            else:
                row = conn.execute(
                    "SELECT sku_klucz FROM produkty WHERE id=?", (str(produkt),)
                ).fetchone()
                if row is None:
                    raise KonfliktEdycji("Wybrany Produkt nie istnieje. Odśwież katalog.")
                if not pozycja.dane.sku.strip() or row[0] != pozycja.dane.sku.strip().casefold():
                    raise blad("Powiązanie wymaga zgodnego SKU. Popraw symbol lub wybór Produktu.")
                self._powiaz(conn, pozycja, produkt, "powiazano")
            conn.execute("DELETE FROM import_robocze WHERE id=?", (str(pozycja.id),))

    @staticmethod
    def _powiaz(conn: sqlite3.Connection, p: PozycjaImportu, pid: UUID, tryb: str) -> None:
        conn.execute(
            "INSERT INTO import_powiazania VALUES (?,?,?,?,?)",
            (str(p.id), str(p.paczka), p.wiersz, str(pid), tryb),
        )

    def uzupelnij_ceny(self, pozycje: tuple[UzupelnienieCeny, ...]) -> Path:
        if not pozycje or len({p.produkt_id for p in pozycje}) != len(pozycje):
            raise blad("Nieprawidłowy zakres uzupełniania cen.")
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            for p in pozycje:
                row = conn.execute(
                    "SELECT wersja FROM produkty WHERE id=?", (str(p.produkt_id),)
                ).fetchone()
                jest = conn.execute(
                    "SELECT 1 FROM ceny_sugerowane WHERE produkt_id=?", (str(p.produkt_id),)
                ).fetchone()
                if row is None or row[0] != p.wersja or jest:
                    raise KonfliktEdycji(
                        "Katalog lub ceny zmieniły się. Przygotuj podgląd ponownie."
                    )
            kopia = self._kopia_spojna("kopie_cen")
            for p in pozycje:
                try:
                    cena = p.cena.sprawdz()
                except ValueError as exc:
                    raise blad(str(exc)) from exc
                if cena is None:
                    raise blad("Brak ceny do uzupełnienia.")
                conn.execute(
                    "INSERT INTO ceny_sugerowane VALUES (?,?,?,?,?)",
                    (
                        str(p.produkt_id),
                        format(cena.kwota, "f"),
                        cena.waluta,
                        cena.rodzaj,
                        p.zrodlo,
                    ),
                )
                conn.execute("UPDATE produkty SET wersja=wersja+1 WHERE id=?", (str(p.produkt_id),))
        return kopia
