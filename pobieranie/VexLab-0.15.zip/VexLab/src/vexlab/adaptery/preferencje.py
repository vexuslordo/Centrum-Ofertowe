"""Techniczne ustawienia Qt poza repozytorium; żadnych danych biznesowych."""

import getpass

from PySide6.QtCore import QSettings

from vexlab.przypadki_uzycia.powloka import Motyw, PreferencjePowloki
from vexlab.rdzen.kontrakty import BladTechniczny


class PreferencjeQt:
    def __init__(self, ustawienia: QSettings) -> None:
        self._ustawienia = ustawienia

    def odczytaj(self) -> PreferencjePowloki:
        self._ustawienia.sync()
        self._sprawdz_status()
        try:
            motyw = Motyw(str(self._ustawienia.value("wyglad/motyw", Motyw.CIEMNY.value)))
        except ValueError:
            motyw = Motyw.CIEMNY
        zwiniete = bool(self._ustawienia.value("wyglad/menu_zwiniete", False, type=bool))
        return PreferencjePowloki(motyw, zwiniete)

    def zapisz(self, preferencje: PreferencjePowloki) -> None:
        self._ustawienia.setValue("wyglad/motyw", preferencje.motyw.value)
        self._ustawienia.setValue("wyglad/menu_zwiniete", preferencje.menu_zwiniete)
        self._ustawienia.sync()
        self._sprawdz_status()

    def _sprawdz_status(self) -> None:
        if self._ustawienia.status() != QSettings.Status.NoError:
            raise BladTechniczny("Nie można odczytać lub zapisać ustawień wyglądu.")


def nazwa_uzytkownika_systemu() -> str:
    try:
        return getpass.getuser()
    except (OSError, KeyError) as blad:
        raise BladTechniczny("Nie można odczytać nazwy użytkownika systemu.") from blad
