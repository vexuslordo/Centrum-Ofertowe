"""Publiczny katalog Shopify. Domena pochodzi wyłącznie od użytkownika."""

import ipaddress
import json
import socket
from typing import Any, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener

from vexlab.adaptery.obraz import obraz as obraz
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.media import KandydaciZdjec


def blad(tekst: str) -> BladScenariuszaKatalogu:
    return BladScenariuszaKatalogu("MEDIA", tekst)


def adres_https(url: str) -> str:
    try:
        if len(url) > 4096:
            raise ValueError()
        u = urlsplit(url)
        if (
            u.scheme != "https"
            or not u.hostname
            or u.username
            or u.password
            or u.port not in (None, 443)
        ):
            raise ValueError()
        host = u.hostname.lower()
        if host == "localhost" or host.endswith((".localhost", ".local")):
            raise ValueError()
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            if "." not in host:
                raise ValueError() from None
        else:
            if not ip.is_global or ip.is_multicast:
                raise ValueError()
    except ValueError as exc:
        raise blad("Dozwolony jest publiczny adres HTTPS bez danych logowania.") from exc
    return url


class TransportPubliczny(Protocol):
    def odczytaj(self, url: str, limit: int) -> bytes: ...


class BezpiecznePrzekierowania(HTTPRedirectHandler):
    def redirect_request(
        self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str
    ) -> Any:
        adres_https(newurl)
        sprawdz_dns(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def sprawdz_dns(url: str) -> None:
    host = urlsplit(url).hostname
    if not host:
        raise blad("Brak hosta strony.")
    try:
        wyniki = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        if not wyniki or any(
            (
                not ipaddress.ip_address(w[4][0]).is_global
                or ipaddress.ip_address(w[4][0]).is_multicast
            )
            for w in wyniki
        ):
            raise blad("Źródło nie wskazuje publicznej witryny.")
    except OSError as exc:
        raise blad("Nie można rozpoznać adresu źródła zdjęć.") from exc


class TransportHTTPS:
    def odczytaj(self, url: str, limit: int) -> bytes:
        adres_https(url)
        sprawdz_dns(url)
        try:
            # ProxyHandler zachowuje systemowe/inherited proxy; HTTPS weryfikuje TLS.
            opener = build_opener(ProxyHandler(), HTTPSHandler(), BezpiecznePrzekierowania())
            request = Request(
                url,
                headers={
                    "User-Agent": "VexLab product media reader",
                    "Accept": "application/json,image/*",
                },
            )
            with opener.open(request, timeout=20) as response:  # nosec B310
                # B310: schemat HTTPS sprawdzony również dla każdego przekierowania.
                dane: bytes = response.read(limit + 1)
                if len(dane) > limit:
                    raise blad("Odpowiedź źródła przekracza limit rozmiaru.")
                return dane
        except HTTPError as exc:
            raise blad(
                f"Źródło zdjęć zwróciło HTTP {exc.code}. Nie zapisano nowych zdjęć."
            ) from exc
        except (URLError, OSError, TimeoutError) as exc:
            raise blad(
                "Nie można pobrać zdjęć. Sprawdź sieć, adres i obsługę katalogu Shopify."
            ) from exc


class ZdjeciaShopify:
    def __init__(self, transport: TransportPubliczny) -> None:
        self.transport = transport

    def _json(self, url: str) -> dict[str, Any]:
        try:
            result = json.loads(self.transport.odczytaj(url, 2 * 1024 * 1024))
            if not isinstance(result, dict):
                raise ValueError()
            return result
        except (ValueError, TypeError) as exc:
            raise blad("Źródło nie udostępniło poprawnego katalogu JSON Shopify.") from exc

    def pobierz(self, strona: str, sku: str) -> KandydaciZdjec:
        adres_https(strona)
        u = urlsplit(strona)
        if u.query or u.fragment:
            raise blad("Podaj adres główny sklepu bez parametrów.")
        baza = strona.rstrip("/") + "/"
        query = urlencode({"q": sku, "resources[type]": "product", "resources[limit]": "5"})
        sugestie = self._json(urljoin(baza, "search/suggest.json") + "?" + query)
        try:
            produkty = sugestie["resources"]["results"]["products"]
            if not isinstance(produkty, list):
                raise ValueError()
            znalezione = []
            for item in produkty[:5]:
                if not isinstance(item, dict) or not isinstance(item.get("url"), str):
                    raise ValueError()
                url = urljoin(baza, item["url"])
                parsed = urlsplit(url)
                if parsed.hostname != u.hostname or "/products/" not in parsed.path:
                    raise ValueError()
                karta = parsed._replace(query="", fragment="").geturl()
                produkt = self._json(karta.rstrip("/") + ".js")
                variants = produkt.get("variants", [])
                if not isinstance(variants, list):
                    raise ValueError()
                trafienia = [
                    v
                    for v in variants
                    if isinstance(v, dict)
                    and isinstance(v.get("sku"), str)
                    and v["sku"].strip().casefold() == sku.casefold()
                ]
                if len(trafienia) > 1:
                    raise blad("SKU nie jest jednoznaczne w wariantach. Nie przypisano zdjęć.")
                if trafienia:
                    znalezione.append((karta, produkt, trafienia[0]))
            # Dedup identycznych kart w podpowiedziach.
            unikalne = {k: p for k, *p in znalezione}
            if len(unikalne) != 1:
                raise blad("Brak jednoznacznego produktu o dokładnie takim SKU w katalogu źródła.")
            karta, (produkt, wariant) = next(iter(unikalne.items()))
            images = produkt.get("images", [])
            featured = wariant.get("featured_image")
            if isinstance(featured, dict) and isinstance(featured.get("src"), str):
                images = [featured["src"]] + images
            if not isinstance(images, list):
                raise ValueError()
            urls = []
            for src in images:
                if isinstance(src, str):
                    url = adres_https(urljoin(karta, src))
                    if url not in urls:
                        urls.append(url)
            if not urls:
                raise blad("Znaleziono SKU, ale źródło nie udostępniło zdjęć.")
            photos = tuple(
                obraz(self.transport.odczytaj(url, 8 * 1024 * 1024), url) for url in urls[:5]
            )
            return KandydaciZdjec(karta, str(produkt.get("title", ""))[:1000], sku, photos)
        except (KeyError, TypeError, ValueError) as exc:
            raise blad("Nieobsługiwana struktura katalogu producenta. Nie zapisano zdjęć.") from exc
