"""Pobranie kandydatów zdjęć za portem; zapis dopiero po akceptacji użytkownika."""

from dataclasses import dataclass
from typing import Protocol

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu


@dataclass(frozen=True)
class ZdjecieDane:
    zrodlo: str
    dane: bytes
    miniatura: bytes


@dataclass(frozen=True)
class KandydaciZdjec:
    strona_produktu: str
    tytul: str
    sku: str
    zdjecia: tuple[ZdjecieDane, ...]


class ZrodloZdjec(Protocol):
    def pobierz(self, strona: str, sku: str) -> KandydaciZdjec: ...


class PobierzZdjecia:
    def __init__(self, zrodlo: ZrodloZdjec) -> None:
        self.zrodlo = zrodlo

    def wykonaj(self, strona: str, sku: str) -> KandydaciZdjec:
        if not strona.strip() or not sku.strip():
            raise BladScenariuszaKatalogu("MEDIA", "Wpisz adres HTTPS producenta i SKU.")
        return self.zrodlo.pobierz(strona.strip(), sku.strip())
