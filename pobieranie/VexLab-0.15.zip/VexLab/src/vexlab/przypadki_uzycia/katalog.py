"""Port katalogu i małe lokalne scenariusze. Brak obiektów Qt i SQL."""

from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from uuid import UUID, uuid4

from vexlab.domena.producent import ProducentNieaktywny, ProducentNieIstnieje
from vexlab.domena.produkt import (
    BladKatalogu,
    DopasowanieMotocykla,
    KonfliktEdycji,
    NieprawidlowyProdukt,
    Produkt,
    ProduktNieIstnieje,
    SKUJuzIstnieje,
)
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu as BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.producenci import ProducentDTO, RepozytoriumProducentow, producent_dto


@contextmanager
def _mapuj_bledy() -> Iterator[None]:
    try:
        yield
    except BladKatalogu as blad:
        kody = {
            NieprawidlowyProdukt: "WALIDACJA",
            SKUJuzIstnieje: "SKU_ZAJETE",
            KonfliktEdycji: "KONFLIKT_WERSJI",
            ProduktNieIstnieje: "NIE_ZNALEZIONO",
            ProducentNieIstnieje: "PRODUCENT_NIE_ISTNIEJE",
            ProducentNieaktywny: "PRODUCENT_NIEAKTYWNY",
        }
        kod = kody[type(blad)]
        if isinstance(blad, NieprawidlowyProdukt) and blad.pole is not None:
            kod = f"WALIDACJA_{blad.pole.upper()}"
        raise BladScenariuszaKatalogu(kod, str(blad)) from blad


@dataclass(frozen=True)
class DaneDopasowania:
    marka: str
    model: str
    rok_od: str = ""
    rok_do: str = ""
    wariant: str = ""

    @property
    def etykieta(self) -> str:
        roczniki = f"od: {self.rok_od or 'brak'}, do: {self.rok_do or 'brak'}"
        return " • ".join(
            (self.marka or "[brak marki]", self.model or "[brak modelu]", roczniki, self.wariant)
        ).rstrip(" •")


@dataclass(frozen=True)
class DopasowanieDTO:
    marka: str
    model: str
    rok_od: int | None = None
    rok_do: int | None = None
    wariant: str = ""

    @property
    def etykieta(self) -> str:
        lata = "roczniki niepodane"
        if self.rok_od is not None:
            lata = (
                f"{self.rok_od}–{self.rok_do}"
                if self.rok_do is not None
                else f"od {self.rok_od}, koniec niepodany"
            )
        return " • ".join(x for x in (self.marka, self.model, lata, self.wariant) if x)


def _dopasowania(dane: tuple[DaneDopasowania, ...]) -> tuple[DopasowanieMotocykla, ...]:
    wynik = []
    for d in dane:
        if not any(x.strip() for x in (d.marka, d.model, d.rok_od, d.rok_do, d.wariant)):
            continue
        try:
            rok_od = int(d.rok_od.strip()) if d.rok_od.strip() else None
            rok_do = int(d.rok_do.strip()) if d.rok_do.strip() else None
        except ValueError as exc:
            raise NieprawidlowyProdukt(
                "Roczniki muszą być liczbami całkowitymi.", "dopasowania"
            ) from exc
        wynik.append(
            DopasowanieMotocykla(
                d.marka.strip(), d.model.strip(), rok_od, rok_do, d.wariant.strip()
            )
        )
    return tuple(wynik)


@dataclass(frozen=True)
class DaneProduktu:
    nazwa: str
    sku: str
    opis: str = ""
    producent_id: UUID | None = None
    dopasowania: tuple[DaneDopasowania, ...] | None = None


@dataclass(frozen=True)
class CenaSugerowanaDTO:
    kwota: str
    waluta: str
    rodzaj: str
    zrodlo: str

    @property
    def etykieta(self) -> str:
        return f"{self.kwota.replace('.', ',')} {self.waluta} {self.rodzaj}"


@dataclass(frozen=True)
class ProduktDTO:
    id: UUID
    nazwa: str
    sku: str
    opis: str
    wersja: int
    producent_id: UUID | None = None
    producent_nazwa: str | None = None
    cena_sugerowana: CenaSugerowanaDTO | None = None
    miniatura: bytes | None = None
    dopasowania: tuple[DopasowanieDTO, ...] = ()


@dataclass(frozen=True)
class WidokKatalogu:
    produkty: tuple[ProduktDTO, ...]
    producenci: tuple[ProducentDTO, ...]


class RepozytoriumProduktow(Protocol):
    def wyszukaj(self, fraza: str) -> list[Produkt]: ...

    def pobierz(self, id_produktu: UUID) -> Produkt | None: ...

    def dodaj(self, produkt: Produkt) -> None: ...

    def zapisz(self, produkt: Produkt, oczekiwana_wersja: int) -> None: ...

    def wykonaj_kopie(self, cel: Path) -> None: ...

    def ceny_sugerowane(self) -> dict[UUID, CenaSugerowanaDTO]: ...

    def usun_produkty(self, produkty: tuple[tuple[UUID, int], ...]) -> Path: ...

    def zapisz_wiele(self, produkty: tuple[Produkt, ...]) -> Path: ...

    def miniatury(self) -> dict[UUID, bytes]: ...

    def dodaj_z_mediami(self, produkt: Produkt, zdjecia: tuple[ZdjecieDane, ...]) -> None: ...

    def zapisz_z_mediami(
        self, produkt: Produkt, wersja: int, zdjecia: tuple[ZdjecieDane, ...]
    ) -> None: ...


def _dto(
    produkt: Produkt,
    nazwy: dict[UUID, str],
    cena: CenaSugerowanaDTO | None = None,
    miniatura: bytes | None = None,
) -> ProduktDTO:
    return ProduktDTO(
        produkt.id,
        produkt.nazwa,
        produkt.sku,
        produkt.opis,
        produkt.wersja,
        produkt.producent_id,
        nazwy.get(produkt.producent_id) if produkt.producent_id else None,
        cena,
        miniatura,
        tuple(
            DopasowanieDTO(d.marka, d.model, d.rok_od, d.rok_do, d.wariant)
            for d in produkt.dopasowania
        ),
    )


@dataclass(frozen=True)
class ZmianaMasowa:
    zmien_producenta: bool = False
    producent_id: UUID | None = None
    opis_tryb: str = "bez_zmian"
    opis: str = ""
    dolacz_nazwe: bool = False


class KatalogProduktow:
    def __init__(
        self, repozytorium: RepozytoriumProduktow, producenci: RepozytoriumProducentow
    ) -> None:
        self._repozytorium = repozytorium
        self._producenci = producenci

    def _nazwy(self) -> dict[UUID, str]:
        return {p.id: p.nazwa for p in self._producenci.lista_producentow()}

    def wyszukaj(self, fraza: str = "") -> list[ProduktDTO]:
        return list(self.odczytaj(fraza).produkty)

    def odczytaj(self, fraza: str = "") -> WidokKatalogu:
        produkty = self._repozytorium.wyszukaj(fraza.strip())
        producenci = self._producenci.lista_producentow()
        nazwy = {p.id: p.nazwa for p in producenci}
        ceny = self._repozytorium.ceny_sugerowane()
        miniatury = self._repozytorium.miniatury()
        return WidokKatalogu(
            tuple(_dto(p, nazwy, ceny.get(p.id), miniatury.get(p.id)) for p in produkty),
            tuple(producent_dto(p) for p in producenci),
        )

    def dodaj(self, dane: DaneProduktu, zdjecia: tuple[ZdjecieDane, ...] = ()) -> ProduktDTO:
        with _mapuj_bledy():
            produkt = Produkt(
                uuid4(),
                dane.nazwa.strip(),
                dane.sku.strip(),
                dane.opis,
                producent_id=dane.producent_id,
                dopasowania=_dopasowania(dane.dopasowania or ()),
            )
            nazwy = self._nazwy() if dane.producent_id is not None else {}
            if zdjecia:
                self._repozytorium.dodaj_z_mediami(produkt, zdjecia)
            else:
                self._repozytorium.dodaj(produkt)
            return _dto(produkt, nazwy)

    def edytuj(
        self,
        id_produktu: UUID,
        wersja: int,
        dane: DaneProduktu,
        zdjecia: tuple[ZdjecieDane, ...] = (),
    ) -> ProduktDTO:
        with _mapuj_bledy():
            produkt = self._repozytorium.pobierz(id_produktu)
            if produkt is None:
                raise ProduktNieIstnieje("Produkt nie istnieje. Odśwież katalog.")
            if produkt.wersja != wersja:
                raise KonfliktEdycji(
                    "Produkt zmieniono w innym formularzu. Odśwież dane przed edycją."
                )
            nowy = produkt.zmien(
                dane.nazwa.strip(),
                dane.sku.strip(),
                dane.opis,
                dane.producent_id,
                None if dane.dopasowania is None else _dopasowania(dane.dopasowania),
            )
            nazwy = self._nazwy() if dane.producent_id is not None else {}
            if zdjecia:
                self._repozytorium.zapisz_z_mediami(nowy, wersja, zdjecia)
            else:
                self._repozytorium.zapisz(nowy, wersja)
            return _dto(nowy, nazwy)

    def utworz_kopie(self, cel: Path) -> None:
        self._repozytorium.wykonaj_kopie(cel)

    def usun(self, produkty: tuple[ProduktDTO, ...]) -> Path:
        if not produkty:
            raise BladScenariuszaKatalogu("BRAK_DANYCH", "Brak Produktów do usunięcia.")
        with _mapuj_bledy():
            return self._repozytorium.usun_produkty(tuple((p.id, p.wersja) for p in produkty))

    def zmien_masowo(self, produkty: tuple[ProduktDTO, ...], zmiana: ZmianaMasowa) -> Path:
        if not produkty or (
            not zmiana.zmien_producenta
            and zmiana.opis_tryb == "bez_zmian"
            and not zmiana.dolacz_nazwe
        ):
            raise BladScenariuszaKatalogu("WALIDACJA", "Wybierz Produkty i pola do zmiany.")
        if zmiana.opis_tryb not in ("bez_zmian", "zastap", "dopisz", "wyczysc"):
            raise BladScenariuszaKatalogu("WALIDACJA", "Nieprawidłowy tryb zmiany opisu.")
        nowe = []
        with _mapuj_bledy():
            for dto in produkty:
                p = Produkt(
                    dto.id,
                    dto.nazwa,
                    dto.sku,
                    dto.opis,
                    dto.wersja,
                    dto.producent_id,
                    tuple(
                        DopasowanieMotocykla(d.marka, d.model, d.rok_od, d.rok_do, d.wariant)
                        for d in dto.dopasowania
                    ),
                )
                opis = p.opis
                if zmiana.opis_tryb == "zastap":
                    opis = zmiana.opis
                elif zmiana.opis_tryb == "dopisz":
                    opis = "\n\n".join(x for x in (p.opis, zmiana.opis) if x.strip())
                elif zmiana.opis_tryb == "wyczysc":
                    opis = ""
                if zmiana.dolacz_nazwe and p.nazwa not in opis:
                    opis = "\n\n".join(x for x in (opis, p.nazwa) if x.strip())
                nowe.append(
                    p.zmien(
                        p.nazwa,
                        p.sku,
                        opis,
                        zmiana.producent_id if zmiana.zmien_producenta else p.producent_id,
                    )
                )
            return self._repozytorium.zapisz_wiele(tuple(nowe))
