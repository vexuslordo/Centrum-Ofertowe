"""Plan i atomowy zapis lokalnych szkiców z paczki; żadnej publikacji."""

import re
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Protocol
from uuid import UUID, uuid4

from vexlab.domena.oferta import SzkicOferty
from vexlab.domena.produkt import BladKatalogu, Produkt
from vexlab.przypadki_uzycia.importowanie import PozycjaImportu, blad
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow, _mapuj_bledy
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.tekst_opisu import tekst_katalogowy


@dataclass(frozen=True)
class PozycjaSzkicu:
    oferta: OfertaPodglad
    produkt_id: UUID | None
    wersja_produktu: int | None
    nowy_produkt: PozycjaImportu | None


@dataclass(frozen=True)
class PlanSzkicow:
    zrodlo: str
    pozycje: tuple[PozycjaSzkicu, ...]
    bledy: tuple[str, ...]


@dataclass(frozen=True)
class SzkicDTO:
    id: UUID
    produkt_id: UUID
    wersja_produktu: int
    wersja: int
    oferta: OfertaPodglad
    zrodlo: str
    zrodlo_zmienione: bool


@dataclass(frozen=True)
class WynikSzkicow:
    zapisane: int
    pominiete: int
    produkty: int
    kopia: Path


class MagazynSzkicow(Protocol):
    def zapisz_paczke(self, plan: PlanSzkicow) -> WynikSzkicow: ...
    def lista(self) -> tuple[SzkicDTO, ...]: ...
    def edytuj(self, szkic: SzkicOferty, oferta: OfertaPodglad | None = None) -> None: ...
    def usun(self, id: UUID, wersja: int) -> Path: ...
    def usun_wiele(self, szkice: tuple[tuple[UUID, int], ...]) -> Path: ...


class SzkiceOfert:
    def __init__(self, magazyn: MagazynSzkicow, katalog: KatalogProduktow) -> None:
        self.magazyn, self.katalog = magazyn, katalog

    def zaplanuj(
        self, oferty: tuple[OfertaPodglad, ...], zrodlo: str, producent: UUID | None = None
    ) -> PlanSzkicow:
        produkty = {p.sku.strip().casefold(): p for p in self.katalog.wyszukaj()}
        pozycje, bledy = [], []
        for o in oferty:
            try:
                if o.problemy:
                    raise ValueError("; ".join(o.problemy))
                sku = o.sku.strip().casefold()
                p = produkty.get(sku)
                if not sku:
                    raise ValueError("Brak SKU")
                nowy = None
                if p is None:
                    Produkt(uuid4(), o.tytul.strip(), o.sku.strip(), tekst_katalogowy(o.opis))
                    nowy = PozycjaImportu(
                        uuid4(),
                        uuid4(),
                        zrodlo,
                        "ZIP",
                        o.numer,
                        DaneProduktu(
                            o.tytul.strip(), o.sku.strip(), tekst_katalogowy(o.opis), producent
                        ),
                        "",
                    )
                SzkicOferty(uuid4(), p.id if p else uuid4(), p.wersja if p else 1, o.tytul, o.opis)
                pozycje.append(PozycjaSzkicu(o, p.id if p else None, p.wersja if p else None, nowy))
            except (ValueError, BladKatalogu) as exc:
                bledy.append(f"Wiersz {o.numer}, SKU {o.sku}: {exc}")
        return PlanSzkicow(zrodlo, tuple(pozycje), tuple(bledy))

    def zapisz(self, plan: PlanSzkicow) -> WynikSzkicow:
        if not plan.pozycje:
            raise blad("Brak prawidłowych ofert do zapisania.")
        with _mapuj_bledy():
            return self.magazyn.zapisz_paczke(plan)

    def lista(self) -> tuple[SzkicDTO, ...]:
        return self.magazyn.lista()

    def edytuj(
        self,
        dto: SzkicDTO,
        tytul: str,
        opis: str,
        sekcje: tuple[tuple[ElementPodgladu, ...], ...] | None = None,
    ) -> None:
        try:
            s = SzkicOferty(
                dto.id,
                dto.produkt_id,
                dto.wersja_produktu,
                dto.oferta.tytul,
                dto.oferta.opis,
                dto.wersja,
            ).zmien(tytul, opis)
        except (ValueError, BladKatalogu) as exc:
            raise blad(str(exc)) from exc
        nowe_sekcje = dto.oferta.sekcje if sekcje is None else sekcje
        for sekcja in nowe_sekcje:
            if not sekcja:
                raise blad("Sekcja musi zawierać tekst lub zdjęcie.")
            for element in sekcja:
                if element.typ not in {"tekst", "obraz"}:
                    raise blad("Nieobsługiwany rodzaj elementu opisu.")
                if element.typ == "obraz" and (
                    re.fullmatch(r"https://[^/?#@\s\\]+(?:[/?#][^\s\\]*)?", element.adres) is None
                ):
                    raise blad("Podaj pełny adres HTTPS zdjęcia bez loginu i hasła.")
        self.magazyn.edytuj(s, replace(dto.oferta, tytul=s.tytul, opis=s.opis, sekcje=nowe_sekcje))

    def usun(self, dto: SzkicDTO) -> Path:
        return self.magazyn.usun(dto.id, dto.wersja)

    def usun_wiele(self, szkice: tuple[SzkicDTO, ...]) -> Path:
        if not szkice or len({s.id for s in szkice}) != len(szkice):
            raise blad("Zaznacz szkice do usunięcia bez powtarzania wpisów.")
        return self.magazyn.usun_wiele(tuple((s.id, s.wersja) for s in szkice))
