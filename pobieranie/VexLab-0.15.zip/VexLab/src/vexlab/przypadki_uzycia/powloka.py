"""Preferencje techniczne powłoki; bez encji i reguł sprzedaży."""

from dataclasses import dataclass, replace
from enum import StrEnum
from typing import Protocol


class Motyw(StrEnum):
    CIEMNY = "ciemny"
    JASNY = "jasny"
    SYSTEMOWY = "systemowy"


@dataclass(frozen=True)
class PreferencjePowloki:
    motyw: Motyw = Motyw.CIEMNY
    menu_zwiniete: bool = False


class MagazynPreferencji(Protocol):
    def odczytaj(self) -> PreferencjePowloki: ...

    def zapisz(self, preferencje: PreferencjePowloki) -> None: ...


class PowlokaAplikacji:
    def __init__(self, magazyn: MagazynPreferencji, nazwa_uzytkownika: str, wersja: str) -> None:
        self._magazyn = magazyn
        self.preferencje = magazyn.odczytaj()
        self.nazwa_uzytkownika = nazwa_uzytkownika
        self.wersja = wersja

    def ustaw_motyw(self, motyw: Motyw) -> None:
        nowe = replace(self.preferencje, motyw=motyw)
        self._magazyn.zapisz(nowe)
        self.preferencje = nowe

    def ustaw_menu(self, zwiniete: bool) -> None:
        nowe = replace(self.preferencje, menu_zwiniete=zwiniete)
        self._magazyn.zapisz(nowe)
        self.preferencje = nowe
