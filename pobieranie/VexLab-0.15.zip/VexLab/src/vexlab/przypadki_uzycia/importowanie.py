"""Planowanie importu i trwałe pozycje robocze, bez formatu pliku i SQL."""

from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from uuid import UUID, uuid4

from vexlab.domena.cena import CenaSugerowana
from vexlab.domena.produkt import NieprawidlowyProdukt, Produkt
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import (
    DaneDopasowania,
    DaneProduktu,
    RepozytoriumProduktow,
    _dopasowania,
    _mapuj_bledy,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.tekst_opisu import tekst_katalogowy


def blad(tekst: str) -> BladScenariuszaKatalogu:
    return BladScenariuszaKatalogu("IMPORT", tekst)


@dataclass(frozen=True)
class Komorka:
    tekst: str = ""
    problem: str = ""


@dataclass(frozen=True)
class Arkusz:
    nazwa: str
    wiersze: tuple[tuple[int, tuple[Komorka, ...]], ...]


@dataclass(frozen=True)
class PlikImportu:
    nazwa: str
    arkusze: tuple[Arkusz, ...]


@dataclass(frozen=True)
class CenaImportu:
    tekst: str
    waluta: str
    rodzaj: str

    def sprawdz(self) -> CenaSugerowana | None:
        if not self.tekst.strip():
            return None
        return CenaSugerowana.z_tekstu(self.tekst, self.waluta, self.rodzaj)


@dataclass(frozen=True)
class MapowanieCeny:
    kolumna: int
    waluta: str
    rodzaj: str
    zapisane_formuly: bool = False


@dataclass(frozen=True)
class MapowanieMotocykla:
    marka: int
    model: int
    rok_od: int | None = None
    rok_do: int | None = None
    wariant: int | None = None

    @property
    def kolumny(self) -> tuple[int, ...]:
        return tuple(
            i
            for i in (self.marka, self.model, self.rok_od, self.rok_do, self.wariant)
            if i is not None
        )


@dataclass(frozen=True)
class Mapowanie:
    naglowek: int
    nazwa: int
    sku: int
    opis: int | None = None
    dodatkowy_opis: int | None = None
    dolacz_nazwe_zrodlowa: bool = False
    cena: MapowanieCeny | None = None
    motocykl: MapowanieMotocykla | None = None


@dataclass(frozen=True)
class PozycjaImportu:
    id: UUID
    paczka: UUID
    zrodlo: str
    arkusz: str
    wiersz: int
    dane: DaneProduktu
    powod: str = ""
    wersja: int = 1
    cena: CenaImportu | None = None


@dataclass(frozen=True)
class OcenaPozycji:
    pozycja: PozycjaImportu
    problem: str


@dataclass(frozen=True)
class WynikImportu:
    dodane: int
    odlozone: int


@dataclass(frozen=True)
class UzupelnienieCeny:
    produkt_id: UUID
    wersja: int
    sku: str
    nazwa: str
    cena: CenaImportu
    zrodlo: str


@dataclass(frozen=True)
class PlanUzupelnieniaCen:
    pozycje: tuple[UzupelnienieCeny, ...]
    pominiete: tuple[tuple[int, str], ...]


@dataclass(frozen=True)
class PlanProduktowPaczki:
    oceny: tuple[OcenaPozycji, ...]
    istniejace: tuple[str, ...]

    @property
    def wybrane(self) -> frozenset[UUID]:
        return frozenset(o.pozycja.id for o in self.oceny if not o.problem)


class CzytnikImportu(Protocol):
    def odczytaj(self, plik: Path) -> PlikImportu: ...


class MagazynImportu(Protocol):
    def zatwierdz_paczke(
        self, pozycje: tuple[PozycjaImportu, ...], wybrane: frozenset[UUID]
    ) -> WynikImportu: ...

    def oczekujace(self) -> tuple[PozycjaImportu, ...]: ...

    def usun_oczekujace(self, pozycje: tuple[PozycjaImportu, ...]) -> Path: ...

    def popraw(self, pozycja: PozycjaImportu) -> None: ...

    def rozstrzygnij(self, pozycja: PozycjaImportu, produkt: UUID | None) -> None: ...

    def uzupelnij_ceny(self, pozycje: tuple[UzupelnienieCeny, ...]) -> Path: ...


class ImportujProdukty:
    def __init__(
        self, czytnik: CzytnikImportu, magazyn: MagazynImportu, katalog: RepozytoriumProduktow
    ) -> None:
        self.czytnik = czytnik
        self.magazyn = magazyn
        self.katalog = katalog

    def zaplanuj_z_paczki(
        self,
        oferty: tuple[OfertaPodglad, ...],
        zrodlo: str,
        plik_danych: str,
        producent: UUID | None = None,
    ) -> PlanProduktowPaczki:
        istniejace = {p.klucz_sku for p in self.katalog.wyszukaj("")}
        pominiete = []
        pozycje = []
        paczka = uuid4()
        for oferta in oferty:
            if oferta.sku.strip() and oferta.sku.strip().casefold() in istniejace:
                pominiete.append(oferta.sku)
                continue
            dane = DaneProduktu(
                oferta.tytul.strip(), oferta.sku.strip(), tekst_katalogowy(oferta.opis), producent
            )
            pozycje.append(
                PozycjaImportu(
                    uuid4(),
                    paczka,
                    zrodlo,
                    plik_danych,
                    oferta.numer,
                    dane,
                    "; ".join(oferta.problemy),
                )
            )
        return PlanProduktowPaczki(self.ocen(tuple(pozycje)), tuple(pominiete))

    def odczytaj(self, plik: Path) -> PlikImportu:
        return self.czytnik.odczytaj(plik)

    def zaplanuj(
        self, plik: PlikImportu, arkusz: int, mapa: Mapowanie, producent: UUID | None
    ) -> tuple[OcenaPozycji, ...]:
        if not 0 <= arkusz < len(plik.arkusze):
            raise blad("Wybierz arkusz.")
        tabela = plik.arkusze[arkusz]
        wiersze = dict(tabela.wiersze)
        naglowki = wiersze.get(mapa.naglowek)
        kolumny = [mapa.nazwa, mapa.sku] + [
            i for i in (mapa.opis, mapa.dodatkowy_opis) if i is not None
        ]
        if (
            naglowki is None
            or mapa.nazwa == mapa.sku
            or any(i < 0 or i >= len(naglowki) for i in kolumny)
        ):
            raise blad("Wybierz wiersz nagłówków i różne kolumny nazwy oraz SKU.")
        if mapa.cena is not None:
            if (
                mapa.cena.kolumna < 0
                or mapa.cena.kolumna >= len(naglowki)
                or mapa.cena.kolumna in kolumny
            ):
                raise blad("Wybierz odrębną kolumnę ceny.")
            try:
                CenaSugerowana.z_tekstu("0", mapa.cena.waluta, mapa.cena.rodzaj)
            except ValueError as exc:
                raise blad(str(exc)) from exc
        if mapa.motocykl is not None:
            moto = mapa.motocykl
            if (
                len(set(moto.kolumny)) != len(moto.kolumny)
                or any(i < 0 or i >= len(naglowki) for i in moto.kolumny)
                or any(i in (mapa.nazwa, mapa.sku) for i in moto.kolumny)
                or (mapa.cena is not None and mapa.cena.kolumna in moto.kolumny)
            ):
                raise blad("Wybierz różne kolumny dopasowania, odrębne od nazwy, SKU i ceny.")
        paczka = uuid4()
        pozycje = []
        for numer, komorki in tabela.wiersze:
            if numer <= mapa.naglowek or not any(c.tekst or c.problem for c in komorki):
                continue

            def pole(i: int, cells: tuple[Komorka, ...] = komorki) -> Komorka:
                return cells[i] if i < len(cells) else Komorka()

            problemy = "; ".join(dict.fromkeys(pole(i).problem for i in kolumny if pole(i).problem))
            fragmenty = []
            if mapa.dolacz_nazwe_zrodlowa:
                fragmenty.append(pole(mapa.nazwa).tekst.strip())
            for indeks in (mapa.opis, mapa.dodatkowy_opis):
                if indeks is not None:
                    fragmenty.append(pole(indeks).tekst)
            # Jawne kopiowanie tekstu źródła, bez odgadywania pojazdu i roczników.
            opis = "\n\n".join(dict.fromkeys(f for f in fragmenty if f.strip()))
            dopasowania = None
            if mapa.motocykl is not None:
                m = mapa.motocykl
                wartosci = tuple(
                    pole(i).tekst if i is not None else ""
                    for i in (m.marka, m.model, m.rok_od, m.rok_do, m.wariant)
                )
                dopasowania = (
                    (DaneDopasowania(*wartosci),) if any(x.strip() for x in wartosci) else ()
                )
                for i in m.kolumny:
                    problem = pole(i).problem
                    if problem and not (
                        i in (m.rok_od, m.rok_do) and problem.startswith("Komórka liczbowa")
                    ):
                        problemy = "; ".join(filter(None, (problemy, "Dopasowanie: " + problem)))
            dane = DaneProduktu(
                pole(mapa.nazwa).tekst.strip(),
                pole(mapa.sku).tekst.strip(),
                opis,
                producent,
                dopasowania,
            )
            cena = None
            if mapa.cena is not None:
                c = pole(mapa.cena.kolumna)
                cena = CenaImportu(c.tekst, mapa.cena.waluta, mapa.cena.rodzaj)
                if (
                    c.problem
                    and not c.problem.startswith("Komórka liczbowa")
                    and not (c.problem.startswith("Formuła") and mapa.cena.zapisane_formuly)
                ):
                    problemy = "; ".join(filter(None, (problemy, "Cena: " + c.problem)))
            pozycje.append(
                PozycjaImportu(
                    uuid4(), paczka, plik.nazwa, tabela.nazwa, numer, dane, problemy, cena=cena
                )
            )
        if not pozycje:
            raise blad("Brak wierszy danych poniżej wybranych nagłówków.")
        return self.ocen(tuple(pozycje))

    def ocen(self, pozycje: tuple[PozycjaImportu, ...]) -> tuple[OcenaPozycji, ...]:
        istniejace = {p.klucz_sku for p in self.katalog.wyszukaj("")}
        liczby = Counter(p.dane.sku.strip().casefold() for p in pozycje)
        wynik = []
        for p in pozycje:
            problemy = [p.powod] if p.powod else []
            if not p.dane.nazwa.strip():
                problemy.append("Brak nazwy")
            if not p.dane.sku.strip():
                problemy.append("Brak SKU")
            elif liczby[p.dane.sku.strip().casefold()] > 1:
                problemy.append("Powtórzone SKU w paczce")
            if p.dane.sku.strip().casefold() in istniejace:
                problemy.append("SKU istnieje w katalogu")
            try:
                Produkt(
                    uuid4(),
                    p.dane.nazwa.strip() or "brak",
                    p.dane.sku.strip() or "brak",
                    dopasowania=_dopasowania(p.dane.dopasowania or ()),
                )
            except NieprawidlowyProdukt as exc:
                problemy.append(str(exc))
            if p.cena is not None:
                try:
                    p.cena.sprawdz()
                except ValueError as exc:
                    problemy.append(str(exc))
            wynik.append(OcenaPozycji(p, "; ".join(problemy)))
        return tuple(wynik)

    def zatwierdz(self, oceny: tuple[OcenaPozycji, ...], wybrane: frozenset[UUID]) -> WynikImportu:
        ids = {o.pozycja.id for o in oceny}
        if not oceny or not wybrane <= ids or len(ids) != len(oceny):
            raise blad("Nieprawidłowy wybór pozycji importu.")
        wybrane_pozycje = tuple(o.pozycja for o in oceny if o.pozycja.id in wybrane)
        # Ponowne sprawdzenie wybranej paczki pozwala wybrać jeden z duplikatów.
        if any(o.problem for o in self.ocen(wybrane_pozycje)):
            raise blad("Wybrane wiersze mają błędy. Popraw wybór lub odłóż je do poprawy.")
        with _mapuj_bledy():
            return self.magazyn.zatwierdz_paczke(
                tuple(
                    PozycjaImportu(
                        o.pozycja.id,
                        o.pozycja.paczka,
                        o.pozycja.zrodlo,
                        o.pozycja.arkusz,
                        o.pozycja.wiersz,
                        o.pozycja.dane,
                        o.problem or "Wykluczono przez użytkownika",
                        cena=o.pozycja.cena,
                    )
                    for o in oceny
                ),
                wybrane,
            )

    def oczekujace(self) -> tuple[PozycjaImportu, ...]:
        return self.magazyn.oczekujace()

    def usun_oczekujace(self, pozycje: tuple[PozycjaImportu, ...]) -> Path:
        if not pozycje:
            raise blad("Zaznacz wpisy do usunięcia.")
        return self.magazyn.usun_oczekujace(pozycje)

    def popraw(self, pozycja: PozycjaImportu) -> None:
        # Dopuszczamy zapis niekompletnego szkicu; finalne dodanie waliduje domena.
        self.magazyn.popraw(pozycja)

    def rozstrzygnij(self, pozycja: PozycjaImportu, produkt: UUID | None = None) -> None:
        if produkt is None and pozycja.cena is not None:
            try:
                pozycja.cena.sprawdz()
            except ValueError as exc:
                raise blad(str(exc)) from exc
        with _mapuj_bledy():
            if produkt is None:
                Produkt(
                    uuid4(),
                    pozycja.dane.nazwa.strip(),
                    pozycja.dane.sku.strip(),
                    pozycja.dane.opis,
                    producent_id=pozycja.dane.producent_id,
                    dopasowania=_dopasowania(pozycja.dane.dopasowania or ()),
                )
            self.magazyn.rozstrzygnij(pozycja, produkt)

    def zaplanuj_uzupelnienie_cen(self, oceny: tuple[OcenaPozycji, ...]) -> PlanUzupelnieniaCen:
        produkty = {p.klucz_sku: p for p in self.katalog.wyszukaj("")}
        ceny = self.katalog.ceny_sugerowane()
        liczby = Counter(o.pozycja.dane.sku.casefold() for o in oceny)
        zmiany = []
        pominiete = []
        for o in oceny:
            p = o.pozycja
            sku = p.dane.sku.casefold()
            produkt = produkty.get(sku)
            powod = ""
            if p.powod:
                powod = p.powod
            elif not sku or liczby[sku] > 1:
                powod = "Brak lub niejednoznaczne SKU w pliku"
            elif produkt is None:
                powod = "Brak Produktu w katalogu"
            elif produkt.id in ceny:
                powod = "Produkt ma już cenę — nie nadpisano"
            elif p.cena is None or not p.cena.tekst.strip():
                powod = "Brak ceny źródłowej"
            else:
                try:
                    p.cena.sprawdz()
                except ValueError as exc:
                    powod = str(exc)
            if powod:
                pominiete.append((p.wiersz, powod))
            elif produkt is not None and p.cena is not None:
                zmiany.append(
                    UzupelnienieCeny(
                        produkt.id,
                        produkt.wersja,
                        produkt.sku,
                        produkt.nazwa,
                        p.cena,
                        f"{p.zrodlo} / {p.arkusz} / {p.wiersz}",
                    )
                )
        if not zmiany:
            raise blad(
                "Brak jednoznacznych Produktów z brakującą ceną i poprawną ceną źródłową. "
                "Wybierz kolumnę ceny i sprawdź podgląd."
            )
        return PlanUzupelnieniaCen(tuple(zmiany), tuple(pominiete))

    def uzupelnij_ceny(self, plan: PlanUzupelnieniaCen) -> Path:
        with _mapuj_bledy():
            return self.magazyn.uzupelnij_ceny(plan.pozycje)
