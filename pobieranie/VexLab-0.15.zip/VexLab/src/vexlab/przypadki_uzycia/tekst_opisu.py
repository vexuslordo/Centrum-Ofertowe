"""Czysta transformacja opisu HTML paczki do tekstu katalogowego; bez zasobów i I/O."""

from html.parser import HTMLParser


class _Tekst(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.czesc: list[str] = []
        self.ukryte = 0
        self.zakazane = {"script", "style", "iframe", "object", "svg"}
        self.bloki = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "br"}

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self.zakazane:
            self.ukryte += 1
        elif not self.ukryte:
            if tag in self.bloki:
                self.czesc.append("\n")
            elif tag == "li":
                self.czesc.append("\n- ")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.zakazane:
            self.ukryte = max(0, self.ukryte - 1)
        elif not self.ukryte and (tag in self.bloki or tag == "li"):
            self.czesc.append("\n")

    def handle_data(self, data: str) -> None:
        if not self.ukryte:
            self.czesc.append(data)


def tekst_katalogowy(html: str) -> str:
    parser = _Tekst()
    parser.feed(html)
    parser.close()
    return "\n".join(w.strip() for w in "".join(parser.czesc).splitlines() if w.strip())
