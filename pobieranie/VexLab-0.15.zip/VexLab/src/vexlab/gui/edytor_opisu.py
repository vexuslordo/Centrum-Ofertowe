"""Wizualne sekcje szkicu. Treści i układ pochodzą wyłącznie od użytkownika."""

from collections.abc import Sequence
from html import escape
from typing import cast

from PySide6.QtCore import QMimeData, Qt, QUrl, Signal
from PySide6.QtGui import (
    QDragEnterEvent,
    QDragMoveEvent,
    QDropEvent,
    QFont,
    QTextCharFormat,
    QTextListFormat,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSplitter,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.paczki_ofert import FiltrHTML, TekstPodgladu, bezpieczny_html, etykieta
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad

MIME_ZDJECIA = "application/x-vexlab-image-url"


class HTMLZEdytora(FiltrHTML):
    """Zamienia formatowanie Qt na proste znaczniki; odrzuca pozostałe atrybuty."""

    def __init__(self) -> None:
        super().__init__()
        self.spany: list[tuple[str, ...]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "span":
            styl = dict(attrs).get("style") or ""
            deklaracje = dict(x.strip().split(":", 1) for x in styl.split(";") if ":" in x)
            znaczniki = tuple(
                t
                for t, warunek in (
                    ("b", deklaracje.get("font-weight", "").strip() in {"600", "700", "bold"}),
                    ("i", deklaracje.get("font-style", "").strip() == "italic"),
                    ("u", "underline" in deklaracje.get("text-decoration", "")),
                )
                if warunek
            )
            self.spany.append(znaczniki)
            if not self.ukryte:
                self.wynik.extend(f"<{t}>" for t in znaczniki)
        else:
            super().handle_starttag(tag, attrs)

    def handle_endtag(self, tag: str) -> None:
        if tag == "span":
            znaczniki = self.spany.pop() if self.spany else ()
            if not self.ukryte:
                self.wynik.extend(f"</{t}>" for t in reversed(znaczniki))
        else:
            super().handle_endtag(tag)


def html_edytora(tekst: str) -> str:
    parser = HTMLZEdytora()
    parser.feed(tekst)
    parser.close()
    return "".join(parser.wynik)


class TekstWizualny(QTextEdit):
    def __init__(self, html: str) -> None:
        super().__init__()
        self.setAcceptRichText(True)
        self.setHtml(bezpieczny_html(html))
        self.setMinimumHeight(250)

    def loadResource(self, typ: int, nazwa: QUrl | str) -> object:
        return None

    def insertFromMimeData(self, dane: QMimeData) -> None:
        if dane.hasHtml():
            self.insertHtml(bezpieczny_html(dane.html()))
        elif dane.hasText():
            self.insertPlainText(dane.text())


class GaleriaDoPrzeciagniecia(QListWidget):
    def mimeData(self, items: Sequence[QListWidgetItem]) -> QMimeData:
        dane = QMimeData()
        if items:
            dane.setData(MIME_ZDJECIA, str(items[0].data(Qt.ItemDataRole.UserRole)).encode())
        return dane


class ListaSekcji(QListWidget):
    zdjecieUpuszczone = Signal(str)

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if event.mimeData().hasFormat(MIME_ZDJECIA):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event: QDragMoveEvent) -> None:
        if event.mimeData().hasFormat(MIME_ZDJECIA):
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event: QDropEvent) -> None:
        dane = event.mimeData()
        if dane.hasFormat(MIME_ZDJECIA):
            self.zdjecieUpuszczone.emit(
                bytes(dane.data(MIME_ZDJECIA).data()).decode(errors="replace")
            )
            event.acceptProposedAction()
            return
        super().dropEvent(event)


class EdytorOpisu(QWidget):
    def __init__(self, oferta: OfertaPodglad, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.oferta = oferta
        self.zmieniony = False
        self.lista = ListaSekcji()
        self.lista.setAccessibleName("Sekcje opisu — przeciągnij, aby zmienić kolejność")
        self.lista.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.lista.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.lista.setMinimumWidth(240)
        self.lista.zdjecieUpuszczone.connect(self.dodaj_zdjecie)
        self.lista.currentRowChanged.connect(self.pokaz_sekcje)
        self.lista.model().rowsMoved.connect(self._zmiana)
        self.pole = QWidget()
        self.pole_layout = QVBoxLayout(self.pole)
        layout = QVBoxLayout(self)
        layout.addWidget(
            etykieta(
                "Przeciągaj sekcje na liście lub użyj strzałek. "
                "Tekst edytujesz z formatowaniem. Zmiana sekcji aktualizuje "
                "pełny opis tego szkicu."
            )
        )
        akcje = QHBoxLayout()
        for tekst, funkcja in (
            ("+ Tekst", lambda: self.dodaj((ElementPodgladu("tekst"),))),
            ("+ Zdjęcie", lambda: self.dodaj_zdjecie("")),
            (
                "+ Tekst i zdjęcie",
                lambda: self.dodaj((ElementPodgladu("tekst"), ElementPodgladu("obraz"))),
            ),
            (
                "+ Dwa zdjęcia",
                lambda: self.dodaj((ElementPodgladu("obraz"), ElementPodgladu("obraz"))),
            ),
            ("↑", lambda: self.przesun(-1)),
            ("↓", lambda: self.przesun(1)),
            ("Usuń sekcję", self.usun),
        ):
            b = QPushButton(tekst)
            b.setAccessibleName(
                {"↑": "Przesuń sekcję w górę", "↓": "Przesuń sekcję w dół"}.get(tekst, tekst)
            )
            b.clicked.connect(funkcja)
            akcje.addWidget(b)
        layout.addLayout(akcje)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        obszar = QSplitter()
        obszar.addWidget(self.lista)
        obszar.addWidget(self.pole)
        obszar.setStretchFactor(1, 1)
        self.tabs.addTab(obszar, "Edytor sekcji")
        self.podglad = TekstPodgladu(oferta.opis)
        self.tabs.addTab(self.podglad, "Podgląd pełnego opisu")
        self.tabs.currentChanged.connect(self._podglad)
        galeria_layout = QHBoxLayout()
        galeria_layout.addWidget(etykieta("Zdjęcia z paczki\nPrzeciągnij na listę sekcji:"))
        self.galeria = GaleriaDoPrzeciagniecia()
        self.galeria.setAccessibleName("Galeria adresów zdjęć do przeciągnięcia")
        self.galeria.setMaximumHeight(90)
        self.galeria.setDragEnabled(True)
        self.galeria.setSupportedDragActions(Qt.DropAction.CopyAction)
        for i, url in enumerate(oferta.zdjecia, 1):
            item = QListWidgetItem(f"Zdjęcie {i} • {url}")
            item.setData(Qt.ItemDataRole.UserRole, url)
            self.galeria.addItem(item)
        self.galeria.itemDoubleClicked.connect(
            lambda item: self.dodaj_zdjecie(str(item.data(Qt.ItemDataRole.UserRole)))
        )
        galeria_layout.addWidget(self.galeria, 1)
        layout.addLayout(galeria_layout)
        sekcje = oferta.sekcje or ((ElementPodgladu("tekst", oferta.opis),),)
        for sekcja in sekcje:
            self._dodaj_item(sekcja)
        pierwsza_tekstowa = next(
            (i for i, sekcja in enumerate(sekcje) if any(e.typ == "tekst" for e in sekcja)), 0
        )
        self.lista.setCurrentRow(pierwsza_tekstowa)

    def _dodaj_item(self, sekcja: tuple[ElementPodgladu, ...]) -> None:
        item = QListWidgetItem()
        item.setData(Qt.ItemDataRole.UserRole, sekcja)
        self.lista.addItem(item)
        self._etykiety()

    def _etykiety(self) -> None:
        for i in range(self.lista.count()):
            item = self.lista.item(i)
            elementy = cast(tuple[ElementPodgladu, ...], item.data(Qt.ItemDataRole.UserRole))
            item.setText(
                f"Sekcja {i + 1} • "
                + " + ".join("Tekst" if e.typ == "tekst" else "Zdjęcie" for e in elementy)
            )

    def dodaj(self, elementy: tuple[ElementPodgladu, ...]) -> None:
        self._dodaj_item(elementy)
        self.lista.setCurrentRow(self.lista.count() - 1)
        self.tabs.setCurrentIndex(0)
        self._zmiana()

    def dodaj_zdjecie(self, url: str) -> None:
        self.dodaj((ElementPodgladu("obraz", adres=url),))

    def przesun(self, delta: int) -> None:
        i = self.lista.currentRow()
        if 0 <= i + delta < self.lista.count():
            item = self.lista.takeItem(i)
            self.lista.insertItem(i + delta, item)
            self.lista.setCurrentRow(i + delta)
            self._zmiana()

    def usun(self) -> None:
        i = self.lista.currentRow()
        if i >= 0:
            self.lista.takeItem(i)
            self._zmiana()

    def _zmiana(self) -> None:
        self.zmieniony = True
        self._etykiety()

    def _podglad(self) -> None:
        self.podglad.setHtml(bezpieczny_html(self.opis()))

    def sekcje(self) -> tuple[tuple[ElementPodgladu, ...], ...]:
        return tuple(
            cast(tuple[ElementPodgladu, ...], self.lista.item(i).data(Qt.ItemDataRole.UserRole))
            for i in range(self.lista.count())
        )

    def opis(self) -> str:
        if not self.zmieniony:
            return self.oferta.opis
        return "".join(
            e.tekst if e.typ == "tekst" else f'<p><img src="{escape(e.adres, quote=True)}"></p>'
            for s in self.sekcje()
            for e in s
        )

    def wynik_sekcji(self) -> tuple[tuple[ElementPodgladu, ...], ...]:
        return self.sekcje() if self.zmieniony else self.oferta.sekcje

    def pokaz_sekcje(self) -> None:
        while self.pole_layout.count():
            zawartosc = self.pole_layout.takeAt(0)
            child = zawartosc.widget() if zawartosc is not None else None
            if child is not None:
                child.deleteLater()
        item = self.lista.currentItem()
        if item is None:
            return
        elementy = cast(tuple[ElementPodgladu, ...], item.data(Qt.ItemDataRole.UserRole))
        row = QHBoxLayout()
        host = QWidget()
        host.setLayout(row)
        self.pole_layout.addWidget(host)
        for i, element in enumerate(elementy):
            panel = QWidget()
            kolumna = QVBoxLayout(panel)
            row.addWidget(panel, 1)
            if element.typ == "tekst":
                tekst = TekstWizualny(element.tekst)
                tekst.setAccessibleName(f"Tekst elementu {i + 1} wybranej sekcji")
                tools = QHBoxLayout()
                for label, style in (
                    ("B", "bold"),
                    ("I", "italic"),
                    ("U", "underline"),
                    ("• Lista", "list"),
                    ("Nagłówek", "heading"),
                ):
                    b = QPushButton(label)
                    b.setAccessibleName(
                        {"B": "Pogrubienie", "I": "Kursywa", "U": "Podkreślenie"}.get(label, label)
                    )
                    b.clicked.connect(lambda checked=False, t=tekst, s=style: self.formatuj(t, s))
                    tools.addWidget(b)
                kolumna.addLayout(tools)
                tekst.textChanged.connect(
                    lambda t=tekst, n=i, it=item: self._element(
                        it, n, ElementPodgladu("tekst", html_edytora(t.toHtml()))
                    )
                )
                kolumna.addWidget(tekst, 1)
            else:
                kolumna.addWidget(etykieta("Zdjęcie — adres HTTPS"))
                adres = QLineEdit(element.adres)
                adres.setAccessibleName(f"Adres zdjęcia elementu {i + 1} wybranej sekcji")
                adres.textEdited.connect(
                    lambda value, n=i, it=item: self._element(
                        it, n, ElementPodgladu("obraz", adres=value)
                    )
                )
                kolumna.addWidget(adres)
                kolumna.addWidget(
                    etykieta(
                        "Zdjęcie zostanie użyte w tej sekcji. "
                        "Obrazy z internetu nie są pobierane w tym edytorze."
                    )
                )
                kolumna.addStretch()
        self.pole_layout.addStretch()

    def _element(self, item: QListWidgetItem, i: int, element: ElementPodgladu) -> None:
        elementy = list(cast(tuple[ElementPodgladu, ...], item.data(Qt.ItemDataRole.UserRole)))
        elementy[i] = element
        item.setData(Qt.ItemDataRole.UserRole, tuple(elementy))
        self._zmiana()

    @staticmethod
    def formatuj(tekst: QTextEdit, styl: str) -> None:
        tekst.setFocus()
        if styl == "heading":
            cursor = tekst.textCursor()
            block = cursor.blockFormat()
            block.setHeadingLevel(0 if block.headingLevel() == 2 else 2)
            cursor.setBlockFormat(block)
            return
        if styl == "list":
            tekst.textCursor().createList(QTextListFormat.Style.ListDisc)
            return
        fmt = QTextCharFormat()
        if styl == "bold":
            fmt.setFontWeight(
                QFont.Weight.Normal
                if tekst.fontWeight() >= QFont.Weight.Bold
                else QFont.Weight.Bold
            )
        elif styl == "italic":
            fmt.setFontItalic(not tekst.fontItalic())
        elif styl == "underline":
            fmt.setFontUnderline(not tekst.fontUnderline())
        tekst.mergeCurrentCharFormat(fmt)
