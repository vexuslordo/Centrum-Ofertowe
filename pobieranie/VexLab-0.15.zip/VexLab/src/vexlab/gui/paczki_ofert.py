"""Podgląd ZIP i profile użytkownika. Bez publikacji lub zapisu Ofert do bazy."""

from collections.abc import Callable
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from typing import cast
from uuid import UUID

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty, PlanProduktowPaczki, WynikImportu
from vexlab.przypadki_uzycia.paczki_ofert import (
    OfertaPodglad,
    PaczkaOfert,
    PodgladPaczek,
    ProfilPaczki,
    WynikPodgladu,
)
from vexlab.przypadki_uzycia.producenci import ProducentDTO, RejestrProducentow
from vexlab.przypadki_uzycia.szkice import PlanSzkicow, SzkiceOfert, WynikSzkicow


class FiltrHTML(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.wynik: list[str] = []
        self.ukryte = 0
        self.zakazane = {"script", "style", "iframe", "object", "svg"}
        self.dozwolone = {
            "p",
            "b",
            "strong",
            "i",
            "em",
            "u",
            "ul",
            "ol",
            "li",
            "br",
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            "h6",
        }

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self.zakazane:
            self.ukryte += 1
        elif not self.ukryte and tag in self.dozwolone:
            self.wynik.append(f"<{tag}>")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.zakazane:
            self.ukryte = max(0, self.ukryte - 1)
        elif not self.ukryte and tag in self.dozwolone and tag != "br":
            self.wynik.append(f"</{tag}>")

    def handle_data(self, data: str) -> None:
        if not self.ukryte:
            self.wynik.append(escape(data))


def bezpieczny_html(tekst: str) -> str:
    parser = FiltrHTML()
    parser.feed(tekst)
    parser.close()
    return "".join(parser.wynik)


class TekstPodgladu(QTextBrowser):
    def __init__(self, tekst: str) -> None:
        super().__init__()
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setHtml(bezpieczny_html(tekst))
        self.setMinimumHeight(120)

    def loadResource(self, typ: int, nazwa: QUrl | str) -> object:
        return None  # Nigdy nie odczytuj zasobów z dysku/sieci na żądanie HTML.


def etykieta(tekst: str) -> QLabel:
    label = QLabel(tekst)
    label.setTextFormat(Qt.TextFormat.PlainText)
    label.setWordWrap(True)
    return label


class SzczegolyPaczki(QDialog):
    def __init__(self, oferta: OfertaPodglad, parent: QWidget) -> None:
        super().__init__(parent)
        self.setWindowTitle("Podgląd oferty z paczki")
        self.resize(880, 700)
        layout = QVBoxLayout(self)
        layout.addWidget(etykieta(f"{oferta.sku} • {oferta.tytul}"))
        layout.addWidget(
            etykieta(
                "Podgląd lokalny. Obrazy nie są pobierane; "
                "ustawienia Allegro nie są jeszcze sprawdzane przez API."
            )
        )
        tabs = QTabWidget()
        layout.addWidget(tabs)
        informacje = QPlainTextEdit(
            f"SKU: {oferta.sku}\nEAN (źródłowy): {oferta.ean}\n"
            f"Cena z paczki: {oferta.cena} (waluta i rodzaj nieustalone)\n"
            f"Dopasowanie źródłowe: {oferta.dopasowanie_tekst}\n\nZdjęcia produktu:\n"
            + "\n".join(oferta.zdjecia)
            + "\n\nProblemy: "
            + ("; ".join(oferta.problemy) or "Nie wykryto w mapowanym zakresie")
        )
        informacje.setReadOnly(True)
        tabs.addTab(informacje, "Dane i zdjęcia")
        tabs.addTab(TekstPodgladu(oferta.opis), "Opis")
        surowy = QPlainTextEdit(oferta.opis)
        surowy.setReadOnly(True)
        tabs.addTab(surowy, "Źródło opisu")
        zawartosc = QWidget()
        sekcje = QVBoxLayout(zawartosc)
        for i, elementy in enumerate(oferta.sekcje, 1):
            grupa = QGroupBox(f"Sekcja {i}")
            wiersz = QHBoxLayout(grupa)
            for element in elementy:
                if element.typ == "tekst":
                    wiersz.addWidget(TekstPodgladu(element.tekst), 1)
                else:
                    wiersz.addWidget(etykieta("Obraz (adres z paczki):\n" + element.adres), 1)
            sekcje.addWidget(grupa)
        if not oferta.sekcje:
            sekcje.addWidget(etykieta("Nie wybrano sekcji lub rekord ich nie zawiera."))
        sekcje.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(zawartosc)
        tabs.addTab(scroll, "Układ sekcji")
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class StronaPaczek(QWidget):
    zmieniono = Signal()
    POLA = (
        ("sku", "SKU *"),
        ("tytul", "Tytuł *"),
        ("opis", "Pełny opis HTML"),
        ("sekcje", "Układ sekcji"),
        ("zdjecia", "Galeria zdjęć"),
        ("ean", "EAN"),
        ("cena", "Cena źródłowa"),
        ("dopasowanie_tekst", "Tekst dopasowania"),
    )
    STRUKTURA = (
        ("lista_elementow", "Klucz listy elementów w sekcji"),
        ("typ_elementu", "Klucz typu elementu"),
        ("tresc_elementu", "Klucz tekstu HTML"),
        ("adres_elementu", "Klucz adresu obrazu"),
        ("typ_tekstu", "Wartość typu tekstu"),
        ("typ_obrazu", "Wartość typu obrazu"),
    )

    def __init__(
        self,
        serwis: PodgladPaczek,
        uruchom: Uruchom,
        parent: QWidget,
        importer: ImportujProdukty,
        producenci: RejestrProducentow,
        szkice: SzkiceOfert | None = None,
    ) -> None:
        super().__init__(parent)
        self.serwis, self.uruchom = serwis, uruchom
        self.importer, self.producenci = importer, producenci
        self.szkice = szkice
        self.plan_produktow: PlanProduktowPaczki | None = None
        self.zapisano_produkty = False
        self.paczka: PaczkaOfert | None = None
        self.profil_wczytany: ProfilPaczki | None = None
        self._profil_zewnetrzny = False
        self.kandydaci_profili: tuple[ProfilPaczki, ...] = ()
        self.oferty: tuple[OfertaPodglad, ...] = ()
        self.dialog: SzczegolyPaczki | None = None
        self.trwa = False
        self._generacja = 0
        self.setObjectName("strona")
        glowny = QVBoxLayout(self)
        label = etykieta("Nowe oferty — paczka ZIP")
        label.setObjectName("marka")
        glowny.addWidget(label)
        glowny.addWidget(
            etykieta(
                "Wybierz paczkę ZIP. Znany układ zostanie rozpoznany automatycznie. "
                "Produkty możesz dodać do katalogu lokalnego. "
                "Wysyłka na Allegro jeszcze niewdrożona."
            )
        )
        self.tabs = QTabWidget()
        glowny.addWidget(self.tabs, 1)
        ustawienia = QWidget()
        layout = QVBoxLayout(ustawienia)
        pasek = QHBoxLayout()
        wybierz = QPushButton("Wybierz paczkę ZIP…")
        wybierz.setObjectName("primary")
        wybierz.clicked.connect(self.otworz)
        pasek.addWidget(wybierz, 1)
        wczytaj = QPushButton("Wczytaj profil — pierwszy raz…")
        wczytaj.clicked.connect(self.wczytaj_profil)
        pasek.addWidget(wczytaj)
        self.rozwin_konfiguracje = QPushButton("Konfiguracja zaawansowana")
        self.rozwin_konfiguracje.clicked.connect(self._konfiguruj)
        pasek.addWidget(self.rozwin_konfiguracje)
        layout.addLayout(pasek)
        self.info_profili = etykieta(
            "Układ wystarczy wskazać raz. Program zapamięta go dla kolejnych paczek."
        )
        layout.addWidget(self.info_profili)
        self.wybor_profilu = QComboBox()
        self.wybor_profilu.setAccessibleName("Wybierz jeden z profili dołączonych do paczki")
        self.wybor_profilu.currentIndexChanged.connect(self._profil_z_paczki)
        self.wybor_profilu.hide()
        layout.addWidget(self.wybor_profilu)
        self.konfiguracja = QWidget()
        konfig = QVBoxLayout(self.konfiguracja)
        self.konfiguracja.hide()
        zapisz = QPushButton("Zapisz profil jako…")
        zapisz.clicked.connect(self.zapisz_profil)
        konfig.addWidget(zapisz)
        self.nazwa = QLineEdit()
        self.nazwa.setAccessibleName("Nazwa profilu odczytu paczki")
        self.plik = QComboBox()
        self.plik.setAccessibleName("Plik danych wewnątrz ZIP")
        self.plik.currentIndexChanged.connect(self._pola)
        form = QFormLayout()
        form.addRow("Nazwa profilu użytkownika", self.nazwa)
        form.addRow("Plik danych", self.plik)
        self.mapy: dict[str, QComboBox] = {}
        for klucz, opis in self.POLA:
            box = QComboBox()
            box.setAccessibleName("Pole z paczki: " + opis)
            box.currentIndexChanged.connect(self._uniewaznij)
            self.mapy[klucz] = box
            form.addRow(opis, box)
        konfig.addLayout(form)
        zaawansowane = QGroupBox("Mapowanie struktury sekcji (jeśli wybrane)")
        struktura = QFormLayout(zaawansowane)
        self.struktura: dict[str, QLineEdit] = {}
        for klucz, opis in self.STRUKTURA:
            pole = QLineEdit()
            pole.setAccessibleName(opis)
            pole.textChanged.connect(self._uniewaznij)
            self.struktura[klucz] = pole
            struktura.addRow(opis, pole)
        rozwin = QToolButton()
        rozwin.setText("Struktura sekcji — ustawienia zaawansowane")
        rozwin.setCheckable(True)
        rozwin.setArrowType(Qt.ArrowType.RightArrow)
        rozwin.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        zaawansowane.setVisible(False)
        rozwin.toggled.connect(zaawansowane.setVisible)
        rozwin.toggled.connect(
            lambda stan: rozwin.setArrowType(
                Qt.ArrowType.DownArrow if stan else Qt.ArrowType.RightArrow
            )
        )
        konfig.addWidget(rozwin)
        konfig.addWidget(zaawansowane)
        self.przygotuj = QPushButton("Sprawdź i zapamiętaj układ")
        self.przygotuj.setObjectName("primary")
        self.przygotuj.clicked.connect(self.podglad)
        konfig.addWidget(self.przygotuj)
        self.inwentarz = QPlainTextEdit()
        self.inwentarz.setReadOnly(True)
        self.inwentarz.setMaximumHeight(140)
        konfig.addWidget(self.inwentarz)
        self.dialog_konfiguracji = QDialog(self)
        self.dialog_konfiguracji.setWindowTitle("Edytor układu — ustawienia zaawansowane")
        self.dialog_konfiguracji.resize(850, 700)
        edytor_layout = QVBoxLayout(self.dialog_konfiguracji)
        edytor_scroll = QScrollArea()
        edytor_scroll.setWidgetResizable(True)
        edytor_scroll.setWidget(self.konfiguracja)
        edytor_layout.addWidget(edytor_scroll)
        zamknij = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        zamknij.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        zamknij.rejected.connect(self.dialog_konfiguracji.reject)
        edytor_layout.addWidget(zamknij)
        zapomnij = QPushButton("Usuń zapamiętany układ tej paczki…")
        zapomnij.clicked.connect(self.zapomnij)
        konfig.addWidget(zapomnij)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(ustawienia)
        self.tabs.addTab(scroll, "Wczytaj paczkę")
        self.tabela = QTableWidget(0, 8)
        self.tabela.verticalHeader().hide()
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setHorizontalHeaderLabels(
            ["Nr", "SKU", "Tytuł", "EAN", "Cena z paczki", "Zdjęcia", "Sekcje", "Problemy"]
        )
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tabela.doubleClicked.connect(self.szczegoly)
        wynik = QWidget()
        wynik_layout = QVBoxLayout(wynik)
        otworz = QPushButton("Pokaż wybraną ofertę…")
        otworz.clicked.connect(self.szczegoly)
        wynik_layout.addWidget(otworz)
        produkty = QHBoxLayout()
        produkty.addWidget(etykieta("Producent nowych produktów (opcjonalnie)"))
        self.producent = QComboBox()
        self.producent.setAccessibleName("Producent nowych produktów z paczki")
        self.producent.addItem("Brak producenta", None)
        self.producent.currentIndexChanged.connect(self.sprawdz_produkty)
        produkty.addWidget(self.producent, 1)
        self.sprawdz_katalog = QPushButton("Sprawdź katalog ponownie")
        self.sprawdz_katalog.setEnabled(False)
        self.sprawdz_katalog.clicked.connect(self.sprawdz_produkty)
        produkty.addWidget(self.sprawdz_katalog)
        self.dodaj_produkty = QPushButton("Dodaj nowe produkty do katalogu")
        self.dodaj_produkty.setObjectName("primary")
        self.dodaj_produkty.setEnabled(False)
        self.dodaj_produkty.clicked.connect(self.zapisz_produkty)
        produkty.addWidget(self.dodaj_produkty)
        wynik_layout.addLayout(produkty)
        self.zapisz_szkice = QPushButton("Zapisz oferty jako lokalne szkice…")
        self.zapisz_szkice.setObjectName("primary")
        self.zapisz_szkice.setVisible(self.szkice is not None)
        self.zapisz_szkice.clicked.connect(self.przygotuj_szkice)
        wynik_layout.addWidget(self.zapisz_szkice)
        self.info_produkty = etykieta("Po odczycie paczki program sprawdzi produkty po SKU.")
        wynik_layout.addWidget(self.info_produkty)
        wynik_layout.addWidget(self.tabela)
        self.tabs.addTab(wynik, "Oferty z paczki")
        self.info = etykieta(
            "Wybierz gotową paczkę ZIP — oferty pojawią się automatycznie po sprawdzeniu."
        )
        glowny.addWidget(self.info)

    def _zadanie(self, funkcja: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self.trwa:
            return
        self.trwa = True
        self.setEnabled(False)
        self.info.setText("Odczytywanie lub sprawdzanie danych…")

        def gotowe(wynik: object) -> None:
            self.trwa = False
            self.setEnabled(True)
            sukces(wynik)

        def blad(kod: str, tekst: str) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.info.setText(tekst)

        self.uruchom(funkcja, gotowe, blad)

    def _uniewaznij(self) -> None:
        self._generacja += 1
        self.oferty = ()
        self.plan_produktow = None
        if hasattr(self, "dodaj_produkty"):
            self.dodaj_produkty.setEnabled(False)
            self.sprawdz_katalog.setEnabled(False)
        if hasattr(self, "tabela"):
            self.tabela.setRowCount(0)

    def otworz(self) -> None:
        nazwa, _ = QFileDialog.getOpenFileName(
            self, "Paczka gotowych ofert", "", "Archiwum ZIP (*.zip)"
        )
        if not nazwa:
            return
        self._uniewaznij()
        self.paczka = None
        self.zapisano_produkty = False
        self.rozwin_konfiguracje.setChecked(False)
        self.tabs.setCurrentIndex(0)
        self.wybor_profilu.hide()
        self.kandydaci_profili = ()
        self.dialog_konfiguracji.reject()
        self.info_profili.setText("Rozpoznawanie układu paczki…")
        self.plik.clear()
        self.inwentarz.clear()
        self._zadanie(lambda: self.serwis.odczytaj(Path(nazwa)), self._wczytano)

    def _wczytano(self, wynik: object) -> None:
        self.paczka = cast(PaczkaOfert, wynik)
        self.inwentarz.setPlainText(
            self.paczka.nazwa
            + "\n"
            + "\n".join(f"{p.nazwa} • {p.rozmiar} B • {p.uwaga}" for p in self.paczka.pliki)
        )
        self.plik.addItem("Wybierz plik danych", None)
        for z in self.paczka.zbiory:
            self.plik.addItem(f"{z.nazwa} ({len(z.rekordy)} rekordów)", z.nazwa)
        if self.paczka.bledy_profili:
            self.info.setText(
                "Profil w ZIP jest nieprawidłowy. Nie otwarto ofert: "
                + "; ".join(self.paczka.bledy_profili)
            )
        elif len(self.paczka.profile) == 1:
            self._profil_zewnetrzny = False
            self._automatycznie(self.paczka.profile[0].profil)
        elif len(self.paczka.profile) > 1:
            self._lista_profili(
                tuple(p.profil for p in self.paczka.profile),
                "Paczka zawiera kilka układów. Wybierz właściwy z listy.",
            )
        elif self._profil_zewnetrzny and self.profil_wczytany is not None:
            self._automatycznie(self.profil_wczytany)
        else:
            paczka = self.paczka
            self._zadanie(lambda: self.serwis.rozpoznaj(paczka), self._rozpoznano)

    def _lista_profili(self, profile: tuple[ProfilPaczki, ...], komunikat: str) -> None:
        self.kandydaci_profili = profile
        self.wybor_profilu.blockSignals(True)
        self.wybor_profilu.clear()
        self.wybor_profilu.addItem("Wybierz układ paczki", None)
        for i, p in enumerate(profile):
            self.wybor_profilu.addItem(f"{p.nazwa} ({p.plik})", i)
        self.wybor_profilu.blockSignals(False)
        self.wybor_profilu.show()
        self.info_profili.setText(komunikat)
        self.info.setText(komunikat)

    def _rozpoznano(self, wynik: object) -> None:
        profile = cast(tuple[ProfilPaczki, ...], wynik)
        if len(profile) == 1:
            self._automatycznie(profile[0])
        elif profile:
            self._lista_profili(
                profile, "Pasuje kilka zapamiętanych układów. Wybierz jeden — bez mapowania pól."
            )
        else:
            self.info_profili.setText(
                "Nowy układ — wczytaj profil tylko za pierwszym razem. "
                "Kolejne paczki otworzą się same."
            )
            self.info.setText(
                "Nie rozpoznano układu paczki. "
                "Wczytaj profil z pliku lub użyj jednorazowo edytora zaawansowanego."
            )

    def _profil_z_paczki(self) -> None:
        indeks = self.wybor_profilu.currentData()
        if isinstance(indeks, int) and 0 <= indeks < len(self.kandydaci_profili):
            self._profil_zewnetrzny = False
            self._automatycznie(self.kandydaci_profili[indeks])

    def _konfiguruj(self) -> None:
        self.konfiguracja.show()
        self.dialog_konfiguracji.setModal(True)
        self.dialog_konfiguracji.open()

    def zapomnij(self) -> None:
        paczka, profil = self.paczka, self.profil_wczytany
        if paczka is None or profil is None:
            self.info_profili.setText("Najpierw otwórz paczkę z rozpoznanym układem.")
            return
        if (
            QMessageBox.question(
                self.dialog_konfiguracji,
                "Usuń zapamiętany układ",
                "Usunąć ten układ z pamięci programu? Produkty i pliki ZIP pozostaną bez zmian.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        self.dialog_konfiguracji.accept()
        self._zadanie(
            lambda: self.serwis.zapomnij(paczka, profil),
            lambda wynik: self.info_profili.setText(
                "Usunięto zapamiętany układ. "
                "Następna paczka bez profilu nie zostanie nim rozpoznana."
            ),
        )

    def _wynik_z_pamieci(self, wynik: object) -> None:
        dane = cast(WynikPodgladu, wynik)
        self._profil_zewnetrzny = False
        self.info_profili.setText(dane.informacja or "Układ odczytany. Sprawdź oferty z paczki.")
        self._pokaz(dane.oferty)

    def _automatycznie(self, profil: ProfilPaczki) -> None:
        self._ustaw_profil(profil)
        paczka = self.paczka
        if paczka is not None:
            self._zadanie(
                lambda: self.serwis.podglad_z_pamiecia(paczka, profil), self._wynik_z_pamieci
            )

    def _pola(self) -> None:
        nazwy: tuple[str, ...] = ()
        if self.paczka:
            zbior = next(
                (z for z in self.paczka.zbiory if z.nazwa == self.plik.currentData()), None
            )
            if zbior:
                nazwy = zbior.pola
        for box in self.mapy.values():
            box.blockSignals(True)
            box.clear()
            box.addItem("Nie wybrano / pomiń", "")
            for nazwa in nazwy:
                box.addItem(nazwa, nazwa)
            box.blockSignals(False)
        self._uniewaznij()

    def profil(self) -> ProfilPaczki:
        return ProfilPaczki(
            self.nazwa.text().strip(),
            str(self.plik.currentData() or ""),
            **{k: str(b.currentData() or "") for k, b in self.mapy.items()},
            **{k: b.text() for k, b in self.struktura.items()},
        )

    def wczytaj_profil(self) -> None:
        nazwa, _ = QFileDialog.getOpenFileName(
            self, "Profil użytkownika", "", "Profil JSON (*.json)"
        )
        if nazwa:
            self._zadanie(
                lambda: self.serwis.wczytaj_profil(Path(nazwa)),
                self._profil_z_pliku,
            )

    def _profil_z_pliku(self, wynik: object) -> None:
        self._profil_zewnetrzny = True
        self._automatycznie(cast(ProfilPaczki, wynik))

    def _ustaw_profil(self, profil: ProfilPaczki) -> None:
        self.profil_wczytany = profil
        self.nazwa.setText(profil.nazwa)
        if self.paczka is None:
            self.info.setText("Profil wczytany. Wybierz paczkę ZIP, aby zastosować mapowanie.")
            return
        self.plik.setCurrentIndex(self.plik.findData(profil.plik))
        self._pola()
        brak = self.plik.currentIndex() < 0
        for k, box in self.mapy.items():
            value = getattr(profil, k)
            index = box.findData(value)
            brak |= index < 0
            box.setCurrentIndex(index)
        for k, pole_struktury in self.struktura.items():
            pole_struktury.setText(getattr(profil, k))
        self.info.setText(
            "Profil nie pasuje do plików/pól tej paczki. Popraw mapowanie."
            if brak
            else "Profil wczytany. Sprawdź mapowanie i przygotuj podgląd."
        )

    def zapisz_profil(self) -> None:
        profil = self.profil()
        nazwa, _ = QFileDialog.getSaveFileName(
            self, "Zapisz profil pod nową nazwą", "", "Profil JSON (*.json)"
        )
        if nazwa:
            self._zadanie(
                lambda: self.serwis.zapisz_profil(Path(nazwa), profil),
                lambda wynik: self.info.setText(
                    "Profil zapisany. Możesz użyć go przy następnej paczce."
                ),
            )

    def podglad(self) -> None:
        if self.paczka is None:
            self.info.setText("Najpierw wybierz paczkę ZIP.")
            return
        paczka, profil = self.paczka, self.profil()
        self.dialog_konfiguracji.accept()
        self._uniewaznij()
        self._zadanie(lambda: self.serwis.podglad_z_pamiecia(paczka, profil), self._wynik_z_pamieci)

    def _pokaz(self, wynik: object) -> None:
        self.oferty = cast(tuple[OfertaPodglad, ...], wynik)
        self.tabela.setRowCount(len(self.oferty))
        self._partia(0, self._generacja)

    def _partia(self, start: int, numer: int) -> None:
        if numer != self._generacja:
            return
        for i in range(start, min(start + 100, len(self.oferty))):
            p = self.oferty[i]
            for j, value in enumerate(
                (
                    str(p.numer),
                    p.sku,
                    p.tytul,
                    p.ean,
                    p.cena,
                    str(len(p.zdjecia)),
                    str(len(p.sekcje)),
                    "; ".join(p.problemy),
                )
            ):
                self.tabela.setItem(i, j, QTableWidgetItem(value))
        if start + 100 < len(self.oferty):
            QTimer.singleShot(0, lambda: self._partia(start + 100, numer))
            return
        self.tabela.resizeColumnsToContents()
        self.tabela.setColumnWidth(2, 350)
        self.tabs.setCurrentIndex(1)
        self.info.setText(
            f"Podgląd: {len(self.oferty)} ofert, "
            f"{sum(bool(p.problemy) for p in self.oferty)} z problemami. "
            "Dwuklik — szczegóły i układ sekcji. Wysyłka na Allegro jeszcze niewdrożona."
        )

        self.sprawdz_produkty()

    def odswiez_producentow(self) -> None:
        def gotowe(wynik: object) -> None:
            wybrany = self.producent.currentData()
            self.producent.blockSignals(True)
            self.producent.clear()
            self.producent.addItem("Brak producenta", None)
            for p in cast(list[ProducentDTO], wynik):
                if p.aktywny:
                    self.producent.addItem(p.nazwa, str(p.id))
            self.producent.setCurrentIndex(max(0, self.producent.findData(wybrany)))
            self.producent.blockSignals(False)
            if self.oferty:
                self.sprawdz_produkty()
            else:
                self.info.setText("Wybierz gotową paczkę ZIP.")

        self._zadanie(self.producenci.lista, gotowe)

    def sprawdz_produkty(self) -> None:
        self.plan_produktow = None
        self.dodaj_produkty.setEnabled(False)
        self.sprawdz_katalog.setEnabled(bool(self.oferty) and not self.zapisano_produkty)
        if not self.oferty or self.paczka is None or self.zapisano_produkty:
            return
        oferty, paczka, profil = self.oferty, self.paczka, self.profil()
        pid = self.producent.currentData()
        producent = UUID(pid) if pid else None
        self.info_produkty.setText("Sprawdzanie produktów w katalogu…")
        self._zadanie(
            lambda: self.importer.zaplanuj_z_paczki(oferty, paczka.nazwa, profil.plik, producent),
            self._plan_katalogu,
        )

    def _plan_katalogu(self, wynik: object) -> None:
        self.plan_produktow = cast(PlanProduktowPaczki, wynik)
        p = self.plan_produktow
        self.dodaj_produkty.setEnabled(bool(p.oceny))
        self.info.setText(
            "Paczka sprawdzona. Możesz dodać nowe produkty do katalogu."
            if p.oceny
            else "Produkty o wskazanych SKU już są w katalogu — bez ponownego dodawania."
        )
        self.info_produkty.setText(
            f"Nowe poprawne: {len(p.wybrane)}. Do poprawy: {len(p.oceny) - len(p.wybrane)}. "
            f"Już w katalogu: {len(p.istniejace)} — bez nadpisywania. "
            "Dodawane pola: SKU, nazwa, tekst opisu i wybrany producent. "
            "Ceny, zdjęcia, EAN i układ oferty pozostają w paczce."
        )

    def przygotuj_szkice(self) -> None:
        if self.szkice is None or self.paczka is None or not self.oferty:
            return
        serwis, oferty, zrodlo = self.szkice, self.oferty, self.paczka.nazwa
        pid = self.producent.currentData()
        producent = UUID(pid) if pid else None
        self._zadanie(lambda: serwis.zaplanuj(oferty, zrodlo, producent), self._plan_szkicow)

    def _plan_szkicow(self, wynik: object) -> None:
        plan = cast(PlanSzkicow, wynik)
        if not plan.pozycje:
            self.info.setText("Brak prawidłowych ofert. " + "; ".join(plan.bledy[:5]))
            return
        nowe = len({p.oferta.sku.strip().casefold() for p in plan.pozycje if p.produkt_id is None})
        komunikat = (
            f"Zapisać {len(plan.pozycje)} ofert jako szkice lokalne?\n"
            f"Nowe produkty: {nowe}. Błędne wiersze pomijane: {len(plan.bledy)}.\n"
            "Identyczne zapisane oferty zostaną pominięte. Zmienione oferty "
            "utworzą osobne szkice. Produkty nie będą nadpisywane.\n"
            "Nie wysyła to ofert do Allegro. Powstanie kopia bazy."
        )
        if plan.bledy:
            komunikat += "\n\n" + "\n".join(plan.bledy[:5])
        if (
            QMessageBox.question(
                self,
                "Zapis lokalnych szkiców",
                komunikat,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        if self.szkice is not None:
            serwis = self.szkice
            self._zadanie(lambda: serwis.zapisz(plan), self._zapisano_szkice)

    def _zapisano_szkice(self, wynik: object) -> None:
        w = cast(WynikSzkicow, wynik)
        self.info.setText(
            f"Zapisane szkice: {w.zapisane}, identyczne pominięte: {w.pominiete}, "
            f"nowe produkty: {w.produkty}. Otwórz Szkice. Kopia: {w.kopia}"
        )
        self.zmieniono.emit()
        self.plan_produktow = None
        self.dodaj_produkty.setEnabled(False)
        self.info_produkty.setText("Produkty sprawdź ponownie przed osobnym importem.")

    def zapisz_produkty(self) -> None:
        plan = self.plan_produktow
        if plan is None or not plan.oceny or self.zapisano_produkty:
            return

        def zapisano(wynik: object) -> None:
            raport = cast(WynikImportu, wynik)
            self.zapisano_produkty = True
            self.plan_produktow = None
            self.dodaj_produkty.setEnabled(False)
            self.sprawdz_katalog.setEnabled(False)
            self.info_produkty.setText(
                f"Dodano produktów: {raport.dodane}. Do poprawy: {raport.odlozone}. "
                f"Już istniejące SKU: {len(plan.istniejace)} — zachowano wcześniejsze dane. "
                "Produkty znajdziesz w Produkty, błędne pozycje w Cenniki → Do poprawy."
            )
            self.info.setText("Produkty zapisano lokalnie. Oferty nie zostały wysłane na Allegro.")
            self.zmieniono.emit()

        self._zadanie(lambda: self.importer.zatwierdz(plan.oceny, plan.wybrane), zapisano)

    def szczegoly(self) -> None:
        i = self.tabela.currentRow()
        if not 0 <= i < len(self.oferty):
            self.info.setText("Wybierz ofertę z listy.")
            return
        dialog = SzczegolyPaczki(self.oferty[i], self)
        self.dialog = dialog
        dialog.setModal(True)
        dialog.finished.connect(lambda: self._zamknieto(dialog))
        dialog.open()

    def _zamknieto(self, dialog: SzczegolyPaczki) -> None:
        self.dialog = None
        dialog.deleteLater()
