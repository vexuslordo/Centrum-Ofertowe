"""Lokalna prezentacja Produktu, bez konta i statusów zewnętrznego API."""

from dataclasses import dataclass, replace
from uuid import UUID


@dataclass(frozen=True)
class SzkicOferty:
    id: UUID
    produkt_id: UUID
    wersja_produktu: int
    tytul: str
    opis: str
    wersja: int = 1

    def __post_init__(self) -> None:
        if not self.tytul.strip():
            raise ValueError("Tytuł szkicu jest wymagany.")
        if self.wersja < 1 or self.wersja_produktu < 1:
            raise ValueError("Nieprawidłowa wersja szkicu lub Produktu.")

    def zmien(self, tytul: str, opis: str) -> "SzkicOferty":
        return replace(self, tytul=tytul.strip(), opis=opis, wersja=self.wersja + 1)
