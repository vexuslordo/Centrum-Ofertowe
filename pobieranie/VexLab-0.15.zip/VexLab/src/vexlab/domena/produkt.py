"""Minimalny lokalny Produkt; bez cen, magazynu i modeli platform."""

from dataclasses import dataclass, replace
from typing import Self
from uuid import UUID


class BladKatalogu(Exception):
    """Bezpieczny błąd scenariusza katalogu."""


class NieprawidlowyProdukt(BladKatalogu):
    def __init__(self, komunikat: str, pole: str | None = None) -> None:
        super().__init__(komunikat)
        self.pole = pole


class SKUJuzIstnieje(BladKatalogu):
    pass


class KonfliktEdycji(BladKatalogu):
    pass


class ProduktNieIstnieje(BladKatalogu):
    pass


@dataclass(frozen=True)
class DopasowanieMotocykla:
    marka: str
    model: str
    rok_od: int | None = None
    rok_do: int | None = None
    wariant: str = ""

    def __post_init__(self) -> None:
        if not self.marka.strip() or not self.model.strip():
            raise NieprawidlowyProdukt(
                "Dopasowanie wymaga marki i modelu motocykla.", "dopasowania"
            )
        for rok in (self.rok_od, self.rok_do):
            if rok is not None and (type(rok) is not int or not 1000 <= rok <= 9999):
                raise NieprawidlowyProdukt(
                    "Rocznik musi być liczbą od 1000 do 9999.", "dopasowania"
                )
        if self.rok_do is not None and (self.rok_od is None or self.rok_do < self.rok_od):
            raise NieprawidlowyProdukt(
                "Rocznik do wymaga rocznika od i nie może być wcześniejszy.", "dopasowania"
            )

    @property
    def klucz(self) -> tuple[str, str, int | None, int | None, str]:
        return (
            self.marka.strip().casefold(),
            self.model.strip().casefold(),
            self.rok_od,
            self.rok_do,
            self.wariant.strip().casefold(),
        )


@dataclass(frozen=True)
class Produkt:
    id: UUID
    nazwa: str
    sku: str
    opis: str = ""
    wersja: int = 1
    producent_id: UUID | None = None
    dopasowania: tuple[DopasowanieMotocykla, ...] = ()

    def __post_init__(self) -> None:
        if not self.nazwa.strip():
            raise NieprawidlowyProdukt("Podaj nazwę produktu.", "nazwa")
        if not self.sku.strip():
            raise NieprawidlowyProdukt("Podaj obowiązkowy symbol SKU.", "sku")
        if self.nazwa != self.nazwa.strip() or self.sku != self.sku.strip():
            raise NieprawidlowyProdukt("Nazwa i SKU nie mogą mieć skrajnych odstępów.")
        if len({d.klucz for d in self.dopasowania}) != len(self.dopasowania):
            raise NieprawidlowyProdukt("Lista zawiera powtórzone dopasowanie.", "dopasowania")
        if self.wersja < 1:
            raise NieprawidlowyProdukt("Nieprawidłowa wersja produktu.")

    def zmien(
        self,
        nazwa: str,
        sku: str,
        opis: str,
        producent_id: UUID | None = None,
        dopasowania: tuple[DopasowanieMotocykla, ...] | None = None,
    ) -> Self:
        return replace(
            self,
            nazwa=nazwa,
            sku=sku,
            opis=opis,
            wersja=self.wersja + 1,
            producent_id=producent_id,
            dopasowania=self.dopasowania if dopasowania is None else dopasowania,
        )

    @property
    def klucz_sku(self) -> str:
        return self.sku.casefold()
