import json
import os
import sqlite3
import subprocess
import sys
from contextlib import closing
from pathlib import Path
from uuid import UUID


def test_start_diagnostyki_nie_tworzacy_danych(tmp_path: Path) -> None:
    wynik = subprocess.run(
        [sys.executable, "-m", "vexlab", "--diagnostyka"],
        cwd=tmp_path,
        env={**os.environ, "XDG_DATA_HOME": str(tmp_path), "LOCALAPPDATA": str(tmp_path)},
        capture_output=True,
        text=True,
        check=True,
        timeout=30,
    )
    raport = json.loads(wynik.stdout)
    assert raport["zakres"] == "diagnostyka_techniczna"
    assert raport["python"] == ".".join(map(str, sys.version_info[:3]))
    assert raport["pyside6"] == "6.12.0"
    assert raport["sqlite"]
    assert UUID(raport["id_korelacji"])
    assert list(tmp_path.iterdir()) == []


def test_import_centrum_bez_qt_sql_i_http() -> None:
    kod = """
import sys
class Blokada:
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'PySide6', 'sqlite3', 'http', 'urllib', 'requests', 'httpx'}:
            raise ImportError('Zabroniona zależność: ' + fullname)
sys.meta_path.insert(0, Blokada())
import vexlab.domena
import vexlab.domena.produkt
import vexlab.rdzen.kontrakty
import vexlab.przypadki_uzycia.diagnostyka
import vexlab.przypadki_uzycia.katalog
"""
    subprocess.run([sys.executable, "-c", kod], check=True, timeout=30)


def test_rzeczywisty_start_gui_nie_zasila_katalogu(tmp_path: Path) -> None:
    kod = """
import sys
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
from vexlab.bootstrap import main
oryginalne_exec = QApplication.exec
def krotka_petla(self):
    QTimer.singleShot(600, self.quit)
    return oryginalne_exec()
QApplication.exec = krotka_petla
sys.argv = ['vexlab', '--katalog-danych', sys.argv[1]]
raise SystemExit(main())
"""
    wynik = subprocess.run(
        [sys.executable, "-c", kod, str(tmp_path)],
        cwd=tmp_path,
        env={
            **os.environ,
            "QT_QPA_PLATFORM": "offscreen",
            "XDG_DATA_HOME": str(tmp_path),
            "XDG_CONFIG_HOME": str(tmp_path),
            "APPDATA": str(tmp_path),
            "LOCALAPPDATA": str(tmp_path),
        },
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert wynik.returncode == 0, wynik.stderr
    bazy = list(tmp_path.rglob("katalog.sqlite3"))
    assert len(bazy) == 1
    with closing(sqlite3.connect(bazy[0])) as conn:
        assert conn.execute("SELECT count(*) FROM produkty").fetchone()[0] == 0
