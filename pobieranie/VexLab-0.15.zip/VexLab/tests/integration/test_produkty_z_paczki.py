from dataclasses import replace

import pytest

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.tekst_opisu import tekst_katalogowy
from vexlab.rdzen.kontrakty import BladTechniczny


def oferta(sku="NEW", tytul="Gotowy produkt"):
    return OfertaPodglad(
        1,
        sku,
        tytul,
        "<p>Opis &amp; fakty</p><script>Nie wykonuj</script><ul><li>Cecha</li></ul>",
        "123",
        "999",
        "Motocykl w tekście",
        ("https://example.test/a.jpg",),
        (),
        (),
    )


def test_nowe_produkty_zapisane_stare_zachowane_bledy_trwale(tmp_path):
    repo = ImportSQLite(tmp_path / "k.sqlite3")
    kat = KatalogProduktow(repo, repo)
    stary = kat.dodaj(DaneProduktu("Zachowaj", "OLD", "Stary opis"))
    imp = ImportujProdukty(CzytnikTabel(), repo, repo)
    plan = imp.zaplanuj_z_paczki(
        (
            oferta("old", "Nie zmień"),
            oferta(),
            replace(oferta(""), numer=3, problemy=("Brak SKU",)),
        ),
        "paczka.zip",
        "lista.json",
    )
    assert len(plan.istniejace) == 1 and len(plan.wybrane) == 1 and len(plan.oceny) == 2
    assert len(kat.wyszukaj()) == 1
    wynik = imp.zatwierdz(plan.oceny, plan.wybrane)
    assert (wynik.dodane, wynik.odlozone) == (1, 1)
    produkty = {p.sku: p for p in kat.wyszukaj()}
    assert produkty["OLD"] == stary
    assert produkty["NEW"].opis == "Opis & fakty\n- Cecha"
    assert produkty["NEW"].cena_sugerowana is None and produkty["NEW"].dopasowania == ()
    assert produkty["NEW"].miniatura is None
    drugi = ImportSQLite(repo.plik)
    assert drugi.oczekujace()[0].zrodlo == "paczka.zip"
    assert drugi.oczekujace()[0].dane.sku == ""
    ponowny = imp.zaplanuj_z_paczki((oferta("OLD"), oferta()), "paczka.zip", "lista.json")
    assert not ponowny.oceny and len(ponowny.istniejace) == 2


def test_podwojne_sku_nie_tworz_dwoch_produktow(tmp_path):
    repo = ImportSQLite(tmp_path / "k.sqlite3")
    imp = ImportujProdukty(CzytnikTabel(), repo, repo)
    plan = imp.zaplanuj_z_paczki(
        (oferta("NEW"), replace(oferta("new"), numer=2)), "z.zip", "a.json"
    )
    assert not plan.wybrane and all(o.problem for o in plan.oceny)
    wynik = imp.zatwierdz(plan.oceny, plan.wybrane)
    assert wynik.dodane == 0 and wynik.odlozone == 2


def test_konflikt_po_planie_i_awaria_portu_nie_nadpisuja(tmp_path, monkeypatch):
    repo = ImportSQLite(tmp_path / "k.sqlite3")
    kat = KatalogProduktow(repo, repo)
    imp = ImportujProdukty(CzytnikTabel(), repo, repo)
    plan = imp.zaplanuj_z_paczki((oferta(),), "z.zip", "a.json")
    kat.dodaj(DaneProduktu("Inna sesja", "NEW"))
    with pytest.raises(BladScenariuszaKatalogu):
        imp.zatwierdz(plan.oceny, plan.wybrane)
    assert kat.wyszukaj()[0].nazwa == "Inna sesja"
    plan = imp.zaplanuj_z_paczki((oferta("INNY"),), "z.zip", "a.json")
    orig = repo._dodaj_importowany

    def awaria(conn, p):
        orig(conn, p)
        raise BladTechniczny("Awaria po zapisie")

    monkeypatch.setattr(repo, "_dodaj_importowany", awaria)
    with pytest.raises(BladTechniczny):
        imp.zatwierdz(plan.oceny, plan.wybrane)
    assert len(kat.wyszukaj()) == 1 and not imp.oczekujace()


def test_opis_jest_tekstem_bez_skryptow_i_odczytu_obrazow():
    assert (
        tekst_katalogowy(
            '<h1>Tytuł</h1><p>A <b>B</b></p><img src="file:///sekret"><style>hidden</style>'
        )
        == "Tytuł\nA B"
    )
    assert tekst_katalogowy("Zwykły tekst\nDruga linia") == "Zwykły tekst\nDruga linia"
