import csv
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.katalog import ProduktDTO
from vexlab.rdzen.kontrakty import BladTechniczny


def produkt(
    nazwa: str = "Żółty; produkt", sku: str = "TEST-A", opis: str = 'Opis "cytowany"\nDrugi wiersz'
) -> ProduktDTO:
    return ProduktDTO(uuid4(), nazwa, sku, opis, 1, producent_nazwa="Producent testowy")


def test_csv_zachowuje_polskie_litery_separator_cudzyslow_i_nowa_linie(tmp_path: Path) -> None:
    cel = tmp_path / "wynik.csv"
    p = produkt()
    wynik = EksportujKatalog(EksportCSV()).wykonaj(cel, (p,))
    assert wynik.produkty == 1 and wynik.zabezpieczone_pola == 0
    assert cel.read_bytes().startswith(b"\xef\xbb\xbf")
    with cel.open(encoding="utf-8-sig", newline="") as plik:
        rows = list(csv.reader(plik, delimiter=";"))
    assert rows == [
        ["Nazwa produktu", "SKU", "Opis", "Producent"],
        [p.nazwa, p.sku, p.opis, p.producent_nazwa],
    ]


@pytest.mark.parametrize(
    "opis", ["=1+1", "+SUM(A1)", "-1+1", "@SUM(A1)", " \t=1", "\r\n+1", "\ufeff =1"]
)
def test_formuly_sa_zabezpieczone_apostrofem(tmp_path: Path, opis: str) -> None:
    cel = tmp_path / "formuly.csv"
    p = produkt(opis=opis)
    wynik = EksportCSV().zapisz(cel, (p,))
    with cel.open(encoding="utf-8-sig", newline="") as plik:
        rows = list(csv.reader(plik, delimiter=";"))
    assert rows[1][2] == "'" + opis
    assert wynik.zabezpieczone_pola == 1
    assert p.opis == opis


def test_export_nie_nadpisuje_istniejacego_pliku(tmp_path: Path) -> None:
    cel = tmp_path / "istniejacy.csv"
    cel.write_bytes(b"zachowaj")
    with pytest.raises(BladTechniczny, match="już istnieje"):
        EksportCSV().zapisz(cel, (produkt(),))
    assert cel.read_bytes() == b"zachowaj"


def test_pusty_zestaw_nie_tworzy_pliku(tmp_path: Path) -> None:
    cel = tmp_path / "pusty.csv"
    with pytest.raises(BladScenariuszaKatalogu) as blad:
        EksportujKatalog(EksportCSV()).wykonaj(cel, ())
    assert blad.value.kod == "BRAK_DANYCH"
    assert not cel.exists()


def test_blad_sprzatania_jawnie_oznacza_niekompletny_plik(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cel = tmp_path / "pozostal.csv"

    class Awaria:
        def writerow(self, pola):
            raise OSError("Błąd zapisu")

    def nie_usuwaj(plik, **kwargs):
        raise PermissionError("Symulacja blokady pliku")

    monkeypatch.setattr(csv, "writer", lambda *a, **kw: Awaria())
    monkeypatch.setattr(Path, "unlink", nie_usuwaj)
    with pytest.raises(BladTechniczny, match="niekompletny plik"):
        EksportCSV().zapisz(cel, (produkt(),))
    assert cel.exists()


def test_niedostepny_katalog_nie_udaje_sukcesu(tmp_path: Path) -> None:
    with pytest.raises(BladTechniczny):
        EksportCSV().zapisz(tmp_path / "nieistniejacy" / "wynik.csv", (produkt(),))


def test_awaria_po_pierwszym_wierszu_usuwa_niekompletny_nowy_plik(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cel = tmp_path / "awaria.csv"
    oryginalny = csv.writer

    class Awaria:
        def __init__(self, *args, **kwargs):
            self.writer = oryginalny(*args, **kwargs)
            self.wiersze = 0

        def writerow(self, pola):
            self.wiersze += 1
            if self.wiersze == 2:
                raise OSError("Symulacja braku miejsca")
            return self.writer.writerow(pola)

    monkeypatch.setattr(csv, "writer", Awaria)
    with pytest.raises(BladTechniczny, match="Nie udało się"):
        EksportCSV().zapisz(cel, (produkt(),))
    assert not cel.exists()
