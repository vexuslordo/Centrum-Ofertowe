from uuid import uuid4

import pytest

from vexlab.domena.oferta import SzkicOferty


@pytest.mark.parametrize("tytul", ["", "   "])
def test_szkic_wymaga_tytulu(tytul):
    with pytest.raises(ValueError):
        SzkicOferty(uuid4(), uuid4(), 1, tytul, "")


def test_edycja_nie_zmienia_produktu_i_zwieksza_wersje():
    s = SzkicOferty(uuid4(), uuid4(), 4, "Tytuł", "")
    n = s.zmien(" Nowy ", "<p>HTML</p>")
    assert n.id == s.id and n.produkt_id == s.produkt_id and n.wersja_produktu == 4
    assert n.wersja == 2 and n.tytul == "Nowy" and s.tytul == "Tytuł"
