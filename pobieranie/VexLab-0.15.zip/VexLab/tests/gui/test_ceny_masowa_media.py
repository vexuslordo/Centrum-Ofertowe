import pytest
from PySide6.QtCore import QBuffer, QIODevice, QSettings, Qt
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QMessageBox

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.adaptery.zdjecia_shopify import obraz
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty, Mapowanie, MapowanieCeny
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.media import KandydaciZdjec, PobierzZdjecia
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow


class ZrodloTestowe:
    def pobierz(self, adres, sku):
        image = QImage(16, 16, QImage.Format.Format_RGB32)
        image.fill(0xFF0000)
        buf = QBuffer()
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        image.save(buf, "PNG")
        z = obraz(bytes(buf.data().data()), adres + "/zdjecie.png")
        return KandydaciZdjec(adres + "/products/test", "Tytuł źródła", sku, (z,))


@pytest.fixture
def okno(qtbot, tmp_path, monkeypatch):
    repo = ImportSQLite(tmp_path / "test.sqlite3")
    kat = KatalogProduktow(repo, repo)
    rejestr = RejestrProducentow(repo)
    producent = rejestr.dodaj(DaneProducenta("Producent", strona_www="https://shop.example"))
    kat.dodaj(DaneProduktu("A", "A", "Stary opis", producent.id))
    kat.dodaj(DaneProduktu("B", "B"))
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        kat,
        rejestr,
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
        PobierzZdjecia(ZrodloTestowe()),
    )
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **kw: QMessageBox.StandardButton.Ok)
    qtbot.addWidget(w)
    w.show()
    qtbot.waitUntil(lambda: not w._zadania and w._katalog_wczytany)
    w.przejdz("Produkty")
    yield w
    qtbot.waitUntil(lambda: not w._zadania)
    if w.formularz:
        w.formularz.reject()
    if w.masowy:
        w.masowy.reject()
    w.close()


def czekaj(qtbot, w):
    qtbot.waitUntil(lambda: not w._zadania and not w._ladowanie_masowej)


def test_zaznacz_wszystkie_dotyczy_filtra_i_przetrwa_odswiezenie(qtbot, okno):
    okno.szukaj.setText("A")
    okno.tabela_select_all()
    assert len(okno._zaznaczone_w_tabeli(okno.tabela_produktow)) == 1
    okno.odswiez()
    czekaj(qtbot, okno)
    assert len(okno._zaznaczone_w_tabeli(okno.tabela_produktow)) == 1
    okno.szukaj.clear()
    okno.tabela_select_all()
    assert len(okno._zaznaczone_w_tabeli(okno.tabela_produktow)) == 2
    assert "2" in okno.info_zaznaczenia.text()
    okno.odznacz_wszystkie.trigger()
    assert not okno._zaznaczone_w_tabeli(okno.tabela_produktow)


def test_anulowanie_usuniecia_nie_zmienia_danych(qtbot, okno, monkeypatch):
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **kw: QMessageBox.StandardButton.No)
    okno.tabela_select_all()
    okno.usun_zaznaczony()
    czekaj(qtbot, okno)
    assert len(okno.katalog.wyszukaj()) == 2
    assert not (okno.importer.magazyn.plik.parent / "kopie_usuwania").exists()


def test_usuwanie_wynikow_uzywa_migawki_sprzed_potwierdzenia(qtbot, okno, monkeypatch):
    okno.szukaj.setText("A")

    def zgoda(*a, **kw):
        okno.szukaj.clear()
        return QMessageBox.StandardButton.Yes

    monkeypatch.setattr(QMessageBox, "question", zgoda)
    okno.usun_wyniki()
    czekaj(qtbot, okno)
    assert [p.sku for p in okno.katalog.wyszukaj()] == ["B"]
    assert len(list((okno.importer.magazyn.plik.parent / "kopie_usuwania").glob("*.sqlite3"))) == 1


def test_masowa_zmiana_producenta_i_dopisanie_opisu(qtbot, okno):
    okno.tabela_select_all()
    okno.edycja_masowa()
    czekaj(qtbot, okno)
    d = okno.masowy
    assert d is not None
    d.zmien_producenta.setChecked(True)
    d.producent.setCurrentIndex(1)
    d.tryb.setCurrentIndex(d.tryb.findData("dopisz"))
    d.opis.setPlainText("Dopisek")
    qtbot.mouseClick(d.zapisz, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert okno.masowy is None
    p = okno.katalog.wyszukaj()
    assert all(x.producent_nazwa == "Producent" for x in p)
    assert p[0].opis == "Stary opis\n\nDopisek" and p[1].opis == "Dopisek"


def test_cena_widoczna_w_tabeli_i_szczegolach(qtbot, okno, tmp_path):
    file = tmp_path / "cennik.csv"
    file.write_text("Nazwa;SKU;Cena\nC;C;99,50\n")
    imp = okno.importer
    o = imp.zaplanuj(
        imp.odczytaj(file), 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "EUR", "brutto")), None
    )
    imp.zatwierdz(o, frozenset([o[0].pozycja.id]))
    okno.odswiez()
    czekaj(qtbot, okno)
    okno.szukaj.setText("C")
    indeks = okno.filtr.index(0, 4)
    assert indeks.data() == "99,50 EUR brutto"
    okno.pokaz_szczegoly(indeks)
    assert okno.szczegoly.cena.text() == "99,50 EUR brutto"
    okno.szczegoly.reject()


def test_zdjecia_pobierane_przed_dodaniem_i_zapisywane_dopiero_po_wyborze(qtbot, okno):
    okno.dodaj_produkt()
    czekaj(qtbot, okno)
    d = okno.formularz
    d.nazwa.setText("Nowy")
    d.sku.setText("NOWY")
    d.producent.setCurrentIndex(1)
    assert d.strona_www.text() == "https://shop.example"
    qtbot.mouseClick(d.pobierz_zdjecia, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert len(d.fotografie) == 1
    assert not okno.katalog.wyszukaj("NOWY")
    assert not d.wybrane_zdjecia()
    d.wybory_zdjec[0].setChecked(True)
    qtbot.mouseClick(d.zapisz, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert okno.katalog.wyszukaj("NOWY")[0].miniatura is not None


def test_zmiana_sku_uniewaznia_wybrane_zdjecia(qtbot, okno):
    okno.dodaj_produkt()
    czekaj(qtbot, okno)
    d = okno.formularz
    d.sku.setText("X")
    d.strona_www.setText("https://shop.example")
    qtbot.mouseClick(d.pobierz_zdjecia, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    d.wybory_zdjec[0].setChecked(True)
    d.sku.setText("Y")
    assert not d.fotografie and not d.wybrane_zdjecia()


def test_uzupelnienie_ceny_z_podgladem_bez_usuwania_istniejacego_produktu(qtbot, okno, tmp_path):
    from PySide6.QtWidgets import QDialogButtonBox

    from vexlab.gui.importowanie import DialogPotwierdzenia

    p = tmp_path / "ceny.csv"
    p.write_text("Nazwa;Kod;Cena\nNazwa z pliku;A;12.50\n")
    okno.przejdz("Cenniki")
    czekaj(qtbot, okno)
    s = okno.strona_importu
    s._plik_wczytany((okno.importer.odczytaj(p), okno.producenci.lista()))
    s.kol_nazwa.setCurrentIndex(s.kol_nazwa.findData(0))
    s.kol_sku.setCurrentIndex(s.kol_sku.findData(1))
    s.kol_cena.setCurrentIndex(s.kol_cena.findData(2))
    s.waluta.setCurrentText("EUR")
    s.rodzaj_ceny.setCurrentText("netto")
    s.zaplanuj()
    czekaj(qtbot, okno)
    assert "SKU istnieje" in s.oceny[0].problem
    s.podglad_cen()
    czekaj(qtbot, okno)
    d = next(d for d in s.findChildren(DialogPotwierdzenia) if d.isVisible())
    buttons = d.findChild(QDialogButtonBox)
    qtbot.mouseClick(
        buttons.button(QDialogButtonBox.StandardButton.Save), Qt.MouseButton.LeftButton
    )
    czekaj(qtbot, okno)
    produkty = okno.katalog.wyszukaj()
    assert len(produkty) == 2
    assert produkty[0].nazwa == "A" and produkty[0].opis == "Stary opis"
    assert produkty[0].cena_sugerowana.etykieta == "12,50 EUR netto"


@pytest.mark.parametrize("strona", ["Produkty", "Masowa edycja"])
def test_masowa_zmiana_2375_produktow_odswieza_zaznaczenie_zbiorczo(qtbot, okno, tmp_path, strona):
    from threading import get_ident
    from time import perf_counter

    from PySide6.QtCore import QTimer
    from PySide6.QtTest import QSignalSpy

    plik = tmp_path / "duzy.csv"
    plik.write_text(
        "Nazwa;SKU\n"
        + "".join(f"Produkt wydajnościowy {i:04d};PERF-{i:04d}\n" for i in range(2373)),
        encoding="utf-8",
    )
    imp = okno.importer
    plan = imp.zaplanuj(imp.odczytaj(plik), 0, Mapowanie(1, 0, 1), None)
    imp.zatwierdz(plan, frozenset(o.pozycja.id for o in plan))
    okno.odswiez()
    czekaj(qtbot, okno)
    okno.przejdz(strona)
    tabela = okno.tabela_masowa if strona == "Masowa edycja" else okno.tabela_produktow
    tabela.selectAll()
    assert len(okno._zaznaczone_w_tabeli(tabela)) == 2375
    okno.edycja_masowa()
    czekaj(qtbot, okno)
    dialog = okno.masowy
    assert dialog is not None
    dialog.zmien_producenta.setChecked(True)
    dialog.producent.setCurrentIndex(1)
    spy = QSignalSpy(tabela.selectionModel().selectionChanged)
    watki = []
    orig = okno.katalog._repozytorium.zapisz_wiele

    def zapis(produkty):
        watki.append(get_ident())
        return orig(produkty)

    okno.katalog._repozytorium.zapisz_wiele = zapis
    odstepy = []
    ostatni = [perf_counter()]

    def tick():
        teraz = perf_counter()
        odstepy.append(teraz - ostatni[0])
        ostatni[0] = teraz

    timer = QTimer(okno)
    timer.setInterval(10)
    timer.timeout.connect(tick)
    timer.start()
    try:
        qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
        qtbot.waitUntil(lambda: not okno._zadania and okno.masowy is None, timeout=30000)
        qtbot.wait(30)
    finally:
        timer.stop()
    produkty = okno.katalog.wyszukaj()
    assert len(produkty) == 2375
    assert all(p.producent_nazwa == "Producent" for p in produkty)
    assert len(okno._zaznaczone_w_tabeli(tabela)) == 2375
    # Chroni przed powrotem odtwarzania N wierszy z N kosztownymi sygnałami.
    assert spy.count() <= 3
    assert watki and all(w != get_ident() for w in watki)
    assert odstepy and max(odstepy) < 8.0
    assert (
        len(list((okno.importer.magazyn.plik.parent / "kopie_edycji_masowej").glob("*.sqlite3")))
        == 1
    )


def test_odswiezanie_zachowuje_niesasiedni_wybor_po_sortowaniu(qtbot, okno):
    from PySide6.QtCore import QItemSelectionModel
    from PySide6.QtTest import QSignalSpy

    for i in range(8):
        okno.katalog.dodaj(DaneProduktu(f"Produkt {i}", f"WYBOR-{i}"))
    okno.odswiez()
    czekaj(qtbot, okno)
    okno.tabela_produktow.sortByColumn(1, Qt.SortOrder.DescendingOrder)
    sm = okno.tabela_produktow.selectionModel()
    for nr in (0, 2, 3, 7):
        sm.select(
            okno.filtr.index(nr, 1),
            QItemSelectionModel.SelectionFlag.Select | QItemSelectionModel.SelectionFlag.Rows,
        )
    przed = {p.id for p in okno._zaznaczone_w_tabeli(okno.tabela_produktow)}
    spy = QSignalSpy(sm.selectionChanged)
    okno.odswiez()
    czekaj(qtbot, okno)
    assert {p.id for p in okno._zaznaczone_w_tabeli(okno.tabela_produktow)} == przed
    assert spy.count() <= 3


def test_galeria_pliki_i_zapis_w_tle_odswiezaja_miniature(qtbot, okno, tmp_path, monkeypatch):
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QFileDialog

    from vexlab.adaptery.zdjecia_lokalne import LokalneZdjecia
    from vexlab.gui.galeria import GaleriaProduktu
    from vexlab.przypadki_uzycia.galeria import GaleriaProduktow

    repo = ImportSQLite(tmp_path / "test.sqlite3")
    okno.galeria = GaleriaProduktow(repo, LokalneZdjecia())
    image = QImage(16, 16, QImage.Format.Format_RGB32)
    image.fill(0x00FF00)
    plik = tmp_path / "lokalne.png"
    assert image.save(str(plik), "PNG")
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a: ([str(plik)], ""))
    okno.tabela_produktow.selectRow(0)
    produkt = okno._zaznaczone_w_tabeli(okno.tabela_produktow)[0]
    dialogi = []

    def modal(dialog):
        dialogi.append(dialog)
        dialog.dodaj()
        assert dialog.trwa
        QTimer.singleShot(0, lambda: None)
        qtbot.waitUntil(lambda: not dialog.trwa)
        assert len(dialog.zdjecia) == 1
        dialog.zapisz()
        assert dialog.trwa
        qtbot.waitUntil(lambda: not dialog.trwa)
        return 1

    monkeypatch.setattr(GaleriaProduktu, "exec", modal)
    okno.pokaz_galerie()
    qtbot.waitUntil(lambda: bool(dialogi) and not okno._zadania)
    assert okno.galeria.odczytaj(produkt.id).zdjecia
    assert next(p for p in okno.model.produkty if p.id == produkt.id).miniatura


def test_media_maja_osobna_strone_i_galerie_wybranego_tam_produktu(
    qtbot, okno, tmp_path, monkeypatch
):
    from PySide6.QtWidgets import QPushButton

    from vexlab.adaptery.zdjecia_lokalne import LokalneZdjecia
    from vexlab.gui.galeria import GaleriaProduktu
    from vexlab.przypadki_uzycia.galeria import GaleriaProduktow

    repo = ImportSQLite(tmp_path / "test.sqlite3")
    okno.galeria = GaleriaProduktow(repo, LokalneZdjecia())
    okno._media()
    okno.przejdz("Zdjęcia i media")
    strona = okno.strony["Zdjęcia i media"]
    assert strona is not okno.strony["Produkty"]
    assert okno.stos.currentWidget() is strona
    assert okno.przyciski_menu["Zdjęcia i media"].isChecked()
    assert not okno.przyciski_menu["Produkty"].isChecked()
    assert not any("Usuń wszystkie" in b.text() for b in strona.findChildren(QPushButton))
    okno.szukaj.setText("B")
    assert okno.stos.currentWidget() is strona and okno.filtr.rowCount() == 1
    okno.tabela_mediow.selectRow(0)
    oczekiwany = okno._zaznaczone_w_tabeli(okno.tabela_mediow)[0]
    otwarte = []
    monkeypatch.setattr(GaleriaProduktu, "exec", lambda d: otwarte.append(d.dane.produkt_id))
    button = next(
        b for b in strona.findChildren(QPushButton) if b.text().startswith("Otwórz galerię")
    )
    button.click()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert otwarte == [oczekiwany.id]
    okno.szukaj.setText("nieistniejący")
    assert "Brak produktów" in okno.info_mediow.text()
    okno.przejdz("Produkty")
    assert okno.stos.currentWidget() is okno.strony["Produkty"]


def test_dopasowania_formularz_walidacja_zapis_podglad_i_anulowanie(qtbot, okno, monkeypatch):
    from PySide6.QtWidgets import QDialog

    from vexlab.gui.dopasowania import EdytorDopasowan
    from vexlab.przypadki_uzycia.katalog import DaneDopasowania

    def edytuj(dialog):
        dialog.dodaj(DaneDopasowania("Marka A", "", "2018", "2020"))
        dialog.dodaj(DaneDopasowania("Marka B", "Model Y", "2021", "", "S"))
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(EdytorDopasowan, "exec", edytuj)
    okno.edytuj_indeks(okno.filtr.index(0, 1))
    czekaj(qtbot, okno)
    dialog = okno.formularz
    dialog.edytuj_dopasowania()
    assert len(dialog.dane().dopasowania) == 2
    dialog.nazwa.setText("Nowy tytuł")
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert dialog.blad.text() and dialog.isVisible()
    assert okno.katalog.wyszukaj("A")[0].nazwa == "A"
    dialog.dopasowania = (
        DaneDopasowania("Marka A", "Model X", "2018", "2020"),
        dialog.dopasowania[1],
    )
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert okno.formularz is None
    p = okno.katalog.wyszukaj("Nowy tytuł")[0]
    assert len(p.dopasowania) == 2
    okno.szukaj.setText("Nowy tytuł")
    okno.pokaz_szczegoly(okno.filtr.index(0, 1))
    tekst = okno.szczegoly.dopasowania_podglad.toPlainText()
    assert "Model X" in tekst and "koniec niepodany" in tekst
    okno.szczegoly.reject()
    okno.edytuj_indeks(okno.filtr.index(0, 1))
    czekaj(qtbot, okno)
    dialog = okno.formularz
    assert dialog.dane().dopasowania[0].model == "Model X"
    dialog.dopasowania = ()
    dialog.reject()
    assert len(okno.katalog.wyszukaj("Nowy tytuł")[0].dopasowania) == 2


def test_masowa_ma_osobna_strone_i_zmienia_wybor_z_tego_widoku(qtbot, okno):
    from PySide6.QtWidgets import QPushButton

    okno.tabela_produktow.selectRow(0)
    okno.przejdz("Masowa edycja")
    strona = okno.strony["Masowa edycja"]
    assert strona is not okno.strony["Produkty"]
    assert okno.stos.currentWidget() is strona and okno.masowy is None
    assert okno.przyciski_menu["Masowa edycja"].isChecked()
    assert not okno.przyciski_menu["Produkty"].isChecked()
    assert not okno.zmiana_masowa_przycisk.isEnabled()
    teksty = [b.text() for b in strona.findChildren(QPushButton)]
    assert not any("Dodaj produkt" in t or "Importuj" in t or "Usuń" in t for t in teksty)
    okno.tabela_masowa.selectRow(1)
    assert "Zaznaczono: 1" in okno.info_masowej.text()
    okno.zmiana_masowa_przycisk.click()
    czekaj(qtbot, okno)
    d = okno.masowy
    assert d is not None
    d.tryb.setCurrentIndex(d.tryb.findData("zastap"))
    d.opis.setPlainText("Zmiana wyłącznie B")
    d.zapisz.click()
    czekaj(qtbot, okno)
    a, b = okno.katalog.wyszukaj()
    assert a.opis == "Stary opis" and b.opis == "Zmiana wyłącznie B"
    assert len(okno._zaznaczone_w_tabeli(okno.tabela_masowa)) == 1
    assert "Zaznaczono: 1" in okno.info_masowej.text()


def test_masowa_wyszukiwanie_wybor_wynikow_i_pusty_stan(qtbot, okno):
    from PySide6.QtWidgets import QPushButton

    okno.przejdz("Masowa edycja")
    strona = okno.strony["Masowa edycja"]
    okno.szukaj.setText("B")
    assert okno.stos.currentWidget() is strona
    wszystkie = next(
        b for b in strona.findChildren(QPushButton) if b.text() == "Zaznacz wszystkie wyniki"
    )
    wszystkie.click()
    assert [p.sku for p in okno._zaznaczone_w_tabeli(okno.tabela_masowa)] == ["B"]
    odznacz = next(b for b in strona.findChildren(QPushButton) if b.text() == "Odznacz")
    odznacz.click()
    assert not okno.zmiana_masowa_przycisk.isEnabled()
    okno.szukaj.setText("nieistniejący")
    assert "Brak wyników" in okno.info_masowej.text()
    okno.wyczysc_filtry()
    assert okno.filtr.rowCount() == 2 and okno.stos.currentWidget() is strona


def test_menu_produktow_udostepnia_te_same_akcje_i_reaguje_na_wybor(qtbot, okno):
    from vexlab.adaptery.zdjecia_lokalne import LokalneZdjecia
    from vexlab.przypadki_uzycia.galeria import GaleriaProduktow

    okno.galeria = GaleriaProduktow(okno.importer.magazyn, LokalneZdjecia())
    assert len(okno._przyciski_produktow) == 4
    assert okno.wiecej_produktow.menu() is okno.menu_produktow
    for akcja in (
        okno.szczegoly_akcja,
        okno.edycja_akcja,
        okno.galeria_akcja,
        okno.edytuj_masowo_przycisk,
        okno.usun_przycisk,
        okno.wyczysc_przycisk,
        okno.eksportuj_przycisk,
        okno.odznacz_wszystkie,
    ):
        assert akcja in okno.menu_produktow.actions()
        assert akcja in okno.menu_kontekstowe_produktow.actions()
    okno.tabela_produktow.clearSelection()
    okno.menu_produktow.aboutToShow.emit()
    assert not okno.edycja_akcja.isEnabled() and not okno.usun_przycisk.isEnabled()
    assert okno.wyczysc_przycisk.isEnabled() and okno.eksportuj_przycisk.isEnabled()
    okno.tabela_produktow.selectRow(0)
    assert okno.edycja_akcja.isEnabled() and okno.galeria_akcja.isEnabled()
    okno.szczegoly_akcja.trigger()
    assert okno.szczegoly.produkt.sku == "A"
    okno.szczegoly.reject()
    qtbot.waitUntil(lambda: okno.szczegoly is None)
    okno.tabela_select_all()
    assert not okno.edycja_akcja.isEnabled() and not okno.galeria_akcja.isEnabled()
    assert okno.edytuj_masowo_przycisk.isEnabled() and okno.usun_przycisk.isEnabled()
    okno.odznacz_wszystkie.trigger()
    okno.szukaj.setText("Nieistniejący produkt")
    assert not okno.wyczysc_przycisk.isEnabled() and not okno.eksportuj_przycisk.isEnabled()


def test_prawy_przycisk_wybiera_cel_zachowuje_grupe_i_nie_usuwaja_bez_potwierdzenia(
    qtbot, okno, monkeypatch
):
    from PySide6.QtCore import QPoint
    from PySide6.QtGui import QContextMenuEvent
    from PySide6.QtWidgets import QApplication, QMenu

    menu_otwarte = []
    monkeypatch.setattr(QMenu, "popup", lambda self, punkt: menu_otwarte.append(self))
    tabela = okno.tabela_produktow
    okno.tabela_select_all()
    punkt = tabela.visualRect(okno.filtr.index(0, 1)).center()
    event = QContextMenuEvent(
        QContextMenuEvent.Reason.Mouse, punkt, tabela.viewport().mapToGlobal(punkt)
    )
    QApplication.sendEvent(tabela.viewport(), event)
    assert len(okno._zaznaczone_w_tabeli(tabela)) == 2
    assert not okno.szczegoly_akcja.isEnabled() and okno.usun_przycisk.isEnabled()
    tabela.clearSelection()
    tabela.selectRow(0)
    punkt = tabela.visualRect(okno.filtr.index(1, 1)).center()
    tabela.customContextMenuRequested.emit(punkt)
    assert [p.sku for p in okno._zaznaczone_w_tabeli(tabela)] == ["B"]
    assert okno.edycja_akcja.isEnabled()
    pytania = []

    def odmowa(*args, **kwargs):
        pytania.append(args[2])
        return QMessageBox.StandardButton.No

    monkeypatch.setattr(QMessageBox, "question", odmowa)
    okno.usun_przycisk.trigger()
    assert "1 lokalnych" in pytania[0]
    assert len(okno.katalog.wyszukaj()) == 2
    assert menu_otwarte[-1] is okno.menu_kontekstowe_produktow
    tabela.customContextMenuRequested.emit(QPoint(4, tabela.viewport().height() - 4))
    assert not okno._zaznaczone_w_tabeli(tabela)
    assert not okno.usun_przycisk.isEnabled() and not okno.edycja_akcja.isEnabled()


def test_menu_klawiaturowe_nie_zmienia_zaznaczenia(qtbot, okno, monkeypatch):
    from PySide6.QtWidgets import QMenu

    otwarte = []
    monkeypatch.setattr(QMenu, "popup", lambda self, punkt: otwarte.append(self))
    okno.tabela_select_all()
    okno.tabela_produktow.setFocus()
    qtbot.keyClick(okno.tabela_produktow, Qt.Key.Key_F10, Qt.KeyboardModifier.ShiftModifier)
    assert otwarte == [okno.menu_kontekstowe_produktow]
    assert len(okno._zaznaczone_w_tabeli(okno.tabela_produktow)) == 2
