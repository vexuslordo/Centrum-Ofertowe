import ast
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "src" / "vexlab"
CENTRUM = {"rdzen", "domena", "przypadki_uzycia"}
ZAKAZANE = {"PySide6", "sqlite3", "requests", "httpx", "http", "urllib"}


def naruszenia_zewnetrzne(plik: Path, warstwa: str) -> list[str]:
    naruszenia = []
    for node in ast.walk(ast.parse(plik.read_text(encoding="utf-8"))):
        nazwy: list[str] = []
        if isinstance(node, ast.Import):
            nazwy = [alias.name for alias in node.names]
        elif isinstance(node, ast.ImportFrom):
            nazwy = [node.module or ""]
        for nazwa in nazwy:
            root = nazwa.split(".")[0]
            if warstwa in CENTRUM and root in ZAKAZANE:
                naruszenia.append(nazwa)
            if warstwa in {"gui", "kanaly"} and root == "sqlite3":
                naruszenia.append(nazwa)
            # Bez dynamicznych importów, pluginów i wykonywania kodu na etapie 2.
            if root == "importlib" and nazwa != "importlib.metadata":
                naruszenia.append(nazwa)
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id in {"__import__", "eval", "exec"}
        ):
            naruszenia.append(node.func.id)
    return naruszenia


def test_brak_frameworkow_w_centrum_i_dynamicznych_obejsc() -> None:
    bledy = {
        str(plik.relative_to(SRC)): naruszenia_zewnetrzne(plik, plik.relative_to(SRC).parts[0])
        for plik in SRC.rglob("*.py")
    }
    assert not {plik: wynik for plik, wynik in bledy.items() if wynik}


@pytest.mark.parametrize(
    ("warstwa", "kod"),
    [
        ("domena", "import sqlite3"),
        ("rdzen", "from PySide6 import QtCore"),
        ("przypadki_uzycia", "import httpx"),
        ("gui", "import sqlite3"),
        ("kanaly", "import sqlite3"),
        ("domena", "import importlib"),
        ("gui", "__import__('sqlite3')"),
    ],
)
def test_kontrola_wykrywa_zewnetrzne_naruszenie(tmp_path: Path, warstwa: str, kod: str) -> None:
    plik = tmp_path / "naruszenie.py"
    plik.write_text(kod, encoding="utf-8")
    assert naruszenia_zewnetrzne(plik, warstwa)


@pytest.mark.parametrize(
    ("warstwa", "cel"),
    [
        ("rdzen", "domena"),
        ("domena", "adaptery.srodowisko"),
        ("przypadki_uzycia", "gui"),
        ("adaptery", "kanaly"),
        ("kanaly", "adaptery"),
        ("gui", "domena"),
        ("gui", "adaptery"),
        ("domena", "bootstrap"),
        ("gui", "kanaly"),
    ],
)
def test_import_linter_odrzuca_zabroniona_krawedz(tmp_path: Path, warstwa: str, cel: str) -> None:
    """Mutacja wyłącznie kopii w tmp; pliki projektu pozostają nietknięte."""
    shutil.copytree(ROOT / "src", tmp_path / "src", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(ROOT / ".importlinter", tmp_path / ".importlinter")
    plik = tmp_path / "src" / "vexlab" / warstwa / "naruszenie.py"
    plik.write_text(f"import vexlab.{cel}\n", encoding="utf-8")
    exe = Path(sys.executable).parent / ("lint-imports.exe" if os.name == "nt" else "lint-imports")
    wynik = subprocess.run(
        [str(exe), "--no-cache"],
        cwd=tmp_path,
        env={**os.environ, "PYTHONPATH": str(tmp_path / "src")},
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert wynik.returncode == 1, wynik.stdout + wynik.stderr
    assert "BROKEN" in wynik.stdout, wynik.stdout + wynik.stderr
    assert f"Granice warstwy {warstwa}" in wynik.stdout


def test_gui_moze_korzystac_z_domeny_posrednio_przez_przypadek_uzycia(tmp_path: Path) -> None:
    shutil.copytree(ROOT / "src", tmp_path / "src", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(ROOT / ".importlinter", tmp_path / ".importlinter")
    pakiet = tmp_path / "src" / "vexlab"
    (pakiet / "przypadki_uzycia" / "proba.py").write_text("import vexlab.domena\n")
    (pakiet / "gui" / "proba.py").write_text("import vexlab.przypadki_uzycia.proba\n")
    exe = Path(sys.executable).parent / ("lint-imports.exe" if os.name == "nt" else "lint-imports")
    wynik = subprocess.run(
        [str(exe), "--no-cache"],
        cwd=tmp_path,
        env={**os.environ, "PYTHONPATH": str(tmp_path / "src")},
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert wynik.returncode == 0, wynik.stdout + wynik.stderr
