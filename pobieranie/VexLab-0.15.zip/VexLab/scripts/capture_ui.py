"""Zrzuty pustej instalacji z izolowaną testową tożsamością i bazą."""

import sys
from importlib.metadata import version
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QSettings, QTimer
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.paczki_zip import CzytnikZIP, ProfileJSON
from vexlab.adaptery.pamiec_profili import PamiecProfiliJSON
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.adaptery.zdjecia_lokalne import LokalneZdjecia
from vexlab.adaptery.zdjecia_shopify import TransportHTTPS, ZdjeciaShopify
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.galeria import GaleriaProduktow
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.media import PobierzZdjecia
from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


def main() -> int:
    app = QApplication(sys.argv)
    cel = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    cel.mkdir(exist_ok=True)
    zakonczono = False
    with TemporaryDirectory(prefix="vexlab-visual-") as katalog:
        tmp = Path(katalog)
        ustawienia = QSettings(str(tmp / "prefs.ini"), QSettings.Format.IniFormat)
        powloka = PowlokaAplikacji(
            PreferencjeQt(ustawienia), "uzytkownik_testowy", version("vexlab")
        )
        repo = KatalogSQLite(tmp / "katalog.sqlite3")
        okno = OknoVexLab(
            powloka,
            KatalogProduktow(repo, repo),
            RejestrProducentow(repo),
            EksportujKatalog(EksportCSV()),
            ImportujProdukty(CzytnikTabel(), ImportSQLite(repo.plik), repo),
            PobierzZdjecia(ZdjeciaShopify(TransportHTTPS())),
            GaleriaProduktow(repo, LokalneZdjecia()),
            PodgladPaczek(CzytnikZIP(), ProfileJSON(), PamiecProfiliJSON(tmp / "profile_paczek")),
            SzkiceOfert(SzkiceSQLite(repo.plik), KatalogProduktow(repo, repo)),
        )
        okno.show()

        def import_jasny() -> None:
            nonlocal zakonczono
            if okno._zadania:
                QTimer.singleShot(30, import_jasny)
                return
            if not okno.grab().save(str(cel / "vexlab-import-light.png")):
                app.exit(1)
                return
            zakonczono = True
            okno.close()
            app.quit()

        def import_ciemny() -> None:
            if okno._zadania:
                QTimer.singleShot(30, import_ciemny)
                return
            if not okno.grab().save(str(cel / "vexlab-import-dark.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.JASNY))
            QTimer.singleShot(60, import_jasny)

        def szkice_jasne() -> None:
            if okno._zadania:
                QTimer.singleShot(30, szkice_jasne)
                return
            if not okno.grab().save(str(cel / "vexlab-szkice-light.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.CIEMNY))
            okno.przejdz("Cenniki")
            QTimer.singleShot(60, import_ciemny)

        def szkice_ciemne() -> None:
            if okno._zadania:
                QTimer.singleShot(30, szkice_ciemne)
                return
            if not okno.grab().save(str(cel / "vexlab-szkice-dark.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.JASNY))
            QTimer.singleShot(60, szkice_jasne)

        def paczki_jasne() -> None:
            if not okno.grab().save(str(cel / "vexlab-paczki-light.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.CIEMNY))
            okno.przejdz("Szkice")
            QTimer.singleShot(60, szkice_ciemne)

        def paczki_ciemne() -> None:
            if not okno.grab().save(str(cel / "vexlab-paczki-dark.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.JASNY))
            QTimer.singleShot(60, paczki_jasne)

        def media_jasne() -> None:
            if not okno.grab().save(str(cel / "vexlab-media-light.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.CIEMNY))
            okno.przejdz("Nowe oferty")
            QTimer.singleShot(60, paczki_ciemne)

        def media_ciemne() -> None:
            if not okno.grab().save(str(cel / "vexlab-media-dark.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.JASNY))
            QTimer.singleShot(60, media_jasne)

        def masowa_jasna() -> None:
            if not okno.grab().save(str(cel / "vexlab-masowa-light.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.CIEMNY))
            okno.przejdz("Zdjęcia i media")
            QTimer.singleShot(60, media_ciemne)

        def masowa_ciemna() -> None:
            if not okno.grab().save(str(cel / "vexlab-masowa-dark.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.JASNY))
            QTimer.singleShot(60, masowa_jasna)

        def menu_produktow_jasne() -> None:
            if not okno.menu_produktow.grab().save(str(cel / "vexlab-produkty-akcje-light.png")):
                app.exit(1)
                return
            okno.menu_produktow.hide()
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.CIEMNY))
            okno.przejdz("Masowa edycja")
            QTimer.singleShot(60, masowa_ciemna)

        def produkty_jasne() -> None:
            if not okno.grab().save(str(cel / "vexlab-produkty-light.png")):
                app.exit(1)
                return
            okno.menu_produktow.popup(
                okno.wiecej_produktow.mapToGlobal(okno.wiecej_produktow.rect().bottomLeft())
            )
            QTimer.singleShot(100, menu_produktow_jasne)

        def menu_produktow_ciemne() -> None:
            if not okno.menu_produktow.grab().save(str(cel / "vexlab-produkty-akcje-dark.png")):
                app.exit(1)
                return
            okno.menu_produktow.hide()
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.JASNY))
            QTimer.singleShot(60, produkty_jasne)

        def produkty() -> None:
            if not okno.grab().save(str(cel / "vexlab-produkty-dark.png")):
                app.exit(1)
                return
            okno.menu_produktow.popup(
                okno.wiecej_produktow.mapToGlobal(okno.wiecej_produktow.rect().bottomLeft())
            )
            QTimer.singleShot(100, menu_produktow_ciemne)

        def producenci() -> None:
            if okno._zadania or not okno.strona_producentow._wczytano:
                QTimer.singleShot(30, producenci)
                return
            if not okno.grab().save(str(cel / "vexlab-producenci-dark.png")):
                app.exit(1)
                return
            okno.przejdz("Produkty")
            QTimer.singleShot(60, produkty)

        def jasny() -> None:
            if not okno.grab().save(str(cel / "vexlab-dashboard-light.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.CIEMNY))
            okno.przejdz("Producenci")
            QTimer.singleShot(60, producenci)

        def ciemny() -> None:
            if okno._zadania or not okno._katalog_wczytany:
                QTimer.singleShot(30, ciemny)
                return
            if not okno.grab().save(str(cel / "vexlab-dashboard-dark.png")):
                app.exit(1)
                return
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.JASNY))
            QTimer.singleShot(60, jasny)

        QTimer.singleShot(100, ciemny)

        def timeout() -> None:
            if okno._zadania:
                QTimer.singleShot(100, timeout)
                return
            okno.close()
            app.exit(1)

        QTimer.singleShot(60000, timeout)
        kod = app.exec()
    return kod if zakonczono else 1


if __name__ == "__main__":
    raise SystemExit(main())
