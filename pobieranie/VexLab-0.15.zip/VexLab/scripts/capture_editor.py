"""Izolowany zrzut edytora; syntetyczna treść nigdy nie zasila aplikacji użytkownika."""

from collections.abc import Callable
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.szkice import StronaSzkicow
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


def main() -> int:
    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    cel.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix="vexlab-editor-") as folder:
        repo = SzkiceSQLite(Path(folder) / "test.sqlite3")
        serwis = SzkiceOfert(repo, KatalogProduktow(repo, repo))
        opis = "<h2>Przykładowy opis</h2><p>Edytuj <b>tekst</b> bez znajomości HTML.</p>"
        oferta = OfertaPodglad(
            1,
            "DEMO-EDITOR",
            "Przykładowa oferta — edycja wizualna",
            opis,
            "",
            "",
            "",
            ("https://example.test/zdjecie.png",),
            (
                (ElementPodgladu("tekst", opis),),
                (
                    ElementPodgladu("tekst", "<p>Druga sekcja — zmień kolejność.</p>"),
                    ElementPodgladu("obraz", adres="https://example.test/zdjecie.png"),
                ),
            ),
            (),
        )
        serwis.zapisz(serwis.zaplanuj((oferta,), "test-visual.zip"))

        def uruchom(
            funkcja: Callable[[], object],
            sukces: Callable[[object], None],
            blad: Callable[[str, str], None],
        ) -> None:
            sukces(funkcja())  # Wyłącznie izolowany generator zrzutów.

        parent = QWidget()
        strona = StronaSzkicow(serwis, uruchom, parent)
        strona.odswiez()
        strona.tabela.selectRow(0)
        strona.edytuj()
        dialog = strona.dialog
        assert dialog is not None
        zastosuj_motyw(app, Motyw.CIEMNY)
        sukces = []

        def jasny() -> None:
            sukces.append(dialog.grab().save(str(cel / "vexlab-edytor-opisu-light.png")))
            dialog.reject()
            app.quit()

        def ciemny() -> None:
            sukces.append(dialog.grab().save(str(cel / "vexlab-edytor-opisu-dark.png")))
            zastosuj_motyw(app, Motyw.JASNY)
            QTimer.singleShot(150, jasny)

        QTimer.singleShot(200, ciemny)
        app.exec()
        return 0 if sukces == [True, True] else 1


if __name__ == "__main__":
    raise SystemExit(main())
