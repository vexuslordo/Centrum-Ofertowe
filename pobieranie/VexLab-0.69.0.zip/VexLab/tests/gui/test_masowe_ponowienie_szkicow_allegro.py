import pytest
from PySide6.QtWidgets import QDialog

from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from tests.integration import test_masowe_ponowienie_szkicow_allegro as partie
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.ponowienie_szkicow_allegro import PodgladNowychProb
from vexlab.przypadki_uzycia.nowe_szkice_allegro import WynikTworzenia
from vexlab.przypadki_uzycia.ponowienie_szkicu_allegro import PrzygotujNoweProby
from vexlab.przypadki_uzycia.powloka import Motyw

blokada = partie.blokada
partia = partie.partia


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_podglad_wymaga_jawnej_zgody_na_cala_partie(qtbot, qapp, partia, motyw):
    service, api, repo, s, plany = partia
    api.czy_istnieje_oferta = lambda s, ident: ident == "1001"
    wynik = PrzygotujNoweProby(service).sprawdz(s, plany, lambda: False, lambda *a: None)
    zastosuj_motyw(qapp, motyw)
    d = PodgladNowychProb(None, wynik, s.konto.login)
    qtbot.addWidget(d)
    d.show()
    assert not d.zgoda.isChecked() and not d.zatwierdz.isEnabled()
    assert d.tabela.rowCount() == 3
    assert d.tabela.item(1, 1).text() == "Nie odblokujemy"
    assert "istnieje" in d.tabela.item(1, 2).text()
    d.zgoda.setChecked(True)
    assert d.zatwierdz.isEnabled()
    d.zgoda.setChecked(False)
    assert not d.zatwierdz.isEnabled()
    assert all(repo.odczytaj(service.klucz(s, p.oferta.sku)) for p in plany)


def test_jedna_zgoda_odblokowuje_wiele_bez_nowej_wysylki(qtbot, partia, monkeypatch):
    service, api, repo, s, plany = partia
    api.czy_istnieje_oferta = lambda s, ident: ident == "1001"
    oferty = tuple(p.oferta for p in plany)
    w, jobs = panel(qtbot, (service, api, repo, s, oferty[0], plany[0].ustawienia), oferty)
    w.przygotuj()
    wykonaj(jobs)
    w.wyniki = tuple(
        WynikTworzenia(p.oferta.sku, "Wymaga sprawdzenia", "Inna wersja", str(1000 + i))
        for i, p in enumerate(plany)
    )
    w.tabela.selectAll()
    zgody = []

    def akceptuj(d):
        assert isinstance(d, PodgladNowychProb)
        zgody.append(d.tabela.rowCount())
        d.zgoda.setChecked(True)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(PodgladNowychProb, "exec", akceptuj)
    w.sprawdz_blokade()
    wykonaj(jobs)
    assert zgody == [3]
    qtbot.waitUntil(lambda: w.trwa)
    wykonaj(jobs)
    wykonaj(jobs)
    assert [repo.odczytaj(service.klucz(s, o.sku)) is None for o in oferty] == [True, False, True]
    assert [w._mozna_wyslac(i) for i in range(3)] == [True, False, True]
    assert w.wyniki[1].ident == "1001" and "istnieje" in w.wyniki[1].komunikat
    assert "Odblokowano: 2" in w.podsumowanie.text()
    assert api.calls.count("POST") == 1


def test_szczegoly_przekazuja_wszystkie_zaznaczone_do_akcji(qtbot, partia, monkeypatch):
    from PySide6.QtWidgets import QPushButton

    service, api, repo, s, plany = partia
    oferty = tuple(p.oferta for p in plany)
    w, jobs = panel(qtbot, (service, api, repo, s, oferty[0], plany[0].ustawienia), oferty)
    w.przygotuj()
    wykonaj(jobs)
    w.wyniki = tuple(WynikTworzenia(o.sku, "Wymaga sprawdzenia", "Inna wersja") for o in oferty)
    zakresy = []
    monkeypatch.setattr(w, "sprawdz_blokade", lambda: zakresy.append(w.wybrane()))

    def kliknij(d):
        for b in d.findChildren(QPushButton):
            if b.text() == "Zaznacz widoczne":
                b.click()
        for b in d.findChildren(QPushButton):
            if b.text().startswith("Sprawdź blokadę"):
                b.click()
        return QDialog.DialogCode.Rejected

    monkeypatch.setattr(QDialog, "exec", kliknij)
    w.pokaz_szczegoly()
    qtbot.waitUntil(lambda: bool(zakresy))
    assert zakresy == [(0, 1, 2)]
