from dataclasses import replace

import pytest
from PySide6.QtWidgets import QDialog, QDialogButtonBox, QMessageBox

from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from tests.integration import test_przelicznik_cen_allegro as testy_przelicznika
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.przelicznik_cen_allegro import WyborPrzelicznika
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.przelicznik_cen_allegro import RegulaKursowa

kurs = testy_przelicznika.kurs


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_wybor_rynkow_pustka_blad_i_klawiatura(qtbot, qapp, nowe_szkice_fixture, motyw):
    s = nowe_szkice_fixture[3]
    zastosuj_motyw(qapp, motyw)
    jobs = []
    d = WyborPrzelicznika(
        None,
        s,
        197,
        None,
        lambda: (RegulaKursowa("exchange", "Kurs Allegro"),),
        lambda *a: jobs.append(a),
        lambda: True,
    )
    qtbot.addWidget(d)
    d.show()
    qtbot.waitUntil(lambda: bool(jobs))
    assert not d.buttons.button(QDialogButtonBox.StandardButton.Apply).isEnabled()
    fn, ok, error = jobs.pop()
    error("SIEC", "Brak połączenia")
    assert "Brak połączenia" in d.status.text()
    d.stosuj.setChecked(True)
    assert not d.buttons.button(QDialogButtonBox.StandardButton.Apply).isEnabled()
    d.odswiez.click()
    fn, ok, error = jobs.pop()
    ok(fn())
    d.zastosuj()
    assert d.result() != QDialog.DialogCode.Accepted and "co najmniej" in d.status.text()
    from PySide6.QtCore import Qt

    d.rynki["allegro-hu"].setFocus()
    qtbot.keyClick(d.rynki["allegro-hu"], Qt.Key.Key_Space)
    d.zastosuj()
    assert d.result() == QDialog.DialogCode.Accepted
    assert d.wynik.rynki == ("allegro-hu",) and d.wynik.konto == s.konto.id


def test_zamkniety_dialog_nie_przyjmuje_spoznionego_odczytu(qtbot, nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    jobs = []
    d = WyborPrzelicznika(None, s, 2, None, lambda: (), lambda *a: jobs.append(a), lambda: True)
    qtbot.addWidget(d)
    d.show()
    qtbot.waitUntil(lambda: bool(jobs))
    d.reject()
    jobs[0][1]((RegulaKursowa("course", "Kurs"),))
    assert d.regula.count() == 0 and d.wynik is None


def test_brak_reguly_i_jawne_wylaczenie_tylko_lokalnego_wyboru(qtbot, nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    jobs = []
    d = WyborPrzelicznika(None, s, 2, None, lambda: (), lambda *a: jobs.append(a), lambda: True)
    qtbot.addWidget(d)
    d.show()
    qtbot.waitUntil(lambda: bool(jobs))
    jobs[0][1](())
    d.stosuj.setChecked(True)
    assert not d.buttons.button(QDialogButtonBox.StandardButton.Apply).isEnabled()
    assert "Brak reguły" in d.status.text()
    d.stosuj.setChecked(False)
    d.zastosuj()
    assert d.result() == QDialog.DialogCode.Accepted and d.wynik is None


def test_przycisk_stosuje_do_wybranych_automatyczne_przypiecie_i_get_only(qtbot, kurs, monkeypatch):
    service, api, repo, s, o, u, state = kurs
    fixture = (service, api, repo, s, o, replace(u, przelicznik=None))
    w, jobs = panel(qtbot, fixture)
    w.tabela.selectRow(0)
    assert w.przelicznik_przycisk.parentWidget() is w.vat_przycisk.parentWidget()

    def wybor(d):
        assert isinstance(d, WyborPrzelicznika)
        d.wynik = u.przelicznik
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", wybor)
    w.ustaw_przelicznik()
    wykonaj(jobs)
    assert w.plany[0].ustawienia.przelicznik == u.przelicznik
    assert state["post"] == [] and "POST" not in api.calls
    w.wyslij(False)
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Utworzono szkic"
    assert len(state["post"]) == api.calls.count("POST") == 1
    w.wyslij(True)
    wykonaj(jobs)
    assert len(state["post"]) == api.calls.count("POST") == 1
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    w.dokoncz_przeliczniki()
    wykonaj(jobs)
    assert len(state["post"]) == api.calls.count("POST") == 1
