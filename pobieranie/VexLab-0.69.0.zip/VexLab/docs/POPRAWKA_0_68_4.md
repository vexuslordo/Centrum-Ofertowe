# VexLab 0.68.4 — zamówienia, Dashboard i czytelny interfejs

- Ikony odświeżenia i zamknięcia podglądu są wektorowe, 16×16 w przyciskach
  28×28, z polskimi podpowiedziami i kolorem dopasowanym do motywu.
- Kafelek Obrót w zamówieniach ma wybór rzeczywistej waluty. PLN/EUR/CZK/HUF
  pokazują osobne sumy zamówień w tej walucie; bez przeliczania kursów.
- Krótsze pole wyszukiwania i większe filtry. Przy węższym oknie układ przechodzi
  do kolejnych wierszy. Przyciski Szukaj i Filtry pozostają kompaktowe.
- Dashboard: ostatnie zamówienia z Allegro i PrestaShop, źródło, klient, kwota
  i status. Kafelki Zamówienia/Obrót/Błędy pokazują rzeczywisty stan odczytów.
  Wybrany okres działa na danych, a nie tylko na podpisie. Rok zleca 365 dni.
- Waluta obrotu Dashboardu wybierana w jego nagłówku. Marża pozostaje oznaczona
  jako brak danych kosztowych; nie jest wyliczana z samego obrotu.

## PrestaShop

W Ustawienia → Integracje → PrestaShop sprawdź połączenie, wybierz sklep i język.
Dla zamówień nadaj kluczowi GET orders i currencies; GET order_states udostępnia
nazwy statusów sklepu. Zamówienia pobierane w tle i odświeżane według zapamiętanego
interwału. Wyłączenie automatyki pozostawia ręczne Odśwież zamówienia na Dashboardzie.
Bez połączenia lub uprawnień źródło pozostaje jawnie bez odczytu, zamiast fikcyjnego 0.
Klient Presta jest pokazywany przez jego ID; nie ma importu osobnej bazy klientów.
Daty sklepu i lokalna strefa czasu programu muszą być zgodne.

Dane zamówień tylko w RAM, bez SQLite i migracji. Zmiana konta, klucza albo sklepu
czyści właściwy podgląd. Nieudany odczyt nie zastępuje poprzedniego raportu wynikiem
częściowym. Pełny zakres i źródła są wskazane w podpowiedziach kafelków.

Obrót: sumy wartości brutto przed kosztami/zwrotami, w wybranej walucie.
Allegro bez anulowanych; PrestaShop według ważności zamówienia w sklepie (valid=1).
Rekordy kanałów liczone osobno — nie łączymy domyślnie zamówień pomiędzy systemami.
Szczegóły: [ADR-096](adr/ADR-096-dashboard-zamowien-kanalow.md).
