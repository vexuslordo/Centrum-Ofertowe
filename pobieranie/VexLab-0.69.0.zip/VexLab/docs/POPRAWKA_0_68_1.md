# VexLab 0.68.1 — kompaktowe statusy zamówień

Na polecenie właściciela odznaki w kolumnie Status są mniejsze (22 px),
wyśrodkowane w obu osiach i używają stonowanej palety granatowego interfejsu.
Tekst 11 px, cienkie obramowanie i subtelnie zaokrąglone rogi. Długie etykiety
mieszczą się w kolumnie dzięki skróceniu z wielokropkiem; polski pełny status
pozostaje dostępny w szczegółach. Paleta osobna dla jasnego i ciemnego motywu,
wspólna z odznaką w panelu szczegółów. Bez zmian danych i działania Allegro.

Panel szczegółów uporządkowany według drugiej referencji właściciela: wyrównane
kolumny ikona / etykieta / wartość, kopiowanie numeru, kupującego, telefonu oraz
e-maila wyłącznie po kliknięciu. Prawdziwy kod PL daje flagę biało-czerwoną i
nazwę Polska; inne kraje nie otrzymują polskiej flagi. Braki pozostają oznaczone.
Polskie nazwy krajów to etykiety prezentacji kodów ISO, nie dane biznesowe.

Dane dostawy i punktu odbioru są osobnymi polami odczytu DTO, bez migracji bazy.
Panel rozwija je na żądanie. Dotychczasowa zbiorcza reprezentacja adresu jest
zachowana dla zgodności. Pozycje mają osobną listę z ilością i SKU; zdjęcia
pierwszych ośmiu różnych ofert odczytywane w tle, bez zapisu na dysku. Pozostałe
pozycje pozostają widoczne także bez miniatury. Zdjęcia odpowiadają aktualnym
ofertom; nie tworzymy fikcyjnych fotografii dla brakujących źródeł.
Wybranie innego zamówienia, filtra lub zamknięcie panelu unieważnia starsze
odpowiedzi zdjęć. Dane pól, adresy i lista pozycji są czyszczone po zmianie konta.


Uzupełnienie: flagi PL/CZ/HU/SK dostępne offline jako SVG z Flagcdn. Pola kraju
nadal pochodzą z Allegro. Sposób zapłaty pokazuje typ oraz operatora payment.provider
(np. PayU, Przelewy24) otrzymanego z odpowiedzi. Nie wnioskujemy o BLIK/kartach
z samego operatora; odczyt zamówienia nie udostępnia takiego szczegółu.

Automatyczny odczyt co 10 minut podczas działania programu, także poza zakładką
zamówień. Zegar startuje przy dostępnym, niewygasłym połączeniu z uprawnieniem
odczytu zamówień, a ponownie po zakończeniu odczytu. Ręczne Odśwież nadal działa.
Zajęte zadanie odracza automatyczny odczyt, bez równoległych serii. Zmiana konta
resetuje zegar i dane. Bez sesji, uprawnienia lub po wygaśnięciu nie wysyłamy
żądań. To odczyt listy, nie zmiana realizacji lub płatności.

Odświeżenie pozostawia dotychczasowy pełny wynik podczas pracy w tle. Po sukcesie
zachowuje bieżące filtry, stronę i zaznaczone ID nadal obecne w wyniku. Nieobecne
zaznaczenia są usuwane. Błąd/przerwanie pozostawia ostatni pełny raport z jego
czasem odczytu i pokazuje komunikat. Dane częściowego pobrania nie zastępują listy.
