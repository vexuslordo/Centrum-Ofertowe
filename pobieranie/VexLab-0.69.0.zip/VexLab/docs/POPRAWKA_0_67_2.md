# VexLab 0.67.2 — zamówienia wewnątrz Allegro

W lewym menu wybierz Sprzedaż → Allegro. U góry są dwie zakładki:
Oferty oraz Zamówienia. Osobna pozycja Zamówienia z lewego menu została usunięta.
Kafel Zamówienia na Dashboard otwiera bezpośrednio podmenu Zamówienia w Allegro.
Przełączanie zachowuje pobrane dane i filtry, nie uruchamia dodatkowych żądań.
Zmiana konta nadal czyści dane zamówień i blokuje spóźnione wyniki.

Zapis i odczyt danych, uprawnienia oraz funkcje ofert pozostają bez zmian.
Do zamówień nadal potrzebne allegro:api:orders:read i ponowna zgoda po włączeniu.
Paczka bez archiwalnych zrzutów, obraz referencyjny oraz logo zachowane.
