# VexLab 0.68.5 — czytelność Zamówień według referencji VexLab

Wyłącznie warstwa prezentacji. Układ aplikacji, kolumny i ich model, połączenia,
filtry, sortowanie dostępne w widoku, zaznaczanie, paginacja, eksport, odświeżanie,
uprawnienia oraz reguły statusów/kwot pozostają dotychczasowe.

Tabela:

- Wiersze 76 px. Produkt wyróżniony w pierwszej linii, SKU poniżej w stonowanym
  podpisie. Pełna treść pozostaje dostępna w podpowiedzi i szczegółach.
- Miniatury 56×56 z promieniem 8 px; wciąż ładowane przez istniejący cache
  tylko dla widocznych pozycji. Nie tworzymy widżetu dla każdego wiersza.
- Kupujący z inicjałami, flagą i nazwą kraju; dostawa nadal w swojej kolumnie,
  tak jak na przesłanym screenie. Nie usuwamy informacji ani kolumn modelu.
- Status jako wyśrodkowana odznaka z punktem i mocniejszą hierarchią tekstu.
  Dotychczasowe kolory i źródłowe etykiety, bez tworzenia fikcyjnego stanu Problem.

Panel po prawej zachowuje swoją szerokość, obszar przewijania i istniejące
sterowanie. Główne zdjęcie 190 px, wyraźna nazwa i SKU. Kwota, Status, Płatność
oraz Dostawa tworzą cztery kompaktowe karty. Dalej są klient, szczegóły dostawy,
adresy i produkty. Operator płatności jest razem z potwierdzeniem opłacenia.
Sekcja Akcje pozostaje na dole, zawsze dostępna. Dodano ikony oraz pełną szerokość
głównego i zewnętrznego przycisku. Nieaktywne funkcje pozostają nieaktywne.

Dane w kartach są tymi samymi kontrolkami powiązanymi z dotychczasowym modelem
odczytu; bez dodatkowych obliczeń, nowych DTO lub kopii danych klienta.
Paleta i rodzina czcionek VexLab nie zostały zastąpione; wykorzystano istniejące
role kolorów i typografii. Flaga DE jest zasobem UI, a kraj nadal pochodzi z API.
Obrazu referencyjnego i logo nie zmieniono. Bez zmian bazy lub migracji.
