# VexLab 0.68.3 — ustawienia odświeżania i dane płatności

Ustawienia → Ogólne → Zamówienia Allegro: Wyłączone (ręczne), 1, 5, 10, 15,
30 lub 60 minut. Domyślnie 10 minut dla istniejących i nowych instalacji.
Wybór zapisywany jako preferencja użytkownika przez port magazynu i QSettings,
bez SQLite i rekordów biznesowych. Jest zachowany po restarcie oraz zmianie
innych ustawień. Błędny zapis wraca do 10 minut.

Zmiana działa od razu. Wyłączenie zatrzymuje zegar, a Odśwież nadal działa.
Trwający odczyt może się zakończyć; kolejny okres zaczyna się po jego końcu.
Brak równoległych serii, odczyt w tle zachowuje filtry i zaznaczenie. Bez konta,
uprawnienia lub po wygaśnięciu sesji automatyczny odczyt nie działa.

Sposób zapłaty pokazuje typ i rzeczywistą nazwę operatora z Allegro. Znane
nazwy PayU, Przelewy24 i Allegro mają czytelne etykiety; pozostałe nazwy
nie są ukrywane pod komunikatem Nieznany operator. Nie wnioskujemy o BLIK,
karcie ani banku z samego operatora. Płatność Opłacone pozostaje osobnym stanem.

Przycisk Wiadomość zastępuje Napisz klientowi i nie otwiera błędnego linku.
Jest nieaktywny do wdrożenia bezpośrednich wiadomości w programie.
Reguły Do wysyłki po Subiekcie oraz Wysłane po skanie kuriera zapisano w
[ADR-095](adr/ADR-095-realizacja-subiekt-i-skan-kuriera.md) jako przyszły etap;
obecna paczka nie uruchamia tej automatyzacji.


Otwórz w Allegro: poprawiona domena z nieistniejącej salescenter.allegro.pl
na oficjalne https://salescenter.allegro.com/orders. Link listy sprawdzono —
bez zalogowania kieruje do logowania Allegro z zachowaniem adresu docelowego.
Nie dopisujemy niepotwierdzonej ścieżki UUID. Numer zamówienia można skopiować
przy ID w panelu. Przycisk Wiadomość jest od tego linku niezależny i nieaktywny.
