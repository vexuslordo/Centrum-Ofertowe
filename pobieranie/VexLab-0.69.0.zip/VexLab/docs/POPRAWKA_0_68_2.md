# VexLab 0.68.2 — czytelne karty adresów

Sekcja adresów w panelu zamówienia ma neutralny przełącznik Pokaż/Ukryj adresy,
zamiast niebieskiego aktywnego przycisku. Dwie odrębne karty: Adres dostawy
oraz Punkt odbioru. Każda ma ikonę, delikatne obramowanie, wyraźną nazwę
odbiorcy/punktu, spokojniejszy tekst lokalizacji i kraj z flagą PL/CZ/HU/SK.
Punkt bez danych nie zajmuje pustej karty. Motyw ciemny i jasny zgodny z programem.

Kopiowanie z karty zachowuje pełny otrzymany adres, także kod kraju i ID punktu.
Nie zmieniamy pisowni, numerów domu ani kodów pocztowych. Czyszczenie panelu
usuwa tekst i wyłącza kopiowanie. Dane klientów i adresów nie trafiają do bazy,
logów ani danych startowych. Bez zmian API i bez migracji.


Naprawa widoku Karty: delegat podaje pełny rozmiar elementu zgodny z siatką.
Wcześniej Qt przydzielał wysokość pojedynczej linii mimo większej komórki siatki,
co ucinało tekst i tło. Kafelek ma teraz zdjęcie, dwuliniową nazwę, SKU,
kupującego, kwotę i kompaktową odznakę statusu. Całe malowanie jest ograniczone
do granic kafelka. Pełne dane są w podpowiedzi i panelu po wybraniu karty.
Miniatury wyznaczane przez przecięcie widocznych prostokątów kart z viewportem,
a nie zgadywanie numeru pierwszego rzędu po przewinięciu.
