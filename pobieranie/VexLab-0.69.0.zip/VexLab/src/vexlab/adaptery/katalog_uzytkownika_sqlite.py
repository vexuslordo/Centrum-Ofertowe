"""Atomowy zapis lokalnych Produktów z paczek, w istniejącej bazie użytkownika."""

from datetime import UTC, datetime
from uuid import UUID, uuid4

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.domena.producent import Producent
from vexlab.domena.produkt import Produkt
from vexlab.przypadki_uzycia.importowanie import CenaImportu
from vexlab.przypadki_uzycia.katalog import DaneDopasowania, _dopasowania
from vexlab.przypadki_uzycia.katalog_uzytkownika import ProduktUzytkownika, WynikKatalogu, blad
from vexlab.przypadki_uzycia.media import ZdjecieDane


class KatalogUzytkownikaSQLite(KatalogSQLite):
    def wersja_produktu(self, ident: UUID) -> int | None:
        with self._polaczenie() as c:
            row = c.execute("SELECT wersja FROM produkty WHERE id=?", (str(ident),)).fetchone()
            return row[0] if row else None

    def producenci_uzytkownika(self) -> tuple[str, ...]:
        with self._polaczenie() as c:
            return tuple(
                r[0]
                for r in c.execute(
                    "SELECT nazwa FROM producenci WHERE aktywny=1 ORDER BY nazwa COLLATE NOCASE"
                )
            )

    def zapisz_uzytkownika(self, produkty: tuple[ProduktUzytkownika, ...]) -> WynikKatalogu:
        with self._polaczenie() as c:
            c.execute("BEGIN IMMEDIATE")
            kopia = self._kopia_spojna("kopie_katalogu_uzytkownika")
            dodane = istniejace = 0
            for p in produkty:
                p.sprawdz()
                old = c.execute(
                    "SELECT * FROM produkty WHERE sku_klucz=?", (p.sku.casefold(),)
                ).fetchone()
                if old and old["ean"] and p.ean and old["ean"] != p.ean:
                    raise blad(f"SKU {p.sku}: inny EAN w lokalnym katalogu. Nie nadpisano danych.")
                producer = old["producent_id"] if old else None
                if producer is None and p.producent.strip():
                    matches = [
                        r
                        for r in c.execute("SELECT * FROM producenci")
                        if r["nazwa"].strip().casefold() == p.producent.strip().casefold()
                    ]
                    if len(matches) > 1 or (matches and not matches[0]["aktywny"]):
                        raise blad("Producent jest niejednoznaczny lub nieaktywny. Popraw rejestr.")
                    if matches:
                        producer = matches[0]["id"]
                    else:
                        pr = Producent(uuid4(), p.producent.strip(), strona_www=p.producent_www)
                        producer = str(pr.id)
                        c.execute(
                            "INSERT INTO producenci(id,nazwa,aktywny,wersja,strona_www) "
                            "VALUES (?,?,1,1,?)",
                            (producer, pr.nazwa, pr.strona_www),
                        )
                pid = old["id"] if old else str(uuid4())
                if old is None:
                    product = Produkt(
                        UUID(pid),
                        p.nazwa,
                        p.sku,
                        p.opis,
                        producent_id=UUID(producer) if producer else None,
                        ean=p.ean,
                        dopasowania=_dopasowania(p.dopasowania),
                    )
                    c.execute(
                        "INSERT INTO produkty(id,nazwa,sku,sku_klucz,opis,wersja,producent_id,ean) "
                        "VALUES (?,?,?,?,?,1,?,?)",
                        (pid, p.nazwa, p.sku, p.sku.casefold(), p.opis, producer, p.ean),
                    )
                    self._zapisz_dopasowania(c, product)
                    c.execute("INSERT INTO dostepnosc_produktow VALUES (?,?)", (pid, p.dostepnosc))
                    dodane += 1
                else:
                    istniejace += 1
                changed = False
                if old and (
                    (not old["opis"] and p.opis)
                    or (not old["ean"] and p.ean)
                    or old["producent_id"] != producer
                ):
                    c.execute(
                        "UPDATE produkty SET opis=?,ean=?,producent_id=? WHERE id=?",
                        (old["opis"] or p.opis, old["ean"] or p.ean, producer, pid),
                    )
                    changed = True
                if (
                    p.cena
                    and not c.execute(
                        "SELECT 1 FROM ceny_sugerowane WHERE produkt_id=?", (pid,)
                    ).fetchone()
                ):
                    price = p.cena.sprawdz()
                    if price:
                        c.execute(
                            "INSERT INTO ceny_sugerowane VALUES (?,?,?,?,?)",
                            (
                                pid,
                                format(price.kwota, "f"),
                                price.waluta,
                                price.rodzaj,
                                "Paczka / import danych użytkownika",
                            ),
                        )
                        changed = True
                if (
                    p.zdjecia
                    and not c.execute("SELECT 1 FROM zdjecia WHERE produkt_id=?", (pid,)).fetchone()
                ):
                    self._zdjecia(c, UUID(pid), p.zdjecia)
                    changed = True
                if old and changed:
                    c.execute("UPDATE produkty SET wersja=wersja+1 WHERE id=?", (pid,))
        return WynikKatalogu(dodane, istniejace, kopia)

    def odczytaj_uzytkownika(self, ids: tuple[UUID, ...]) -> tuple[ProduktUzytkownika, ...]:
        result = []
        size = 0
        with self._polaczenie() as c:
            c.execute("BEGIN")
            fits = self._odczytaj_dopasowania(c)
            for ident in ids:
                pid = str(ident)
                p = c.execute(
                    "SELECT p.*,pr.nazwa AS producent,pr.strona_www AS www "
                    "FROM produkty p LEFT JOIN producenci pr ON pr.id=p.producent_id "
                    "WHERE p.id=?",
                    (pid,),
                ).fetchone()
                if p is None:
                    raise blad("Produkt usunięto przed eksportem. Odśwież katalog.")
                price = c.execute(
                    "SELECT * FROM ceny_sugerowane WHERE produkt_id=?", (pid,)
                ).fetchone()
                images = tuple(
                    ZdjecieDane(r["zrodlo"], bytes(r["dane"]), bytes(r["miniatura"]))
                    for r in c.execute(
                        "SELECT * FROM zdjecia WHERE produkt_id=? ORDER BY kolejnosc", (pid,)
                    )
                )
                size += sum(len(z.dane) + len(z.miniatura) for z in images)
                if size > 128 * 1024 * 1024:
                    raise blad("Eksport przekracza 128 MiB zdjęć. Wybierz mniejszą partię.")
                availability = c.execute(
                    "SELECT stan FROM dostepnosc_produktow WHERE produkt_id=?", (pid,)
                ).fetchone()
                result.append(
                    ProduktUzytkownika(
                        p["nazwa"],
                        p["sku"],
                        p["opis"],
                        p["ean"],
                        p["producent"] or "",
                        p["www"] or "",
                        CenaImportu(price["kwota"], price["waluta"], price["rodzaj"])
                        if price
                        else None,
                        images,
                        tuple(
                            DaneDopasowania(
                                d.marka,
                                d.model,
                                str(d.rok_od or ""),
                                str(d.rok_do or ""),
                                d.wariant,
                            )
                            for d in fits.get(pid, ())
                        ),
                        availability[0] if availability else "nieustalona",
                    )
                )
        return tuple(result)

    def powiaz_uzytkownika(self, sku: str, konto: str, env: str, ident: str) -> None:
        if (
            env not in {"Allegro", "Allegro Sandbox"}
            or not konto
            or not ident.isascii()
            or not ident.isdigit()
        ):
            raise blad("Nieprawidłowe powiązanie oferty Allegro.")
        with self._polaczenie() as c:
            c.execute("BEGIN IMMEDIATE")
            p = c.execute(
                "SELECT * FROM produkty WHERE sku_klucz=?", (sku.strip().casefold(),)
            ).fetchone()
            if not p:
                raise blad("Brak produktu lokalnego do powiązania.")
            old = c.execute(
                "SELECT produkt_id FROM oferty_produktow_allegro "
                "WHERE srodowisko=? AND konto=? AND oferta_id=?",
                (env, konto, ident),
            ).fetchone()
            if old and old[0] != p["id"]:
                raise blad("Oferta ma inne powiązanie. Nie zastąpiono go.")
            c.execute(
                "INSERT INTO oferty_produktow_allegro(srodowisko,konto,oferta_id,produkt_id,"
                "status,tytul,sku,producent,ean,odczytano) "
                "VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(srodowisko,konto,oferta_id) DO NOTHING",
                (
                    env,
                    konto,
                    ident,
                    p["id"],
                    "INACTIVE",
                    p["nazwa"],
                    p["sku"],
                    "",
                    p["ean"],
                    datetime.now(UTC).isoformat(),
                ),
            )
