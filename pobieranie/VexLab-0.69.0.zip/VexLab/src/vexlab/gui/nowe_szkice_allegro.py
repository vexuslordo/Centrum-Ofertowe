"""Przegląd planu ZIP → INACTIVE, jawne dane konta, raport i anulowanie serii."""

import csv
import re
from collections import Counter
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from threading import Event
from typing import cast

from PySide6.QtCore import QEvent, QItemSelectionModel, QObject, Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.kafelek_kpi import PanelDashboardu
from vexlab.gui.masowa_paczka_allegro import MasowaPaczkaAllegro
from vexlab.gui.podglad_oferty import ObrazyOferty
from vexlab.gui.ponowienie_szkicow_allegro import PodgladNowychProb
from vexlab.gui.producenci import Uruchom
from vexlab.gui.przelicznik_cen_allegro import WyborPrzelicznika
from vexlab.gui.szablony_ofert import WyborSzablonu
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.gui.ustawienia_sprzedazy_allegro import DaneSprzedazyAllegro
from vexlab.gui.vat_allegro import VATAllegro
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.duplikaty_allegro import (
    IstniejacaOferta,
    SprawdzDuplikatyAllegro,
    opis_duplikatow,
)
from vexlab.przypadki_uzycia.edycja_paczki_allegro import zmien_parametry
from vexlab.przypadki_uzycia.katalog_uzytkownika import KatalogUzytkownika
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    USTAWIENIA_DO_SPRAWDZENIA,
    KategoriaSzkicu,
    NoweSzkiceAllegro,
    PlanNowegoSzkicu,
    ProduktSzkicu,
    UstawieniaSzkicu,
    WynikTworzenia,
    domyslne_zrodlo,
    mozna_poprawic_przed_utworzeniem,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.ponowienie_szkicu_allegro import (
    KontrolaPonowienia,
    PartiaKontroliPonowien,
    PrzygotujNowaProbe,
    PrzygotujNoweProby,
    WynikPonowienia,
)
from vexlab.przypadki_uzycia.sygnatury_allegro import APISygnatur, napraw_sygnature
from vexlab.przypadki_uzycia.szablony_ofert import SzablonyOfert
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import SlownikiSprzedazy
from vexlab.rdzen.kontrakty import BladTechniczny


def zapisz_raport(
    plik: Path, wyniki: tuple[WynikTworzenia, ...], konto: str = "", srodowisko: str = ""
) -> None:
    def pole(v: str) -> str:
        return (
            "'" + v
            if v.lstrip().startswith(("=", "+", "-", "@")) or v.startswith(("\t", "\r", "\n"))
            else v
        )

    with plik.open("x", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(("Konto", "Środowisko", "SKU", "Wynik", "ID Allegro", "Informacja"))
        for w in wyniki:
            writer.writerow(
                tuple(pole(v) for v in (konto, srodowisko, w.sku, w.stan, w.ident, w.komunikat))
            )


def podsumuj_wysylke(wyniki: tuple[WynikTworzenia, ...]) -> str:
    potwierdzone = {
        "Utworzono szkic",
        "Szkic kompletny",
        "Szkic do poprawy",
        USTAWIENIA_DO_SPRAWDZENIA,
    }
    niewyslane = {"Nie wysłano", "Nie sprawdzono", "Do poprawy", "Wstrzymano", "Anulowano"}
    zapisane = sum(w.stan in potwierdzone and bool(w.ident) for w in wyniki)
    pominiete = sum(w.stan == "Już na Allegro" for w in wyniki)
    odrzucone = sum(w.stan == "Odrzucono" for w in wyniki)
    bez_proby = sum(w.stan in niewyslane for w in wyniki)
    nieznane = len(wyniki) - zapisane - pominiete - odrzucone - bez_proby
    ustawienia = sum(w.stan == USTAWIENIA_DO_SPRAWDZENIA and bool(w.ident) for w in wyniki)
    return (
        f"Gotowe: {zapisane} · Do sprawdzenia: {nieznane} · "
        f"Błędy: {odrzucone} · Niewysłane: {bez_proby} · Pominięte: {pominiete}"
        + (f" · Ustawienia do sprawdzenia: {ustawienia}" if ustawienia else "")
    )


def wskazowka_wyniku(stan: str, komunikat: str = "") -> str:
    if "inną wersję danych" in komunikat:
        return "Wybierz Sprawdź blokadę i ponów. Najpierw sprawdzimy poprzednie ID i konto Allegro."
    if stan == USTAWIENIA_DO_SPRAWDZENIA:
        return (
            "Oferta jest już utworzona. Sprawdź wskazane ustawienia w Allegro "
            "lub kliknij „Sprawdź wyniki wysyłki”. Nie twórz jej ponownie."
        )
    if stan in {"Wynik nieznany", "Wymaga sprawdzenia", "Przetwarzanie"}:
        return "Kliknij „Sprawdź wyniki wysyłki”. Nie twórz tej oferty ponownie."
    if stan == "Odrzucono" and "HTTP 429" in komunikat:
        return "Allegro ograniczyło liczbę żądań. Odczekaj przed kolejną wysyłką."
    if stan == "Odrzucono" and any(k in komunikat for k in ("HTTP 401", "HTTP 403")):
        return "Sprawdź połączenie i uprawnienia konta w Ustawienia → Integracje → Allegro."
    if stan == "Odrzucono" and "numer katalogowy" in komunikat.casefold():
        match = re.search(
            r"change the value to ['\"`]([^'\"`]{1,256})['\"`]", komunikat, re.IGNORECASE
        )
        wartosc = (" Wartość wskazana przez Allegro: " + match[1] + ".") if match else ""
        return (
            "Kliknij „Popraw wybrane…”. W parametrze Numer katalogowy części "
            "wybierz źródło ręczne i wpisz wartość wymaganą przez Allegro. "
            "SKU pozostaje osobnym kodem Twojej oferty." + wartosc
        )
    if stan in {"Do poprawy", "Odrzucono"}:
        return "Kliknij „Popraw wybrane…”, uzupełnij wskazane pola i kliknij „Sprawdź paczkę”."
    if stan == "Szkic do poprawy":
        return "Szkic jest już w Allegro. Uzupełnij wskazane dane w Allegro; nie twórz go ponownie."
    if stan == "Wstrzymano":
        return "Sprawdź przyczynę zatrzymania i wynik poprzedniej oferty przed wznowieniem."
    if stan in {"Nie wysłano", "Nie sprawdzono", "Anulowano"}:
        return (
            "Kliknij „Sprawdź paczkę”, popraw ewentualne braki "
            "i wybierz „Utwórz zaznaczone szkice”."
        )
    return ""


class DialogNowychSzkicow(QDialog):
    postep = Signal(int, str)
    katalog_zmieniony = Signal()
    lokalny_status = Signal(str)
    praca_zmieniona = Signal(bool, str)
    w_tle_zadane = Signal()

    def __init__(
        self,
        parent: QWidget,
        serwis: NoweSzkiceAllegro,
        sesja: SesjaAllegro,
        oferty: tuple[OfertaPodglad, ...],
        uruchom: Uruchom,
        zdjecia: PodgladZdjec | None = None,
        duplikaty: SprawdzDuplikatyAllegro | None = None,
        szablony_ofert: SzablonyOfert | None = None,
        katalog_uzytkownika: KatalogUzytkownika | None = None,
    ) -> None:
        super().__init__(parent)
        self.serwis, self.sesja, self.oferty, self.uruchom = serwis, sesja, oferty, uruchom
        self.plany: tuple[PlanNowegoSzkicu, ...] = ()
        self.wyniki: tuple[WynikTworzenia, ...] = ()
        self._ostatnie_plany: tuple[PlanNowegoSzkicu, ...] = ()
        self._zmienione: set[int] = set()
        self._odrzucenia: dict[int, WynikTworzenia] = {}
        self._poprawiane: tuple[int, ...] = ()
        self.ilosci: dict[int, int] = {}
        self.ustawienia: dict[int, UstawieniaSzkicu] = {}
        self.trwa = self.nieaktualny = False
        self._lokalny_zamkniety = False
        self.finished.connect(lambda _: setattr(self, "_lokalny_zamkniety", True))
        self.katalog_uzytkownika = katalog_uzytkownika
        self.szablony_ofert = szablony_ofert
        self.kontrola_duplikatow = duplikaty
        self.duplikaty: dict[int, tuple[IstniejacaOferta, ...]] = {}
        self.stop = Event()
        self.obrazy = ObrazyOferty(self, zdjecia, uruchom, miniatury=True)
        self._miniatury: dict[int, str] = {}
        self.timer_miniatur = QTimer(self)
        self.timer_miniatur.setSingleShot(True)
        self.timer_miniatur.timeout.connect(self._miniatury_widoczne)
        self.finished.connect(lambda _: self.obrazy.zamknij())
        self.finished.connect(lambda _: self.timer_miniatur.stop())
        self.setWindowFlag(Qt.WindowType.WindowContextHelpButtonHint, False)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.setWindowTitle("Przygotuj szkice Allegro")
        self.resize(1280, 760)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(8)
        tytul = etykieta("Przygotuj oferty Allegro")
        tytul.setObjectName("tytulStronyAllegro")
        layout.addWidget(tytul)
        konto = etykieta(
            f"Konto: {sesja.konto.login} • {sesja.srodowisko.value} • {len(oferty)} pozycji"
        )
        konto.setObjectName("opis")
        layout.addWidget(konto)
        self.kompletny = QCheckBox("Przygotuj komplet danych do publikacji")
        self.kompletny.setChecked(True)
        self.kompletny.setToolTip(
            "Wymaga GPSR, dostawy i warunków. Publikacja sprzedaży nadal osobno."
        )
        self.formularz = QWidget()
        form = QHBoxLayout(self.formularz)
        form.setContentsMargins(0, 0, 0, 0)
        form.setSpacing(12)
        self.waluta = QComboBox()
        self.waluta.setAccessibleName("Waluta cen brutto z paczki")
        self.waluta.addItem("Wybierz walutę cen brutto", "")
        for waluta in ("PLN", "EUR", "CZK", "HUF"):
            self.waluta.addItem(waluta, waluta)
        self.ilosc = QSpinBox()
        self.ilosc.setAccessibleName("Ilość w każdym nowym szkicu")
        self.ilosc.setRange(0, 10000000)
        self.ilosc.setValue(1)
        self.waluta.setMinimumWidth(100)
        self.ilosc.setMaximumWidth(110)
        self.ilosc.setToolTip("Wspólna ilość. Wyjątki możesz ustawić w tabeli lub edycji masowej.")
        form.addWidget(etykieta("Waluta cen brutto"))
        form.addWidget(self.waluta, 1)
        form.addWidget(etykieta("Domyślna ilość"))
        form.addWidget(self.ilosc)
        self.sprawdz_przycisk = QPushButton("Sprawdź paczkę")
        self.produkt_przycisk = QPushButton("Wybierz produkt Allegro…")
        self.nowy_przycisk = QPushButton("Nowy produkt w Allegro…")
        self.nowy_przycisk.setToolTip(
            "Produkt nie istnieje w katalogu? Wybierz kategorię i przygotuj jego zgłoszenie."
        )
        self.uzupelnij_przycisk = QPushButton("Dane wybranej oferty…")
        self.utworz_przycisk = QPushButton("Utwórz szkice w Allegro…")
        self.utworz_przycisk.setObjectName("primary")
        self.wynik_przycisk = QPushButton("Sprawdź wyniki wysyłki")
        self.eksport = QPushButton("Eksportuj raport…")
        self.sygnatury = QPushButton("Popraw stare sygnatury…")
        self.sygnatury.setToolTip(
            "Dla szkiców utworzonych wcześniej z tej paczki: zamień vexlab-… na SKU."
        )
        self.anuluj = QPushButton("Zatrzymaj serię")
        self.anuluj.clicked.connect(self.stop.set)
        self.przyciski: tuple[QPushButton, ...] = (
            self.sprawdz_przycisk,
            self.produkt_przycisk,
            self.uzupelnij_przycisk,
            self.utworz_przycisk,
            self.wynik_przycisk,
            self.eksport,
        )
        self.parametry_masowe = QPushButton("Parametry produktów…")
        self.sprzedaz_przycisk = QPushButton("GPSR, dostawa i warunki…")
        self.vat_przycisk = QPushButton("VAT według krajów…")
        self.przelicznik_przycisk = QPushButton("Przelicznik cen…")
        menu_cen = QMenu(self.przelicznik_przycisk)
        menu_cen.addAction("Ustaw dla nowych szkiców…", self.ustaw_przelicznik)
        menu_cen.addAction("Dokończ przypinanie do utworzonych…", self.dokoncz_przeliczniki)
        self.przelicznik_przycisk.setMenu(menu_cen)
        self.przyciski += (
            self.nowy_przycisk,
            self.sprzedaz_przycisk,
            self.vat_przycisk,
            self.przelicznik_przycisk,
        )
        przygotowanie = QHBoxLayout()
        przygotowanie.setSpacing(12)
        for naglowek, opis, widgets in (
            (
                "1. Dane produktów",
                "SKU, EAN i ceny pozostają osobne dla każdego produktu.",
                (self.formularz,),
            ),
            (
                "2. Ustawienia Allegro",
                "Ustaw dla zaznaczonych produktów lub wszystkich widocznych.",
                (self.kompletny,),
            ),
        ):
            karta = PanelDashboardu("produkty" if widgets[0] is self.formularz else "aktywne")
            karta.setObjectName("karta")
            card = QVBoxLayout(karta)
            card.setContentsMargins(12, 10, 12, 10)
            card.setSpacing(6)
            card.setAlignment(Qt.AlignmentFlag.AlignTop)
            label = etykieta(naglowek)
            label.setObjectName("tytulSekcjiAllegro")
            card.addWidget(label)
            label.setToolTip(opis)
            buttons = QHBoxLayout()
            if widgets[0] is self.formularz:
                card.addWidget(self.formularz)
                self.producent_lokalny = QComboBox()
                self.producent_lokalny.setEditable(True)
                self.producent_lokalny.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
                self.producent_lokalny.setAccessibleName("Producent produktów lokalnych")
                cast(QLineEdit, self.producent_lokalny.lineEdit()).setPlaceholderText(
                    "Wybierz lub wpisz nowego producenta"
                )
                self.producent_lokalny.setVisible(katalog_uzytkownika is not None)
                if katalog_uzytkownika is not None:
                    producent_row = QHBoxLayout()
                    producent_row.addWidget(etykieta("Producent lokalny *"))
                    producent_row.addWidget(self.producent_lokalny, 1)
                    card.addLayout(producent_row)
                else:
                    card.addWidget(self.producent_lokalny)
                self.info_katalogu = etykieta("Zapis lokalny: zdjęcie, SKU, EAN i cena.")
                self.info_katalogu.setToolTip(
                    "Produkty zapiszą się automatycznie w lokalnym katalogu. "
                    "Wybierz producenta lub wpisz nową nazwę."
                )
                self.info_katalogu.setVisible(katalog_uzytkownika is not None)
                self.lokalny_status.connect(self.info_katalogu.setText)
                card.addWidget(self.info_katalogu)
                buttons.addWidget(self.produkt_przycisk)
                buttons.addWidget(self.nowy_przycisk)
                buttons.addWidget(self.parametry_masowe)
                card.addLayout(buttons)
            else:
                buttons.addWidget(self.sprzedaz_przycisk)
                buttons.addWidget(self.vat_przycisk)
                buttons.addWidget(self.przelicznik_przycisk)
                card.addLayout(buttons)
                card.addWidget(self.kompletny)
            przygotowanie.addWidget(karta, 1)
        layout.addLayout(przygotowanie)
        wybor = QHBoxLayout()
        self.wszystkie = QPushButton("Zaznacz widoczne")
        self.odznacz = QPushButton("Odznacz")
        self.masowa = QPushButton("Edytuj dane…")
        self.filtr = QComboBox()
        for nazwa in (
            "Wszystkie pozycje",
            "Gotowe",
            "Do poprawy",
            "Odrzucone",
            "Niewysłane",
            "Do sprawdzenia",
            "Utworzone — do uzupełnienia",
            "Utworzone",
        ):
            self.filtr.addItem(nazwa)
        self.filtr.setAccessibleName("Filtr gotowości i wyników paczki")
        self.filtr.setMaximumWidth(230)
        self.zakres = etykieta("Wybrane: 0")
        self.zakres.setWordWrap(False)
        self.zakres.setObjectName("opis")
        self.duplikaty_przycisk = QPushButton("Sprawdź duplikaty")
        self.duplikaty_przycisk.clicked.connect(self.sprawdz_duplikaty)
        self.przyciski += (self.duplikaty_przycisk,)
        self.wiecej = QPushButton("Więcej działań")
        self.menu_dzialan = QMenu(self.wiecej)
        self.wiecej.setMenu(self.menu_dzialan)
        self.akcje_dodatkowe = []
        for button in (
            self.uzupelnij_przycisk,
            self.odznacz,
            self.wynik_przycisk,
            self.eksport,
            self.sygnatury,
        ):
            action = self.menu_dzialan.addAction(button.text())
            action.triggered.connect(button.click)
            self.akcje_dodatkowe.append((action, button))
            button.setParent(self)
            button.hide()
        self.menu_dzialan.addSeparator()
        self.nowa_proba_akcja = self.menu_dzialan.addAction("Sprawdź blokadę i ponów…")
        self.nowa_proba_akcja.triggered.connect(self.sprawdz_blokade)
        self.menu_dzialan.aboutToShow.connect(self._menu_dzialan)
        for widget in (self.wszystkie, self.masowa, self.duplikaty_przycisk):
            wybor.addWidget(widget)
        self.popraw_przycisk = QPushButton("Popraw wybrane…")
        self.popraw_przycisk.clicked.connect(self.popraw_wybrane)
        wybor.addWidget(self.popraw_przycisk)
        wybor.addStretch(1)
        wybor.addWidget(self.zakres)
        wybor.addWidget(self.filtr)
        wybor.addWidget(self.wiecej)
        layout.addLayout(wybor)
        self.przyciski += (self.wszystkie, self.odznacz, self.masowa, self.parametry_masowe)
        self.tabela = QTableWidget(len(oferty), 8)
        self.tabela.setHorizontalHeaderLabels(
            (
                "SKU",
                "Nazwa produktu",
                "Produkt Allegro",
                "Cena brutto",
                "Gotowość / wynik",
                "ID Allegro",
                "Ilość",
                "Zdjęcie",
            )
        )
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.verticalHeader().hide()
        self.tabela.verticalHeader().setDefaultSectionSize(76)
        self.tabela.setShowGrid(False)
        self.tabela.setWordWrap(False)
        self.tabela.setAlternatingRowColors(True)
        header = self.tabela.horizontalHeader()
        header.setStretchLastSection(False)
        header.moveSection(7, 0)
        self.tabela.setColumnWidth(7, 84)
        header.setSectionResizeMode(7, QHeaderView.ResizeMode.Fixed)
        self.tabela.viewport().installEventFilter(self)
        self.tabela.verticalScrollBar().valueChanged.connect(
            lambda _: self.timer_miniatur.start(40)
        )
        self.timer_miniatur.start(0)
        for col, width in ((0, 140), (3, 115), (4, 150), (5, 105), (6, 65)):
            self.tabela.setColumnWidth(col, width)
        for col in (1, 2):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.Stretch)
        self.tabela.setAccessibleName("Plan i wyniki tworzenia szkiców z ZIP")
        for i, o in enumerate(oferty):
            for j, tekst in enumerate(
                (o.sku, o.tytul, "Do sprawdzenia", o.cena, "Nie sprawdzono", "", "1")
            ):
                item = QTableWidgetItem(tekst)
                item.setToolTip(tekst)
                self.tabela.setItem(i, j, item)
        layout.addWidget(self.tabela, 1)
        self.pasek = QProgressBar()
        self.pasek.hide()
        layout.addWidget(self.pasek)
        self.info = etykieta(
            "Uzupełnij dane i kliknij „Sprawdź paczkę”. "
            "Wybierz wiersz, aby zobaczyć szczegóły braków."
        )
        self.info.setObjectName("opis")
        layout.addWidget(self.info)
        self.podsumowanie = etykieta("")
        self.podsumowanie.setObjectName("tytulSekcjiAllegro")
        self.podsumowanie.setToolTip(
            "Gotowe — zapis potwierdzony przez Allegro. Do sprawdzenia — czeka na potwierdzenie; "
            "użyj Sprawdź wyniki wysyłki. Pominięte — już na Allegro. "
            "Ustawienia do sprawdzenia — oferta już utworzona, bez potwierdzenia wybranych pól. "
            "Szczegóły są pod przyciskiem Szczegóły wysyłki."
        )
        self.podsumowanie.hide()
        layout.addWidget(self.podsumowanie)
        bottom = QHBoxLayout()
        note = etykieta("Zapisujemy szkice. Sprzedaż uruchomisz osobno.")
        note.setObjectName("opis")
        bottom.addWidget(note, 1)
        self.pracuj_w_programie = QPushButton("Pracuj w programie")
        self.pracuj_w_programie.setAccessibleName(
            "Ukryj przygotowanie Allegro i pracuj w programie"
        )
        self.pracuj_w_programie.clicked.connect(self.w_tle_zadane.emit)
        bottom.addWidget(self.pracuj_w_programie)
        bottom.addWidget(self.anuluj)
        self.szczegoly_przycisk = QPushButton("Szczegóły wysyłki")
        self.szczegoly_przycisk.setToolTip("Dlaczego nie wysłano i co wymaga poprawy")
        self.szczegoly_przycisk.clicked.connect(self.pokaz_szczegoly)
        self.szczegoly_przycisk.setEnabled(False)
        bottom.addWidget(self.szczegoly_przycisk)
        bottom.addWidget(self.wynik_przycisk)
        self.wynik_przycisk.hide()
        bottom.addWidget(self.sprawdz_przycisk)
        bottom.addWidget(self.utworz_przycisk)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        close.rejected.connect(self.reject)
        bottom.addWidget(close)
        layout.addLayout(bottom)
        self.sprawdz_przycisk.clicked.connect(self.przygotuj)
        self.produkt_przycisk.clicked.connect(self.wybierz_produkt)
        self.sprzedaz_przycisk.clicked.connect(self.ustaw_sprzedaz)
        self.vat_przycisk.clicked.connect(self.ustaw_vat)
        self.kompletny.toggled.connect(self.uniewaznij)
        self.nowy_przycisk.clicked.connect(self.nowy_produkt)
        self.uzupelnij_przycisk.clicked.connect(self.uzupelnij)
        self.utworz_przycisk.clicked.connect(self.tworz)
        self.wynik_przycisk.clicked.connect(lambda: self.wyslij(True))
        self.eksport.clicked.connect(self.eksportuj)
        self.sygnatury.clicked.connect(self.popraw_sygnatury)
        self.przyciski += (self.sygnatury,)
        self.waluta.currentIndexChanged.connect(self.uniewaznij)
        self.ilosc.valueChanged.connect(self.uniewaznij)
        self.wszystkie.clicked.connect(self.zaznacz_widoczne)
        self.odznacz.clicked.connect(self.tabela.clearSelection)
        self.masowa.clicked.connect(self.edytuj_masowo)
        self.parametry_masowe.clicked.connect(lambda: self.uzupelnij(True))
        self.filtr.currentIndexChanged.connect(self._filtruj)
        self.postep.connect(self._postep)
        self.tabela.itemSelectionChanged.connect(self._szczegoly_wyniku)
        self.tabela.currentCellChanged.connect(lambda *_: self._szczegoly_wyniku())
        self._przyciski()

    def eventFilter(self, obiekt: QObject, zdarzenie: QEvent) -> bool:
        if obiekt is self.tabela.viewport() and zdarzenie.type() in (
            QEvent.Type.Show,
            QEvent.Type.Resize,
        ):
            self.timer_miniatur.start(0)
        return super().eventFilter(obiekt, zdarzenie)

    def _miniatury_widoczne(self) -> None:
        if not self.isVisible():
            return
        for row in range(len(self.oferty)):
            if self.tabela.isRowHidden(row) or not self.tabela.visualRect(
                self.tabela.model().index(row, 7)
            ).intersects(self.tabela.viewport().rect()):
                continue
            o = self.oferty[row]
            url = next(iter(o.zdjecia), "") or next(
                (e.adres for section in o.sekcje for e in section if e.typ == "obraz"), ""
            )
            if self._miniatury.get(row) == url:
                continue
            self._miniatury[row] = url
            image = self.obrazy.obraz(url)
            if not url:
                image.setText("—")
                image.setAccessibleName("Brak zdjęcia produktu")
            host = QWidget()
            box = QHBoxLayout(host)
            box.setContentsMargins(4, 4, 4, 4)
            box.addWidget(image, 0, Qt.AlignmentFlag.AlignCenter)
            self.tabela.setCellWidget(row, 7, host)

    def _menu_dzialan(self) -> None:
        self.nowa_proba_akcja.setEnabled(
            not self.trwa and not self.nieaktualny and bool(self.plany)
        )
        for action, button in self.akcje_dodatkowe:
            action.setEnabled(button.isEnabled())

    def wybrane(self) -> tuple[int, ...]:
        return tuple(
            sorted(
                i.row()
                for i in self.tabela.selectionModel().selectedRows()
                if not self.tabela.isRowHidden(i.row())
            )
        )

    def zakres_wysylki(self) -> tuple[int, ...]:
        return self.wybrane() or tuple(
            i for i in range(len(self.plany)) if not self.tabela.isRowHidden(i)
        )

    def _edytowalny(self, i: int) -> bool:
        return mozna_poprawic_przed_utworzeniem(self.wyniki[i] if i < len(self.wyniki) else None)

    def _sprawdz_edycje(self, rows: tuple[int, ...]) -> bool:
        if any(not self._edytowalny(i) for i in rows):
            self.info.setText(
                "Wybór obejmuje ofertę już utworzoną lub z niepewnym wynikiem. "
                "Sprawdź wynik wysyłki. Istniejącą ofertę edytuj w zakładce Allegro."
            )
            return False
        return True

    def _mozna_wyslac(self, i: int) -> bool:
        return (
            i < len(self.plany)
            and not self.plany[i].bledy
            and not self.duplikaty.get(i)
            and self._edytowalny(i)
            and (i >= len(self.wyniki) or self.wyniki[i].stan not in {"Odrzucono", "Do poprawy"})
        )

    def _powod_poprawki(self, i: int) -> str:
        w = self.wyniki[i] if i < len(self.wyniki) else None
        poprzedni = self._odrzucenia.get(i)
        tekst = (w.komunikat + "\n" + wskazowka_wyniku(w.stan, w.komunikat)) if w else ""
        if poprzedni and poprzedni != w:
            tekst += (
                "\n\nPoprzedni powód przed wysyłką:\n"
                + poprzedni.komunikat
                + "\n"
                + wskazowka_wyniku(poprzedni.stan, poprzedni.komunikat)
            )
        return tekst

    def popraw_wybrane(self) -> None:
        if self.trwa or self.nieaktualny:
            return
        rows = self.wybrane()
        if not rows:
            self.info.setText("Zaznacz oferty do poprawienia lub użyj „Zaznacz widoczne”.")
            return
        if not self._sprawdz_edycje(rows):
            return
        d = QDialog(self)
        d.setWindowTitle(f"Popraw wybrane oferty • {len(rows)}")
        d.setWindowFlag(Qt.WindowType.WindowContextHelpButtonHint, False)
        d.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        d.setMinimumSize(700, 420)
        d.resize(840, 520)
        box = QVBoxLayout(d)
        box.addWidget(etykieta("Powód i wskazówki dla zaznaczonych ofert"))
        powod = QPlainTextEdit()
        powod.setReadOnly(True)
        powod.setAccessibleName("Powody i wskazówki poprawy wybranych ofert")
        powod.setPlainText(
            "\n\n".join(f"{self.oferty[i].sku}\n{self._powod_poprawki(i)}" for i in rows)
        )
        box.addWidget(powod, 1)
        box.addWidget(etykieta("Wybierz dane do poprawienia. Zapis w tym oknie nie wysyła oferty."))
        wybor: list[str] = []
        for nazwa, typ in (
            ("Parametry produktu, np. numer katalogowy…", "parametry"),
            ("Tytuł, cena i ilość…", "dane"),
            ("GPSR, dostawa i warunki…", "gpsr"),
            ("VAT…", "vat"),
        ):
            button = QPushButton(nazwa)

            def klik(_checked: bool = False, typ: str = typ) -> None:
                wybor.append(typ)
                d.accept()

            button.clicked.connect(klik)
            box.addWidget(button)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        close.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        close.rejected.connect(d.reject)
        box.addWidget(close)
        accepted = d.exec() == QDialog.DialogCode.Accepted
        d.deleteLater()
        if not accepted or not wybor or self.nieaktualny:
            return
        self._poprawiane = rows
        self.tabela.setCurrentCell(rows[0], 4, QItemSelectionModel.SelectionFlag.NoUpdate)
        if wybor[0] == "parametry":
            self.uzupelnij(len(rows) > 1)
        elif wybor[0] == "dane":
            self.edytuj_masowo()
        elif wybor[0] == "gpsr":
            self.ustaw_sprzedaz()
        else:
            self.ustaw_vat()
        if not self.trwa:
            self._poprawiane = ()

    def _wybor(self) -> None:
        rows = self.wybrane()
        gotowe = sum(self._mozna_wyslac(i) for i in rows if i < len(self.plany))
        self.zakres.setText(f"Wybrane: {len(rows)} • gotowe: {gotowe}")
        self.utworz_przycisk.setEnabled(
            not self.trwa
            and not self.nieaktualny
            and any(self._mozna_wyslac(i) for i in self.zakres_wysylki() if i < len(self.plany))
        )
        self.utworz_przycisk.setText(
            "Wyślij poprawione szkice…"
            if rows and any(i in self._odrzucenia for i in rows)
            else "Utwórz zaznaczone szkice…"
            if rows
            else "Utwórz gotowe szkice…"
        )
        bledne = tuple(
            i
            for i, w in enumerate(self.wyniki)
            if w.stan in {"Odrzucono", "Do poprawy"} and not self.tabela.isRowHidden(i)
        )
        self.popraw_przycisk.setVisible(bool(bledne))
        self.popraw_przycisk.setEnabled(
            not self.trwa and not self.nieaktualny and bool(bledne) and bool(rows)
        )

    def _filtruj(self) -> None:
        self.timer_miniatur.start(0)
        for i in range(len(self.oferty)):
            w = self.wyniki[i] if i < len(self.wyniki) else None
            stan = w.stan if w else "Nie sprawdzono"
            index = self.filtr.currentIndex()
            pasuje = (
                index == 0
                or (index == 1 and self._mozna_wyslac(i))
                or (index == 2 and stan == "Do poprawy" and self._edytowalny(i))
                or (index == 3 and stan == "Odrzucono")
                or (
                    index == 4
                    and stan
                    in {"Nie wysłano", "Wstrzymano", "Anulowano", "Nie sprawdzono", "Pominięto"}
                )
                or (
                    index == 5 and stan in {"Wymaga sprawdzenia", "Wynik nieznany", "Przetwarzanie"}
                )
                or (index == 6 and stan in {"Szkic do poprawy", USTAWIENIA_DO_SPRAWDZENIA})
                or (
                    index == 7
                    and bool(w and w.ident)
                    and stan
                    in {
                        "Utworzono szkic",
                        "Szkic kompletny",
                        "Szkic do poprawy",
                        USTAWIENIA_DO_SPRAWDZENIA,
                        "Już na Allegro",
                    }
                )
            )
            hide = not pasuje
            if hide:
                for col in range(self.tabela.columnCount()):
                    self._komorka(i, col).setSelected(False)
            self.tabela.setRowHidden(i, hide)
        self._wybor()

    def zaznacz_widoczne(self) -> None:
        self.tabela.selectAll()
        self._filtruj()

    def popraw_sygnatury(self) -> None:
        rows = self.wybrane()
        if not rows or self.trwa or self.nieaktualny:
            self.info.setText("Zaznacz pozycje z wcześniej utworzonymi szkicami.")
            return
        if (
            QMessageBox.question(
                self,
                "Popraw sygnatury własnych szkiców",
                f"Konto: {self.sesja.konto.login}. Sprawdzić {len(rows)} pozycji "
                "i zamienić stare sygnatury vexlab-… na ich SKU? Zmienione zostaną "
                "wyłącznie własne, zarejestrowane szkice INACTIVE.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return

        def praca() -> tuple[WynikTworzenia, ...]:
            wyniki = (
                list(self.wyniki)
                if len(self.wyniki) == len(self.oferty)
                else [WynikTworzenia(o.sku, "Nie sprawdzono", "") for o in self.oferty]
            )
            for row in rows:
                if self.stop.is_set():
                    break
                try:
                    wyniki[row] = napraw_sygnature(
                        self.serwis,
                        cast(APISygnatur, self.serwis.api),
                        self.sesja,
                        self.oferty[row].sku,
                    )
                except BladAllegro as exc:
                    wyniki[row] = WynikTworzenia(
                        self.oferty[row].sku, "Wymaga sprawdzenia", str(exc)
                    )
                    break
                if wyniki[row].stan == "Wynik nieznany":
                    break
            return tuple(wyniki)

        def gotowe(w: object) -> None:
            self.wyniki = cast(tuple[WynikTworzenia, ...], w)
            self._pokaz_wyniki()
            self.info.setText(
                "Sprawdzono sygnatury. Zachowaj raport. Możesz ponownie sprawdzić "
                "operacje w toku tym samym przyciskiem."
            )

        self._zadanie(praca, gotowe)

    def sprawdz_blokade(self) -> None:
        if self.trwa or self.nieaktualny or not self.plany:
            return
        rows = self.wybrane()
        if len(rows) > 1:
            self.sprawdz_blokady_masowo(rows)
            return
        if not rows:
            QMessageBox.information(self, "Nowa próba", "Zaznacz zablokowane oferty.")
            return
        i = rows[0]
        p = self.plany[i]
        serwis = PrzygotujNowaProbe(self.serwis)

        def sprawdzono(w: object) -> None:
            kontrola = cast(KontrolaPonowienia, w)
            if (
                QMessageBox.question(
                    self,
                    "Potwierdź nową próbę",
                    f"Konto: {self.sesja.konto.login}\nSKU: {p.oferta.sku}\n"
                    f"Zapisane ID: {kontrola.poprzednia.ident or 'brak'}.\n"
                    "Nie znaleziono oferty w wykonanych odczytach SKU i tytułu/EAN. "
                    "Poprzedni wynik może być nieznany, a odczyt Allegro opóźniony. "
                    "Nowa próba może wtedy utworzyć duplikat. "
                    "Potwierdź także brak oferty w panelu Allegro.\n\n"
                    "Archiwizować poprzednią próbę i zezwolić na przygotowanie nowej? "
                    "To jeszcze nie wysyła oferty.",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No,
                )
                != QMessageBox.StandardButton.Yes
            ):
                return

            def odblokowano(_w: object) -> None:
                wyniki = list(self.wyniki)
                while len(wyniki) <= i:
                    wyniki.append(WynikTworzenia(self.oferty[len(wyniki)].sku, "Nie wysłano", ""))
                wyniki[i] = WynikTworzenia(
                    p.oferta.sku,
                    "Do poprawy",
                    "Nowa próba odblokowana po Twoim potwierdzeniu. "
                    "Sprawdź paczkę i wyślij osobno.",
                )
                self.wyniki = tuple(wyniki)
                self._odrzucenia.pop(i, None)
                self._uniewaznij_wiersze((i,))
                self.przygotuj()

            QTimer.singleShot(
                0,
                lambda: self._zadanie(
                    lambda: serwis.potwierdz(self.sesja, p, kontrola, True),
                    odblokowano,
                    "Ponowna kontrola i archiwizacja próby",
                ),
            )

        self._zadanie(lambda: serwis.sprawdz(self.sesja, p), sprawdzono, "Sprawdzanie blokady SKU")

    def sprawdz_blokady_masowo(self, rows: tuple[int, ...]) -> None:
        if self.trwa or self.nieaktualny or not rows or any(i >= len(self.plany) for i in rows):
            return
        plany = tuple(self.plany[i] for i in rows)
        serwis = PrzygotujNoweProby(self.serwis)

        def postep(n: int, total: int) -> None:
            self.postep.emit(n, f"Kontrola blokad {n}/{total} · {plany[n - 1].oferta.sku}")

        def sprawdzono(w: object) -> None:
            if self.nieaktualny:
                return
            partia = cast(PartiaKontroliPonowien, w)
            d = PodgladNowychProb(self, partia, self.sesja.konto.login)
            if (
                d.exec() != QDialog.DialogCode.Accepted
                or not d.zgoda.isChecked()
                or self.nieaktualny
            ):
                return

            def odblokowano(w: object) -> None:
                raport = cast(tuple[WynikPonowienia, ...], w)
                wyniki = list(self.wyniki)
                while len(wyniki) < len(self.oferty):
                    wyniki.append(WynikTworzenia(self.oferty[len(wyniki)].sku, "Nie wysłano", ""))
                zmienione = []
                for i, rezultat in zip(rows, raport, strict=True):
                    if rezultat.odblokowano:
                        wyniki[i] = WynikTworzenia(rezultat.sku, "Do poprawy", rezultat.komunikat)
                        self._odrzucenia.pop(i, None)
                        zmienione.append(i)
                    else:
                        wyniki[i] = replace(
                            wyniki[i], komunikat="Nowa próba: " + rezultat.komunikat
                        )
                self.wyniki = tuple(wyniki)
                self._pokaz_wyniki()
                self.podsumowanie.setText(
                    f"Odblokowano: {len(zmienione)} • "
                    f"Pozostawiono bez zmian: {len(rows) - len(zmienione)}. "
                    "Szczegóły dla każdej pozycji w Szczegółach wysyłki."
                )
                self.podsumowanie.show()
                if zmienione:
                    self.filtr.setCurrentIndex(0)
                    self._uniewaznij_wiersze(tuple(zmienione))
                    if not self.stop.is_set():
                        self.przygotuj()
                else:
                    self.info.setText(
                        "Nie odblokowano pozycji. Sprawdź powody w Szczegółach wysyłki."
                    )

            QTimer.singleShot(
                0,
                lambda: self._zadanie(
                    lambda: serwis.potwierdz(self.sesja, partia, True, self.stop.is_set, postep),
                    odblokowano,
                    "Odblokowywanie zaznaczonych pozycji",
                ),
            )

        self._zadanie(
            lambda: serwis.sprawdz(self.sesja, plany, self.stop.is_set, postep),
            sprawdzono,
            "Sprawdzanie blokad zaznaczonych ofert",
        )

    def ustaw_przelicznik(self) -> None:
        if self.trwa or self.nieaktualny:
            return
        rows = self.wybrane() or tuple(
            i for i in range(len(self.oferty)) if not self.tabela.isRowHidden(i)
        )
        if not rows or not self._sprawdz_edycje(rows):
            return
        if any(self._ustawienia(i).waluta != "PLN" for i in rows):
            QMessageBox.information(
                self, "Przelicznik cen", "Ustaw cenę bazową w PLN na allegro.pl."
            )
            return
        d = WyborPrzelicznika(
            self,
            self.sesja,
            len(rows),
            self._ustawienia(rows[0]).przelicznik,
            lambda: self.serwis.api.reguly_kursowe(self.sesja, True),
            self.uruchom,
            lambda: not self.nieaktualny,
        )
        if d.exec() == QDialog.DialogCode.Accepted and not self.nieaktualny:
            for i in rows:
                self.ustawienia[i] = replace(self._ustawienia(i), przelicznik=d.wynik)
            self._uniewaznij_wiersze(rows)
            self.przygotuj()

    def dokoncz_przeliczniki(self) -> None:
        if self.trwa or self.nieaktualny:
            return
        rows = tuple(
            i
            for i in (self.wybrane() or tuple(range(len(self.plany))))
            if not self.tabela.isRowHidden(i)
            and i < len(self.plany)
            and self.plany[i].ustawienia.przelicznik is not None
            and i < len(self.wyniki)
            and self.wyniki[i].ident
        )
        if not rows:
            QMessageBox.information(
                self,
                "Przelicznik cen",
                "Brak utworzonych ofert z wybranym przelicznikiem w tym zakresie.",
            )
            return
        if (
            QMessageBox.question(
                self,
                "Przelicznik cen",
                f"Przypiąć wybraną regułę do {len(rows)} utworzonych ofert? "
                "Nie tworzy to nowych ofert i nie uruchamia sprzedaży. "
                "Istniejące próby zostaną tylko sprawdzone.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        poprzednie, plany = self.wyniki, self.plany

        def praca() -> tuple[WynikTworzenia, ...]:
            wynik = list(poprzednie)
            for i in rows:
                if self.stop.is_set():
                    break
                self.postep.emit(i + 1, plany[i].oferta.sku)
                try:
                    wynik[i] = self.serwis.dokoncz_przelicznik(
                        self.sesja, plany[i], self.stop.is_set
                    )
                except BladAllegro as exc:
                    wynik[i] = replace(
                        wynik[i], komunikat=wynik[i].komunikat + " Przelicznik cen: " + str(exc)
                    )
            return tuple(wynik)

        def gotowe(w: object) -> None:
            self.wyniki = cast(tuple[WynikTworzenia, ...], w)
            self._pokaz_wyniki()
            self.podsumowanie.setText(podsumuj_wysylke(self.wyniki))
            self.podsumowanie.show()
            self.info.setText("Przelicznik cen: sprawdź wynik w Szczegółach wysyłki.")

        self._zadanie(praca, gotowe, "Przelicznik cen Allegro")

    def ustaw_vat(self) -> None:
        if self.trwa or self.nieaktualny:
            return
        rows = self.wybrane() or tuple(
            i for i in range(len(self.oferty)) if not self.tabela.isRowHidden(i)
        )
        if not rows or not self._sprawdz_edycje(rows):
            return
        if any(i >= len(self.plany) or self.plany[i].produkt is None for i in rows):
            QMessageBox.information(
                self,
                "VAT — wybierz kategorię",
                "Najpierw wybierz kategorię lub produkt Allegro i sprawdź paczkę.",
            )
            return
        categories = {cast(ProduktSzkicu, self.plany[i].produkt).kategoria for i in rows}
        if len(categories) != 1:
            QMessageBox.information(
                self,
                "VAT — jedna kategoria",
                "Stawki zależą od kategorii. Zaznacz grupę ofert jednej kategorii.",
            )
            return
        category = next(iter(categories))
        d = VATAllegro(
            self,
            category,
            len(rows),
            self._ustawienia(rows[0]).vat,
            lambda: self.serwis.api.vat_kategorii(self.sesja, category, True),
            lambda ident: self.serwis.api.vat_oferty(self.sesja, ident, category),
            self.uruchom,
            lambda: not self.nieaktualny,
            konto=self.sesja.konto.login,
        )
        if d.exec() == QDialog.DialogCode.Accepted and not self.nieaktualny:
            for i in rows:
                self.ustawienia[i] = replace(self._ustawienia(i), vat=d.wynik)
            self._uniewaznij_wiersze(rows)
            self.przygotuj()

    def ustaw_sprzedaz(self) -> None:
        if self.trwa or self.nieaktualny:
            return
        rows = self.wybrane() or tuple(
            i for i in range(len(self.oferty)) if not self.tabela.isRowHidden(i)
        )
        if not rows or not self._sprawdz_edycje(rows):
            return

        d = DaneSprzedazyAllegro(
            self,
            SlownikiSprzedazy((), (), (), (), (), ()),
            self._ustawienia(rows[0]).sprzedaz,
            len(rows),
            pobierz=lambda: self.serwis.api.slowniki_sprzedazy(self.sesja, True, True),
            uruchom=self.uruchom,
            aktualne=lambda: not self.nieaktualny,
            szablony_ofert=self.szablony_ofert,
        )
        if d.exec() == QDialog.DialogCode.Accepted and d.wynik and not self.nieaktualny:
            for row in rows:
                self.ustawienia[row] = replace(self._ustawienia(row), sprzedaz=d.wynik)
            self._uniewaznij_wiersze(rows)
            self.przygotuj()

    def edytuj_masowo(self) -> None:
        rows = self.wybrane()
        if not rows or self.trwa or self.nieaktualny:
            self.info.setText("Zaznacz pozycje do edycji (Ctrl/Shift lub Zaznacz widoczne).")
            return
        if not self._sprawdz_edycje(rows):
            return
        d = MasowaPaczkaAllegro(self, tuple((self.oferty[i], self._ustawienia(i)) for i in rows))
        if d.exec() != QDialog.DialogCode.Accepted or self.nieaktualny or not d.wynik:
            return
        oferty = list(self.oferty)
        for i, (o, u) in zip(rows, d.wynik, strict=True):
            oferty[i], self.ustawienia[i], self.ilosci[i] = o, u, u.ilosc
        self.oferty = tuple(oferty)
        self._uniewaznij_wiersze(rows)
        self.przygotuj()

    def _szczegoly_wyniku(self) -> None:
        self._wybor()
        row = self.tabela.currentRow()
        if not self.trwa and 0 <= row < len(self.wyniki):
            self.info.setText(self.wyniki[row].komunikat[:1200])

    def pokaz_szczegoly(self) -> None:
        if not self.wyniki:
            return
        d = QDialog(self)
        d.setWindowTitle("Szczegóły wysyłki — powody i wymagane poprawki")
        d.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        d.setMinimumSize(700, 420)
        d.resize(1000, 620)
        layout = QVBoxLayout(d)
        opis = etykieta("Wybierz ofertę, aby przeczytać pełny powód i wskazówkę.")
        layout.addWidget(opis)
        filtr = QComboBox()
        filtr.addItems(("Wymagające uwagi", "Wszystkie oferty"))
        filtr.setAccessibleName("Zakres szczegółów wysyłki")
        layout.addWidget(filtr)
        tabela = QTableWidget(0, 3)
        tabela.setHorizontalHeaderLabels(("SKU", "Status", "Powód / co poprawić"))
        tabela.setAccessibleName("Powody niewysłania i wymagane poprawki ofert")
        tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        tabela.setColumnWidth(0, 200)
        tabela.setColumnWidth(1, 155)
        tabela.horizontalHeader().setStretchLastSection(True)
        tabela.verticalHeader().hide()
        tabela.verticalHeader().setDefaultSectionSize(62)
        layout.addWidget(tabela, 1)
        szczegoly = QPlainTextEdit()
        szczegoly.setReadOnly(True)
        szczegoly.setAccessibleName("Pełny powód statusu oferty i co zrobić dalej")
        szczegoly.setMaximumHeight(160)
        layout.addWidget(szczegoly)
        zamknij = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        zamknij.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        zamknij.rejected.connect(d.reject)
        ponow = zamknij.addButton(
            "Sprawdź blokadę i ponów…", QDialogButtonBox.ButtonRole.ActionRole
        )
        ponow.setEnabled(bool(self.plany) and not self.trwa)
        wszystkie_widoczne = zamknij.addButton(
            "Zaznacz widoczne", QDialogButtonBox.ButtonRole.ActionRole
        )
        wszystkie_widoczne.clicked.connect(tabela.selectAll)

        def otworz_ponowienie() -> None:
            zaznaczone = tuple(index.row() for index in tabela.selectionModel().selectedRows())
            if not zaznaczone:
                return
            rows = tuple(
                sorted(
                    {self.wyniki.index(widoczne[row]) for row in zaznaczone if row < len(widoczne)}
                )
            )
            if not rows:
                return
            self.filtr.setCurrentIndex(0)
            self.tabela.clearSelection()
            for i in rows:
                self.tabela.selectionModel().select(
                    self.tabela.model().index(i, 0),
                    QItemSelectionModel.SelectionFlag.Select
                    | QItemSelectionModel.SelectionFlag.Rows,
                )
            self.tabela.setCurrentCell(rows[0], 0, QItemSelectionModel.SelectionFlag.NoUpdate)
            d.reject()
            QTimer.singleShot(0, self.sprawdz_blokade)

        ponow.clicked.connect(otworz_ponowienie)
        layout.addWidget(zamknij)
        wyniki = self.wyniki  # Spójny podgląd, bez żądań API ani zmiany wyboru paczki.
        widoczne: list[WynikTworzenia] = []

        def szczegol() -> None:
            row = tabela.currentRow()
            if 0 <= row < len(widoczne):
                w = widoczne[row]
                szczegoly.setPlainText(
                    (
                        f"{w.sku} · {w.stan}\n{w.komunikat}\n"
                        f"{wskazowka_wyniku(w.stan, w.komunikat)}"
                    ).strip()
                )
            else:
                szczegoly.clear()

        def odswiez() -> None:
            bez_uwag = {
                "Gotowa do utworzenia",
                "Utworzono szkic",
                "Szkic kompletny",
                "Już na Allegro",
            }
            widoczne[:] = [w for w in wyniki if filtr.currentIndex() == 1 or w.stan not in bez_uwag]
            tabela.setRowCount(len(widoczne))
            for i, w in enumerate(widoczne):
                for j, tekst in enumerate((w.sku, w.stan, w.komunikat)):
                    item = QTableWidgetItem(tekst)
                    item.setToolTip(tekst)
                    tabela.setItem(i, j, item)
            opis.setText(
                f"Ofert: {len(widoczne)}. Wybierz wiersz, aby przeczytać pełny powód i wskazówkę."
                if widoczne
                else "Brak ofert wymagających uwagi. Możesz wybrać „Wszystkie oferty”."
            )
            if widoczne:
                tabela.setCurrentCell(0, 0)
            szczegol()

        tabela.currentCellChanged.connect(lambda *_: szczegol())
        filtr.currentIndexChanged.connect(odswiez)
        odswiez()
        d.exec()
        d.deleteLater()

    def _postep(self, numer: int, sku: str) -> None:
        self.info.setText(
            f"Pozycja {numer}/{len(self.oferty)} • {sku}. Żądania już wysłanego nie można cofnąć."
        )

    def _przyciski(self) -> None:
        self.szczegoly_przycisk.setEnabled(bool(self.wyniki) and not self.trwa)
        self.producent_lokalny.setEnabled(not self.trwa and not self.nieaktualny)
        for b in self.przyciski:
            b.setEnabled(not self.trwa and not self.nieaktualny)
        self.utworz_przycisk.setEnabled(
            not self.trwa and not self.nieaktualny and any(not p.bledy for p in self.plany)
        )
        self.wynik_przycisk.setEnabled(not self.trwa and not self.nieaktualny and bool(self.plany))
        self.wynik_przycisk.setVisible(
            any(
                w.stan
                in {
                    "Wynik nieznany",
                    "Wymaga sprawdzenia",
                    "Przetwarzanie",
                    USTAWIENIA_DO_SPRAWDZENIA,
                }
                for w in self.wyniki
            )
        )
        self.eksport.setEnabled(not self.trwa and bool(self.wyniki))
        self.formularz.setEnabled(not self.trwa and not self.nieaktualny)
        self.kompletny.setEnabled(not self.trwa and not self.nieaktualny)
        self.anuluj.setEnabled(self.trwa)
        self.anuluj.setVisible(self.trwa)
        self._wybor()

    def _uniewaznij_wiersze(self, rows: tuple[int, ...]) -> None:
        self._zmienione.update(i for i in rows if self._edytowalny(i))
        if self.plany:
            self._ostatnie_plany = self.plany
        self.duplikaty.clear()
        self.plany = ()
        self._przyciski()
        self.info.setText("Ustawienia zmienione. Sprawdź paczkę ponownie.")

    def uniewaznij(self) -> None:
        self._uniewaznij_wiersze(tuple(range(len(self.oferty))))

    def zmiana_sesji(self) -> None:
        self.nieaktualny = True
        self.stop.set()
        self.info.setText(
            "Sesja konta zmieniła się. Zatrzymano dalsze żądania; zachowaj "
            "raport i otwórz plan ponownie."
        )
        self._przyciski()

    def _zadanie(
        self,
        funkcja: Callable[[], object],
        sukces: Callable[[object], None],
        opis_pracy: str = "Przygotowanie Allegro",
    ) -> None:
        if self.trwa or self.nieaktualny:
            return
        self.trwa = True
        self.praca_zmieniona.emit(True, opis_pracy)
        self.stop.clear()
        self.pasek.setRange(0, 0)
        self.pasek.show()
        self._przyciski()

        def gotowe(wynik: object) -> None:
            self.trwa = False
            self.pasek.hide()
            sukces(wynik)
            self._przyciski()
            self.praca_zmieniona.emit(
                False,
                self.podsumowanie.text()
                if not self.podsumowanie.isHidden()
                else "Operacja zakończona",
            )

        def blad(kod: str, opis: str) -> None:
            self.trwa = False
            self.pasek.hide()
            self.info.setText(opis)
            self._przyciski()
            self.praca_zmieniona.emit(False, "Błąd: " + opis)

        self.uruchom(funkcja, gotowe, blad)

    def _ustawienia(self, i: int) -> UstawieniaSzkicu:
        return replace(
            self.ustawienia.get(i, UstawieniaSzkicu("", 1)),
            waluta=str(self.waluta.currentData()),
            ilosc=self.ilosci.get(i, self.ilosc.value()),
            gotowosc=self.kompletny.isChecked(),
        )

    def przygotuj(self) -> None:
        if self.trwa or self.nieaktualny:
            return
        poprzednie = self.wyniki
        stare_plany = self.plany or self._ostatnie_plany
        zmienione = frozenset(self._zmienione)
        if stare_plany:
            self._ostatnie_plany = stare_plany
        self.duplikaty.clear()
        self.plany = ()
        ustawienia = tuple(self._ustawienia(i) for i in range(len(self.oferty)))
        duplikaty = Counter(o.sku.strip().casefold() for o in self.oferty)

        def zadanie() -> tuple[PlanNowegoSzkicu, ...]:
            wynik = []
            for i, (o, u) in enumerate(zip(self.oferty, ustawienia, strict=True)):
                if self.stop.is_set():
                    break
                self.postep.emit(i + 1, o.sku)
                if (
                    i < len(stare_plany)
                    and i < len(poprzednie)
                    and not mozna_poprawic_przed_utworzeniem(poprzednie[i])
                ):
                    wynik.append(stare_plany[i])
                    continue
                p = self.serwis.przygotuj(self.sesja, o, u)
                if duplikaty[o.sku.strip().casefold()] > 1:
                    p = replace(
                        p,
                        bledy=(
                            *p.bledy,
                            "Powtórzone SKU w paczce. Rozdziel pozycje przed wysyłką.",
                        ),
                    )
                wynik.append(p)
            return tuple(wynik)

        def gotowe(w: object) -> None:
            self.plany = cast(tuple[PlanNowegoSzkicu, ...], w)
            self._ostatnie_plany = self.plany + stare_plany[len(self.plany) :]
            self.wyniki = tuple(
                poprzednie[i]
                if i < len(poprzednie)
                and (
                    not mozna_poprawic_przed_utworzeniem(poprzednie[i])
                    or (poprzednie[i].stan == "Odrzucono" and i not in zmienione)
                )
                else WynikTworzenia(
                    p.oferta.sku,
                    "Do poprawy" if p.bledy else "Gotowa do utworzenia",
                    "; ".join(p.bledy)
                    or "Sprawdź nazwę dopasowanego produktu przed potwierdzeniem.",
                )
                for i, p in enumerate(self.plany)
            )
            self._zmienione.difference_update(range(len(self.plany)))
            self.wyniki += tuple(
                WynikTworzenia(
                    o.sku, "Nie sprawdzono", "Sprawdzanie zostało przerwane. Nie wysłano tworzenia."
                )
                if i >= len(poprzednie)
                else poprzednie[i]
                for i, o in enumerate(self.oferty[len(self.plany) :], len(self.plany))
            )
            self._pokaz_plan()
            if self._poprawiane:
                rows = self._poprawiane
                self._poprawiane = ()
                self.filtr.setCurrentIndex(0)
                self.tabela.clearSelection()
                for row in rows:
                    self.tabela.selectionModel().select(
                        self.tabela.model().index(row, 0),
                        QItemSelectionModel.SelectionFlag.Select
                        | QItemSelectionModel.SelectionFlag.Rows,
                    )
            self.info.setText(
                f"Sprawdzono {len(self.plany)} pozycji. "
                f"Do wysłania: {sum(self._mozna_wyslac(i) for i in range(len(self.plany)))}. "
                f"Do poprawy: {sum(bool(p.bledy) for p in self.plany)}."
            )

        self._zadanie(zadanie, gotowe)

    def _komorka(self, row: int, col: int) -> QTableWidgetItem:
        item = self.tabela.item(row, col)
        if item is None:
            item = QTableWidgetItem()
            self.tabela.setItem(row, col, item)
        return item

    def _pokaz_plan(self) -> None:
        for i, p in enumerate(self.plany):
            self._komorka(i, 2).setText(
                ("Nowy produkt • " if p.ustawienia.nowy else "") + p.produkt.nazwa
                if p.produkt
                else "Wybierz lub utwórz produkt"
            )
            self._komorka(i, 2).setToolTip(
                f"{p.produkt.nazwa}\n{p.produkt.id}" if p.produkt else ""
            )
            self._komorka(i, 1).setText(p.oferta.tytul)
            self._komorka(i, 1).setToolTip(p.oferta.tytul)
            self._komorka(i, 6).setText(str(p.ustawienia.ilosc))
            self._komorka(i, 3).setText(
                (p.ustawienia.cena or p.oferta.cena) + " " + p.ustawienia.waluta
            )
        self._pokaz_wyniki()
        self._filtruj()

    def _pokaz_wyniki(self) -> None:
        for i, w in enumerate(self.wyniki):
            item = self._komorka(i, 4)
            item.setData(Qt.ItemDataRole.AccessibleTextRole, w.stan)
            if w.stan == "Gotowa do utworzenia":
                item.setText("")
                znak = QLabel()
                znak.setPixmap(ikona("aktywne", "#55B294").pixmap(24, 24))
                znak.setAlignment(Qt.AlignmentFlag.AlignCenter)
                znak.setAccessibleName("Gotowa do utworzenia szkicu")
                znak.setToolTip("Gotowa do utworzenia szkicu. " + w.komunikat)
                self.tabela.setCellWidget(i, 4, znak)
            else:
                poprzedni = self.tabela.cellWidget(i, 4)
                if poprzedni is not None:
                    poprzedni.hide()
                self.tabela.removeCellWidget(i, 4)
                item.setText(
                    "Utworzono\nSprawdź ustawienia"
                    if w.stan == USTAWIENIA_DO_SPRAWDZENIA
                    else w.stan
                )
            self._komorka(i, 4).setToolTip(w.komunikat)
            self._komorka(i, 5).setText(w.ident)
        for i, w in enumerate(self.wyniki):
            if w.stan == "Odrzucono" or (w.stan == "Do poprawy" and i not in self._odrzucenia):
                self._odrzucenia[i] = w
        self.szczegoly_przycisk.setEnabled(bool(self.wyniki))
        self._filtruj()

    def wybierz_produkt(self) -> None:
        i = self.tabela.currentRow()
        if not 0 <= i < len(self.oferty) or self.trwa or self.nieaktualny:
            return
        if not self._sprawdz_edycje((i,)):
            return
        d = QDialog(self)
        d.setWindowTitle("Wybierz istniejący produkt z Katalogu Allegro")
        d.resize(700, 240)
        layout = QVBoxLayout(d)
        fraza = QLineEdit(self.oferty[i].ean or self.oferty[i].tytul)
        fraza.setAccessibleName("EAN lub nazwa produktu Allegro")
        search = QPushButton("Szukaj w Katalogu Allegro")
        wybor = QComboBox()
        wybor.setAccessibleName("Wyniki wyszukiwania produktów Allegro")
        info = etykieta("Wybór nie tworzy ani nie zmienia produktu w katalogu.")
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Wybierz")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
        for widget in (fraza, search, wybor, info, buttons):
            layout.addWidget(widget)

        def szukaj() -> None:
            query = fraza.text().strip()
            self.trwa = True
            self._przyciski()
            d.setEnabled(False)

            def gotowe(w: object) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                wybor.clear()
                for p in cast(tuple[ProduktSzkicu, ...], w):
                    wybor.addItem(p.nazwa + " • " + p.id, p.id)
                buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(wybor.count() > 0)
                info.setText("Wybierz właściwy produkt. Dla kolejnych wyników zawęź wyszukiwanie.")

            def blad(k: str, m: str) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                info.setText(m)

            self.uruchom(lambda: self.serwis.api.znajdz_produkty(self.sesja, query), gotowe, blad)

        def wybierz() -> None:
            if self.nieaktualny:
                d.reject()
                return
            self.ustawienia[i] = replace(
                self._ustawienia(i),
                produkt=str(wybor.currentData()),
                wartosci=(),
                nowy=False,
                kategoria="",
                zrodla=(),
            )
            d.accept()
            self._uniewaznij_wiersze((i,))
            self.przygotuj()

        search.clicked.connect(szukaj)
        buttons.accepted.connect(wybierz)
        buttons.rejected.connect(d.reject)
        d.exec()

    def _zastosuj_kategorie(
        self, i: int, kategoria: str, wszystkie: bool, wiersze: tuple[int, ...] = ()
    ) -> None:
        zmienione = []
        for row in range(len(self.oferty)):
            u = self._ustawienia(row)
            dopasowany = (
                row < len(self.plany)
                and self.plany[row].produkt is not None
                and not self.plany[row].ustawienia.nowy
            )
            if self._edytowalny(row) and (
                row == i or row in wiersze or (wszystkie and not u.produkt and not dopasowany)
            ):
                zmienione.append(row)
                self.ustawienia[row] = replace(
                    u, nowy=True, kategoria=kategoria, produkt="", wartosci=(), zrodla=()
                )
        self._uniewaznij_wiersze(tuple(zmienione))
        self.przygotuj()

    def nowy_produkt(self) -> None:
        i = self.tabela.currentRow()
        if not 0 <= i < len(self.oferty) or self.trwa or self.nieaktualny:
            self.info.setText("Zaznacz pozycję, dla której chcesz przygotować nowy produkt.")
            return
        rows = self.wybrane()
        if not self._sprawdz_edycje(tuple(set(rows) | {i})):
            return
        d = QDialog(self)
        d.setWindowTitle("Nowy produkt • wybierz kategorię Allegro")
        d.resize(850, 320)
        layout = QVBoxLayout(d)
        layout.addWidget(
            etykieta(
                "To przygotuje zgłoszenie do Katalogu Allegro. "
                "Wysłanie wymaga późniejszego potwierdzenia."
            )
        )
        fraza = QLineEdit(self.oferty[i].tytul)
        fraza.setAccessibleName("Nazwa produktu lub kategorii")
        szukaj = QPushButton("Znajdź kategorie")
        wybor = QComboBox()
        wybor.setAccessibleName("Kategoria nowego produktu Allegro")
        razem = QCheckBox("Zastosuj kategorię do wszystkich pozycji bez produktu Allegro")
        info = etykieta(
            f"Wybrany zakres: {len(rows) or 1} pozycji. "
            "Program pobierze wymagane parametry kategorii."
        )
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        ok = buttons.button(QDialogButtonBox.StandardButton.Ok)
        ok.setText("Wybierz kategorię")
        ok.setEnabled(False)
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        for widget in (fraza, szukaj, wybor, razem, info, buttons):
            layout.addWidget(widget)

        def search() -> None:
            query = fraza.text().strip()
            self.trwa = True
            self._przyciski()
            d.setEnabled(False)

            def gotowe(w: object) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                wybor.clear()
                wybor.addItem("Wybierz kategorię…", "")
                for k in cast(tuple[KategoriaSzkicu, ...], w):
                    wybor.addItem(k.nazwa + " • " + k.id, k.id)
                info.setText(
                    "Wybierz kategorię z listy."
                    if wybor.count() > 1
                    else "Brak kategorii. Zmień wyszukiwaną nazwę."
                )

            def blad(k: str, opis: str) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                info.setText(opis)

            self.uruchom(lambda: self.serwis.api.kategorie(self.sesja, query), gotowe, blad)

        wybor.currentIndexChanged.connect(lambda: ok.setEnabled(bool(wybor.currentData())))
        szukaj.clicked.connect(search)
        buttons.accepted.connect(d.accept)
        buttons.rejected.connect(d.reject)
        if d.exec() == QDialog.DialogCode.Accepted and not self.nieaktualny and wybor.currentData():
            self._zastosuj_kategorie(i, str(wybor.currentData()), razem.isChecked(), rows)

    def _zastosuj_parametry(
        self,
        i: int,
        cena: str,
        wartosci: tuple[tuple[str, str], ...],
        zrodla: tuple[tuple[str, str], ...],
        wszystkie: bool,
    ) -> None:
        if not self._sprawdz_edycje((i,)):
            return
        zmienione = [i]
        p = self.plany[i]
        self.ustawienia[i] = replace(p.ustawienia, cena=cena, wartosci=wartosci, zrodla=zrodla)
        if wszystkie and p.ustawienia.nowy:
            for row in range(len(self.oferty)):
                u = self._ustawienia(row)
                if (
                    row != i
                    and self._edytowalny(row)
                    and u.nowy
                    and u.kategoria == p.ustawienia.kategoria
                ):
                    zmienione.append(row)
                    self.ustawienia[row] = replace(u, wartosci=wartosci, zrodla=zrodla)
        self._uniewaznij_wiersze(tuple(zmienione))
        self.przygotuj()

    def uzupelnij(self, masowo: bool = False) -> None:
        i = self.tabela.currentRow()
        wybrane = self.wybrane()
        if masowo and wybrane and i not in wybrane:
            i = wybrane[0]
        if not 0 <= i < len(self.plany) or self.trwa:
            return
        p = self.plany[i]
        if not self._sprawdz_edycje(wybrane if masowo else (i,)):
            return
        if p.produkt is None:
            if masowo:
                self.info.setText("Najpierw wybierz kategorię lub produkt i sprawdź paczkę.")
                return
            self.wybierz_produkt()
            return
        rows = self.wybrane() if masowo else (i,)
        if masowo and (
            not rows
            or any(
                row >= len(self.plany)
                or self.plany[row].produkt is None
                or cast(ProduktSzkicu, self.plany[row].produkt).kategoria != p.produkt.kategoria
                or self.plany[row].ustawienia.nowy != p.ustawienia.nowy
                for row in rows
            )
        ):
            self.info.setText(
                "Parametry zbiorcze wymagają tej samej kategorii i trybu produktu. "
                "Wybierz zgodne pozycje."
            )
            return
        d = QDialog(self)
        d.setWindowTitle("Uzupełnij dane szkicu • " + p.oferta.sku)
        d.resize(700, 600)
        outer = QVBoxLayout(d)
        poprzedni_blad = self._odrzucenia.get(i)
        if poprzedni_blad is not None:
            powod = QPlainTextEdit()
            powod.setReadOnly(True)
            powod.setAccessibleName("Powód odrzucenia i wskazówka poprawy")
            powod.setPlainText(self._powod_poprawki(i))
            wiersze = min(3, max(2, powod.document().blockCount()))
            powod.setFixedHeight(powod.fontMetrics().lineSpacing() * wiersze + 20)
            outer.addWidget(powod)
        outer.addWidget(etykieta(p.produkt.nazwa + " • kategoria " + p.produkt.kategoria))
        tabs = QTabWidget()
        outer.addWidget(tabs, 1)
        forms = []
        for nazwa in ("Wymagane", "Dodatkowe"):
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            host = QWidget()
            form = QFormLayout(host)
            form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
            form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
            scroll.setWidget(host)
            tabs.addTab(scroll, nazwa)
            forms.append(form)
        form = forms[0]
        outer.insertWidget(
            1,
            etykieta(
                "SKU i EAN są pobierane z każdej pozycji paczki. Uzupełnij "
                "wymagane pola; pozostałe są w Dodatkowe."
            ),
        )
        advanced = QCheckBox("Zaawansowane: zmień źródła wartości")
        source_rows: list[tuple[QFormLayout, QWidget]] = []
        cena = QLineEdit(p.ustawienia.cena or p.oferta.cena)
        cena.setObjectName("cena_szkicu")
        if not masowo:
            form.addRow("Cena brutto (" + p.ustawienia.waluta + ")", cena)
        else:
            outer.addWidget(
                etykieta(
                    f"Zaznaczono {len(rows)} pozycji. "
                    "Zaznacz wyłącznie parametry do wspólnej zmiany."
                )
            )
        zmieniane: dict[str, QCheckBox] = {}
        pola: dict[str, QComboBox | QLineEdit] = {}
        zrodla: dict[str, QComboBox] = {}
        for req in p.produkt.parametry:
            produktowy = req.produktowy or (p.ustawienia.nowy and req.wymagany_produkt)
            wymagany = req.wymagany or (produktowy and req.wymagany_produkt)
            form = forms[0 if wymagany else 1]
            if req.produktowy and not p.ustawienia.nowy:
                continue
            value = dict(p.ustawienia.wartosci).get(req.id, "")
            if req.typ == "dictionary":
                pole = QComboBox()
                pole.addItem("Wybierz wartość", "")
                for ident, nazwa in req.slownik:
                    pole.addItem(nazwa, ident)
                pole.setCurrentIndex(max(0, pole.findData(value)))
                pola[req.id] = pole
            else:
                tekst = QLineEdit(value)
                tekst.setMaxLength(1000)
                pola[req.id] = tekst
            pola[req.id].setAccessibleName(req.nazwa)
            pola[req.id].setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            if isinstance(pola[req.id], QComboBox):
                box = cast(QComboBox, pola[req.id])
                box.setMinimumContentsLength(18)
                box.setSizeAdjustPolicy(
                    QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
                )
            produktowy = req.produktowy or (p.ustawienia.nowy and req.wymagany_produkt)
            wymagany = req.wymagany or (produktowy and req.wymagany_produkt)
            nazwa = req.nazwa + (" *" if wymagany else "")
            if masowo:
                check = QCheckBox(nazwa)
                zmieniane[req.id] = check
                form.addRow(check, pola[req.id])
            else:
                label = QLabel(nazwa)
                label.setWordWrap(True)
                label.setToolTip("Parametr produktu" if produktowy else "Parametr oferty")
                form.addRow(label, pola[req.id])
            if p.ustawienia.nowy and req.typ != "dictionary":
                source = QComboBox()
                source.setAccessibleName("Źródło parametru " + req.nazwa)
                jawny_kod = domyslne_zrodlo(req) == "sku"
                if jawny_kod:
                    source.addItem("Z paczki — SKU każdego produktu", "sku")
                    source.addItem(
                        "Wpisz ręcznie — wspólna wartość" if masowo else "Wpisz ręcznie", ""
                    )
                    if dict(p.ustawienia.zrodla).get(req.id) == "ean":
                        source.addItem("EAN z paczki — wcześniejsze ustawienie", "ean")
                else:
                    source.addItem("Wspólna wartość wpisana powyżej", "")
                    source.addItem("SKU z każdej pozycji paczki", "sku")
                    source.addItem("EAN z każdej pozycji paczki", "ean")
                source.setCurrentIndex(
                    max(0, source.findData(dict(p.ustawienia.zrodla).get(req.id, "")))
                )
                widget = pola[req.id]
                widget.setEnabled(not bool(source.currentData()))
                source.currentIndexChanged.connect(
                    lambda _i, combo=source, control=widget: control.setEnabled(
                        not bool(combo.currentData())
                    )
                )
                if masowo:
                    checkbox = zmieniane[req.id]
                    source.activated.connect(
                        lambda _idx, checkbox=checkbox: checkbox.setChecked(True)
                    )
                    source.currentIndexChanged.connect(
                        lambda _idx, checkbox=checkbox: (
                            checkbox.setChecked(True) if checkbox else None
                        )
                    )
                    if isinstance(widget, QLineEdit):
                        widget.textEdited.connect(
                            lambda _text, checkbox=checkbox: (
                                checkbox.setChecked(True) if checkbox else None
                            )
                        )
                widget.setToolTip(
                    (
                        "Wybierz poniżej wpisanie ręczne albo SKU z każdej pozycji paczki."
                        if jawny_kod
                        else "Wartość z bieżącej pozycji. Dla każdej oferty pobierana osobno. "
                        "Źródło zmienisz w Zaawansowane."
                    )
                    if source.currentData()
                    else ""
                )
                zrodla[req.id] = source
                source.setMinimumContentsLength(18)
                source.setSizeAdjustPolicy(
                    QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
                )
                form.addRow("Sposób uzupełniania" if jawny_kod else "Źródło", source)
                if not jawny_kod:
                    form.setRowVisible(source, False)
                    source_rows.append((form, source))
            if (
                self.szablony_ofert is not None
                and "taryf" in req.nazwa.casefold()
                and isinstance(pola[req.id], QLineEdit)
            ):
                field = cast(QLineEdit, pola[req.id])

                def wstaw_taryfe(value: str, ident: str = req.id, field: QLineEdit = field) -> None:
                    if ident in zrodla:
                        zrodla[ident].setCurrentIndex(zrodla[ident].findData(""))
                    field.setText(value)
                    if ident in zmieniane:
                        zmieniane[ident].setChecked(True)

                form.addRow(
                    "Moje taryfy",
                    WyborSzablonu(d, self.szablony_ofert, "taryfa", field.text, wstaw_taryfe),
                )
        advanced.toggled.connect(
            lambda visible: [f.setRowVisible(w, visible) for f, w in source_rows]
        )
        outer.addWidget(advanced)
        outer.addWidget(
            etykieta(
                "* Parametry wymagane. Ograniczenia i wymagania warunkowe "
                "dodatkowo sprawdza Allegro. GPSR i dostawę ustawisz przyciskiem "
                "„GPSR, dostawa i warunki…” w głównym oknie."
            )
        )
        razem = QCheckBox("Zastosuj parametry i źródła do nowych produktów w tej samej kategorii")
        razem.setObjectName("stosuj_parametry_wspolne")
        razem.setVisible(p.ustawienia.nowy and not masowo)
        outer.addWidget(razem)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Zastosuj")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.accepted.connect(d.accept)
        buttons.rejected.connect(d.reject)
        outer.addWidget(buttons)
        if d.exec() == QDialog.DialogCode.Accepted:
            wartosci = tuple(
                (ident, str(w.currentData()) if isinstance(w, QComboBox) else w.text())
                for ident, w in pola.items()
            )
            sources = tuple(
                (ident, str(w.currentData())) for ident, w in zrodla.items() if w.currentData()
            )
            if masowo:
                chosen = {ident for ident, check in zmieniane.items() if check.isChecked()}
                if not chosen:
                    self.info.setText("Nie zaznaczono parametrów do zmiany.")
                    return
                for row in rows:
                    self.ustawienia[row] = zmien_parametry(
                        self._ustawienia(row),
                        tuple(v for v in wartosci if v[0] in chosen),
                        tuple(v for v in sources if v[0] in chosen),
                    )
                self._uniewaznij_wiersze(rows)
                self.przygotuj()
            else:
                self._zastosuj_parametry(
                    i, cena.text().strip(), wartosci, sources, razem.isChecked()
                )

    def sprawdz_duplikaty(self) -> None:
        if self.kontrola_duplikatow is None:
            self.info.setText("Sprawdzanie konta jest niedostępne. Otwórz okno z programu VexLab.")
            return
        rows = self.wybrane() or tuple(
            i for i in range(len(self.oferty)) if not self.tabela.isRowHidden(i)
        )
        kontrola = self.kontrola_duplikatow

        def gotowe(w: object) -> None:
            matches = cast(tuple[tuple[IstniejacaOferta, ...], ...], w)
            if self.nieaktualny:
                return
            self.duplikaty.update(zip(rows, matches, strict=True))
            wyniki = (
                list(self.wyniki)
                if len(self.wyniki) == len(self.oferty)
                else [WynikTworzenia(o.sku, "Nie sprawdzono", "") for o in self.oferty]
            )
            for row, items in zip(rows, matches, strict=True):
                if items:
                    wyniki[row] = WynikTworzenia(
                        self.oferty[row].sku,
                        "Już na Allegro",
                        opis_duplikatow(items),
                        items[0].ident,
                    )
                elif wyniki[row].stan == "Już na Allegro":
                    p = self.plany[row] if row < len(self.plany) else None
                    wyniki[row] = WynikTworzenia(
                        self.oferty[row].sku,
                        "Gotowa do utworzenia" if p and not p.bledy else "Nie sprawdzono",
                        "Nie znaleziono dopasowania na koncie.",
                    )
            self.wyniki = tuple(wyniki)
            self._pokaz_wyniki()
            self.info.setText(
                f"Sprawdzono konto: {len(rows)} pozycji. "
                f"Znaleziono istniejące oferty dla {sum(bool(x) for x in matches)} pozycji. "
                "Znalezione pozycje zostaną pominięte. Wybierz wiersz, aby zobaczyć ID i status."
            )

        self._zadanie(
            lambda: kontrola.sprawdz(self.sesja, tuple(self.oferty[i] for i in rows)), gotowe
        )

    def odswiez_producentow_lokalnych(self) -> None:
        if self.katalog_uzytkownika is None:
            return

        def ok(value: object) -> None:
            if self._lokalny_zamkniety:
                return
            text = self.producent_lokalny.currentText()
            self.producent_lokalny.blockSignals(True)
            self.producent_lokalny.clear()
            self.producent_lokalny.addItems(cast(tuple[str, ...], value))
            self.producent_lokalny.setCurrentIndex(-1)
            self.producent_lokalny.setEditText(text)
            self.producent_lokalny.blockSignals(False)

        self.uruchom(
            self.katalog_uzytkownika.producenci,
            ok,
            lambda _code, text: (
                None if self._lokalny_zamkniety else self.info_katalogu.setText(text)
            ),
        )

    def tworz(self) -> None:
        rows = self.zakres_wysylki()
        gotowe = sum(self._mozna_wyslac(i) for i in rows if i < len(self.plany))
        if not gotowe or self.nieaktualny or self.trwa:
            return
        if (
            self.katalog_uzytkownika is not None
            and not self.producent_lokalny.currentText().strip()
        ):
            self.info_katalogu.setText("Wybierz lub wpisz producenta lokalnych produktów.")
            self.producent_lokalny.setFocus()
            return
        nowych = sum(
            not p.bledy and p.ustawienia.nowy for i, p in enumerate(self.plany) if i in rows
        )
        katalog = (
            f"\nUWAGA: dla {nowych} pozycji wyślesz definicje NOWYCH PRODUKTÓW "
            "do Katalogu Allegro. "
            "Allegro może utworzyć produkty lub dopasować istniejące. "
            "Potwierdzasz także ten skutek katalogowy.\n"
            if nowych
            else ""
        )
        if (
            QMessageBox.question(
                self,
                "Utwórz nowe szkice Allegro",
                f"Konto: {self.sesja.konto.login}\nŚrodowisko: "
                f"{self.sesja.srodowisko.value}\n\nUtworzyć {gotowe} nowych "
                f"szkiców INACTIVE? Pozostałe pozycje zostaną pominięte.\nWaluta: "
                f"{self.waluta.currentData()}, ilość w szkicu: "
                f"według planu. Zakres: {len(rows)} pozycji.\nSprawdź produkty, ceny i "
                f"parametry. Zdjęcia zostaną przesłane do Allegro.\nOferty nie "
                f"zostaną opublikowane do sprzedaży.{katalog}"
                + (
                    "\nPo utworzeniu przypniemy wybrany przelicznik cen do wskazanych rynków."
                    if any(
                        self.plany[i].ustawienia.przelicznik for i in rows if i < len(self.plany)
                    )
                    else ""
                )
                + (
                    "\nProdukty zapiszą się też w Twoim lokalnym katalogu. Producent: "
                    + self.producent_lokalny.currentText().strip()
                    if self.katalog_uzytkownika is not None
                    else ""
                ),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            == QMessageBox.StandardButton.Yes
        ):
            self.wyslij(False)

    def wyslij(self, sprawdzenie: bool) -> None:
        if not self.plany or self.nieaktualny or self.trwa:
            return
        plany = self.plany
        rows = self.zakres_wysylki()
        poprzednie = self.wyniki
        do_utworzenia = frozenset(i for i in rows if self._mozna_wyslac(i))
        lokalny = self.katalog_uzytkownika
        producent = self.producent_lokalny.currentText().strip()

        def praca() -> tuple[WynikTworzenia, ...]:
            if not sprawdzenie and lokalny is not None and do_utworzenia:
                poprawne = tuple(p for i, p in enumerate(plany) if i in do_utworzenia)
                report = lokalny.z_ofert(poprawne, producent, self.stop.is_set)
                self.lokalny_status.emit(report.tekst)
                self.katalog_zmieniony.emit()
            istniejace: dict[int, tuple[IstniejacaOferta, ...]] = {}
            if not sprawdzenie and self.kontrola_duplikatow is not None:
                nowe = tuple(
                    i
                    for i in rows
                    if i in do_utworzenia
                    and i < len(plany)
                    and not plany[i].bledy
                    and self.serwis.rejestr.odczytaj(
                        self.serwis.klucz(self.sesja, plany[i].oferta.sku)
                    )
                    is None
                )
                checks = self.kontrola_duplikatow.sprawdz(
                    self.sesja, tuple(plany[i].oferta for i in nowe)
                )
                istniejace = dict(zip(nowe, checks, strict=True))
            wynik = []
            zatrzymano = False
            powod_zatrzymania = ""
            for i, p in enumerate(plany):
                self.postep.emit(i + 1, p.oferta.sku)
                if i not in rows:
                    wynik.append(
                        poprzednie[i]
                        if i < len(poprzednie)
                        else WynikTworzenia(p.oferta.sku, "Pominięto", "Poza zakresem wysyłki.")
                    )
                elif i < len(poprzednie) and (
                    (not sprawdzenie and i not in do_utworzenia)
                    or (
                        sprawdzenie
                        and poprzednie[i].stan in {"Odrzucono", "Do poprawy"}
                        and self.serwis.rejestr.odczytaj(
                            self.serwis.klucz(self.sesja, p.oferta.sku)
                        )
                        is None
                    )
                ):
                    wynik.append(poprzednie[i])
                elif self.stop.is_set() or zatrzymano:
                    wynik.append(
                        WynikTworzenia(
                            p.oferta.sku,
                            "Wstrzymano",
                            (
                                "Nie wysłano: zmieniło się połączenie z kontem Allegro. "
                                "Otwórz paczkę ponownie."
                            )
                            if self.nieaktualny
                            else "Nie wysłano: zatrzymano serię na Twoje polecenie."
                            if self.stop.is_set()
                            else "Nie wysłano: " + powod_zatrzymania,
                        )
                    )
                elif istniejace.get(i):
                    items = istniejace[i]
                    wynik.append(
                        WynikTworzenia(
                            p.oferta.sku, "Już na Allegro", opis_duplikatow(items), items[0].ident
                        )
                    )
                elif p.bledy:
                    wynik.append(WynikTworzenia(p.oferta.sku, "Do poprawy", "; ".join(p.bledy)))
                else:
                    try:
                        w = (
                            self.serwis.sprawdz(self.sesja, p)
                            if sprawdzenie
                            else self.serwis.utworz(self.sesja, p, self.stop.is_set)
                        )
                        wynik.append(w)
                        if (
                            lokalny is not None
                            and w.ident
                            and w.stan
                            in {
                                "Utworzono szkic",
                                "Szkic kompletny",
                                "Szkic do poprawy",
                                USTAWIENIA_DO_SPRAWDZENIA,
                            }
                        ):
                            try:
                                lokalny.powiaz(
                                    p.oferta.sku,
                                    self.sesja.konto.id,
                                    self.sesja.srodowisko.value,
                                    w.ident,
                                )
                            except (BladScenariuszaKatalogu, BladTechniczny) as exc:
                                self.lokalny_status.emit(
                                    "Oferta zapisana w Allegro; powiązanie lokalne wymaga poprawy: "
                                    + str(exc)
                                )
                        zatrzymano = w.stan in {"Wynik nieznany", "Wymaga sprawdzenia"}
                        if zatrzymano:
                            powod_zatrzymania = (
                                f"poprzednia oferta {p.oferta.sku} wymaga sprawdzenia wyniku. "
                                + w.komunikat
                            )
                    except BladAllegro as exc:
                        stan = "Odrzucono" if exc.kod == "ODRZUCONO" else "Wymaga sprawdzenia"
                        ident = ""
                        try:
                            proba = self.serwis.rejestr.odczytaj(
                                self.serwis.klucz(self.sesja, p.oferta.sku)
                            )
                            if proba is not None:
                                ident = proba.ident
                        except (BladAllegro, OSError):
                            pass
                        wynik.append(WynikTworzenia(p.oferta.sku, stan, str(exc), ident))
                        zatrzymano = exc.kod in {
                            "WYGASLA",
                            "AUTORYZACJA",
                            "NIEZNANY",
                            "REJESTR",
                        } or any(f"HTTP {n}" in str(exc) for n in (401, 403, 429))
                        if zatrzymano:
                            powod_zatrzymania = f"serię zatrzymała oferta {p.oferta.sku}. {exc}"
            if not sprawdzenie:
                for i in rows:
                    if i >= len(plany) or i >= len(wynik) or not plany[i].ustawienia.przelicznik:
                        continue
                    if self.stop.is_set() or self.nieaktualny:
                        break
                    if not wynik[i].ident or wynik[i].stan not in {
                        "Utworzono szkic",
                        "Szkic kompletny",
                        "Szkic do poprawy",
                        USTAWIENIA_DO_SPRAWDZENIA,
                        "Przetwarzanie",
                    }:
                        continue
                    self.postep.emit(i + 1, "Przelicznik cen · " + plany[i].oferta.sku)
                    try:
                        wynik[i] = self.serwis.dokoncz_przelicznik(
                            self.sesja, plany[i], self.stop.is_set
                        )
                    except BladAllegro as exc:
                        wynik[i] = replace(
                            wynik[i], komunikat=wynik[i].komunikat + " Przelicznik cen: " + str(exc)
                        )
            wynik.extend(
                WynikTworzenia(
                    o.sku, "Nie sprawdzono", "Pozycja nie została sprawdzona ani wysłana."
                )
                for o in self.oferty[len(plany) :]
            )
            return tuple(wynik)

        def gotowe(w: object) -> None:
            self.wyniki = cast(tuple[WynikTworzenia, ...], w)
            if lokalny is not None:
                self.katalog_zmieniony.emit()
            self._pokaz_wyniki()
            wskazane = tuple(w for i, w in enumerate(self.wyniki) if i in rows)
            self.podsumowanie.setText(podsumuj_wysylke(wskazane))
            self.podsumowanie.show()
            self.info.setText(
                "Kliknij „Sprawdź wyniki wysyłki”, aby potwierdzić pozostałe."
                if any(
                    w.stan
                    in {
                        "Wymaga sprawdzenia",
                        "Wynik nieznany",
                        "Przetwarzanie",
                        USTAWIENIA_DO_SPRAWDZENIA,
                    }
                    for w in wskazane
                )
                else "Wyniki wysyłki zaktualizowane."
            )

        self._zadanie(
            praca, gotowe, "Sprawdzanie wyniku Allegro" if sprawdzenie else "Wysyłka Allegro"
        )

    def eksportuj(self) -> None:
        nazwa, _ = QFileDialog.getSaveFileName(
            self, "Zapisz raport", "raport-szkicow-allegro.csv", "CSV (*.csv)"
        )
        if nazwa:
            try:
                zapisz_raport(
                    Path(nazwa), self.wyniki, self.sesja.konto.login, self.sesja.srodowisko.value
                )
            except OSError:
                self.info.setText(
                    "Nie zapisano raportu. Wybierz nową nazwę; istniejące pliki nie są nadpisywane."
                )

    def reject(self) -> None:
        if self.trwa:
            self.stop.set()
            self.info.setText(
                "Zatrzymywanie serii po bieżącym żądaniu. Zaczekaj na raport przed zamknięciem."
            )
            return
        super().reject()
