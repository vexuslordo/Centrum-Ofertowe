"""Polskie etykiety kodów Allegro i kolory prezentacji; bez zmiany statusów."""

from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication

from vexlab.przypadki_uzycia.opisy_zamowien import (
    PLATNOSC as PLATNOSC,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    REALIZACJA as REALIZACJA,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    TYP_PLATNOSCI as TYP_PLATNOSCI,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    ZAKUP as ZAKUP,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    etykieta as etykieta,
)
from vexlab.przypadki_uzycia.zamowienia_allegro import stan_platnosci as stan_platnosci


def kolor(kod: str) -> QColor:
    ciemny = QApplication.palette().color(QApplication.palette().ColorRole.Base).lightness() < 128
    paleta = {
        "oplacone": ("#62D6A8", "#137448"),
        "SENT": ("#62D6A8", "#137448"),
        "PICKED_UP": ("#62D6A8", "#137448"),
        "CANCELLED": ("#FF969E", "#B42339"),
        "RETURNED": ("#FF969E", "#B42339"),
        "czesciowo": ("#F4C375", "#935600"),
        "oczekuje": ("#F4C375", "#935600"),
        "PROCESSING": ("#82BBFF", "#1766A8"),
        "NEW": ("#82BBFF", "#1766A8"),
    }
    return QColor(paleta.get(kod, ("#B6C8DF", "#435E89"))[0 if ciemny else 1])


def kolory_odznaki(kod: str, ciemny: bool) -> tuple[str, str, str]:
    """Tło, tekst i obramowanie w stonowanej palecie kart programu."""
    wariant = {
        "NEW": "zielony",
        "READY_FOR_SHIPMENT": "niebieski",
        "PROCESSING": "niebieski",
        "READY_FOR_PICKUP": "niebieski",
        "SENT": "fioletowy",
        "PICKED_UP": "fioletowy",
        "CANCELLED": "czerwony",
        "RETURNED": "czerwony",
        "SUSPENDED": "zloty",
    }.get(kod, "szary")
    paleta = {
        "zielony": (("#193B35", "#83D2B2", "#315A4D"), ("#E2F1E9", "#286349", "#B6D6C3")),
        "niebieski": (("#19334E", "#94BFE8", "#315375"), ("#E5EFF9", "#2D608D", "#BAD0E6")),
        "fioletowy": (("#30283F", "#C4A9DF", "#51405F"), ("#EEE8F5", "#685182", "#CEBFDE")),
        "czerwony": (("#3E2934", "#DDA0AD", "#64404E"), ("#F5E7EC", "#8E465D", "#DFBFCA")),
        "zloty": (("#3B3526", "#D9C28B", "#605339"), ("#F4EEDC", "#786132", "#DBCCA8")),
        "szary": (("#273343", "#B4C1D1", "#435269"), ("#EAF0F5", "#4E6077", "#C7D3DF")),
    }
    return paleta[wariant][0 if ciemny else 1]
