"""Lista zamówień w pamięci, filtry po rzeczywistych kodach i odczyt szczegółów w tle."""

from collections.abc import Callable
from pathlib import Path
from threading import Event
from typing import cast

from PySide6.QtCore import (
    QAbstractTableModel,
    QDateTime,
    QModelIndex,
    QPersistentModelIndex,
    QSize,
    Qt,
    QTimer,
    QUrl,
    Signal,
)
from PySide6.QtGui import QDesktopServices, QIcon, QPixmap, QResizeEvent
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListView,
    QMenu,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QTableView,
    QVBoxLayout,
    QWidget,
    QWidgetAction,
)

from vexlab.gui.design_system import ikona_menu
from vexlab.gui.karty_zamowien import KartaZamowienia
from vexlab.gui.miniatury_zamowien import MiniaturyZamowien
from vexlab.gui.odznaki_zamowien import OdznakaZamowienia
from vexlab.gui.panel_zamowienia import PanelZamowienia
from vexlab.gui.producenci import Uruchom
from vexlab.gui.statusy_zamowien import (
    PLATNOSC,
    REALIZACJA,
    TYP_PLATNOSCI,
    ZAKUP,
    etykieta,
    kolor,
    stan_platnosci,
)
from vexlab.gui.wiersze_zamowien import WierszZamowienia
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.powloka import sprawdz_odswiezanie_zamowien
from vexlab.przypadki_uzycia.zamowienia_allegro import (
    OdczytajZamowieniaAllegro,
    RaportZamowien,
    ZamowienieAllegro,
    obrot_zamowien,
    waluty_obrotu,
)
from vexlab.rdzen.kontrakty import BladTechniczny

Indeks = QModelIndex | QPersistentModelIndex


class ModelZamowien(QAbstractTableModel):
    def __init__(self) -> None:
        super().__init__()
        self.rows: tuple[ZamowienieAllegro, ...] = ()
        self.miniatury: dict[str, QIcon | None] = {}
        self.zaznaczone: set[str] = set()

    def ustaw(self, rows: tuple[ZamowienieAllegro, ...]) -> None:
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def rowCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else 9

    def headerData(
        self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole
    ) -> object:
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return (
                "☐",
                "Zdjęcie",
                "Produkt / Tytuł",
                "Kupujący",
                "Kwota",
                "Dostawa",
                "Status",
                "Data zakupu",
                "",
            )[section]
        return None

    def data(self, index: Indeks, role: int = Qt.ItemDataRole.DisplayRole) -> object:
        if not index.isValid() or not 0 <= index.row() < len(self.rows):
            return None
        r = self.rows[index.row()]
        if role == Qt.ItemDataRole.UserRole:
            return r
        if role == Qt.ItemDataRole.ForegroundRole and index.column() == 6:
            return kolor(r.realizacja)
        if role == Qt.ItemDataRole.CheckStateRole and index.column() == 0:
            return Qt.CheckState.Checked if r.id in self.zaznaczone else Qt.CheckState.Unchecked
        if role == Qt.ItemDataRole.DecorationRole and index.column() == 1:
            return self.miniatury.get(r.pozycje[0].oferta_id) if r.pozycje else None
        if role == Qt.ItemDataRole.ToolTipRole:
            return (
                f"{r.id}\n"
                + "\n".join(p.nazwa + " • SKU: " + p.sku for p in r.pozycje)
                + f"\nKupujący: {r.kupujacy}\nKraj: {r.kraj}\nDostawa: {r.dostawa}"
                + f"\nKwota: {r.kwota}"
                + f"\nPłatność: {PLATNOSC[stan_platnosci(r)]}"
            )
        if role == Qt.ItemDataRole.DisplayRole:
            item = r.pozycje[0] if r.pozycje else None
            product = (item.nazwa + "\nSKU: " + (item.sku or "—")) if item else "Brak pozycji"
            date = (
                QDateTime.fromString(r.kupiono, Qt.DateFormat.ISODate)
                .toLocalTime()
                .toString("dd.MM.yyyy\nHH:mm")
            )
            return (
                "",
                "",
                product,
                r.kupujacy,
                r.kwota,
                r.dostawa,
                etykieta(r.realizacja, REALIZACJA),
                date or "Brak daty",
                "⋯",
            )[index.column()]
        return None

    def flags(self, index: Indeks) -> Qt.ItemFlag:
        flags = super().flags(index)
        return flags | Qt.ItemFlag.ItemIsUserCheckable if index.column() == 0 else flags

    def setData(self, index: Indeks, value: object, role: int = Qt.ItemDataRole.EditRole) -> bool:
        if role == Qt.ItemDataRole.CheckStateRole and index.isValid() and index.column() == 0:
            ident = self.rows[index.row()].id
            if value == Qt.CheckState.Checked or value == Qt.CheckState.Checked.value:
                self.zaznaczone.add(ident)
            else:
                self.zaznaczone.discard(ident)
            self.dataChanged.emit(index, index, [role])
            return True
        return False


class StronaZamowien(QWidget):
    postep = Signal(int, int, int)
    ustawienia_zadane = Signal()
    raport_zmieniony = Signal()
    blad_odczytu = Signal(str)

    def __init__(
        self,
        uc: OdczytajZamowieniaAllegro,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
        odswiezanie_minuty: int = 10,
    ) -> None:
        super().__init__()
        self.setObjectName("zamowieniaAllegro")
        self.uc, self.uruchom, self.sesja = uc, uruchom, sesja
        sprawdz_odswiezanie_zamowien(odswiezanie_minuty)
        self._odswiezanie_minuty = odswiezanie_minuty
        self.raport: RaportZamowien | None = None
        self._sesja = sesja()
        self._nr, self._trwa = 0, False
        self._dashboard_oczekuje: int | None = None
        self._stop = Event()
        box = QVBoxLayout(self)
        box.setContentsMargins(12, 10, 12, 10)
        head = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(ikona_menu("Allegro", True).pixmap(42, 42))
        head.addWidget(logo)
        header = QVBoxLayout()
        title_row = QHBoxLayout()
        title = QLabel("Allegro – Zamówienia")
        title.setObjectName("tytulStronyAllegro")
        title_row.addWidget(title)
        subtitle = QLabel("Zamówienia na Twoim koncie")
        subtitle.setObjectName("opisAllegro")
        subtitle.setText("Zarządzaj zamówieniami z Twojego konta Allegro.")
        title_row.addStretch()
        header.addLayout(title_row)
        header.addWidget(subtitle)
        line = QHBoxLayout()
        self.konto = QLabel("Konto: —")
        self.polaczono = QLabel("Niepołączono")
        self.ostatni = QLabel("Ostatni odczyt: —")
        line.addWidget(self.konto)
        line.addWidget(self.polaczono)
        line.addStretch()
        line.addWidget(self.ostatni)
        header.addLayout(line)
        head.addLayout(header, 1)
        self.ustawienia = QPushButton("Ustawienia połączenia")
        self.ustawienia.clicked.connect(self.ustawienia_zadane.emit)
        head.addWidget(self.ustawienia)
        help_button = QPushButton("Pomoc Allegro")
        help_button.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl("https://help.allegro.com/sell/pl"))
        )
        head.addWidget(help_button)
        box.addLayout(head)
        metrics = QHBoxLayout()
        metrics.setSpacing(8)
        self.kafelki = {}
        for name, variant in (
            ("Nowe", "zielony"),
            ("Do wysyłki", "niebieski"),
            ("Wysłane", "fioletowy"),
            ("Obrót (30 dni)", "zloty"),
        ):
            card = QFrame()
            card.setObjectName("kpiAllegro")
            card.setProperty("wariantAllegro", variant)
            card_row = QHBoxLayout(card)
            card_icon = QLabel()
            icon_name = {
                "Nowe": "Szkice",
                "Do wysyłki": "Produkty",
                "Wysłane": "Zamówienia",
                "Obrót (30 dni)": "Raporty",
            }[name]
            card_icon.setPixmap(ikona_menu(icon_name, True).pixmap(30, 30))
            card_row.addWidget(card_icon)
            inner = QVBoxLayout()
            card_row.addLayout(inner, 1)
            card_row.setContentsMargins(12, 10, 12, 10)
            label = QLabel(name)
            label.setObjectName("opisAllegro")
            value = QLabel("—")
            value.setObjectName("licznikAllegro")
            desc = QLabel("W pobranym zakresie")
            desc.setObjectName("podpisAllegro")
            if name == "Obrót (30 dni)":
                heading = QHBoxLayout()
                heading.addWidget(label, 1)
                self.waluta_obrotu = QComboBox()
                self.waluta_obrotu.setAccessibleName("Waluta obrotu zamówień")
                self.waluta_obrotu.setObjectName("walutaObrotuZamowien")
                self.waluta_obrotu.setFixedWidth(76)
                self.waluta_obrotu.addItem("PLN", "PLN")
                heading.addWidget(self.waluta_obrotu)
                inner.addLayout(heading)
            else:
                inner.addWidget(label)
            inner.addWidget(value)
            inner.addWidget(desc)
            self.kafelki[name] = value
            metrics.addWidget(card, 1)
        box.addLayout(metrics)
        quick = QHBoxLayout()
        self.szybkie = {}
        for name, field, code in (
            ("Wszystkie", "", ""),
            ("Nowe", "realizacja", "NEW"),
            ("Do wysyłki", "realizacja", "READY_FOR_SHIPMENT"),
            ("Wysłane", "realizacja", "SENT"),
            ("Anulowane", "status", "CANCELLED"),
        ):
            button = QPushButton(name)
            button.setProperty("tabAllegro", True)
            button.setCheckable(True)
            button.setChecked(not field)
            button.clicked.connect(lambda checked=False, f=field, c=code: self._szybki(f, c))
            self.szybkie[name] = button
            quick.addWidget(button, 1)
        box.addLayout(quick)
        self.dni = QComboBox()
        for n in (7, 30, 90, 365):
            self.dni.addItem(f"Ostatnie {n} dni zakupu", n)
        self.dni.setCurrentIndex(1)
        self.pobierz = QPushButton("Odśwież zamówienia")
        self.pobierz.setObjectName("primary")
        self.stop = QPushButton("Przerwij pobieranie")
        self.liczniki = QLabel("Nie pobrano zamówień.")
        self.filters_grid = QGridLayout()
        self.filters_grid.setContentsMargins(0, 0, 0, 0)
        self.search_bar, self.filter_bar = QWidget(), QWidget()
        filters = QHBoxLayout(self.search_bar)
        filters.setContentsMargins(0, 0, 0, 0)
        self.filter_controls = filter_controls = QGridLayout(self.filter_bar)
        filter_controls.setContentsMargins(0, 0, 0, 0)
        self.status, self.realizacja = QComboBox(), QComboBox()
        self.status.addItem("Wszystkie statusy zamówienia", "")
        self.realizacja.addItem("Wszystkie statusy realizacji", "")
        self.platnosc = QComboBox()
        self.platnosc.addItem("Wszystkie płatności", "")
        for code, payment_label in PLATNOSC.items():
            self.platnosc.addItem(payment_label, code)
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Numer zamówienia, kupujący, SKU lub nazwa pozycji…")
        self.dostawa = QComboBox()
        self.dostawa.addItem("Wszystkie formy dostawy", "")
        self.dostawa.currentIndexChanged.connect(self.filtruj)
        self.szukaj.setPlaceholderText("Szukaj zamówienia, produktu, kupującego, SKU…")
        self.szukaj.setMaximumWidth(360)
        self.szukaj.setMinimumWidth(160)
        filters.addWidget(self.szukaj, 1)
        search = QPushButton("Szukaj")
        search.clicked.connect(self.filtruj)
        search.setFixedWidth(72)
        filters.addWidget(search)
        filters.addStretch()
        filter_controls.addWidget(self.realizacja, 0, 0)
        filter_controls.addWidget(self.dostawa, 0, 1)
        filter_controls.addWidget(self.dni, 0, 2)
        more = QPushButton("Filtry")
        more.setFixedWidth(76)
        popup = QMenu(more)
        form_widget = QWidget()
        form = QFormLayout(form_widget)
        form.addRow("Zamówienie", self.status)
        form.addRow("Płatność", self.platnosc)
        action = QWidgetAction(popup)
        action.setDefaultWidget(form_widget)
        popup.addAction(action)
        more.setMenu(popup)
        self.filtry_dodatkowe = more
        filter_controls.addWidget(more, 0, 3)
        for combo in (self.realizacja, self.dostawa, self.dni):
            combo.setMinimumContentsLength(0)
            combo.setMinimumWidth(
                208 if combo is self.realizacja else 215 if combo is self.dostawa else 190
            )
            combo.setSizeAdjustPolicy(
                QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
            )
        self.filters_grid.addWidget(self.search_bar, 0, 0)
        self.filters_grid.addWidget(self.filter_bar, 1, 0)
        self.filters_grid.setColumnStretch(0, 1)
        box.addLayout(self.filters_grid)
        actions = QHBoxLayout()
        self.pobierz.setText("Odśwież")
        self.pobierz.setObjectName("")
        for action_widget in (self.pobierz, self.stop):
            actions.addWidget(action_widget)
        self.eksport = QPushButton("Eksportuj")
        self.eksport.clicked.connect(self.eksportuj)
        actions.addWidget(self.eksport)
        print_labels = QPushButton("Drukuj etykiety ▾")
        print_labels.setEnabled(False)
        print_labels.setToolTip("Pobieranie etykiet wymaga integracji nadawania przesyłek.")
        actions.addWidget(print_labels)
        actions.addStretch()
        self.wyczysc = QPushButton("Wyczyść filtry")
        self.wyczysc.clicked.connect(self._wyczysc)
        actions.addWidget(self.wyczysc)
        box.addLayout(actions)
        split = QSplitter()
        self.model = ModelZamowien()
        self.tabela = QTableView()
        self.tabela.setObjectName("tabelaZamowienia")
        self.tabela.setShowGrid(False)
        self.tabela.setAlternatingRowColors(True)
        self.tabela.setModel(self.model)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tabela.horizontalHeader().sectionClicked.connect(self._zaznacz_wszystkie)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.verticalHeader().hide()
        self.tabela.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.tabela.setIconSize(QSize(56, 56))
        self.tabela.verticalHeader().setDefaultSectionSize(76)
        for column in (1, 2, 3, 5):
            self.tabela.setItemDelegateForColumn(column, WierszZamowienia(self.tabela))
        self.tabela.setItemDelegateForColumn(6, OdznakaZamowienia(self.tabela))
        for i, width in (
            (0, 30),
            (1, 72),
            (3, 140),
            (4, 92),
            (5, 126),
            (6, 132),
            (7, 98),
            (8, 38),
        ):
            self.tabela.setColumnWidth(i, width)
        split.addWidget(self.tabela)
        self.panel = PanelZamowienia()
        self.panel.otworz.connect(self._otworz_allegro)
        self.panel.zamknij.connect(self._zamknij_panel)
        self.detale = QPlainTextEdit(self)
        self.detale.setReadOnly(True)
        self.detale.setUndoRedoEnabled(False)
        self.detale.hide()
        self.odswiez_szczegoly = self.panel.odswiez
        right = self.panel
        split.addWidget(right)
        split.setSizes([1000, 350])
        box.addWidget(split, 1)
        self.progress = QProgressBar()
        self.progress.hide()
        box.addWidget(self.progress)
        self.info = QLabel(
            "Połącz Allegro z uprawnieniem odczytu zamówień, następnie pobierz listę."
        )
        self.info.setWordWrap(True)
        self.info.setTextFormat(Qt.TextFormat.PlainText)
        box.addWidget(self.liczniki)
        box.addWidget(self.info)
        self.pobierz.clicked.connect(lambda: self.pobierz_liste())
        self.stop.clicked.connect(lambda: self._stop.set())
        self.status.currentIndexChanged.connect(self.filtruj)
        self.realizacja.currentIndexChanged.connect(self.filtruj)
        self.szukaj.textChanged.connect(self.filtruj)
        self.platnosc.currentIndexChanged.connect(self.filtruj)
        self.tabela.selectionModel().currentRowChanged.connect(lambda *_: self._wybor())
        self.odswiez_szczegoly.clicked.connect(self.szczegoly)
        self.postep.connect(self._postep)
        self.widoki = QStackedWidget()
        self.karty = QListView()
        self.karty.setModel(self.model)
        self.karty.setModelColumn(2)
        self.karty.setSelectionModel(self.tabela.selectionModel())
        self.karty.setViewMode(QListView.ViewMode.IconMode)
        self.karty.setResizeMode(QListView.ResizeMode.Adjust)
        self.karty.setMovement(QListView.Movement.Static)
        self.karty.setGridSize(QSize(300, 160))
        self.karty.setUniformItemSizes(True)
        self.karty.setItemDelegate(KartaZamowienia(self.karty))
        self.widoki.addWidget(self.tabela)
        self.widoki.addWidget(self.karty)
        self.widok_tabela = QPushButton("▦ Tabela")
        self.widok_karty = QPushButton("▤ Karty")
        for i, button in enumerate((self.widok_tabela, self.widok_karty)):
            button.setCheckable(True)
            button.setChecked(i == 0)
            button.clicked.connect(lambda checked=False, n=i: self._widok(n))
            actions.addWidget(button)
        self.miniatury = MiniaturyZamowien(self)
        outer = QHBoxLayout()
        left = QWidget()
        left_box = QVBoxLayout(left)
        left_box.setContentsMargins(0, 0, 0, 0)
        self.panel.setParent(self)
        self.widoki.setParent(left)
        while box.count():
            entry = box.takeAt(0)
            if entry is None:
                break
            entry_widget, entry_layout = entry.widget(), entry.layout()
            if entry_widget is split:
                left_box.addWidget(self.widoki, 1)
                split.hide()
                split.deleteLater()
            elif entry_widget is not None:
                left_box.addWidget(entry_widget)
            elif entry_layout is not None:
                entry_layout.setParent(None)
                left_box.addLayout(entry_layout)
        outer.addWidget(left, 1)
        outer.addWidget(self.panel)
        box.addLayout(outer)
        self._strona = 0
        self._wynik: tuple[ZamowienieAllegro, ...] = ()
        pagebar = QHBoxLayout()
        self.zaznaczono = QLabel("Zaznaczono: 0")
        self.zakres = QLabel("Brak zamówień")
        self.poprzednia = QPushButton("Poprzednia")
        self.nastepna = QPushButton("Następna →")
        self.rozmiar = QComboBox()
        for size in (25, 50, 100):
            self.rozmiar.addItem(f"{size} na stronę", size)
        self.rozmiar.setCurrentIndex(1)
        for part in (self.zaznaczono, self.zakres, self.poprzednia, self.nastepna, self.rozmiar):
            pagebar.addWidget(part)
        self.numery_stron = []
        for i in range(5):
            number = QPushButton(str(i + 1))
            number.setCheckable(True)
            number.setFixedWidth(32)
            number.clicked.connect(lambda checked=False, b=number: self._numer_strony(b))
            pagebar.insertWidget(pagebar.count() - 2, number)
            self.numery_stron.append(number)
        left_box.addLayout(pagebar)
        self.poprzednia.clicked.connect(lambda: self._zmien_strone(-1))
        self.nastepna.clicked.connect(lambda: self._zmien_strone(1))
        self.rozmiar.currentIndexChanged.connect(self.filtruj)
        self.model.dataChanged.connect(
            lambda *_: self.zaznaczono.setText(f"Zaznaczono: {len(self.model.zaznaczone)}")
        )
        self.auto = QTimer(self)
        self.auto.setSingleShot(True)
        self.auto.timeout.connect(self._auto_odswiez)
        self.auto_opis = QLabel("Automatycznie: co 10 min")
        self.auto_opis.setObjectName("opisAllegro")
        self.auto_opis.setToolTip(
            "Odczyt w tle także w innych zakładkach. Filtry i zaznaczenie są zachowywane. "
            "Zmień w Ustawienia → Ogólne → Zamówienia Allegro."
        )
        actions.insertWidget(4, self.auto_opis)
        self.waluta_obrotu.currentIndexChanged.connect(self._stan)
        self._stan()

    def odswiez_dla_dashboardu(self, dni: int) -> None:
        self._dashboard_oczekuje = dni
        self._wznow_dashboard()

    def _wznow_dashboard(self) -> None:
        if self._trwa or self._dashboard_oczekuje is None:
            return
        dni, self._dashboard_oczekuje = self._dashboard_oczekuje, None
        self.dni.setCurrentIndex(max(0, self.dni.findData(dni)))
        self.pobierz_liste()

    def ustaw_odswiezanie(self, minuty: int) -> None:
        sprawdz_odswiezanie_zamowien(minuty)
        self._odswiezanie_minuty = minuty
        self.auto.stop()
        self._ustaw_auto()

    def _auto_dostepne(self) -> bool:
        s = self.sesja()
        return bool(
            self._odswiezanie_minuty > 0
            and s is not None
            and s.aplikacja is not None
            and s.aplikacja.odczyt_zamowien
            and self.uc.czas.teraz() < s.wygasa
        )

    def _ustaw_auto(self) -> None:
        enabled = self._auto_dostepne()
        self.auto_opis.setText(
            f"Automatycznie: co {self._odswiezanie_minuty} min"
            if enabled
            else "Odświeżanie ręczne"
            if not self._odswiezanie_minuty
            else "Auto: nieaktywne"
        )
        if not enabled:
            self.auto.stop()
        elif not self._trwa and not self.auto.isActive():
            self.auto.start(self._odswiezanie_minuty * 60_000)

    def _auto_odswiez(self) -> None:
        if not self._auto_dostepne():
            self._ustaw_auto()
            return
        if self._trwa:
            self.auto.start(5_000)
            return
        self.pobierz_liste()

    def _widok(self, index: int) -> None:
        self.widoki.setCurrentIndex(index)
        self.widok_tabela.setChecked(index == 0)
        self.widok_karty.setChecked(index == 1)
        self.miniatury.zaplanuj()

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        if hasattr(self, "panel"):
            self.panel.setFixedWidth(max(280, min(420, int(self.width() * 0.22))))
            if hasattr(self, "filters_grid"):
                narrow = self.width() - self.panel.width() < 1120
                self.filters_grid.addWidget(self.filter_bar, 1 if narrow else 0, 0 if narrow else 1)
                self.filters_grid.setColumnStretch(1, 0)
                small = self.width() - self.panel.width() < 720
                self.filter_controls.addWidget(self.dni, 1 if small else 0, 0 if small else 2)
                self.filter_controls.addWidget(
                    self.filtry_dodatkowe, 1 if small else 0, 1 if small else 3
                )

    def _stan(self) -> None:
        self._ustaw_auto()
        self.eksport.setEnabled(
            not self._trwa
            and self.raport is not None
            and bool(getattr(self, "_wynik", ()))
            and self.uc.zapis is not None
        )
        s = self.sesja()
        self.konto.setText(f"Konto: {s.konto.login}" if s else "Konto: —")
        self.polaczono.setText("● Połączono" if s else "Niepołączono")
        self.polaczono.setStyleSheet("color: #249B70" if s else "")
        for b in self.szybkie.values():
            b.setEnabled(self.raport is not None)
        rows = self.raport.pozycje if self.raport else ()
        counts = {
            "Nowe": sum(r.realizacja == "NEW" for r in rows),
            "Do wysyłki": sum(r.realizacja == "READY_FOR_SHIPMENT" for r in rows),
            "Wysłane": sum(r.realizacja == "SENT" for r in rows),
        }
        for name, label in self.kafelki.items():
            label.setText(str(counts[name]) if self.raport and name in counts else "—")
        tab_counts = {
            "Wszystkie": len(rows),
            **counts,
            "Anulowane": sum(r.status == "CANCELLED" for r in rows),
        }
        for name, button in self.szybkie.items():
            button.setText(f"{name} ({tab_counts.get(name, 0) if self.raport else '—'})")
        codes = waluty_obrotu(self.raport)
        selected_currency = str(self.waluta_obrotu.currentData() or "PLN")
        if (
            codes
            and tuple(self.waluta_obrotu.itemData(i) for i in range(self.waluta_obrotu.count()))
            != codes
        ):
            self.waluta_obrotu.blockSignals(True)
            self.waluta_obrotu.clear()
            for code in codes:
                self.waluta_obrotu.addItem(code, code)
            self.waluta_obrotu.setCurrentIndex(
                max(0, self.waluta_obrotu.findData(selected_currency))
            )
            self.waluta_obrotu.blockSignals(False)
        self.waluta_obrotu.setEnabled(bool(codes))
        turnover, tooltip = obrot_zamowien(self.raport, str(self.waluta_obrotu.currentData() or ""))
        self.kafelki["Obrót (30 dni)"].setText(turnover)
        self.kafelki["Obrót (30 dni)"].setToolTip(tooltip)
        self.pobierz.setEnabled(not self._trwa and self.sesja() is not None)
        self.dni.setEnabled(not self._trwa)
        self.stop.setVisible(self._trwa)
        self.odswiez_szczegoly.setEnabled(not self._trwa and self.tabela.currentIndex().isValid())

    def polaczenie(self) -> None:
        if self.sesja() is not self._sesja:
            self._sesja = self.sesja()
            self.auto.stop()
            self._nr += 1
            self._dashboard_oczekuje = None
            self._stop.set()
            self._trwa = False
            self.raport = None
            self._wynik = ()
            self._strona = 0
            self.model.zaznaczone.clear()
            self.miniatury.reset()
            self.ostatni.setText("Ostatni odczyt: —")
            self.szukaj.clear()
            self.model.ustaw(())
            self.detale.clear()
            self._zamknij_panel()
            self._pokaz_strone()
            self.liczniki.setText("Nie pobrano zamówień.")
            self.progress.hide()
            self.info.setText("Zmieniono połączenie. Pobierz zamówienia aktualnego konta.")
            self.raport_zmieniony.emit()
        self._stan()

    def _zadanie(self, fn: Callable[[], object], ok: Callable[[object], None]) -> None:
        self._nr += 1
        nr, s = self._nr, self.sesja()
        self._trwa = True
        self.progress.setRange(0, 0)
        self.progress.show()
        self._stan()

        def gotowe(value: object) -> None:
            if nr != self._nr or self.sesja() is not s:
                return
            self._trwa = False
            self.progress.hide()
            ok(value)
            self._stan()
            self._wznow_dashboard()

        def blad(kod: str, tekst: str) -> None:
            if nr != self._nr or self.sesja() is not s:
                return
            self._trwa = False
            self.progress.hide()
            if self.raport is None:
                self.liczniki.setText("Nie pobrano pełnej listy zamówień.")
            self.info.setText(tekst)
            if kod != "ANULOWANO":
                self.blad_odczytu.emit(tekst)
            self._stan()
            self._wznow_dashboard()

        self.uruchom(fn, gotowe, blad)

    def pobierz_liste(self) -> None:
        if self._trwa or self.sesja() is None:
            return
        self.polaczenie()
        s = self.sesja()
        if s is None:
            return
        self.auto.stop()
        self._stop = stop = Event()
        self.liczniki.setText("Odświeżanie w tle…" if self.raport else "Pobieranie…")
        nr = self._nr + 1
        dni = int(self.dni.currentData())

        def gotowe(value: object) -> None:
            filters = {
                combo: combo.currentData() for combo in (self.status, self.realizacja, self.dostawa)
            }
            page = self._strona
            selected = self.tabela.currentIndex().data(Qt.ItemDataRole.UserRole)
            self.raport = cast(RaportZamowien, value)
            self.model.zaznaczone.intersection_update(r.id for r in self.raport.pozycje)
            self.zaznaczono.setText(f"Zaznaczono: {len(self.model.zaznaczone)}")
            self.miniatury.reset()
            self.ostatni.setText(
                "Ostatni odczyt: " + self.raport.odczytano[:16].replace("T", " ") + " UTC"
            )
            for combo, attr, title in (
                (self.status, "status", "Wszystkie statusy zakupu"),
                (self.realizacja, "realizacja", "Wszystkie statusy realizacji"),
            ):
                combo.blockSignals(True)
                combo.clear()
                combo.addItem(title, "")
                labels = ZAKUP if attr == "status" else REALIZACJA
                for code in dict.fromkeys(
                    (*labels, *(getattr(r, attr) for r in self.raport.pozycje if getattr(r, attr)))
                ):
                    combo.addItem(etykieta(code, labels), code)
                combo.setCurrentIndex(max(0, combo.findData(filters[combo])))
                combo.blockSignals(False)
            self.dostawa.blockSignals(True)
            self.dostawa.clear()
            self.dostawa.addItem("Wszystkie formy dostawy", "")
            for name in sorted({r.dostawa for r in self.raport.pozycje if r.dostawa}):
                self.dostawa.addItem(name, name)
            self.dostawa.setCurrentIndex(max(0, self.dostawa.findData(filters[self.dostawa])))
            self.dostawa.blockSignals(False)
            self.filtruj()
            self._strona = page
            self._pokaz_strone()
            if isinstance(selected, ZamowienieAllegro):
                for n, row in enumerate(self.model.rows):
                    if row.id == selected.id:
                        self.tabela.selectRow(n)
                        break
            self.raport_zmieniony.emit()

        self._zadanie(
            lambda: self.uc.pobierz(
                s,
                dni,
                stop.is_set,
                lambda n, total: self.postep.emit(nr, n, total),
            ),
            gotowe,
        )

    def _postep(self, nr: int, n: int, total: int) -> None:
        if nr == self._nr and self._trwa:
            self.progress.setRange(0, max(1, total))
            self.progress.setValue(n)
            self.info.setText(f"Pobrano zamówień: {n} z {total}")

    def filtruj(self) -> None:
        if self.raport is None:
            return
        status, realizacja, text = (
            self.status.currentData(),
            self.realizacja.currentData(),
            self.szukaj.text().strip().casefold(),
        )
        rows = tuple(
            r
            for r in self.raport.pozycje
            if (not status or r.status == status)
            and (not realizacja or r.realizacja == realizacja)
            and (not self.dostawa.currentData() or r.dostawa == self.dostawa.currentData())
            and (
                not self.platnosc.currentData() or stan_platnosci(r) == self.platnosc.currentData()
            )
            and text
            in (
                r.id + " " + r.kupujacy + " " + " ".join(p.sku + " " + p.nazwa for p in r.pozycje)
            ).casefold()
        )
        self._wynik = rows
        self._strona = 0
        self._pokaz_strone()
        self.detale.clear()
        self._zamknij_panel()
        self.liczniki.setText(
            f"Widoczne: {len(rows)} z {len(self.raport.pozycje)} zamówień. Tylko odczyt."
        )
        for name, b in self.szybkie.items():
            b.setChecked(
                (name == "Wszystkie" and not status and not realizacja)
                or (name == "Nowe" and realizacja == "NEW" and not status)
                or (name == "Do wysyłki" and realizacja == "READY_FOR_SHIPMENT" and not status)
                or (name == "Wysłane" and realizacja == "SENT" and not status)
                or (name == "Anulowane" and status == "CANCELLED" and not realizacja)
            )
        self.info.setText(
            f"Allegro • {self.raport.login} • {self.raport.srodowisko} • "
            f"Zakupy UTC: {self.raport.od[:10]} – {self.raport.do[:10]} • "
            f"Odczyt UTC: {self.raport.odczytano}"
        )
        self._stan()

    def _zamknij_panel(self) -> None:
        self.tabela.setCurrentIndex(QModelIndex())
        self.tabela.clearSelection()
        self._foto_nr = getattr(self, "_foto_nr", 0) + 1
        self.panel.wyczysc()
        self.detale.clear()

    def _pokaz(self, r: ZamowienieAllegro) -> None:
        self.panel.ustaw(r)
        self._foto_nr = getattr(self, "_foto_nr", 0) + 1
        nr = self._foto_nr
        s = self.sesja()
        ident = r.pozycje[0].oferta_id if r.pozycje else ""
        icon = self.miniatury.cache.get(ident)
        if icon is not None:
            self.panel.foto.setPixmap(icon.pixmap(300, 170))
        for item in r.pozycje:
            cached = self.miniatury.cache.get(item.oferta_id)
            if cached is not None:
                self.panel.miniatura_pozycji(item.oferta_id, cached)
        if s is not None and ident and self.uc.obrazy is not None:

            def read() -> tuple[bytes, dict[str, bytes]]:
                if self.sesja() is not s or self._foto_nr != nr:
                    return b"", {}
                try:
                    photo = self.uc.zdjecie(s, ident)
                except BladTechniczny:
                    photo = b""
                others = dict.fromkeys(
                    p.oferta_id for p in r.pozycje if p.oferta_id and p.oferta_id != ident
                )
                images = {}
                for other in tuple(others)[:7]:
                    if not other or self.sesja() is not s or self._foto_nr != nr:
                        break
                    try:
                        images[other] = self.uc.miniatura(s, other)
                    except BladTechniczny:
                        continue
                return photo, images

            def show(value: object) -> None:
                if self.sesja() is s and self._foto_nr == nr:
                    photo, images = cast(tuple[bytes, dict[str, bytes]], value)
                    self.panel.zdjecie(photo)
                    for other, data in images.items():
                        pix = QPixmap()
                        if data and len(data) <= 512 * 1024 and pix.loadFromData(data):
                            self.panel.miniatura_pozycji(other, QIcon(pix))

            self.uruchom(read, show, lambda *_: None)
        self.detale.setPlainText(
            f"Allegro • konto: {self.raport.login if self.raport else ''}\n"
            f"Numer: {r.id}\n"
            f"Kupujący: {r.kupujacy}\n"
            f"Zamówienie: {etykieta(r.status, ZAKUP)}\n"
            f"Realizacja: {etykieta(r.realizacja, REALIZACJA)}\n"
            f"\n"
            f"Wartość zamówienia: {r.kwota or '—'}\n"
            f"Płatność: {PLATNOSC[stan_platnosci(r)]}\n"
            f"Sposób zapłaty: {etykieta(r.platnosc, TYP_PLATNOSCI)}\n"
            f"Zapłacono: {r.zaplacono or 'brak danych'}\n"
            f"\n"
            f"Dostawa: {r.dostawa or '—'}\n"
            f"{r.adres}\n"
            f"\n"
            f"Pozycje:\n"
            f""
            + "\n".join(
                f"{p.nazwa}\nSKU: {p.sku or '—'} • {p.ilosc} szt. • {p.cena}\n" for p in r.pozycje
            )
        )

    def _wybor(self) -> None:
        r = self.tabela.currentIndex().data(Qt.ItemDataRole.UserRole)
        if isinstance(r, ZamowienieAllegro):
            self._pokaz(r)
        self._stan()

    def szczegoly(self) -> None:
        s, r = self.sesja(), self.tabela.currentIndex().data(Qt.ItemDataRole.UserRole)
        if self._trwa or s is None or not isinstance(r, ZamowienieAllegro):
            return
        self._zadanie(
            lambda: self.uc.szczegoly(s, r.id),
            lambda value: (
                self._pokaz(cast(ZamowienieAllegro, value))
                if self.tabela.currentIndex().data(Qt.ItemDataRole.UserRole) == r
                else None
            ),
        )

    def pokaz_zamowienie(self, ident: str) -> None:
        """Nawigacja z karty Dashboardu do istniejącej listy i jej szczegółów."""
        if self.raport is None or not any(r.id == ident for r in self.raport.pozycje):
            return
        self._wyczysc()
        self.szukaj.setText(ident)
        for i, row in enumerate(self.model.rows):
            if row.id == ident:
                self.tabela.selectRow(i)
                self.tabela.scrollTo(self.model.index(i, 2))
                break

    def _wyczysc(self) -> None:
        self.szukaj.clear()
        self.platnosc.setCurrentIndex(0)
        self.dostawa.setCurrentIndex(0)
        self._szybki("", "")

    def _szybki(self, pole: str, code: str) -> None:
        self.status.blockSignals(True)
        self.realizacja.blockSignals(True)
        self.status.setCurrentIndex(max(0, self.status.findData(code if pole == "status" else "")))
        self.realizacja.setCurrentIndex(
            max(0, self.realizacja.findData(code if pole == "realizacja" else ""))
        )
        self.status.blockSignals(False)
        self.realizacja.blockSignals(False)
        self.filtruj()

    def _otworz_allegro(self) -> None:
        row = self.tabela.currentIndex().data(Qt.ItemDataRole.UserRole)
        if isinstance(row, ZamowienieAllegro):
            QDesktopServices.openUrl(QUrl("https://salescenter.allegro.com/orders"))

    def _pokaz_strone(self) -> None:
        size = int(self.rozmiar.currentData())
        max_page = max(0, (len(self._wynik) - 1) // size)
        self._strona = max(0, min(self._strona, max_page))
        start = self._strona * size
        self.model.ustaw(self._wynik[start : start + size])
        self.zakres.setText(
            f"Wyświetlane: {start + 1 if self._wynik else 0}–{min(start + size, len(self._wynik))} "
            f"z {len(self._wynik)} zamówień"
        )
        self.poprzednia.setEnabled(self._strona > 0)
        self.nastepna.setEnabled(self._strona < max_page)
        start_page = max(0, min(self._strona - 2, max_page - 4))
        for offset, button in enumerate(self.numery_stron):
            page = start_page + offset
            button.setText(str(page + 1))
            button.setVisible(page <= max_page)
            button.setChecked(page == self._strona)

    def _zaznacz_wszystkie(self, section: int) -> None:
        if section != 0:
            return
        ids = {r.id for r in self._wynik}
        if ids and ids <= self.model.zaznaczone:
            self.model.zaznaczone.difference_update(ids)
        else:
            self.model.zaznaczone.update(ids)
        if self.model.rowCount():
            self.model.dataChanged.emit(
                self.model.index(0, 0),
                self.model.index(self.model.rowCount() - 1, 0),
                [Qt.ItemDataRole.CheckStateRole],
            )

    def _numer_strony(self, button: QPushButton) -> None:
        self._zmien_strone(int(button.text()) - 1 - self._strona)

    def _zmien_strone(self, step: int) -> None:
        self._zamknij_panel()
        self._strona += step
        self._pokaz_strone()

    def eksportuj(self) -> None:
        s, report = self.sesja(), self.raport
        if self._trwa or s is None or report is None:
            return
        rows = (
            tuple(r for r in self._wynik if r.id in self.model.zaznaczone)
            if self.model.zaznaczone
            else self._wynik
        )
        path, _ = QFileDialog.getSaveFileName(
            self, "Eksportuj zamówienia", "zamowienia.csv", "CSV (*.csv)"
        )
        if not path or self.sesja() is not s or self.raport is not report:
            return
        self._zadanie(
            lambda: self.uc.eksportuj(s, report, rows, Path(path)),
            lambda n: self.info.setText(f"Zapisano {n} zamówień."),
        )
