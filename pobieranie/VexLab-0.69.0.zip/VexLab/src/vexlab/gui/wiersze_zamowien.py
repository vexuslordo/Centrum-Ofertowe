"""Prezentacja wierszy: zdjęcie, dwie linie produktu i kupującego; bez zmiany modelu."""

from PySide6.QtCore import QModelIndex, QPersistentModelIndex, QRect, QRectF, Qt
from PySide6.QtGui import QFont, QFontMetrics, QIcon, QPainter, QPainterPath, QPalette
from PySide6.QtWidgets import (
    QApplication,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionViewItem,
)

from vexlab.gui.pola_zamowienia import flaga_kraju, nazwa_kraju
from vexlab.przypadki_uzycia.zamowienia_allegro import ZamowienieAllegro


class WierszZamowienia(QStyledItemDelegate):
    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        row = index.data(Qt.ItemDataRole.UserRole)
        if not isinstance(row, ZamowienieAllegro):
            super().paint(painter, option, index)
            return
        base = QStyleOptionViewItem(option)
        self.initStyleOption(base, index)
        base.text, base.icon = "", QIcon()
        base.features &= ~(
            QStyleOptionViewItem.ViewItemFeature.HasDisplay
            | QStyleOptionViewItem.ViewItemFeature.HasDecoration
        )
        style = option.widget.style() if option.widget is not None else QApplication.style()
        if style is not None:
            style.drawControl(QStyle.ControlElement.CE_ItemViewItem, base, painter, option.widget)
        painter.save()
        painter.setClipRect(option.rect)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = option.rect.adjusted(8, 0, -8, 0)
        font = QFont(option.font)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        foreground = option.palette.color(
            QPalette.ColorRole.HighlightedText if selected else QPalette.ColorRole.Text
        )
        muted = option.palette.color(QPalette.ColorRole.PlaceholderText)
        painter.setPen(foreground)
        if index.column() == 1:
            target = QRect(0, 0, 56, 56)
            target.moveCenter(option.rect.center())
            path = QPainterPath()
            path.addRoundedRect(QRectF(target), 8, 8)
            painter.setClipPath(path, Qt.ClipOperation.IntersectClip)
            painter.fillPath(path, option.palette.brush(QPalette.ColorRole.Base))
            icon = index.data(Qt.ItemDataRole.DecorationRole)
            if isinstance(icon, QIcon):
                icon.paint(painter, target)
            else:
                painter.drawText(target, Qt.AlignmentFlag.AlignCenter, "—")
        elif index.column() == 2:
            item = row.pozycje[0] if row.pozycje else None
            font.setWeight(QFont.Weight.DemiBold)
            painter.setFont(font)
            self._line(painter, rect, -11, item.nazwa if item else "Brak pozycji", font)
            font.setWeight(QFont.Weight.Normal)
            font.setPixelSize(11)
            painter.setFont(font)
            painter.setPen(muted)
            self._line(painter, rect, 11, "SKU: " + (item.sku or "—") if item else "—", font)
        elif index.column() == 3:
            avatar = QRect(rect.left(), rect.center().y() - 15, 28, 28)
            painter.setBrush(option.palette.brush(QPalette.ColorRole.Highlight))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(avatar)
            font.setPixelSize(10)
            font.setWeight(QFont.Weight.DemiBold)
            painter.setFont(font)
            painter.setPen(foreground)
            painter.drawText(avatar, Qt.AlignmentFlag.AlignCenter, row.kupujacy[:2].upper())
            text_rect = rect.adjusted(35, 0, 0, 0)
            font = QFont(option.font)
            painter.setFont(font)
            self._line(painter, text_rect, -10, row.kupujacy, font)
            country = nazwa_kraju(row.kraj)
            if country:
                flag = flaga_kraju(row.kraj)
                painter.drawPixmap(text_rect.left(), rect.center().y() + 7, flag)
                font.setPixelSize(11)
                painter.setFont(font)
                painter.setPen(muted)
                self._line(painter, text_rect.adjusted(21, 0, 0, 0), 11, country, font)
        elif index.column() == 5:
            painter.setFont(font)
            target = QRect(rect.left(), rect.center().y() - 22, rect.width(), 44)
            painter.setClipRect(target, Qt.ClipOperation.IntersectClip)
            painter.drawText(
                target, Qt.TextFlag.TextWordWrap | Qt.AlignmentFlag.AlignVCenter, row.dostawa or "—"
            )
        painter.restore()

    @staticmethod
    def _line(painter: QPainter, rect: QRect, offset: int, text: str, font: QFont) -> None:
        line = QRect(rect.left(), rect.center().y() + offset - 10, rect.width(), 20)
        painter.drawText(
            line,
            Qt.AlignmentFlag.AlignVCenter,
            QFontMetrics(font).elidedText(text, Qt.TextElideMode.ElideRight, rect.width()),
        )
