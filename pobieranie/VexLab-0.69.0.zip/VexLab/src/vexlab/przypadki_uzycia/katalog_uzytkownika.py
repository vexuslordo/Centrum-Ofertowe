"""Dane użytkownika z ofert oraz przenośny katalog ze zdjęciami; bez SQL/Qt."""

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from uuid import UUID, uuid4

from vexlab.domena.producent import Producent
from vexlab.domena.produkt import BladKatalogu, Produkt
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.importowanie import CenaImportu
from vexlab.przypadki_uzycia.katalog import DaneDopasowania, _dopasowania
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.nowe_szkice_allegro import PlanNowegoSzkicu
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec

LIMIT = 128 * 1024 * 1024


def blad(tekst: str) -> BladScenariuszaKatalogu:
    return BladScenariuszaKatalogu("KATALOG_UZYTKOWNIKA", tekst)


@dataclass(frozen=True)
class ProduktUzytkownika:
    nazwa: str
    sku: str
    opis: str
    ean: str
    producent: str
    producent_www: str = ""
    cena: CenaImportu | None = None
    zdjecia: tuple[ZdjecieDane, ...] = ()
    dopasowania: tuple[DaneDopasowania, ...] = ()
    dostepnosc: str = "nieustalona"

    def sprawdz(self) -> None:
        try:
            Produkt(
                uuid4(),
                self.nazwa,
                self.sku,
                self.opis,
                dopasowania=_dopasowania(self.dopasowania),
                ean=self.ean,
            )
            if self.producent.strip():
                Producent(uuid4(), self.producent.strip(), strona_www=self.producent_www)
            if self.cena:
                self.cena.sprawdz()
        except (ValueError, BladKatalogu) as exc:
            raise blad(str(exc)) from exc
        if (
            len(self.zdjecia) > 5
            or len(self.nazwa) > 1000
            or len(self.sku) > 100
            or len(self.opis) > 100000
            or len(self.producent) > 200
            or len(self.producent_www) > 2048
            or self.dostepnosc not in {"nieustalona", "dostepny", "niedostepny", "wycofany"}
        ):
            raise blad("Niepoprawne dane produktu lub przekroczony limit galerii.")


@dataclass(frozen=True)
class WynikKatalogu:
    dodane: int
    istniejace: int
    kopia: Path

    @property
    def tekst(self) -> str:
        return f"Produkty lokalne: dodano {self.dodane} • istniejące {self.istniejace}."


class RepoProduktowUzytkownika(Protocol):
    def producenci_uzytkownika(self) -> tuple[str, ...]: ...
    def zapisz_uzytkownika(self, produkty: tuple[ProduktUzytkownika, ...]) -> WynikKatalogu: ...
    def odczytaj_uzytkownika(self, ids: tuple[UUID, ...]) -> tuple[ProduktUzytkownika, ...]: ...
    def powiaz_uzytkownika(self, sku: str, konto: str, env: str, ident: str) -> None: ...


class ArchiwumProduktow(Protocol):
    def zapisz(self, plik: Path, produkty: tuple[ProduktUzytkownika, ...]) -> None: ...
    def odczytaj(self, plik: Path) -> tuple[ProduktUzytkownika, ...]: ...


class KatalogUzytkownika:
    def __init__(
        self, repo: RepoProduktowUzytkownika, archiwum: ArchiwumProduktow, zdjecia: PodgladZdjec
    ) -> None:
        self.repo, self.archiwum, self.zdjecia = repo, archiwum, zdjecia

    def producenci(self) -> tuple[str, ...]:
        return self.repo.producenci_uzytkownika()

    def importuj(self, produkty: tuple[ProduktUzytkownika, ...]) -> WynikKatalogu:
        if not 1 <= len(produkty) <= 500:
            raise blad("Wybierz od 1 do 500 produktów na partię.")
        keys = set()
        size = 0
        for p in produkty:
            p.sprawdz()
            key = p.sku.casefold()
            if key in keys:
                raise blad("Powtórzone SKU w partii. Wybierz jedną pozycję każdego produktu.")
            keys.add(key)
            size += sum(len(z.dane) + len(z.miniatura) for z in p.zdjecia)
        if size > LIMIT:
            raise blad("Zdjęcia przekraczają 128 MiB. Zmniejsz partię.")
        return self.repo.zapisz_uzytkownika(produkty)

    def z_ofert(
        self, plany: tuple[PlanNowegoSzkicu, ...], producent: str, stop: Callable[[], bool]
    ) -> WynikKatalogu:
        if not producent.strip():
            raise blad("Wybierz lub wpisz producenta dla produktów lokalnych.")
        try:
            Producent(uuid4(), producent.strip())
        except BladKatalogu as exc:
            raise blad(str(exc)) from exc
        produkty: dict[str, ProduktUzytkownika] = {}
        koszt = 0
        for p in plany:
            if stop():
                raise blad("Zatrzymano. Nie zapisano katalogu ani nie wysłano nowych ofert.")
            o = p.oferta
            if p.bledy:
                continue
            key = o.sku.strip().casefold()
            if key in produkty:
                if produkty[key].ean != o.ean.strip():
                    raise blad("Jedno SKU ma różne EAN w paczce.")
                continue
            urls = tuple(
                dict.fromkeys(
                    (*o.zdjecia, *(e.adres for s in o.sekcje for e in s if e.typ == "obraz"))
                )
            )[:5]
            images = []
            for url in urls:
                if stop():
                    raise blad("Zatrzymano przed zapisem produktów lokalnych.")
                z = self.zdjecia.pobierz(url)
                koszt += len(z.dane) + len(z.miniatura)
                if koszt > LIMIT:
                    raise blad("Zdjęcia przekraczają 128 MiB. Zmniejsz partię.")
                images.append(z)
            if not images:
                raise blad(f"SKU {o.sku}: dodaj zdjęcie produktu przed wysyłką.")
            produkty[key] = ProduktUzytkownika(
                o.tytul.strip(),
                o.sku.strip(),
                o.opis,
                o.ean.strip(),
                producent.strip(),
                cena=CenaImportu(p.ustawienia.cena or o.cena, p.ustawienia.waluta, "brutto"),
                zdjecia=tuple(images),
            )
        if stop():
            raise blad("Zatrzymano przed zapisem katalogu.")
        return self.importuj(tuple(produkty.values()))

    def eksportuj(self, plik: Path, ids: tuple[UUID, ...]) -> int:
        if not 1 <= len(ids) <= 500:
            raise blad(
                "Eksportuj od 1 do 500 produktów na paczkę. Zaznacz produkty lub zawęź filtr."
            )
        produkty = self.repo.odczytaj_uzytkownika(ids)
        self.archiwum.zapisz(plik, produkty)
        return len(produkty)

    def odczytaj(self, plik: Path) -> tuple[ProduktUzytkownika, ...]:
        return self.archiwum.odczytaj(plik)

    def powiaz(self, sku: str, konto: str, env: str, ident: str) -> None:
        self.repo.powiaz_uzytkownika(sku, konto, env, ident)
