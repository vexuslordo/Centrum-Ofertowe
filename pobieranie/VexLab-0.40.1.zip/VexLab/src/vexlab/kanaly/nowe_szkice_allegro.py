"""Istniejący katalog, upload URL i tworzenie wyłącznie INACTIVE według Swagger."""

import json
import re
import time
from urllib.parse import urlencode, urlsplit
from uuid import UUID

from vexlab.kanaly.allegro import hosty, tekst
from vexlab.kanaly.zapis_szkicu_allegro import ZapisSzkicuAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro, SrodowiskoAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    ParametrSzkicu,
    ProbaTworzenia,
    ProduktSzkicu,
    adres_zdjecia,
)


class NoweSzkiceAPI(ZapisSzkicuAPI):
    def znajdz_produkty(
        self, s: SesjaAllegro, fraza: str, gtin: bool = False
    ) -> tuple[ProduktSzkicu, ...]:
        if not fraza.strip() or len(fraza) > 1024:
            raise BladAllegro("PRODUKT", "Podaj EAN lub nazwę szukanego produktu.")
        query = {"phrase": fraza}
        if gtin:
            query["mode"] = "GTIN"
        d = self._get(s.srodowisko, s.token, "/sale/products?" + urlencode(query))
        try:
            rows = d["products"]
            if not isinstance(rows, list) or len(rows) > 1000:
                raise ValueError("products")
            wynik = tuple(
                ProduktSzkicu(
                    str(UUID(tekst(p, "id"))), tekst(p, "name"), tekst(p["category"], "id")
                )
                for p in rows
            )
            if gtin and isinstance(d.get("nextPage"), dict) and d["nextPage"].get("id"):
                raise BladAllegro(
                    "PRODUKT", "Wynik katalogu ma kolejne strony. Wybierz produkt ręcznie."
                )
            return wynik
        except (KeyError, TypeError, ValueError, AttributeError):
            raise BladAllegro("ODPOWIEDZ", "Niepoprawna odpowiedź katalogu Allegro.") from None

    def produkt_szkicu(self, s: SesjaAllegro, ident: str) -> ProduktSzkicu:
        try:
            ident = str(UUID(ident))
        except ValueError:
            raise BladAllegro("PRODUKT", "Niepoprawny UUID produktu Allegro.") from None
        d = self._get(s.srodowisko, s.token, "/sale/products/" + ident)
        try:
            if tekst(d, "id") != ident:
                raise ValueError("id")
            kategoria = tekst(d["category"], "id")
            if not kategoria.isascii() or not kategoria.isdigit():
                raise ValueError("category")
            meta = self._get(s.srodowisko, s.token, "/sale/categories/" + kategoria + "/parameters")
            reqs = meta["parameters"]
            if not isinstance(reqs, list):
                raise ValueError("parameters")
            parametry = []
            for p in reqs:
                options = p.get("options") or {}
                slownik = p.get("dictionary") or []
                if not isinstance(options, dict) or not isinstance(slownik, list):
                    raise ValueError("parametry")
                parametry.append(
                    ParametrSzkicu(
                        tekst(p, "id"),
                        tekst(p, "name"),
                        tekst(p, "type"),
                        p.get("required") is True,
                        tuple((tekst(v, "id"), tekst(v, "value")) for v in slownik),
                        options.get("describesProduct") is True,
                    )
                )
            return ProduktSzkicu(ident, tekst(d, "name"), kategoria, tuple(parametry))
        except (KeyError, ValueError, TypeError, AttributeError):
            raise BladAllegro(
                "ODPOWIEDZ", "Niepoprawne dane produktu lub wymagań kategorii."
            ) from None

    def wyslij_zdjecie(self, s: SesjaAllegro, url: str) -> str:
        if not adres_zdjecia(url):
            raise BladAllegro("ZDJECIE", "Zdjęcie wymaga poprawnego adresu HTTPS.")
        host = (
            "https://upload.allegro.pl"
            if s.srodowisko == SrodowiskoAllegro.PRODUKCJA
            else "https://upload.allegro.pl.allegrosandbox.pl"
        )
        r = self.transport_zapisu.wyslij(
            "POST", host + "/sale/images", self._naglowki(s), json.dumps({"url": url}).encode()
        )
        if r.status != 201:
            raise BladAllegro(
                "ZDJECIE", f"Nie przesłano zdjęcia (HTTP {r.status}). Nie utworzono szkicu."
            )
        try:
            location = json.loads(r.dane)["location"]
            if not isinstance(location, str) or not adres_zdjecia(location):
                raise ValueError("location")
            hostname = urlsplit(location).hostname or ""
            if not any(
                hostname == d or hostname.endswith("." + d)
                for d in ("allegroimg.com", "allegroimg.allegrosandbox.pl")
            ):
                raise ValueError("host")
            return location
        except (KeyError, ValueError, TypeError, UnicodeError):
            raise BladAllegro(
                "ZDJECIE", "Brak prawidłowego adresu przesłanego zdjęcia Allegro."
            ) from None

    def utworz_szkic(self, s: SesjaAllegro, dane: dict[str, object]) -> ProbaTworzenia:
        _, host = hosty(s.srodowisko)
        try:
            r = self.transport_zapisu.wyslij(
                "POST",
                host + "/sale/product-offers",
                self._naglowki(s),
                json.dumps(dane, ensure_ascii=False).encode(),
            )
        except BladAllegro:
            raise BladAllegro(
                "NIEZNANY", "Brak odpowiedzi tworzenia. Sprawdź wynik; nie ponawiaj wysyłki."
            ) from None
        if r.status in {400, 401, 403, 422, 429}:
            opis = "Allegro odrzuciło tworzenie szkicu."
            try:
                bledy = json.loads(r.dane).get("errors", [])
                if isinstance(bledy, list):
                    opis += " " + "; ".join(
                        str(e.get("userMessage") or e.get("code") or "Błąd danych")[:500]
                        for e in bledy[:10]
                        if isinstance(e, dict)
                    )
            except (ValueError, UnicodeError, AttributeError):
                pass
            raise BladAllegro("ODRZUCONO", f"HTTP {r.status}. " + opis)
        if r.status not in {201, 202}:
            raise BladAllegro(
                "NIEZNANY", f"Nieznany wynik tworzenia (HTTP {r.status}). Nie ponawiaj."
            )
        try:
            d = json.loads(r.dane)
            ident = str(d.get("id", "")) if isinstance(d, dict) else ""
            operacja = ""
            if r.status == 202:
                u = urlsplit(r.lokalizacja)
                m = re.fullmatch(
                    r"/sale/product-offers/([0-9]{1,100})/operations/([A-Za-z0-9-]{1,100})", u.path
                )
                if (
                    not m
                    or u.scheme != "https"
                    or u.netloc != urlsplit(host).netloc
                    or u.query
                    or u.fragment
                ):
                    raise ValueError("Location")
                if ident and ident != m[1]:
                    raise ValueError("id")
                ident, operacja = m[1], m[2]
                self.odczekaj[(s.srodowisko.value, ident)] = time.monotonic() + r.odstep
            if not re.fullmatch(r"[0-9]{1,100}", ident):
                raise ValueError("id")
            return ProbaTworzenia("", "", r.status, ident, operacja)
        except (ValueError, UnicodeError, TypeError):
            raise BladAllegro(
                "NIEZNANY", "Przyjęto tworzenie, ale nie potwierdzono ID/operacji. Nie ponawiaj."
            ) from None

    def znajdz_szkic(self, s: SesjaAllegro, external: str) -> dict[str, object] | None:
        d = self._get(
            s.srodowisko,
            s.token,
            "/sale/offers?" + urlencode({"external.id": external, "limit": 2}),
        )
        rows = d.get("offers")
        total = d.get("totalCount")
        if (
            not isinstance(rows, list)
            or type(total) is not int
            or total < 0
            or len(rows) > 1
            or total > 1
        ):
            raise BladAllegro(
                "KONFLIKT", "Niejednoznaczny wynik external.id. Nie tworzono kolejnego szkicu."
            )
        if not rows:
            return None
        try:
            return self.odczytaj_szkic(s, tekst(rows[0], "id"))
        except (ValueError, TypeError):
            raise BladAllegro("ODPOWIEDZ", "Niepoprawny identyfikator wyniku tworzenia.") from None

    def odczytaj_szkic(self, s: SesjaAllegro, ident: str) -> dict[str, object]:
        return self._get(s.srodowisko, s.token, self._sciezka(ident))

    def operacja_tworzenia(self, s: SesjaAllegro, ident: str, operacja: str) -> bool:
        return self.operacja_szkicu(s, ident, operacja)
