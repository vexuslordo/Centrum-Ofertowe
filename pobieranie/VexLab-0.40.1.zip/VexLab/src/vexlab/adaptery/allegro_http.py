"""HTTPS wyłącznie do ustalonych hostów Allegro, bez przekierowań i logów treści."""

import json
import re
import time
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener

from vexlab.przypadki_uzycia.allegro import BladAllegro, OdpowiedzAllegro


class CzasSystemowy:
    def teraz(self) -> float:
        return time.monotonic()


class BezPrzekierowan(HTTPRedirectHandler):
    def redirect_request(
        self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str
    ) -> Any:
        return None


class HTTPSAllegro:
    def wyslij(
        self, metoda: str, url: str, naglowki: dict[str, str], dane: bytes | None
    ) -> OdpowiedzAllegro:
        u = urlsplit(url)
        hosty = {
            "allegro.pl",
            "api.allegro.pl",
            "upload.allegro.pl",
            "upload.allegro.pl.allegrosandbox.pl",
            "allegro.pl.allegrosandbox.pl",
            "api.allegro.pl.allegrosandbox.pl",
        }
        if (
            u.scheme != "https"
            or u.netloc not in hosty
            or u.fragment
            or metoda not in {"GET", "POST", "PATCH"}
        ):
            raise BladAllegro("ADRES", "Niedozwolony adres integracji Allegro.")
        if metoda == "POST" and u.path not in {"/auth/oauth/device", "/auth/oauth/token"}:
            try:
                pola = json.loads(dane or b"")
                if not isinstance(pola, dict) or u.query:
                    raise ValueError("pola")
                if u.netloc in {"upload.allegro.pl", "upload.allegro.pl.allegrosandbox.pl"}:
                    if (
                        u.path != "/sale/images"
                        or set(pola) != {"url"}
                        or not isinstance(pola["url"], str)
                        or not pola["url"].startswith("https://")
                    ):
                        raise ValueError("upload")
                elif u.netloc in {"api.allegro.pl", "api.allegro.pl.allegrosandbox.pl"}:
                    if u.path != "/sale/product-offers" or pola.get("publication") != {
                        "status": "INACTIVE",
                        "republish": False,
                    }:
                        raise ValueError("publication")
                    if not set(pola) <= {
                        "name",
                        "productSet",
                        "category",
                        "parameters",
                        "stock",
                        "sellingMode",
                        "images",
                        "description",
                        "external",
                        "publication",
                    }:
                        raise ValueError("pola")
                    produkty = pola.get("productSet")
                    if (
                        not isinstance(produkty, list)
                        or len(produkty) != 1
                        or set(produkty[0]) != {"product"}
                        or set(produkty[0]["product"]) != {"id"}
                    ):
                        raise ValueError("productSet")
                    from uuid import UUID

                    UUID(produkty[0]["product"]["id"])
                else:
                    raise ValueError("host")
            except (ValueError, UnicodeError, TypeError, KeyError, AttributeError):
                raise BladAllegro(
                    "POLA",
                    "Dozwolone wyłącznie zdjęcia i nowe szkice INACTIVE istniejących "
                    "produktów Allegro.",
                ) from None
        if metoda == "PATCH":
            if (
                not u.netloc.startswith("api.")
                or u.query
                or not re.fullmatch(r"/sale/product-offers/[0-9]{1,100}", u.path)
            ):
                raise BladAllegro("ADRES", "Niedozwolony zapis Allegro.")
            try:
                pola = json.loads(dane or b"")
                if (
                    not isinstance(pola, dict)
                    or not pola
                    or not set(pola) <= {"name", "description"}
                ):
                    raise ValueError("pola")
            except (ValueError, UnicodeError):
                raise BladAllegro("POLA", "Niedozwolone pola zapisu Allegro.") from None
        opener = build_opener(ProxyHandler(), HTTPSHandler(), BezPrzekierowan())
        req = Request(url, data=dane, headers=naglowki, method=metoda)
        try:
            try:
                response = opener.open(req, timeout=20)  # nosec B310: HTTPS i stała lista hostów
            except HTTPError as exc:
                response = exc
            with response:
                body = response.read(2 * 1024 * 1024 + 1)
                if len(body) > 2 * 1024 * 1024:
                    raise BladAllegro("ROZMIAR", "Odpowiedź Allegro przekracza limit rozmiaru.")
                retry = response.headers.get("Retry-After", "")
                odstep = int(retry) if re.fullmatch(r"[0-9]{1,9}", retry) else 5
                return OdpowiedzAllegro(
                    response.code, body, response.headers.get("Location", ""), odstep
                )
        except (URLError, OSError, TimeoutError):
            raise BladAllegro(
                "SIEC", "Brak odpowiedzi Allegro. Sprawdź połączenie i spróbuj ponownie."
            ) from None
