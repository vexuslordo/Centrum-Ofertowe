"""ZIP i profile użytkownika; zapis samodzielnych szkiców bez zakładania Produktów."""

from collections.abc import Callable
from pathlib import Path
from typing import cast

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.podglad_oferty import ObrazyOferty, PodgladOferty, TekstSekcji
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import FiltrHTML as FiltrHTML
from vexlab.gui.tekst_podgladu import TekstPodgladu as TekstPodgladu
from vexlab.gui.tekst_podgladu import bezpieczny_html as bezpieczny_html
from vexlab.gui.tekst_podgladu import etykieta as etykieta
from vexlab.przypadki_uzycia.paczki_ofert import (
    OfertaPodglad,
    PaczkaOfert,
    PodgladPaczek,
    ProfilPaczki,
    WynikPodgladu,
)
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.szkice import PlanSzkicow, SzkiceOfert, WynikSzkicow


class SzczegolyPaczki(QDialog):
    def __init__(
        self,
        oferta: OfertaPodglad,
        parent: QWidget,
        zdjecia: PodgladZdjec | None = None,
        uruchom: Uruchom | None = None,
    ) -> None:
        super().__init__(parent)
        self.obrazy = ObrazyOferty(self, zdjecia, uruchom)
        self.finished.connect(lambda _: self.obrazy.zamknij())
        self.setWindowTitle("Podgląd oferty z paczki")
        self.resize(880, 700)
        layout = QVBoxLayout(self)
        layout.addWidget(etykieta(f"{oferta.sku} • {oferta.tytul}"))
        layout.addWidget(
            etykieta(
                "Podgląd lokalny. Zdjęcia są pobierane w tle; "
                "ustawienia Allegro nie są jeszcze sprawdzane przez API."
            )
        )
        tabs = QTabWidget()
        self.tabs = tabs
        layout.addWidget(tabs)
        informacje = QPlainTextEdit(
            f"SKU: {oferta.sku}\nEAN (źródłowy): {oferta.ean}\n"
            f"Cena z paczki: {oferta.cena} (waluta i rodzaj nieustalone)\n"
            f"Dopasowanie źródłowe: {oferta.dopasowanie_tekst}"
            + "\n\nProblemy: "
            + ("; ".join(oferta.problemy) or "Nie wykryto w mapowanym zakresie")
        )
        informacje.setReadOnly(True)
        informacje.setMaximumHeight(170)
        dane = QWidget()
        dane_layout = QVBoxLayout(dane)
        dane_layout.addWidget(informacje)
        if oferta.zdjecia:
            galeria = PodgladOferty(self.obrazy)
            galeria.pokaz(oferta, ())
            dane_layout.addWidget(galeria, 1)
        else:
            dane_layout.addWidget(etykieta("Brak zdjęć w galerii paczki."))
        tabs.addTab(dane, "Dane i zdjęcia")
        tabs.addTab(TekstPodgladu(oferta.opis), "Opis")
        surowy = QPlainTextEdit(oferta.opis)
        surowy.setReadOnly(True)
        tabs.addTab(surowy, "Źródło opisu")
        zawartosc = QWidget()
        sekcje = QVBoxLayout(zawartosc)
        for i, elementy in enumerate(oferta.sekcje, 1):
            grupa = QGroupBox(f"Sekcja {i}")
            wiersz = QHBoxLayout(grupa)
            for element in elementy:
                if element.typ == "tekst":
                    wiersz.addWidget(TekstSekcji(element.tekst), 1)
                else:
                    wiersz.addWidget(self.obrazy.obraz(element.adres), 1)
            sekcje.addWidget(grupa)
        if not oferta.sekcje:
            sekcje.addWidget(etykieta("Nie wybrano sekcji lub rekord ich nie zawiera."))
        sekcje.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(zawartosc)
        tabs.addTab(scroll, "Układ sekcji")
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class StronaPaczek(QWidget):
    zmieniono = Signal()
    wysylka_zadana = Signal(object)
    POLA = (
        ("sku", "SKU *"),
        ("tytul", "Tytuł *"),
        ("opis", "Pełny opis HTML"),
        ("sekcje", "Układ sekcji"),
        ("zdjecia", "Galeria zdjęć"),
        ("ean", "EAN"),
        ("cena", "Cena źródłowa"),
        ("dopasowanie_tekst", "Tekst dopasowania"),
    )
    STRUKTURA = (
        ("lista_elementow", "Klucz listy elementów w sekcji"),
        ("typ_elementu", "Klucz typu elementu"),
        ("tresc_elementu", "Klucz tekstu HTML"),
        ("adres_elementu", "Klucz adresu obrazu"),
        ("typ_tekstu", "Wartość typu tekstu"),
        ("typ_obrazu", "Wartość typu obrazu"),
    )

    def __init__(
        self,
        serwis: PodgladPaczek,
        uruchom: Uruchom,
        parent: QWidget,
        szkice: SzkiceOfert | None = None,
        zdjecia: PodgladZdjec | None = None,
        allegro_dostepne: bool = False,
    ) -> None:
        super().__init__(parent)
        self.serwis, self.uruchom = serwis, uruchom
        self.zdjecia = zdjecia
        self.szkice = szkice
        self.paczka: PaczkaOfert | None = None
        self.profil_wczytany: ProfilPaczki | None = None
        self._profil_zewnetrzny = False
        self.kandydaci_profili: tuple[ProfilPaczki, ...] = ()
        self.oferty: tuple[OfertaPodglad, ...] = ()
        self.dialog: SzczegolyPaczki | None = None
        self.trwa = False
        self._generacja = 0
        self.setObjectName("strona")
        glowny = QVBoxLayout(self)
        label = etykieta("Nowe oferty — paczka ZIP")
        label.setObjectName("marka")
        glowny.addWidget(label)
        glowny.addWidget(
            etykieta(
                "Wybierz paczkę ZIP. Znany układ zostanie rozpoznany automatycznie. "
                "Paczka zapisuje szkice bez dodawania produktów do katalogu. "
                "Dane nowych szkiców Allegro można przygotować po wczytaniu paczki."
            )
        )
        self.tabs = QTabWidget()
        glowny.addWidget(self.tabs, 1)
        ustawienia = QWidget()
        layout = QVBoxLayout(ustawienia)
        pasek = QHBoxLayout()
        wybierz = QPushButton("Wybierz paczkę ZIP…")
        wybierz.setObjectName("primary")
        wybierz.clicked.connect(self.otworz)
        pasek.addWidget(wybierz, 1)
        wczytaj = QPushButton("Wczytaj profil…")
        wczytaj.clicked.connect(self.wczytaj_profil)
        pasek.addWidget(wczytaj)
        self.rozwin_konfiguracje = QPushButton("Konfiguracja zaawansowana")
        self.rozwin_konfiguracje.clicked.connect(self._konfiguruj)
        pasek.addWidget(self.rozwin_konfiguracje)
        layout.addLayout(pasek)
        self.info_profili = etykieta(
            "Gotowe układy rozpoznajemy automatycznie. Dla innych możesz wczytać własny profil."
        )
        layout.addWidget(self.info_profili)
        self.wybor_profilu = QComboBox()
        self.wybor_profilu.setAccessibleName("Wybierz jeden z profili dołączonych do paczki")
        self.wybor_profilu.currentIndexChanged.connect(self._profil_z_paczki)
        self.wybor_profilu.hide()
        layout.addWidget(self.wybor_profilu)
        self.konfiguracja = QWidget()
        konfig = QVBoxLayout(self.konfiguracja)
        self.konfiguracja.hide()
        zapisz = QPushButton("Zapisz profil jako…")
        zapisz.clicked.connect(self.zapisz_profil)
        konfig.addWidget(zapisz)
        self.nazwa = QLineEdit()
        self.nazwa.setAccessibleName("Nazwa profilu odczytu paczki")
        self.plik = QComboBox()
        self.plik.setAccessibleName("Plik danych wewnątrz ZIP")
        self.plik.currentIndexChanged.connect(self._pola)
        form = QFormLayout()
        form.addRow("Nazwa profilu użytkownika", self.nazwa)
        form.addRow("Plik danych", self.plik)
        self.mapy: dict[str, QComboBox] = {}
        for klucz, opis in self.POLA:
            box = QComboBox()
            box.setAccessibleName("Pole z paczki: " + opis)
            box.currentIndexChanged.connect(self._uniewaznij)
            self.mapy[klucz] = box
            form.addRow(opis, box)
        konfig.addLayout(form)
        zaawansowane = QGroupBox("Mapowanie struktury sekcji (jeśli wybrane)")
        struktura = QFormLayout(zaawansowane)
        self.struktura: dict[str, QLineEdit] = {}
        for klucz, opis in self.STRUKTURA:
            pole = QLineEdit()
            pole.setAccessibleName(opis)
            pole.textChanged.connect(self._uniewaznij)
            self.struktura[klucz] = pole
            struktura.addRow(opis, pole)
        rozwin = QToolButton()
        rozwin.setText("Struktura sekcji — ustawienia zaawansowane")
        rozwin.setCheckable(True)
        rozwin.setArrowType(Qt.ArrowType.RightArrow)
        rozwin.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        zaawansowane.setVisible(False)
        rozwin.toggled.connect(zaawansowane.setVisible)
        rozwin.toggled.connect(
            lambda stan: rozwin.setArrowType(
                Qt.ArrowType.DownArrow if stan else Qt.ArrowType.RightArrow
            )
        )
        konfig.addWidget(rozwin)
        konfig.addWidget(zaawansowane)
        self.przygotuj = QPushButton("Sprawdź i zapamiętaj układ")
        self.przygotuj.setObjectName("primary")
        self.przygotuj.clicked.connect(self.podglad)
        konfig.addWidget(self.przygotuj)
        self.inwentarz = QPlainTextEdit()
        self.inwentarz.setReadOnly(True)
        self.inwentarz.setMaximumHeight(140)
        konfig.addWidget(self.inwentarz)
        self.dialog_konfiguracji = QDialog(self)
        self.dialog_konfiguracji.setWindowTitle("Edytor układu — ustawienia zaawansowane")
        self.dialog_konfiguracji.resize(850, 700)
        edytor_layout = QVBoxLayout(self.dialog_konfiguracji)
        edytor_scroll = QScrollArea()
        edytor_scroll.setWidgetResizable(True)
        edytor_scroll.setWidget(self.konfiguracja)
        edytor_layout.addWidget(edytor_scroll)
        zamknij = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        zamknij.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        zamknij.rejected.connect(self.dialog_konfiguracji.reject)
        edytor_layout.addWidget(zamknij)
        zapomnij = QPushButton("Usuń zapamiętany układ tej paczki…")
        zapomnij.clicked.connect(self.zapomnij)
        konfig.addWidget(zapomnij)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(ustawienia)
        self.tabs.addTab(scroll, "Wczytaj paczkę")
        self.tabela = QTableWidget(0, 8)
        self.tabela.verticalHeader().hide()
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setHorizontalHeaderLabels(
            ["Nr", "SKU", "Tytuł", "EAN", "Cena z paczki", "Zdjęcia", "Sekcje", "Problemy"]
        )
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tabela.doubleClicked.connect(self.szczegoly)
        wynik = QWidget()
        wynik_layout = QVBoxLayout(wynik)
        otworz = QPushButton("Pokaż wybraną ofertę…")
        otworz.clicked.connect(self.szczegoly)
        wynik_layout.addWidget(otworz)
        self.zapisz_szkice = QPushButton("Zapisz oferty jako lokalne szkice…")
        self.zapisz_szkice.setObjectName("primary")
        self.zapisz_szkice.setVisible(self.szkice is not None)
        self.zapisz_szkice.setEnabled(False)
        self.zapisz_szkice.clicked.connect(self.przygotuj_szkice)
        wynik_layout.addWidget(self.zapisz_szkice)
        self.przygotuj_allegro = QPushButton("Przygotuj szkice w Allegro…")
        self.przygotuj_allegro.setEnabled(False)
        self.przygotuj_allegro.setVisible(allegro_dostepne)
        self.przygotuj_allegro.clicked.connect(lambda: self.wysylka_zadana.emit(self.oferty))
        wynik_layout.addWidget(self.przygotuj_allegro)
        wynik_layout.addWidget(etykieta("Zapis szkiców nie tworzy produktów w katalogu."))
        wynik_layout.addWidget(self.tabela)
        self.tabs.addTab(wynik, "Oferty z paczki")
        self.info = etykieta(
            "Wybierz gotową paczkę ZIP — oferty pojawią się automatycznie po sprawdzeniu."
        )
        glowny.addWidget(self.info)

    def _zadanie(self, funkcja: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self.trwa:
            return
        self.trwa = True
        self.setEnabled(False)
        self.info.setText("Odczytywanie lub sprawdzanie danych…")

        def gotowe(wynik: object) -> None:
            self.trwa = False
            self.setEnabled(True)
            sukces(wynik)

        def blad(kod: str, tekst: str) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.info.setText(tekst)

        self.uruchom(funkcja, gotowe, blad)

    def _uniewaznij(self) -> None:
        self._generacja += 1
        self.oferty = ()
        if hasattr(self, "zapisz_szkice"):
            self.zapisz_szkice.setEnabled(False)
        if hasattr(self, "przygotuj_allegro"):
            self.przygotuj_allegro.setEnabled(False)
        if hasattr(self, "tabela"):
            self.tabela.setRowCount(0)

    def otworz(self) -> None:
        nazwa, _ = QFileDialog.getOpenFileName(
            self, "Paczka gotowych ofert", "", "Archiwum ZIP (*.zip)"
        )
        if not nazwa:
            return
        self._uniewaznij()
        self.paczka = None
        self.rozwin_konfiguracje.setChecked(False)
        self.tabs.setCurrentIndex(0)
        self.wybor_profilu.hide()
        self.kandydaci_profili = ()
        self.dialog_konfiguracji.reject()
        self.info_profili.setText("Rozpoznawanie układu paczki…")
        self.plik.clear()
        self.inwentarz.clear()
        self._zadanie(lambda: self.serwis.odczytaj(Path(nazwa)), self._wczytano)

    def _wczytano(self, wynik: object) -> None:
        self.paczka = cast(PaczkaOfert, wynik)
        self.inwentarz.setPlainText(
            self.paczka.nazwa
            + "\n"
            + "\n".join(f"{p.nazwa} • {p.rozmiar} B • {p.uwaga}" for p in self.paczka.pliki)
        )
        self.plik.addItem("Wybierz plik danych", None)
        for z in self.paczka.zbiory:
            self.plik.addItem(f"{z.nazwa} ({len(z.rekordy)} rekordów)", z.nazwa)
        if self.paczka.bledy_profili:
            self.info.setText(
                "Profil w ZIP jest nieprawidłowy. Nie otwarto ofert: "
                + "; ".join(self.paczka.bledy_profili)
            )
        elif len(self.paczka.profile) == 1:
            self._profil_zewnetrzny = False
            self._automatycznie(self.paczka.profile[0].profil)
        elif len(self.paczka.profile) > 1:
            self._lista_profili(
                tuple(p.profil for p in self.paczka.profile),
                "Paczka zawiera kilka układów. Wybierz właściwy z listy.",
            )
        elif self._profil_zewnetrzny and self.profil_wczytany is not None:
            self._automatycznie(self.profil_wczytany)
        else:
            paczka = self.paczka
            self._zadanie(lambda: self.serwis.rozpoznaj(paczka), self._rozpoznano)

    def _lista_profili(self, profile: tuple[ProfilPaczki, ...], komunikat: str) -> None:
        self.kandydaci_profili = profile
        self.wybor_profilu.blockSignals(True)
        self.wybor_profilu.clear()
        self.wybor_profilu.addItem("Wybierz układ paczki", None)
        for i, p in enumerate(profile):
            self.wybor_profilu.addItem(f"{p.nazwa} ({p.plik})", i)
        self.wybor_profilu.blockSignals(False)
        self.wybor_profilu.show()
        self.info_profili.setText(komunikat)
        self.info.setText(komunikat)

    def _rozpoznano(self, wynik: object) -> None:
        profile = cast(tuple[ProfilPaczki, ...], wynik)
        if len(profile) == 1:
            self._automatycznie(profile[0])
        elif profile:
            self._lista_profili(
                profile, "Pasuje kilka układów. Wybierz właściwy plik danych — bez mapowania pól."
            )
        else:
            self.info_profili.setText(
                "Nowy układ — wczytaj profil tylko za pierwszym razem. "
                "Kolejne paczki otworzą się same."
            )
            self.info.setText(
                "Nie rozpoznano układu paczki. "
                "Wczytaj profil z pliku lub użyj jednorazowo edytora zaawansowanego."
            )

    def _profil_z_paczki(self) -> None:
        indeks = self.wybor_profilu.currentData()
        if isinstance(indeks, int) and 0 <= indeks < len(self.kandydaci_profili):
            self._profil_zewnetrzny = False
            self._automatycznie(self.kandydaci_profili[indeks])

    def _konfiguruj(self) -> None:
        self.konfiguracja.show()
        self.dialog_konfiguracji.setModal(True)
        self.dialog_konfiguracji.open()

    def zapomnij(self) -> None:
        paczka, profil = self.paczka, self.profil_wczytany
        if paczka is None or profil is None:
            self.info_profili.setText("Najpierw otwórz paczkę z rozpoznanym układem.")
            return
        if (
            QMessageBox.question(
                self.dialog_konfiguracji,
                "Usuń zapamiętany układ",
                "Usunąć ten układ z pamięci programu? Produkty i pliki ZIP pozostaną bez zmian.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        self.dialog_konfiguracji.accept()
        self._zadanie(
            lambda: self.serwis.zapomnij(paczka, profil),
            lambda wynik: self.info_profili.setText(
                "Usunięto zapamiętany układ. "
                "Następna paczka bez profilu nie zostanie nim rozpoznana."
            ),
        )

    def _wynik_z_pamieci(self, wynik: object) -> None:
        dane = cast(WynikPodgladu, wynik)
        self._profil_zewnetrzny = False
        self.info_profili.setText(dane.informacja or "Układ odczytany. Sprawdź oferty z paczki.")
        self._pokaz(dane.oferty)

    def _automatycznie(self, profil: ProfilPaczki) -> None:
        self._ustaw_profil(profil)
        paczka = self.paczka
        if paczka is not None:
            self._zadanie(
                lambda: self.serwis.podglad_z_pamiecia(paczka, profil), self._wynik_z_pamieci
            )

    def _pola(self) -> None:
        nazwy: tuple[str, ...] = ()
        if self.paczka:
            zbior = next(
                (z for z in self.paczka.zbiory if z.nazwa == self.plik.currentData()), None
            )
            if zbior:
                nazwy = zbior.pola
        for box in self.mapy.values():
            box.blockSignals(True)
            box.clear()
            box.addItem("Nie wybrano / pomiń", "")
            for nazwa in nazwy:
                box.addItem(nazwa, nazwa)
            box.blockSignals(False)
        self._uniewaznij()

    def profil(self) -> ProfilPaczki:
        return ProfilPaczki(
            self.nazwa.text().strip(),
            str(self.plik.currentData() or ""),
            **{k: str(b.currentData() or "") for k, b in self.mapy.items()},
            **{k: b.text() for k, b in self.struktura.items()},
        )

    def wczytaj_profil(self) -> None:
        nazwa, _ = QFileDialog.getOpenFileName(
            self, "Profil użytkownika", "", "Profil JSON (*.json)"
        )
        if nazwa:
            self._zadanie(
                lambda: self.serwis.wczytaj_profil(Path(nazwa)),
                self._profil_z_pliku,
            )

    def _profil_z_pliku(self, wynik: object) -> None:
        self._profil_zewnetrzny = True
        self._automatycznie(cast(ProfilPaczki, wynik))

    def _ustaw_profil(self, profil: ProfilPaczki) -> None:
        self.profil_wczytany = profil
        self.nazwa.setText(profil.nazwa)
        if self.paczka is None:
            self.info.setText("Profil wczytany. Wybierz paczkę ZIP, aby zastosować mapowanie.")
            return
        self.plik.setCurrentIndex(self.plik.findData(profil.plik))
        self._pola()
        brak = self.plik.currentIndex() < 0
        for k, box in self.mapy.items():
            value = getattr(profil, k)
            index = box.findData(value)
            brak |= index < 0
            box.setCurrentIndex(index)
        for k, pole_struktury in self.struktura.items():
            pole_struktury.setText(getattr(profil, k))
        self.info.setText(
            "Profil nie pasuje do plików/pól tej paczki. Popraw mapowanie."
            if brak
            else "Profil wczytany. Sprawdź mapowanie i przygotuj podgląd."
        )

    def zapisz_profil(self) -> None:
        profil = self.profil()
        nazwa, _ = QFileDialog.getSaveFileName(
            self, "Zapisz profil pod nową nazwą", "", "Profil JSON (*.json)"
        )
        if nazwa:
            self._zadanie(
                lambda: self.serwis.zapisz_profil(Path(nazwa), profil),
                lambda wynik: self.info.setText(
                    "Profil zapisany. Możesz użyć go przy następnej paczce."
                ),
            )

    def podglad(self) -> None:
        if self.paczka is None:
            self.info.setText("Najpierw wybierz paczkę ZIP.")
            return
        paczka, profil = self.paczka, self.profil()
        self.dialog_konfiguracji.accept()
        self._uniewaznij()
        self._zadanie(lambda: self.serwis.podglad_z_pamiecia(paczka, profil), self._wynik_z_pamieci)

    def _pokaz(self, wynik: object) -> None:
        self.oferty = cast(tuple[OfertaPodglad, ...], wynik)
        self.tabela.setRowCount(len(self.oferty))
        self._partia(0, self._generacja)

    def _partia(self, start: int, numer: int) -> None:
        if numer != self._generacja:
            return
        for i in range(start, min(start + 100, len(self.oferty))):
            p = self.oferty[i]
            for j, value in enumerate(
                (
                    str(p.numer),
                    p.sku,
                    p.tytul,
                    p.ean,
                    p.cena,
                    str(len(p.zdjecia)),
                    str(len(p.sekcje)),
                    "; ".join(p.problemy),
                )
            ):
                self.tabela.setItem(i, j, QTableWidgetItem(value))
        if start + 100 < len(self.oferty):
            QTimer.singleShot(0, lambda: self._partia(start + 100, numer))
            return
        self.tabela.resizeColumnsToContents()
        self.tabela.setColumnWidth(2, 350)
        self.tabs.setCurrentIndex(1)
        self.info.setText(
            f"Podgląd: {len(self.oferty)} ofert, "
            f"{sum(bool(p.problemy) for p in self.oferty)} z problemami. "
            "Dwuklik — szczegóły i układ sekcji. Przygotowanie szkiców Allegro jest osobną akcją."
        )

        self.zapisz_szkice.setEnabled(bool(self.oferty))
        self.przygotuj_allegro.setEnabled(bool(self.oferty))

    def przygotuj_szkice(self) -> None:
        if self.szkice is None or self.paczka is None or not self.oferty:
            return
        serwis, oferty, zrodlo = self.szkice, self.oferty, self.paczka.nazwa
        self._zadanie(lambda: serwis.zaplanuj(oferty, zrodlo), self._plan_szkicow)

    def _plan_szkicow(self, wynik: object) -> None:
        plan = cast(PlanSzkicow, wynik)
        if not plan.pozycje:
            self.info.setText("Brak prawidłowych ofert. " + "; ".join(plan.bledy[:5]))
            return
        komunikat = (
            f"Zapisać {len(plan.pozycje)} ofert jako szkice lokalne?\n"
            f"Błędne wiersze pomijane: {len(plan.bledy)}.\n"
            "Identyczne zapisane oferty zostaną pominięte. Zmienione oferty "
            "utworzą osobne szkice. Nie utworzymy produktów w katalogu.\n"
            "Nie wysyła to ofert do Allegro. Powstanie kopia bazy."
        )
        if plan.bledy:
            komunikat += "\n\n" + "\n".join(plan.bledy[:5])
        if (
            QMessageBox.question(
                self,
                "Zapis lokalnych szkiców",
                komunikat,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        if self.szkice is not None:
            serwis = self.szkice
            self._zadanie(lambda: serwis.zapisz(plan), self._zapisano_szkice)

    def _zapisano_szkice(self, wynik: object) -> None:
        w = cast(WynikSzkicow, wynik)
        self.info.setText(
            f"Zapisane szkice: {w.zapisane}, identyczne pominięte: {w.pominiete}, "
            f"Otwórz Szkice. Kopia: {w.kopia}"
        )
        self.zmieniono.emit()

    def szczegoly(self) -> None:
        i = self.tabela.currentRow()
        if not 0 <= i < len(self.oferty):
            self.info.setText("Wybierz ofertę z listy.")
            return
        dialog = SzczegolyPaczki(self.oferty[i], self, self.zdjecia, self.uruchom)
        self.dialog = dialog
        dialog.setModal(True)
        dialog.finished.connect(lambda: self._zamknieto(dialog))
        dialog.open()

    def _zamknieto(self, dialog: SzczegolyPaczki) -> None:
        self.dialog = None
        dialog.deleteLater()
