"""Połączenie i odczyt kategorii PrestaShop, bez zapisów do sklepu."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import (
    QAbstractTableModel,
    QModelIndex,
    QPersistentModelIndex,
    QSortFilterProxyModel,
    Qt,
    Signal,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta as etykieta_bazowa
from vexlab.przypadki_uzycia.prestashop import (
    BladPresta,
    KategoriaPresta,
    KonfiguracjaPresta,
    PolaczPresta,
    SlownikiPresta,
)

Indeks = QModelIndex | QPersistentModelIndex


def etykieta(tekst: str, styl: str = "", zawijaj: bool = False) -> QLabel:
    label = etykieta_bazowa(tekst)
    label.setObjectName(styl)
    label.setWordWrap(zawijaj)
    return label


class ModelKategorii(QAbstractTableModel):
    def __init__(self) -> None:
        super().__init__()
        self.pozycje: tuple[KategoriaPresta, ...] = ()

    def ustaw(self, pozycje: tuple[KategoriaPresta, ...]) -> None:
        self.beginResetModel()
        self.pozycje = pozycje
        self.endResetModel()

    def rowCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else len(self.pozycje)

    def columnCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else 4

    def data(self, index: Indeks, role: int = Qt.ItemDataRole.DisplayRole) -> object:
        if not index.isValid() or not 0 <= index.row() < len(self.pozycje):
            return None
        k = self.pozycje[index.row()]
        if role == Qt.ItemDataRole.UserRole:
            return k
        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.ToolTipRole):
            return (k.id, k.nazwa, k.rodzic, "Aktywna" if k.aktywna else "Nieaktywna")[
                index.column()
            ]
        return None

    def headerData(
        self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole
    ) -> object:
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return ("ID", "Kategoria sklepu", "ID nadrzędnej", "Status")[section]
        return None


class StronaPresta(QWidget):
    stan = Signal(str)

    def __init__(self, serwis: PolaczPresta, uruchom: Uruchom) -> None:
        super().__init__()
        self.serwis, self.uruchom = serwis, uruchom
        self._trwa = False
        self._sprawdzone: KonfiguracjaPresta | None = None
        self._pamiec: KonfiguracjaPresta | None = None
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 18, 24, 18)
        layout.addWidget(etykieta("PrestaShop", "tytulStronyAllegro"))
        layout.addWidget(
            etykieta("Połączenie Webservice 1.6.1.24 · odczyt kategorii sklepu", "opis")
        )
        form = QFormLayout()
        self.adres = QLineEdit()
        self.adres.setPlaceholderText("https://adres-twojego-sklepu.pl/")
        self.adres.setAccessibleName("Adres HTTPS sklepu PrestaShop")
        self.klucz = QLineEdit()
        self.klucz.setEchoMode(QLineEdit.EchoMode.Password)
        self.klucz.setAccessibleName("Klucz Webservice PrestaShop")
        self.klucz.setMaxLength(32)
        form.addRow("Adres sklepu", self.adres)
        form.addRow("Klucz Webservice", self.klucz)
        layout.addLayout(form)
        layout.addWidget(
            etykieta(
                "W panelu PrestaShop: Zaawansowane → Webservice. Włącz API i nadaj kluczowi "
                "uprawnienia GET do shops, languages i categories.",
                "opis",
                True,
            )
        )
        actions = QHBoxLayout()
        self.polacz = QPushButton("Sprawdź połączenie")
        self.polacz.setObjectName("primary")
        self.zapisz = QPushButton("Zapamiętaj połączenie i wybór")
        self.usun = QPushButton("Usuń zapamiętane połączenie")
        for b in (self.polacz, self.zapisz, self.usun):
            actions.addWidget(b)
        layout.addLayout(actions)
        self.status = etykieta(
            "Podaj adres sklepu i klucz Webservice. Nie używaj adresu panelu administratora.",
            "opis",
            True,
        )
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.status)
        wybory = QHBoxLayout()
        self.sklep, self.jezyk = QComboBox(), QComboBox()
        self.sklep.setAccessibleName("Docelowy sklep PrestaShop")
        self.jezyk.setAccessibleName("Język kategorii PrestaShop")
        self.sklep.addItem("Wybierz sklep", "")
        self.jezyk.addItem("Wybierz język", "")
        self.pobierz = QPushButton("Pobierz kategorie")
        for w in (self.sklep, self.jezyk, self.pobierz):
            wybory.addWidget(w)
        layout.addLayout(wybory)
        self.filtr = QLineEdit()
        self.filtr.setPlaceholderText("Szukaj kategorii po nazwie lub ID…")
        self.filtr.setAccessibleName("Szukaj kategorii PrestaShop")
        layout.addWidget(self.filtr)
        self.model = ModelKategorii()
        self.proxy = QSortFilterProxyModel(self)
        self.proxy.setSourceModel(self.model)
        self.proxy.setFilterKeyColumn(-1)
        self.proxy.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.tabela = QTableView()
        self.tabela.setModel(self.proxy)
        self.tabela.setAccessibleName("Kategorie wybranego sklepu i języka PrestaShop")
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.tabela.setColumnWidth(0, 80)
        self.tabela.setColumnWidth(2, 150)
        self.tabela.setColumnWidth(3, 115)
        self.tabela.verticalHeader().hide()
        self.tabela.setMinimumHeight(220)
        layout.addWidget(self.tabela, 1)
        self.wybrana = etykieta("Nie wybrano kategorii docelowej.", "opis", True)
        self.wybrana.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.wybrana)
        self.postep = QProgressBar()
        self.postep.setRange(0, 0)
        self.postep.hide()
        layout.addWidget(self.postep)
        layout.addWidget(
            etykieta(
                "Ten etap pobiera ustawienia. Produkty i kategorie w sklepie pozostają bez zmian.",
                "opis",
                True,
            )
        )
        self.polacz.clicked.connect(self.sprawdz)
        self.pobierz.clicked.connect(self.pobierz_kategorie)
        self.zapisz.clicked.connect(self.zapamietaj)
        self.usun.clicked.connect(self.usun_polaczenie)
        self.adres.textChanged.connect(self._uniewaznij)
        self.klucz.textChanged.connect(self._uniewaznij)
        self.sklep.currentIndexChanged.connect(self._wybor_kontekstu)
        self.jezyk.currentIndexChanged.connect(self._wybor_kontekstu)
        self.filtr.textChanged.connect(self.proxy.setFilterFixedString)
        self.tabela.selectionModel().currentRowChanged.connect(lambda *_: self._wybor_kategorii())
        self._przyciski()

    def _przyciski(self) -> None:
        for w in (self.adres, self.klucz, self.polacz, self.sklep, self.jezyk, self.tabela):
            w.setEnabled(not self._trwa)
        self.pobierz.setEnabled(
            not self._trwa
            and self._sprawdzone is not None
            and bool(self.sklep.currentData())
            and bool(self.jezyk.currentData())
        )
        self.zapisz.setEnabled(
            not self._trwa and self._sprawdzone is not None and self.serwis.magazyn is not None
        )
        self.usun.setEnabled(not self._trwa and self.serwis.magazyn is not None)
        if self.serwis.magazyn is None:
            self.zapisz.setToolTip("Bezpieczne zapamiętywanie klucza wymaga Windows.")

    def _uniewaznij(self) -> None:
        self._sprawdzone = None
        self.sklep.clear()
        self.jezyk.clear()
        self.model.ustaw(())
        self.wybrana.setText("Nie wybrano kategorii docelowej.")
        self.stan.emit("Nie sprawdzono")
        self._przyciski()

    def _wybor_kontekstu(self) -> None:
        self.model.ustaw(())
        self.wybrana.setText("Nie wybrano kategorii docelowej.")
        self._przyciski()

    def _konfiguracja(self) -> KonfiguracjaPresta:
        return KonfiguracjaPresta(
            self.adres.text(),
            self.klucz.text(),
            self.sklep.currentData() or "",
            self.jezyk.currentData() or "",
            self._kategoria(),
        ).sprawdz()

    def _kategoria(self) -> str:
        index = self.tabela.currentIndex()
        item = self.proxy.data(index, Qt.ItemDataRole.UserRole)
        return item.id if isinstance(item, KategoriaPresta) and item.aktywna else ""

    def _wybor_kategorii(self) -> None:
        item = self.proxy.data(self.tabela.currentIndex(), Qt.ItemDataRole.UserRole)
        if isinstance(item, KategoriaPresta):
            self.wybrana.setText(
                f"Wybrana kategoria: {item.nazwa} · ID {item.id}"
                if item.aktywna
                else "Kategoria nieaktywna — wybierz aktywną kategorię."
            )

        else:
            self.wybrana.setText("Nie wybrano kategorii docelowej.")

    def _zadanie(self, funkcja: Callable[[], object], sukces: Callable[[object], None]) -> None:
        self._trwa = True
        self.postep.show()
        self._przyciski()

        def ok(w: object) -> None:
            self._trwa = False
            self.postep.hide()
            sukces(w)
            self._przyciski()

        def blad(_kod: str, tekst: str) -> None:
            self._trwa = False
            self.postep.hide()
            self.status.setText(tekst)
            self.stan.emit("Błąd odczytu")
            self._przyciski()

        self.uruchom(funkcja, ok, blad)

    def sprawdz(self) -> None:
        if self._trwa:
            return
        try:
            k = self._konfiguracja()
        except BladPresta as e:
            self.status.setText(str(e))
            return
        pamiec = (
            self._pamiec
            if self._pamiec and (self._pamiec.adres, self._pamiec.klucz) == (k.adres, k.klucz)
            else None
        )
        self._sprawdzone = None
        self.model.ustaw(())
        self.status.setText("Sprawdzanie połączenia i uprawnień…")

        def ok(w: object) -> None:
            dane = cast(SlownikiPresta, w)
            for combo, rows, tytul, ident in (
                (
                    self.sklep,
                    dane.sklepy,
                    "Wybierz sklep",
                    k.sklep or (pamiec.sklep if pamiec else ""),
                ),
                (
                    self.jezyk,
                    dane.jezyki,
                    "Wybierz język",
                    k.jezyk or (pamiec.jezyk if pamiec else ""),
                ),
            ):
                combo.clear()
                combo.addItem(tytul, "")
                for row in rows:
                    if row.aktywna:
                        combo.addItem(row.nazwa, row.id)
                selected = combo.findData(ident)
                combo.setCurrentIndex(selected if selected > 0 else 1 if combo.count() == 2 else 0)
            self._sprawdzone = k
            self.status.setText("Połączono. Wybierz sklep i język, a następnie pobierz kategorie.")
            self.stan.emit("Połączono — odczyt")

        self._zadanie(lambda: self.serwis.sprawdz(k), ok)

    def pobierz_kategorie(self) -> None:
        if self._trwa or self._sprawdzone is None:
            return
        k = self._konfiguracja()
        self.model.ustaw(())
        self.status.setText("Pobieranie kategorii wybranego sklepu i języka…")

        def ok(w: object) -> None:
            dane = cast(tuple[KategoriaPresta, ...], w)
            self.model.ustaw(dane)
            self.status.setText(f"Pobrano kategorii: {len(dane)}. Wybierz kategorię docelową.")
            if self._pamiec and (k.adres, k.sklep, k.jezyk) == (
                self._pamiec.adres,
                self._pamiec.sklep,
                self._pamiec.jezyk,
            ):
                for i, item in enumerate(dane):
                    if item.id == self._pamiec.kategoria and item.aktywna:
                        self.tabela.setCurrentIndex(
                            self.proxy.mapFromSource(self.model.index(i, 0))
                        )
                        break
            self.stan.emit("Połączono — odczyt")

        self._zadanie(lambda: self.serwis.kategorie(k), ok)

    def zapamietaj(self) -> None:
        if self._trwa or self._sprawdzone is None:
            return
        k = self._konfiguracja()

        def ok(_w: object) -> None:
            self._pamiec = k
            self.status.setText(
                "Zapamiętano połączenie i wybór w danych Twojego użytkownika Windows."
            )

        self._zadanie(lambda: self.serwis.zapamietaj(k), ok)

    def przywroc(self) -> None:
        def ok(w: object) -> None:
            k = cast(KonfiguracjaPresta | None, w)
            if k:
                self._uniewaznij()
                self.adres.setText(k.adres)
                self.klucz.setText(k.klucz)
                self._pamiec = k
                self.status.setText(
                    "Wczytano zapamiętane ustawienia. Kliknij „Sprawdź połączenie”."
                )

        self._zadanie(self.serwis.przywroc, ok)

    def usun_polaczenie(self) -> None:
        if self._trwa:
            return

        def ok(_w: object) -> None:
            self._pamiec = None
            self.adres.clear()
            self.klucz.clear()
            self.status.setText("Usunięto zapamiętane połączenie PrestaShop.")
            self.stan.emit("Niepołączono")

        self._zadanie(self.serwis.usun, ok)
