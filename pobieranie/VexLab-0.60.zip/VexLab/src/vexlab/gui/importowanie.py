"""Kreator mapowania i trwała lista korekt. Wyłącznie DTO i porty scenariuszy."""

from collections import Counter
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from typing import cast
from uuid import UUID

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.katalog import FormularzProduktu, SzczegolyProduktu, nazwa_wyboru_producenta
from vexlab.gui.producenci import Uruchom
from vexlab.gui.profile_cennikow import PanelProfiliCennikow
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.ceny_cennika import etykieta_cennika
from vexlab.przypadki_uzycia.importowanie import (
    CenaImportu,
    ImportujProdukty,
    Mapowanie,
    MapowanieCeny,
    MapowanieMotocykla,
    OcenaPozycji,
    PlanUzupelnieniaCen,
    PlikImportu,
    PozycjaImportu,
    WynikImportu,
)
from vexlab.przypadki_uzycia.katalog import CenaSugerowanaDTO, KatalogProduktow, ProduktDTO
from vexlab.przypadki_uzycia.producenci import ProducentDTO, RejestrProducentow
from vexlab.przypadki_uzycia.profile_cennikow import DopasowanieCennika, ProfileCennikow


def tabela(naglowki: list[str]) -> QTableWidget:
    w = QTableWidget(0, len(naglowki))
    w.setHorizontalHeaderLabels(naglowki)
    w.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    w.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    w.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    w.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    w.horizontalHeader().setStretchLastSection(True)
    return w


class DialogPotwierdzenia(QDialog):
    trwa: bool = False

    def reject(self) -> None:
        if not self.trwa:
            super().reject()

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.trwa:
            event.ignore()
        else:
            super().closeEvent(event)


class StronaImportu(QWidget):
    zmieniono = Signal()
    plan_zmieniony = Signal()
    plik_zmieniony = Signal()

    def __init__(
        self,
        serwis: ImportujProdukty,
        producenci: RejestrProducentow,
        katalog: KatalogProduktow,
        uruchom: Uruchom,
        parent: QWidget,
        profile: ProfileCennikow | None = None,
    ) -> None:
        super().__init__(parent)
        self.profile = profile
        self.panel_profili: PanelProfiliCennikow | None = None
        self.serwis = serwis
        self.producenci = producenci
        self.katalog = katalog
        self.uruchom = uruchom
        self.plik: PlikImportu | None = None
        self.oceny: tuple[OcenaPozycji, ...] = ()
        self.pozycje: tuple[PozycjaImportu, ...] = ()
        self._trwa = False
        self.dialog: FormularzProduktu | None = None
        self.podglad_dialog: SzczegolyProduktu | None = None
        self.setObjectName("strona")
        layout = QVBoxLayout(self)
        tytul = QLabel("Import produktów z cennika")
        self.tytul = tytul
        tytul.setObjectName("marka")
        layout.addWidget(tytul)
        opis = QLabel(
            "XLSX / CSV UTF-8 • nazwa, SKU, opis i producent. "
            "Cena sugerowana w wybranej walucie • opcjonalne dopasowania motocykli "
            "• opcjonalny EAN."
        )
        opis.setWordWrap(True)
        layout.addWidget(opis)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self.info = QLabel("Wybierz plik. Nic nie zostanie zapisane przed zatwierdzeniem.")
        self.info.setTextFormat(Qt.TextFormat.PlainText)
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        self.raport = QLabel("")
        self.raport.setTextFormat(Qt.TextFormat.PlainText)
        self.raport.setWordWrap(True)
        layout.addWidget(self.raport)
        self._buduj_import()
        self._buduj_korekty()

    def _buduj_import(self) -> None:
        strona = QWidget()
        layout = QVBoxLayout(strona)
        self.wybierz = QPushButton("Wybierz plik…")
        self.wybierz.clicked.connect(self.wybierz_plik)
        layout.addWidget(self.wybierz)
        self.nazwa_pliku = QLabel("Brak pliku")
        self.nazwa_pliku.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.nazwa_pliku)
        self.ustawienia_importu = QWidget()
        ustawienia_layout = QVBoxLayout(self.ustawienia_importu)
        ustawienia_layout.setContentsMargins(0, 0, 0, 0)
        if self.profile is not None:
            self.panel_profili = PanelProfiliCennikow(self, self.profile)
            layout.addWidget(self.panel_profili)
        form = QFormLayout()
        self.arkusz = QComboBox()
        self.arkusz.setAccessibleName("Arkusz importu")
        self.arkusz.currentIndexChanged.connect(self._arkusz)
        form.addRow("Arkusz", self.arkusz)
        self.naglowek = QSpinBox()
        self.naglowek.setRange(1, 20000)
        self.naglowek.setAccessibleName("Numer wiersza nagłówków")
        self.naglowek.valueChanged.connect(self._kolumny)
        form.addRow("Wiersz nagłówków", self.naglowek)
        self.kol_nazwa = QComboBox()
        self.kol_sku = QComboBox()
        self.kol_ean = QComboBox()
        self.kol_opis = QComboBox()
        self.kol_dodatkowy_opis = QComboBox()
        self.kol_cena = QComboBox()
        for label, widget in [
            ("Nazwa *", self.kol_nazwa),
            ("SKU *", self.kol_sku),
            ("EAN (opcjonalnie)", self.kol_ean),
            ("Opis źródłowy", self.kol_opis),
            ("Dodatkowe dane do opisu", self.kol_dodatkowy_opis),
            ("Cena sugerowana (opcjonalnie)", self.kol_cena),
        ]:
            widget.setAccessibleName("Kolumna: " + label)
            widget.currentIndexChanged.connect(self._uniewaznij)
            form.addRow(label, widget)
        self.dolacz_nazwe = QCheckBox("Dołącz pełną nazwę z pliku do opisu")
        self.dolacz_nazwe.setToolTip(
            "Zachowuje tekst nazwy wraz z motocyklem, modelem i rocznikami, "
            "jeśli podano je w pliku. "
            "Nie odgaduje dopasowania ani nie tłumaczy tekstu."
        )
        self.dolacz_nazwe.toggled.connect(self._uniewaznij)
        form.addRow("Dane źródłowe", self.dolacz_nazwe)
        self.waluta = QComboBox()
        self.waluta.addItems(
            ["Wybierz walutę", "PLN", "EUR", "GBP", "USD", "CHF", "CZK", "SEK", "NOK", "DKK"]
        )
        self.waluta.setAccessibleName("Waluta ceny sugerowanej")
        self.rodzaj_ceny = QComboBox()
        self.rodzaj_ceny.addItems(["Wybierz netto/brutto", "netto", "brutto"])
        self.rodzaj_ceny.setAccessibleName("Cena sugerowana netto czy brutto")
        form.addRow("Waluta źródłowa", self.waluta)
        form.addRow("Rodzaj kwoty", self.rodzaj_ceny)
        self.formuly_cen = QCheckBox("Użyj zapisanych wyników formuł ceny (mogą być nieaktualne)")
        self.formuly_cen.setToolTip(
            "Nie przeliczamy Excela. Wybierz tylko po sprawdzeniu wartości w pliku."
        )
        form.addRow("Formuły ceny", self.formuly_cen)
        self.pelne_brutto = QCheckBox("Brutto bez groszy · VAT 23% · pokaż netto")
        self.pelne_brutto.setChecked(True)
        self.pelne_brutto.setToolTip(
            "Netto źródłowe × 1,23. Brutto zaokrąglamy matematycznie do pełnej "
            "jednostki, a netto obliczamy z zaokrąglonego brutto."
        )
        form.addRow("Ceny cennika", self.pelne_brutto)
        self.pelne_brutto.toggled.connect(self._uniewaznij)
        self.waluta.currentIndexChanged.connect(self._uniewaznij)
        self.rodzaj_ceny.currentIndexChanged.connect(self._uniewaznij)
        self.formuly_cen.toggled.connect(self._uniewaznij)
        self.producent = QComboBox()
        self.producent.setAccessibleName("Producent dla paczki")
        self.producent.currentIndexChanged.connect(self._uniewaznij)
        if self.panel_profili is None:
            form.addRow("Producent paczki", self.producent)
        else:
            producent_form = QFormLayout()
            producent_form.addRow("Producent", self.producent)
            layout.addLayout(producent_form)
        ustawienia_layout.addLayout(form)
        self.moto_grupa = QGroupBox("Importuj dopasowanie do motocykla (opcjonalne)")
        self.moto_grupa.setCheckable(True)
        self.moto_grupa.setChecked(False)
        self.moto_pola = QWidget()
        moto_form = QFormLayout(self.moto_pola)
        moto_layout = QVBoxLayout(self.moto_grupa)
        moto_layout.addWidget(self.moto_pola)
        self.moto_pola.setVisible(False)
        self.moto_grupa.toggled.connect(self.moto_pola.setVisible)
        self.kolumny_moto = tuple(QComboBox() for _ in range(5))
        for label, widget in zip(
            (
                "Marka motocykla *",
                "Model motocykla *",
                "Rocznik od",
                "Rocznik do",
                "Wariant / uwagi",
            ),
            self.kolumny_moto,
            strict=True,
        ):
            widget.setAccessibleName("Kolumna: " + label)
            widget.currentIndexChanged.connect(self._uniewaznij)
            moto_form.addRow(label, widget)
        uwaga = QLabel(
            "Jedno dopasowanie z wiersza. Puste pola są dozwolone; "
            "niepełne dopasowania trafią do poprawy. Nie odgadujemy danych z nazwy."
        )
        uwaga.setWordWrap(True)
        moto_form.addRow(uwaga)
        self.moto_grupa.toggled.connect(self._uniewaznij)
        ustawienia_layout.addWidget(self.moto_grupa)
        layout.addWidget(self.ustawienia_importu)
        self.probka = tabela(["Wiersz", "Próbka danych — pierwsze 10 wierszy arkusza"])
        self.probka.setMaximumHeight(170)
        self.probka.setMinimumHeight(100)
        ustawienia_layout.addWidget(self.probka)
        self.pominiete = QLabel("")
        self.pominiete.setTextFormat(Qt.TextFormat.PlainText)
        self.pominiete.setWordWrap(True)
        layout.addWidget(self.pominiete)
        actions = QVBoxLayout()
        self.podglad = QPushButton("Sprawdź i pokaż podgląd")
        self.podglad.clicked.connect(self.zaplanuj)
        actions.addWidget(self.podglad)
        self.zapisz = QPushButton("Zapisz wybrane, pozostałe odłóż do poprawy")
        self.zapisz.setObjectName("primary")
        self.zapisz.setEnabled(False)
        self.zapisz.clicked.connect(self.zatwierdz)
        actions.addWidget(self.zapisz)
        self.uzupelnij_ceny_przycisk = QPushButton("Podgląd uzupełniania brakujących cen po SKU…")
        self.uzupelnij_ceny_przycisk.setEnabled(False)
        self.uzupelnij_ceny_przycisk.clicked.connect(self.podglad_cen)
        actions.addWidget(self.uzupelnij_ceny_przycisk)
        layout.addLayout(actions)
        self.wyniki = tabela(
            [
                "Dodaj",
                "Wiersz",
                "Nazwa",
                "SKU",
                "Pełny opis",
                "Cena sugerowana",
                "Problem / stan",
                "Dopasowania",
                "EAN",
            ]
        )
        self.wyniki.setMinimumHeight(210)
        self.wyniki.doubleClicked.connect(self.podglad_wiersza)
        self.wyniki.setAccessibleName("Podgląd importu — zaznacz wiersze do dodania")
        layout.addWidget(self.wyniki, 1)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(strona)
        self.tabs.addTab(scroll, "Nowy import")

    def _buduj_korekty(self) -> None:
        strona = QWidget()
        layout = QVBoxLayout(strona)
        actions = QHBoxLayout()
        self.odswiez_korekty = QPushButton("Odśwież listę Do poprawy")
        self.odswiez_korekty.clicked.connect(self.odswiez)
        actions.addWidget(self.odswiez_korekty)
        self.popraw_przycisk = QPushButton("Popraw / przypisz zaznaczony…")
        self.popraw_przycisk.clicked.connect(self.edytuj)
        actions.addWidget(self.popraw_przycisk)
        layout.addLayout(actions)
        czyszczenie = QHBoxLayout()
        self.usun_korekty = QPushButton("Usuń zaznaczone wpisy…")
        self.usun_korekty.clicked.connect(lambda: self.usun_odlozone(False))
        self.wyczysc_korekty = QPushButton("Wyczyść listę Do poprawy…")
        self.wyczysc_korekty.clicked.connect(lambda: self.usun_odlozone(True))
        czyszczenie.addWidget(self.usun_korekty)
        czyszczenie.addWidget(self.wyczysc_korekty)
        layout.addLayout(czyszczenie)
        self.korekty = tabela(["Plik / arkusz / wiersz", "Nazwa", "SKU", "Powód odłożenia"])
        self.korekty.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.korekty.setAccessibleName("Pozycje importu do poprawy")
        self.korekty.doubleClicked.connect(self.edytuj)
        layout.addWidget(self.korekty)
        self.tabs.addTab(strona, "Do poprawy")

    def tryb_biblioteki(self, wlaczony: bool) -> None:
        self._biblioteka = wlaczony
        self.tytul.setText("Nowy cennik" if wlaczony else "Import produktów z cennika")
        self.wyniki.setColumnHidden(0, wlaczony)
        self.zapisz.setVisible(not wlaczony)
        self.uzupelnij_ceny_przycisk.setVisible(not wlaczony)

    def _zadanie(self, funkcja: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self._trwa:
            return
        self._trwa = True
        self.setEnabled(False)
        self.info.setText("Trwa odczyt lub zapis…")

        def gotowe(wynik: object) -> None:
            self._trwa = False
            self.setEnabled(True)
            sukces(wynik)

        def blad(kod: str, komunikat: str) -> None:
            self._trwa = False
            self.setEnabled(True)
            self.info.setText(komunikat)
            if self.dialog is not None:
                self.dialog.setEnabled(True)
                self.dialog.pokaz_blad(kod, komunikat)
                self.dialog.zapisz.setText("Zapisz poprawki na później")

        self.uruchom(funkcja, gotowe, blad)

    def wyczysc_import(self) -> None:
        if self.panel_profili is not None:
            self.panel_profili.wyczysc()
            self.panel_profili.pokaz_ustawienia(True)
        self.plik = None
        self._uniewaznij()
        self.nazwa_pliku.setText("Brak pliku")
        self.arkusz.clear()
        self._kolumny()
        self.probka.setRowCount(0)
        self.pominiete.clear()
        self.producent.setCurrentIndex(0)
        self.naglowek.setValue(1)
        self.waluta.setCurrentIndex(0)
        self.rodzaj_ceny.setCurrentIndex(0)
        self.formuly_cen.setChecked(False)
        self.dolacz_nazwe.setChecked(False)
        self.moto_grupa.setChecked(False)
        self.raport.clear()
        self.info.setText("Wybierz plik nowego cennika.")

    def wybierz_plik(self) -> None:
        nazwa, _ = QFileDialog.getOpenFileName(
            self, "Cennik producenta", "", "Tabele (*.xlsx *.csv)"
        )
        if nazwa:
            if self.panel_profili is not None:
                self.panel_profili.wyczysc()
                self.panel_profili.pokaz_ustawienia(True)
            self.plik = None
            self._uniewaznij()
            self.nazwa_pliku.setText("Odczyt nowego pliku…")
            self.probka.setRowCount(0)
            self.pominiete.clear()
            self._zadanie(
                lambda: (self.serwis.odczytaj(Path(nazwa)), self.producenci.lista()),
                self._plik_wczytany,
            )

    def _plik_wczytany(self, wynik: object) -> None:
        plik, producenci = cast(tuple[PlikImportu, list[ProducentDTO]], wynik)
        self.plik = plik
        self._uniewaznij()
        self.formuly_cen.setChecked(False)
        self.nazwa_pliku.setText(plik.nazwa)
        self.arkusz.blockSignals(True)
        self.arkusz.clear()
        self.arkusz.addItems([a.nazwa for a in plik.arkusze])
        self.arkusz.blockSignals(False)
        self.producent.clear()
        self.producent.addItem("Brak producenta", None)
        nazwy = Counter(p.nazwa.casefold() for p in producenci)
        for p in producenci:
            if p.aktywny:
                self.producent.addItem(nazwa_wyboru_producenta(p, nazwy), str(p.id))
        self.naglowek.setValue(1)
        self._arkusz()
        self.info.setText("Wybierz nagłówki, kolumny i producenta. Próbka nie jest importem.")
        self.plik_zmieniony.emit()
        if self.panel_profili is not None:
            self.panel_profili.rozpoznaj()

    def _uniewaznij(self) -> None:
        self.oceny = ()
        self.wyniki.setRowCount(0)
        self.zapisz.setEnabled(False)
        self.uzupelnij_ceny_przycisk.setEnabled(False)
        self._opis_pominietych()
        self.plan_zmieniony.emit()

    def _arkusz(self) -> None:
        self._kolumny()
        if self.plik is None or self.arkusz.currentIndex() < 0:
            return
        a = self.plik.arkusze[self.arkusz.currentIndex()]
        self.probka.setRowCount(min(10, len(a.wiersze)))
        for i, (nr, cells) in enumerate(a.wiersze[:10]):
            self.probka.setItem(i, 0, QTableWidgetItem(str(nr)))
            self.probka.setItem(i, 1, QTableWidgetItem(" | ".join(c.tekst for c in cells)))

    def _kolumny(self) -> None:
        for box in (
            self.kol_nazwa,
            self.kol_sku,
            self.kol_ean,
            self.kol_opis,
            self.kol_dodatkowy_opis,
            self.kol_cena,
            *self.kolumny_moto,
        ):
            box.blockSignals(True)
            box.clear()
            box.addItem("Nie wybrano / pomiń", None)
        if self.plik is not None and self.arkusz.currentIndex() >= 0:
            rows = dict(self.plik.arkusze[self.arkusz.currentIndex()].wiersze)
            for i, c in enumerate(rows.get(self.naglowek.value(), ())):
                for box in (
                    self.kol_nazwa,
                    self.kol_sku,
                    self.kol_ean,
                    self.kol_opis,
                    self.kol_dodatkowy_opis,
                    self.kol_cena,
                    *self.kolumny_moto,
                ):
                    box.addItem(f"Kolumna {i + 1}: {c.tekst or 'bez nagłówka'}", i)
        for box in (
            self.kol_nazwa,
            self.kol_sku,
            self.kol_ean,
            self.kol_opis,
            self.kol_dodatkowy_opis,
            self.kol_cena,
            *self.kolumny_moto,
        ):
            box.blockSignals(False)
        self._uniewaznij()

    def _opis_pominietych(self) -> None:
        if self.plik is None or self.arkusz.currentIndex() < 0:
            return
        rows = dict(self.plik.arkusze[self.arkusz.currentIndex()].wiersze)
        wybrane = {
            b.currentData()
            for b in (
                self.kol_nazwa,
                self.kol_sku,
                self.kol_ean,
                self.kol_opis,
                self.kol_dodatkowy_opis,
                self.kol_cena,
                *self.kolumny_moto,
            )
        }
        if not self.moto_grupa.isChecked():
            wybrane = {
                b.currentData()
                for b in (
                    self.kol_nazwa,
                    self.kol_sku,
                    self.kol_ean,
                    self.kol_opis,
                    self.kol_dodatkowy_opis,
                    self.kol_cena,
                )
            }
        nazwy = [
            f"{i + 1}: {c.tekst or 'bez nagłówka'}"
            for i, c in enumerate(rows.get(self.naglowek.value(), ()))
            if i not in wybrane
        ]
        self.pominiete.setText("Kolumny pomijane (nie zostaną zapisane): " + ", ".join(nazwy))

    def mapowanie(self) -> Mapowanie:
        if self.kol_nazwa.currentData() is None or self.kol_sku.currentData() is None:
            raise BladScenariuszaKatalogu("IMPORT", "Wybierz kolumny nazwy i SKU.")
        cena_mapa = None
        if self.kol_cena.currentData() is not None:
            cena_mapa = MapowanieCeny(
                int(self.kol_cena.currentData()),
                self.waluta.currentText(),
                self.rodzaj_ceny.currentText(),
                self.formuly_cen.isChecked(),
                self.pelne_brutto.isChecked(),
            )
        motocykl = None
        if self.moto_grupa.isChecked():
            indeksy = tuple(b.currentData() for b in self.kolumny_moto)
            if indeksy[0] is None or indeksy[1] is None:
                raise BladScenariuszaKatalogu(
                    "IMPORT", "Wskaż kolumny marki i modelu motocykla lub wyłącz import dopasowań."
                )
            motocykl = MapowanieMotocykla(int(indeksy[0]), int(indeksy[1]), *indeksy[2:])
        return Mapowanie(
            self.naglowek.value(),
            int(self.kol_nazwa.currentData()),
            int(self.kol_sku.currentData()),
            self.kol_opis.currentData(),
            self.kol_dodatkowy_opis.currentData(),
            self.dolacz_nazwe.isChecked(),
            cena_mapa,
            motocykl,
            self.kol_ean.currentData(),
        )

    def zaplanuj(self) -> None:
        if self.plik is None:
            self.info.setText("Wybierz plik oraz kolumny nazwy i SKU.")
            return
        try:
            mapa = self.mapowanie()
        except BladScenariuszaKatalogu as exc:
            self.info.setText(str(exc))
            return
        plik, arkusz = self.plik, self.arkusz.currentIndex()
        pid = self.producent.currentData()
        producent = UUID(pid) if pid else None
        self._zadanie(lambda: self.serwis.zaplanuj(plik, arkusz, mapa, producent), self._plan)

    def zastosuj_mape(self, d: DopasowanieCennika) -> None:
        m = d.mapa
        self.arkusz.setCurrentIndex(d.arkusz)
        self.naglowek.setValue(m.naglowek)
        self._kolumny()
        for box, indeks in (
            (self.kol_nazwa, m.nazwa),
            (self.kol_sku, m.sku),
            (self.kol_ean, m.ean),
            (self.kol_opis, m.opis),
            (self.kol_dodatkowy_opis, m.dodatkowy_opis),
            (self.kol_cena, m.cena.kolumna if m.cena else None),
        ):
            box.setCurrentIndex(box.findData(indeks))
        self.dolacz_nazwe.setChecked(m.dolacz_nazwe_zrodlowa)
        self.formuly_cen.setChecked(False)
        self.waluta.setCurrentText(m.cena.waluta if m.cena else "Wybierz walutę")
        self.rodzaj_ceny.setCurrentText(m.cena.rodzaj if m.cena else "Wybierz netto/brutto")
        self.pelne_brutto.setChecked(m.cena.pelne_brutto_vat23 if m.cena else True)
        self.moto_grupa.setChecked(m.motocykl is not None)
        if m.motocykl is not None:
            for box, indeks in zip(
                self.kolumny_moto,
                (
                    m.motocykl.marka,
                    m.motocykl.model,
                    m.motocykl.rok_od,
                    m.motocykl.rok_do,
                    m.motocykl.wariant,
                ),
                strict=True,
            ):
                box.setCurrentIndex(box.findData(indeks))
        if d.profil is not None:
            pid = str(d.profil.producent_id) if d.profil.producent_id else None
            self.producent.setCurrentIndex(self.producent.findData(pid))

    def _plan(self, wynik: object) -> None:
        self.oceny = cast(tuple[OcenaPozycji, ...], wynik)
        self.wyniki.verticalHeader().setDefaultSectionSize(52)
        self.wyniki.setRowCount(len(self.oceny))
        for i, o in enumerate(self.oceny):
            item = QTableWidgetItem()
            item.setFlags(
                Qt.ItemFlag.ItemIsEnabled
                | Qt.ItemFlag.ItemIsSelectable
                | Qt.ItemFlag.ItemIsUserCheckable
            )
            item.setCheckState(Qt.CheckState.Unchecked if o.problem else Qt.CheckState.Checked)
            self.wyniki.setItem(i, 0, item)
            for j, value in enumerate(
                (
                    str(o.pozycja.wiersz),
                    o.pozycja.dane.nazwa,
                    o.pozycja.dane.sku,
                    o.pozycja.dane.opis,
                    (
                        etykieta_cennika(
                            o.pozycja.cena.tekst, o.pozycja.cena.waluta, o.pozycja.cena.rodzaj
                        )
                        if o.pozycja.cena and o.pozycja.cena.tekst
                        else "—"
                    ),
                    o.problem or "Gotowy",
                    "\n".join(d.etykieta for d in o.pozycja.dane.dopasowania or ()) or "—",
                    o.pozycja.dane.ean or "—",
                ),
                1,
            ):
                self.wyniki.setItem(i, j, QTableWidgetItem(value))
        bledy = sum(bool(o.problem) for o in self.oceny)
        self.info.setText(
            f"Podgląd: {len(self.oceny)} pozycji, {bledy} z problemami. "
            "Zaznaczone trafią do katalogu; pozostałe na listę Do poprawy. "
            "Jeden wiersz z grupy duplikatów można wybrać świadomie. "
            "Dwuklik otwiera pełny opis przed zapisem."
        )
        self.zapisz.setEnabled(True)
        self.uzupelnij_ceny_przycisk.setEnabled(any(o.pozycja.cena for o in self.oceny))

        if getattr(self, "_biblioteka", False):
            self.info.setText(
                f"Pozycje: {len(self.oceny)}. Zapis cennika zachowa wszystkie wiersze; "
                "produkty wybierzesz później."
            )
        self.plan_zmieniony.emit()

    def podglad_cen(self) -> None:
        oceny = self.oceny
        self._zadanie(lambda: self.serwis.zaplanuj_uzupelnienie_cen(oceny), self._dialog_cen)

    def _dialog_cen(self, wynik: object) -> None:
        plan = cast(PlanUzupelnieniaCen, wynik)
        dialog = DialogPotwierdzenia(self)
        dialog.setWindowTitle("Uzupełnij brakujące ceny źródłowe")
        dialog.resize(780, 560)
        layout = QVBoxLayout(dialog)
        layout.addWidget(
            QLabel(
                f"Uzupełnienie: {len(plan.pozycje)}. Pominięte: {len(plan.pominiete)}. "
                "Istniejące ceny, nazwy, opisy i producenci nie zostaną nadpisane."
            )
        )
        tab = tabela(["SKU", "Nazwa", "Cena sugerowana"])
        tab.setRowCount(len(plan.pozycje))
        for i, p in enumerate(plan.pozycje):
            for j, v in enumerate(
                (p.sku, p.nazwa, f"{p.cena.tekst} {p.cena.waluta} {p.cena.rodzaj}")
            ):
                tab.setItem(i, j, QTableWidgetItem(v))
        layout.addWidget(tab)
        pom = tabela(["Pominięty wiersz", "Powód"])
        pom.setRowCount(len(plan.pominiete))
        for i, (nr, powod) in enumerate(plan.pominiete):
            pom.setItem(i, 0, QTableWidgetItem(str(nr)))
            pom.setItem(i, 1, QTableWidgetItem(powod))
        layout.addWidget(pom)
        info = QLabel("Przed zapisem powstanie kopia całej bazy.")
        info.setTextFormat(Qt.TextFormat.PlainText)
        info.setWordWrap(True)
        layout.addWidget(info)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText(
            "Uzupełnij wyłącznie pokazane ceny"
        )
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        def zapisz() -> None:
            buttons.setEnabled(False)
            dialog.trwa = True

            def sukces(wynik: object) -> None:
                dialog.trwa = False
                dialog.accept()
                self._uniewaznij()
                self.raport.setText(f"Uzupełniono {len(plan.pozycje)} cen. Kopia: {wynik}")
                self.zmieniono.emit()

            def blad(kod: str, tekst: str) -> None:
                buttons.setEnabled(True)
                info.setText(tekst)
                dialog.trwa = False

            self.uruchom(lambda: self.serwis.uzupelnij_ceny(plan), sukces, blad)

        buttons.accepted.connect(zapisz)
        dialog.finished.connect(dialog.deleteLater)
        dialog.setModal(True)
        dialog.open()

    def podglad_wiersza(self) -> None:
        row = self.wyniki.currentRow()
        if row < 0 or row >= len(self.oceny):
            return
        p = self.oceny[row].pozycja
        dto = ProduktDTO(
            p.id,
            p.dane.nazwa,
            p.dane.sku,
            p.dane.opis,
            1,
            p.dane.producent_id,
            self.producent.currentText() if p.dane.producent_id else None,
            ean=p.dane.ean or "",
        )
        if p.cena is not None:
            try:
                cena = p.cena.sprawdz()
            except ValueError:
                cena = None
            if cena is not None:
                dto = replace(
                    dto,
                    cena_sugerowana=CenaSugerowanaDTO(
                        format(cena.kwota, "f"),
                        cena.waluta,
                        cena.rodzaj,
                        f"{p.zrodlo} / {p.arkusz} / {p.wiersz}",
                    ),
                )
        dialog = SzczegolyProduktu(dto, self)
        dialog.dopasowania_podglad.setPlainText(
            "\n".join(d.etykieta for d in p.dane.dopasowania or ()) or "Brak dopasowań w wierszu."
        )
        dialog.setWindowTitle("Podgląd wiersza przed importem")
        dialog.przycisk_edycji.hide()
        self.podglad_dialog = dialog

        def zamknieto() -> None:
            self.podglad_dialog = None
            dialog.deleteLater()

        dialog.finished.connect(zamknieto)
        dialog.setModal(True)
        dialog.open()

    def zatwierdz(self) -> None:
        if not self.oceny:
            return
        oceny = self.oceny
        wybrane = frozenset(
            o.pozycja.id
            for i, o in enumerate(oceny)
            if (item := self.wyniki.item(i, 0)) is not None
            and item.checkState() == Qt.CheckState.Checked
        )
        self._zadanie(lambda: self.serwis.zatwierdz(oceny, wybrane), self._zapisano)

    def _zapisano(self, wynik: object) -> None:
        w = cast(WynikImportu, wynik)
        self._uniewaznij()
        self.raport.setText(
            f"Zapisano {w.dodane} nowych produktów. Odłożono do poprawy: {w.odlozone}."
        )
        self.info.setText("Paczka zapisana.")
        self.zmieniono.emit()
        if w.odlozone:
            self.tabs.setCurrentIndex(1)
            self.odswiez()

    def odswiez(self) -> None:
        self._zadanie(self.serwis.oczekujace, self._oczekujace)

    def _oczekujace(self, wynik: object) -> None:
        self.pozycje = cast(tuple[PozycjaImportu, ...], wynik)
        self.korekty.setRowCount(len(self.pozycje))
        for i, p in enumerate(self.pozycje):
            for j, value in enumerate(
                (f"{p.zrodlo} / {p.arkusz} / {p.wiersz}", p.dane.nazwa, p.dane.sku, p.powod)
            ):
                self.korekty.setItem(i, j, QTableWidgetItem(value))
        self.info.setText(f"Do poprawy: {len(self.pozycje)}. Dane zachowane po restarcie.")

    def usun_odlozone(self, wszystkie: bool) -> None:
        if self._trwa:
            return
        indeksy = {i.row() for i in self.korekty.selectionModel().selectedRows(0)}
        pozycje = tuple(p for i, p in enumerate(self.pozycje) if wszystkie or i in indeksy)
        if not pozycje:
            self.info.setText("Brak wpisów do usunięcia. Zaznacz wiersze na liście Do poprawy.")
            return
        odpowiedz = QMessageBox.question(
            self,
            "Usuwanie wpisów Do poprawy",
            f"Usunąć {len(pozycje)} wpisów z listy Do poprawy?\n"
            "Produkty w katalogu i pliki źródłowe pozostaną bez zmian. "
            "Przed usunięciem zostanie utworzona kopia bazy.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if odpowiedz != QMessageBox.StandardButton.Yes:
            return
        self._zadanie(lambda: self.serwis.usun_oczekujace(pozycje), self._usunieto_odlozone)

    def _usunieto_odlozone(self, wynik: object) -> None:
        self.raport.setText(f"Usunięto wpisy Do poprawy. Kopia bazy: {wynik}")
        self.odswiez()

    def edytuj(self) -> None:
        row = self.korekty.currentRow()
        if row < 0 or row >= len(self.pozycje):
            self.info.setText("Zaznacz pozycję Do poprawy.")
            return
        p = self.pozycje[row]
        self._zadanie(
            lambda: (self.producenci.lista(), self.katalog.wyszukaj()),
            lambda wynik: self._edytor(p, wynik),
        )

    def _edytor(self, p: PozycjaImportu, wynik: object) -> None:
        producenci, produkty = cast(tuple[list[ProducentDTO], list[ProduktDTO]], wynik)
        dto = ProduktDTO(
            p.id,
            p.dane.nazwa,
            p.dane.sku,
            p.dane.opis,
            p.wersja,
            p.dane.producent_id,
            ean=p.dane.ean or "",
        )
        dialog = FormularzProduktu(producenci, dto, self)
        dialog.dopasowania = p.dane.dopasowania or ()
        dialog._opis_dopasowan()
        self.dialog = dialog
        dialog.setWindowTitle("Do poprawy — korekta / przypisanie")
        dialog.zapisz.setText("Zapisz poprawki na później")
        layout = cast(QVBoxLayout, dialog.layout())
        cena_tekst = QLineEdit(p.cena.tekst if p.cena else "")
        cena_tekst.setPlaceholderText("Cena sugerowana — puste oznacza brak")
        cena_tekst.setAccessibleName("Poprawiona cena sugerowana")
        waluta = QComboBox()
        waluta.addItems(["PLN", "EUR", "GBP", "USD", "CHF", "CZK", "SEK", "NOK", "DKK"])
        if p.cena:
            waluta.setCurrentText(p.cena.waluta)
        rodzaj = QComboBox()
        rodzaj.addItems(["netto", "brutto"])
        if p.cena:
            rodzaj.setCurrentText(p.cena.rodzaj)
        layout.addWidget(QLabel("Źródłowa cena sugerowana / waluta / netto lub brutto"))
        layout.addWidget(cena_tekst)
        layout.addWidget(waluta)
        layout.addWidget(rodzaj)
        combo = QComboBox()
        combo.setAccessibleName("Istniejący Produkt do jawnego powiązania")
        combo.addItem("Wybierz istniejący Produkt — bez nadpisywania", None)
        for produkt in produkty:
            combo.addItem(f"{produkt.sku} • {produkt.nazwa} • {produkt.id}", str(produkt.id))
        layout.addWidget(combo)
        dodaj = QPushButton("Dodaj poprawiony Produkt do katalogu")
        przypisz = QPushButton("Powiąż z wybranym Produktem (wymagane zgodne SKU)")
        layout.addWidget(dodaj)
        layout.addWidget(przypisz)
        informacja = QLabel(
            "Powiązanie rozstrzyga wiersz bez kopiowania jego danych, "
            "w tym dopasowań, do istniejącego Produktu."
        )
        informacja.setWordWrap(True)
        layout.addWidget(informacja)

        def wykonaj(tryb: str) -> None:
            nowa = replace(
                p,
                dane=dialog.dane(),
                powod="",
                cena=CenaImportu(cena_tekst.text(), waluta.currentText(), rodzaj.currentText())
                if cena_tekst.text().strip()
                else None,
            )
            cel = combo.currentData()
            if tryb == "powiaz" and not cel:
                dialog.pokaz_blad("IMPORT", "Wybierz istniejący Produkt.")
                return
            dialog.setEnabled(False)

            def operacja() -> None:
                if tryb == "szkic":
                    self.serwis.popraw(nowa)
                else:
                    self.serwis.rozstrzygnij(nowa, UUID(cel) if tryb == "powiaz" else None)

            def sukces(wynik: object) -> None:
                tekst = {
                    "szkic": "Zapisano poprawki na później.",
                    "dodaj": "Dodano poprawiony Produkt do katalogu.",
                    "powiaz": "Powiązano z istniejącym Produktem bez nadpisania danych.",
                }
                self.raport.setText(tekst[tryb])
                dialog.setEnabled(True)
                dialog.accept()
                self.zmieniono.emit()
                self.odswiez()

            self._zadanie(operacja, sukces)

        dialog.przyciski.accepted.connect(lambda: wykonaj("szkic"))
        dodaj.clicked.connect(lambda: wykonaj("dodaj"))
        przypisz.clicked.connect(lambda: wykonaj("powiaz"))

        def zamknieto() -> None:
            self.dialog = None
            dialog.deleteLater()

        dialog.finished.connect(zamknieto)
        dialog.setModal(True)
        dialog.open()
