# Cenniki 0.59

Import pokazuje opcję „Brutto bez groszy · VAT 23% · pokaż netto”, domyślnie
włączoną. Wskaż, czy kwota w źródle jest netto czy brutto. Źródłowe netto
mnożymy przez 1,23; wynik brutto zaokrąglamy matematycznie do pełnej jednostki.
Przykład: 1340,2345 brutto → 1340 brutto i 1089,43 netto. Źródłowe 100 netto
→ 123 brutto i 100,00 netto. Przy połowie zaokrąglamy w górę.

Podgląd importu i lista cennika pokazują obie ceny. Do katalogu trafia
zaokrąglona cena brutto. Opcję można wyłączyć, zachowując źródłową precyzję.
Profile zapamiętują wybór; dawne profile zachowują dotychczasową regułę.
Istniejące cenniki i ceny Produktów nie są automatycznie przepisywane.
Źródłowy Excel pozostaje bez zmian, formuły wymagają zgody na użycie
zapisanych wyników. Obsługujemy także nadmiarowe miejsca dziesiętne
liczbowych wyników Excela przy zaokrąglaniu. Brak nowej migracji lub zależności.

Weryfikacja obejmuje kwoty netto/brutto, progi, zero, odrzucenie błędnych
wartości, import i ponowny odczyt SQLite, dodanie do katalogu, widoczność
obu cen w Qt. Natywny Windows wymaga odbioru na komputerze użytkownika.
