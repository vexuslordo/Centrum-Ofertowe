# VexLab 0.57 — Twoje produkty z paczek Allegro

W Przygotuj oferty Allegro wybierz producenta lokalnego lub wpisz nową nazwę.
Ręcznie wpisany producent zapisze się przy tworzeniu produktów i będzie do
wyboru w przyszłych paczkach. To odrębny rejestr od producenta GPSR oraz
parametru producenta w Katalogu Allegro; ich ustawienia nadal wybierasz osobno.

Po potwierdzeniu tworzenia szkiców wskazane poprawne pozycje są zapisywane
w Produkty: nazwa, opis, SKU, EAN, cena sugerowana brutto z walutą i zdjęcia.
Lokalna galeria zachowuje do5 pierwszych zdjęć, zgodnie z jej obecnym limitem;
pełna galeria oferty Allegro pozostaje w szkicu. SKU nie może być puste,
EAN jest zachowywany ze źródła bez zgadywania. Cena pochodzi z aktualnego planu.

Zapis lokalny następuje przed nowymi żądaniami tworzenia ofert; jego błąd
blokuje wysyłkę. Produkty są Twoimi danymi także wtedy, gdy Allegro odrzuci
ofertę albo nie potwierdzi wyniku. Oddzielny komunikat pokazuje liczbę
nowych i istniejących Produktów. Powiązanie z ID Allegro zapisujemy dopiero
po potwierdzeniu utworzenia/odczytu. Nie tworzymy Produktów przy samym
otwarciu paczki lub anulowaniu potwierdzenia.

Istniejące SKU (bez rozróżniania wielkości liter) nie tworzy drugiego Produktu.
Uzupełniamy tylko puste pola/cenę/galerię. Lokalne nazwy, opisy, ceny, galerie
oraz przypisania producentów są zachowane. Inny niepusty EAN dla tego samego
SKU blokuje całą partię przed zapisem. EAN nie służy do scalania Produktów.

## Eksport i import

Produkty → Więcej akcji → Eksportuj produkty ze zdjęciami (ZIP).
Zaznaczenie eksportuje wybrane produkty; bez zaznaczenia eksportuje wyniki
filtra. Do500 produktów i128MiB zdjęć na partię. W razie przekroczenia limitu
zawęź filtr lub zaznacz mniej produktów. Istniejący eksport CSV pozostaje
przeznaczony do pracy z arkuszem; ZIP obejmuje zdjęcia i cenę z walutą.

Importuj produkty ze zdjęciami (ZIP) otwiera podgląd. Zaznacz wpisy i potwierdź
import. W paczce są osadzone zdjęcia, kody, opis, nazwa/strona producenta,
cena/waluta/rodzaj, dopasowania i dostępność. Możesz przenieść ją na inny
komputer bez oryginalnych plików zdjęć i bez połączenia z Allegro. Kolejność
zdjęć jest zachowana. Ponowny import nie dubluje SKU ani producentów.
Import nie nadpisuje niepustych lokalnych pól, nie publikuje ani nie tworzy
kont/powiązań Allegro. Nie przenosimy tokenów, haseł i dzienników operacji.

## Dane i aktualizacja

To istniejąca baza katalog.sqlite3 w katalogu danych użytkownika, bez migracji
schematu12 i bez danych demonstracyjnych na starcie. Ręcznie dodani producenci
oraz produkty przeżywają wymianę programu. Zachowuj cały katalog danych przy
aktualizacji. Przed atomowym zapisem partii powstaje spójna kopia bazy.
ZIP jest przenośnym katalogiem produktów, a nie kopią całej konfiguracji kont.

Testy: dane/zdjęcia/cena/producent po restarcie, deduplikacja i konflikt EAN,
rollback i kopia, podgląd/anulowanie, lokalny błąd bez POST, zachowanie
produktów po timeoutcie Allegro, roundtrip ZIP bez sieci, uszkodzone hashe,
niepoprawne EAN i ścieżki, oba motywy oraz większe DPI.

Poprawka współbieżnego pierwszego uruchomienia: rejestr migracji oraz wersja
schematu są sprawdzane w jednym spójnym odczycie, bez zmiany sum migracji.

Zrzuty: [producent w przygotowaniu Allegro](screenshots/vexlab-przygotowanie-057-dark.png),
[import ze zdjęciami](screenshots/vexlab-import-produktow-057-light.png).
