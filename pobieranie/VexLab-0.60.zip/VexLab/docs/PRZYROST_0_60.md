# PrestaShop 1.6.1.24 — połączenie i kategorie

Otwórz Sprzedaż → PrestaShop albo Ustawienia → Integracje → PrestaShop →
Otwórz połączenie i kategorie. Podaj główny adres HTTPS sklepu (może mieć
podkatalog), bez adresu panelu administratora. Klucz Webservice utwórz
w PrestaShop: Zaawansowane → Webservice/API. Włącz Webservice i nadaj
kluczowi uprawnienia GET do shops, languages i categories.

1. Kliknij Sprawdź połączenie. Wybierz sklep i język z pobranych list.
2. Kliknij Pobierz kategorie. Szukaj po nazwie lub ID; wybierz aktywną kategorię.
3. Opcjonalnie kliknij Zapamiętaj połączenie i wybór. Na Windows klucz
   trafia wyłącznie do zaszyfrowanego pliku danych bieżącego użytkownika.
   Podgląd i odczyt działają też bez zapamiętywania połączenia.

W przypadku jednego aktywnego sklepu/języka wybór jest automatyczny;
w konfiguracji wielosklepowej trzeba wskazać właściwy sklep. Zmiana kontekstu
usuwa poprzedni podgląd. Nieaktywne kategorie są widoczne, ale nie zostają
zapamiętane jako docelowe. Brak uprawnień lub niepełny/błędny XML daje
konkretny komunikat. Nie pokazujemy częściowej listy jako kompletnej.
Przywrócenie klucza z pliku po starcie nie łączy automatycznie ze sklepem.
Po restarcie potrzebne jest Sprawdź połączenie oraz ponowne pobranie kategorii.

To pierwszy etap PrestaShop w roadmapie: wyłącznie odczyt ustawień i kategorii.
Nie wysyła ani nie modyfikuje produktów, cen, zamówień i kategorii w sklepie.
Zapis oferty i wspólna wysyłka kanałów będą następnymi przyrostami.
Nie wykonywano odczytów na rzeczywistym sklepie właściciela ani zapisów
biznesowych przez API. Kontrakt oparto o źródła PrestaShop 1.6.1.24,
syntetyczne odpowiedzi XML i testy transportu. Odbiór z rzeczywistym kluczem
oraz natywnym DPAPI Windows pozostaje do sprawdzenia na komputerze właściciela.
Schemat katalogu 12 bez zmian; brak nowych zależności.

Walidacja: pełne kontrole statyczne i granic warstw, 1216 testów OK,
1 pominięty test natywnego DPAPI Windows. Dodatkowo 62 testy regresji GUI
PrestaShop/Allegro i odczytu API po zmianie wspólnego statusu połączeń.
Audyt zależności runtime i developerskich bez znanych podatności.
Podglądy syntetyczne: [ciemny](screenshots/vexlab-presta-060-dark.png),
[jasny](screenshots/vexlab-presta-060-light.png).
