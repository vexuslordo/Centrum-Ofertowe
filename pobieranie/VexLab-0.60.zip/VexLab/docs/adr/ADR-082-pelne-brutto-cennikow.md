# ADR-082 — pełne brutto i netto w cennikach

Status: zatwierdzone poleceniem właściciela, 2026-11-16.

Właściciel wymaga brutto bez groszy, widocznego netto oraz VAT zawsze 23%
w swoich cennikach. Import ma jawnie wybraną regułę: źródłowe netto mnożymy
przez 1,23, brutto zaokrąglamy HALF_UP do jednostki, netto wyświetlamy
z tego brutto z dokładnością dwóch miejsc. Źródłowy plik pozostaje bez zmian.
Reguła jest opcją mapowania importu, nie globalną zmianą cen Produktów,
Ofert, kanałów ani istniejących cenników. Kwota zapisywana przez istniejący
importer jest brutto. Brak nowej relacji domenowej, schematu i migracji.
GUI wyłącznie wybiera regułę i pokazuje przygotowane etykiety; obliczenia
w przypadku użycia, Decimal bez float. Niepoprawne ceny nadal trafiają
do poprawy. Zapisane formuły wymagają dotychczasowej jawnej zgody.

Akceptacja: granice zaokrąglenia, źródłowe netto/brutto, zero i błędne dane;
rzeczywisty import XLSX, zapis i ponowny odczyt cennika, obie ceny w GUI.
