# ADR-083 — odczyt połączenia i kategorii PrestaShop 1.6

Status: wdrożenie kolejnego zatwierdzonego etapu roadmapy na polecenie
właściciela z 2026-11-17. Właściciel wskazał wersję 1.6.1.24.

Pierwszy pionowy zakres PrestaShop: ustawienia adresu sklepu i klucza
Webservice, test GET shops/languages oraz pobranie pełnych stron kategorii
w jawnym kontekście sklepu i języka. Tylko odczyt; bez zmiany produktów,
kategorii, cen i publikacji. Wybór kategorii zapamiętywany jako ustawienie
konkretnego połączenia, nie pole wspólnego Produktu. Brak nowego bytu domeny
lub migracji katalogu. Wspólne wysyłki Allegro/PrestaShop pozostają następnym
przyrostem, nie są zastąpione panelem ustawień.

Kontrakt zweryfikowano ze źródłami PrestaShop 1.6.1.24:
classes/webservice/WebserviceRequest.php, classes/Category.php,
classes/shop/Shop.php w oficjalnym repozytorium PrestaShop/PrestaShop.
GET XML, display, sort, limit, language i id_shop; Basic Auth z kluczem
jako nazwą użytkownika i pustym hasłem. Klucz nigdy w URL ani logach.
Adres panelu administratora i jego token nie są danymi połączenia.

Porty i neutralne DTO w przypadkach użycia; mapowanie XML w kanale;
HTTPS i magazyn sekretów w adapterach; GUI jedynie zleca pracę w tle.
HTTPS z walidacją certyfikatu, bez przekierowań i proxy ze środowiska,
limity rozmiaru odpowiedzi, liczby stron/rekordów, duplikatów i XML bez DTD.
Uprawnienia do GET shops, languages, categories wymagane jawnie. Różne
sklepy/języki nie dzielą kategorii; zmiana ustawień usuwa stary podgląd.

Dobrowolne zapamiętanie całego połączenia przez istniejący szyfrator DPAPI
Windows, atomowy zapis wyłącznie zaszyfrowanych bajtów w osobnym pliku
polaczenia/prestashop.dpapi. Nie nadpisuje połączenia Allegro. Odnowienie
pola klucza po restarcie nie oznacza potwierdzonego połączenia — potrzebny GET.
Bez automatycznego kontaktu ze sklepem przy starcie. Rozłączenie usuwa
wyłącznie własny zapis i podgląd. Błąd testu nie niszczy zapamiętanego wpisu.
Nowa instalacja nie zawiera adresu, klucza ani przykładowych kategorii.
