# ADR-080 — automatyczny katalog użytkownika z paczek i jego przenoszenie

Status: polecenia właściciela 2026-11-16: automatycznie lokalny Produkt przy
wysyłaniu paczki na Allegro; zdjęcie, SKU/EAN/cena, wybierany lub ręcznie
wpisany Producent zachowany na przyszłość, eksport/import danych użytkownika.
Zastępuje wcześniejszy zakres „ZIP nie tworzy produktów” dla tej ścieżki.

Przed zleceniem tworzenia szkiców zapisać atomowo wskazane poprawne pozycje
w istniejącym katalogu. To niezależne dane użytkownika, nie seed programu.
Potwierdzenie tworzenia wskazuje także ten lokalny skutek; brak osobnego pytania.
Lokalny błąd blokuje nowe POST. Przy błędzie Allegro produkty nadal istnieją,
a wynik lokalnego zapisu jest pokazany osobno. Powiązanie konto/env/ID dopiero
po potwierdzeniu utworzenia/odczytu; błąd powiązania nie zmienia wyniku Allegro.

Producent lokalny to rejestr Producentów, odrębny od GPSR i słownika kategorii
Allegro. Edytowalna lista, ręczna nazwa zapisywana w tej samej transakcji;
jednoznaczne aktywne dopasowanie casefold, bez automatycznych nazw z tytułu.
SKU casefold to tożsamość dopasowania, EAN nigdy nie scala. Istniejących pól
nie nadpisywać; uzupełniać braki, sprzeczny niepusty EAN blokuje zapis.
Cena jako cena sugerowana brutto z walutą i źródłem. Galeria lokalna do5
pierwszych zdjęć zgodnie z istniejącym limitem; szkic zachowuje pełną galerię.
Nie zgadywać strukturalnych dopasowań z tytułu/tekstu paczki.

Przenośny ZIP v1: manifest JSON oraz obrazy JPEG z SHA256, nazwy, SKU, EAN,
opis, nazwa/strona Producenta, cena/waluta/rodzaj, dopasowania i dostępność.
Bez sekretów, kont, historii operacji i powiązań Allegro; import nie publikuje.
Podgląd i wybór pozycji przed importem, potwierdzany zapis z kopią, atomowy
rollback, ponowienie bez duplikowania. Eksport wybranych lub wyników filtra.
Istniejący CSV bez zmian. Limity:500 produktów i128MiB danych na partię;
bez extractall, z kontrolą nazw/duplikatów/rozmiaru/hash/formatu obrazu.

Sześć warstw zachowanych: DTO/port/scenariusz w przypadkach użycia, SQLite
oraz ZIP w adapterach; GUI nie używa SQL/HTTP. Brak migracji schematu12.
Dane w istniejącym katalogu użytkownika, zachowane przy wymianie programu.
Testy: ręczny Producent/restart, SKU deduplikacja/konflikt EAN, obraz/cena,
rollback/kopia, ZIP roundtrip/offline/uszkodzenie/traversal, zatrzymanie
przed POST, osobne wyniki lokalne/Allegro, oba motywy/DPI, brak seedów.
