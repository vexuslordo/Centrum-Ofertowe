# ADR-079 — pojedyncza i masowa edycja zdalnych ofert

Status: polecenie właściciela i kontynuacja roadmapy 2026-11-16, przyrost0.56.
INACTIVE/ACTIVE, pola name/external.id oraz EAN przez jawne powiązanie
z jednoznacznym istniejącym produktem tej samej kategorii. Bez tworzenia
produktu lub oferty. Zestawy oraz automatyczne dopasowania/TecDoc wymagające
osobnego mapowania są blokowane dla zmiany EAN. Tytuł/SKU nadal dostępne.

Port i immutable DTO w przypadkach użycia; mapowanie API w kanaly; GUI bez
SQL/HTTP. Model Produktu i lokalne szkice bez zmian. Brak migracji.
Odczyt → indywidualne wartości → podgląd przed/po i produkt EAN → zatwierdzenie
→ preflight → PATCH tylko wybrane pola → GET potwierdzający. Sieć w tle,
postęp i zatrzymanie między żądaniami. Każdy wiersz ma niezależny wynik.

Wspólny trwały rejestr zapisy_allegro, ten sam klucz env/konto/ID jak zapis
starych szkiców: wzajemna blokada prób. Hash celu bez treści/tokenów.
Zapis rezerwacji przed preflight, zwolnienie tylko gdy PATCH nie wysłany,
jednoznacznie odrzucony albo GET potwierdza pełny cel. Timeout/202/restart
wymagają GET, bez ponowienia PATCH. Kontekst sesji sprawdzany także w serii.

EAN: kontrakt PATCH productSet zastępuje tablicę; zachować ilość i GPSR.
Opis/zdjęcia/parametry przekazać jawnie przy product.id, ponieważ inaczej
Allegro może pobrać je z produktu. Zachować parametry oprócz GTIN.
Źródła: oficjalny Swagger i poradnik zarządzania ofertami Allegro,
https://developer.allegro.pl/tutorials/jak-zarzadzac-ofertami-7GzB2L37ase
Ograniczenia Allegro ostatecznie rozstrzyga odpowiedź API, widoczna w wyniku.

Testy: częściowy PATCH, własność konta, walidacja, świeży stan, brak duplikatu,
EAN/produkt i zachowanie GPSR, 202, odrzucenie, timeout/restart/GET-only,
częściowy sukces, anulowanie oraz zmiana sesji; bez realnych zapisów w testach.
