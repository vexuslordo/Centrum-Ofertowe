# ADR-081 — nowa oferta z lokalnego Produktu

Status: wdrożenie zaakceptowanego punktu1 po sprawdzeniu roadmapy, 2026-11-16,
przyrost0.58. Produkty → jeden Produkt → Utwórz ofertę z Produktu.

Odczyt danych i galerii w tle, z kontrolą wersji wybranego Produktu. Kopie
zdjęć zapisane w istniejącym magazynie zdjęć ofert przez port bajtowy; oferta
nie zależy od późniejszego usunięcia/zmiany galerii Produktu. Samo otwarcie
lub anulowanie nie tworzy szkicu i nie modyfikuje Produktu. Kopie zdjęć mogą
pozostać w magazynie jak przy ręcznym dodaniu zdjęć.

Ten sam edytor i podgląd co przy ręcznej ofercie. Pobieramy nazwę, opis,
SKU/EAN, zdjęcia, cenę z walutą/rodzajem oraz producenta jako kontekst lokalny.
Nie zgadujemy GPSR ani parametrów Katalogu Allegro. Cena netto lub waluta
nieobsługiwana w przygotowaniu Allegro nie jest kopiowana jako cena brutto:
pokaż źródło i poproś o ręczne podanie ceny brutto. Brak automatycznej stawki VAT.
Długi tytuł zachować do świadomego skrócenia, bez cichego obcięcia.

Zapis tworzy Szkic z istniejącym opcjonalnym FK produkt_id/wersja_produktu.
Kontrola wersji w transakcji zapisu i kopia, bez nowych tabel/migracji.
Klucz deduplikacji obejmuje treść oraz ID/wersję źródła. Niezależne szkice
z wcześniejszych ścieżek zachowują dotychczasowe klucze.

Waluta i nazwa lokalnego producenta jako małe dane przygotowania w istniejącym
tresc_json, z domyślnymi pustymi wartościami dla dawnych szkiców. Zachować
przy edycji. Snapshot nie modyfikuje rejestru producentów. Przy wejściu do
przygotowania Allegro wypełnić walutę i lokalnego producenta, także po restarcie.
Różne znane waluty zaznaczonych szkiców blokują wspólną partię; nie wybrać
pierwszej waluty dla wszystkich. Producent GPSR/parametr kategorii pozostają
osobnymi ustawieniami. Dalej najpierw zapisuje szkic, nie publikuje oferty.

Nowe porty i DTO w przypadkach użycia, zapis binarny w adapterze zdjęć, odczyt
ze spójnego eksportowego snapshotu istniejącego katalogu + kontrola wersji.
GUI nie importuje SQLite/adapterów. Zachować logo, motywy i miniatury64.
Testy: dane początkowe, kwoty/waluty, niezależność zdjęć, anulowanie,
konflikt wersji, FK/wersja/restart/metadane/deduplikacja i brak zmian źródła.
PrestaShop i wybór wielu kanałów pozostają następnymi etapami.

Dodatkowe polecenie właściciela w tym etapie: możliwość pracy w programie
podczas wysyłki produktów do Allegro. Przygotowanie/wysyłka paczki jako okno
niemodalne, przycisk Pracuj w programie ukrywa bez zamykania, stały przycisk
w pasku stanu pokazuje postęp i przywraca to samo okno/plan (także zmaksymalizowane).
Dotychczasowy worker i dwuwątkowa pula pozostają; inne moduły mają wolny wątek.
Jeden formularz przygotowania Allegro naraz. Zmiany w katalogu nie zmieniają
zatwierdzonej partii w toku. Zamknięcie programu podczas pracy nadal blokowane;
zakończone ukryte okno zamykane razem z programem. Bez trwałej kolejki ogólnej.
Sprzątanie zakończonych QRunnable nadal wymaga bezczynnej puli jak w0.52;
przy długiej wysyłce wspólny pojedynczy timer50ms zastępuje wiele timerów5ms.
Nie zmieniamy autoDelete ani nie usuwamy sygnałów przed wyjściem run().
