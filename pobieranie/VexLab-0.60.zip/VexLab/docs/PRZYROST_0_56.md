# VexLab 0.56 — edycja wysłanych i aktywnych ofert Allegro

Allegro → zaznacz 1–100 ofert → Więcej działań → Edytuj zaznaczone oferty.
Ołówek przy jednej ofercie otwiera wyłącznie tę ofertę, niezależnie od checkboxów.
Obsługiwane statusy: ACTIVE i INACTIVE. Zgoda offers:write jak przy zapisie szkiców.

1. Pobierz oferty. Tabela pokazuje osobno wartości obecne i wartości po zmianie.
2. Popraw tytuł, SKU lub EAN indywidualnie dla każdej pozycji. Narzędzia nad
   tabelą pozwalają znaleźć/zamienić tekst oraz dodać tekst przed/po tytułach.
   Te operacje nie kopiują SKU ani EAN między ofertami. Wklej SKU / EAN z arkusza
   przyjmuje trzy kolumny: ID Allegro, SKU, EAN. Kody są dopasowywane po ID,
   a puste pola pozostawiają dotychczasowe wartości.
3. Sprawdź podgląd zmian. Błędy są widoczne w odpowiednich wierszach.
4. Zapisz zmiany w Allegro i potwierdź zakres. Każda oferta ma własny wynik.
5. Przy wyniku Do sprawdzenia użyj Sprawdź wyniki zapisu; nie ponawiaj zmiany.
   Kopiuj raport pozwala zachować całą tabelę w arkuszu lub pliku tekstowym.

EAN identyfikuje produkt Katalogu Allegro. Zmiana wymaga jednoznacznego,
istniejącego produktu tej samej kategorii, którego nazwę widać w podglądzie.
Nie tworzymy produktu ani nowej oferty. Zestawy i oferty z dopasowaniami/TecDoc
wymagają zmiany EAN w Allegro; tytuł i SKU nadal można zmieniać w VexLab.
EAN nie jest edycją globalnego wpisu Katalogu Allegro. Ograniczenia aktualizacji
aktywnej oferty ostatecznie ocenia Allegro; odrzucenie widać w wyniku.

Tytuł/SKU są częściowym PATCH bez wysyłania produktu. Przy zmianie EAN
zachowane opis, zdjęcia, pozostałe parametry, ilość produktu i GPSR. Cena,
stan magazynowy, dostawa oraz publikacja nie są zlecanymi zmianami.
Świeży odczyt przed PATCH wykrywa konflikt; API nie oferuje tu transakcji
obejmującej cudzą równoczesną edycję między GET i PATCH. Potwierdzenie GET
obejmuje docelowe pola i chronione dane, a brak pełnego potwierdzenia
zachowuje blokadę oraz wynik Do sprawdzenia.

Liczniki: Zapisane, Do poprawy, Do sprawdzenia, Pominięte. Zatrzymaj kończy
serię po bieżącym żądaniu. Zmiana konta blokuje kolejne wysyłki, także po
ostatnim odczycie przed PATCH. Nieznany wynik/202 jest trwale rejestrowany
w zapisy_allegro; po restarcie zaznacz te same ID i sprawdź wyniki przez GET.
Rejestr jest wspólny z dotychczasowym zapisem szkiców, więc obie ścieżki
wzajemnie blokują niepotwierdzone próby dotyczące tej samej oferty.

Lokalne Produkty i Szkice nie są automatycznie zmieniane. Nie zmieniono
schematu12. Zachowaj katalog danych, zdjęcia, szablony i rejestry przy aktualizacji.
PrestaShop i synchronizacja wspólnych zmian pozostają kolejnym etapem.
Testy automatyczne używają wyłącznie izolowanych danych i atrap API.

Podgląd okna: [ciemny](screenshots/vexlab-edycja-056-dark.png),
[jasny](screenshots/vexlab-edycja-056-light.png).
