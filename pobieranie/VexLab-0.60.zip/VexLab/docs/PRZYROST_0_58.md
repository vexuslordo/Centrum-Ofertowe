# VexLab 0.58 — oferta z Produktu i praca podczas wysyłki

## Utwórz ofertę z lokalnego Produktu

Produkty → zaznacz jeden Produkt → Więcej akcji → Utwórz ofertę z Produktu.
Ta sama akcja jest w menu prawego przycisku myszy przy danym Produkcie.
Pojedynczy edytor otwiera się z nazwą/opisem, SKU, EAN i kopiami zdjęć.
Nagłówek pokazuje lokalnego producenta oraz źródłową cenę z walutą/rodzajem.
Możesz poprawić treść i układ opisu, używać drag & drop oraz dodać zdjęcia.

Cena brutto w PLN/EUR/CZK/HUF trafia do formularza. Cena netto lub inna waluta
jest pokazana jako źródło, a kwotę brutto wpisujesz świadomie. Program nie
zgaduje stawki VAT ani kursu. Długą nazwę zobaczysz w całości, do skrócenia
do limitu75 znaków. Brak zdjęcia/ceny w katalogu nie generuje danych fikcyjnych.

Zapisz szkic zapisuje ofertę powiązaną z ID i wersją Produktu. Dane Produktu
pozostają bez zmian; konflikt wersji przed otwarciem lub zapisem blokuje
użycie nieaktualnego źródła. Edycja samego szkicu pozostaje niezależna.
Ponowne zapisanie tej samej treści z tej samej wersji źródła nie dubluje szkicu.
Zdjęcia są kopiami w danych użytkownika i nie zależą od późniejszych zmian galerii.
Anulowanie nie zapisuje szkicu; kopie zdjęć mogą pozostać jak przy ręcznej ofercie.

Dalej najpierw zapisuje szkic, potem otwiera przygotowanie Allegro. Waluta i
lokalny producent są podstawiane także po powrocie przez Szkice i restarcie.
Różne znane waluty zaznaczonych szkiców wymagają oddzielnych partii. Przy
mieszance źródeł z nieznaną walutą nie wybieramy automatycznie waluty innych.
Producent GPSR i parametr kategorii Allegro nadal wymagają osobnych ustawień.

## Pracuj podczas wysyłki Allegro

Okno Przygotuj oferty Allegro jest niemodalne. Pracuj w programie ukrywa
okno bez zatrzymywania zadania i bez zamykania formularza. Przycisk Allegro
w dolnym pasku pokazuje postęp i przywraca to samo okno oraz jego wyniki.
Możesz przeglądać i edytować katalog, tworzyć szkice i pracować w innych
modułach. Zmiany w Produktach nie zmieniają zatwierdzonej partii w toku.

Zatrzymaj serię działa jak wcześniej po bieżącym żądaniu. Jedno okno
przygotowania Allegro pozostaje otwarte naraz. Kolejnego zlecenia nie
mieszamy z obecną partią. Zamknięcie całego programu podczas pracy nadal
jest blokowane; po zakończeniu ukryte okno zamknie się razem z programem.
Dane wyników i dzienniki nieznanych zapisów mają dotychczasowe zabezpieczenia.
To nie jest trwała ogólna kolejka zadań ani automatyczna synchronizacja.

Dwuwątkowa pula pozwala wykonywać inne operacje w trakcie wysyłki. Sprzątanie
QRunnable nadal czeka na rzeczywiste wyjście puli; jeden wspólny timer50ms
zapobiega mnożeniu timerów podczas długiej wysyłki.

## Dane i sprawdzenia

Schemat12 bez migracji. Dawne szkice mają puste metadane przygotowania;
nowe zachowują je w istniejącym tresc_json, także po edycji. Zachowaj katalog
danych użytkownika podczas aktualizacji. Szkice z Produktu używają istniejącego
FK; usunięcie źródła podlega istniejącej ochronie powiązanych szkiców.

Testy: źródłowe dane i ceny, netto/waluty, kopie zdjęć, anulowanie, FK,
restart/metadane, edycja i deduplikacja, konflikt wersji i różne waluty;
rzeczywisty worker oczekujący w atrapie POST równolegle z odczytem katalogu,
ukrycie/powrót/postęp, blokada zamknięcia i ochrona czasu życia QRunnable.
Bez rzeczywistych zapisów do Allegro. PrestaShop/wybór kanałów to następne kroki.

Podgląd formularza: [ciemny](screenshots/vexlab-oferta-z-produktu-058-dark.png),
[jasny](screenshots/vexlab-oferta-z-produktu-058-light.png).
