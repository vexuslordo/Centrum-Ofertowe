"""Rozszerzenie istniejącej tabeli paczki. Żadne akcje ani ich zakres nie są zastępowane."""

from collections.abc import Callable
from typing import TYPE_CHECKING, cast

from PySide6.QtCore import QEvent, QObject, Qt, QTimer
from PySide6.QtWidgets import (
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QSplitter,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from vexlab.gui.kafelek_kpi import KafelekKPI
from vexlab.gui.panel_walidacji_oferty import PanelWalidacjiOferty
from vexlab.gui.walidacja_paczki_ui import OznaczenieOferty, oznacz_oferte
from vexlab.gui.wiersze_nowych_ofert import WierszNowejOferty
from vexlab.przypadki_uzycia.allegro import SesjaAllegro

if TYPE_CHECKING:
    from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
    from vexlab.gui.paczki_ofert import StronaPaczek


class CentrumNowychOfert(QObject):
    def __init__(
        self, page: "StronaPaczek", host: QWidget, layout: QVBoxLayout, preview: QPushButton
    ) -> None:
        super().__init__(page)
        self.page = page
        self.czytaj_kontekst: Callable[
            [], tuple[DialogNowychSzkicow | None, SesjaAllegro | None]
        ] = lambda: (None, None)
        self.stany: tuple[OznaczenieOferty, ...] = ()
        self.filtr = "wszystkie"
        self._signature: tuple[object, ...] = ()
        self._panel_signature: tuple[object, ...] = ()
        self._szeroki: bool | None = None
        self._dark: bool | None = None
        self._aktualizuje_widok = False
        global_layout = cast(QVBoxLayout, page.layout())
        title_item = global_layout.takeAt(0)
        title = title_item.widget() if title_item else None
        header = QHBoxLayout()
        if title:
            header.addWidget(title, 1)
        header.addWidget(page.recznie)
        global_layout.insertLayout(0, header)
        host.setObjectName("centrumNowychOfert")
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(10)
        toolbar = QHBoxLayout()
        for button, text in (
            (preview, "Podgląd"),
            (page.zapisz_szkice, "Zapisz szkice lokalnie"),
            (page.przygotuj_allegro, "Przygotuj Allegro"),
        ):
            button.setText(text)
            toolbar.addWidget(button)
        page.przygotuj_allegro.setObjectName("primary")
        page.zapisz_szkice.setObjectName("")
        self.szczegoly_przycisk = QPushButton("Walidacja")
        self.szczegoly_przycisk.setCheckable(True)
        self.szczegoly_przycisk.setChecked(True)
        toolbar.addWidget(self.szczegoly_przycisk)
        toolbar.addStretch()
        layout.insertLayout(0, toolbar)
        kpis = QWidget()
        self.kpi_grid = QGridLayout(kpis)
        self.kpi_grid.setContentsMargins(0, 0, 0, 0)
        self.kpi_grid.setSpacing(10)
        self.kpi: dict[str, KafelekKPI] = {}
        for i, (key, name, icon, color) in enumerate(
            (
                ("wszystkie", "Wszystkie oferty", "Produkty", "#0662BB"),
                ("gotowe", "Gotowe do szkicu", "Zamówienia", "#00824D"),
                ("gpsr", "GPSR · problemy", "Raporty", "#997017"),
                ("parametry", "Parametry · problemy", "Produkty", "#6A478C"),
                ("bledy", "Oferty z problemami", "Historia operacji", "#AF2635"),
            )
        ):
            card = KafelekKPI(name, "produkty", "Brak odczytu", symbol=icon, akcent=color)
            card.setFixedHeight(88)
            card.setMinimumWidth(0)
            self.kpi[key] = card
            self.kpi_grid.addWidget(card, 0, i)
        layout.insertWidget(1, kpis)
        self.kpi_host = kpis
        filters = QHBoxLayout()
        self.chipy: dict[str, QPushButton] = {}
        for key, text in (
            ("wszystkie", "Wszystkie"),
            ("gotowe", "Gotowe"),
            ("gpsr", "GPSR"),
            ("parametry", "Parametry"),
            ("ean", "EAN"),
            ("bledy", "Błędy"),
        ):
            button = QPushButton(text)
            button.setCheckable(True)
            button.setChecked(key == "wszystkie")
            button.setObjectName("chipPaczki")
            button.clicked.connect(lambda _checked=False, key=key: self._filtr(key))
            filters.addWidget(button)
            self.chipy[key] = button
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj tytułu, SKU lub EAN…")
        self.szukaj.setAccessibleName("Filtr widocznych ofert z paczki")
        self.szukaj.textChanged.connect(self.filtruj)
        filters.addWidget(self.szukaj, 1)
        layout.insertLayout(2, filters)
        self.hint = QLabel("")
        self.hint.setWordWrap(True)
        self.hint.setObjectName("opis")
        layout.insertWidget(3, self.hint)
        self.panel = PanelWalidacjiOferty()
        self.panel.podglad.connect(page.szczegoly)
        self.panel.przygotowanie.connect(page.przygotuj_allegro.click)
        self.panel.problem.connect(self.przejdz_do_problemu)
        self.split = QSplitter(Qt.Orientation.Horizontal)
        self.split.setChildrenCollapsible(False)
        self.split.addWidget(page.tabela)
        self.split.addWidget(self.panel)
        self.split.setStretchFactor(0, 1)
        self.split.setSizes([1000, 360])
        layout.addWidget(self.split, 1)
        self.szczegoly_przycisk.toggled.connect(self.panel.setVisible)
        self.postep = QProgressBar()
        self.postep.setMaximumHeight(18)
        self.postep.setAccessibleName("Postęp potwierdzonego przygotowania szkiców Allegro")
        layout.addWidget(self.postep)
        self.podsumowanie = QLabel()
        self.podsumowanie.setWordWrap(True)
        self.podsumowanie.setObjectName("opis")
        layout.addWidget(self.podsumowanie)
        table = page.tabela
        table.setColumnCount(10)
        table.setHorizontalHeaderItem(9, QTableWidgetItem("Status"))
        table.horizontalHeader().moveSection(table.horizontalHeader().visualIndex(9), 2)
        table.horizontalHeader().setStretchLastSection(False)
        table.horizontalHeader().setMinimumHeight(40)
        table.setShowGrid(False)
        self.delegat = WierszNowejOferty(table)
        table.setItemDelegateForColumn(2, self.delegat)
        table.setItemDelegateForColumn(9, self.delegat)
        table.currentCellChanged.connect(lambda *_: self.pokaz_panel())
        self.timer = QTimer(self)
        self.timer.setInterval(750)
        self.timer.timeout.connect(self.odswiez)
        self.timer.start()
        page.installEventFilter(self)
        self.panel.installEventFilter(self)
        self.kolumny()
        self.odswiez(wymus=True)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if self._aktualizuje_widok:
            return False
        if event.type() in (QEvent.Type.Show, QEvent.Type.Resize, QEvent.Type.PaletteChange):
            self._aktualizuje_widok = True
            try:
                if obj is self.page:
                    self.rozmiar()
                    self.odswiez(wymus=event.type() == QEvent.Type.Show)
                elif obj is self.panel:
                    self._panel_signature = ()
                    self.pokaz_panel()
            finally:
                self._aktualizuje_widok = False
        return False

    def kolumny(self) -> None:
        table = self.page.tabela
        for col in (0, 1, 7):
            table.setColumnHidden(col, True)
        for col, width in ((8, 84), (9, 175), (3, 140), (4, 130), (5, 65), (6, 65)):
            table.setColumnWidth(col, width)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        item = table.horizontalHeaderItem(2)
        if item is not None:
            item.setText("Produkt / SKU")
        table.setColumnWidth(2, max(180, table.columnWidth(2)))

    def _kontekst(self) -> tuple["DialogNowychSzkicow | None", SesjaAllegro | None]:
        dialog, session = self.czytaj_kontekst()
        if (
            dialog is None
            or not isValid(dialog)
            or dialog.nieaktualny
            or dialog.sesja is not session
        ):
            return None, session
        return dialog, session

    def odswiez(self, *, wymus: bool = False) -> None:
        if not isValid(self.page):
            return
        if not wymus and not self.page.isVisible():
            return
        d, session = self._kontekst()
        producer = d.producent_lokalny.currentText() if d else ""
        signature = (
            id(self.page.oferty),
            id(d),
            id(session),
            id(d.oferty) if d else 0,
            id(d.plany) if d else 0,
            id(d.wyniki) if d else 0,
            d.trwa if d else False,
            producer,
            d._blad_operacji if d else "",
        )
        if not wymus and signature == self._signature:
            self.pokaz_panel()
            return
        self._signature = signature
        rows = []
        for i, offer in enumerate(self.page.oferty):
            match = bool(d and len(d.oferty) == len(self.page.oferty) and d.oferty[i] == offer)
            plan = (
                d.plany[i]
                if match and d and i < len(d.plany) and d.plany[i].oferta == offer
                else None
            )
            result = d.wyniki[i] if match and d and i < len(d.wyniki) else None
            rows.append(
                oznacz_oferte(
                    offer,
                    plan,
                    result,
                    mozna_utworzyc=bool(match and d and d._mozna_wyslac(i)),
                    trwa=bool(match and d and d.trwa),
                    producent=producer if match else "",
                    producent_wymagany=bool(match and d and d.katalog_uzytkownika is not None),
                    blad_operacji=d._blad_operacji if match and d else "",
                    zmieniona=bool(d and len(d.oferty) == len(self.page.oferty) and not match),
                )
            )
        self.stany = tuple(rows)
        for i, state in enumerate(self.stany):
            item = QTableWidgetItem(state.status)
            item.setData(Qt.ItemDataRole.UserRole, state.ton)
            item.setToolTip(
                "\n".join(state.problemy)
                or state.status + ". Gotowość dotyczy szkicu, nie publikacji."
            )
            self.page.tabela.setItem(i, 9, item)
        count = len(self.stany)
        ready = sum(s.gotowa for s in self.stany)
        for key, card in self.kpi.items():
            value = (
                count
                if key == "wszystkie"
                else ready
                if key == "gotowe"
                else sum(key in s.grupy for s in self.stany)
            )
            card.liczba.setText(str(value))
            card.podpis.setText(
                "Cała paczka"
                if key == "wszystkie"
                else "Z istniejącego sprawdzenia"
                if any(s.plan is not None for s in self.stany)
                else "Brak sprawdzenia Allegro"
            )
        instruction = (
            "Uzupełnij ustawienia w oknie przygotowania i kliknij „Sprawdź paczkę”. "
            if not any(s.plan is not None for s in self.stany)
            else "Popraw wskazane problemy w przygotowaniu; zapis do Allegro wymaga potwierdzenia. "
        )
        self.hint.setText(
            instruction + "Filtry zmieniają tylko widok. Zapis szkiców i przygotowanie "
            "Allegro obejmują całą paczkę. "
            "Niesprawdzone dane nie są oznaczane jako poprawne."
        )
        self.postep.setRange(0, max(1, count))
        self.postep.setValue(ready)
        self.postep.setFormat(
            f"{ready} / {count} gotowych do szkicu · {round(100 * ready / count) if count else 0}%"
        )
        self.podsumowanie.setText(
            f"GPSR: {sum('gpsr' in s.grupy for s in self.stany)} · "
            f"Parametry: {sum('parametry' in s.grupy for s in self.stany)} · "
            f"EAN: {sum('ean' in s.grupy for s in self.stany)} ofert ze zgłoszonym problemem. "
            "Publikacja pozostaje osobnym działaniem."
        )
        self.page.przygotuj_allegro.setText(
            "Wróć do przygotowania szkiców…" if d is not None else "Przygotuj szkice do wysyłki…"
        )
        self.page.przygotuj_allegro.setToolTip(
            f"Otwiera istniejące przygotowanie dla wszystkich {count} ofert. "
            "Nie wysyła i nie publikuje automatycznie; zakres wybierzesz w przygotowaniu."
        )
        self.panel.przygotuj.setVisible(self.page.allegro_dostepne)
        self.panel.przygotuj.setEnabled(self.page.przygotuj_allegro.isEnabled())
        self.filtruj()
        self._panel_signature = ()
        self.pokaz_panel()

    def _filtr(self, key: str) -> None:
        self.filtr = key
        for name, button in self.chipy.items():
            button.setChecked(name == key)
        self.filtruj()

    def filtruj(self) -> None:
        if len(self.stany) != len(self.page.oferty):
            self.odswiez(wymus=True)
            return
        search = self.szukaj.text().strip().casefold()
        for i, (offer, state) in enumerate(zip(self.page.oferty, self.stany, strict=True)):
            match = self.filtr == "wszystkie" or self.filtr in state.grupy
            match = match and search in (offer.tytul + " " + offer.sku + " " + offer.ean).casefold()
            self.page.tabela.setRowHidden(i, not match)
        row = self.page.tabela.currentRow()
        if row >= 0 and self.page.tabela.isRowHidden(row):
            self.page.tabela.clearSelection()
            self.page.tabela.setCurrentCell(-1, -1)
        self.pokaz_panel()

    def pokaz_panel(self) -> None:
        row = self.page.tabela.currentRow()
        if not 0 <= row < len(self.stany) or self.page.tabela.isRowHidden(row):
            if self._panel_signature:
                self.panel.wyczysc()
                self._panel_signature = ()
            return
        offer, state = self.page.oferty[row], self.stany[row]
        url = next(iter(offer.zdjecia), "") or next(
            (e.adres for section in offer.sekcje for e in section if e.typ == "obraz"), ""
        )
        data = self.page.obrazy_tabeli.cache.get(url, b"")
        signature = (row, id(state), id(data), self.panel.width())
        if signature != self._panel_signature:
            self._panel_signature = signature
            self.panel.pokaz(offer, state, data)

    def przejdz_do_problemu(self, key: str) -> None:
        row = self.page.tabela.currentRow()
        if not 0 <= row < len(self.stany):
            return
        if key == "zrodlo":
            self.page.szczegoly()
            return
        d, _ = self._kontekst()
        if d is None:
            # Ten sam przycisk i ten sam sygnał; bez nowego zakresu i nowego procesu.
            self.page.przygotuj_allegro.click()
            d, _ = self._kontekst()
        if d is None or row >= len(d.oferty) or d.oferty[row] != self.page.oferty[row]:
            return
        if d.trwa or d.nieaktualny:
            return
        d.show()
        d.raise_()
        d.activateWindow()
        d.filtr.setCurrentIndex(0)
        d.tabela.selectRow(row)
        d.tabela.setCurrentCell(row, 4)
        targets = {
            "gpsr": d.sprzedaz_przycisk,
            "parametry": d.uzupelnij_przycisk,
            "ean": d.produkt_przycisk,
            "produkt": d.produkt_przycisk,
            "kategoria": d.produkt_przycisk,
            "vat": d.vat_przycisk,
            "producent": d.producent_lokalny,
        }
        if key in targets:
            targets[key].setFocus()
        else:
            d.pomoc_wysylki.tresc.setFocus()

    def rozmiar(self) -> None:
        wide = self.page.width() >= 1400
        if wide != self._szeroki:
            self._szeroki = wide
            self.szczegoly_przycisk.setChecked(wide)
            self.split.setSizes([max(650, self.page.width() - 400), 360])
        dark = self.page.palette().color(self.page.palette().ColorRole.Window).lightness() < 128
        if dark != self._dark:
            self._dark = dark
            border = "#203B51" if dark else "#CDDBEE"
            self.page.setStyleSheet(f"""
                QFrame#panelWalidacjiPaczki {{border:1px solid {border};border-radius:9px;}}
                QLabel#liczbaDashboardu {{font-size:22px;font-weight:600;}}
                QLabel#podpisDashboardu {{font-size:11px;}}
                QPushButton#chipPaczki {{border-radius:12px;padding:4px 10px;}}
            """)
            self._panel_signature = ()
            self.pokaz_panel()
