"""Prawy panel tego samego widoku paczki. Zdjęcie wyłącznie z istniejącego cache."""

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.statusy_zamowien import kolory_odznaki
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.gui.walidacja_paczki_ui import OznaczenieOferty
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad

KODY_TONOW = {
    "zielony": "NEW",
    "niebieski": "PROCESSING",
    "czerwony": "CANCELLED",
    "zloty": "SUSPENDED",
    "szary": "",
}


def kolor_opisu(label: QLabel, ton: str) -> None:
    dark = label.palette().color(label.palette().ColorRole.Window).lightness() < 128
    _, color, _ = kolory_odznaki(KODY_TONOW[ton], dark)
    label.setStyleSheet(f"color:{color};background:transparent;border:0;")


class PanelWalidacjiOferty(QFrame):
    problem = Signal(str)
    podglad = Signal()
    przygotowanie = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("panelWalidacjiPaczki")
        self.setMinimumWidth(0)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(8)
        header = etykieta("Walidacja oferty")
        header.setObjectName("tytulSekcjiAllegro")
        layout.addWidget(header)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        body = QWidget()
        box = QVBoxLayout(body)
        box.setContentsMargins(0, 0, 0, 0)
        box.setSpacing(7)
        self.foto = QLabel("Wybierz ofertę z tabeli")
        self.foto.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.foto.setFixedHeight(150)
        self.foto.setWordWrap(True)
        self.foto.setAccessibleName("Zdjęcie wybranej oferty")
        box.addWidget(self.foto)
        self.nazwa = etykieta("")
        self.nazwa.setObjectName("tytulSekcjiAllegro")
        box.addWidget(self.nazwa)
        self.status = etykieta("")
        box.addWidget(self.status)
        self.pola: dict[str, QLabel] = {}
        for name in ("SKU", "EAN", "Cena", "Ilość"):
            row = QHBoxLayout()
            caption = etykieta(name)
            caption.setObjectName("opis")
            row.addWidget(caption)
            value = etykieta("—")
            value.setMinimumWidth(0)
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            value.setAccessibleName(name + " wybranej oferty")
            row.addWidget(value, 1)
            self.pola[name] = value
            box.addLayout(row)
        title = etykieta("Weryfikacja")
        title.setObjectName("tytulSekcjiAllegro")
        box.addWidget(title)
        self.kontrole: dict[str, QLabel] = {}
        for name in (
            "Zdjęcia",
            "GPSR",
            "Parametry",
            "Producent lokalny",
            "Kategoria",
            "VAT",
            "EAN",
            "Produkt Allegro",
        ):
            label = etykieta(name + " · Nie sprawdzono")
            label.setAccessibleName("Weryfikacja: " + name)
            self.kontrole[name] = label
            box.addWidget(label)
        title = etykieta("Problemy")
        title.setObjectName("tytulSekcjiAllegro")
        box.addWidget(title)
        self.problemy = etykieta("Wybierz wiersz, aby zobaczyć dostępne wyniki.")
        self.problemy.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        box.addWidget(self.problemy)
        self.linki: dict[str, QPushButton] = {}
        for key, name in (
            ("gpsr", "GPSR, dostawa i warunki…"),
            ("parametry", "Parametry produktu…"),
            ("produkt", "Produkt Allegro / kategoria…"),
            ("ean", "Sprawdź EAN i dopasowanie…"),
            ("vat", "VAT…"),
            ("producent", "Producent lokalny…"),
            ("zrodlo", "Podgląd zdjęć, opisu i sekcji…"),
            ("bledy", "Powód i poprawki w przygotowaniu…"),
        ):
            button = QPushButton(name)
            button.clicked.connect(lambda _checked=False, key=key: self.problem.emit(key))
            button.hide()
            box.addWidget(button)
            self.linki[key] = button
        box.addStretch()
        scroll.setWidget(body)
        layout.addWidget(scroll, 1)
        self.przygotuj = QPushButton("Ustawienia i przygotowanie szkiców…")
        self.przygotuj.clicked.connect(self.przygotowanie)
        self.przygotuj.setToolTip(
            "Otwiera przygotowanie całej paczki: dane, GPSR, VAT, parametry i sprawdzenie. "
            "Nie wysyła automatycznie."
        )
        layout.addWidget(self.przygotuj)
        preview = QPushButton("Podgląd oferty")
        preview.clicked.connect(self.podglad)
        layout.addWidget(preview)
        self.wyczysc()

    def wyczysc(self) -> None:
        self.foto.clear()
        self.foto.setText("Wybierz ofertę z tabeli")
        self.nazwa.clear()
        self.status.clear()
        for label in self.pola.values():
            label.setText("—")
        for name, label in self.kontrole.items():
            label.setText(name + " · Nie sprawdzono")
            kolor_opisu(label, "szary")
        for button in self.linki.values():
            button.hide()
        self.problemy.setText("Wybierz wiersz, aby zobaczyć dostępne wyniki.")

    def pokaz(self, oferta: OfertaPodglad, stan: OznaczenieOferty, obraz: bytes = b"") -> None:
        self.nazwa.setText(oferta.tytul)
        self.status.setText("● " + stan.status)
        kolor_opisu(self.status, stan.ton)
        self.pola["SKU"].setText(oferta.sku or "—")
        self.pola["EAN"].setText(oferta.ean or "Brak w paczce")
        price = oferta.cena or "—"
        quantity = "Nie ustawiono w przygotowaniu"
        if stan.plan:
            price = (
                (stan.plan.ustawienia.cena or oferta.cena or "—")
                + " "
                + stan.plan.ustawienia.waluta
            )
            quantity = str(stan.plan.ustawienia.ilosc)
        else:
            price += " · waluta nieustalona"
        self.pola["Cena"].setText(price)
        self.pola["Ilość"].setText(quantity)
        for name, text, tone in stan.kontrole:
            label = self.kontrole[name]
            label.setText(
                ("✓ " if tone == "zielony" else "! " if tone == "czerwony" else "— ")
                + name
                + " · "
                + text
            )
            kolor_opisu(label, tone)
        self.problemy.setText(
            "\n\n".join(stan.problemy)
            or (
                "Brak zgłoszonych błędów w planie szkicu."
                if stan.gotowa
                else "Brak potwierdzonej pełnej walidacji. Użyj istniejącego przygotowania Allegro."
            )
        )
        for key, button in self.linki.items():
            show = key in stan.grupy or key == "produkt" and "kategoria" in stan.grupy
            if key == "zrodlo":
                show = bool(stan.grupy & {"zdjecia", "opis"}) or bool(oferta.problemy)
            button.setVisible(show)
        pix = QPixmap()
        self.foto.clear()
        if obraz and pix.loadFromData(obraz):
            self.foto.setPixmap(
                pix.scaled(
                    max(180, self.width() - 35),
                    145,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
        else:
            self.foto.setText(
                "Podgląd zdjęcia z paczki" if oferta.zdjecia else "Brak zdjęcia w galerii paczki"
            )
