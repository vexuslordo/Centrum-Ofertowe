"""Mapowanie własnych ofert do importu katalogu; brak publikacji ACTIVE."""

import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field, replace
from urllib.parse import urlencode

from vexlab.kanaly.allegro import hosty, tekst
from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro, TransportAllegro
from vexlab.przypadki_uzycia.katalog_allegro import OfertaKatalogu


@dataclass
class _OdczytListy:
    konto: tuple[str, str]
    oferty: dict[str, OfertaKatalogu] = field(default_factory=dict)
    razem: int | None = None
    limit: int = 100
    pierwsze: tuple[str, ...] = ()


class KatalogAllegroAPI(NoweSzkiceAPI):
    def __init__(self, transport: TransportAllegro) -> None:
        super().__init__(transport)
        self._odczyt_listy: _OdczytListy | None = None

    def _strona_listy(
        self, s: SesjaAllegro, offset: int, limit: int, stop: Callable[[], bool]
    ) -> dict[str, object]:
        for proba in range(3):
            if stop():
                raise BladAllegro("ANULOWANO", "Zatrzymano pobieranie. Możesz je wznowić.")
            try:
                return self._get(
                    s.srodowisko,
                    s.token,
                    "/sale/offers?" + urlencode({"limit": limit, "offset": offset}),
                )
            except BladAllegro as exc:
                if exc.kod != "SIEC" or proba == 2:
                    raise
                for _ in range(10 * (proba + 1)):
                    if stop():
                        raise BladAllegro(
                            "ANULOWANO", "Zatrzymano pobieranie. Możesz je wznowić."
                        ) from None
                    time.sleep(0.1)
        raise AssertionError("Nieosiągalny koniec ponawiania odczytu")

    @staticmethod
    def _odczytaj_strone(
        d: dict[str, object], limit: int
    ) -> tuple[tuple[OfertaKatalogu, ...], int]:
        rows, total = d["offers"], d["totalCount"]
        if (
            not isinstance(rows, list)
            or type(total) is not int
            or not 0 <= total <= 100000
            or len(rows) > limit
        ):
            raise ValueError("lista")
        oferty = []
        for row in rows:
            ident = tekst(row, "id", 100)
            if not ident.isdigit():
                raise ValueError("id")
            external = row.get("external") or {}
            sku = external.get("id") or ""
            if not isinstance(sku, str) or len(sku) > 100:
                raise ValueError("sku")
            oferty.append(
                OfertaKatalogu(
                    ident,
                    tekst(row, "name"),
                    sku,
                    tekst(row["publication"], "status", 32),
                    sku_zrodlowe=sku,
                )
            )
        return tuple(oferty), total

    def lista_katalogu(
        self,
        s: SesjaAllegro,
        stop: Callable[[], bool],
        postep: Callable[[int, int], None] | None = None,
    ) -> tuple[OfertaKatalogu, ...]:
        konto = (s.srodowisko.value, s.konto.id)
        state = self._odczyt_listy
        if state is None or state.konto != konto:
            state = _OdczytListy(konto)
            self._odczyt_listy = state
        # Przed wznowieniem sprawdzamy początek listy i licznik konta.
        if state.oferty:
            if postep is not None:
                postep(len(state.oferty), state.razem or 0)
            try:
                raw = self._strona_listy(s, 0, len(state.pierwsze), stop)
                first, total = self._odczytaj_strone(raw, len(state.pierwsze))
                if total != state.razem or tuple(o.ident for o in first) != state.pierwsze:
                    state = _OdczytListy(konto)
                    self._odczyt_listy = state
                    if postep is not None:
                        postep(0, total)
            except BladAllegro as exc:
                if exc.kod != "ROZMIAR":
                    raise
                state = _OdczytListy(konto, limit=50)
                self._odczyt_listy = state
            except (KeyError, ValueError, TypeError, AttributeError):
                self._odczyt_listy = None
                raise BladAllegro(
                    "IMPORT", "Lista konta zmieniła się. Pobierz ją ponownie."
                ) from None
        while True:
            offset = len(state.oferty)
            try:
                raw = self._strona_listy(s, offset, state.limit, stop)
            except BladAllegro as exc:
                if exc.kod == "ROZMIAR" and state.limit > 1:
                    state.limit = max(1, state.limit // 2)
                    continue
                raise
            try:
                rows, total = self._odczytaj_strone(raw, state.limit)
                if state.razem is not None and state.razem != total:
                    raise ValueError("zmieniona lista")
                ids = tuple(o.ident for o in rows)
                if len(set(ids)) != len(ids) or any(i in state.oferty for i in ids):
                    raise ValueError("powtórzone id")
                if offset + len(rows) > total or (not rows and offset != total):
                    raise ValueError("niepełna lista")
            except (KeyError, ValueError, TypeError, AttributeError):
                self._odczyt_listy = None
                raise BladAllegro(
                    "IMPORT",
                    "Lista konta zmieniła się, jest niepełna lub przekracza 100 000 ofert. "
                    "Pobierz ponownie.",
                ) from None
            # Zachowujemy tylko kompletną, sprawdzoną stronę, bez tokenu sesji.
            if not state.oferty:
                state.pierwsze = ids
            state.razem = total
            state.oferty.update((o.ident, o) for o in rows)
            if postep is not None:
                postep(len(state.oferty), total)
            if len(state.oferty) == total:
                self._odczyt_listy = None
                return tuple(state.oferty.values())

    def szczegoly_katalogu(self, s: SesjaAllegro, oferta: OfertaKatalogu) -> OfertaKatalogu:
        d = self._get(s.srodowisko, s.token, self._sciezka(oferta.ident))
        try:
            category = tekst(d["category"], "id", 100)
            if len(d.get("productSet", [])) > 1:
                raise BladAllegro(
                    "IMPORT",
                    "Oferta zestawowa wymaga ręcznego rozdzielenia produktów: " + oferta.ident,
                )
            params = []
            for part in d.get("productSet", []):
                params.extend(part["product"].get("parameters", []))
            params.extend(d.get("parameters", []))
            # Wartości słownikowe (Producent/Marka) zwracane są zwykle jako valuesIds.
            metadata = self.nowy_produkt(s, category)

            def value(names: tuple[str, ...]) -> str:
                for name in names:
                    definitions = [
                        p for p in metadata.parametry if p.nazwa.strip().casefold() == name
                    ]
                    for definition in definitions:
                        row = next((p for p in params if p.get("id") == definition.id), None)
                        if not row:
                            continue
                        values = row.get("values") or []
                        if values:
                            if (
                                not isinstance(values, list)
                                or len(values) != 1
                                or any(not isinstance(v, str) for v in values)
                            ):
                                raise ValueError("wartości")
                            return str(values[0]).strip()
                        ids = row.get("valuesIds") or []
                        dictionary = dict(definition.slownik)
                        if ids:
                            if len(ids) != 1 or ids[0] not in dictionary:
                                raise ValueError("nierozpoznany producent")
                            return dictionary[ids[0]].strip()
                return ""

            producent = value(("producent", "marka"))
            ean = value(("ean (gtin)", "ean", "gtin"))
            texts = []
            for section in (d.get("description") or {}).get("sections", []):
                for item in section["items"]:
                    if item.get("type") == "TEXT":
                        texts.append(tekst(item, "content", 100000))
            images = tuple(tekst(image, "url", 4096) for image in d.get("images", []))
            if any(not url.startswith("https://") for url in images):
                raise ValueError("zdjęcia")
            return replace(
                oferta,
                nazwa=tekst(d, "name"),
                status=tekst(d["publication"], "status"),
                ean=ean,
                producent=producent,
                opis="\n".join(texts),
                zdjecia=images[:16],
            )
        except (KeyError, ValueError, TypeError, AttributeError):
            raise BladAllegro(
                "IMPORT",
                "Nie udało się rozpoznać danych produktu/producenta oferty " + oferta.ident,
            ) from None

    def status_katalogu(self, s: SesjaAllegro, ident: str) -> str:
        d = self._get(s.srodowisko, s.token, self._sciezka(ident))
        try:
            return tekst(d["publication"], "status", 32)
        except (KeyError, ValueError, TypeError):
            raise BladAllegro("IMPORT", "Nie udało się odczytać statusu oferty.") from None

    def zakoncz_oferte(self, s: SesjaAllegro, ident: str) -> None:
        if time.monotonic() < self.odczekaj.get((s.srodowisko.value, ident), 0):
            raise BladAllegro(
                "ODRZUCONO", "Odczekaj przed ponownym zakończeniem zgodnie z limitem Allegro."
            )
        _, host = hosty(s.srodowisko)
        r = self.transport_zapisu.wyslij(
            "PATCH",
            host + self._sciezka(ident),
            self._naglowki(s),
            json.dumps({"publication": {"status": "ENDED"}}).encode(),
        )
        if r.status == 429:
            self.odczekaj[(s.srodowisko.value, ident)] = time.monotonic() + max(1, r.odstep)
        if r.status not in (200, 202):
            raise BladAllegro(
                "ODRZUCONO" if r.status in (400, 401, 403, 404, 409, 422, 429) else "ZAKONCZENIE",
                f"Nie potwierdzono zakończenia (HTTP {r.status}). Sprawdź wynik odczytem.",
            )
