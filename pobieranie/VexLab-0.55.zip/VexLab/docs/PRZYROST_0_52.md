# VexLab 0.52 — publikacja szkiców i wznowienie pobierania Allegro

## Opublikuj szkice

**Allegro → zaznacz szkice checkboxami → Więcej działań → Opublikuj szkice…**.
Bez checkboxów używany jest wskazany wiersz. Jedna seria obejmuje do 100 ofert.

Okno pobiera aktualne tytuły, ceny, ilości i statusy. Sprawdź je, następnie wybierz **Opublikuj…**. Osobne potwierdzenie wskazuje konto, środowisko i liczbę szkiców; domyślna odpowiedź to **Nie**. Dopiero odpowiedź Tak zleca uruchomienie sprzedaży. Tworzenie szkiców z ZIP/ręcznie nadal nie publikuje automatycznie.

Tylko INACTIVE może otrzymać nową komendę. ACTIVE jest pomijane jako już aktywne, ENDED nie jest wznawiane. Zmiana danych od podglądu blokuje zlecenie i wymaga ponownego sprawdzenia. Ilość/cena/waluta muszą być uzupełnione; pozostałe wymagania sprawdza Allegro. Ostatecznie publikacja może zostać odrzucona ze wskazaniem błędów API.

Wynik **Opublikowano** wymaga odczytu ACTIVE. Samo przyjęcie komendy lub jej raport SUCCESS nie wystarcza. **Do sprawdzenia** oznacza brak potwierdzenia — przycisk **Sprawdź wynik** wyłącznie odczytuje stan. Timeout lub nieznany wynik nie ponawia PUT. Po restarcie wybierz te same oferty na tym samym koncie: dziennik kieruje do odczytu poprzedniej komendy. Po jednoznacznym odrzuceniu można poprawić dane, ponownie sprawdzić i osobno potwierdzić nową próbę.

Zatrzymaj / zmiana konta kończy serię przed następną komendą; nie cofa wysłanej. Wymagane istniejące uprawnienie allegro:api:sale:offers:write i zgoda na zapis ofert. Odczyt wyniku nie wymaga nowej lokalnej zgody na zapis, choć serwer wymaga właściwych uprawnień tokenu.

Dziennik techniczny **publikacje_allegro/rejestr.sqlite3** w katalogu danych przechowuje tylko skrót kontekstu i UUID komendy. Atomowe rozpoczęcie blokuje równoległe wysłanie dla tego samego ID, a warunkowe zakończenie nie usuwa nowszej próby. Uszkodzony dziennik blokuje zapis i jest zachowywany. Zachowaj go przy przenoszeniu aplikacji. Katalog produktów nadal ma schemat12; brak migracji użytkowej bazy.

Odcisk porównuje konfigurację oferty tuż przed zleceniem. API komendy nie udostępnia transakcyjnego warunku If-Match dla tych danych; odczyt nie blokuje równoczesnej edycji w Allegro.

## Pobieranie produktów nie zaczyna od zera po błędzie sieci

GET listy ponawiany jest do trzech razy dla tej samej strony po braku odpowiedzi. Po dalszym błędzie przycisk zmienia się na **Wznów pobieranie**, z zachowaniem licznika (np. 4300 z 14292).
Kompletne odebrane strony pozostają w pamięci programu, także po zamknięciu samego okna. Wznowienie sprawdza pierwszą stronę i licznik konta, następnie pobiera brakujące strony. Zmiana początku lub liczby ofert rozpoczyna nowy pełny odczyt, aby nie mieszać list. Zmiana konta/środowiska nie wykorzystuje poprzedniego odczytu.

Niepełna lista nie jest zapisywana w Produktach. Błędy uprawnień nie są automatycznie ponawiane jak błąd sieci. Po zamknięciu całego programu pobieranie zacznie od początku — ta pamięć wznowienia nie jest zapisem na dysku. Bez zmian Produktów, zdjęć i istniejących plików użytkownika.

## Weryfikacja

Tymczasowe bazy i atrapy API: publikacja i GET ACTIVE, timeout/restart bez drugiego PUT, odrzucenie i nowa jawna próba, raport FAIL, zmiana danych/konta, wybór checkboxów, domyślna odmowa, blokada równoległego rozpoczęcia i warunkowe usunięcie, uszkodzony dziennik, dokładny transport PUT, limity429, odcisk bez zmiennych czasów walidacji, wznowienie stronicowania i izolacja kont, oba motywy i DPI. Nie uruchamiano rzeczywistej sprzedaży ani testów na bazie użytkownika.

## Czas życia zadań Qt

Kontrola powtórnych przebiegów ujawniła natywne przerwanie w obsłudze zdarzeń Qt. Zmieniono własność QRunnable: okno zachowuje zadanie do rzeczywistego opuszczenia puli wątków, a sygnały są zwalniane w GUI. Sam sygnał zakończenia nie wystarcza do usunięcia zadania. Test wymusza przerwę między wysłaniem sygnału a wyjściem wątku i sprawdza blokadę zamknięcia okna do końca pracy.
