# VexLab 0.51 — oferty ręcznie, zdjęcia z dysku i wysyłka lokalnych szkiców

## Utwórz ręcznie

**Allegro → Nowa oferta** otwiera formularz bez paczki. To samo wejście jest w **Nowe oferty → Utwórz ręcznie…**. Dotychczasowe wczytywanie ZIP pozostaje obok.

Wypełnij SKU i tytuł. Możesz od razu dodać EAN, roboczą cenę i zdjęcia. W zakładce **Opis i podgląd** działa ten sam wizualny edytor sekcji, tekstów i zdjęć co w lokalnych szkicach.

- **Zapisz szkic lokalnie** zapisuje treść w Szkicach i zamyka formularz.
- **Zapisz i przygotuj Allegro…** zapisuje lokalnie, następnie otwiera wspólne przygotowanie Allegro.
- Samo otwarcie lub zamknięcie formularza nie tworzy szkicu ani produktu.

Cena jest robocza. Walutę brutto trzeba jawnie wskazać w kolejnym oknie. Tam wybierasz kategorię/produkt, ilość, parametry, GPSR, dostawy, VAT i sprawdzasz dane. Dopiero osobne potwierdzenie tworzy zdalny szkic. Sprzedaż nie zostaje uruchomiona. Brak podłączonego Allegro pozostawia zapisany szkic lokalny do późniejszego przygotowania.

## Zdjęcia z dysku

**Dodaj zdjęcia z dysku…** obsługuje JPEG, PNG i WebP. Łącznie do 16 różnych zdjęć w galerii i opisie. Źródło maks. 8 MiB / 16 megapikseli; zdjęcia są normalizowane do JPEG o dłuższym boku do 1600 px, tak jak dotychczasowe media.
Kopie trafiają do **zdjecia_ofert** w katalogu danych użytkownika. Szkic zapisuje identyfikator z sumą SHA256 zamiast ścieżki oryginału. Możesz potem przenieść oryginalny plik. Kopia nadal działa po restarcie i aktualizacji; przy przenoszeniu VexLab zachowaj cały katalog danych.

Podgląd i miniatury przygotowania Allegro odczytują lokalne kopie. Po potwierdzeniu wysyłki JPEG trafia binarnie na serwer zdjęć Allegro; dopiero otrzymany adres Allegro jest umieszczany w ofercie. Adresy HTTPS również pozostają obsługiwane. Brak/uszkodzenie kopii blokuje tworzenie oferty.

Przycisk usuwania zdjęć usuwa je z galerii bieżącej oferty. Jeżeli zdjęcie dodano już do sekcji opisu, usuń także odpowiednią sekcję lub jej element. Kopie w katalogu danych pozostają — mogą należeć do innych szkiców. Jawne dodanie zdjęć zachowuje ich kopie nawet po anulowaniu samego formularza; aplikacja nie kasuje automatycznie tych danych.

## Praca z zapisanymi szkicami

**Szkice → zaznacz pozycje → Przygotuj Allegro…** przekazuje dokładnie zaznaczone treści do tej samej walidacji i zabezpieczeń przed duplikacją. Działa także dla szkiców zapisanych z ZIP i po ponownym uruchomieniu. Lokalny zapis jest atomowy z kopią bazy i dotychczasową deduplikacją. Nie tworzy Produktów w katalogu, nie zmienia istniejących ofert zdalnych.

Schemat bazy pozostaje 12; poprzednie dane i migracje bez zmian. Własne teksty bezpieczeństwa i taryfy z 0.50 nadal działają. Wspólna praca Allegro/PrestaShop, synchronizacja zmian, publikacja sprzedaży, zamówienia i Subiekt pozostają dalszymi etapami.

Weryfikacja: walidacja danych, otwarcie/anulowanie, zachowanie treści i układu po restarcie, deduplikacja, kopie zdjęć po usunięciu oryginału, integralność plików, upload binarny i zamiana odwołań na URL Allegro, właściwy wybór lokalnych szkiców, oba motywy i DPI. Testy wyłącznie na tymczasowych danych i atrapach API, bez rzeczywistych publikacji.
