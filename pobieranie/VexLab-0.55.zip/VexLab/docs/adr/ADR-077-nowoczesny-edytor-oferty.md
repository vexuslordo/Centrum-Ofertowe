# ADR-077 — nowoczesny wygląd ręcznej oferty

Status: wdrożenie polecenia właściciela „Zrób mi to bardzo nowocześnie”, 2026-11-16.

Scenariusz: jedna przewijana strona z danymi, galerią i sekcjami opisu.
Sukces: czytelna hierarchia, zaokrąglone karty, wyraźne miejsce upuszczania,
spójne akcenty niebieskie i klawiatura w obu motywach oraz przy większym DPI.
Zmiana wyłącznie GUI: zachowane drag & drop, 64 px miniatury, walidacja,
lokalny zapis i osobny krok Allegro. Brak zmian domeny, portów, SQL, migracji,
transakcji i efektów zewnętrznych. Dane nadal należą do użytkownika.
Kolory powierzchni i tekstu pochodzą z palety aplikacji; styl ograniczony
selektorem do ręcznego edytora, bez zmiany innych ekranów.
