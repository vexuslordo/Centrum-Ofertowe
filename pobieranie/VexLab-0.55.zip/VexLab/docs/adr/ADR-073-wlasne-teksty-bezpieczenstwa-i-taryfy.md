# ADR-073 — nazwane teksty użytkownika do przygotowania ofert

Status: zaakceptowane w zakresie polecenia właściciela z 15.11.2026.

Właściciel chce zapisać własne informacje bezpieczeństwa (np. Crash pady) i kody taryfy, a potem wybierać je po nazwie.
To pomocnicze dane użytkownika do formularza, nie nowe produkty ani ustawienia programu. Nie zastępują parametrów produktu, podmiotów GPSR ani walidacji Allegro. Program nie dostarcza gotowych treści ani nie dobiera kodów.

Osobne zbiory bezpieczeństwo/taryfa, nazwa i wartość. Wybranie wstawia wartość do bieżącego formularza; istniejące oferty nie są automatycznie zmieniane. Własny zapis/zmiana/usunięcie jest jawny, zastąpienie istniejącej nazwy i usunięcie potwierdzane. Zapis biblioteki jest niezależny od Zastosuj/Anuluj formularza.

Port w przypadkach użycia, adapter atomowych plików JSON w katalogu danych użytkownika szablony_ofert, składanie wyłącznie bootstrap. Brak migracji bazy, seedów i zapisów w katalogu instalacji. Każdy wpis to oddzielny ograniczony plik, nazwa pliku wyliczana z rodzaju i znormalizowanej nazwy. Błąd odczytu nie usuwa plików i nie blokuje ręcznego wypełnienia formularza. Aktualizacja ZIP nie zawiera plików użytkownika.

Testy: ponowne otwarcie, rozdzielenie zbiorów, długi tekst i polskie znaki, walidacja/niepoprawny plik, atomowa podmiana, wybór i anulowanie, ręczny/massowy kod taryfy, oba motywy. Powrót do starszej aplikacji pozostawia pliki, ale nie udostępnia tej funkcji.
