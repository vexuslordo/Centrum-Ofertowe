# ADR-078 — wspólny edytor zapisanych szkiców

Status: wdrożenie polecenia właściciela kontynuowania roadmapy po odbiorze 0.54,
2026-11-16. Przyrost 0.55 realizuje kolejny fragment wspólnego miejsca pracy Oferty.

Nowe oferty i Szkice używają tego samego edytora. Użytkownik wraca do zapisanego
szkicu i zmienia SKU, EAN, tytuł, cenę, galerię oraz opis. Zapis aktualizuje
istniejące ID, zachowując pochodzenie, numer źródłowy, dopasowanie i ewentualne
powiązanie Produktu. Produkt pozostaje bez zmian. Nie tworzy drugiego szkicu.

Nowa operacja przypadku użycia waliduje pełną treść tym samym walidatorem co
ręczna oferta. Zapis przez istniejący port edytuj: wersja optymistyczna,
atomowa transakcja i kopia bazy. Konflikt lub błąd nie zamyka formularza.
Dotychczasowy klucz importu pozostaje historyczny: powtórny import tej samej
paczki nadal pomija źródłową pozycję, jak wcześniej. Brak migracji schematu12.

GUI nie zna SQL ani adapterów; magazyn plików przekazany z punktu składania.
Zdjęcia z dysku są kopiowane. Anulowanie nie zapisuje szkicu; zaimportowane
kopie zdjęć mogą pozostać w magazynie, jak w nowej ofercie. Bez kasowania plików.

Akcja Dalej najpierw zapisuje, potem przekazuje aktualną treść do istniejącego
przygotowania Allegro. Nie uruchamia sprzedaży i nie modyfikuje dawnych ofert
kanału. PrestaShop, wspólne wyniki kanałów i synchronizacja pozostają kolejnymi
etapami; nie oznaczać ich jako dostępne. Testy: zapis tego samego ID/restart,
konflikt, walidacja, anulowanie, zdjęcia, przekazanie zapisanej treści, oba motywy/DPI.
