# ADR-075 — osobna, potwierdzana publikacja szkiców Allegro

Właściciel od początku wymaga osobnej potwierdzanej publikacji, a następnie zlecił kontynuowanie roadmapy. Przyrost nie wykonuje rzeczywistych publikacji w testach.

Scenariusz: Allegro → zaznaczone szkice → Opublikuj szkice → odczyt aktualnych danych → jawne potwierdzenie konta i liczby ofert (domyślnie Nie). Tylko INACTIVE, nigdy wznowienie ENDED. Odcisk odczytu jest porównywany tuż przed zleceniem; zmiana danych wymaga ponownego sprawdzenia. Dotychczasowe tworzenie INACTIVE niczego nie publikuje automatycznie.

API: PUT /sale/offer-publication-commands/{UUID}, publication.action=ACTIVATE, CONTAINS_OFFERS z jednym wskazanym ID. Osobny identyfikator dla każdej oferty, maksymalnie 100 wybranych na serię. Kontrakt changePublicationStatusUsingPUT, GeneralReport i CommandTask potwierdzony w Swagger Allegro. Komenda zapisana przed PUT. GET raportu/zadań i własnej oferty potwierdza wynik; Opublikowano wymaga statusu ACTIVE. Sukces komendy bez ACTIVE pozostaje w toku.

Techniczny dziennik SQLite w publikacje_allegro/rejestr.sqlite3: tylko skrót env/konto/ID i UUID komendy. Brak tokenów, tytułów, treści i nowego modelu biznesowego. Atomowe INSERT blokuje równoległą publikację tego samego ID; usunięcie odmowy ma warunek UUID, aby nie usuwać nowszej próby. Timeout/409/5xx/niepoprawna odpowiedź zostawia blokadę i pozwala jedynie czytać tę samą komendę. Jednoznaczne 4xx albo końcowy FAIL pozwala po poprawie na nową osobno potwierdzoną próbę. Limit429 respektuje Retry-After. Brak automatycznych ponowień PUT. Katalog SQLite pozostaje w schemacie12.

Przerwanie i zmiana sesji zatrzymuje nowe komendy; wysłanego żądania nie da się cofnąć. Po restarcie wybór tych samych ID odczytuje dziennik zamiast ponownie publikować. Uszkodzony dziennik blokuje zapis, nie jest kasowany.

W tym przyroście naprawiono również blokujący import: bezpieczne GET ponawiane do trzech razy, zachowanie pełnych stron w pamięci ostatniego konta, wznowienie po weryfikacji pierwszej strony/licznika; zmiana listy powoduje nowy pełny odczyt. Brak częściowego importu i brak zmian użytkowych danych przy błędzie sieci.
