# ADR-076 — ręczny formularz i opis bliżej edycji Allegro

Właściciel 16.11.2026 wymaga uproszczenia ręcznej oferty, edycji podobnej do Allegro i drag & drop.

Jeden przewijany formularz: dane, galeria 64×64 i bezpośrednio edytowane karty opisu. Bez bocznej listy sekcji i zagnieżdżonych zakładek. Cztery dotychczasowe układy, formatowanie, kolejność i pełny podgląd zachowane; zapis/Allegro pozostają osobnymi czynnościami. Nowy komponent dotyczy ręcznej oferty; pozostałych edytorów nie przebudowuje się w tym przyroście.

Przeciąganie: pliki z dysku do galerii/opisu, zdjęcie galerii do opisu, sekcja za uchwyt do nowego położenia. Przyciski zapewniają te same operacje. Rozpoznawane tylko lokalne pliki zdjęć i wewnętrzne MIME zdjęcia/sekcji. Kopie wykonuje istniejący port w tle; opisy i zdjęcia nadal są danymi użytkownika. Zmiana układu usuwająca niepuste elementy wymaga potwierdzenia. Nie kasować oryginałów lub kopii zdjęć przy usuwaniu z galerii.

Bez zmian domeny, schematu12, API i zasad publikacji. Mapowanie do dotychczasowych sekcji OfertaPodglad i istniejącego atomowego zapisu. Otwarcie bez edycji nie przepisuje źródła. Logo, motywy i jednakowe miniatury zachowane. Testy: drag & drop, kolejność i treści po zapisie, formatowanie, układy, anulowanie, pliki/odnośniki, oba motywy i DPI.
