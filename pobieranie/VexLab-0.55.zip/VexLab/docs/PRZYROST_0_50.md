# VexLab 0.50 — własne informacje bezpieczeństwa i taryfy, postęp pobierania

## Moje informacje bezpieczeństwa

W **GPSR, dostawa i warunki → GPSR**:
1. Wpisz lub wklej cały tekst bezpieczeństwa.
2. Przy **Moje informacje** kliknij **Zapisz jako…**, wpisz nazwę, np. **Crash pady**.
3. Przy następnej paczce wybierz tę nazwę — cały tekst pojawi się w polu bezpieczeństwa.
4. **Zastosuj** przenosi dane na wskazane oferty; zapisanie biblioteki jest osobną czynnością.

Zapis pod tą samą nazwą oraz usunięcie wymagają potwierdzenia. Usunięcie zapisanej pozycji nie czyści tekstu z bieżącego formularza. Nie ma wbudowanych ostrzeżeń, kodów ani automatycznego dobierania treści.

## Moje taryfy

W **Parametry produktów** przy polu **Kod taryfy celnej** jest analogiczny wybór **Moje taryfy** i **Zapisz jako…**. Nazwa może opisywać grupę produktów, a zapisaną wartością jest kod wpisany przez użytkownika.
Wybór wstawia kod do formularza i przełącza jego źródło na wartość ręczną. W edycji masowej zaznacza ten parametr do zmiany. Zastosowanie respektuje dotychczasowy zakres zaznaczonych produktów. Wybór nie zmienia samodzielnie opublikowanych ofert.

## Dane użytkownika

Biblioteka jest przechowywana w **szablony_ofert** we własnym katalogu danych VexLab, obok bazy i preferencji. Osobne zbiory bezpieczeństwa i taryf; wpisy JSON zapisywane atomowo. Nie zapisujemy w folderze programu ani w ZIP-ie aktualizacji. Zapisane wartości pozostają po restarcie i aktualizacji, o ile używany jest ten sam katalog danych. Przy przenoszeniu na inny komputer należy zachować cały katalog danych.
Nie ma migracji schematu bazy. Błąd odczytu nie usuwa plików i pozwala wpisać tekst ręcznie.

## Postęp importu Allegro

Zawiera także [pasek i liczniki importu](POPRAWKA_0_49_2.md): pobrane oferty / liczba wszystkich, procent, sprawdzone pozycje, przygotowanie zdjęć i wynik zapisu. Przed pierwszą odpowiedzią pasek jest animowany. Błąd zachowuje ostatni licznik.

Sprawdzane na danych syntetycznych: trwałość biblioteki, oddzielne rodzaje, podmiana/odmowa/usunięcie, brak zmian przy anulowaniu formularza, pełny tekst GPSR oraz taryfa w pojedynczej i masowej edycji, pasek postępu, oba motywy i skalowanie. Bez dostępu do rzeczywistego konta użytkownika.
