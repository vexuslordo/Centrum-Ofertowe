# VexLab 0.55 — wróć do oferty i edytuj ją w jednym miejscu

Szkice → zaznacz jedną ofertę → Edytuj ofertę otwiera ten sam nowoczesny
formularz co Nowe oferty. Możesz zmienić SKU, EAN, tytuł, cenę, galerię
oraz sekcje opisu. Zdjęcia z dysku i drag & drop działają także po powrocie.

Zapisz szkic aktualizuje ten sam wpis. Dalej — ustawienia Allegro najpierw
zapisuje, następnie otwiera przygotowanie Allegro z aktualną treścią.
Nie uruchamia sprzedaży ani nie zmienia już wysłanej oferty na Allegro.

Zachowane ID, pochodzenie, numer pozycji, dopasowanie i powiązanie Produktu.
Produkt nie jest zmieniany. Zapis z nieaktualnej wersji jest blokowany;
formularz i niezapisane zmiany pozostają widoczne. Anulowanie nie zapisuje
zmian. Zaimportowane zdjęcia są kopiami, bez usuwania oryginałów.

Schemat12 bez migracji. Istniejący zapis atomowy i kopia bazy przed zmianą.
Przy aktualizacji zachować katalog danych, bazę, zdjęcia i własne szablony.
Historyczny klucz importu pozostaje zachowany, więc ponowne wczytanie tej samej
paczki nie odtwarza oryginalnego szkicu po edycji.

To fragment wspólnego miejsca pracy Oferty. PrestaShop i synchronizacja
zmian z kanałami nie są jeszcze wdrożone.

Sprawdzenia: rzeczywisty SQLite, restart, kopia, walidacja i konflikt wersji;
GUI: anulowanie, zachowanie zdjęć i treści, przekazanie zapisanego szkicu,
konflikt bez zamknięcia lub wysyłki, oba motywy i większe DPI.

Zrzuty: [edycja szkicu](screenshots/vexlab-reczna-055-formularz-dark.png),
[opis w jasnym motywie](screenshots/vexlab-reczna-055-opis-light.png).
