# VexLab 0.54

Nowoczesny ręczny edytor: numerowane sekcje, zaokrąglone karty, większe pola,
wyraźna strefa zdjęć i lżejsza hierarchia tekstu. Kolory z palety programu.
Drag & drop i zapis pozostają jak w 0.53. Miniatury 64×64.
Bez migracji i zmian danych; zachować bazę oraz katalog zdjęć przy aktualizacji.
Sprawdzenia: oba motywy, większe DPI, pełna kontrola projektu i audyt zależności.

Podgląd: [ciemny formularz](screenshots/vexlab-reczna-054-formularz-dark.png),
[jasny opis](screenshots/vexlab-reczna-054-opis-light.png).
