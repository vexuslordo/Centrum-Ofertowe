# VexLab 0.53 — prostsza ręczna oferta i drag & drop

**Nowe oferty → Utwórz ręcznie…** otwiera jeden przewijany formularz: dane oferty, zdjęcia oraz opis edytowany bezpośrednio w widocznych kartach. Nie ma bocznej listy sekcji ani zagnieżdżonych zakładek.

## Przeciąganie

- Przeciągnij pliki JPEG/PNG/WebP z dysku do obszaru Zdjęcia.
- Przeciągnij miniaturę z galerii na opis lub puste miejsce zdjęcia w sekcji.
- Pliki z dysku możesz upuścić także bezpośrednio w opisie — kopie trafią do danych użytkownika, a zdjęcia do wskazanej sekcji.
- Chwyć sekcję za **⠿** i upuść nad/pod inną sekcją, aby zmienić kolejność.

Import plików zawsze zgłasza akcję kopiowania, również gdy system proponuje przeniesienie. Oryginały pozostają na dysku. Aktualne limity zdjęć, normalizacja, przechowywanie kopii i wysyłka binarna Allegro są zachowane z 0.51.

## Edycja

Pod opisem dodasz sam tekst, zdjęcie, tekst ze zdjęciem lub dwa zdjęcia. Formatowanie jest przy tekście. Układ można zmienić na pasku danej sekcji; jeżeli usunąłby niepuste elementy, program pyta o zgodę. Strzałki i przyciski zapewniają alternatywę dla przeciągania.

Przy zdjęciu jest menu **… → Ustaw jako główne / Dodaj do opisu / Usuń z galerii**. Pierwsze zdjęcie jest główne. Miniatury nadal mają 64×64 px. Adresy HTTPS pozostają dostępne pod **Dodaj przez link**. Usunięcie zdjęcia z galerii nie kasuje jego pliku i nie usuwa go automatycznie z istniejącej sekcji opisu.

**Podgląd oferty** pokazuje całość w osobnym oknie. **Zapisz szkic** zapisuje lokalnie; **Dalej — ustawienia Allegro** zapisuje szkic i otwiera dotychczasowe przygotowanie parametrów, GPSR, dostaw i VAT. Publikacja sprzedaży nadal jest osobną potwierdzaną akcją.

Zmiana dotyczy ręcznego formularza jako ekranu do oceny. Bez migracji schematu12, zmian API i nadpisywania istniejących szkiców lub Produktów. Logo, dane użytkownika i zapisane teksty/taryfy zachowane. Otwarcie edytora bez zmian nie przepisuje źródłowego HTML/sekcji.

Testy obejmują rzeczywiste zdarzenia Qt drag/drop i generowanie MIME podczas ruchu myszy, kopiowanie plików zamiast przenoszenia, kolejność i zawartość zapisanych sekcji, układ dwóch zdjęć, formatowanie, zgodę na zmianę układu, anulowanie, miniatury i oba motywy/DPI. Bez rzeczywistych operacji sprzedaży.
