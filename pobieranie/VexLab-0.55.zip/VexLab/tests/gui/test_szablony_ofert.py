from dataclasses import replace

import pytest
from PySide6.QtWidgets import QDialog, QInputDialog, QLineEdit, QMessageBox, QWidget

from tests.gui.test_masowa_paczka_allegro import select
from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from vexlab.adaptery.szablony_ofert_json import SzablonyOfertJSON
from vexlab.gui.szablony_ofert import WyborSzablonu
from vexlab.gui.ustawienia_sprzedazy_allegro import DaneSprzedazyAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import ParametrSzkicu
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import SlownikiSprzedazy


def test_zapis_wybor_ponowne_otwarcie_i_odmowa_nadpisania(qtbot, tmp_path, monkeypatch):
    parent = QWidget()
    qtbot.addWidget(parent)
    field = QLineEdit(parent)
    field.setText("Pełne ostrzeżenia\nCrash pady")
    repo = SzablonyOfertJSON(tmp_path)
    row = WyborSzablonu(parent, repo, "bezpieczenstwo", field.text, field.setText)
    monkeypatch.setattr(QInputDialog, "getText", lambda *a, **k: ("Crash pady", True))
    row.zapisz()
    assert repo.lista("bezpieczenstwo")[0][0] == "Crash pady"
    field.clear()
    again = WyborSzablonu(
        parent, SzablonyOfertJSON(tmp_path), "bezpieczenstwo", field.text, field.setText
    )
    assert field.text() == ""
    again.wybor.setCurrentIndex(1)
    again.wybor.activated.emit(1)
    assert "Pełne ostrzeżenia" in field.text()
    field.setText("Nie zapisywać")
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    again.zapisz()
    again.usun()
    assert repo.lista("bezpieczenstwo")[0][1] != "Nie zapisywać"
    monkeypatch.setattr(QInputDialog, "getText", lambda *a, **k: ("Nowy", False))
    again.zapisz()
    assert len(repo.lista("bezpieczenstwo")) == 1
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    again.usun()
    assert repo.lista("bezpieczenstwo") == () and field.text() == "Nie zapisywać"


def test_gpsr_wstawia_pelny_tekst_uzytkownika(qtbot, tmp_path):
    parent = QWidget()
    qtbot.addWidget(parent)
    repo = SzablonyOfertJSON(tmp_path)
    text = "Crash pady\nPełna informacja bezpieczeństwa"
    repo.zapisz("bezpieczenstwo", "Crash pady", text)
    d = DaneSprzedazyAllegro(
        parent, SlownikiSprzedazy((), (), (), (), (), ()), None, 197, szablony_ofert=repo
    )
    qtbot.addWidget(d)
    row = d.findChild(WyborSzablonu)
    row.wybor.activated.emit(1)
    assert d.bezpieczenstwo.toPlainText() == text
    d.reject()
    assert d.wynik is None and repo.lista("bezpieczenstwo") == (("Crash pady", text),)


@pytest.mark.parametrize("masowo", [False, True])
def test_taryfa_w_formularzu_wstawia_wartosc_i_ustawia_zrodlo_reczne(
    qtbot, tmp_path, nowe_szkice_fixture, monkeypatch, masowo
):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(qtbot, nowe_szkice_fixture, (o, replace(o, sku="DRUGI")))
    w.szablony_ofert = SzablonyOfertJSON(tmp_path)
    w.szablony_ofert.zapisz("taryfa", "Crash pady", "87141090")
    select(w, (0, 1) if masowo else (0,))
    w.przygotuj()
    wykonaj(jobs)
    plans = []
    for p in w.plany:
        product = replace(
            p.produkt,
            parametry=p.produkt.parametry
            + (ParametrSzkicu("tar", "Kod taryfy celnej", "string", False),),
        )
        u = replace(p.ustawienia, nowy=True, zrodla=p.ustawienia.zrodla + (("tar", "sku"),))
        plans.append(replace(p, produkt=product, ustawienia=u))
    w.plany = tuple(plans)
    w.ustawienia = {i: p.ustawienia for i, p in enumerate(w.plany)}

    def edit(d):
        row = d.findChild(WyborSzablonu)
        assert row is not None
        row.wybor.activated.emit(1)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", edit)
    w.uzupelnij(masowo)
    for i in (0, 1) if masowo else (0,):
        assert dict(w.ustawienia[i].wartosci)["tar"] == "87141090"
        assert "tar" not in dict(w.ustawienia[i].zrodla)
