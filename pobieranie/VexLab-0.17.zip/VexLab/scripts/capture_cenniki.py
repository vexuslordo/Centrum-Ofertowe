"""Izolowany podgląd cenników z syntetycznymi pozycjami i cenami."""

from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import uuid4

from PySide6.QtCore import QSettings, QTimer
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import CenaImportu, ImportujProdukty, PozycjaImportu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow


def main() -> int:
    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    with TemporaryDirectory(prefix="vexlab-cenniki-visual-") as folder:
        tmp = Path(folder)
        repo = CennikiSQLite(tmp / "test.sqlite3")
        imp = ImportujProdukty(CzytnikTabel(), repo, repo)
        kat = KatalogProduktow(repo, repo)
        producenci = RejestrProducentow(repo)
        pid = producenci.dodaj(DaneProducenta("Producent testowy")).id
        rows = tuple(
            PozycjaImportu(
                uuid4(),
                uuid4(),
                "test.csv",
                "A",
                i + 2,
                DaneProduktu(nazwa, f"TEST-{i}", producent_id=pid),
                cena=CenaImportu(cena, "EUR", "brutto"),
            )
            for i, (nazwa, cena) in enumerate(
                (
                    ("Przykładowy produkt A", "100.00"),
                    ("Przykładowy produkt B", "90.00"),
                    ("Nowy produkt", "75.00"),
                    ("Pozycja do sprawdzenia", "brak"),
                )
            )
        )
        paczka = uuid4()
        bazowe = tuple(replace(p, paczka=paczka) for p in rows[:2])
        imp.zatwierdz(imp.ocen(bazowe), frozenset(p.id for p in bazowe))
        serwis = BibliotekaCennikow(repo, imp)
        serwis.zapisz("Cennik 2025", 2025, "listopad", imp.ocen(rows))
        nowy = serwis.zapisz(
            "Cennik 2026",
            2026,
            "wydanie 2",
            imp.ocen((replace(rows[0], cena=CenaImportu("125.00", "EUR", "brutto")), *rows[1:])),
        )
        serwis.oznacz(next(c for c in serwis.lista() if c.id == nowy), True, serwis.lista())
        okno = OknoVexLab(
            PowlokaAplikacji(
                PreferencjeQt(QSettings(str(tmp / "prefs.ini"), QSettings.Format.IniFormat)),
                "uzytkownik_testowy",
                "0.17.0.dev0",
            ),
            kat,
            producenci,
            EksportujKatalog(EksportCSV()),
            imp,
            cenniki=serwis,
        )
        okno.show()
        s = okno.strona_cennikow
        assert s is not None
        sukces: list[bool] = []

        def gotowe() -> bool:
            return not okno._zadania and not s._podglad_trwa and s.wiersze.isEnabled()

        def zakoncz() -> None:
            if not gotowe():
                QTimer.singleShot(30, zakoncz)
                return
            sukces.append(okno.grab().save(str(cel / "vexlab-cenniki-small.png")))
            okno.close()
            app.quit()

        def jasny() -> None:
            if not gotowe():
                QTimer.singleShot(30, jasny)
                return
            sukces.append(okno.grab().save(str(cel / "vexlab-cenniki-light.png")))
            okno.resize(900, 800)
            QTimer.singleShot(100, zakoncz)

        def ciemny() -> None:
            if not gotowe() or s.wiersze.rowCount() != 4:
                QTimer.singleShot(30, ciemny)
                return
            sukces.append(okno.grab().save(str(cel / "vexlab-cenniki-dark.png")))
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.JASNY))
            QTimer.singleShot(100, jasny)

        def wybierz() -> None:
            if okno._zadania:
                QTimer.singleShot(30, wybierz)
                return
            s.tabela.selectRow(0)
            QTimer.singleShot(100, ciemny)

        def zacznij() -> None:
            if okno._zadania:
                QTimer.singleShot(30, zacznij)
                return
            okno.przejdz("Cenniki")
            QTimer.singleShot(100, wybierz)

        QTimer.singleShot(100, zacznij)
        QTimer.singleShot(30000, lambda: app.exit(1))
        app.exec()
        okno.pula.waitForDone(30000)
        return 0 if sukces == [True, True, True] else 1


if __name__ == "__main__":
    raise SystemExit(main())
