"""SQLite: parametryzowane zapisy, kontrola wersji i początkowy schemat 1."""

import hashlib
import sqlite3
from collections.abc import Iterator
from contextlib import closing, contextmanager
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID, uuid4

from vexlab.domena.producent import (
    NieprawidlowyProducent,
    Producent,
    ProducentNieaktywny,
    ProducentNieIstnieje,
)
from vexlab.domena.produkt import (
    DopasowanieMotocykla,
    KonfliktEdycji,
    NieprawidlowyProdukt,
    Produkt,
    SKUJuzIstnieje,
)
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.galeria import GaleriaDTO
from vexlab.przypadki_uzycia.katalog import CenaSugerowanaDTO
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.rdzen.kontrakty import BladTechniczny

SCHEMAT = """
CREATE TABLE produkty (
    id TEXT PRIMARY KEY NOT NULL,
    nazwa TEXT NOT NULL CHECK(length(trim(nazwa)) > 0),
    sku TEXT NOT NULL CHECK(length(trim(sku)) > 0),
    sku_klucz TEXT NOT NULL UNIQUE CHECK(length(sku_klucz) > 0),
    opis TEXT NOT NULL,
    wersja INTEGER NOT NULL CHECK(wersja >= 1)
)
"""

# Schemat 1 został wydany w 0.2. Nie zmieniać jego tekstu ani sumy.
MIGRACJA_2 = (
    "CREATE TABLE producenci (id TEXT PRIMARY KEY NOT NULL, "
    "nazwa TEXT NOT NULL CHECK(length(trim(nazwa)) > 0), "
    "aktywny INTEGER NOT NULL CHECK(aktywny IN (0,1)), "
    "wersja INTEGER NOT NULL CHECK(wersja >= 1))",
    "ALTER TABLE produkty ADD COLUMN producent_id TEXT "
    "REFERENCES producenci(id) ON DELETE RESTRICT",
)


MIGRACJA_3 = (
    "CREATE TABLE importy (id TEXT PRIMARY KEY NOT NULL, zrodlo TEXT NOT NULL, "
    "arkusz TEXT NOT NULL, dodane INTEGER NOT NULL, odlozone INTEGER NOT NULL)",
    "CREATE TABLE import_robocze (id TEXT PRIMARY KEY NOT NULL, "
    "paczka TEXT NOT NULL REFERENCES importy(id), wiersz INTEGER NOT NULL, "
    "nazwa TEXT NOT NULL, sku TEXT NOT NULL, opis TEXT NOT NULL, "
    "producent_id TEXT REFERENCES producenci(id), powod TEXT NOT NULL, "
    "wersja INTEGER NOT NULL CHECK(wersja >= 1))",
    "CREATE TABLE import_powiazania (id TEXT PRIMARY KEY NOT NULL, "
    "paczka TEXT NOT NULL REFERENCES importy(id), wiersz INTEGER NOT NULL, "
    "produkt_id TEXT NOT NULL REFERENCES produkty(id), "
    "tryb TEXT NOT NULL CHECK(tryb IN ('dodano','powiazano')))",
)


MIGRACJA_4 = (
    "CREATE TABLE ceny_sugerowane (produkt_id TEXT PRIMARY KEY NOT NULL "
    "REFERENCES produkty(id), kwota TEXT NOT NULL, waluta TEXT NOT NULL, "
    "rodzaj TEXT NOT NULL CHECK(rodzaj IN ('netto','brutto')), zrodlo TEXT NOT NULL)",
    "ALTER TABLE import_robocze ADD COLUMN cena_tekst TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE import_robocze ADD COLUMN cena_waluta TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE import_robocze ADD COLUMN cena_rodzaj TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE producenci ADD COLUMN strona_www TEXT NOT NULL DEFAULT ''",
    "CREATE TABLE zdjecia (id TEXT PRIMARY KEY NOT NULL, produkt_id TEXT NOT NULL "
    "REFERENCES produkty(id), zrodlo TEXT NOT NULL, dane BLOB NOT NULL, miniatura BLOB NOT NULL, "
    "kolejnosc INTEGER NOT NULL, UNIQUE(produkt_id,kolejnosc))",
)


MIGRACJA_9 = (
    "ALTER TABLE cenniki ADD COLUMN aktualny INTEGER NOT NULL DEFAULT 0 "
    "CHECK(aktualny IN (0,1) AND (aktualny=0 OR producent_id IS NOT NULL))",
    "CREATE UNIQUE INDEX cenniki_aktualny_producent ON cenniki(producent_id) WHERE aktualny=1",
)


def suma_migracji_9() -> str:
    return hashlib.sha256("\n".join(MIGRACJA_9).encode()).hexdigest()


MIGRACJA_8 = (
    "CREATE TABLE cenniki (id TEXT PRIMARY KEY, nazwa TEXT NOT NULL CHECK(length(trim(nazwa))>0), "
    "rok INTEGER NOT NULL CHECK(rok BETWEEN 1000 AND 9999), wydanie TEXT NOT NULL, "
    "producent_id TEXT REFERENCES producenci(id) ON DELETE RESTRICT, zrodlo TEXT NOT NULL, "
    "arkusz TEXT NOT NULL, liczba INTEGER NOT NULL CHECK(liczba>0), wczytano_utc TEXT NOT NULL, "
    "dane_json TEXT NOT NULL, wersja INTEGER NOT NULL CHECK(wersja>0))",
)


def suma_migracji_8() -> str:
    return hashlib.sha256("\n".join(MIGRACJA_8).encode()).hexdigest()


MIGRACJA_7 = (
    "CREATE TABLE szkice (id TEXT PRIMARY KEY, produkt_id TEXT NOT NULL "
    "REFERENCES produkty(id) ON DELETE RESTRICT, wersja_produktu INTEGER NOT NULL, "
    "tytul TEXT NOT NULL CHECK(length(trim(tytul))>0), opis TEXT NOT NULL, "
    "tresc_json TEXT NOT NULL, zrodlo TEXT NOT NULL, klucz TEXT NOT NULL UNIQUE, "
    "wersja INTEGER NOT NULL CHECK(wersja>0))",
    "CREATE INDEX szkice_produkt ON szkice(produkt_id)",
)


def suma_migracji_7() -> str:
    return hashlib.sha256("\n".join(MIGRACJA_7).encode()).hexdigest()


MIGRACJA_6 = ("ALTER TABLE import_robocze ADD COLUMN dopasowania_json TEXT NOT NULL DEFAULT '[]'",)


def suma_migracji_6() -> str:
    return hashlib.sha256("\n".join(MIGRACJA_6).encode()).hexdigest()


MIGRACJA_5 = (
    "CREATE TABLE dopasowania (produkt_id TEXT NOT NULL REFERENCES produkty(id), "
    "kolejnosc INTEGER NOT NULL CHECK(kolejnosc >= 0), "
    "marka TEXT NOT NULL CHECK(length(trim(marka)) > 0), "
    "model TEXT NOT NULL CHECK(length(trim(model)) > 0), "
    "rok_od INTEGER CHECK(rok_od BETWEEN 1000 AND 9999), "
    "rok_do INTEGER CHECK(rok_do BETWEEN 1000 AND 9999), wariant TEXT NOT NULL, "
    "CHECK(rok_do IS NULL OR (rok_od IS NOT NULL AND rok_do >= rok_od)), "
    "PRIMARY KEY(produkt_id,kolejnosc))",
)


def suma_migracji_5() -> str:
    return hashlib.sha256("\n".join(MIGRACJA_5).encode()).hexdigest()


def suma_migracji_4() -> str:
    return hashlib.sha256("\n".join(MIGRACJA_4).encode()).hexdigest()


def suma_migracji_3() -> str:
    return hashlib.sha256("\n".join(MIGRACJA_3).encode()).hexdigest()


def suma_migracji_2() -> str:
    return hashlib.sha256("\n".join(MIGRACJA_2).encode()).hexdigest()


class KatalogSQLite:
    def __init__(self, plik: Path) -> None:
        self.plik = plik

    @contextmanager
    def _polaczenie(self) -> Iterator[sqlite3.Connection]:
        polaczenie: sqlite3.Connection | None = None
        try:
            self.plik.parent.mkdir(parents=True, exist_ok=True)
            polaczenie = sqlite3.connect(self.plik, timeout=5)
            polaczenie.row_factory = sqlite3.Row
            polaczenie.execute("PRAGMA foreign_keys = ON")
            self._sprawdz_schemat(polaczenie)
            with polaczenie:
                yield polaczenie
        except sqlite3.IntegrityError as blad:
            if "produkty.sku_klucz" in str(blad):
                raise SKUJuzIstnieje("Ten symbol SKU jest już używany. Wybierz inny.") from blad
            raise BladTechniczny("Zapis katalogu narusza ograniczenia danych.") from blad
        except (sqlite3.Error, OSError) as blad:
            raise BladTechniczny("Nie można odczytać lub zapisać lokalnego katalogu.") from blad
        finally:
            if polaczenie is not None:
                polaczenie.close()

    def _sprawdz_schemat(self, polaczenie: sqlite3.Connection) -> None:
        wersja = polaczenie.execute("PRAGMA user_version").fetchone()[0]
        nowa = wersja == 0
        if wersja == 0:
            with polaczenie:
                polaczenie.execute("BEGIN IMMEDIATE")
                # Drugi proces mógł zakończyć inicjalizację przed uzyskaniem blokady.
                wersja = polaczenie.execute("PRAGMA user_version").fetchone()[0]
                if wersja == 0:
                    tabele = polaczenie.execute(
                        "SELECT name FROM sqlite_master "
                        "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                    ).fetchall()
                    if tabele:
                        raise BladTechniczny(
                            "Nieobsługiwana baza. Nie zmieniono istniejących tabel."
                        )
                    polaczenie.execute(SCHEMAT)
                    polaczenie.execute(
                        "CREATE TABLE migracje (wersja INTEGER PRIMARY KEY, "
                        "suma_sha256 TEXT NOT NULL, zastosowano_utc TEXT NOT NULL)"
                    )
                    polaczenie.execute(
                        "INSERT INTO migracje VALUES (1, ?, ?)",
                        (
                            hashlib.sha256(SCHEMAT.encode()).hexdigest(),
                            datetime.now(UTC).isoformat(),
                        ),
                    )
                    polaczenie.execute("PRAGMA user_version = 1")
                    wersja = 1
        if wersja not in (1, 2, 3, 4, 5, 6, 7, 8, 9):
            raise BladTechniczny("Nieobsługiwana wersja bazy. Użyj zgodnej wersji VexLab.")
        polaczenie.execute("SELECT id, nazwa, sku, sku_klucz, opis, wersja FROM produkty LIMIT 0")
        wpis = polaczenie.execute("SELECT suma_sha256 FROM migracje WHERE wersja=1").fetchone()
        if wpis is None or wpis[0] != hashlib.sha256(SCHEMAT.encode()).hexdigest():
            raise BladTechniczny("Nie potwierdzono wersji schematu. Zachowaj kopię bazy.")
        pierwotna = wersja
        if wersja == 1:
            self._migruj_do_2(polaczenie, nowa)
        polaczenie.execute("SELECT id, nazwa, aktywny, wersja FROM producenci LIMIT 0")
        polaczenie.execute("SELECT producent_id FROM produkty LIMIT 0")
        wpisy = polaczenie.execute(
            "SELECT wersja, suma_sha256 FROM migracje ORDER BY wersja"
        ).fetchall()
        oczekiwane = [(1, hashlib.sha256(SCHEMAT.encode()).hexdigest()), (2, suma_migracji_2())]
        aktualna = polaczenie.execute("PRAGMA user_version").fetchone()[0]
        if aktualna in (3, 4, 5, 6, 7, 8, 9):
            oczekiwane.append((3, suma_migracji_3()))
        if aktualna in (4, 5, 6, 7, 8, 9):
            oczekiwane.append((4, suma_migracji_4()))
        if aktualna in (5, 6, 7, 8, 9):
            oczekiwane.append((5, suma_migracji_5()))
        if aktualna in (6, 7, 8, 9):
            oczekiwane.append((6, suma_migracji_6()))
        if aktualna in (7, 8, 9):
            oczekiwane.append((7, suma_migracji_7()))
        if aktualna in (8, 9):
            oczekiwane.append((8, suma_migracji_8()))
        if aktualna == 9:
            oczekiwane.append((9, suma_migracji_9()))
        if [tuple(w) for w in wpisy] != oczekiwane:
            raise BladTechniczny("Nie potwierdzono wersji schematu. Zachowaj kopię bazy.")

        if aktualna == 2:
            self._migruj_do_3(polaczenie, nowa or pierwotna == 1)
        polaczenie.execute("SELECT id, zrodlo, arkusz, dodane, odlozone FROM importy LIMIT 0")
        polaczenie.execute(
            "SELECT id, paczka, wiersz, nazwa, sku, opis, producent_id, "
            "powod, wersja FROM import_robocze LIMIT 0"
        )

        polaczenie.execute(
            "SELECT id, paczka, wiersz, produkt_id, tryb FROM import_powiazania LIMIT 0"
        )

        if polaczenie.execute("PRAGMA user_version").fetchone()[0] == 3:
            self._migruj_do_4(polaczenie, nowa or pierwotna in (1, 2))
        polaczenie.execute(
            "SELECT produkt_id, kwota, waluta, rodzaj, zrodlo FROM ceny_sugerowane LIMIT 0"
        )
        polaczenie.execute(
            "SELECT cena_tekst, cena_waluta, cena_rodzaj FROM import_robocze LIMIT 0"
        )

        polaczenie.execute("SELECT strona_www FROM producenci LIMIT 0")
        polaczenie.execute(
            "SELECT id, produkt_id, zrodlo, dane, miniatura, kolejnosc FROM zdjecia LIMIT 0"
        )

        if polaczenie.execute("PRAGMA user_version").fetchone()[0] == 4:
            self._migruj_do_5(polaczenie, nowa or pierwotna in (1, 2, 3))
        polaczenie.execute(
            "SELECT produkt_id,kolejnosc,marka,model,rok_od,rok_do,wariant FROM dopasowania LIMIT 0"
        )

        if polaczenie.execute("PRAGMA user_version").fetchone()[0] == 5:
            self._migruj_do_6(polaczenie, nowa or pierwotna in (1, 2, 3, 4))
        polaczenie.execute("SELECT dopasowania_json FROM import_robocze LIMIT 0")

        if polaczenie.execute("PRAGMA user_version").fetchone()[0] == 6:
            self._migruj_do_7(polaczenie, nowa or pierwotna < 6)
        polaczenie.execute(
            "SELECT id,produkt_id,tytul,opis,tresc_json,zrodlo,klucz,"
            "wersja_produktu,wersja FROM szkice LIMIT 0"
        )

        if polaczenie.execute("PRAGMA user_version").fetchone()[0] == 7:
            self._migruj_do_8(polaczenie, nowa or pierwotna < 7)
        polaczenie.execute(
            "SELECT id,nazwa,rok,wydanie,producent_id,zrodlo,arkusz,liczba,"
            "wczytano_utc,dane_json,wersja FROM cenniki LIMIT 0"
        )

        if polaczenie.execute("PRAGMA user_version").fetchone()[0] == 8:
            self._migruj_do_9(polaczenie, nowa or pierwotna < 8)
        polaczenie.execute("SELECT aktualny FROM cenniki LIMIT 0")

    def _migruj_do_9(self, conn: sqlite3.Connection, kopia_juz_jest: bool) -> None:
        with conn:
            conn.execute("BEGIN IMMEDIATE")
            wersja = conn.execute("PRAGMA user_version").fetchone()[0]
            if wersja == 9:
                return
            if wersja != 8:
                raise BladTechniczny("Nie potwierdzono schematu przed aktualizacją cenników.")
            if not kopia_juz_jest:
                self._kopia_przed_migracja()
            for sql in MIGRACJA_9:
                conn.execute(sql)
            conn.execute(
                "INSERT INTO migracje VALUES (9,?,?)",
                (suma_migracji_9(), datetime.now(UTC).isoformat()),
            )
            if conn.execute("PRAGMA foreign_key_check").fetchall():
                raise BladTechniczny("Niespójna baza po aktualizacji statusów cenników.")
            conn.execute("PRAGMA user_version = 9")

    def _migruj_do_8(self, conn: sqlite3.Connection, kopia_juz_jest: bool) -> None:
        with conn:
            conn.execute("BEGIN IMMEDIATE")
            wersja = conn.execute("PRAGMA user_version").fetchone()[0]
            if wersja in (8, 9):
                return
            if wersja != 7:
                raise BladTechniczny("Nie potwierdzono schematu przed zapisem cenników.")
            if not kopia_juz_jest:
                self._kopia_przed_migracja()
            for sql in MIGRACJA_8:
                conn.execute(sql)
            conn.execute(
                "INSERT INTO migracje VALUES (8,?,?)",
                (suma_migracji_8(), datetime.now(UTC).isoformat()),
            )
            if conn.execute("PRAGMA foreign_key_check").fetchall():
                raise BladTechniczny("Niespójna baza po aktualizacji cenników.")
            conn.execute("PRAGMA user_version = 8")

    def _migruj_do_7(self, conn: sqlite3.Connection, kopia_juz_jest: bool) -> None:
        with conn:
            conn.execute("BEGIN IMMEDIATE")
            wersja = conn.execute("PRAGMA user_version").fetchone()[0]
            if wersja in (7, 8, 9):
                return
            if wersja != 6:
                raise BladTechniczny("Nie potwierdzono schematu przed zapisem szkiców.")
            if not kopia_juz_jest:
                self._kopia_przed_migracja()
            for sql in MIGRACJA_7:
                conn.execute(sql)
            conn.execute(
                "INSERT INTO migracje VALUES (7,?,?)",
                (suma_migracji_7(), datetime.now(UTC).isoformat()),
            )
            if conn.execute("PRAGMA foreign_key_check").fetchall():
                raise BladTechniczny("Niespójna baza po aktualizacji szkiców.")
            conn.execute("PRAGMA user_version = 7")

    def _migruj_do_6(self, conn: sqlite3.Connection, kopia_juz_jest: bool) -> None:
        with conn:
            conn.execute("BEGIN IMMEDIATE")
            wersja = conn.execute("PRAGMA user_version").fetchone()[0]
            oczekiwane = [
                (1, hashlib.sha256(SCHEMAT.encode()).hexdigest()),
                (2, suma_migracji_2()),
                (3, suma_migracji_3()),
                (4, suma_migracji_4()),
                (5, suma_migracji_5()),
            ]
            if wersja in (6, 7, 8, 9):
                oczekiwane.append((6, suma_migracji_6()))
            if wersja in (7, 8, 9):
                oczekiwane.append((7, suma_migracji_7()))
            if wersja in (8, 9):
                oczekiwane.append((8, suma_migracji_8()))
            if wersja == 9:
                oczekiwane.append((9, suma_migracji_9()))
            rows = conn.execute(
                "SELECT wersja,suma_sha256 FROM migracje ORDER BY wersja"
            ).fetchall()
            if wersja not in (5, 6, 7, 8, 9) or [tuple(r) for r in rows] != oczekiwane:
                raise BladTechniczny(
                    "Nie potwierdzono schematu przed aktualizacją importu dopasowań."
                )
            if wersja in (6, 7, 8, 9):
                return
            if not kopia_juz_jest:
                self._kopia_przed_migracja()
            for sql in MIGRACJA_6:
                conn.execute(sql)
            conn.execute(
                "INSERT INTO migracje VALUES (6,?,?)",
                (suma_migracji_6(), datetime.now(UTC).isoformat()),
            )
            if conn.execute("PRAGMA foreign_key_check").fetchall():
                raise BladTechniczny("Niespójna baza po aktualizacji importu dopasowań.")
            conn.execute("PRAGMA user_version = 6")

    def _migruj_do_5(self, conn: sqlite3.Connection, kopia_juz_jest: bool) -> None:
        with conn:
            conn.execute("BEGIN IMMEDIATE")
            wersja = conn.execute("PRAGMA user_version").fetchone()[0]
            oczekiwane = [
                (1, hashlib.sha256(SCHEMAT.encode()).hexdigest()),
                (2, suma_migracji_2()),
                (3, suma_migracji_3()),
                (4, suma_migracji_4()),
            ]
            if wersja in (5, 6, 7, 8, 9):
                oczekiwane.append((5, suma_migracji_5()))
            if wersja in (6, 7, 8, 9):
                oczekiwane.append((6, suma_migracji_6()))
            if wersja in (7, 8, 9):
                oczekiwane.append((7, suma_migracji_7()))
            if wersja in (8, 9):
                oczekiwane.append((8, suma_migracji_8()))
            if wersja == 9:
                oczekiwane.append((9, suma_migracji_9()))
            wpisy = conn.execute(
                "SELECT wersja,suma_sha256 FROM migracje ORDER BY wersja"
            ).fetchall()
            if wersja not in (4, 5, 6, 7, 8, 9) or [tuple(w) for w in wpisy] != oczekiwane:
                raise BladTechniczny("Nie potwierdzono schematu przed aktualizacją dopasowań.")
            if wersja in (5, 6, 7, 8, 9):
                return
            if not kopia_juz_jest:
                self._kopia_przed_migracja()
            for sql in MIGRACJA_5:
                conn.execute(sql)
            conn.execute(
                "INSERT INTO migracje VALUES (5,?,?)",
                (suma_migracji_5(), datetime.now(UTC).isoformat()),
            )
            if conn.execute("PRAGMA foreign_key_check").fetchall():
                raise BladTechniczny("Niespójne dopasowania po aktualizacji.")
            conn.execute("PRAGMA user_version = 5")

    def _migruj_do_4(self, conn: sqlite3.Connection, kopia_juz_jest: bool) -> None:
        with conn:
            conn.execute("BEGIN IMMEDIATE")
            wersja = conn.execute("PRAGMA user_version").fetchone()[0]
            oczekiwane = [
                (1, hashlib.sha256(SCHEMAT.encode()).hexdigest()),
                (2, suma_migracji_2()),
                (3, suma_migracji_3()),
            ]
            if wersja in (4, 5, 6, 7, 8, 9):
                oczekiwane.append((4, suma_migracji_4()))
            if wersja in (5, 6, 7, 8, 9):
                oczekiwane.append((5, suma_migracji_5()))
            if wersja in (6, 7, 8, 9):
                oczekiwane.append((6, suma_migracji_6()))
            if wersja in (7, 8, 9):
                oczekiwane.append((7, suma_migracji_7()))
            if wersja in (8, 9):
                oczekiwane.append((8, suma_migracji_8()))
            if wersja == 9:
                oczekiwane.append((9, suma_migracji_9()))
            rows = conn.execute(
                "SELECT wersja,suma_sha256 FROM migracje ORDER BY wersja"
            ).fetchall()
            if wersja not in (3, 4, 5, 6, 7, 8, 9) or [tuple(r) for r in rows] != oczekiwane:
                raise BladTechniczny("Nie potwierdzono schematu przed aktualizacją cen.")
            if wersja in (4, 5, 6, 7, 8, 9):
                return
            if not kopia_juz_jest:
                self._kopia_przed_migracja()
            for sql in MIGRACJA_4:
                conn.execute(sql)
            conn.execute(
                "INSERT INTO migracje VALUES (4, ?, ?)",
                (suma_migracji_4(), datetime.now(UTC).isoformat()),
            )
            if conn.execute("PRAGMA foreign_key_check").fetchall():
                raise BladTechniczny("Niespójne dane po aktualizacji cen.")
            conn.execute("PRAGMA user_version = 4")

    def _migruj_do_3(self, polaczenie: sqlite3.Connection, kopia_juz_jest: bool) -> None:
        with polaczenie:
            polaczenie.execute("BEGIN IMMEDIATE")
            wersja = polaczenie.execute("PRAGMA user_version").fetchone()[0]
            oczekiwane = [(1, hashlib.sha256(SCHEMAT.encode()).hexdigest()), (2, suma_migracji_2())]
            if wersja in (3, 4, 5, 6, 7, 8, 9):
                oczekiwane.append((3, suma_migracji_3()))
            if wersja in (4, 5, 6, 7, 8, 9):
                oczekiwane.append((4, suma_migracji_4()))
            if wersja in (5, 6, 7, 8, 9):
                oczekiwane.append((5, suma_migracji_5()))
            if wersja in (6, 7, 8, 9):
                oczekiwane.append((6, suma_migracji_6()))
            if wersja in (7, 8, 9):
                oczekiwane.append((7, suma_migracji_7()))
            if wersja in (8, 9):
                oczekiwane.append((8, suma_migracji_8()))
            if wersja == 9:
                oczekiwane.append((9, suma_migracji_9()))
            wpisy = polaczenie.execute(
                "SELECT wersja, suma_sha256 FROM migracje ORDER BY wersja"
            ).fetchall()
            if wersja not in (2, 3, 4, 5, 6, 7, 8, 9) or [tuple(w) for w in wpisy] != oczekiwane:
                raise BladTechniczny("Nie potwierdzono schematu przed aktualizacją importu.")
            if wersja in (3, 4, 5, 6, 7, 8, 9):
                return
            if not kopia_juz_jest:
                self._kopia_przed_migracja()
            for sql in MIGRACJA_3:
                polaczenie.execute(sql)
            polaczenie.execute(
                "INSERT INTO migracje VALUES (3, ?, ?)",
                (suma_migracji_3(), datetime.now(UTC).isoformat()),
            )
            if polaczenie.execute("PRAGMA foreign_key_check").fetchall():
                raise BladTechniczny("Nie potwierdzono spójności po aktualizacji importu.")
            polaczenie.execute("PRAGMA user_version = 3")

    def _migruj_do_2(self, polaczenie: sqlite3.Connection, nowa: bool) -> None:
        with polaczenie:
            polaczenie.execute("BEGIN IMMEDIATE")
            wersja = polaczenie.execute("PRAGMA user_version").fetchone()[0]
            if wersja in (2, 3, 4, 5, 6, 7, 8, 9):
                return
            if wersja != 1:
                raise BladTechniczny("Wersja bazy zmieniła się podczas aktualizacji.")
            wpisy = polaczenie.execute("SELECT wersja, suma_sha256 FROM migracje").fetchall()
            if [tuple(w) for w in wpisy] != [(1, hashlib.sha256(SCHEMAT.encode()).hexdigest())]:
                raise BladTechniczny("Nie potwierdzono wersji schematu. Zachowaj kopię bazy.")
            if not nowa or polaczenie.execute("SELECT 1 FROM produkty LIMIT 1").fetchone():
                self._kopia_przed_migracja()
            for sql in MIGRACJA_2:
                polaczenie.execute(sql)
            polaczenie.execute(
                "INSERT INTO migracje VALUES (2, ?, ?)",
                (suma_migracji_2(), datetime.now(UTC).isoformat()),
            )
            if polaczenie.execute("PRAGMA foreign_key_check").fetchall():
                raise BladTechniczny("Nie potwierdzono spójności bazy po aktualizacji.")
            polaczenie.execute("PRAGMA user_version = 2")

    def _kopia_przed_migracja(self) -> None:
        self._kopia_spojna("kopie_migracji")

    def _kopia_spojna(self, podkatalog: str) -> Path:
        katalog = self.plik.parent / podkatalog
        katalog.mkdir(exist_ok=True)
        with closing(sqlite3.connect(self.plik)) as odczyt:
            wersja = odczyt.execute("PRAGMA user_version").fetchone()[0]
        cel = katalog / f"{self.plik.stem}-schemat-{wersja}-{uuid4().hex}.sqlite3"
        with cel.open("xb"):
            pass
        try:
            # Główne połączenie ma RESERVED lock; drugie może odczytać spójny stan.
            with (
                closing(sqlite3.connect(self.plik)) as zrodlo,
                closing(sqlite3.connect(cel)) as kopia,
            ):
                zrodlo.backup(kopia)
                if kopia.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise BladTechniczny("Nie potwierdzono integralności kopii przed aktualizacją.")
        except (sqlite3.Error, OSError, BladTechniczny):
            cel.unlink(missing_ok=True)
            raise

        return cel

    @staticmethod
    def _produkt(
        wiersz: sqlite3.Row, dopasowania: tuple[DopasowanieMotocykla, ...] = ()
    ) -> Produkt:
        try:
            return Produkt(
                UUID(wiersz["id"]),
                wiersz["nazwa"],
                wiersz["sku"],
                wiersz["opis"],
                wiersz["wersja"],
                UUID(wiersz["producent_id"]) if wiersz["producent_id"] is not None else None,
                dopasowania,
            )
        except (ValueError, TypeError, NieprawidlowyProdukt) as blad:
            raise BladTechniczny(
                "Katalog zawiera nieprawidłowe dane. Zachowaj kopię bazy."
            ) from blad

    @staticmethod
    def _odczytaj_dopasowania(
        conn: sqlite3.Connection,
    ) -> dict[str, tuple[DopasowanieMotocykla, ...]]:
        wynik: dict[str, list[DopasowanieMotocykla]] = {}
        try:
            for r in conn.execute("SELECT * FROM dopasowania ORDER BY produkt_id,kolejnosc"):
                wynik.setdefault(r["produkt_id"], []).append(
                    DopasowanieMotocykla(
                        r["marka"], r["model"], r["rok_od"], r["rok_do"], r["wariant"]
                    )
                )
        except (ValueError, TypeError, NieprawidlowyProdukt) as exc:
            raise BladTechniczny("Katalog zawiera nieprawidłowe dopasowania.") from exc
        return {pid: tuple(w) for pid, w in wynik.items()}

    @staticmethod
    def _zapisz_dopasowania(conn: sqlite3.Connection, produkt: Produkt) -> None:
        conn.execute("DELETE FROM dopasowania WHERE produkt_id=?", (str(produkt.id),))
        conn.executemany(
            "INSERT INTO dopasowania VALUES (?,?,?,?,?,?,?)",
            (
                (str(produkt.id), i, d.marka, d.model, d.rok_od, d.rok_do, d.wariant)
                for i, d in enumerate(produkt.dopasowania)
            ),
        )

    def wyszukaj(self, fraza: str) -> list[Produkt]:
        with self._polaczenie() as conn:
            conn.execute("BEGIN")
            wiersze = conn.execute(
                "SELECT * FROM produkty ORDER BY nazwa COLLATE NOCASE,id"
            ).fetchall()
            dopasowania = self._odczytaj_dopasowania(conn)
        fraza = fraza.casefold()
        return [
            self._produkt(w, dopasowania.get(w["id"], ()))
            for w in wiersze
            if fraza in w["nazwa"].casefold() or fraza in w["sku"].casefold()
        ]

    def pobierz(self, id_produktu: UUID) -> Produkt | None:
        with self._polaczenie() as conn:
            conn.execute("BEGIN")
            wiersz = conn.execute(
                "SELECT * FROM produkty WHERE id=?", (str(id_produktu),)
            ).fetchone()
            dopasowania = self._odczytaj_dopasowania(conn)
        return (
            None if wiersz is None else self._produkt(wiersz, dopasowania.get(str(id_produktu), ()))
        )

    def dodaj(self, produkt: Produkt) -> None:
        with self._polaczenie() as polaczenie:
            polaczenie.execute("BEGIN IMMEDIATE")
            self._sprawdz_przypisanie(polaczenie, produkt, None)
            polaczenie.execute(
                "INSERT INTO produkty (id, nazwa, sku, sku_klucz, opis, wersja, producent_id) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    str(produkt.id),
                    produkt.nazwa,
                    produkt.sku,
                    produkt.klucz_sku,
                    produkt.opis,
                    produkt.wersja,
                    str(produkt.producent_id) if produkt.producent_id else None,
                ),
            )

            self._zapisz_dopasowania(polaczenie, produkt)

    def zapisz(self, produkt: Produkt, oczekiwana_wersja: int) -> None:
        with self._polaczenie() as polaczenie:
            polaczenie.execute("BEGIN IMMEDIATE")
            stary = polaczenie.execute(
                "SELECT producent_id, wersja FROM produkty WHERE id=?", (str(produkt.id),)
            ).fetchone()
            if stary is None or stary["wersja"] != oczekiwana_wersja:
                raise KonfliktEdycji("Produkt zmieniono równocześnie. Odśwież katalog.")
            self._sprawdz_przypisanie(polaczenie, produkt, stary["producent_id"])
            wynik = polaczenie.execute(
                "UPDATE produkty SET nazwa=?, sku=?, sku_klucz=?, opis=?, wersja=?, producent_id=? "
                "WHERE id=? AND wersja=?",
                (
                    produkt.nazwa,
                    produkt.sku,
                    produkt.klucz_sku,
                    produkt.opis,
                    produkt.wersja,
                    str(produkt.producent_id) if produkt.producent_id else None,
                    str(produkt.id),
                    oczekiwana_wersja,
                ),
            )
            if wynik.rowcount != 1:
                raise KonfliktEdycji("Produkt zmieniono równocześnie. Odśwież katalog.")

            self._zapisz_dopasowania(polaczenie, produkt)

    @staticmethod
    def _sprawdz_przypisanie(
        polaczenie: sqlite3.Connection, produkt: Produkt, poprzedni: str | None
    ) -> None:
        if produkt.producent_id is None:
            return
        producent = polaczenie.execute(
            "SELECT aktywny FROM producenci WHERE id=?", (str(produkt.producent_id),)
        ).fetchone()
        if producent is None:
            raise ProducentNieIstnieje("Wybrany producent nie istnieje. Odśwież listę.")
        if not producent["aktywny"] and str(produkt.producent_id) != poprzedni:
            raise ProducentNieaktywny("Producent jest nieaktywny. Wybierz aktywnego producenta.")

    @staticmethod
    def _producent(wiersz: sqlite3.Row) -> Producent:
        try:
            return Producent(
                UUID(wiersz["id"]),
                wiersz["nazwa"],
                bool(wiersz["aktywny"]),
                wiersz["wersja"],
                wiersz["strona_www"],
            )
        except (ValueError, TypeError, NieprawidlowyProducent) as blad:
            raise BladTechniczny("Rejestr producentów zawiera nieprawidłowe dane.") from blad

    def lista_producentow(self) -> list[Producent]:
        with self._polaczenie() as polaczenie:
            wiersze = polaczenie.execute(
                "SELECT id, nazwa, aktywny, wersja, strona_www FROM producenci "
                "ORDER BY nazwa COLLATE NOCASE, id"
            ).fetchall()
        return [self._producent(w) for w in wiersze]

    def pobierz_producenta(self, id_producenta: UUID) -> Producent | None:
        with self._polaczenie() as polaczenie:
            wiersz = polaczenie.execute(
                "SELECT id, nazwa, aktywny, wersja, strona_www FROM producenci WHERE id=?",
                (str(id_producenta),),
            ).fetchone()
        return None if wiersz is None else self._producent(wiersz)

    def dodaj_producenta(self, producent: Producent) -> None:
        with self._polaczenie() as polaczenie:
            polaczenie.execute(
                "INSERT INTO producenci (id, nazwa, aktywny, wersja, strona_www) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    str(producent.id),
                    producent.nazwa,
                    int(producent.aktywny),
                    producent.wersja,
                    producent.strona_www,
                ),
            )

    def zapisz_producenta(self, producent: Producent, oczekiwana_wersja: int) -> None:
        with self._polaczenie() as polaczenie:
            wynik = polaczenie.execute(
                "UPDATE producenci SET nazwa=?, aktywny=?, wersja=?, strona_www=? "
                "WHERE id=? AND wersja=?",
                (
                    producent.nazwa,
                    int(producent.aktywny),
                    producent.wersja,
                    producent.strona_www,
                    str(producent.id),
                    oczekiwana_wersja,
                ),
            )
            if wynik.rowcount != 1:
                raise KonfliktEdycji("Producent zmienił się równocześnie. Odśwież listę.")

    def wykonaj_kopie(self, cel: Path) -> None:
        if cel.resolve() == self.plik.resolve():
            raise BladTechniczny("Kopia musi mieć inną ścieżkę niż aktywna baza.")
        utworzony = False
        try:
            with cel.open("xb"):
                utworzony = True
            with self._polaczenie() as zrodlo:
                kopia = sqlite3.connect(cel)
                try:
                    zrodlo.backup(kopia)
                    if kopia.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                        raise BladTechniczny("Nie potwierdzono integralności kopii.")
                finally:
                    kopia.close()
        except (OSError, sqlite3.Error, BladTechniczny) as blad:
            if utworzony:
                cel.unlink(missing_ok=True)
            raise BladTechniczny(
                "Nie można utworzyć kopii. Nie nadpisano istniejącego pliku."
            ) from blad

    def ceny_sugerowane(self) -> dict[UUID, CenaSugerowanaDTO]:
        with self._polaczenie() as conn:
            rows = conn.execute("SELECT * FROM ceny_sugerowane").fetchall()
        return {
            UUID(r["produkt_id"]): CenaSugerowanaDTO(
                r["kwota"], r["waluta"], r["rodzaj"], r["zrodlo"]
            )
            for r in rows
        }

    def usun_produkty(self, produkty: tuple[tuple[UUID, int], ...]) -> Path:
        if not produkty or len({p[0] for p in produkty}) != len(produkty):
            raise BladTechniczny("Nieprawidłowy zakres usuwania.")
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            for pid, wersja in produkty:
                row = conn.execute("SELECT wersja FROM produkty WHERE id=?", (str(pid),)).fetchone()
                if row is None or row[0] != wersja:
                    raise KonfliktEdycji(
                        "Katalog zmienił się. Odśwież i ponownie wybierz usuwanie."
                    )
            for pid, _ in produkty:
                if conn.execute("SELECT 1 FROM szkice WHERE produkt_id=?", (str(pid),)).fetchone():
                    raise KonfliktEdycji("Produkt ma lokalne szkice. Najpierw usuń jego szkice.")
            kopia = self._kopia_spojna("kopie_usuwania")
            for pid, _ in produkty:
                conn.execute("DELETE FROM zdjecia WHERE produkt_id=?", (str(pid),))
                conn.execute("DELETE FROM import_powiazania WHERE produkt_id=?", (str(pid),))
                conn.execute("DELETE FROM ceny_sugerowane WHERE produkt_id=?", (str(pid),))
                conn.execute("DELETE FROM dopasowania WHERE produkt_id=?", (str(pid),))
                conn.execute("DELETE FROM produkty WHERE id=?", (str(pid),))
        return kopia

    def zapisz_wiele(self, produkty: tuple[Produkt, ...]) -> Path:
        if not produkty or len({p.id for p in produkty}) != len(produkty):
            raise BladTechniczny("Nieprawidłowy zakres edycji masowej.")
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            for p in produkty:
                row = conn.execute(
                    "SELECT wersja,producent_id FROM produkty WHERE id=?", (str(p.id),)
                ).fetchone()
                if row is None or row["wersja"] != p.wersja - 1:
                    raise KonfliktEdycji("Katalog zmienił się. Odśwież przed edycją masową.")
                self._sprawdz_przypisanie(conn, p, row["producent_id"])
            kopia = self._kopia_spojna("kopie_edycji_masowej")
            for p in produkty:
                conn.execute(
                    "UPDATE produkty SET nazwa=?,sku=?,sku_klucz=?,opis=?,wersja=?,"
                    "producent_id=? WHERE id=?",
                    (
                        p.nazwa,
                        p.sku,
                        p.klucz_sku,
                        p.opis,
                        p.wersja,
                        str(p.producent_id) if p.producent_id else None,
                        str(p.id),
                    ),
                )
                self._zapisz_dopasowania(conn, p)
        return kopia

    def miniatury(self) -> dict[UUID, bytes]:
        with self._polaczenie() as conn:
            rows = conn.execute(
                "SELECT produkt_id,miniatura FROM zdjecia WHERE kolejnosc=0"
            ).fetchall()
        return {UUID(r[0]): bytes(r[1]) for r in rows}

    @staticmethod
    def _zdjecia(
        conn: sqlite3.Connection, produkt_id: UUID, zdjecia: tuple[ZdjecieDane, ...]
    ) -> None:
        if not 1 <= len(zdjecia) <= 5:
            raise BladTechniczny("Wybierz od 1 do 5 zdjęć.")
        conn.execute("DELETE FROM zdjecia WHERE produkt_id=?", (str(produkt_id),))
        for i, z in enumerate(zdjecia):
            if not z.dane or not z.miniatura or len(z.dane) > 8 * 1024 * 1024:
                raise BladTechniczny("Nieprawidłowe dane zdjęcia.")
            conn.execute(
                "INSERT INTO zdjecia VALUES (?,?,?,?,?,?)",
                (str(uuid4()), str(produkt_id), z.zrodlo, z.dane, z.miniatura, i),
            )

    def dodaj_z_mediami(self, produkt: Produkt, zdjecia: tuple[ZdjecieDane, ...]) -> None:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            self._sprawdz_przypisanie(conn, produkt, None)
            conn.execute(
                "INSERT INTO produkty (id,nazwa,sku,sku_klucz,opis,wersja,producent_id) "
                "VALUES (?,?,?,?,?,?,?)",
                (
                    str(produkt.id),
                    produkt.nazwa,
                    produkt.sku,
                    produkt.klucz_sku,
                    produkt.opis,
                    produkt.wersja,
                    str(produkt.producent_id) if produkt.producent_id else None,
                ),
            )
            self._zapisz_dopasowania(conn, produkt)
            self._zdjecia(conn, produkt.id, zdjecia)

    def zapisz_z_mediami(
        self, produkt: Produkt, wersja: int, zdjecia: tuple[ZdjecieDane, ...]
    ) -> None:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT wersja,producent_id FROM produkty WHERE id=?", (str(produkt.id),)
            ).fetchone()
            if row is None or row["wersja"] != wersja:
                raise KonfliktEdycji("Produkt zmienił się. Odśwież przed zapisem zdjęć.")
            self._sprawdz_przypisanie(conn, produkt, row["producent_id"])
            self._kopia_spojna("kopie_zdjec")
            conn.execute(
                "UPDATE produkty SET nazwa=?,sku=?,sku_klucz=?,opis=?,wersja=?,"
                "producent_id=? WHERE id=?",
                (
                    produkt.nazwa,
                    produkt.sku,
                    produkt.klucz_sku,
                    produkt.opis,
                    produkt.wersja,
                    str(produkt.producent_id) if produkt.producent_id else None,
                    str(produkt.id),
                ),
            )
            self._zapisz_dopasowania(conn, produkt)
            self._zdjecia(conn, produkt.id, zdjecia)

    def odczytaj_galerie(self, produkt_id: UUID) -> GaleriaDTO:
        with self._polaczenie() as conn:
            conn.execute("BEGIN")
            row = conn.execute(
                "SELECT wersja FROM produkty WHERE id=?", (str(produkt_id),)
            ).fetchone()
            if row is None:
                raise BladScenariuszaKatalogu("MEDIA", "Produkt nie istnieje. Odśwież katalog.")
            zdjecia = tuple(
                ZdjecieDane(r[0], bytes(r[1]), bytes(r[2]))
                for r in conn.execute(
                    "SELECT zrodlo,dane,miniatura FROM zdjecia "
                    "WHERE produkt_id=? ORDER BY kolejnosc",
                    (str(produkt_id),),
                )
            )
            return GaleriaDTO(produkt_id, row[0], zdjecia)

    def zapisz_galerie(self, galeria: GaleriaDTO) -> Path:
        if len(galeria.zdjecia) > 5:
            raise BladScenariuszaKatalogu("MEDIA", "Galeria mieści maksymalnie 5 zdjęć.")
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT wersja FROM produkty WHERE id=?", (str(galeria.produkt_id),)
            ).fetchone()
            if row is None or row[0] != galeria.wersja:
                raise BladScenariuszaKatalogu(
                    "KONFLIKT", "Produkt zmienił się. Zamknij galerię i odśwież katalog."
                )
            kopia = self._kopia_spojna("kopie_zdjec")
            if galeria.zdjecia:
                self._zdjecia(conn, galeria.produkt_id, galeria.zdjecia)
            else:
                conn.execute("DELETE FROM zdjecia WHERE produkt_id=?", (str(galeria.produkt_id),))
            conn.execute(
                "UPDATE produkty SET wersja=wersja+1 WHERE id=?", (str(galeria.produkt_id),)
            )
        return kopia
