import pytest
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QFileDialog, QMessageBox

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow


@pytest.fixture
def okno(qtbot, tmp_path):
    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    importer = ImportujProdukty(CzytnikTabel(), repo, repo)
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        importer,
        cenniki=BibliotekaCennikow(repo, importer),
    )
    qtbot.addWidget(w)
    w.show()
    qtbot.waitUntil(lambda: not w._zadania)
    yield w
    qtbot.waitUntil(lambda: not w._zadania)
    w.close()


def czekaj(qtbot, w):
    qtbot.waitUntil(lambda: not w._zadania and not w.strona_importu._trwa)


def wczytaj(qtbot, w, tmp_path, monkeypatch):
    w.przejdz("Cenniki")
    czekaj(qtbot, w)
    s = w.strona_cennikow
    s.nowy()
    czekaj(qtbot, w)
    plik = tmp_path / "cennik.csv"
    plik.write_text("SKU;Nazwa\nA;Pierwszy\nB;Drugi\n", encoding="utf-8")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **kw: (str(plik), ""))
    i = w.strona_importu
    i.wybierz_plik()
    czekaj(qtbot, w)
    i.kol_nazwa.setCurrentIndex(i.kol_nazwa.findData(1))
    i.kol_sku.setCurrentIndex(i.kol_sku.findData(0))
    i.podglad.click()
    czekaj(qtbot, w)
    assert s.zapisz.isEnabled() and not i.zapisz.isVisible()
    s.nazwa.setText("Cennik testowy")
    s.rok.setValue(2025)
    s.zapisz.click()
    czekaj(qtbot, w)
    return s


def test_cennik_z_rokiem_wybor_dodanie_usuwanie_bez_produktow(qtbot, okno, tmp_path, monkeypatch):
    s = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    assert s.stos.currentWidget() is s.biblioteka
    assert s.tabela.item(0, 2).text() == "2025"
    assert okno.katalog.wyszukaj() == []
    assert len(okno._przyciski_produktow) == 3
    assert not any("Importuj" in a.text() for a in okno.menu_kontekstowe_produktow.actions())
    s.tabela.selectRow(0)
    s.otworz()
    czekaj(qtbot, okno)
    qtbot.waitUntil(lambda: s.wiersze.isEnabled())
    s.wiersze.selectRow(1)
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **kw: QMessageBox.StandardButton.Yes)
    s.dodaj()
    czekaj(qtbot, okno)
    assert [p.sku for p in okno.katalog.wyszukaj()] == ["B"]
    assert "Dodano: 1" in s.raport.text()
    s.wroc()
    czekaj(qtbot, okno)
    s.tabela.selectAll()
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **kw: QMessageBox.StandardButton.No)
    s.usun()
    assert s.tabela.rowCount() == 1
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **kw: QMessageBox.StandardButton.Yes)
    s.usun()
    czekaj(qtbot, okno)
    assert s.tabela.rowCount() == 0 and len(okno.katalog.wyszukaj()) == 1


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_filtr_wybor_i_korekty_w_obu_motywach(qtbot, okno, tmp_path, monkeypatch, motyw):
    s = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(motyw))
    s.szukaj.setText("nieznany")
    assert s.tabela.rowCount() == 0
    s.szukaj.clear()
    s.tabela.selectRow(0)
    s.otworz()
    czekaj(qtbot, okno)
    s.filtr.setText("Pierwszy")
    qtbot.waitUntil(lambda: s.wiersze.isEnabled())
    assert s.wiersze.rowCount() == 1
    s.wroc()
    czekaj(qtbot, okno)
    okno.pokaz_korekty()
    czekaj(qtbot, okno)
    assert s.stos.currentWidget() is s.kreator and okno.strona_importu.tabs.currentIndex() == 1


def test_duza_lista_filtr_uniewaznia_stare_partie_i_menu_z_klawiatury(qtbot, okno, monkeypatch):
    from uuid import uuid4

    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QMenu

    from vexlab.przypadki_uzycia.cenniki import PozycjaCennika
    from vexlab.przypadki_uzycia.importowanie import PozycjaImportu
    from vexlab.przypadki_uzycia.katalog import DaneProduktu

    s = okno.strona_cennikow
    s.stos.setCurrentWidget(s.szczegoly)
    okno.przejdz("Cenniki")
    czekaj(qtbot, okno)
    s.pozycje = tuple(
        PozycjaCennika(
            i,
            PozycjaImportu(
                uuid4(), uuid4(), "test.csv", "A", i + 2, DaneProduktu(f"Produkt {i}", f"SKU-{i}")
            ),
            "Gotowy",
            False,
        )
        for i in range(3000)
    )
    s._wiersze()
    assert not s.wiersze.isEnabled()
    s.filtr.setText("SKU-2999")
    qtbot.waitUntil(lambda: s.wiersze.isEnabled())
    qtbot.wait(20)
    assert s.wiersze.rowCount() == 1 and s.wiersze.item(0, 2).text() == "SKU-2999"
    s.wiersze.selectAll()
    s.wiersze.setFocus()
    menus = []
    monkeypatch.setattr(QMenu, "popup", lambda menu, *a: menus.append(menu))
    qtbot.keyClick(s.wiersze, Qt.Key.Key_F10, Qt.KeyboardModifier.ShiftModifier)
    assert menus and menus[0].actions()[0].text() == "Dodaj do katalogu"
    assert menus[0].actions()[0].isEnabled()
    assert len(s.wiersze.selectionModel().selectedRows()) == 1
    s.filtr.clear()
    s.wroc()
    czekaj(qtbot, okno)
    qtbot.wait(20)
    assert s.stos.currentWidget() is s.biblioteka
