import shutil
import sqlite3
from contextlib import closing
from dataclasses import replace
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.importowanie import CenaImportu, ImportujProdukty, PozycjaImportu
from vexlab.przypadki_uzycia.katalog import DaneDopasowania, DaneProduktu, KatalogProduktow
from vexlab.rdzen.kontrakty import BladTechniczny


@pytest.fixture
def uslugi(tmp_path):
    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    importer = ImportujProdukty(CzytnikTabel(), repo, repo)
    return BibliotekaCennikow(repo, importer), KatalogProduktow(repo, repo), repo


def pozycje():
    paczka = uuid4()
    return tuple(
        PozycjaImportu(
            uuid4(),
            paczka,
            "user.csv",
            "A",
            i + 2,
            DaneProduktu(
                nazwa,
                sku,
                "Opis",
                None,
                (DaneDopasowania("Marka", "Model", "2020", "2024", ""),) if i == 0 else (),
            ),
            cena=CenaImportu("12,30", "EUR", "brutto"),
        )
        for i, (nazwa, sku) in enumerate((("Pierwszy", "ABC"), ("Drugi", "DEF"), ("Błędny", "")))
    )


def zapisz(s, rows=None):
    s.zapisz("Cennik użytkownika", 2025, "marzec", s.importer.ocen(rows or pozycje()))
    return s.lista()[0]


def test_zapis_bez_produktow_restart_wybor_i_pominiecie_znanych(uslugi):
    s, kat, repo = uslugi
    rows = pozycje()
    c = zapisz(s, rows)
    assert kat.wyszukaj() == [] and repo.oczekujace() == ()
    assert c.rok == 2025 and c.wydanie == "marzec" and c.liczba == 3
    restart = BibliotekaCennikow(CennikiSQLite(repo.plik), s.importer)
    assert tuple(p.pozycja for p in restart.pozycje(c)) == rows
    wynik = restart.dodaj(c, frozenset({0}))
    assert (wynik.dodane, wynik.odlozone, wynik.pominiete) == (1, 0, 0)
    p = kat.wyszukaj()[0]
    assert p.sku == "ABC" and p.dopasowania[0].rok_do == 2024
    assert p.cena_sugerowana.waluta == "EUR" and p.cena_sugerowana.kwota == "12.30"
    assert repo.oczekujace() == ()
    assert restart.pozycje(c)[0].w_katalogu
    w = s.dodaj(c, frozenset({0, 1, 2}))
    assert (w.dodane, w.odlozone, w.pominiete) == (1, 1, 1)
    assert next(x for x in kat.wyszukaj() if x.sku == "ABC") == p
    assert len(repo.oczekujace()) == 1
    assert "Brak SKU" in repo.oczekujace()[0].powod
    assert s.dodaj(c, frozenset({0, 1})).kopia is None


def test_usuwanie_wielu_kopia_i_produkty_pozostaja(uslugi, tmp_path):
    s, kat, repo = uslugi
    c = zapisz(s)
    s.dodaj(c, frozenset({0, 2}))
    zapisz(s)
    zapisane = s.lista()
    produkty, robocze = kat.wyszukaj(), repo.oczekujace()
    kopia = s.usun(zapisane)
    assert s.lista() == () and kat.wyszukaj() == produkty and repo.oczekujace() == robocze
    restore = tmp_path / "restore.sqlite3"
    shutil.copyfile(kopia, restore)
    assert CennikiSQLite(restore).lista() == zapisane
    with pytest.raises(BladScenariuszaKatalogu):
        s.dodaj(c, frozenset({1}))
    assert kat.wyszukaj() == produkty


def test_konflikt_blad_kopii_i_awaria_srodka_usuwania_atomowe(uslugi, tmp_path):
    s, kat, repo = uslugi
    c = zapisz(s)
    with pytest.raises(BladScenariuszaKatalogu):
        s.usun((replace(c, wersja=2),))
    folder = tmp_path / "kopie_cennikow"
    shutil.rmtree(folder)
    folder.write_text("blokada")
    with pytest.raises(BladTechniczny):
        s.dodaj(c, frozenset({0}))
    assert kat.wyszukaj() == [] and s.lista() == (c,)
    with pytest.raises(BladTechniczny):
        s.usun((c,))
    folder.unlink()
    zapisz(s)
    lists = s.lista()
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute(
            "CREATE TRIGGER stop_delete BEFORE DELETE ON cenniki WHEN old.id='"
            + str(lists[1].id)
            + "' BEGIN SELECT RAISE(ABORT,'stop'); END"
        )
    with pytest.raises(BladTechniczny):
        s.usun(lists)
    assert s.lista() == lists


def test_duplikat_mozna_wybrac_jeden_a_zly_cennik_nie_nadpisuje(uslugi):
    s, kat, repo = uslugi
    rows = pozycje()
    c = zapisz(s, (rows[0], replace(rows[1], dane=replace(rows[1].dane, sku="abc"))))
    assert "Powtórzone" in s.pozycje(c)[0].stan
    assert s.dodaj(c, frozenset({0})).dodane == 1
    assert s.dodaj(c, frozenset({1})).pominiete == 1
    for nazwa, rok in (("", 2025), ("A", 0)):
        with pytest.raises(BladScenariuszaKatalogu):
            s.zapisz(nazwa, rok, "", s.importer.ocen(rows))
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute("UPDATE cenniki SET dane_json='[{}]' WHERE id=?", (str(c.id),))
    with pytest.raises(BladTechniczny):
        s.pozycje(c)


def test_czesciowy_import_cofa_sie_po_bledzie(uslugi):
    s, kat, repo = uslugi
    c = zapisz(s)
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute(
            "CREATE TRIGGER stop_add BEFORE INSERT ON produkty WHEN new.sku='DEF' "
            "BEGIN SELECT RAISE(ABORT,'stop'); END"
        )
    with pytest.raises(BladTechniczny):
        s.dodaj(c, frozenset({0, 1}))
    assert kat.wyszukaj() == [] and repo.oczekujace() == ()


def test_migracja8_kopia_odtworzenie_i_suma(tmp_path):
    plik = tmp_path / "k.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_7.sql"
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.executescript(fixture.read_text())
    repo = CennikiSQLite(plik)
    assert repo.lista() == ()
    (kopia,) = (tmp_path / "kopie_migracji").glob("*.sqlite3")
    with closing(sqlite3.connect(kopia)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 7
    restore = tmp_path / "restore.sqlite3"
    shutil.copyfile(kopia, restore)
    assert CennikiSQLite(restore).lista() == ()
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.execute("UPDATE migracje SET suma_sha256='inna' WHERE wersja=8")
    with pytest.raises(BladTechniczny):
        repo.lista()


@pytest.mark.parametrize("kopia", [False, True])
def test_przerwana_migracja8_lub_brak_kopii_nie_zmienia_bazy(tmp_path, monkeypatch, kopia):
    plik = tmp_path / "k.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_7.sql"
    orig = sqlite3.connect
    with closing(orig(plik)) as conn, conn:
        conn.executescript(fixture.read_text())
    if kopia:
        (tmp_path / "kopie_migracji").write_text("blokada")

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("INSERT INTO migracje VALUES (8"):
                raise sqlite3.OperationalError("awaria")
            return super().execute(sql, parameters)

    if not kopia:
        monkeypatch.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
    with pytest.raises(BladTechniczny):
        CennikiSQLite(plik).lista()
    with closing(orig(plik)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 7
        assert not conn.execute("SELECT 1 FROM sqlite_master WHERE name='cenniki'").fetchall()


def test_migracja8_zachowuje_produkt_szkic_i_cene_w_kopii(tmp_path):
    from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
    from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
    from vexlab.przypadki_uzycia.szkice import SzkiceOfert

    plik = tmp_path / "k.sqlite3"
    repo = SzkiceSQLite(plik)
    kat = KatalogProduktow(repo, repo)
    szkice = SzkiceOfert(repo, kat)
    oferta = OfertaPodglad(1, "A", "Szkic", "<p>Opis</p>", "", "", "", (), (), ())
    szkice.zapisz(szkice.zaplanuj((oferta,), "user.zip"))
    before = szkice.lista()
    # Fixture opublikowanego schematu 7 z rzeczywistą treścią szkicu.
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.execute("DROP TABLE cenniki")
        conn.execute("DELETE FROM migracje WHERE wersja=8")
        conn.execute("PRAGMA user_version=7")
    cenniki = CennikiSQLite(plik)
    assert cenniki.lista() == ()
    assert szkice.lista() == before and kat.wyszukaj()[0].sku == "A"
    (kopia,) = (tmp_path / "kopie_migracji").glob("*.sqlite3")
    with closing(sqlite3.connect(kopia)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 7
        assert conn.execute("SELECT tytul FROM szkice").fetchone()[0] == "Szkic"
