"""Izolowany zrzut edytora; syntetyczna treść nigdy nie zasila aplikacji użytkownika."""

from collections.abc import Callable
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QBuffer, QIODevice, Qt, QTimer
from PySide6.QtGui import QColor, QImage, QPainter
from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.edytor_opisu import EdytorOpisu
from vexlab.gui.szkice import StronaSzkicow
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


def main() -> int:
    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    cel.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix="vexlab-editor-") as folder:
        repo = SzkiceSQLite(Path(folder) / "test.sqlite3")
        serwis = SzkiceOfert(repo, KatalogProduktow(repo, repo))
        opis = "<h2>Przykładowy opis</h2><p>Edytuj <b>tekst</b> bez znajomości HTML.</p>"
        oferta = OfertaPodglad(
            1,
            "DEMO-EDITOR",
            "Przykładowa oferta — edycja wizualna",
            opis,
            "",
            "",
            "",
            ("https://example.test/zdjecie.png",),
            (
                (ElementPodgladu("tekst", opis),),
                (
                    ElementPodgladu("tekst", "<p>Druga sekcja — zmień kolejność.</p>"),
                    ElementPodgladu("obraz", adres="https://example.test/zdjecie.png"),
                ),
            ),
            (),
        )
        serwis.zapisz(serwis.zaplanuj((oferta,), "test-visual.zip"))

        def uruchom(
            funkcja: Callable[[], object],
            sukces: Callable[[object], None],
            blad: Callable[[str, str], None],
        ) -> None:
            sukces(funkcja())  # Wyłącznie izolowany generator zrzutów.

        parent = QWidget()

        class ObrazTestowy:
            def pobierz_obraz(self, url: str) -> ZdjecieDane:
                image = QImage(640, 360, QImage.Format.Format_RGB32)
                image.fill(QColor("#f0f3f7"))
                painter = QPainter(image)
                painter.setBrush(QColor("#277f87"))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(110, 80, 420, 200, 30, 30)
                painter.setPen(QColor("white"))
                painter.drawText(image.rect(), Qt.AlignmentFlag.AlignCenter, "Zdjęcie testowe")
                painter.end()
                out = QBuffer()
                out.open(QIODevice.OpenModeFlag.WriteOnly)
                image.save(out, "PNG")
                data = bytes(out.data())
                return ZdjecieDane(url, data, data)

        strona = StronaSzkicow(serwis, uruchom, parent, PodgladZdjec(ObrazTestowy()))
        strona.odswiez()
        strona.tabela.selectRow(0)
        strona.edytuj()
        dialog = strona.dialog
        assert dialog is not None
        zastosuj_motyw(app, Motyw.CIEMNY)
        sukces = []
        editor = dialog.findChild(EdytorOpisu)
        assert editor is not None
        editor.lista.setCurrentRow(1)

        def jasny() -> None:
            sukces.append(dialog.grab().save(str(cel / "vexlab-edytor-opisu-light.png")))
            editor.tabs.setCurrentIndex(2)
            QTimer.singleShot(150, pelny_jasny)

        def pelny_jasny() -> None:
            sukces.append(dialog.grab().save(str(cel / "vexlab-pelna-oferta-light.png")))
            zastosuj_motyw(app, Motyw.CIEMNY)
            QTimer.singleShot(150, pelny_ciemny)

        def pelny_ciemny() -> None:
            sukces.append(dialog.grab().save(str(cel / "vexlab-pelna-oferta-dark.png")))
            dialog.reject()
            app.quit()

        def ciemny() -> None:
            sukces.append(dialog.grab().save(str(cel / "vexlab-edytor-opisu-dark.png")))
            zastosuj_motyw(app, Motyw.JASNY)
            QTimer.singleShot(150, jasny)

        QTimer.singleShot(200, ciemny)
        app.exec()
        return 0 if sukces == [True, True, True, True] else 1


if __name__ == "__main__":
    raise SystemExit(main())
