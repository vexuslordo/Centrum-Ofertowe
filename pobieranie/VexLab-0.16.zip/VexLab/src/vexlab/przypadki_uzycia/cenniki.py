"""Biblioteka źródeł importu, niezależna od katalogu Produktów."""

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Protocol
from uuid import UUID, uuid4

from vexlab.przypadki_uzycia.importowanie import (
    ImportujProdukty,
    OcenaPozycji,
    PozycjaImportu,
    blad,
)
from vexlab.przypadki_uzycia.katalog import _mapuj_bledy


@dataclass(frozen=True)
class CennikDTO:
    id: UUID
    nazwa: str
    rok: int
    wydanie: str
    producent: str
    zrodlo: str
    arkusz: str
    liczba: int
    wczytano_utc: str
    wersja: int


@dataclass(frozen=True)
class PozycjaCennika:
    indeks: int
    pozycja: PozycjaImportu
    stan: str
    w_katalogu: bool


@dataclass(frozen=True)
class WynikCennika:
    dodane: int
    odlozone: int
    pominiete: int
    kopia: Path | None


class MagazynCennikow(Protocol):
    def zapisz_cennik(
        self, nazwa: str, rok: int, wydanie: str, pozycje: tuple[PozycjaImportu, ...]
    ) -> UUID: ...
    def lista(self) -> tuple[CennikDTO, ...]: ...
    def pozycje(self, id: UUID, wersja: int) -> tuple[PozycjaImportu, ...]: ...
    def dodaj_pozycje(
        self, cennik: CennikDTO, oceny: tuple[OcenaPozycji, ...], pominiete: int
    ) -> WynikCennika: ...
    def usun(self, cenniki: tuple[tuple[UUID, int], ...]) -> Path: ...


class BibliotekaCennikow:
    def __init__(self, magazyn: MagazynCennikow, importer: ImportujProdukty) -> None:
        self.magazyn, self.importer = magazyn, importer

    def zapisz(self, nazwa: str, rok: int, wydanie: str, oceny: tuple[OcenaPozycji, ...]) -> UUID:
        if not nazwa.strip() or not 1000 <= rok <= 9999 or not oceny:
            raise blad("Podaj nazwę, rok cennika oraz sprawdź dane pliku.")
        if len({o.pozycja.dane.producent_id for o in oceny}) != 1:
            raise blad("Wybierz jednego producenta cennika lub brak producenta.")
        return self.magazyn.zapisz_cennik(
            nazwa.strip(), rok, wydanie.strip(), tuple(o.pozycja for o in oceny)
        )

    def lista(self) -> tuple[CennikDTO, ...]:
        return self.magazyn.lista()

    def pozycje(self, cennik: CennikDTO) -> tuple[PozycjaCennika, ...]:
        rows = self.magazyn.pozycje(cennik.id, cennik.wersja)
        znane = {p.klucz_sku for p in self.importer.katalog.wyszukaj("")}
        oceny = self.importer.ocen(rows)
        return tuple(
            PozycjaCennika(
                i,
                o.pozycja,
                "W katalogu"
                if o.pozycja.dane.sku.strip().casefold() in znane
                else o.problem or "Gotowy",
                o.pozycja.dane.sku.strip().casefold() in znane,
            )
            for i, o in enumerate(oceny)
        )

    def dodaj(self, cennik: CennikDTO, indeksy: frozenset[int]) -> WynikCennika:
        rows = self.magazyn.pozycje(cennik.id, cennik.wersja)
        if not indeksy or not indeksy <= set(range(len(rows))):
            raise blad("Zaznacz pozycje cennika do dodania.")
        znane = {p.klucz_sku for p in self.importer.katalog.wyszukaj("")}
        pominiete = sum(rows[i].dane.sku.strip().casefold() in znane for i in indeksy)
        paczka = uuid4()
        nowe = tuple(
            replace(
                rows[i],
                id=uuid4(),
                paczka=paczka,
                zrodlo=f"{cennik.nazwa} ({cennik.rok}) • {cennik.zrodlo}",
            )
            for i in sorted(indeksy)
            if rows[i].dane.sku.strip().casefold() not in znane
        )
        oceny = self.importer.ocen(nowe)
        with _mapuj_bledy():
            return self.magazyn.dodaj_pozycje(cennik, oceny, pominiete)

    def usun(self, cenniki: tuple[CennikDTO, ...]) -> Path:
        if not cenniki or len({c.id for c in cenniki}) != len(cenniki):
            raise blad("Zaznacz cenniki do usunięcia.")
        return self.magazyn.usun(tuple((c.id, c.wersja) for c in cenniki))
