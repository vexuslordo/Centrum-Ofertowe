"""Biblioteka cenników: źródło → wybór pozycji → katalog."""

from collections.abc import Callable
from pathlib import Path
from typing import cast

from PySide6.QtCore import QPoint, Qt, QTimer, Signal
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from vexlab.gui.importowanie import StronaImportu, tabela
from vexlab.gui.paczki_ofert import etykieta
from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.cenniki import (
    BibliotekaCennikow,
    CennikDTO,
    PozycjaCennika,
    WynikCennika,
)


class StronaCennikow(QWidget):
    zmieniono = Signal()

    def __init__(
        self, serwis: BibliotekaCennikow, importer: StronaImportu, uruchom: Uruchom
    ) -> None:
        super().__init__()
        self.serwis, self.importer, self.uruchom = serwis, importer, uruchom
        self.cenniki: tuple[CennikDTO, ...] = ()
        self.pozycje: tuple[PozycjaCennika, ...] = ()
        self.cennik: CennikDTO | None = None
        self._trwa = False
        self._generacja = 0
        self.setObjectName("strona")
        layout = QVBoxLayout(self)
        self.stos = QStackedWidget()
        layout.addWidget(self.stos, 1)
        self.info = etykieta("")
        layout.addWidget(self.info)
        self.raport = etykieta("")
        layout.addWidget(self.raport)
        self.biblioteka = QWidget()
        uklad = QVBoxLayout(self.biblioteka)
        tytul = etykieta("Cenniki")
        tytul.setObjectName("marka")
        uklad.addWidget(tytul)
        uklad.addWidget(
            etykieta("Zapisz cennik z rokiem. Otwórz go i dodaj wybrane pozycje do katalogu.")
        )
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj nazwy, producenta lub roku…")
        self.szukaj.textChanged.connect(self._lista)
        uklad.addWidget(self.szukaj)
        actions = QHBoxLayout()
        for tekst, fn in (
            ("Dodaj cennik", self.nowy),
            ("Otwórz", self.otworz),
            ("Odśwież", self.odswiez),
            ("Do poprawy", self.korekty),
            ("Usuń zaznaczone…", self.usun),
        ):
            b = QPushButton(tekst)
            b.clicked.connect(fn)
            if tekst == "Dodaj cennik":
                b.setObjectName("primary")
            actions.addWidget(b)
        uklad.addLayout(actions)
        self.tabela = tabela(
            ["Cennik", "Producent", "Rok", "Wydanie / data", "Pozycje", "Wczytano", "Plik"]
        )
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tabela.setAccessibleName("Zapisane cenniki")
        for i, width in enumerate((300, 160, 75, 160, 85, 170, 220)):
            self.tabela.setColumnWidth(i, width)
        self.tabela.doubleClicked.connect(self.otworz)
        self.tabela.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tabela.customContextMenuRequested.connect(self._menu_cennikow)
        uklad.addWidget(self.tabela, 1)
        self.stos.addWidget(self.biblioteka)
        self.kreator = QWidget()
        uklad = QVBoxLayout(self.kreator)
        top = QHBoxLayout()
        b = QPushButton("← Cenniki")
        b.clicked.connect(self.wroc)
        top.addWidget(b)
        self.zapisz = QPushButton("Zapisz cennik")
        self.zapisz.clicked.connect(self.zapisz_cennik)
        top.addWidget(self.zapisz)
        direct = QPushButton("Import bezpośredni…")
        direct.clicked.connect(self.bezposredni)
        top.addWidget(direct)
        uklad.addLayout(top)
        self.metadane = QWidget()
        form = QFormLayout(self.metadane)
        self.nazwa = QLineEdit()
        self.rok = QSpinBox()
        self.rok.setRange(0, 9999)
        self.rok.setSpecialValueText("Podaj rok")
        self.wydanie = QLineEdit()
        self.wydanie.setPlaceholderText("Opcjonalnie, np. marzec / wersja 2")
        form.addRow("Nazwa cennika *", self.nazwa)
        form.addRow("Rok *", self.rok)
        form.addRow("Wydanie / data", self.wydanie)
        uklad.addWidget(self.metadane)
        uklad.addWidget(importer, 1)
        self.stos.addWidget(self.kreator)
        self.wiersze: QTableWidget
        self.szczegoly = QWidget()
        uklad = QVBoxLayout(self.szczegoly)
        self.naglowek = etykieta("")
        uklad.addWidget(self.naglowek)
        top = QHBoxLayout()
        for tekst, fn in (
            ("← Cenniki", self.wroc),
            ("Dodaj do katalogu", self.dodaj),
            ("Zaznacz wszystkie", lambda: self.wiersze.selectAll()),
            ("Odznacz", lambda: self.wiersze.clearSelection()),
            ("Uzupełnij brakujące ceny…", self.ceny),
        ):
            b = QPushButton(tekst)
            b.clicked.connect(fn)
            top.addWidget(b)
        uklad.addLayout(top)
        self.filtr = QLineEdit()
        self.filtr.setPlaceholderText("Szukaj po SKU lub nazwie…")
        self.filtr.textChanged.connect(self._wiersze)
        uklad.addWidget(self.filtr)
        self.wiersze = tabela(["Wiersz", "Nazwa", "SKU", "Cena sugerowana", "Stan"])
        for i, width in enumerate((75, 500, 180, 180, 300)):
            self.wiersze.setColumnWidth(i, width)
        self.wiersze.setAccessibleName("Pozycje cennika — wybierz i dodaj do katalogu")
        self.wiersze.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.wiersze.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.wiersze.customContextMenuRequested.connect(self._menu_pozycji)
        uklad.addWidget(self.wiersze, 1)
        self.stos.addWidget(self.szczegoly)
        self.skroty: list[QShortcut] = []
        for t, menu in ((self.tabela, self._menu_cennikow), (self.wiersze, self._menu_pozycji)):
            for key in ("Shift+F10", "Menu"):
                skrot = QShortcut(QKeySequence(key), t)
                skrot.setContext(Qt.ShortcutContext.WidgetShortcut)
                skrot.activated.connect(lambda m=menu: m(QPoint(-1, -1)))
                self.skroty.append(skrot)
        importer.plan_zmieniony.connect(self._plan)
        importer.zmieniono.connect(self.zmieniono.emit)

    def _zadanie(self, fn: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self._trwa or self.importer._trwa:
            return
        self._trwa = True
        self.stos.setEnabled(False)
        self.info.setText("Trwa odczyt lub zapis…")

        def ok(w: object) -> None:
            self._trwa = False
            self.stos.setEnabled(True)
            sukces(w)

        def blad(k: str, tekst: str) -> None:
            self._trwa = False
            self.stos.setEnabled(True)
            self.info.setText(tekst)

        self.uruchom(fn, ok, blad)

    def wroc(self) -> None:
        if self._trwa or self.importer._trwa:
            return
        self._generacja += 1
        self.stos.setCurrentWidget(self.biblioteka)
        self.odswiez()

    def odswiez(self) -> None:
        def gotowe(w: object) -> None:
            self.cenniki = cast(tuple[CennikDTO, ...], w)
            self._lista()

        self._zadanie(self.serwis.lista, gotowe)

    def _lista(self) -> None:
        tekst = self.szukaj.text().strip().casefold()
        rows = [
            c
            for c in self.cenniki
            if tekst in f"{c.nazwa} {c.producent} {c.rok} {c.wydanie}".casefold()
        ]
        self.tabela.setRowCount(len(rows))
        for i, c in enumerate(rows):
            for j, value in enumerate(
                (
                    c.nazwa,
                    c.producent or "—",
                    str(c.rok),
                    c.wydanie or "—",
                    str(c.liczba),
                    c.wczytano_utc[:16].replace("T", " ") + " UTC",
                    c.zrodlo,
                )
            ):
                item = QTableWidgetItem(value)
                item.setData(Qt.ItemDataRole.UserRole, c)
                self.tabela.setItem(i, j, item)
        self.info.setText(
            f"Cenniki: {len(rows)}. Dwuklik otwiera pozycje; Ctrl+A zaznacza wszystkie wyniki."
        )

    def _wybrane(self) -> tuple[CennikDTO, ...]:
        return tuple(
            cast(
                CennikDTO,
                cast(QTableWidgetItem, self.tabela.item(i.row(), 0)).data(Qt.ItemDataRole.UserRole),
            )
            for i in self.tabela.selectionModel().selectedRows()
        )

    def nowy(self) -> None:
        self.nazwa.clear()
        self.rok.setValue(0)
        self.wydanie.clear()
        self.importer._uniewaznij()
        self.importer.tryb_biblioteki(True)
        self.metadane.show()
        self.zapisz.show()
        self.importer.tabs.setCurrentIndex(0)
        self.importer.odswiez()
        self.stos.setCurrentWidget(self.kreator)
        self.info.setText(
            "Wskaż plik, producenta i kolumny. Sprawdź dane, podaj nazwę oraz rok i zapisz cennik."
        )

    def _plan(self) -> None:
        self.zapisz.setEnabled(bool(self.importer.oceny))
        if self.importer.oceny and not self.nazwa.text().strip():
            self.nazwa.setText(Path(self.importer.oceny[0].pozycja.zrodlo).stem)

    def zapisz_cennik(self) -> None:
        args = self.nazwa.text(), self.rok.value(), self.wydanie.text(), self.importer.oceny

        def gotowe(w: object) -> None:
            self.wroc()

        self._zadanie(lambda: self.serwis.zapisz(*args), gotowe)

    def bezposredni(self) -> None:
        self.metadane.hide()
        self.zapisz.hide()
        self.importer.tryb_biblioteki(False)
        self.importer.tabs.setCurrentIndex(0)
        self.stos.setCurrentWidget(self.kreator)
        self.info.setText(
            "Import bezpośredni: zapis dodaje produkty do katalogu bez zapisywania cennika."
        )

    def korekty(self) -> None:
        self.bezposredni()
        self.importer.tabs.setCurrentIndex(1)
        self.importer.odswiez()

    def otworz(self) -> None:
        wybrane = self._wybrane()
        if len(wybrane) != 1:
            self.info.setText("Zaznacz jeden cennik do otwarcia.")
            return
        self.cennik = wybrane[0]
        self._odczytaj_pozycje()

    def _odczytaj_pozycje(self) -> None:
        c = self.cennik
        if c is None:
            return

        def gotowe(w: object) -> None:
            self.pozycje = cast(tuple[PozycjaCennika, ...], w)
            self.naglowek.setText(
                f"{c.nazwa} • {c.rok} • {c.producent or 'Bez producenta'} • {c.wydanie}"
            )
            self.stos.setCurrentWidget(self.szczegoly)
            self._wiersze()

        self._zadanie(lambda: self.serwis.pozycje(c), gotowe)

    def _wiersze(self) -> None:
        self._generacja += 1
        generacja = self._generacja
        filtr = self.filtr.text().strip().casefold()
        rows = [
            p
            for p in self.pozycje
            if filtr in f"{p.pozycja.dane.nazwa} {p.pozycja.dane.sku}".casefold()
        ]
        self.wiersze.clearSelection()
        self.wiersze.setEnabled(False)
        self.wiersze.setRowCount(len(rows))

        def part(start: int) -> None:
            if not isValid(self) or generacja != self._generacja:
                return
            for i in range(start, min(start + 100, len(rows))):
                p = rows[i]
                cena = p.pozycja.cena
                wartosci = (
                    str(p.pozycja.wiersz),
                    p.pozycja.dane.nazwa,
                    p.pozycja.dane.sku,
                    f"{cena.tekst} {cena.waluta} {cena.rodzaj}" if cena and cena.tekst else "—",
                    p.stan,
                )
                for j, value in enumerate(wartosci):
                    item = QTableWidgetItem(value)
                    item.setData(Qt.ItemDataRole.UserRole, p.indeks)
                    self.wiersze.setItem(i, j, item)
            if start + 100 < len(rows):
                QTimer.singleShot(0, lambda: part(start + 100))
            else:
                self.wiersze.setEnabled(True)
                self.info.setText(
                    f"Pozycje: {len(rows)}. Zaznacz wybrane i kliknij prawym "
                    f"przyciskiem → Dodaj do katalogu."
                )

        part(0)

    @staticmethod
    def _wybor_ppm(t: QTableWidget, punkt: QPoint) -> None:
        if punkt.x() < 0:
            return
        indeks = t.indexAt(punkt)
        if indeks.isValid() and not t.selectionModel().isRowSelected(indeks.row(), indeks.parent()):
            t.clearSelection()
            t.selectRow(indeks.row())
        elif not indeks.isValid():
            t.clearSelection()

    def _menu_cennikow(self, punkt: QPoint) -> None:
        self._wybor_ppm(self.tabela, punkt)
        menu = QMenu(self)
        menu.addAction("Otwórz", self.otworz).setEnabled(len(self._wybrane()) == 1)
        menu.addAction("Usuń zaznaczone…", self.usun).setEnabled(bool(self._wybrane()))
        menu.aboutToHide.connect(menu.deleteLater)
        menu.popup(
            self.tabela.viewport().mapToGlobal(
                punkt if punkt.x() >= 0 else self.tabela.viewport().rect().center()
            )
        )

    def _menu_pozycji(self, punkt: QPoint) -> None:
        self._wybor_ppm(self.wiersze, punkt)
        menu = QMenu(self)
        menu.addAction("Dodaj do katalogu", self.dodaj).setEnabled(
            bool(self.wiersze.selectionModel().selectedRows())
        )
        menu.addSeparator()
        menu.addAction("Zaznacz wszystkie", self.wiersze.selectAll)
        menu.aboutToHide.connect(menu.deleteLater)
        menu.popup(
            self.wiersze.viewport().mapToGlobal(
                punkt if punkt.x() >= 0 else self.wiersze.viewport().rect().center()
            )
        )

    def dodaj(self) -> None:
        c = self.cennik
        if c is None or not self.wiersze.isEnabled():
            return
        indeksy = frozenset(
            int(
                cast(QTableWidgetItem, self.wiersze.item(i.row(), 0)).data(Qt.ItemDataRole.UserRole)
            )
            for i in self.wiersze.selectionModel().selectedRows()
        )
        if not indeksy:
            self.info.setText("Zaznacz pozycje do dodania.")
            return
        odpowiedz = QMessageBox.question(
            self,
            "Dodaj do katalogu",
            f"Sprawdzić i dodać {len(indeksy)} pozycji?\nZnane SKU zostaną "
            f"pominięte, błędne pozycje trafią do Do poprawy.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if odpowiedz != QMessageBox.StandardButton.Yes:
            return

        def gotowe(w: object) -> None:
            wynik = cast(WynikCennika, w)
            self.zmieniono.emit()
            self._odczytaj_pozycje()
            self.raport.setText(
                f"Dodano: {wynik.dodane}, do poprawy: {wynik.odlozone}, "
                f"pominięto: {wynik.pominiete}. Kopia: {wynik.kopia or 'bez zmian'}"
            )

        self._zadanie(lambda: self.serwis.dodaj(c, indeksy), gotowe)

    def ceny(self) -> None:
        c = self.cennik
        if c is not None:
            self._zadanie(
                lambda: self.serwis.importer.zaplanuj_uzupelnienie_cen(
                    self.serwis.importer.ocen(self.serwis.magazyn.pozycje(c.id, c.wersja))
                ),
                self.importer._dialog_cen,
            )

    def usun(self) -> None:
        wybrane = self._wybrane()
        if not wybrane:
            self.info.setText("Zaznacz cenniki do usunięcia.")
            return
        if (
            QMessageBox.question(
                self,
                "Usuń cenniki",
                f"Usunąć {len(wybrane)} zaznaczonych cenników?\nProdukty w "
                f"katalogu i pliki źródłowe pozostaną. Przed usunięciem powstanie kopia bazy.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return

        def gotowe(w: object) -> None:
            self.raport.setText(f"Usunięto cenniki: {len(wybrane)}. Kopia: {w}")
            self.odswiez()

        self._zadanie(lambda: self.serwis.usun(wybrane), gotowe)
