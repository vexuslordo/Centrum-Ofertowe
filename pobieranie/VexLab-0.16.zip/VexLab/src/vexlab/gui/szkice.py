"""Osobny obszar lokalnych szkiców, bez publikacji i żądań sieciowych."""

from collections.abc import Callable
from typing import cast

from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.edytor_opisu import EdytorOpisu
from vexlab.gui.importowanie import DialogPotwierdzenia
from vexlab.gui.paczki_ofert import SzczegolyPaczki, etykieta
from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.szkice import SzkicDTO, SzkiceOfert


class StronaSzkicow(QWidget):
    def __init__(
        self,
        serwis: SzkiceOfert,
        uruchom: Uruchom,
        parent: QWidget,
        zdjecia: PodgladZdjec | None = None,
    ) -> None:
        super().__init__(parent)
        self.serwis, self.uruchom = serwis, uruchom
        self.zdjecia = zdjecia
        self.dane: tuple[SzkicDTO, ...] = ()
        self.widoczne: tuple[SzkicDTO, ...] = ()
        self.trwa = False
        self.dialog: QDialog | None = None
        self.setObjectName("strona")
        layout = QVBoxLayout(self)
        tytul = etykieta("Szkice ofert")
        tytul.setObjectName("marka")
        layout.addWidget(tytul)
        layout.addWidget(
            etykieta(
                "Zapisane lokalnie. Wysyłka do szkiców Allegro będzie dostępna "
                "po wdrożeniu integracji API. Sprzedaż nie jest uruchamiana."
            )
        )
        akcje = QHBoxLayout()
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj po SKU lub tytule…")
        self.szukaj.setAccessibleName("Wyszukiwanie lokalnych szkiców")
        self.szukaj.textChanged.connect(self.filtruj)
        akcje.addWidget(self.szukaj, 1)
        for tekst, funkcja in (
            ("Odśwież", self.odswiez),
            ("Podgląd", self.podglad),
            ("Edytuj tytuł i opis…", self.edytuj),
        ):
            b = QPushButton(tekst)
            b.clicked.connect(funkcja)
            akcje.addWidget(b)
        layout.addLayout(akcje)
        self.tabela = QTableWidget(0, 4)
        self.tabela.setHorizontalHeaderLabels(["SKU", "Tytuł", "Stan", "Źródło / aktualność"])
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setColumnWidth(0, 170)
        self.tabela.setColumnWidth(1, 480)
        self.tabela.setColumnWidth(2, 150)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setAccessibleName("Zapisane szkice ofert")
        self.tabela.activated.connect(self.podglad)
        layout.addWidget(self.tabela, 1)
        wybor = QHBoxLayout()
        self.zaznacz_wszystkie = QPushButton("Zaznacz wszystkie wyniki")
        self.zaznacz_wszystkie.clicked.connect(self.tabela.selectAll)
        self.odznacz = QPushButton("Odznacz")
        self.odznacz.clicked.connect(self.tabela.clearSelection)
        self.usun_zaznaczone = QPushButton("Usuń zaznaczone szkice…")
        self.usun_zaznaczone.clicked.connect(lambda: self.usun(False))
        self.usun_wyniki = QPushButton("Usuń wszystkie wyniki…")
        self.usun_wyniki.clicked.connect(lambda: self.usun(True))
        for przycisk in (
            self.zaznacz_wszystkie,
            self.odznacz,
            self.usun_zaznaczone,
            self.usun_wyniki,
        ):
            wybor.addWidget(przycisk)
        layout.addLayout(wybor)
        self.info_wybor = etykieta(
            "Zaznaczono: 0. Ctrl/Shift — wiele szkiców; Ctrl+A — wszystkie wyniki."
        )
        self.tabela.itemSelectionChanged.connect(self._licznik)
        layout.addWidget(self.info_wybor)
        self.raport = etykieta("")
        layout.addWidget(self.raport)
        self.info = etykieta("Brak zapisanych szkiców. Wczytaj paczkę ZIP w Nowe oferty.")
        layout.addWidget(self.info)

    def _zadanie(self, funkcja: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self.trwa:
            return
        self.trwa = True
        self.setEnabled(False)

        def gotowe(wynik: object) -> None:
            self.trwa = False
            self.setEnabled(True)
            sukces(wynik)

        def blad(kod: str, tekst: str) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.info.setText(tekst)

        self.uruchom(funkcja, gotowe, blad)

    def odswiez(self) -> None:
        self._zadanie(self.serwis.lista, self._wczytano)

    def _wczytano(self, wynik: object) -> None:
        self.dane = cast(tuple[SzkicDTO, ...], wynik)
        self.filtruj()

    def filtruj(self) -> None:
        self.tabela.clearSelection()
        self.tabela.setCurrentCell(-1, -1)
        tekst = self.szukaj.text().strip().casefold()
        self.widoczne = tuple(
            d for d in self.dane if tekst in (d.oferta.sku + " " + d.oferta.tytul).casefold()
        )
        self.tabela.setRowCount(len(self.widoczne))
        for i, d in enumerate(self.widoczne):
            for j, t in enumerate(
                (
                    d.oferta.sku,
                    d.oferta.tytul,
                    "Szkic lokalny",
                    d.zrodlo + (" • Produkt zmieniony" if d.zrodlo_zmienione else ""),
                )
            ):
                self.tabela.setItem(i, j, QTableWidgetItem(t))
        self.info.setText(
            f"Szkice: {len(self.widoczne)} z {len(self.dane)}. Nie zostały wysłane do Allegro."
        )

    def _licznik(self) -> None:
        liczba = len(self.tabela.selectionModel().selectedRows(0))
        self.info_wybor.setText(
            f"Zaznaczono: {liczba}. Ctrl/Shift — wiele szkiców; Ctrl+A — wszystkie wyniki."
        )

    def _wybrany(self) -> SzkicDTO | None:
        wybrane = self.tabela.selectionModel().selectedRows(0)
        if len(wybrane) != 1 or not 0 <= wybrane[0].row() < len(self.widoczne):
            self.info.setText("Do podglądu lub edycji zaznacz dokładnie jeden szkic.")
            return None
        return self.widoczne[wybrane[0].row()]

    def podglad(self) -> None:
        d = self._wybrany()
        if d is not None:
            self.dialog = SzczegolyPaczki(d.oferta, self)
            self.dialog.setWindowTitle("Szkic lokalny — podgląd zapisanej treści")
            self.dialog.setModal(True)
            self.dialog.open()

    def edytuj(self) -> None:
        d = self._wybrany()
        if d is None:
            return
        dialog = DialogPotwierdzenia(self)
        self.dialog = dialog
        dialog.setWindowTitle("Edycja lokalnego szkicu")
        dialog.resize(1120, 780)
        layout = QVBoxLayout(dialog)
        layout.addWidget(
            etykieta(
                "Edytujesz tylko ten szkic. Przeciągaj sekcje i zdjęcia, zmieniaj tekst "
                "z formatowaniem. Produkt w katalogu pozostaje bez zmian."
            )
        )
        formularz = QFormLayout()
        tytul = QLineEdit(d.oferta.tytul)
        opis = EdytorOpisu(d.oferta, dialog, self.zdjecia, self.uruchom)
        tytul.textChanged.connect(lambda value: setattr(opis, "tytul", value))
        dialog.finished.connect(lambda: opis.obrazy.zamknij())
        tytul.setObjectName("tytul_szkicu")
        opis.setObjectName("opis_szkicu")
        formularz.addRow("Tytuł *", tytul)
        layout.addLayout(formularz)
        layout.addWidget(opis, 1)
        blad_opisu = etykieta("")
        layout.addWidget(blad_opisu)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Zapisz")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        def zapisz() -> None:
            t, o = tytul.text(), opis.opis()
            sekcje = opis.wynik_sekcji()
            if not t.strip():
                blad_opisu.setText("Tytuł szkicu jest wymagany.")
                tytul.setFocus()
                return
            dialog.trwa = True
            buttons.setEnabled(False)
            dialog.setEnabled(False)

            def sukces(wynik: object) -> None:
                dialog.trwa = False
                dialog.setEnabled(True)
                dialog.accept()
                self.odswiez()

            def blad(kod: str, tekst: str) -> None:
                dialog.trwa = False
                buttons.setEnabled(True)
                dialog.setEnabled(True)
                blad_opisu.setText(tekst)

            self.uruchom(lambda: self.serwis.edytuj(d, t, o, sekcje), sukces, blad)

        buttons.accepted.connect(zapisz)
        dialog.setModal(True)
        dialog.open()

    def usun(self, wszystkie: bool = False) -> None:
        if self.trwa:
            return
        indeksy = {i.row() for i in self.tabela.selectionModel().selectedRows(0)}
        szkice = tuple(s for i, s in enumerate(self.widoczne) if wszystkie or i in indeksy)
        if not szkice:
            self.info.setText("Brak szkiców do usunięcia. Zaznacz szkice lub zmień filtr.")
            return
        zakres = "z bieżących wyników wyszukiwania" if wszystkie else "z zaznaczenia"
        if (
            QMessageBox.question(
                self,
                "Usuń lokalne szkice",
                f"Usunąć {len(szkice)} lokalnych szkiców {zakres}?\n"
                "Produkty pozostaną w katalogu. Przed usunięciem powstanie kopia bazy.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        self._zadanie(lambda: self.serwis.usun_wiele(szkice), self._usunieto)

    def _usunieto(self, wynik: object) -> None:
        self.raport.setText(f"Usunięto wskazane lokalne szkice. Kopia bazy: {wynik}")
        self.odswiez()
