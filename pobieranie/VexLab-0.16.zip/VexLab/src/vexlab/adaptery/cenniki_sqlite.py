"""Trwałe dokumenty cenników i atomowe dodawanie wybranych pozycji."""

import json
from dataclasses import asdict, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.przypadki_uzycia.cenniki import CennikDTO, WynikCennika
from vexlab.przypadki_uzycia.importowanie import CenaImportu, OcenaPozycji, PozycjaImportu, blad
from vexlab.przypadki_uzycia.katalog import DaneDopasowania, DaneProduktu
from vexlab.rdzen.kontrakty import BladTechniczny


def _tekst(d: dict[str, Any], klucz: str) -> str:
    value = d[klucz]
    if not isinstance(value, str):
        raise ValueError(klucz)
    return value


def _pozycja(d: Any) -> PozycjaImportu:
    if not isinstance(d, dict) or not isinstance(d.get("dane"), dict):
        raise ValueError("Pozycja")
    dane = d["dane"]
    ds = dane.get("dopasowania")
    if ds is not None and (not isinstance(ds, list) or len(ds) > 1000):
        raise ValueError("Dopasowania")
    dopasowania = tuple(
        DaneDopasowania(*(_tekst(x, k) for k in ("marka", "model", "rok_od", "rok_do", "wariant")))
        for x in ds or ()
    )
    cena = d.get("cena")
    if cena is not None and not isinstance(cena, dict):
        raise ValueError("Cena")
    if type(d.get("wiersz")) is not int or type(d.get("wersja")) is not int:
        raise ValueError("Numer wiersza")
    return PozycjaImportu(
        UUID(_tekst(d, "id")),
        UUID(_tekst(d, "paczka")),
        _tekst(d, "zrodlo"),
        _tekst(d, "arkusz"),
        d["wiersz"],
        DaneProduktu(
            _tekst(dane, "nazwa"),
            _tekst(dane, "sku"),
            _tekst(dane, "opis"),
            UUID(dane["producent_id"]) if dane.get("producent_id") else None,
            dopasowania if ds is not None else None,
        ),
        _tekst(d, "powod"),
        d["wersja"],
        CenaImportu(*(_tekst(cena, k) for k in ("tekst", "waluta", "rodzaj"))) if cena else None,
    )


class CennikiSQLite(ImportSQLite):
    def zapisz_cennik(
        self, nazwa: str, rok: int, wydanie: str, pozycje: tuple[PozycjaImportu, ...]
    ) -> UUID:
        if not nazwa.strip() or not 1000 <= rok <= 9999 or not 0 < len(pozycje) <= 20_000:
            raise blad("Nieprawidłowe dane cennika.")
        if len({p.dane.producent_id for p in pozycje}) != 1:
            raise blad("Cennik może wskazywać jednego producenta.")
        dane = json.dumps([asdict(p) for p in pozycje], ensure_ascii=False, default=str)
        if len(dane.encode()) > 64 * 1024 * 1024:
            raise blad("Cennik przekracza limit 64 MiB danych.")
        id = uuid4()
        pid = pozycje[0].dane.producent_id
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            self._kopia_spojna("kopie_cennikow")
            conn.execute(
                "INSERT INTO cenniki VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (
                    str(id),
                    nazwa.strip(),
                    rok,
                    wydanie.strip(),
                    str(pid) if pid else None,
                    pozycje[0].zrodlo,
                    pozycje[0].arkusz,
                    len(pozycje),
                    datetime.now(UTC).isoformat(),
                    dane,
                    1,
                ),
            )
        return id

    def lista(self) -> tuple[CennikDTO, ...]:
        with self._polaczenie() as conn:
            rows = conn.execute(
                "SELECT c.id,c.nazwa,c.rok,c.wydanie,coalesce(p.nazwa,''),c.zrodlo,c.arkusz,"
                "c.liczba,c.wczytano_utc,c.wersja FROM cenniki c LEFT JOIN producenci p "
                "ON p.id=c.producent_id ORDER BY c.wczytano_utc DESC,c.id"
            ).fetchall()
        return tuple(CennikDTO(UUID(r[0]), *r[1:]) for r in rows)

    @staticmethod
    def _sprawdz_cennik(conn: Any, id: UUID, wersja: int) -> Any:
        row = conn.execute(
            "SELECT dane_json,liczba,wersja FROM cenniki WHERE id=?", (str(id),)
        ).fetchone()
        if row is None or row[2] != wersja:
            raise blad("Cennik został usunięty lub zmieniony. Odśwież listę.")
        return row

    def pozycje(self, id: UUID, wersja: int) -> tuple[PozycjaImportu, ...]:
        with self._polaczenie() as conn:
            row = self._sprawdz_cennik(conn, id, wersja)
        try:
            if len(row[0]) > 64 * 1024 * 1024:
                raise ValueError("Rozmiar")
            dane = json.loads(row[0])
            if not isinstance(dane, list) or not 0 < len(dane) <= 20_000 or len(dane) != row[1]:
                raise ValueError("Liczba pozycji")
            return tuple(_pozycja(d) for d in dane)
        except (ValueError, KeyError, TypeError, AttributeError, RecursionError) as exc:
            raise BladTechniczny("Nie można odczytać cennika. Zachowaj kopię bazy.") from exc

    def dodaj_pozycje(
        self, cennik: CennikDTO, oceny: tuple[OcenaPozycji, ...], pominiete: int
    ) -> WynikCennika:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            self._sprawdz_cennik(conn, cennik.id, cennik.wersja)
            if not oceny:
                return WynikCennika(0, 0, pominiete, None)
            kopia = self._kopia_spojna("kopie_cennikow")
            pozycje = tuple(replace(o.pozycja, powod=o.problem or "") for o in oceny)
            wynik = self._zapisz_paczke(
                conn, pozycje, frozenset(o.pozycja.id for o in oceny if not o.problem)
            )
            return WynikCennika(wynik.dodane, wynik.odlozone, pominiete, kopia)

    def usun(self, cenniki: tuple[tuple[UUID, int], ...]) -> Path:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            for id, wersja in cenniki:
                self._sprawdz_cennik(conn, id, wersja)
            kopia = self._kopia_spojna("kopie_cennikow")
            conn.executemany("DELETE FROM cenniki WHERE id=?", [(str(id),) for id, _ in cenniki])
        return kopia
