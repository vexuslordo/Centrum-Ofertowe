"""Odczyt zamówień konta. Bez lokalnej kopii danych klientów i operacji zapisu."""

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Protocol

from vexlab.przypadki_uzycia.allegro import BladAllegro, CzasMonotoniczny, SesjaAllegro
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec


@dataclass(frozen=True)
class PozycjaZamowienia:
    nazwa: str
    sku: str
    ilosc: int
    cena: str
    oferta_id: str = ""


@dataclass(frozen=True)
class ZamowienieAllegro:
    id: str
    kupujacy: str
    status: str
    realizacja: str
    kwota: str
    platnosc: str
    zaplacono: str
    dostawa: str
    adres: str
    pozycje: tuple[PozycjaZamowienia, ...]
    kiedy: str
    kupiono: str = ""
    klient: str = ""
    email: str = ""
    telefon: str = ""
    kraj: str = ""


@dataclass(frozen=True)
class StronaZamowien:
    pozycje: tuple[ZamowienieAllegro, ...]
    razem: int


@dataclass(frozen=True)
class RaportZamowien:
    konto: str
    login: str
    srodowisko: str
    od: str
    do: str
    odczytano: str
    pozycje: tuple[ZamowienieAllegro, ...]


class APIZamowien(Protocol):
    def strona_zamowien(self, s: SesjaAllegro, od: str, do: str, offset: int) -> StronaZamowien: ...
    def zdjecie_oferty(self, s: SesjaAllegro, ident: str) -> str: ...
    def szczegoly_zamowienia(self, s: SesjaAllegro, ident: str) -> ZamowienieAllegro: ...


class ZapisZamowien(Protocol):
    def zapisz(
        self, cel: Path, raport: RaportZamowien, rows: tuple[ZamowienieAllegro, ...]
    ) -> int: ...


class OdczytajZamowieniaAllegro:
    def __init__(
        self,
        api: APIZamowien,
        czas: CzasMonotoniczny,
        obrazy: PodgladZdjec | None = None,
        zapis: ZapisZamowien | None = None,
    ) -> None:
        self.api, self.czas, self.obrazy = api, czas, obrazy
        self.zapis = zapis

    def _sesja(self, s: SesjaAllegro) -> None:
        if self.czas.teraz() >= s.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto Allegro ponownie.")
        if s.aplikacja is None or not s.aplikacja.odczyt_zamowien:
            raise BladAllegro(
                "ZAMOWIENIA",
                "W Integracje → Allegro włącz Odczyt zamówień i połącz konto ponownie.",
            )

    def pobierz(
        self,
        s: SesjaAllegro,
        dni: int,
        stop: Callable[[], bool],
        postep: Callable[[int, int], None],
    ) -> RaportZamowien:
        self._sesja(s)
        if dni not in (7, 30, 90):
            raise BladAllegro("ZAKRES", "Wybierz 7, 30 lub 90 dni.")
        teraz = datetime.now(UTC)
        od, do = ((teraz - timedelta(days=dni)).isoformat(), teraz.isoformat())
        rows: list[ZamowienieAllegro] = []
        seen = set()
        total = None
        while True:
            self._sesja(s)
            if stop():
                raise BladAllegro("ANULOWANO", "Anulowano pobieranie zamówień.")
            page = self.api.strona_zamowien(s, od, do, len(rows))
            if total is None:
                total = page.razem
            if not 0 <= total <= 20000 or page.razem != total:
                raise BladAllegro(
                    "ODCZYT",
                    "Lista zamówień zmieniła się lub przekracza 20 000. "
                    "Wybierz krótszy zakres i pobierz ponownie.",
                )
            for row in page.pozycje:
                if row.id in seen:
                    raise BladAllegro(
                        "ODCZYT", "Powtórzone zamówienie podczas stronicowania. Pobierz ponownie."
                    )
                seen.add(row.id)
                rows.append(row)
            postep(len(rows), total)
            if len(rows) == total:
                break
            if not page.pozycje or len(rows) > total:
                raise BladAllegro("ODCZYT", "Niepełna lista zamówień. Pobierz ponownie.")
        if stop():
            raise BladAllegro("ANULOWANO", "Anulowano pobieranie zamówień.")
        return RaportZamowien(
            s.konto.id,
            s.konto.login,
            s.srodowisko.value,
            od,
            do,
            datetime.now(UTC).isoformat(timespec="seconds"),
            tuple(rows),
        )

    def szczegoly(self, s: SesjaAllegro, ident: str) -> ZamowienieAllegro:
        self._sesja(s)
        return self.api.szczegoly_zamowienia(s, ident)

    def miniatura(self, s: SesjaAllegro, ident: str) -> bytes:
        self._sesja(s)
        if self.obrazy is None:
            return b""
        url = self.api.zdjecie_oferty(s, ident)
        return self.obrazy.pobierz(url).miniatura if url else b""

    def zdjecie(self, s: SesjaAllegro, ident: str) -> bytes:
        self._sesja(s)
        if self.obrazy is None:
            return b""
        url = self.api.zdjecie_oferty(s, ident)
        return self.obrazy.pobierz(url).dane if url else b""

    def eksportuj(
        self,
        s: SesjaAllegro,
        raport: RaportZamowien,
        rows: tuple[ZamowienieAllegro, ...],
        cel: Path,
    ) -> int:
        self._sesja(s)
        if self.zapis is None:
            raise BladAllegro("EKSPORT", "Eksport nie jest dostępny.")
        if (
            (raport.konto, raport.srodowisko) != (s.konto.id, s.srodowisko.value)
            or not rows
            or any(r not in raport.pozycje for r in rows)
        ):
            raise BladAllegro("KONTO", "Eksport wymaga wyników aktualnego konta.")
        return self.zapis.zapisz(cel, raport, rows)


def stan_platnosci(r: ZamowienieAllegro) -> str:
    try:
        total, currency = r.kwota.rsplit(" ", 1)
        paid, paid_currency = r.zaplacono.rsplit(" ", 1)
        a, b = Decimal(total), Decimal(paid)
        if a.is_finite() and b.is_finite() and currency == paid_currency and a > 0:
            if b >= a:
                return "oplacone"
            if b > 0:
                return "czesciowo"
    except (ValueError, InvalidOperation):
        pass
    if r.platnosc == "CASH_ON_DELIVERY":
        return "pobranie"
    if r.status in {"BOUGHT", "FILLED_IN"}:
        return "oczekuje"
    return "brak"


def obrot_zamowien(raport: RaportZamowien | None) -> tuple[str, str]:
    if raport is None:
        return "—", "Pobierz zamówienia z ostatnich 30 dni."
    try:
        do = datetime.fromisoformat(raport.do)
        od = datetime.fromisoformat(raport.od)
        limit = do - timedelta(days=30)
        if od > limit:
            return "—", "Wybierz zakres 30 lub 90 dni, aby objąć pełne 30 dni."
        sumy: dict[str, Decimal] = {}
        for r in raport.pozycje:
            if r.status == "CANCELLED" or r.realizacja == "CANCELLED":
                continue
            if not r.kupiono:
                return "—", "Brak daty zakupu części zamówień."
            data = datetime.fromisoformat(r.kupiono.replace("Z", "+00:00"))
            if not limit <= data <= do:
                continue
            kwota, waluta = r.kwota.rsplit(" ", 1)
            value = Decimal(kwota)
            if not value.is_finite() or value < 0:
                raise ValueError("kwota")
            sumy[waluta] = sumy.get(waluta, Decimal(0)) + value
        opis = "Suma wartości zamówień bez anulowanych; przed potrąceniami i zwrotami."
        if not sumy:
            return "0", opis
        wartosci = [
            f"{v:,.2f}".replace(",", " ").replace(".", ",") + " " + k
            for k, v in sorted(sumy.items())
        ]
        return (wartosci[0] if len(wartosci) == 1 else "Wiele walut"), opis + "\n" + "\n".join(
            wartosci
        )
    except (ValueError, InvalidOperation, TypeError):
        return "—", "Niepełne dane do obliczenia sumy wartości zamówień."
