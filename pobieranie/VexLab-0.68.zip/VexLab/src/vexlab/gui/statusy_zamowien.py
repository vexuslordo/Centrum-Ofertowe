"""Polskie etykiety kodów Allegro i kolory prezentacji; bez zmiany statusów."""

from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication

from vexlab.przypadki_uzycia.opisy_zamowien import (
    PLATNOSC as PLATNOSC,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    REALIZACJA as REALIZACJA,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    TYP_PLATNOSCI as TYP_PLATNOSCI,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    ZAKUP as ZAKUP,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    etykieta as etykieta,
)
from vexlab.przypadki_uzycia.zamowienia_allegro import stan_platnosci as stan_platnosci


def kolor(kod: str) -> QColor:
    ciemny = QApplication.palette().color(QApplication.palette().ColorRole.Base).lightness() < 128
    paleta = {
        "oplacone": ("#62D6A8", "#137448"),
        "SENT": ("#62D6A8", "#137448"),
        "PICKED_UP": ("#62D6A8", "#137448"),
        "CANCELLED": ("#FF969E", "#B42339"),
        "RETURNED": ("#FF969E", "#B42339"),
        "czesciowo": ("#F4C375", "#935600"),
        "oczekuje": ("#F4C375", "#935600"),
        "PROCESSING": ("#82BBFF", "#1766A8"),
        "NEW": ("#82BBFF", "#1766A8"),
    }
    return QColor(paleta.get(kod, ("#B6C8DF", "#435E89"))[0 if ciemny else 1])
