"""Kolorowe odznaki realizacji zamówienia."""

from PySide6.QtCore import QModelIndex, QPersistentModelIndex, Qt
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QStyledItemDelegate, QStyleOptionViewItem


class OdznakaZamowienia(QStyledItemDelegate):
    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        row = index.data(Qt.ItemDataRole.UserRole)
        if row is None:
            super().paint(painter, option, index)
            return
        text = str(index.data() or "")
        tone = {
            "NEW": "#0C9E55",
            "READY_FOR_SHIPMENT": "#087EC1",
            "PROCESSING": "#087EC1",
            "SENT": "#7138CE",
            "CANCELLED": "#B6374B",
        }.get(row.realizacja, "#446079")
        painter.save()
        rect = option.rect.adjusted(5, 16, -5, -16)
        width = min(rect.width(), option.fontMetrics.horizontalAdvance(text) + 20)
        rect.setWidth(width)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(tone))
        painter.drawRoundedRect(rect, 11, 11)
        painter.setPen(QColor("#FFFFFF"))
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)
        painter.restore()
