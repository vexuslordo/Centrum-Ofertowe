"""Karty zamówień korzystające z tego samego modelu i zaznaczenia co tabela."""

from PySide6.QtCore import QModelIndex, QPersistentModelIndex, Qt
from PySide6.QtGui import QIcon, QPainter, QPalette
from PySide6.QtWidgets import QStyle, QStyledItemDelegate, QStyleOptionViewItem


class KartaZamowienia(QStyledItemDelegate):
    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        rect = option.rect.adjusted(5, 5, -5, -5)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        palette = option.palette
        painter.save()
        painter.setPen(palette.color(QPalette.ColorRole.Mid))
        painter.setBrush(
            palette.color(QPalette.ColorRole.Highlight if selected else QPalette.ColorRole.Base)
        )
        painter.drawRoundedRect(rect, 7, 7)
        icon = index.sibling(index.row(), 1).data(Qt.ItemDataRole.DecorationRole)
        if isinstance(icon, QIcon):
            icon.paint(painter, rect.adjusted(12, 12, -rect.width() + 66, -rect.height() + 66))
        painter.setPen(
            palette.color(
                QPalette.ColorRole.HighlightedText if selected else QPalette.ColorRole.Text
            )
        )
        name = str(index.data() or "")
        painter.drawText(rect.adjusted(76, 12, -12, -60), Qt.TextFlag.TextWordWrap, name)
        buyer = str(index.sibling(index.row(), 3).data() or "")
        amount = str(index.sibling(index.row(), 4).data() or "")
        status = str(index.sibling(index.row(), 6).data() or "")
        painter.drawText(
            rect.adjusted(12, 80, -12, -12),
            Qt.TextFlag.TextWordWrap,
            f"{buyer}  •  {amount}\n{status}",
        )
        painter.restore()
