"""Panel szczegółów w stylu referencji: zdjęcie, dane klienta, zamówienia i pozycje."""

from html import escape

from PySide6.QtCore import QDateTime, QEvent, QObject, Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.statusy_zamowien import (
    PLATNOSC,
    REALIZACJA,
    TYP_PLATNOSCI,
    etykieta,
    stan_platnosci,
)
from vexlab.przypadki_uzycia.zamowienia_allegro import ZamowienieAllegro


class PanelZamowienia(QFrame):
    otworz = Signal()
    zamknij = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("panelZamowienia")
        self.setMinimumWidth(280)
        self.setMaximumWidth(420)
        self.box = QVBoxLayout(self)
        self.box.setContentsMargins(12, 12, 12, 12)
        top = QHBoxLayout()
        top.addWidget(QLabel("Szczegóły zamówienia"), 1)
        self.odswiez = QPushButton("↻")
        self.odswiez.setMaximumWidth(26)
        self.odswiez.setToolTip("Odśwież szczegóły zamówienia")
        top.addWidget(self.odswiez)
        close = QPushButton("×")
        close.setMaximumWidth(26)
        close.clicked.connect(self.zamknij.emit)
        top.addWidget(close)
        self.box.addLayout(top)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        self.obszar_przewijania, self.body = scroll, body
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.viewport().installEventFilter(self)
        inside = QVBoxLayout(body)
        inside.setContentsMargins(0, 0, 0, 0)
        self.status = QLabel("Wybierz zamówienie")
        self.status.setObjectName("statusZamowienia")
        inside.addWidget(self.status)
        self.numer = self.label()
        inside.addWidget(self.numer)
        self.foto = QLabel("Brak zdjęcia")
        self.foto.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.foto.setFixedHeight(170)
        self.foto.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        self.foto.setObjectName("fotoZamowienia")
        inside.addWidget(self.foto)
        self.male = QHBoxLayout()
        self.miniatury = []
        for _ in range(3):
            photo = QLabel("—")
            photo.setAlignment(Qt.AlignmentFlag.AlignCenter)
            photo.setFixedHeight(44)
            photo.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
            photo.setObjectName("malaFotografiaZamowienia")
            self.miniatury.append(photo)
            self.male.addWidget(photo)
        inside.addLayout(self.male)
        self.produkt = self.label()
        self.produkt.setStyleSheet("font-weight:600; font-size:14px")
        inside.addWidget(self.produkt)
        self.sku = self.label()
        inside.addWidget(self.sku)
        self.klient = self.sekcja(inside, "Informacje o kliencie")
        self.dane = self.sekcja(inside, "Informacje o zamówieniu")
        self.pozycje = self.sekcja(inside, "Produkty w zamówieniu")
        inside.addStretch()
        scroll.setWidget(body)
        self.box.addWidget(scroll, 1)
        actions = QGridLayout()
        self.nadaj = QPushButton("Nadaj przesyłkę")
        self.nadaj.setObjectName("primary")
        self.etykieta = QPushButton("Drukuj etykietę")
        self.napisz = QPushButton("Napisz klientowi ↗")
        self.otworz_button = QPushButton("Otwórz w Allegro ↗")
        for i, b in enumerate((self.nadaj, self.etykieta, self.napisz, self.otworz_button)):
            actions.addWidget(b, i // 2, i % 2)
        for b in (self.nadaj, self.etykieta):
            b.setEnabled(False)
            b.setToolTip(
                "Nadawanie przesyłek i pobieranie etykiet wymaga kolejnego etapu integracji."
            )
        self.napisz.setToolTip("Otwiera zamówienie w Allegro, gdzie możesz napisać do kupującego.")
        self.napisz.clicked.connect(self.otworz.emit)
        self.otworz_button.clicked.connect(self.otworz.emit)
        self.box.addLayout(actions)
        self.wyczysc()

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if obj is self.obszar_przewijania.viewport() and event.type() == QEvent.Type.Resize:
            self.body.setFixedWidth(max(1, self.obszar_przewijania.viewport().width()))
        return super().eventFilter(obj, event)

    @staticmethod
    def label() -> QLabel:
        label = QLabel()
        label.setWordWrap(True)
        label.setTextFormat(Qt.TextFormat.PlainText)
        label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        return label

    def sekcja(self, box: QVBoxLayout, title: str) -> QLabel:
        heading = QLabel(title)
        heading.setStyleSheet("font-weight:600; margin-top:10px")
        box.addWidget(heading)
        label = self.label()
        box.addWidget(label)
        return label

    def wyczysc(self) -> None:
        self.status.setText("Wybierz zamówienie")
        self.status.setStyleSheet("")
        self.status.setFixedWidth(180)
        for label in (self.numer, self.produkt, self.sku, self.klient, self.dane, self.pozycje):
            label.clear()
        self.foto.clear()
        self.foto.setText("Brak zdjęcia")
        for photo in self.miniatury:
            photo.clear()
            photo.setText("—")
        self.napisz.setEnabled(False)
        self.otworz_button.setEnabled(False)

    def ustaw(self, r: ZamowienieAllegro) -> None:
        self.wyczysc()
        self.status.setText(etykieta(r.realizacja, REALIZACJA))
        tone = {
            "NEW": "#0C9E55",
            "READY_FOR_SHIPMENT": "#087EC1",
            "SENT": "#7138CE",
            "CANCELLED": "#B6374B",
        }.get(r.realizacja, "#446079")
        self.status.setStyleSheet(
            f"color:white; background:{tone}; border-radius:9px; padding:3px 8px"
        )
        self.status.setFixedWidth(
            min(180, self.status.fontMetrics().horizontalAdvance(self.status.text()) + 24)
        )
        self.numer.setText("ID: " + r.id)
        self.produkt.setText(r.pozycje[0].nazwa if r.pozycje else "Brak pozycji")
        self.sku.setText("SKU: " + (r.pozycje[0].sku or "—") if r.pozycje else "")
        self.klient.setText(
            f"Kupujący: {r.kupujacy}\n"
            f"Imię i nazwisko: {r.klient or '—'}\n"
            f"E-mail: {r.email or '—'}\n"
            f"Telefon: {r.telefon or '—'}\n"
            f"Kraj: {r.kraj or '—'}"
        )
        date = (
            QDateTime.fromString(r.kupiono, Qt.DateFormat.ISODate)
            .toLocalTime()
            .toString("dd.MM.yyyy HH:mm")
        )
        self.dane.setTextFormat(Qt.TextFormat.PlainText)
        self.dane.setText(
            f"Kwota: {r.kwota}\n"
            f"Płatność: {PLATNOSC[stan_platnosci(r)]}\n"
            f"Sposób zapłaty: {etykieta(r.platnosc, TYP_PLATNOSCI)}\n"
            f"Dostawa: {r.dostawa or '—'}\n"
            f"{r.adres}\n"
            f"Data zakupu: {date or 'Brak daty'}"
        )
        plain = self.dane.text()
        payment_label = PLATNOSC[stan_platnosci(r)]
        tone = "#21BD80" if stan_platnosci(r) == "oplacone" else "#D9AF57"
        html = escape(plain).replace("\n", "<br>")
        html = html.replace(
            "Płatność: " + escape(payment_label),
            "Płatność: <span style='color:" + tone + "'>◆ " + escape(payment_label) + "</span>",
        )
        self.dane.setTextFormat(Qt.TextFormat.RichText)
        self.dane.setText(html)
        self.pozycje.setText(
            "\n\n".join(f"{p.nazwa} ×{p.ilosc}\nSKU: {p.sku or '—'}" for p in r.pozycje)
        )
        self.napisz.setEnabled(True)
        self.otworz_button.setEnabled(True)

    def zdjecie(self, data: bytes) -> None:
        pix = QPixmap()
        if data and pix.loadFromData(data):
            self.foto.setPixmap(
                pix.scaled(
                    max(100, min(350, self.foto.width())),
                    170,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
            self.miniatury[0].setPixmap(
                pix.scaled(
                    100,
                    44,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
        else:
            self.foto.setText("Brak dostępnego zdjęcia")
