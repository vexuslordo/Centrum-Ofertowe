# VexLab 0.68 — Zamówienia według referencji właściciela

Allegro → Zamówienia: nagłówek konta, cztery gradientowe kafelki z ikonami,
szybkie zakładki, wyszukiwarka, filtry, tabela z miniaturami lub karty,
stronicowanie i pełnej wysokości panel szczegółów po prawej. Polskie etykiety,
kolorowe odznaki realizacji i wyróżnienie płatności. Kafelki Nowe / Do wysyłki /
Wysłane liczą rzeczywiste statusy NEW / READY_FOR_SHIPMENT / SENT w pobranym
zakresie. Anulowane jest osobną zakładką. Żadne przykładowe liczniki lub dane
ze screena nie są danymi startowymi aplikacji.

Filtry realizacji, płatności, statusu zakupu, dostawy i tekstu działają łącznie.
Kliknięcie nagłówka checkboxów zaznacza wszystkie wyniki filtra, także poza
stroną. Eksportuj zapisuje zaznaczone wyniki lub wszystkie filtrowane do nowego
pliku CSV wskazanego przez użytkownika, bez nadpisywania plików. Nie eksportuje
adresów, e-maili ani telefonów; chroni pola przed interpretacją jako formuły.

Panel pokazuje dane otrzymane z Allegro: klienta, płatność, dostawę, pozycje,
zdjęcie pierwszej oferty oraz datę zakupu. Aktualizacja zamówienia i data zakupu
są rozdzielone. Braki danych są widoczne. Miniatury ładowane w tle dla widocznych
pozycji, cache 128 ikon w RAM. Zdjęcie jest aktualnym zdjęciem oferty, nie
historycznym dowodem zakupu. Dodatkowych zdjęć nie wymyślamy.

Opłacone wymaga wpłaty pokrywającej wartość w tej samej walucie; gotowość do
obsługi nie dowodzi wpłaty. Obrót (30 dni) to suma wartości zamówień przed
opłatami i zwrotami, bez anulowanych. Wymaga pełnego zakresu i dat zakupów.
Różne waluty są rozdzielone, bez niejawnego przeliczania.

Napisz klientowi i Otwórz w Allegro otwierają zamówienie w przeglądarce.
Nadanie i druk etykiet pozostają nieaktywne do wdrożenia API przesyłek.
Odczyt i widok nie zmieniają zamówień Allegro. Dane kontaktowe i zdjęcia są
w pamięci, czyszczone po zmianie konta. Brak migracji i nowych seedów.
Paczka pozostaje lekka, bez screenów, z obrazem referencyjnym i logo.
