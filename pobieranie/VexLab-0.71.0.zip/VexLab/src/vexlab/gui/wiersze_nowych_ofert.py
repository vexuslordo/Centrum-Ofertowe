"""Dwuliniowy produkt i badge. Oryginalne wartości komórek pozostają bez zmian."""

from PySide6.QtCore import QModelIndex, QPersistentModelIndex, QRect, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter
from PySide6.QtWidgets import QApplication, QStyle, QStyledItemDelegate, QStyleOptionViewItem

from vexlab.gui.panel_walidacji_oferty import KODY_TONOW
from vexlab.gui.statusy_zamowien import kolory_odznaki


class WierszNowejOferty(QStyledItemDelegate):
    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        if index.column() not in (2, 9):
            super().paint(painter, option, index)
            return
        base = QStyleOptionViewItem(option)
        self.initStyleOption(base, index)
        base.text = ""
        style = option.widget.style() if option.widget else QApplication.style()
        if style:
            style.drawControl(QStyle.ControlElement.CE_ItemViewItem, base, painter, option.widget)
        painter.save()
        painter.setClipRect(option.rect)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = option.rect.adjusted(10, 0, -10, 0)
        font = QFont(option.font)
        if index.column() == 2:
            font.setWeight(QFont.Weight.DemiBold)
            painter.setFont(font)
            painter.setPen(option.palette.color(option.palette.ColorRole.Text))
            title = QFontMetrics(font).elidedText(
                str(index.data() or ""), Qt.TextElideMode.ElideRight, rect.width()
            )
            painter.drawText(
                QRect(rect.left(), rect.center().y() - 23, rect.width(), 22),
                Qt.AlignmentFlag.AlignVCenter,
                title,
            )
            font.setPixelSize(11)
            font.setWeight(QFont.Weight.Normal)
            painter.setFont(font)
            painter.setPen(option.palette.color(option.palette.ColorRole.PlaceholderText))
            sku = "SKU: " + str(index.sibling(index.row(), 1).data() or "—")
            sku = QFontMetrics(font).elidedText(sku, Qt.TextElideMode.ElideRight, rect.width())
            painter.drawText(
                QRect(rect.left(), rect.center().y() + 2, rect.width(), 20),
                Qt.AlignmentFlag.AlignVCenter,
                sku,
            )
        else:
            tone = str(index.data(Qt.ItemDataRole.UserRole) or "szary")
            dark = option.palette.color(option.palette.ColorRole.Window).lightness() < 128
            bg, fg, border = kolory_odznaki(KODY_TONOW.get(tone, ""), dark)
            font.setPixelSize(11)
            font.setWeight(QFont.Weight.DemiBold)
            painter.setFont(font)
            text = QFontMetrics(font).elidedText(
                str(index.data() or ""), Qt.TextElideMode.ElideRight, rect.width() - 16
            )
            width = min(rect.width(), QFontMetrics(font).horizontalAdvance(text) + 16)
            badge = QRect(rect.left(), rect.center().y() - 14, width, 28)
            painter.setBrush(QColor(bg))
            painter.setPen(QColor(border))
            painter.drawRoundedRect(badge, 7, 7)
            painter.setPen(QColor(fg))
            painter.drawText(badge, Qt.AlignmentFlag.AlignCenter, text)
        painter.restore()
