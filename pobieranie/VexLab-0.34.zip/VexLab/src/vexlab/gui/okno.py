"""Powłoka VexLab i lokalny katalog; niewdrożone moduły są oznaczone jawnie."""

from collections import Counter
from collections.abc import Callable
from pathlib import Path
from typing import cast
from uuid import UUID

from PySide6.QtCore import (
    QItemSelectionModel,
    QModelIndex,
    QPersistentModelIndex,
    QPoint,
    QSize,
    QSortFilterProxyModel,
    QStandardPaths,
    Qt,
    QThreadPool,
    QTimer,
    Signal,
)
from PySide6.QtGui import QAction, QCloseEvent, QKeySequence, QResizeEvent, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QStackedWidget,
    QTableView,
    QTabWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.allegro import StronaAllegro
from vexlab.gui.cenniki import StronaCennikow
from vexlab.gui.design_system import ikona, ikona_menu, logo_aplikacji, zastosuj_motyw
from vexlab.gui.filtry_katalogu import FiltryKatalogu
from vexlab.gui.galeria import GaleriaProduktu
from vexlab.gui.importowanie import StronaImportu
from vexlab.gui.integracje_dashboard import PanelIntegracji, PasekIntegracji
from vexlab.gui.kafelek_kpi import KafelekKPI
from vexlab.gui.katalog import (
    FormularzProduktu,
    ModelProduktow,
    SzczegolyProduktu,
    nazwa_wyboru_producenta,
)
from vexlab.gui.masowa import FormularzMasowy
from vexlab.gui.miniatury_katalogu import MiniaturyKatalogu
from vexlab.gui.paczki_ofert import StronaPaczek
from vexlab.gui.producenci import StronaProducentow
from vexlab.gui.przyciski import IKONY_PRZYCISKOW, KARTY_AKCJI, KartaAkcji, PrzyciskAkcji
from vexlab.gui.sekcja_menu import SekcjaMenu
from vexlab.gui.srodowisko_gt import PanelSrodowiskaGT
from vexlab.gui.strony_katalogu import PasekStron, TabelaKatalogu, WyborKatalogu
from vexlab.gui.szkice import StronaSzkicow
from vexlab.gui.szybkie_akcje import EdytorSzybkichAkcji
from vexlab.gui.ustawienia import InformacjeOProgramie, IntegracjeUstawien
from vexlab.gui.widoki_katalogu import (
    NaglowekWyboru,
    RysowanieKafelkow,
    RysowanieKatalogu,
    WidokiKatalogu,
)
from vexlab.gui.zadania import Zadanie
from vexlab.gui.zdjecia_seryjne import DialogZdjecSeryjnych
from vexlab.przypadki_uzycia.allegro import PolaczAllegro
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.diagnostyka import DiagnozujSrodowisko
from vexlab.przypadki_uzycia.eksport import EksportujKatalog, WynikEksportu
from vexlab.przypadki_uzycia.galeria import GaleriaDTO, GaleriaProduktow
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import (
    KatalogProduktow,
    ProduktDTO,
    StronaKatalogu,
    ZapytanieKatalogu,
)
from vexlab.przypadki_uzycia.media import KandydaciZdjec, PobierzZdjecia
from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import ProducentDTO, RejestrProducentow
from vexlab.przypadki_uzycia.profile_cennikow import ProfileCennikow
from vexlab.przypadki_uzycia.srodowisko_gt import SprawdzSrodowiskoGT
from vexlab.przypadki_uzycia.szkice import SzkiceOfert
from vexlab.przypadki_uzycia.szybkie_akcje import AKCJE, DOMYSLNE_AKCJE
from vexlab.przypadki_uzycia.zdjecia_seryjne import PobierzZdjeciaSeryjnie
from vexlab.rdzen.kontrakty import BladTechniczny

MENU = (
    ("", (("Dashboard", "dashboard"),)),
    (
        "PRODUKTY",
        (
            ("Produkty", "produkt"),
            ("Cenniki", "plik"),
            ("Producenci", "produkt"),
            ("Zdjęcia i media", "plik"),
            ("Kreator opisów (AI)", "ustawienia"),
        ),
    ),
    (
        "OFERTY",
        (
            ("Nowe oferty", "oferta"),
            ("Szkice", "plik"),
            ("Aktywne oferty", "oferta"),
            ("Masowa edycja", "plik"),
            ("Zmiana cen", "wykres"),
            ("Szablony układów", "plik"),
        ),
    ),
    (
        "SPRZEDAŻ",
        (
            ("Allegro", "oferta"),
            ("PrestaShop", "oferta"),
            ("Synchronizacja", "synchronizacja"),
            ("Kolejka zadań", "plik"),
        ),
    ),
    (
        "ANALITYKA",
        (("Raporty", "wykres"), ("Historia operacji", "synchronizacja"), ("Statystyki", "wykres")),
    ),
    ("NARZĘDZIA", (("Ustawienia", "ustawienia"), ("Pomoc i poradnik", "blad"))),
)


def etykieta(tekst: str, styl: str = "", zawijaj: bool = False) -> QLabel:
    label = QLabel(tekst)
    label.setObjectName(styl)
    label.setWordWrap(zawijaj)
    return label


def przycisk(tekst: str, aktywny: bool = True) -> QPushButton:
    button = PrzyciskAkcji(tekst, IKONY_PRZYCISKOW.get(tekst, ""))
    button.setAccessibleName(tekst)
    button.setEnabled(aktywny)
    if not aktywny:
        button.setToolTip("Funkcja w przygotowaniu. Nie wykonuje operacji.")
    return button


def karta(tytul: str) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("karta")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(15, 14, 15, 14)
    layout.setSpacing(12)
    layout.addWidget(etykieta(tytul, "tytul"))
    return frame, layout


class FiltrProduktow(QSortFilterProxyModel):
    sortowanie = Signal()
    fraza = ""
    producent = "wszyscy"
    zdjecia: bool | None = None
    cena: bool | None = None

    def sort(self, column: int, order: Qt.SortOrder = Qt.SortOrder.AscendingOrder) -> None:
        if column >= 8:
            return
        zmiana = self.sortColumn() != column or self.sortOrder() != order
        super().sort(column, order)
        if zmiana:
            self.sortowanie.emit()

    def ustaw_fraze(self, fraza: str) -> None:
        self.beginFilterChange()
        self.fraza = fraza.strip().casefold()
        self.endFilterChange(QSortFilterProxyModel.Direction.Rows)

    def ustaw_producenta(self, producent: str) -> None:
        self.beginFilterChange()
        self.producent = producent
        self.endFilterChange(QSortFilterProxyModel.Direction.Rows)

    def filterAcceptsRow(
        self, source_row: int, source_parent: QModelIndex | QPersistentModelIndex
    ) -> bool:
        model = cast(ModelProduktow, self.sourceModel())
        produkt = model.produkty[source_row]
        nazwa_pasuje = (
            self.fraza in produkt.nazwa.casefold() or self.fraza in produkt.sku.casefold()
        )
        nazwa_pasuje = nazwa_pasuje or self.fraza in produkt.ean.casefold()
        nazwa_pasuje = nazwa_pasuje and (self.zdjecia is None or produkt.ma_zdjecia == self.zdjecia)
        nazwa_pasuje = nazwa_pasuje and (
            self.cena is None or (produkt.cena_sugerowana is not None) == self.cena
        )
        if self.producent == "brak":
            return nazwa_pasuje and produkt.producent_id is None
        return nazwa_pasuje and (
            self.producent == "wszyscy" or str(produkt.producent_id) == self.producent
        )


class OknoVexLab(QMainWindow):
    def __init__(
        self,
        powloka: PowlokaAplikacji,
        katalog: KatalogProduktow,
        producenci: RejestrProducentow,
        eksport: EksportujKatalog,
        importer: ImportujProdukty,
        media: PobierzZdjecia | None = None,
        galeria: GaleriaProduktow | None = None,
        paczki: PodgladPaczek | None = None,
        szkice: SzkiceOfert | None = None,
        cenniki: BibliotekaCennikow | None = None,
        podglad_zdjec: PodgladZdjec | None = None,
        zdjecia_seryjne: PobierzZdjeciaSeryjnie | None = None,
        profile_cennikow: ProfileCennikow | None = None,
        diagnostyka_gt: SprawdzSrodowiskoGT | None = None,
        allegro: PolaczAllegro | None = None,
        diagnostyka: DiagnozujSrodowisko | None = None,
        katalog_danych: Path | None = None,
    ) -> None:
        super().__init__()
        self.powloka = powloka
        self.katalog = katalog
        self.odczyt_katalogu = katalog.odczyt
        self.diagnostyka_gt = diagnostyka_gt
        self.allegro = allegro
        self.diagnostyka = diagnostyka
        self.katalog_danych = katalog_danych
        self.producenci = producenci
        self.eksport = eksport
        self.profile_cennikow = profile_cennikow
        self.importer = importer
        self.media = media
        self.galeria = galeria
        self.paczki = paczki
        self.szkice = szkice
        self.cenniki = cenniki
        self.podglad_zdjec = podglad_zdjec
        self.zdjecia_seryjne = zdjecia_seryjne
        self.dialog_zdjec: DialogZdjecSeryjnych | None = None
        self._otwieranie_zdjec = False
        self.strona_cennikow: StronaCennikow | None = None
        self._ladowanie_galerii = False
        self._filtry_producenta: list[QComboBox] = []
        self._paski_katalogu: list[FiltryKatalogu] = []
        self._widoki_katalogu: list[WidokiKatalogu] = []
        self._producenci_katalogu: tuple[ProducentDTO, ...] = ()
        self.menu_wiersza: QMenu | None = None
        self._tabele: list[QTableView] = []
        self._paski_stron: list[PasekStron] = []
        self._strona = 0
        self._rozmiar_strony = 100
        self._liczba_wynikow = 0
        self._liczba_wszystkich = 0
        self._katalog_trwa = False
        self._wybor_trwa = False
        self._skroty_tabel: list[QShortcut] = []
        self.szczegoly: SzczegolyProduktu | None = None
        self._ladowanie_formularza = False
        self._usuwanie = False
        self.masowy: FormularzMasowy | None = None
        self._ladowanie_masowej = False
        self.setWindowTitle(f"VexLab {powloka.wersja}")
        self.setWindowIcon(logo_aplikacji())
        self.resize(1536, 1024)
        self.setMinimumSize(800, 620)
        self.pula = QThreadPool(self)
        self.pula.setMaxThreadCount(2)
        self._zadania: list[Zadanie] = []
        self._numer_odczytu = 0
        self._katalog_wczytany = False
        self._blad_katalogu: str | None = None
        self._kolumny = 0
        self.formularz: FormularzProduktu | None = None
        self.tabela_produktow: QTableView
        self.model = ModelProduktow(self)
        self.filtr = FiltrProduktow(self)
        self.filtr.setSourceModel(self.model)
        self.filtr.setSortCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.wybor = WyborKatalogu(self.model, self._produkt_z_indeksu)
        self.przyciski_menu: dict[str, QToolButton] = {}
        self.sekcje_menu: dict[str, SekcjaMenu] = {}
        self.rozwiniete_grupy = set(self.powloka.preferencje.rozwiniete_grupy)
        self.strony: dict[str, QWidget] = {}
        self._kpi: list[QFrame] = []
        self._panele: list[QWidget] = []
        self._zbuduj()
        self.filtr.sortowanie.connect(self._zmiana_zapytania)
        self.miniatury = MiniaturyKatalogu(
            self,
            self.model,
            self._tabele,
            self.katalog,
            self._uruchom,
            tuple(w.kafelki for w in self._widoki_katalogu),
        )
        self._motyw()
        app = cast(QApplication, QApplication.instance())
        app.styleHints().colorSchemeChanged.connect(self._motyw)
        self._ustaw_menu()
        self.przejdz("Dashboard")
        QTimer.singleShot(0, self.odswiez)

    def _zbuduj(self) -> None:
        central = QWidget()
        central.setObjectName("app")
        glowny = QVBoxLayout(central)
        glowny.setContentsMargins(0, 0, 0, 0)
        glowny.setSpacing(0)
        glowny.addWidget(self._naglowek())
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        self.menu = QFrame()
        self.menu.setObjectName("nawigacja")
        nawigacja = QVBoxLayout(self.menu)
        nawigacja.setContentsMargins(8, 10, 8, 8)
        obszar_menu = QScrollArea()
        obszar_menu.setWidgetResizable(True)
        obszar_menu.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        zawartosc = QWidget()
        lista = QVBoxLayout(zawartosc)
        lista.setContentsMargins(2, 0, 2, 0)
        lista.setSpacing(2)
        for grupa, pozycje in MENU:
            miejsce = lista
            if grupa:
                sekcja = SekcjaMenu(grupa)
                sekcja.belka.clicked.connect(
                    lambda checked, cel=grupa: self.zmien_grupe(cel, checked)
                )
                self.sekcje_menu[grupa] = sekcja
                lista.addWidget(sekcja)
                miejsce = sekcja.lista
            for nazwa, symbol in pozycje:
                button = QToolButton()
                button.setObjectName("nav")
                button.setText(nazwa)
                button.setIcon(ikona(symbol))
                button.setIconSize(QSize(20, 20))
                button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                button.setCheckable(True)
                button.setAccessibleName(nazwa)
                button.setToolTip(nazwa)
                button.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
                button.clicked.connect(lambda checked=False, cel=nazwa: self.przejdz(cel))
                miejsce.addWidget(button)
                self.przyciski_menu[nazwa] = button
        lista.addStretch()
        obszar_menu.setWidget(zawartosc)
        nawigacja.addWidget(obszar_menu)
        self.zwin = przycisk("Zwiń menu")
        self.zwin.setObjectName("zwinMenu")
        self.zwin.clicked.connect(self.zmien_menu)
        nawigacja.addWidget(self.zwin)
        body.addWidget(self.menu)
        self.stos = QStackedWidget()
        body.addWidget(self.stos, 1)
        glowny.addLayout(body, 1)
        self.setCentralWidget(central)
        self._dashboard()
        self._produkty()
        self._strona_masowej_edycji()
        if self.galeria is not None:
            self._media()
        self.strona_importu = StronaImportu(
            self.importer, self.producenci, self.katalog, self._uruchom, self, self.profile_cennikow
        )
        self.strona_importu.zmieniono.connect(self.odswiez)
        if self.cenniki is not None:
            self.strona_cennikow = StronaCennikow(self.cenniki, self.strona_importu, self._uruchom)
            self.strona_cennikow.zmieniono.connect(self.odswiez)
        self._dodaj_strone("Cenniki", self.strona_cennikow or self.strona_importu)
        if self.paczki is not None:
            self.strona_paczek = StronaPaczek(self.paczki, self._uruchom, self, self.szkice)
            self._dodaj_strone("Nowe oferty", self.strona_paczek)
        if self.szkice is not None:
            self.strona_szkicow = StronaSzkicow(
                self.szkice, self._uruchom, self, self.podglad_zdjec
            )
            self._dodaj_strone("Szkice", self.strona_szkicow)
            if self.paczki is not None:
                self.strona_paczek.zmieniono.connect(self.strona_szkicow.odswiez)
        if self.allegro is not None:
            self.strona_allegro = StronaAllegro(self.allegro, self._uruchom, self.podglad_zdjec)
            self.strona_allegro.stan.connect(self._stan_allegro)
            self.strona_allegro.nowa_oferta_zadana.connect(lambda: self.przejdz("Nowe oferty"))
            self.strona_allegro.ustawienia_zadane.connect(self._pokaz_ustawienia_allegro)
            obszar_allegro = QScrollArea()
            obszar_allegro.setWidgetResizable(True)
            obszar_allegro.setWidget(self.strona_allegro)
            self._dodaj_strone("Allegro", obszar_allegro)
        self._ustawienia()
        self.status = etykieta("Otwieranie lokalnego katalogu…", "opis")
        self.statusBar().addWidget(self.status, 1)
        self.statusBar().addPermanentWidget(
            etykieta("Synchronizacja: niewdrożona   •   Kolejka: niewdrożona", "opis")
        )
        self.strona_producentow = StronaProducentow(self.producenci, self._uruchom, self)
        self.strona_producentow.zmieniono.connect(self.odswiez)
        self.strona_producentow.status.connect(self.status.setText)
        self._dodaj_strone("Producenci", self.strona_producentow)
        self.skrot = QShortcut(QKeySequence("Ctrl+K"), self)
        self.skrot.activated.connect(self._szukaj_fokus)

    def _naglowek(self) -> QWidget:
        frame = QFrame()
        frame.setObjectName("naglowek")
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(20, 12, 20, 12)
        logo = etykieta("")
        logo.setPixmap(logo_aplikacji(kwadrat=False).pixmap(112, 48))
        logo.setFixedSize(112, 48)
        logo.setAccessibleName("Logo VEX")
        layout.addWidget(logo)
        marka = QVBoxLayout()
        marka.setSpacing(0)
        marka.addWidget(etykieta("VexLab", "marka"))
        marka.addWidget(etykieta("Sprzedawaj szybciej. Zarządzaj mądrzej.", "opis"))
        layout.addLayout(marka)
        layout.addSpacing(24)
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj produktów, SKU, EAN…    Ctrl+K")
        self.szukaj.setAccessibleName("Szukaj lokalnych produktów po nazwie, SKU lub EAN")
        self.szukaj.setClearButtonEnabled(True)
        self.szukaj.setMaximumWidth(520)
        self.szukaj.textChanged.connect(self._wyszukaj)
        layout.addWidget(self.szukaj, 1)
        layout.addStretch()
        self.pasek_integracji = PasekIntegracji(self.allegro is not None)
        self.stan_integracji = self.pasek_integracji.status
        self.pasek_integracji.allegro.connect(lambda: self.przejdz("Allegro"))
        self.pasek_integracji.presta.connect(lambda: self.przejdz("PrestaShop"))
        layout.addWidget(self.pasek_integracji)
        separator = QFrame()
        separator.setObjectName("separatorNaglowka")
        separator.setFixedSize(1, 30)
        layout.addWidget(separator)
        settings = QToolButton()
        settings.setObjectName("ustawieniaNaglowka")
        settings.setAccessibleName("Ustawienia")
        settings.setToolTip("Ustawienia")
        settings.setIcon(ikona("ustawienia"))
        settings.setIconSize(QSize(22, 22))
        settings.clicked.connect(lambda: self.przejdz("Ustawienia"))
        layout.addWidget(settings)
        avatar = etykieta("")
        avatar.setObjectName("avatarNaglowka")
        avatar.setPixmap(ikona("uzytkownik", "#AEBBD0").pixmap(28, 28))
        avatar.setFixedSize(36, 36)
        avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(avatar)
        profil = QVBoxLayout()
        profil.setSpacing(2)
        profil.addWidget(etykieta(self.powloka.nazwa_uzytkownika))
        wersja = etykieta(f"Wersja {self.powloka.wersja}", "wersjaNaglowka")
        profil.addWidget(wersja)
        layout.addLayout(profil)
        avatar.setToolTip(
            "Profil pokazuje nazwę użytkownika systemu. Nie jest kontem sprzedażowym."
        )
        return frame

    def _dodaj_strone(self, nazwa: str, widget: QWidget) -> None:
        self.strony[nazwa] = widget
        self.stos.addWidget(widget)

    def _dashboard(self) -> None:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        strona = QWidget()
        strona.setObjectName("strona")
        self.siatka = QGridLayout(strona)
        self.siatka.setContentsMargins(16, 16, 16, 16)
        self.siatka.setSpacing(14)
        for i, (nazwa, kolor) in enumerate(
            [
                ("Produkty", "produkty"),
                ("Aktywne oferty", "aktywne"),
                ("Szkice ofert", "szkice"),
                ("Błędy", "bledy"),
            ]
        ):
            frame = KafelekKPI(nazwa, kolor, "W bazie produktów" if i == 0 else "W przygotowaniu")
            self._kpi.append(frame)
            if i == 0:
                self.liczba_produktow = frame.liczba
        akcje = QWidget()
        pasek = QGridLayout(akcje)
        pasek.setContentsMargins(0, 0, 0, 0)
        self._pasek_akcji = pasek
        self._przyciski_akcji: list[QPushButton] = []
        for i, nazwa in enumerate(
            (
                "Utwórz nowe oferty",
                "Pobierz z Allegro",
                "Synchronizuj ceny",
                "Masowa edycja",
                "Kreator układu ofert",
            )
        ):
            symbol = ("dodaj", "pobierz", "synchronizacja", "masowa", "edytuj")[i]
            button = PrzyciskAkcji(nazwa, symbol)
            button.setEnabled(False)
            button.setToolTip("Funkcja w przygotowaniu. Nie wykonuje operacji.")
            button.setProperty("pasekAkcji", True)
            if i == 0:
                button.setObjectName("primary")
                if self.paczki is not None:
                    button.setEnabled(True)
                    button.setToolTip("Wczytaj paczkę ofert lub otwórz lokalne szkice")
                    menu = QMenu(button)
                    menu.addAction("Wczytaj paczkę ZIP…", lambda: self.przejdz("Nowe oferty"))
                    if self.szkice is not None:
                        menu.addAction("Otwórz lokalne szkice", lambda: self.przejdz("Szkice"))
                    button.setMenu(menu)
            elif i == 1 and self.allegro is not None:
                button.setEnabled(True)
                button.setToolTip("Otwórz Allegro i odśwież listę szkiców połączonego konta")
                button.clicked.connect(self._pobierz_szkice_allegro)
            if nazwa == "Masowa edycja":
                self._akcja_masowa = button
                button.clicked.connect(lambda: self.przejdz("Masowa edycja"))
            button.setMinimumHeight(50)
            self._przyciski_akcji.append(button)
            pasek.addWidget(button, i // 3, i % 3)
        self.akcje_glowne = akcje
        produkty, layout = karta("Ostatnie produkty")
        self.filtry_dashboard = self._nowy_pasek_katalogu()
        layout.addWidget(self.filtry_dashboard)
        self.tabela_dashboard = self._tabela()
        self.widok_dashboard = self._widoki(self.tabela_dashboard, self.filtry_dashboard)
        layout.addWidget(self.widok_dashboard, 1)
        self._pasek_stron(layout)
        self.dashboard_info = etykieta("Otwieranie katalogu…", "opis", True)
        layout.addWidget(self.dashboard_info)
        operacje, layout = karta("Ostatnie operacje")
        layout.addWidget(etykieta("Historia operacji w przygotowaniu", "opis", True))
        layout.addWidget(
            etykieta("Nie ma podłączonej kolejki ani historii publikacji.", "opis", True)
        )
        layout.addStretch()
        statystyki, layout = karta("Statystyki sprzedaży")
        layout.addWidget(etykieta("● Allegro     ● PrestaShop", "opis"))
        layout.addStretch()
        layout.addWidget(
            etykieta("Wykres w przygotowaniu\nMetryka sprzedaży wymaga ustalenia.", "opis", True)
        )
        layout.addStretch()
        szybkie, layout = karta("Szybkie akcje")
        self.edytor_szybkich: EdytorSzybkichAkcji | None = None
        edytuj = przycisk("Edytuj")
        edytuj.setAccessibleName("Edytuj szybkie akcje")
        edytuj.clicked.connect(self.edytuj_szybkie_akcje)
        tytul_szybkich = layout.takeAt(0)
        naglowek_szybkich = QHBoxLayout()
        if tytul_szybkich is not None:
            tytul = tytul_szybkich.widget()
            if tytul is not None:
                naglowek_szybkich.addWidget(tytul, 1)
        naglowek_szybkich.addWidget(edytuj, 0, Qt.AlignmentFlag.AlignRight)
        layout.insertLayout(0, naglowek_szybkich)
        self.szybkie_grid = QGridLayout()
        layout.addLayout(self.szybkie_grid)
        self._odswiez_szybkie_akcje()
        layout.addStretch()
        integracje = PanelIntegracji()
        self.panel_integracji_dashboard = integracje
        self.dashboard_allegro = integracje.allegro.status
        integracje.zarzadzaj.connect(self._zarzadzaj_integracjami)
        self._panele = [produkty, operacje, statystyki, szybkie, integracje]
        self._rozmiesc(4)
        scroll.setWidget(strona)
        self._dodaj_strone("Dashboard", scroll)

    def _zarzadzaj_integracjami(self) -> None:
        self.przejdz("Ustawienia")
        self.ustawienia_zakladki.setCurrentIndex(1)

    def _pobierz_szkice_allegro(self) -> None:
        self.przejdz("Allegro")
        self.strona_allegro.pobierz()

    def _stan_allegro(self, tekst: str) -> None:
        sesja = self.strona_allegro.sesja
        login = sesja.konto.login if sesja is not None else None
        self.pasek_integracji.ustaw(login)
        self.panel_integracji_dashboard.allegro.ustaw(login)
        if hasattr(self, "integracje"):
            status = (
                "Połączono"
                if self.strona_allegro.sesja is not None
                else ("Sprawdzanie…" if self.strona_allegro.trwa else "Niepołączono")
            )
            self.integracje.ustaw_status(self.strona_allegro.panel_polaczenia, status)

    def _wybrane_szybkie(self) -> tuple[str, ...]:
        wybor = self.powloka.preferencje.szybkie_akcje
        return DOMYSLNE_AKCJE if wybor is None else wybor

    def _odswiez_szybkie_akcje(self) -> None:
        while self.szybkie_grid.count():
            item = self.szybkie_grid.takeAt(0)
            w = item.widget() if item else None
            if w is not None:
                w.deleteLater()
        mapa = {a.id: a for a in AKCJE}
        self.szybkie_przyciski: list[QPushButton] = []
        for i, id in enumerate(self._wybrane_szybkie()):
            akcja = mapa[id]
            symbol, opis = KARTY_AKCJI[id]
            button = KartaAkcji(akcja.nazwa, symbol, opis)
            button.setEnabled(akcja.dostepna)
            button.setProperty("akcja_id", id)
            if akcja.cel == "korekty":
                button.clicked.connect(self.pokaz_korekty)
            else:
                button.clicked.connect(lambda checked=False, cel=akcja.cel: self.przejdz(cel))
            if not akcja.dostepna:
                button.setToolTip("Funkcja w przygotowaniu")
            self.szybkie_grid.addWidget(button, i // 2, i % 2)
            self.szybkie_przyciski.append(button)
        if not self.szybkie_przyciski:
            self.szybkie_grid.addWidget(
                etykieta("Wybierz skróty przyciskiem Edytuj.", "opis", True), 0, 0
            )

    def edytuj_szybkie_akcje(self) -> None:
        if self.edytor_szybkich is not None:
            self.edytor_szybkich.raise_()
            return
        dialog = EdytorSzybkichAkcji(self._wybrane_szybkie(), self)
        self.edytor_szybkich = dialog

        def zapisz() -> None:
            try:
                self.powloka.ustaw_szybkie_akcje(dialog.wynik())
            except (BladTechniczny, ValueError) as exc:
                dialog.blad.setText(str(exc))
                return
            self._odswiez_szybkie_akcje()
            dialog.accept()

        def zamknieto() -> None:
            self.edytor_szybkich = None
            dialog.deleteLater()

        dialog.przyciski.accepted.connect(zapisz)
        dialog.finished.connect(zamknieto)
        dialog.setModal(True)
        dialog.open()

    def _tabela(self, masowa: bool = False) -> QTableView:
        tabela = TabelaKatalogu(self._zaznacz_wyniki, self._odznacz_tabele)
        tabela.setAccessibleName("Katalog produktów lokalnych")
        tabela.setModel(self.filtr)
        tabela.setHorizontalHeader(
            NaglowekWyboru(
                tabela, lambda: self._zaznacz_wyniki(tabela), lambda: self._odznacz_tabele(tabela)
            )
        )
        tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tabela.selectionModel().selectionChanged.connect(self._opis_zaznaczenia)
        tabela.setSortingEnabled(True)
        tabela.sortByColumn(1, Qt.SortOrder.AscendingOrder)
        tabela.verticalHeader().hide()
        tabela.verticalHeader().setDefaultSectionSize(54)
        tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        tabela.horizontalHeader().setMinimumSectionSize(28)
        tabela.horizontalHeader().moveSection(9, 0)
        for col, width in (
            (9, 28),
            (0, 62),
            (2, 112),
            (3, 96),
            (4, 106),
            (5, 48),
            (6, 64),
            (7, 82),
            (8, 76),
        ):
            tabela.setColumnWidth(col, width)
        if masowa:
            tabela.setColumnHidden(8, True)
        dekoracja = RysowanieKatalogu(tabela, self._akcje_wiersza_dostepne)
        for col in (0, 6, 7, 8, 9):
            tabela.setItemDelegateForColumn(col, dekoracja)
        dekoracja.edytuj.connect(lambda index: self._akcja_wiersza(tabela, index, "edytuj"))
        dekoracja.menu.connect(lambda index, point: self._menu_wiersza(tabela, index, point))
        tabela.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        tabela.setMinimumHeight(230)
        tabela.setIconSize(QSize(40, 40))
        if not masowa:
            tabela.doubleClicked.connect(self.edytuj_indeks)
        skrot = QShortcut(QKeySequence("Return"), tabela)
        skrot.setContext(Qt.ShortcutContext.WidgetShortcut)
        if masowa:
            skrot.activated.connect(self.edycja_masowa)
        else:
            skrot.activated.connect(lambda: self.pokaz_szczegoly(tabela.currentIndex()))
        self._skroty_tabel.append(skrot)
        self._tabele.append(tabela)
        return tabela

    def _akcje_wiersza_dostepne(self) -> bool:
        return self._katalog_wczytany and not (
            self._blad_katalogu or self._katalog_trwa or self._wybor_trwa
        )

    def _akcja_wiersza(self, tabela: QTableView, index: QModelIndex, akcja: str) -> None:
        if not self._akcje_wiersza_dostepne():
            return
        produkt = self._produkt_z_indeksu(index)
        if produkt is not None and akcja == "edytuj":
            self._formularz(produkt)

    def _menu_wiersza(self, tabela: QTableView, index: QModelIndex, punkt: QPoint) -> None:
        if not self._akcje_wiersza_dostepne() or not index.isValid():
            return
        wybor = tabela.selectionModel()
        if not wybor.isRowSelected(index.row(), QModelIndex()):
            self.wybor.wyczysc(tabela)
            wybor.select(
                index,
                QItemSelectionModel.SelectionFlag.ClearAndSelect
                | QItemSelectionModel.SelectionFlag.Rows,
            )
        wybor.setCurrentIndex(index, QItemSelectionModel.SelectionFlag.NoUpdate)
        self._opis_zaznaczenia()
        if tabela is self.tabela_produktow:
            self.menu_kontekstowe_produktow.popup(punkt)
            return
        produkt = self._produkt_z_indeksu(index)
        if produkt is None:
            return
        if self.menu_wiersza is not None:
            self.menu_wiersza.close()
        menu = QMenu(self)
        self.menu_wiersza = menu
        menu.addAction("Szczegóły", lambda: self.pokaz_szczegoly(index))
        menu.addAction("Edytuj…", lambda: self._formularz(produkt))
        galeria = menu.addAction("Galeria…", lambda: self._otworz_galerie(tabela))
        galeria.setEnabled(self.galeria is not None and len(self._zaznaczone_w_tabeli(tabela)) == 1)
        menu.addSeparator()
        menu.addAction("Zaznacz wszystkie wyniki", lambda: self._zaznacz_wyniki(tabela))
        menu.addAction("Odznacz", lambda: self._odznacz_tabele(tabela))
        wybrane = self._zaznaczone_w_tabeli(tabela)
        menu.addAction("Usuń zaznaczone…", lambda: self._usun(wybrane))

        def ukryto() -> None:
            if self.menu_wiersza is menu:
                self.menu_wiersza = None
            menu.deleteLater()

        menu.aboutToHide.connect(ukryto)
        menu.popup(punkt)

    def _widoki(self, tabela: QTableView, pasek: FiltryKatalogu) -> WidokiKatalogu:
        w = WidokiKatalogu(
            tabela, lambda: self._zaznacz_wyniki(tabela), lambda: self._odznacz_tabele(tabela)
        )
        w.kafelki.setObjectName("kafelkiProduktow")
        if isinstance(tabela, TabelaKatalogu):
            tabela.dostepnosc.connect(w.kafelki.setEnabled)
        dekoracja = RysowanieKafelkow(w.kafelki, self._akcje_wiersza_dostepne)
        w.kafelki.setItemDelegate(dekoracja)
        dekoracja.edytuj.connect(lambda index: self._akcja_wiersza(tabela, index, "edytuj"))
        dekoracja.menu.connect(lambda index, point: self._menu_wiersza(tabela, index, point))
        w.kafelki.doubleClicked.connect(self.edytuj_indeks)
        w.kafelki.szczegoly.connect(self.pokaz_szczegoly)
        w.kafelki.customContextMenuRequested.connect(
            lambda p: self._menu_wiersza(
                tabela, w.kafelki.indexAt(p), w.kafelki.viewport().mapToGlobal(p)
            )
        )
        pasek.tryb.connect(w.ustaw_tryb)
        self._widoki_katalogu.append(w)
        return w

    def _nowy_pasek_katalogu(self) -> FiltryKatalogu:
        w = FiltryKatalogu()
        w.producent.connect(self._zmien_filtr_producenta)
        w.fraza.connect(self._wyszukaj_lokalnie)
        w.filtry.connect(self._ustaw_filtry_katalogu)
        w.reset.connect(self.wyczysc_filtry)
        self._paski_katalogu.append(w)
        return w

    def _synchronizuj_paski(self) -> None:
        for w in self._paski_katalogu:
            w.ustaw(
                self._producenci_katalogu,
                self.filtr.producent,
                self.filtr.fraza,
                self.filtr.zdjecia,
                self.filtr.cena,
            )

    def _ustaw_filtry_katalogu(self, zdjecia: object, cena: object) -> None:
        self.filtr.beginFilterChange()
        self.filtr.zdjecia = cast(bool | None, zdjecia)
        self.filtr.cena = cast(bool | None, cena)
        self.filtr.endFilterChange(QSortFilterProxyModel.Direction.Rows)
        for tabela in self._tabele:
            self.wybor.wyczysc(tabela)
        self._synchronizuj_paski()
        self._zmiana_zapytania()

    def _wyszukaj_lokalnie(self, fraza: str) -> None:
        self.szukaj.blockSignals(True)
        self.szukaj.setText(fraza)
        self.szukaj.blockSignals(False)
        for tabela in self._tabele:
            self.wybor.wyczysc(tabela)
        self.filtr.ustaw_fraze(fraza)
        self._synchronizuj_paski()
        self._zmiana_zapytania()
        self._opis_listy()

    def _produkty(self) -> None:
        frame = QWidget()
        frame.setObjectName("strona")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.addWidget(etykieta("Produkty", "marka"))
        layout.addWidget(
            etykieta("Lokalny katalog • nazwa, obowiązkowe SKU i opcjonalny opis", "opis", True)
        )
        toolbar = QGridLayout()
        self._pasek_produktow = toolbar
        self.dodaj = przycisk("Dodaj produkt")
        self.dodaj.setObjectName("primary")
        self.dodaj.clicked.connect(self.dodaj_produkt)
        self.odswiez_przycisk = przycisk("Odśwież")
        self.odswiez_przycisk.clicked.connect(self.odswiez)
        self.wiecej_produktow = QToolButton()
        self.wiecej_produktow.setObjectName("menuAkcji")
        self.wiecej_produktow.setText("Więcej akcji")
        self.wiecej_produktow.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        self.wiecej_produktow.setAccessibleName("Więcej akcji produktów — rozwiń menu")
        self.wiecej_produktow.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.wiecej_produktow.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        self._przyciski_produktow = [
            self.dodaj,
            self.odswiez_przycisk,
            self.wiecej_produktow,
        ]
        for i, button in enumerate(self._przyciski_produktow):
            toolbar.addWidget(button, 0, i)
        toolbar.setColumnStretch(3, 1)
        layout.addLayout(toolbar)
        self.menu_produktow = QMenu("Akcje produktów", self)
        self.menu_kontekstowe_produktow = QMenu("Akcje produktów", self)
        self.wiecej_produktow.setMenu(self.menu_produktow)

        def akcja(tekst: str, funkcja: Callable[[], None]) -> QAction:
            a = QAction(tekst, self)
            a.triggered.connect(funkcja)
            return a

        self.szczegoly_akcja = akcja(
            "Szczegóły", lambda: self.pokaz_szczegoly(self._indeks_wybranego_produktu())
        )
        self.edycja_akcja = akcja(
            "Edytuj…", lambda: self.edytuj_indeks(self._indeks_wybranego_produktu())
        )
        self.galeria_akcja = akcja("Galeria…", self.pokaz_galerie)
        self.pobierz_zdjecia_akcja = akcja("Pobierz zdjęcia…", self.pobierz_zdjecia_zaznaczonych)
        self.edytuj_masowo_przycisk = akcja("Masowa edycja…", self.edycja_masowa)
        self.usun_przycisk = akcja("Usuń zaznaczone…", self.usun_zaznaczony)
        self.wyczysc_przycisk = akcja("Usuń wszystkie wyniki…", self.usun_wyniki)
        self.zaznacz_wszystkie = akcja("Zaznacz wszystkie", self.tabela_select_all)
        self.odznacz_wszystkie = akcja("Odznacz", lambda: self.tabela_produktow.clearSelection())
        self.eksportuj_przycisk = akcja("Eksportuj CSV…", self.eksportuj_wyniki)
        self.eksportuj_przycisk.setEnabled(False)
        self.eksportuj_przycisk.setToolTip("Eksportuj wszystkie bieżące wyniki do pliku CSV.")
        self.usun_przycisk.setToolTip("Usuń tylko zaznaczone produkty po potwierdzeniu.")
        self.wyczysc_przycisk.setToolTip("Usuń wszystkie produkty pasujące do bieżących filtrów.")
        korekty = akcja("Do poprawy", self.pokaz_korekty)
        dodaj = akcja("Dodaj", self.dodaj.click)
        odswiez = akcja("Odśwież", self.odswiez_przycisk.click)
        for menu in (self.menu_produktow, self.menu_kontekstowe_produktow):
            menu.setToolTipsVisible(True)
            for a in (
                self.szczegoly_akcja,
                self.edycja_akcja,
                self.galeria_akcja,
                self.pobierz_zdjecia_akcja,
                self.edytuj_masowo_przycisk,
            ):
                menu.addAction(a)
            menu.addSeparator()
            menu.addAction(self.zaznacz_wszystkie)
            menu.addAction(self.odznacz_wszystkie)
            menu.addSeparator()
            katalog_akcje = (
                (dodaj, korekty, self.eksportuj_przycisk, odswiez)
                if menu is self.menu_kontekstowe_produktow
                else (korekty, self.eksportuj_przycisk)
            )
            for a in katalog_akcje:
                menu.addAction(a)
            menu.addSeparator()
            menu.addAction(self.usun_przycisk)
            menu.addAction(self.wyczysc_przycisk)
            menu.aboutToShow.connect(self._stan_akcji_produktow)
        self.info_zaznaczenia = etykieta("Zaznaczono: 0", "opis")
        layout.addWidget(self.info_zaznaczenia)
        self.filtry_produktow = self._nowy_pasek_katalogu()
        layout.addWidget(self.filtry_produktow)
        self.info_produktow = etykieta("Otwieranie katalogu…", "opis", True)
        layout.addWidget(self.info_produktow)
        self.tabela_produktow = self._tabela()
        self.tabela_produktow.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tabela_produktow.customContextMenuRequested.connect(self._menu_produktow_pod_mysza)
        for klawisz in ("Shift+F10", "Menu"):
            skrot = QShortcut(QKeySequence(klawisz), self.tabela_produktow)
            skrot.setContext(Qt.ShortcutContext.WidgetShortcut)
            skrot.activated.connect(self._menu_produktow_z_klawiatury)
            self._skroty_tabel.append(skrot)
        self._stan_akcji_produktow()
        self.widok_produktow = self._widoki(self.tabela_produktow, self.filtry_produktow)
        layout.addWidget(self.widok_produktow, 1)
        self._pasek_stron(layout)
        layout.addWidget(
            etykieta(
                "Enter — szczegóły, dwuklik — edycja, prawy przycisk myszy — akcje. "
                "Producent jest opcjonalny. "
                "Cena to sugerowana cena źródłowa. "
                "Stany magazynowe i publikacja w kanałach niewdrożone.",
                "opis",
                True,
            )
        )
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(frame)
        self._dodaj_strone("Produkty", scroll)

    def _indeks_wybranego_produktu(self) -> QModelIndex:
        indeksy = self.tabela_produktow.selectionModel().selectedRows(1)
        return indeksy[0] if len(indeksy) == 1 else QModelIndex()

    def _stan_akcji_produktow(self) -> None:
        if not hasattr(self, "tabela_produktow") or not hasattr(self, "menu_produktow"):
            return
        ile = len(self._zaznaczone_w_tabeli(self.tabela_produktow))
        gotowe = (
            self._katalog_wczytany
            and not self._blad_katalogu
            and not self._usuwanie
            and not self._katalog_trwa
            and not self._wybor_trwa
        )
        pojedynczy = gotowe and ile == 1 and self._indeks_wybranego_produktu().isValid()
        self.szczegoly_akcja.setEnabled(pojedynczy)
        self.edycja_akcja.setEnabled(pojedynczy)
        self.galeria_akcja.setEnabled(pojedynczy and self.galeria is not None)
        self.pobierz_zdjecia_akcja.setEnabled(
            gotowe
            and ile > 0
            and self.zdjecia_seryjne is not None
            and self.dialog_zdjec is None
            and not self._otwieranie_zdjec
        )
        self.edytuj_masowo_przycisk.setEnabled(gotowe and ile > 0)
        self.usun_przycisk.setEnabled(gotowe and ile > 0)
        self.wyczysc_przycisk.setEnabled(gotowe and self.filtr.rowCount() > 0)
        self.zaznacz_wszystkie.setEnabled(gotowe and self.filtr.rowCount() > 0)
        self.odznacz_wszystkie.setEnabled(ile > 0 and not self._wybor_trwa)
        self.eksportuj_przycisk.setEnabled(gotowe and self.filtr.rowCount() > 0)

    def _menu_produktow_pod_mysza(self, punkt: QPoint) -> None:
        tabela = self.tabela_produktow
        indeks = tabela.indexAt(punkt)
        wybor = tabela.selectionModel()
        if indeks.isValid():
            if not wybor.isRowSelected(indeks.row(), QModelIndex()):
                self.wybor.wyczysc(tabela)
                wybor.select(
                    indeks,
                    QItemSelectionModel.SelectionFlag.ClearAndSelect
                    | QItemSelectionModel.SelectionFlag.Rows,
                )
            wybor.setCurrentIndex(indeks, QItemSelectionModel.SelectionFlag.NoUpdate)
        else:
            self.wybor.wyczysc(tabela)
            wybor.setCurrentIndex(QModelIndex(), QItemSelectionModel.SelectionFlag.NoUpdate)
        self._stan_akcji_produktow()
        self.menu_kontekstowe_produktow.popup(tabela.viewport().mapToGlobal(punkt))

    def _menu_produktow_z_klawiatury(self) -> None:
        tabela = self.tabela_produktow
        indeks = tabela.currentIndex()
        punkt = tabela.visualRect(indeks).center() if indeks.isValid() else QPoint(12, 12)
        self._stan_akcji_produktow()
        self.menu_kontekstowe_produktow.popup(tabela.viewport().mapToGlobal(punkt))

    def _ustawienia(self) -> None:
        frame = QWidget()
        frame.setObjectName("strona")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.addWidget(etykieta("Ustawienia", "marka"))
        self.ustawienia_zakladki = QTabWidget()
        self.ustawienia_zakladki.setAccessibleName("Kategorie ustawień")
        self.ustawienia_zakladki.tabBar().setUsesScrollButtons(False)
        layout.addWidget(self.ustawienia_zakladki, 1)

        def strona(nazwa: str) -> QVBoxLayout:
            panel = QWidget()
            wnetrze = QVBoxLayout(panel)
            wnetrze.setContentsMargins(18, 18, 18, 18)
            wnetrze.setSpacing(14)
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(panel)
            self.ustawienia_zakladki.addTab(scroll, nazwa)
            return wnetrze

        ogolne = strona("Ogólne")
        ogolne.addWidget(etykieta("Wygląd", "tytul"))
        self.wybor_motywu = QComboBox()
        self.wybor_motywu.setAccessibleName("Motyw interfejsu")
        self.wybor_motywu.addItem("Ciemny", Motyw.CIEMNY)
        self.wybor_motywu.addItem("Jasny", Motyw.JASNY)
        self.wybor_motywu.addItem("Systemowy", Motyw.SYSTEMOWY)
        self.wybor_motywu.setCurrentIndex(
            self.wybor_motywu.findData(self.powloka.preferencje.motyw)
        )
        self.wybor_motywu.currentIndexChanged.connect(self.zmien_motyw)
        ogolne.addWidget(self.wybor_motywu)
        ogolne.addWidget(etykieta("Szybkie akcje", "tytul"))
        ogolne.addWidget(
            etykieta("Wybierz skróty widoczne na Dashboardzie i ustaw ich kolejność.", "opis", True)
        )
        edytuj = przycisk("Edytuj szybkie akcje")
        edytuj.clicked.connect(self.edytuj_szybkie_akcje)
        ogolne.addWidget(edytuj, 0, Qt.AlignmentFlag.AlignLeft)
        uzytkownik = etykieta(f"Użytkownik systemu: {self.powloka.nazwa_uzytkownika}", "opis", True)
        uzytkownik.setTextFormat(Qt.TextFormat.PlainText)
        ogolne.addWidget(uzytkownik)
        ogolne.addStretch()

        self.integracje = IntegracjeUstawien()
        if self.allegro is not None:
            self.integracje.dodaj("Allegro", "Niepołączono", self.strona_allegro.panel_polaczenia)
            QTimer.singleShot(0, self.strona_allegro.przywroc)
        presta = QWidget()
        presta_layout = QVBoxLayout(presta)
        presta_layout.addWidget(etykieta("PrestaShop", "tytul"))
        presta_layout.addWidget(
            etykieta(
                "Integracja w przygotowaniu. Konfiguracja połączenia "
                "będzie dostępna po wdrożeniu konektora.",
                "opis",
                True,
            )
        )
        presta_layout.addStretch()
        self.integracje.dodaj("PrestaShop", "W przygotowaniu", presta)
        self.panel_gt = PanelSrodowiskaGT(self.diagnostyka_gt, self._uruchom)
        self.integracje.dodaj("Subiekt GT", "W przygotowaniu", self.panel_gt)
        self.ustawienia_zakladki.addTab(self.integracje, "Integracje")

        dane = strona("Dane i kopie")
        dane.addWidget(etykieta("Lokalizacja danych", "tytul"))
        self.lokalizacja_danych = QLineEdit(
            str(self.katalog_danych)
            if self.katalog_danych is not None
            else "Lokalizacja nie została przekazana w tej konfiguracji."
        )
        self.lokalizacja_danych.setReadOnly(True)
        self.lokalizacja_danych.setAccessibleName("Lokalizacja danych VexLab")
        dane.addWidget(self.lokalizacja_danych)
        dane.addWidget(etykieta("Kopia lokalnego katalogu", "tytul"))
        backup = przycisk("Utwórz kopię katalogu…")
        backup.clicked.connect(self.utworz_kopie)
        dane.addWidget(backup, 0, Qt.AlignmentFlag.AlignLeft)
        dane.addWidget(
            etykieta(
                "Kopia obejmuje katalog lokalny. Nie zawiera zapamiętanych "
                "połączeń Allegro. Istniejące pliki nie są nadpisywane.",
                "opis",
                True,
            )
        )
        dane.addStretch()

        o_programie = strona("O programie")
        self.informacje_programu = InformacjeOProgramie(
            self.powloka.wersja, self.diagnostyka, self._uruchom
        )
        o_programie.addWidget(self.informacje_programu)
        self._dodaj_strone("Ustawienia", frame)

    def _pokaz_ustawienia_allegro(self) -> None:
        self.ustawienia_zakladki.setCurrentIndex(1)
        self.integracje.setCurrentWidget(self.strona_allegro.panel_polaczenia)
        self.przejdz("Ustawienia")

    def przejdz(self, nazwa: str) -> None:
        if nazwa not in self.strony:
            frame = QWidget()
            frame.setObjectName("strona")
            layout = QVBoxLayout(frame)
            layout.setContentsMargins(28, 28, 28, 28)
            layout.addWidget(etykieta(nazwa, "marka"))
            if nazwa == "Pomoc i poradnik":
                tekst = (
                    "Działa lokalny katalog i rejestr producentów.\n"
                    "Produkty: filtry, podgląd szczegółów oraz eksport wyników do CSV.\n"
                    "Cenniki: import XLSX/CSV, ceny sugerowane i trwała lista Do poprawy.\n"
                    "Ctrl+K — wyszukiwanie produktów. Ustawienia — motyw i kopia katalogu.\n"
                    "Pozostałe moduły są w przygotowaniu; nie wykonują publikacji "
                    "ani synchronizacji."
                )
            else:
                tekst = (
                    "W przygotowaniu\nTen moduł nie wykonuje jeszcze operacji biznesowych.\n"
                    "Możesz pracować w lokalnym katalogu: Produkty."
                )
            layout.addWidget(etykieta(tekst, "opis", True))
            layout.addStretch()
            self._dodaj_strone(nazwa, frame)
        self.stos.setCurrentWidget(self.strony[nazwa])
        if nazwa == "Szkice" and self.szkice is not None:
            self.strona_szkicow.odswiez()
        if nazwa == "Cenniki":
            if self.strona_cennikow is not None:
                self.strona_cennikow.odswiez()
            else:
                self.strona_importu.odswiez()
        if nazwa == "Producenci":
            self.strona_producentow.odswiez()
        for cel, button in self.przyciski_menu.items():
            button.setChecked(cel == nazwa)
        for grupa, pozycje in MENU:
            if grupa and any(cel == nazwa for cel, _ in pozycje):
                self.rozwiniete_grupy.add(grupa)
        self._ustaw_menu()

    def pokaz_korekty(self) -> None:
        self.strona_importu.tabs.setCurrentIndex(1)
        self.przejdz("Cenniki")
        if self.strona_cennikow is not None:
            self.strona_cennikow.korekty()

    def _szukaj_fokus(self) -> None:
        self.szukaj.setFocus()
        self.szukaj.selectAll()

    def _nowy_filtr_producenta(self) -> QComboBox:
        combo = QComboBox()
        combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        combo.setMinimumContentsLength(22)
        combo.setAccessibleName("Filtr produktów według producenta")
        combo.addItem("Wszyscy producenci", "wszyscy")
        combo.addItem("Bez producenta", "brak")
        combo.currentIndexChanged.connect(
            lambda: self._zmien_filtr_producenta(str(combo.currentData()))
        )
        self._filtry_producenta.append(combo)
        return combo

    def _zmien_filtr_producenta(self, wybor: str) -> None:
        for tabela in self._tabele:
            self.wybor.wyczysc(tabela)
        self.filtr.ustaw_producenta(wybor)
        for combo in self._filtry_producenta:
            combo.blockSignals(True)
            combo.setCurrentIndex(combo.findData(wybor))
            combo.blockSignals(False)
        self._synchronizuj_paski()
        self._opis_listy()
        self._zmiana_zapytania()

    def _wczytaj_filtry(self, producenci: tuple[ProducentDTO, ...]) -> None:
        self._producenci_katalogu = producenci
        self._synchronizuj_paski()
        wybor = self.filtr.producent
        nazwy = Counter(p.nazwa.casefold() for p in producenci)
        for combo in self._filtry_producenta:
            combo.blockSignals(True)
            combo.clear()
            combo.addItem("Wszyscy producenci", "wszyscy")
            combo.addItem("Bez producenta", "brak")
            for producent in producenci:
                nazwa = nazwa_wyboru_producenta(producent, nazwy)
                if not producent.aktywny:
                    nazwa += " (nieaktywny)"
                combo.addItem(nazwa, str(producent.id))
            indeks = combo.findData(wybor)
            if indeks < 0:
                combo.addItem("Nieodnaleziony producent — filtr zachowany", wybor)
                indeks = combo.count() - 1
            combo.setCurrentIndex(indeks)
            combo.blockSignals(False)

    def wyczysc_filtry(self) -> None:
        self.szukaj.blockSignals(True)
        self.szukaj.clear()
        self.szukaj.blockSignals(False)
        self.filtr.ustaw_fraze("")
        self.filtr.zdjecia, self.filtr.cena = None, None
        self._zmien_filtr_producenta("wszyscy")

    def _wyszukaj(self, fraza: str) -> None:
        for tabela in self._tabele:
            self.wybor.wyczysc(tabela)
        self.filtr.ustaw_fraze(fraza)
        self._synchronizuj_paski()
        if fraza and self.stos.currentWidget() not in (
            self.strony.get("Zdjęcia i media"),
            self.strony.get("Masowa edycja"),
        ):
            self.przejdz("Produkty")
        self._zmiana_zapytania()
        self._opis_listy()

    def _opis_listy(self) -> None:
        self._stan_akcji_produktow()
        self._opis_masowej()
        if self._blad_katalogu is not None:
            self.info_produktow.setText(self._blad_katalogu)
            self.dashboard_info.setText(self._blad_katalogu)
            return
        if not self._katalog_wczytany:
            return
        liczba = self._liczba_wszystkich
        tekst = f"Znaleziono {self._liczba_wynikow} z {liczba} produktów."
        if liczba == 0:
            tekst = "Katalog jest pusty. Dodaj pierwszy produkt — wymagane są nazwa i unikalne SKU."
        elif self._liczba_wynikow == 0:
            tekst = "Brak wyników dla wybranych filtrów. Wyczyść filtry."
        self.info_produktow.setText(tekst)
        self.dashboard_info.setText(tekst)
        self._akcja_masowa.setEnabled(self.filtr.rowCount() > 0)

    def _uruchom(
        self,
        funkcja: Callable[[], object],
        sukces: Callable[[object], None],
        blad: Callable[[str, str], None] | None = None,
    ) -> None:
        zadanie = Zadanie(funkcja)
        self._zadania.append(zadanie)
        zadanie.sygnaly.wynik.connect(sukces, Qt.ConnectionType.QueuedConnection)
        zadanie.sygnaly.blad.connect(
            blad or (lambda kod, komunikat: self._blad(komunikat)),
            Qt.ConnectionType.QueuedConnection,
        )
        zadanie.sygnaly.zakonczono.connect(
            lambda: self._zadania.remove(zadanie), Qt.ConnectionType.QueuedConnection
        )
        self.pula.start(zadanie)

    def _zapytanie(self) -> ZapytanieKatalogu:
        return ZapytanieKatalogu(
            self.filtr.fraza,
            self.filtr.producent,
            self._strona,
            self._rozmiar_strony,
            max(0, self.filtr.sortColumn()),
            self.filtr.sortOrder() == Qt.SortOrder.DescendingOrder,
            self.filtr.zdjecia,
            self.filtr.cena,
        )

    def _pasek_stron(self, layout: QVBoxLayout) -> None:
        pasek = PasekStron()
        pasek.strona.connect(self._zmien_strone)
        pasek.rozmiar.connect(self._zmien_rozmiar_strony)
        self._paski_stron.append(pasek)
        layout.addWidget(pasek)

    def _zmien_strone(self, numer: int) -> None:
        self._strona = max(0, numer)
        self.odswiez()

    def _zmien_rozmiar_strony(self, rozmiar: int) -> None:
        self._rozmiar_strony = rozmiar
        self._strona = 0
        self.odswiez()

    def _zmiana_zapytania(self) -> None:
        self._strona = 0
        self.odswiez()

    def odswiez(self) -> None:
        self._numer_odczytu += 1
        numer = self._numer_odczytu
        zapytanie = self._zapytanie()
        ids = self.wybor.identyfikatory(self._tabele)
        self._katalog_trwa = True
        for tabela in self._tabele:
            tabela.setEnabled(False)
        for pasek in self._paski_stron:
            pasek.setEnabled(False)
        self._stan_akcji_produktow()
        self.status.setText("Odczytywanie katalogu…")
        self._uruchom(
            lambda: self.odczyt_katalogu.strona(zapytanie, ids),
            lambda wynik: self._wczytano(numer, wynik),
            lambda kod, komunikat: self._blad_odczytu(numer, komunikat),
        )

    def _wczytano(self, numer: int, wynik: object) -> None:
        if numer != self._numer_odczytu:
            return
        dane = cast(StronaKatalogu, wynik)
        self._katalog_trwa = False
        self._katalog_wczytany = True
        self._blad_katalogu = None
        self._strona = dane.numer
        self._liczba_wynikow = dane.liczba
        self._liczba_wszystkich = dane.wszystkich
        self._wczytaj_filtry(dane.producenci)
        self.wybor.przywracanie = True
        try:
            self.model.ustaw(list(dane.produkty))
            self.wybor.przywroc(self._tabele, dane.wybrane)
        finally:
            self.wybor.przywracanie = False
        for tabela in self._tabele:
            tabela.setEnabled(True)
        for pasek in self._paski_stron:
            pasek.ustaw(dane)
        self._opis_zaznaczenia()
        self.liczba_produktow.setText(str(dane.wszystkich))
        self._opis_listy()
        self.status.setText("Gotowy • lokalny katalog")

    def _blad_odczytu(self, numer: int, komunikat: str) -> None:
        if numer != self._numer_odczytu:
            return
        self._katalog_trwa = False
        for tabela in self._tabele:
            tabela.setEnabled(True)
        if self._katalog_wczytany:
            komunikat += " Wyświetlono poprzedni odczyt katalogu."
        self._blad_katalogu = komunikat
        self.liczba_produktow.setText("—")
        self.eksportuj_przycisk.setEnabled(False)
        self._blad(komunikat)

    def _blad(self, komunikat: str) -> None:
        self.status.setText(komunikat)
        self.info_produktow.setText(komunikat)
        self.dashboard_info.setText(komunikat)
        self._opis_masowej()
        self._stan_akcji_produktow()

    def dodaj_produkt(self) -> None:
        self._formularz(None)

    def _produkt_z_indeksu(self, indeks: QModelIndex | QPersistentModelIndex) -> ProduktDTO | None:
        if not indeks.isValid() or indeks.model() is not self.filtr:
            return None
        wiersz = self.filtr.mapToSource(indeks).row()
        if not 0 <= wiersz < len(self.model.produkty):
            return None
        return self.model.produkty[wiersz]

    def pokaz_szczegoly(self, indeks: QModelIndex | QPersistentModelIndex) -> None:
        produkt = self._produkt_z_indeksu(indeks)
        if produkt is None:
            self.status.setText("Zaznacz produkt do podglądu.")
            return
        if self.szczegoly is not None:
            self.szczegoly.raise_()
            return
        dialog = SzczegolyProduktu(produkt, self)
        self.szczegoly = dialog
        dialog.setModal(True)
        dialog.edytuj.connect(lambda wynik: self._formularz(cast(ProduktDTO, wynik)))
        dialog.finished.connect(lambda: self._zwolnij_szczegoly(dialog))
        dialog.open()

        if produkt.ma_zdjecia and not produkt.miniatura:

            def obraz(wynik: object) -> None:
                if self.szczegoly is dialog:
                    dialog.ustaw_miniature(cast(dict[UUID, bytes], wynik).get(produkt.id))

            def blad_obrazu(kod: str, komunikat: str) -> None:
                if self.szczegoly is dialog:
                    dialog.ustaw_miniature(None)

            self._uruchom(
                lambda: self.katalog.pobierz_miniatury(((produkt.id, produkt.wersja),)),
                obraz,
                blad_obrazu,
            )

    def _zwolnij_szczegoly(self, dialog: SzczegolyProduktu) -> None:
        if self.szczegoly is dialog:
            self.szczegoly = None
        dialog.deleteLater()

    def widoczne_produkty(self) -> tuple[ProduktDTO, ...]:
        produkty = []
        for wiersz in range(self.filtr.rowCount()):
            produkt = self._produkt_z_indeksu(self.filtr.index(wiersz, 1))
            if produkt is not None:
                produkty.append(produkt)
        return tuple(produkty)

    def eksportuj_wyniki(self) -> None:
        if not self._katalog_wczytany or self._blad_katalogu is not None:
            self.status.setText("Odśwież katalog przed eksportem.")
            return
        self._wszystkie_wyniki(self._eksportuj_produkty)

    def _eksportuj_produkty(self, produkty: tuple[ProduktDTO, ...]) -> None:
        if not produkty:
            self.status.setText("Brak produktów do eksportu.")
            return
        dokumenty = QStandardPaths.writableLocation(
            QStandardPaths.StandardLocation.DocumentsLocation
        )
        if not dokumenty:
            dokumenty = QStandardPaths.writableLocation(
                QStandardPaths.StandardLocation.HomeLocation
            )
        nazwa, _ = QFileDialog.getSaveFileName(
            self,
            f"Eksport {len(produkty)} produktów do CSV",
            str(Path(dokumenty) / "VexLab-produkty.csv"),
            "CSV do arkusza (*.csv)",
            options=QFileDialog.Option.DontConfirmOverwrite,
        )
        if not nazwa:
            return
        self.status.setText(f"Eksportowanie {len(produkty)} produktów…")

        def zapisano(wynik: object) -> None:
            raport = cast(WynikEksportu, wynik)
            tekst = f"Wyeksportowano {raport.produkty} produktów do CSV."
            if raport.zabezpieczone_pola:
                tekst += (
                    f" Zabezpieczono {raport.zabezpieczone_pola} pól przed odczytem jako formuły."
                )
            self.status.setText(tekst)

        self._uruchom(
            lambda: self.eksport.wykonaj(Path(nazwa), produkty),
            zapisano,
            lambda kod, komunikat: self.status.setText(komunikat),
        )

    def edytuj_indeks(self, indeks: QModelIndex | QPersistentModelIndex) -> None:
        produkt = self._produkt_z_indeksu(indeks)
        if produkt is None:
            self.status.setText("Zaznacz produkt do edycji.")
            return
        self._formularz(produkt)

    def _formularz(self, produkt: ProduktDTO | None) -> None:
        if self.formularz is not None and self.formularz.isVisible():
            self.formularz.raise_()
            return
        if self._ladowanie_formularza:
            return
        self._ladowanie_formularza = True

        def blad(kod: str, komunikat: str) -> None:
            self._ladowanie_formularza = False
            self.status.setText(komunikat)

        self._uruchom(
            self.producenci.lista,
            lambda wynik: self._otworz_formularz(produkt, cast(list[ProducentDTO], wynik)),
            blad,
        )

    def _otworz_formularz(self, produkt: ProduktDTO | None, producenci: list[ProducentDTO]) -> None:
        self._ladowanie_formularza = False
        dialog = FormularzProduktu(producenci, produkt, self, obsluga_zdjec=self.media is not None)
        self.formularz = dialog
        if self.media is not None:
            dialog.pobierz_zdjecia.clicked.connect(lambda: self._pobierz_zdjecia(dialog))
        if produkt is None:
            import_button = QPushButton("Importuj wiele produktów z pliku…")
            cast(QVBoxLayout, dialog.layout()).addWidget(import_button)

            def przejdz_do_importu() -> None:
                dialog.reject()
                self.przejdz("Cenniki")

            import_button.clicked.connect(przejdz_do_importu)
        dialog.setModal(True)
        dialog.przyciski.accepted.connect(lambda: self._zapisz(dialog))
        dialog.finished.connect(lambda: self._zwolnij_formularz(dialog))
        dialog.open()

    def _zwolnij_formularz(self, dialog: FormularzProduktu) -> None:
        if self.formularz is dialog:
            self.formularz = None
        dialog.deleteLater()

    def _pobierz_zdjecia(self, dialog: FormularzProduktu) -> None:
        serwis = self.media
        if serwis is None:
            return
        adres, sku = dialog.strona_www.text(), dialog.sku.text()
        dialog.ustaw_zapis(True)

        def sukces(wynik: object) -> None:
            dialog.ustaw_zapis(False)
            dialog.ustaw_zdjecia(cast(KandydaciZdjec, wynik))

        self._uruchom(lambda: serwis.wykonaj(adres, sku), sukces, dialog.pokaz_blad)

    def _zapisz(self, dialog: FormularzProduktu) -> None:
        dane = dialog.dane()
        zdjecia = dialog.wybrane_zdjecia()
        produkt = dialog.produkt
        dialog.ustaw_zapis(True)
        self.status.setText("Zapisywanie produktu…")

        def operacja() -> ProduktDTO:
            if produkt is None:
                return self.katalog.dodaj(dane, zdjecia)
            return self.katalog.edytuj(produkt.id, produkt.wersja, dane, zdjecia)

        def zapisano(wynik: object) -> None:
            dialog.accept()
            self.odswiez()

        def blad(kod: str, komunikat: str) -> None:
            dialog.pokaz_blad(kod, komunikat)
            self.status.setText("Nie zapisano produktu. Popraw dane w formularzu.")

        self._uruchom(operacja, zapisano, blad)

    def tabela_select_all(self) -> None:
        self.tabela_produktow.selectAll()

    def _zaznaczone_w_tabeli(self, tabela: QTableView) -> tuple[ProduktDTO, ...]:
        return self.wybor.produkty(tabela)

    def _odznacz_tabele(self, tabela: QTableView) -> None:
        self.wybor.wyczysc(tabela)
        self._opis_zaznaczenia()

    def _wszystkie_wyniki(self, gotowe: Callable[[tuple[ProduktDTO, ...]], None]) -> None:
        if (
            self._katalog_trwa
            or self._wybor_trwa
            or not self._katalog_wczytany
            or self._blad_katalogu
        ):
            self.status.setText("Poczekaj na poprawny odczyt katalogu.")
            return
        if self._liczba_wynikow <= len(self.model.produkty):
            gotowe(self.widoczne_produkty())
            return
        numer = self._numer_odczytu
        zapytanie = self._zapytanie()
        self._wybor_trwa = True
        for tabela in self._tabele:
            tabela.setEnabled(False)
        self._stan_akcji_produktow()
        self.status.setText("Odczytywanie wszystkich wyników…")

        def sukces(wynik: object) -> None:
            self._wybor_trwa = False
            if not self._katalog_trwa:
                for tabela in self._tabele:
                    tabela.setEnabled(True)
            if numer == self._numer_odczytu and not self._blad_katalogu:
                gotowe(cast(tuple[ProduktDTO, ...], wynik))
            else:
                self.status.setText("Zmieniono widok. Powtórz akcję dla bieżących wyników.")
            self._opis_zaznaczenia()

        def blad(kod: str, komunikat: str) -> None:
            self._wybor_trwa = False
            if not self._katalog_trwa:
                for tabela in self._tabele:
                    tabela.setEnabled(True)
            self._blad(komunikat)

        self._uruchom(lambda: self.odczyt_katalogu.wszystkie_wyniki(zapytanie), sukces, blad)

    def _zaznacz_wyniki(self, tabela: QTableView) -> None:
        def wybierz(produkty: tuple[ProduktDTO, ...]) -> None:
            self.wybor.ustaw(tabela, produkty)
            self._opis_zaznaczenia()

        self._wszystkie_wyniki(wybierz)

    def _opis_zaznaczenia(self) -> None:
        for tabela in self._tabele:
            header = tabela.horizontalHeader()
            if isinstance(header, NaglowekWyboru):
                header.ustaw(len(self._zaznaczone_w_tabeli(tabela)), self._liczba_wynikow)
        if hasattr(self, "info_zaznaczenia") and hasattr(self, "tabela_produktow"):
            ile = len(self._zaznaczone_w_tabeli(self.tabela_produktow))
            self.info_zaznaczenia.setText(
                f"Zaznaczono: {ile}. Ctrl+A — wszystkie wyniki; Ctrl/Shift — wybór."
            )

        self._opis_masowej()
        self._stan_akcji_produktow()
        if hasattr(self, "info_mediow"):
            self._opis_mediow()

    def usun_zaznaczony(self) -> None:
        produkty = self._zaznaczone_w_tabeli(self.tabela_produktow)
        if not produkty:
            self.status.setText("Zaznacz Produkty do usunięcia.")
            return
        self._usun(produkty)

    def edycja_masowa(self) -> None:
        if self.masowy is not None or self._ladowanie_masowej:
            return
        tabela = (
            self.tabela_masowa
            if self.stos.currentWidget() is self.strony["Masowa edycja"]
            else self.tabela_produktow
        )
        produkty = self._zaznaczone_w_tabeli(tabela)
        if (
            not produkty
            or self._blad_katalogu
            or not self._katalog_wczytany
            or self._katalog_trwa
            or self._wybor_trwa
        ):
            self.status.setText("Zaznacz Produkty na liście przed edycją masową.")
            return
        self._ladowanie_masowej = True

        def blad_odczytu(kod: str, tekst: str) -> None:
            self._ladowanie_masowej = False
            self._blad(tekst)

        def otworz(wynik: object) -> None:
            self._ladowanie_masowej = False
            dialog = FormularzMasowy(len(produkty), cast(list[ProducentDTO], wynik), self)
            self.masowy = dialog

            def zakonczono() -> None:
                self.masowy = None
                dialog.deleteLater()

            dialog.finished.connect(zakonczono)

            def zapisz() -> None:
                zmiana = dialog.dane()
                dialog.ustaw_trwa(True)

                def sukces(wynik: object) -> None:
                    dialog.ustaw_trwa(False)
                    dialog.accept()
                    QMessageBox.information(
                        self,
                        "Edycja masowa zakończona",
                        f"Ustawiono dane {len(produkty)} Produktów. "
                        f"Kopia bazy: {cast(Path, wynik)}",
                    )
                    self.odswiez()

                def blad(kod: str, tekst: str) -> None:
                    dialog.ustaw_trwa(False)
                    dialog.blad.setText(tekst)

                self._uruchom(lambda: self.katalog.zmien_masowo(produkty, zmiana), sukces, blad)

            dialog.przyciski.accepted.connect(zapisz)
            dialog.setModal(True)
            dialog.open()

        self._uruchom(self.producenci.lista, otworz, blad_odczytu)

    def usun_wyniki(self) -> None:
        self._wszystkie_wyniki(self._usun)

    def _usun(self, produkty: tuple[ProduktDTO, ...]) -> None:
        if self._usuwanie:
            return
        if (
            not self._katalog_wczytany
            or self._blad_katalogu
            or not produkty
            or self._katalog_trwa
            or self._wybor_trwa
        ):
            self.status.setText("Brak poprawnego odczytu lub Produktów do usunięcia.")
            return
        # Migawka przed potwierdzeniem: zmiana filtrów nie rozszerza zakresu.
        odpowiedz = QMessageBox.question(
            self,
            "Usuń lokalne Produkty",
            f"Usunąć {len(produkty)} lokalnych Produktów z ich cenami i powiązaniami importu?\n"
            "Przed usunięciem powstanie kopia całej bazy w kopie_usuwania.\n"
            "Przywrócenie wymaga otwarcia kopii w osobnym katalogu danych.\n"
            "Producenci i pozycje Do poprawy pozostaną.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if odpowiedz != QMessageBox.StandardButton.Yes:
            return
        liczba_szkicow = 0
        self._usuwanie = True
        self._stan_akcji_produktow()

        def koniec() -> None:
            self._usuwanie = False
            self._stan_akcji_produktow()

        def sukces(wynik: object) -> None:
            koniec()
            QMessageBox.information(
                self,
                "Usunięto Produkty",
                f"Usunięto {len(produkty)} Produktów. "
                + (f"Usunięto też {liczba_szkicow} lokalnych szkiców. " if liczba_szkicow else "")
                + f"Kopia bazy: {cast(Path, wynik)}",
            )
            self.odswiez()

        def blad_zapisu(kod: str, komunikat: str) -> None:
            koniec()
            self._blad(komunikat)
            QMessageBox.warning(self, "Nie usunięto produktów", komunikat)

        def potwierdz_szkice(wynik: object) -> None:
            nonlocal liczba_szkicow
            szkice = cast(tuple[tuple[UUID, int], ...], wynik)
            if not szkice:
                blad_zapisu(
                    "KONFLIKT", "Powiązania zmieniły się. Odśwież produkty i ponów usuwanie."
                )
                return
            odpowiedz = QMessageBox.question(
                self,
                "Produkty mają lokalne szkice",
                f"Nie usunięto produktów, ponieważ mają powiązane szkice.\n\n"
                f"Usunąć {len(produkty)} wybranych produktów ORAZ "
                f"{len(szkice)} powiązanych lokalnych szkiców?\n"
                "Przed zmianą powstanie kopia całej bazy. Cenniki i producenci pozostaną.\n"
                "Ta operacja dotyczy wyłącznie danych lokalnych.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if odpowiedz != QMessageBox.StandardButton.Yes:
                koniec()
                self._blad("Anulowano. Nie usunięto produktów ani powiązanych lokalnych szkiców.")
                return
            liczba_szkicow = len(szkice)
            self.status.setText("Usuwanie produktów i powiązanych lokalnych szkiców…")
            self._uruchom(lambda: self.katalog.usun(produkty, szkice=szkice), sukces, blad_zapisu)

        def blad(kod: str, komunikat: str) -> None:
            if kod == "SZKICE_PRODUKTOW":
                self._blad(komunikat)
                self._uruchom(
                    lambda: self.katalog.szkice_do_usuniecia(produkty),
                    potwierdz_szkice,
                    blad_zapisu,
                )
            else:
                blad_zapisu(kod, komunikat)

        self.status.setText("Usuwanie produktów…")
        self._uruchom(lambda: self.katalog.usun(produkty), sukces, blad)

    def pobierz_zdjecia_zaznaczonych(self) -> None:
        serwis = self.zdjecia_seryjne
        produkty = self._zaznaczone_w_tabeli(self.tabela_produktow)
        if (
            serwis is None
            or not produkty
            or self._otwieranie_zdjec
            or self.dialog_zdjec is not None
        ):
            return
        self._otwieranie_zdjec = True
        self._stan_akcji_produktow()

        def gotowe(w: object) -> None:
            self._otwieranie_zdjec = False
            producenci = cast(list[ProducentDTO], w)
            ids = {p.producent_id for p in produkty}
            strona = self.powloka.preferencje.strona_zdjec
            if len(ids) == 1:
                strona = next(
                    (p.strona_www for p in producenci if p.id in ids and p.strona_www), strona
                )
            dialog = DialogZdjecSeryjnych(
                produkty,
                serwis,
                strona,
                self.powloka.preferencje.limit_zdjec_mb,
                self.powloka.ustaw_zrodlo_zdjec,
                self._uruchom,
                self,
            )
            self.dialog_zdjec = dialog
            dialog.zapisano.connect(self.odswiez)

            def zamknieto() -> None:
                self.dialog_zdjec = None
                dialog.deleteLater()
                self._stan_akcji_produktow()

            dialog.finished.connect(zamknieto)
            dialog.setModal(True)
            dialog.open()
            self._stan_akcji_produktow()

        def blad(kod: str, tekst: str) -> None:
            self._otwieranie_zdjec = False
            self._stan_akcji_produktow()
            QMessageBox.warning(self, "Nie pobrano zdjęć", tekst)

        self._uruchom(self.producenci.lista, gotowe, blad)

    def utworz_kopie(self) -> None:
        dokumenty = QStandardPaths.writableLocation(
            QStandardPaths.StandardLocation.DocumentsLocation
        )
        if not dokumenty:
            dokumenty = QStandardPaths.writableLocation(
                QStandardPaths.StandardLocation.HomeLocation
            )
        nazwa, _ = QFileDialog.getSaveFileName(
            self,
            "Kopia lokalnego katalogu",
            str(Path(dokumenty) / "VexLab-kopia.sqlite3"),
            "Baza SQLite (*.sqlite3)",
        )
        if nazwa:
            self.status.setText("Tworzenie kopii katalogu…")
            self._uruchom(
                lambda: self.katalog.utworz_kopie(Path(nazwa)),
                lambda wynik: self.status.setText(
                    "Kopia katalogu utworzona; integralność poprawna."
                ),
            )

    def zmien_grupe(self, grupa: str, rozwin: bool) -> None:
        nowe = self.rozwiniete_grupy | {grupa} if rozwin else self.rozwiniete_grupy - {grupa}
        try:
            self.powloka.ustaw_grupy(tuple(g for g, _ in MENU if g in nowe))
        except (BladTechniczny, ValueError) as blad:
            self._ustaw_menu()
            self._blad(str(blad))
            return
        self.rozwiniete_grupy = nowe
        self._ustaw_menu()

    def zmien_menu(self) -> None:
        try:
            self.powloka.ustaw_menu(not self.powloka.preferencje.menu_zwiniete)
        except BladTechniczny as blad:
            self._blad(str(blad))
            return
        self._ustaw_menu()

    def _ustaw_menu(self) -> None:
        zwiniete = self.powloka.preferencje.menu_zwiniete
        self.menu.setFixedWidth(64 if zwiniete else 204)
        for grupa, sekcja in self.sekcje_menu.items():
            sekcja.ustaw(grupa in self.rozwiniete_grupy, zwiniete)
        for button in self.przyciski_menu.values():
            button.setToolButtonStyle(
                Qt.ToolButtonStyle.ToolButtonIconOnly
                if zwiniete
                else Qt.ToolButtonStyle.ToolButtonTextBesideIcon
            )
        self.zwin.setText("→" if zwiniete else "← Zwiń menu")
        self.zwin.setAccessibleName("Rozwiń menu" if zwiniete else "Zwiń menu")
        self.zwin.setToolTip(self.zwin.accessibleName())

    def zmien_motyw(self) -> None:
        try:
            self.powloka.ustaw_motyw(Motyw(self.wybor_motywu.currentData()))
        except BladTechniczny as blad:
            self.wybor_motywu.blockSignals(True)
            self.wybor_motywu.setCurrentIndex(
                self.wybor_motywu.findData(self.powloka.preferencje.motyw)
            )
            self.wybor_motywu.blockSignals(False)
            self._blad(str(blad))
            return
        self._motyw()

    def _motyw(self) -> None:
        app = cast(QApplication, QApplication.instance())
        zastosuj_motyw(app, self.powloka.preferencje.motyw)
        ciemny = bool(app.property("motyw_ciemny"))
        for _, pozycje in MENU:
            for nazwa, _ in pozycje:
                self.przyciski_menu[nazwa].setIcon(ikona_menu(nazwa, ciemny))

    def _rozmiesc(self, kolumny: int) -> None:
        if self._kolumny == kolumny:
            return
        self._kolumny = kolumny
        if hasattr(self, "_pasek_produktow"):
            liczba = 3 if kolumny == 4 else 2
            for i, button in enumerate(self._przyciski_produktow):
                self._pasek_produktow.removeWidget(button)
                self._pasek_produktow.addWidget(button, i // liczba, i % liczba)
            for kolumna in range(5):
                self._pasek_produktow.setColumnStretch(kolumna, int(kolumna == liczba))
        liczba_akcji = 5 if kolumny == 4 else 2
        for i, button in enumerate(self._przyciski_akcji):
            self._pasek_akcji.removeWidget(button)
            self._pasek_akcji.addWidget(button, i // liczba_akcji, i % liczba_akcji)
        for widget in [*self._kpi, self.akcje_glowne, *self._panele]:
            self.siatka.removeWidget(widget)
        for i in range(4):
            self.siatka.setColumnStretch(i, 1 if i < kolumny else 0)
        for i, widget in enumerate(self._kpi):
            self.siatka.addWidget(widget, i // kolumny, i % kolumny)
        wiersz = (3 // kolumny) + 1
        self.siatka.addWidget(self.akcje_glowne, wiersz, 0, 1, kolumny)
        produkty, operacje, statystyki, szybkie, integracje = self._panele
        if kolumny == 4:
            self.siatka.addWidget(produkty, wiersz + 1, 0, 1, 3)
            self.siatka.addWidget(operacje, wiersz + 1, 3)
            self.siatka.addWidget(statystyki, wiersz + 2, 0)
            self.siatka.addWidget(szybkie, wiersz + 2, 1, 1, 2)
            self.siatka.addWidget(integracje, wiersz + 2, 3)
        else:
            self.siatka.addWidget(produkty, wiersz + 1, 0, 1, kolumny)
            for i, widget in enumerate([operacje, statystyki, szybkie, integracje]):
                self.siatka.addWidget(widget, wiersz + 2 + i, 0, 1, kolumny)

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        if hasattr(self, "siatka"):
            self._rozmiesc(4 if self.width() >= 1250 else 2)
        if hasattr(self, "pasek_integracji"):
            self.pasek_integracji.setVisible(self.width() >= 1250)

    def closeEvent(self, event: QCloseEvent) -> None:
        if self._zadania:
            self.status.setText("Trwa odczyt lub zapis. Poczekaj na zakończenie przed zamknięciem.")
            event.ignore()
        else:
            self.miniatury.zamknij()
            if self.allegro is not None:
                self.strona_allegro.anuluj()
            super().closeEvent(event)

    def pokaz_galerie(self) -> None:
        self._otworz_galerie(self.tabela_produktow)

    def _otworz_galerie(self, tabela: QTableView) -> None:
        serwis = self.galeria
        if serwis is None or self._ladowanie_galerii:
            return
        produkty = self._zaznaczone_w_tabeli(tabela)
        if len(produkty) != 1:
            self.status.setText("Zaznacz dokładnie jeden produkt, aby otworzyć galerię.")
            return
        produkt = produkty[0]
        self._ladowanie_galerii = True
        self.status.setText("Odczytywanie galerii…")

        def gotowe(wynik: object) -> None:
            self._ladowanie_galerii = False
            dialog = GaleriaProduktu(
                cast(GaleriaDTO, wynik), produkt.nazwa, serwis, self._uruchom, self.odswiez, self
            )
            dialog.exec()

        def blad(kod: str, tekst: str) -> None:
            self._ladowanie_galerii = False
            self._blad(tekst)

        self._uruchom(lambda: serwis.odczytaj(produkt.id), gotowe, blad)

    def _media(self) -> None:
        frame = QWidget()
        frame.setObjectName("strona")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.addWidget(etykieta("Zdjęcia i media", "marka"))
        layout.addWidget(
            etykieta(
                "Wybierz produkt, aby dodać zdjęcia, ustawić ich kolejność lub wyczyścić galerię.",
                "opis",
                True,
            )
        )
        pasek = QHBoxLayout()
        otworz = przycisk("Otwórz galerię produktu…")
        otworz.setObjectName("primary")
        otworz.clicked.connect(lambda: self._otworz_galerie(self.tabela_mediow))
        pasek.addWidget(otworz)
        odswiez = przycisk("Odśwież")
        odswiez.clicked.connect(self.odswiez)
        pasek.addWidget(odswiez)
        layout.addLayout(pasek)
        layout.addWidget(self._nowy_filtr_producenta())
        reset = przycisk("Wyczyść filtry")
        reset.clicked.connect(self.wyczysc_filtry)
        layout.addWidget(reset)
        self.tabela_mediow: QTableView = TabelaKatalogu(self._zaznacz_wyniki, self._odznacz_tabele)
        tabela = self.tabela_mediow
        tabela.setAccessibleName("Produkty do zarządzania zdjęciami")
        tabela.setModel(self.filtr)
        tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        tabela.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tabela.setSortingEnabled(True)
        tabela.verticalHeader().hide()
        tabela.verticalHeader().setDefaultSectionSize(64)
        tabela.setIconSize(QSize(56, 56))
        tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        tabela.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for kolumna in range(4, self.filtr.columnCount()):
            tabela.hideColumn(kolumna)
        tabela.doubleClicked.connect(lambda indeks: self._otworz_galerie(tabela))
        skrot = QShortcut(QKeySequence("Return"), tabela)
        skrot.setContext(Qt.ShortcutContext.WidgetShortcut)
        skrot.activated.connect(lambda: self._otworz_galerie(tabela))
        self._skroty_tabel.append(skrot)
        self._tabele.append(tabela)
        layout.addWidget(tabela, 1)
        self._pasek_stron(layout)
        self.info_mediow = etykieta("", "opis", True)
        layout.addWidget(self.info_mediow)
        self.filtr.rowsInserted.connect(self._opis_mediow)
        self.filtr.rowsRemoved.connect(self._opis_mediow)
        self.filtr.modelReset.connect(self._opis_mediow)
        self.filtr.layoutChanged.connect(self._opis_mediow)
        self._opis_mediow()
        self._dodaj_strone("Zdjęcia i media", frame)

    def _opis_mediow(self) -> None:
        ile = self._liczba_wynikow
        wybrane = len(self._zaznaczone_w_tabeli(self.tabela_mediow))
        self.info_mediow.setText(
            f"Produktów w widoku: {ile}. Zaznaczono: {wybrane}. Enter lub dwuklik — galeria. "
            "Pierwsze zdjęcie jest miniaturą. Wyszukiwanie nazw/SKU: Ctrl+K."
            if ile
            else "Brak produktów. Wyczyść filtry lub dodaj produkt w zakładce Produkty."
        )

    def _strona_masowej_edycji(self) -> None:
        frame = QWidget()
        frame.setObjectName("strona")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.addWidget(etykieta("Masowa edycja", "marka"))
        layout.addWidget(
            etykieta(
                "Wybierz produkty, a następnie ustaw wspólną zmianę producenta lub opisu. "
                "Przed zapisem powstanie kopia bazy. Bez publikacji ofert.",
                "opis",
                True,
            )
        )
        filtr = QHBoxLayout()
        filtr.addWidget(self._nowy_filtr_producenta(), 1)
        reset = przycisk("Wyczyść filtry")
        reset.clicked.connect(self.wyczysc_filtry)
        filtr.addWidget(reset)
        odswiez = przycisk("Odśwież")
        odswiez.clicked.connect(self.odswiez)
        filtr.addWidget(odswiez)
        layout.addLayout(filtr)
        pasek = QHBoxLayout()
        wszystkie = przycisk("Zaznacz wszystkie wyniki")
        wszystkie.clicked.connect(lambda: self.tabela_masowa.selectAll())
        pasek.addWidget(wszystkie)
        odznacz = przycisk("Odznacz")
        odznacz.clicked.connect(lambda: self.tabela_masowa.clearSelection())
        pasek.addWidget(odznacz)
        self.zmiana_masowa_przycisk = przycisk("Ustaw zmianę zaznaczonych…")
        self.zmiana_masowa_przycisk.setObjectName("primary")
        self.zmiana_masowa_przycisk.clicked.connect(self.edycja_masowa)
        pasek.addWidget(self.zmiana_masowa_przycisk)
        layout.addLayout(pasek)
        self.info_masowej = etykieta("", "opis", True)
        layout.addWidget(self.info_masowej)
        self.tabela_masowa: QTableView = self._tabela(masowa=True)
        self.tabela_masowa.setAccessibleName("Produkty wybrane do masowej edycji")
        for kolumna in range(4, self.filtr.columnCount()):
            self.tabela_masowa.hideColumn(kolumna)
        skrot = QShortcut(QKeySequence("Ctrl+A"), self.tabela_masowa)
        skrot.setContext(Qt.ShortcutContext.WidgetShortcut)
        skrot.activated.connect(self.tabela_masowa.selectAll)
        self._skroty_tabel.append(skrot)
        layout.addWidget(self.tabela_masowa, 1)
        self._pasek_stron(layout)
        layout.addWidget(
            etykieta(
                "Ctrl/Shift — wybór wielu wierszy. Ctrl+A — wszystkie bieżące wyniki. "
                "Enter — ustaw zmianę. Wyszukiwanie nazw/SKU: Ctrl+K.",
                "opis",
                True,
            )
        )
        self._dodaj_strone("Masowa edycja", frame)
        self._opis_masowej()

    def _opis_masowej(self) -> None:
        if not hasattr(self, "tabela_masowa"):
            return
        ile = len(self._zaznaczone_w_tabeli(self.tabela_masowa))
        self.zmiana_masowa_przycisk.setEnabled(
            ile > 0
            and self._katalog_wczytany
            and not self._blad_katalogu
            and not self._katalog_trwa
            and not self._wybor_trwa
        )
        if self._blad_katalogu:
            tekst = self._blad_katalogu
        elif not self._katalog_wczytany:
            tekst = "Odczytywanie produktów…"
        elif not self._liczba_wszystkich:
            tekst = (
                "Katalog jest pusty. Najpierw dodaj lub zaimportuj produkty w zakładce Produkty."
            )
        elif not self._liczba_wynikow:
            tekst = "Brak wyników. Wyczyść filtry, aby wybrać produkty do zmiany."
        else:
            tekst = (
                f"Zaznaczono: {ile} z {self._liczba_wynikow} wyników. "
                "Zmienisz wyłącznie zaznaczone produkty."
            )
        self.info_masowej.setText(tekst)
