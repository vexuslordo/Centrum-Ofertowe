import pytest

from vexlab.gui.design_system import logo_aplikacji


@pytest.mark.parametrize("kwadrat,rozmiar", [(True, (32, 32)), (False, (112, 48))])
def test_logo_ma_widoczny_jasny_znak_i_ciemne_tlo(qapp, kwadrat, rozmiar):
    icon = logo_aplikacji(kwadrat)
    assert not icon.isNull()
    pixmap = icon.pixmap(*rozmiar)
    obraz = pixmap.toImage()
    dpr = pixmap.devicePixelRatio()
    assert (obraz.width(), obraz.height()) == tuple(round(x * dpr) for x in rozmiar)
    jasne = ciemne = 0
    for y in range(obraz.height()):
        for x in range(obraz.width()):
            c = obraz.pixelColor(x, y)
            if c.alpha() > 200:
                jasne += min(c.red(), c.green(), c.blue()) > 180
                ciemne += max(c.red(), c.green(), c.blue()) < 40
    assert jasne > 20 and ciemne > 50
