# Znaki przewoźników

Lokalne SVG do identyfikacji dostawy. Pobrane 21.11.2026; aplikacja nie pobiera
logotypów ani nie wysyła danych zamówienia podczas ich wyświetlania.

- InPost: https://inpost.pl/themes/custom/inpost/logo.svg — oficjalny serwis InPost.
- ORLEN Paczka: https://www.orlenpaczka.pl/wp-content/themes/orlenpaczka/img/logo.svg
  — oficjalny serwis ORLEN Paczka.
- DHL, DPD, UPS, FedEx: https://github.com/simple-icons/simple-icons/tree/develop/icons
  (odpowiednio dhl.svg, dpd.svg, ups.svg, fedex.svg). CC0; pełny tekst w
  ../SIMPLE_ICONS_LICENSE.txt.
- Allegro One używa istniejącego znaku Allegro, opisanego w ../IKONY_MAREK.md.

DHL, DPD, UPS i FedEx mają jednokolorową adaptację w kolorze marki.
Dla InPost, DHL i FedEx zawężono viewBox do widocznych ścieżek, bez zmiany
geometrii, aby znak był czytelny w małym polu. InPost i ORLEN są znakami
ich właścicieli, nie są przedstawiane jako utwory objęte CC0. Wyświetlenie
logo nie oznacza partnerstwa ani możliwości nadawania przesyłek.

Nieznany przewoźnik otrzymuje neutralny symbol paczki. Program nie ustala
przewoźnika na podstawie kraju, klienta lub nazwy produktu.
