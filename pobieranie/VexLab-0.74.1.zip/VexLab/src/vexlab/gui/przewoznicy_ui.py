"""Lokalne znaki przewoźników; rozpoznanie wyłącznie z nazwy dostawy, bez sieci."""

import re
from pathlib import Path

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QLabel

from vexlab.gui.design_system import ikona

ZASOBY = Path(__file__).with_name("zasoby")
MARKI = (
    ("inpost", "InPost"),
    ("dpd", "DPD"),
    ("dhl", "DHL"),
    ("ups", "UPS"),
    ("fedex", "FedEx"),
    ("orlen", "ORLEN Paczka"),
)


def przewoznik(nazwa: str) -> tuple[str, str] | None:
    for key, label in MARKI:
        if re.search(r"\b" + re.escape(key) + r"\b", nazwa, re.IGNORECASE):
            return key, label
    if "allegro one" in nazwa.casefold():
        return "allegro", "Allegro One"
    return None


class LogoPrzewoznika(QLabel):
    def __init__(self) -> None:
        super().__init__()
        self.setFixedSize(68, 28)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet("background:#F5F8FC;border:1px solid #CDD8E3;border-radius:5px;")
        self.ustaw("")

    def ustaw(self, nazwa: str) -> None:
        brand = przewoznik(nazwa)
        self.setVisible(bool(nazwa))
        if brand:
            key, label = brand
            path = ZASOBY / (
                "allegro-wordmark.svg" if key == "allegro" else f"przewoznicy/{key}.svg"
            )
            icon = QIcon(str(path))
            self.setAccessibleName("Przewoźnik: " + label)
            self.setToolTip(label + " · " + nazwa)
        else:
            icon = ikona("produkt", "#52677D")
            self.setAccessibleName("Dostawa — przewoźnik nierozpoznany")
            self.setToolTip(nazwa or "Wybierz zamówienie")
        self.setPixmap(icon.pixmap(QSize(60, 22)))
