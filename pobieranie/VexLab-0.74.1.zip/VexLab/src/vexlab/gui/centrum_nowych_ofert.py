"""Rozszerzenie istniejącej tabeli paczki. Żadne akcje ani ich zakres nie są zastępowane."""

from collections.abc import Callable
from typing import TYPE_CHECKING

from PySide6.QtCore import QEvent, QObject, Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QApplication,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from vexlab.gui.elementy_paneli_ofert import odznaka
from vexlab.gui.kafelek_kpi import KafelekKPI
from vexlab.gui.osadzone_przygotowanie import OsadzonePrzygotowanie
from vexlab.gui.panel_walidacji_oferty import PanelWalidacjiOferty
from vexlab.gui.uklad_nowych_ofert import UkladNowychOfert
from vexlab.gui.walidacja_paczki_ui import OznaczenieOferty, oznacz_oferte
from vexlab.gui.wiersze_nowych_ofert import WierszNowejOferty
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.producenci import ProducentDTO

if TYPE_CHECKING:
    from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
    from vexlab.gui.paczki_ofert import StronaPaczek


class CentrumNowychOfert(QObject):
    def __init__(
        self, page: "StronaPaczek", host: QWidget, layout: QVBoxLayout, preview: QPushButton
    ) -> None:
        super().__init__(page)
        self.page = page
        self.czytaj_kontekst: Callable[
            [], tuple[DialogNowychSzkicow | None, SesjaAllegro | None]
        ] = lambda: (None, None)
        self.czytaj_producentow: Callable[[], tuple[ProducentDTO, ...]] = lambda: ()
        self.stany: tuple[OznaczenieOferty, ...] = ()
        self.filtr = "wszystkie"
        self._signature: tuple[object, ...] = ()
        self._panel_signature: tuple[object, ...] = ()
        self._szeroki: bool | None = None
        self._dark: bool | None = None
        self._aktualizuje_widok = False
        self.podglad = preview
        preview.setText("Podgląd oferty")
        page.przygotuj_allegro.setObjectName("primary")
        page.zapisz_szkice.setObjectName("")
        page.zapisz_szkice.setText("Zapisz szkice lokalnie")
        self.szczegoly_przycisk = QPushButton("Szczegóły")
        self.szczegoly_przycisk.setCheckable(True)
        self.szczegoly_przycisk.setChecked(True)
        kpis = QWidget()
        self.kpi_grid = QGridLayout(kpis)
        self.kpi_grid.setContentsMargins(0, 0, 0, 0)
        self.kpi_grid.setSpacing(10)
        self.kpi: dict[str, KafelekKPI] = {}
        for i, (key, name, icon, color) in enumerate(
            (
                ("wszystkie", "Wszystkie oferty", "Produkty", "#0662BB"),
                ("gotowe", "Gotowe do szkicu", "Zamówienia", "#00824D"),
                ("bledy", "Wymagają poprawy", "Raporty", "#997017"),
                ("nowe", "Nowe produkty Allegro", "Produkty", "#0662BB"),
                ("ean", "Problemy z EAN", "Historia operacji", "#AF2635"),
            )
        ):
            card = KafelekKPI(name, "produkty", "Brak odczytu", symbol=icon, akcent=color)
            card.setFixedHeight(88)
            card.setMinimumWidth(0)
            self.kpi[key] = card
            self.kpi_grid.addWidget(card, 0, i)
        self.kpi_host = kpis
        self.filtry_host = QWidget()
        filters = QHBoxLayout(self.filtry_host)
        filters.setContentsMargins(0, 0, 0, 0)
        filters.setSpacing(6)
        self.chipy: dict[str, QPushButton] = {}
        for key, text in (
            ("wszystkie", "Wszystkie"),
            ("gotowe", "Gotowe"),
            ("gpsr", "GPSR"),
            ("parametry", "Parametry"),
            ("ean", "EAN"),
            ("bledy", "Błędy"),
        ):
            button = QPushButton(text)
            button.setCheckable(True)
            button.setChecked(key == "wszystkie")
            button.setObjectName("chipPaczki")
            button.clicked.connect(lambda _checked=False, key=key: self._filtr(key))
            filters.addWidget(button)
            self.chipy[key] = button
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj tytułu, SKU lub EAN…")
        self.szukaj.setAccessibleName("Filtr widocznych ofert z paczki")
        self.szukaj.textChanged.connect(self.filtruj)
        self.hint = QLabel("")
        self.hint.setWordWrap(True)
        self.hint.setObjectName("opis")
        self.panel = PanelWalidacjiOferty()
        self.panel.podglad.connect(page.szczegoly)
        self.panel.przygotowanie.connect(page.przygotuj_allegro.click)
        self.panel.problem.connect(self.przejdz_do_problemu)
        self.panel.edycja.connect(self.edytuj_wybrana)
        self.panel.historia.connect(self.historia_wybranej)
        self.panel.producent.connect(self.otworz_producenta)
        self.postep = QProgressBar()
        self.postep.setFixedHeight(8)
        self.postep.setTextVisible(False)
        self.postep.setObjectName("postepPrzygotowania")
        self.postep.setAccessibleName("Postęp potwierdzonego przygotowania szkiców Allegro")
        self.podsumowanie = QLabel()
        self.podsumowanie.setWordWrap(True)
        self.podsumowanie.setObjectName("opis")
        self.uklad = UkladNowychOfert(self, host, layout)
        self.split = self.uklad.split
        self.osadzenie = OsadzonePrzygotowanie(self)
        self.szczegoly_przycisk.toggled.connect(self.panel.setVisible)
        table = page.tabela
        table.setColumnCount(10)
        table.setHorizontalHeaderItem(9, QTableWidgetItem("Status"))
        table.horizontalHeader().moveSection(table.horizontalHeader().visualIndex(9), 2)
        table.horizontalHeader().setStretchLastSection(False)
        table.horizontalHeader().setMinimumHeight(40)
        table.setShowGrid(False)
        self.delegat = WierszNowejOferty(table)
        table.setItemDelegateForColumn(2, self.delegat)
        table.setItemDelegateForColumn(9, self.delegat)
        table.currentCellChanged.connect(lambda *_: self.pokaz_panel())
        self.timer = QTimer(self)
        self.timer.setInterval(750)
        self.timer.timeout.connect(self.odswiez)
        self.timer.start()
        page.installEventFilter(self)
        self.panel.installEventFilter(self)
        self.kolumny()
        self.odswiez(wymus=True)

    @property
    def oferty_widoku(self) -> tuple[OfertaPodglad, ...]:
        d = self.osadzenie.dialog
        return d.oferty if d is not None else self.page.oferty

    @property
    def tabela_widoku(self) -> QTableWidget:
        d = self.osadzenie.dialog
        return d.tabela if d is not None else self.page.tabela

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if self._aktualizuje_widok:
            return False
        if event.type() in (QEvent.Type.Show, QEvent.Type.Resize, QEvent.Type.PaletteChange):
            self._aktualizuje_widok = True
            try:
                if obj is self.page:
                    self.rozmiar()
                    self.odswiez(wymus=event.type() == QEvent.Type.Show)
                elif obj is self.panel:
                    self._panel_signature = ()
                    self.pokaz_panel()
            finally:
                self._aktualizuje_widok = False
        if obj is self.page and event.type() == QEvent.Type.PaletteChange:
            QTimer.singleShot(0, self._odswiez_motyw)
        return False

    def _odswiez_motyw(self) -> None:
        if isValid(self.page):
            self.odswiez(wymus=True)

    def kolumny(self) -> None:
        table = self.page.tabela
        for col in (0, 1, 7):
            table.setColumnHidden(col, True)
        for col, width in ((8, 84), (9, 175), (3, 140), (4, 130), (5, 65), (6, 65)):
            table.setColumnWidth(col, width)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        item = table.horizontalHeaderItem(2)
        if item is not None:
            item.setText("Produkt / SKU")
        table.setColumnWidth(2, max(180, table.columnWidth(2)))

    def _kontekst(self) -> tuple["DialogNowychSzkicow | None", SesjaAllegro | None]:
        dialog, session = self.czytaj_kontekst()
        if (
            dialog is None
            or not isValid(dialog)
            or dialog.nieaktualny
            or dialog.sesja is not session
        ):
            return None, session
        return dialog, session

    def odswiez(self, *, wymus: bool = False) -> None:
        if not isValid(self.page):
            return
        if not wymus and not self.page.isVisible():
            return
        d, session = self._kontekst()
        producer = d.producent_lokalny.currentText() if d else ""
        signature = (
            QApplication.palette().color(QApplication.palette().ColorRole.Window).rgb(),
            id(self.oferty_widoku),
            id(d),
            id(session),
            id(d.oferty) if d else 0,
            id(d.plany) if d else 0,
            id(d.wyniki) if d else 0,
            d.trwa if d else False,
            producer,
            d._blad_operacji if d else "",
        )
        if not wymus and signature == self._signature:
            self.pokaz_panel()
            return
        self._signature = signature
        self.stany = tuple(self._stan_wiersza(i, d) for i in range(len(self.oferty_widoku)))
        if self.osadzenie.dialog is None:
            for i, state in enumerate(self.stany):
                item = QTableWidgetItem(state.status)
                item.setData(Qt.ItemDataRole.UserRole, state.ton)
                item.setToolTip(
                    "\n".join(state.problemy)
                    or state.status + ". Gotowość dotyczy szkicu, nie publikacji."
                )
                self.page.tabela.setItem(i, 9, item)
        count = len(self.stany)
        ready = sum(s.gotowa for s in self.stany)
        for key, button in self.chipy.items():
            value = count if key == "wszystkie" else sum(key in s.grupy for s in self.stany)
            label = {
                "wszystkie": "Wszystkie",
                "gotowe": "Gotowe",
                "gpsr": "GPSR",
                "parametry": "Parametry",
                "ean": "EAN",
                "bledy": "Błędy",
            }[key]
            button.setText(f"{label} ({value})")
        native = self.osadzenie.dialog
        self.uklad.wczytywanie_wlaczone(native is None or not native.trwa)
        for key, card in self.kpi.items():
            value = (
                count
                if key == "wszystkie"
                else ready
                if key == "gotowe"
                else sum(key in s.grupy for s in self.stany)
            )
            card.liczba.setText(str(value))
            card.podpis.setText(
                "Zgłoszenie nowego produktu"
                if key == "nowe" and value
                else "Cała paczka"
                if key == "wszystkie"
                else "Z istniejącego sprawdzenia"
                if any(s.plan is not None for s in self.stany)
                else "Brak sprawdzenia Allegro"
            )
        instruction = (
            "Uzupełnij ustawienia w oknie przygotowania i kliknij „Sprawdź paczkę”. "
            if not any(s.plan is not None for s in self.stany)
            else "Popraw wskazane problemy w przygotowaniu; zapis do Allegro wymaga potwierdzenia. "
        )
        self.hint.setText(
            instruction + "Filtry zmieniają tylko widok. Zapis szkiców i przygotowanie "
            "Allegro obejmują całą paczkę. "
            "Niesprawdzone dane nie są oznaczane jako poprawne."
        )
        self.postep.setRange(0, max(1, count))
        self.postep.setValue(ready)
        self.postep.setVisible(native is None or not native.trwa)
        self.postep.setFormat(
            f"{ready} / {count} gotowych do szkicu · {round(100 * ready / count) if count else 0}%"
        )
        self.uklad.postep_tytul.setText(
            "Przygotowanie ofert · operacja w toku"
            if native and native.trwa
            else "Postęp przygotowania ofert"
        )
        self.uklad.licznik.setText(f"{ready} / {count} gotowych")
        self.uklad.procent.setText(f"{round(100 * ready / count) if count else 0}%")
        for key, badge in self.uklad.odznaki.items():
            value = ready if key == "gotowe" else sum(key in item.grupy for item in self.stany)
            suffix = {"gotowe": "gotowe", "gpsr": "GPSR", "parametry": "parametrów", "ean": "EAN"}[
                key
            ]
            odznaka(
                badge,
                f"{value} {suffix}",
                "zielony" if key == "gotowe" else "czerwony" if key == "ean" else "zloty",
            )
        self.osadzenie.odswiez_wyglad()
        self.podsumowanie.setText(
            f"GPSR: {sum('gpsr' in s.grupy for s in self.stany)} · "
            f"Parametry: {sum('parametry' in s.grupy for s in self.stany)} · "
            f"EAN: {sum('ean' in s.grupy for s in self.stany)}"
        )
        if native is not None:
            native.info.setVisible(bool(native.trwa or native._blad_operacji or native.nieaktualny))
        self.page.przygotuj_allegro.setText(
            "Wróć do przygotowania szkiców…" if d is not None else "Przygotuj szkice do wysyłki…"
        )
        self.page.przygotuj_allegro.setToolTip(
            f"Otwiera istniejące przygotowanie dla wszystkich {count} ofert. "
            "Nie wysyła i nie publikuje automatycznie; zakres wybierzesz w przygotowaniu."
        )
        self.panel.przygotuj.setVisible(
            self.page.allegro_dostepne and self.osadzenie.dialog is None
        )
        self.panel.przygotuj.setEnabled(self.page.przygotuj_allegro.isEnabled())
        self.filtruj()
        self._panel_signature = ()
        self.pokaz_panel()
        self.tabela_widoku.viewport().update()

    def _stan_wiersza(self, i: int, d: "DialogNowychSzkicow | None") -> OznaczenieOferty:
        offer = self.oferty_widoku[i]
        match = bool(d and len(d.oferty) == len(self.oferty_widoku) and d.oferty[i] == offer)
        plan = (
            d.plany[i] if match and d and i < len(d.plany) and d.plany[i].oferta == offer else None
        )
        result = d.wyniki[i] if match and d and i < len(d.wyniki) else None
        return oznacz_oferte(
            offer,
            plan,
            result,
            mozna_utworzyc=bool(match and d and d._mozna_wyslac(i)),
            trwa=bool(match and d and d.trwa),
            producent=d.producent_lokalny.currentText() if match and d else "",
            producent_wymagany=bool(match and d and d.katalog_uzytkownika is not None),
            blad_operacji=d._blad_operacji if match and d else "",
            zmieniona=bool(d and len(d.oferty) == len(self.oferty_widoku) and not match),
        )

    def odznaka_wiersza(self, row: int) -> tuple[str, str]:
        dialog, _ = self._kontekst()
        state = self._stan_wiersza(row, dialog)
        return state.status, state.ton

    def pasuje_do_filtrow(self, i: int) -> bool:
        """Ten sam filtr przy każdym odrysowaniu tabeli, także przed aktualizacją KPI."""
        if not 0 <= i < len(self.oferty_widoku):
            return False
        d, _ = self._kontekst()
        state = self._stan_wiersza(i, d)
        offer = self.oferty_widoku[i]
        search = self.szukaj.text().strip().casefold()
        return (self.filtr == "wszystkie" or self.filtr in state.grupy) and search in (
            offer.tytul + " " + offer.sku + " " + offer.ean
        ).casefold()

    def _filtr(self, key: str) -> None:
        self.filtr = key
        for name, button in self.chipy.items():
            button.setChecked(name == key)
        self.filtruj()

    def filtruj(self, *_: object) -> None:
        native = self.osadzenie.dialog
        if native is not None:
            native._filtruj()
            self.pokaz_panel()
            return
        if len(self.stany) != len(self.oferty_widoku):
            self.odswiez(wymus=True)
            return
        table = self.tabela_widoku
        for i in range(len(self.oferty_widoku)):
            table.setRowHidden(i, not self.pasuje_do_filtrow(i))
        row = table.currentRow()
        if row >= 0 and table.isRowHidden(row):
            table.clearSelection()
            table.setCurrentCell(-1, -1)
        self.pokaz_panel()

    def pokaz_panel(self, *_: object) -> None:
        row = self.tabela_widoku.currentRow()
        self.podglad.setEnabled(
            0 <= row < len(self.stany) and not self.tabela_widoku.isRowHidden(row)
        )
        if not 0 <= row < len(self.stany) or self.tabela_widoku.isRowHidden(row):
            if self._panel_signature:
                self.panel.wyczysc()
                self._panel_signature = ()
            return
        offer, state = self.oferty_widoku[row], self.stany[row]
        url = next(iter(offer.zdjecia), "") or next(
            (e.adres for section in offer.sekcje for e in section if e.typ == "obraz"), ""
        )
        native = self.osadzenie.dialog
        images = native.obrazy if native is not None else self.page.obrazy_tabeli
        data = images.cache.get(url, b"")
        url_producenta = self.adres_producenta()
        signature = (row, id(state), id(data), self.panel.width(), url_producenta)
        if signature != self._panel_signature:
            self._panel_signature = signature
            ident = native.wyniki[row].ident if native and row < len(native.wyniki) else ""
            self.panel.pokaz(offer, state, data, ident=ident)
            old = native._odrzucenia.get(row) if native else None
            now = native.wyniki[row] if native and row < len(native.wyniki) else None
            self.panel.ustaw_akcje(
                bool(
                    native
                    and not native.trwa
                    and not native.nieaktualny
                    and native._edytowalny(row)
                ),
                bool(old and now and old != now),
                bool(url_producenta),
            )

    def edytuj_wybrana(self) -> None:
        d = self.osadzenie.dialog
        row = self.tabela_widoku.currentRow()
        if (
            d is None
            or not 0 <= row < len(d.oferty)
            or d.trwa
            or d.nieaktualny
            or not d._edytowalny(row)
        ):
            return
        d.tabela.clearSelection()
        d.tabela.selectRow(row)
        d.masowa.click()

    def historia_wybranej(self) -> None:
        d = self.osadzenie.dialog
        row = self.tabela_widoku.currentRow()
        if d is None or not 0 <= row < len(d.wyniki):
            return
        old, now = d._odrzucenia.get(row), d.wyniki[row]
        if old is None or old == now:
            return
        self.panel.pokaz_historie(
            f"Historia bieżącej sesji · {now.sku}\n\n"
            f"Zapamiętany wcześniejszy wynik: {old.stan}\n{old.komunikat}\n\n"
            f"Aktualny wynik: {now.stan}\n{now.komunikat}\n\n"
            "Dostępne są wyniki tej sesji, nie pełna historia produktu."
        )

    def adres_producenta(self) -> str:
        d = self.osadzenie.dialog
        if d is None:
            return ""
        name = d.producent_lokalny.currentText().strip().casefold()
        matches = [
            p for p in self.czytaj_producentow() if p.aktywny and p.nazwa.strip().casefold() == name
        ]
        if len(matches) != 1:
            return ""
        url = QUrl(matches[0].strona_www)
        if (
            not url.isValid()
            or url.scheme() not in {"http", "https"}
            or not url.host()
            or url.userInfo()
        ):
            return ""
        return url.toString()

    def otworz_producenta(self) -> None:
        url = self.adres_producenta()
        if url:
            QDesktopServices.openUrl(QUrl(url))

    def przejdz_do_problemu(self, key: str) -> None:
        row = self.tabela_widoku.currentRow()
        if not 0 <= row < len(self.stany):
            return
        if key == "zrodlo":
            self.page.szczegoly()
            return
        d, _ = self._kontekst()
        if d is None:
            # Ten sam przycisk i ten sam sygnał; bez nowego zakresu i nowego procesu.
            self.page.przygotuj_allegro.click()
            d, _ = self._kontekst()
        if d is None or row >= len(d.oferty) or d.oferty[row] != self.oferty_widoku[row]:
            return
        if d.trwa or d.nieaktualny:
            return
        self.osadzenie.ustawienia.setChecked(True)
        d.show()
        d.raise_()
        d.activateWindow()
        d.filtr.setCurrentIndex(0)
        d.tabela.selectRow(row)
        d.tabela.setCurrentCell(row, 4)
        targets = {
            "gpsr": d.sprzedaz_przycisk,
            "parametry": d.uzupelnij_przycisk,
            "ean": d.produkt_przycisk,
            "produkt": d.produkt_przycisk,
            "kategoria": d.produkt_przycisk,
            "vat": d.vat_przycisk,
            "producent": d.producent_lokalny,
        }
        if key in targets:
            targets[key].setFocus()
        else:
            d.pomoc_wysylki.tresc.setFocus()

    def rozmiar(self) -> None:
        self.uklad.rozmiar_stopki(self.page.width())
        wide = self.page.width() >= 1250
        if wide != self._szeroki:
            self._szeroki = wide
            self.szczegoly_przycisk.setChecked(wide)
            self.split.setSizes([270, max(400, self.page.width() - 600), 300])
        dark = self.page.palette().color(self.page.palette().ColorRole.Window).lightness() < 128
        if dark != self._dark:
            self._dark = dark
            border = "#203B51" if dark else "#CDDBEE"
            self.page.setStyleSheet(f"""
                QFrame#panelWalidacjiPaczki, QFrame#lewyPanelPrzygotowania,
                QFrame#stopkaPrzygotowania {{border:1px solid {border};border-radius:7px;
                    background:{"#0D1D2B" if dark else "#F3F7FC"};}}
                QWidget#trescWalidacjiOferty, QWidget#trescUstawienOfert {{
                    background:transparent;}}
                QFrame#panelWalidacjiPaczki {{
                    background:{"#172A3B" if dark else "#EDF3FA"};}}
                QFrame#lewyPanelPrzygotowania QComboBox:enabled:hover,
                QFrame#lewyPanelPrzygotowania QSpinBox:enabled:hover,
                QFrame#lewyPanelPrzygotowania QComboBox:focus,
                QFrame#lewyPanelPrzygotowania QSpinBox:focus {{
                    background:{"#173C5A" if dark else "#DEEDFB"};border-color:#279BEE;}}
                QFrame#sekcjaUstawienOfert {{border:1px solid {border};border-radius:8px;
                    background:{"#0D1D2B" if dark else "#FFFFFF"};}}
                QLabel#numerSekcjiOfert {{background:{"#153854" if dark else "#DFEDFA"};
                    color:{"#78C5FF" if dark else "#1669A7"};border:0;border-radius:5px;
                    font-size:10px;font-weight:600;}}
                QLabel#zapisLokalnyOfert {{font-size:11px;
                    color:{"#65C7A2" if dark else "#187550"};}}
                QLabel#opisZapisuOfert {{font-size:10px;
                    color:{"#9CAFC2" if dark else "#52677D"};}}
                QLabel[etykietaPolaOfert="true"] {{padding-top:4px;}}
                QFrame#wierszUstawieniaOfert {{border:1px solid {border};border-radius:5px;
                    background:{"#102639" if dark else "#EDF4FD"};}}
                QPushButton#akcjaUstawieniaOfert {{border:0;background:transparent;text-align:left;
                    padding:3px 5px;font-size:11px;}}
                QFrame#wierszUstawieniaOfert[dostepny="true"]:hover {{
                    background:{"#173C5A" if dark else "#DEEDFB"};border-color:#279BEE;}}
                QPushButton#akcjaUstawieniaOfert:enabled:hover,
                QPushButton#akcjaUstawieniaOfert:enabled:pressed,
                QPushButton#akcjaUstawieniaOfert:focus {{
                    background:{"#173C5A" if dark else "#DEEDFB"};border-radius:4px;}}
                QPushButton#masowaAkcjaOfert:enabled:hover,
                QPushButton#masowaAkcjaOfert:enabled:pressed,
                QPushButton#masowaAkcjaOfert:focus {{
                    background:{"#173C5A" if dark else "#DEEDFB"};border:1px solid #279BEE;}}
                QFrame#separatorPaneluOfert {{color:{border};max-height:1px;}}
                QFrame#lewyPanelPrzygotowania QLabel {{font-size:11px;}}
                QFrame#lewyPanelPrzygotowania QLabel#tytulSekcjiAllegro {{
                    font-size:12px;font-weight:600;}}
                QFrame#lewyPanelPrzygotowania QComboBox,
                QFrame#lewyPanelPrzygotowania QSpinBox {{
                    font-size:11px;min-height:0;padding:3px 8px;}}
                QPushButton#masowaAkcjaOfert {{text-align:left;padding:3px 8px;font-size:11px;}}
                QLabel#zdjeciePaneluOfert {{border:1px solid {border};border-radius:6px;
                    background:{"#0B1824" if dark else "#FFFFFF"};}}
                QLabel#liczbaDashboardu {{font-size:22px;font-weight:600;}}
                QLabel#podpisDashboardu {{font-size:11px;}}
                QPushButton#chipPaczki {{border-radius:5px;padding:5px 8px;}}
                QProgressBar#postepPrzygotowania::chunk {{background:#009AE8;border-radius:4px;}}
            """)
            self._panel_signature = ()
            self.pokaz_panel()
