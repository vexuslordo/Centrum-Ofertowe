"""Rozpoznanie dostawy i brak starego logo po zmianie zaznaczenia."""

import pytest
from PySide6.QtSvg import QSvgRenderer

from vexlab.gui.przewoznicy_ui import ZASOBY, LogoPrzewoznika, przewoznik


@pytest.mark.parametrize(
    ("delivery", "key"),
    [
        ("Allegro Paczkomaty InPost", "inpost"),
        ("DPD Pickup", "dpd"),
        ("Kurier DHL", "dhl"),
        ("UPS Standard", "ups"),
        ("FedEx", "fedex"),
        ("Automat ORLEN Paczka", "orlen"),
        ("Allegro One Box", "allegro"),
    ],
)
def test_rozpoznana_nazwa_ma_poprawny_lokalny_znak(qapp, delivery, key):
    assert przewoznik(delivery)[0] == key
    file = ZASOBY / ("allegro-wordmark.svg" if key == "allegro" else f"przewoznicy/{key}.svg")
    assert QSvgRenderer(str(file)).isValid()


def test_nieznany_przewoznik_i_pusty_panel_nie_zachowuja_poprzedniego_logo(qtbot):
    logo = LogoPrzewoznika()
    qtbot.addWidget(logo)
    logo.ustaw("Allegro Paczkomaty InPost")
    assert "InPost" in logo.accessibleName()
    logo.ustaw("Inny przewoźnik z Czech")
    assert przewoznik("Inny przewoźnik z Czech") is None
    assert "nierozpoznany" in logo.accessibleName()
    logo.ustaw("")
    assert logo.isHidden()
