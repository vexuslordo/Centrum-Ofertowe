"""Wspólne powierzchnie, lokalna typografia i dyskretne interakcje warstwy GUI."""

from pathlib import Path

from PySide6.QtCore import (
    QEasingCurve,
    QEvent,
    QModelIndex,
    QObject,
    QPersistentModelIndex,
    QPropertyAnimation,
    QRectF,
    Qt,
    QVariantAnimation,
)
from PySide6.QtGui import QColor, QFont, QFontDatabase, QPainter, QPainterPath, QPaintEvent, QPixmap
from PySide6.QtWidgets import (
    QAbstractButton,
    QAbstractSpinBox,
    QApplication,
    QGraphicsOpacityEffect,
    QLabel,
    QLineEdit,
    QMenu,
    QPlainTextEdit,
    QStyledItemDelegate,
    QStyleOptionViewItem,
    QTableView,
    QWidget,
)

BACKGROUND = "#070B14"
SIDEBAR = "#0C1220"
SURFACE = "#121A2B"
HOVER = "#172235"
ACTIVE = "#1D2A40"
PRIMARY = "#3B82F6"
PRIMARY_HOVER = "#60A5FA"
CYAN = "#06B6D4"
GREEN = "#10B981"
AMBER = "#F59E0B"
RED = "#EF4444"
FONT = "Geist"
MONO = "JetBrains Mono"


def font_danych(font: QFont) -> QFont:
    result = QFont(font)
    result.setFamily(MONO)
    return result


def obraz_inspektora(
    pixmap: QPixmap,
    width: int,
    height: int,
    aspect: Qt.AspectRatioMode = Qt.AspectRatioMode.KeepAspectRatio,
    transform: Qt.TransformationMode = Qt.TransformationMode.SmoothTransformation,
) -> QPixmap:
    scaled = pixmap.scaled(width, height, aspect, transform)
    if scaled.isNull():
        return scaled
    result = QPixmap(scaled.size())
    result.setDevicePixelRatio(scaled.devicePixelRatio())
    result.fill(Qt.GlobalColor.transparent)
    painter = QPainter(result)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    path = QPainterPath()
    size = scaled.deviceIndependentSize()
    path.addRoundedRect(QRectF(0, 0, size.width(), size.height()), 8, 8)
    painter.setClipPath(path)
    painter.drawPixmap(0, 0, scaled)
    painter.end()
    return result


def techniczna_kolumna(nazwa: str) -> bool:
    text = nazwa.casefold()
    if any(word in text for word in ("produkt", "tytuł", "nazwa", "opis", "status", "stan oferty")):
        return False
    return text == "id" or any(
        word in text
        for word in (
            "sku",
            "ean",
            " id",
            "id ",
            "cena",
            "kwota",
            "ilość",
            "numer",
            "kod",
            "netto",
            "brutto",
            "marża",
            "obrót",
            "stan magazynowy",
            "sprzedano",
            "liczba",
            "wyświetlenia",
        )
    )


class DelegatDanych(QStyledItemDelegate):
    """Zmienia wyłącznie font opcji malowania; model i edytory pozostają oryginalne."""

    def initStyleOption(
        self, option: QStyleOptionViewItem, index: QModelIndex | QPersistentModelIndex
    ) -> None:
        super().initStyleOption(option, index)
        model = index.model()
        if model is not None:
            header = str(model.headerData(index.column(), Qt.Orientation.Horizontal) or "")
            if techniczna_kolumna(header):
                option.font = font_danych(option.font)


class PoswiataPrzycisku(QWidget):
    def __init__(self, parent: QAbstractButton) -> None:
        super().__init__(parent)
        self.setObjectName("poswiataPremium")
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.poziom = 0.0
        self.animacja = QVariantAnimation(self)
        self.animacja.setDuration(180)
        self.animacja.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.animacja.valueChanged.connect(self._wartosc)
        self.resize(parent.size())
        self.show()

    def _wartosc(self, value: object) -> None:
        self.poziom = float(str(value))
        self.update()

    def ustaw(self, aktywna: bool) -> None:
        self.animacja.stop()
        self.animacja.setStartValue(self.poziom)
        self.animacja.setEndValue(1.0 if aktywna else 0.0)
        self.animacja.start()
        self.raise_()

    def paintEvent(self, event: QPaintEvent) -> None:
        if self.poziom <= 0:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        color = QColor(PRIMARY)
        color.setAlpha(round(18 * self.poziom))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(color)
        painter.drawRoundedRect(self.rect().adjusted(1, 1, -1, -1), 6, 6)


def oznacz(widget: QWidget, nazwa: str, wartosc: str | bool) -> None:
    if widget.property(nazwa) == wartosc:
        return
    widget.setProperty(nazwa, wartosc)
    style = widget.style()
    style.unpolish(widget)
    style.polish(widget)


class WygladPremium(QObject):
    def __init__(self, app: QApplication) -> None:
        super().__init__(app)
        self.app = app
        # Zachowujemy oba wrappery Qt przez cały czas życia filtra.
        self.style_hints = app.styleHints()
        self.accessibility = self.style_hints.accessibility()

    def _animacje(self) -> bool:
        return not self.app.property("ograniczAnimacje") and (
            self.accessibility.motionPreference() != Qt.MotionPreference.ReducedMotion
        )

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        kind = event.type()
        if kind in (QEvent.Type.Polish, QEvent.Type.Show):
            if isinstance(obj, QTableView):
                obj.setShowGrid(False)
                obj.setMouseTracking(True)
                if type(obj.itemDelegate()) is QStyledItemDelegate:
                    obj.setItemDelegate(DelegatDanych(obj))
            elif isinstance(obj, QAbstractButton):
                if (
                    obj.text()
                    .casefold()
                    .startswith(("historia", "otwórz producenta", "otwórz stronę"))
                    and obj.property("hierarchia") != "ghost"
                ):
                    oznacz(obj, "hierarchia", "ghost")
            elif isinstance(obj, QAbstractSpinBox):
                oznacz(obj, "daneTechniczne", True)
            elif isinstance(obj, QLabel | QLineEdit | QPlainTextEdit):
                name = obj.objectName().casefold()
                title = obj.accessibleName().casefold()
                numeric = name in {
                    "liczba",
                    "kpiliczba",
                    "liczbadashboardu",
                    "licznikallegro",
                    "wartoscai",
                }
                numeric = numeric or (
                    isinstance(obj, QPlainTextEdit)
                    and title.startswith(("log", "dziennik", "pełny powód", "powody i"))
                )
                numeric = numeric or bool(
                    title and not title.startswith("weryfikacja") and techniczna_kolumna(title)
                )
                if numeric and not obj.property("daneTechniczne"):
                    oznacz(obj, "daneTechniczne", True)
        if isinstance(obj, QMenu) and kind == QEvent.Type.Show and self._animacje():
            if obj.graphicsEffect() is None:
                menu_effect = QGraphicsOpacityEffect(obj)
                menu_effect.setObjectName("wejscieMenuPremium")
                obj.setGraphicsEffect(menu_effect)
                created = QPropertyAnimation(menu_effect, b"opacity", menu_effect)
                created.setObjectName("animacjaMenuPremium")
                created.setDuration(180)
                created.setStartValue(0.94)
                created.setEndValue(1.0)
                animation: QPropertyAnimation | None = created
            else:
                animation = obj.findChild(QPropertyAnimation, "animacjaMenuPremium")
            if animation is not None:
                animation.start()
        if isinstance(obj, QAbstractButton):
            if kind in (QEvent.Type.Enter, QEvent.Type.FocusIn) and obj.isEnabled():
                if self._animacje():
                    effect = obj.findChild(PoswiataPrzycisku, "poswiataPremium")
                    if effect is None:
                        effect = PoswiataPrzycisku(obj)
                    effect.ustaw(True)
            elif kind in (QEvent.Type.Leave, QEvent.Type.FocusOut, QEvent.Type.EnabledChange):
                effect = obj.findChild(PoswiataPrzycisku, "poswiataPremium")
                if effect is not None:
                    effect.ustaw(obj.isEnabled() and (obj.underMouse() or obj.hasFocus()))
            elif kind == QEvent.Type.Resize:
                effect = obj.findChild(PoswiataPrzycisku, "poswiataPremium")
                if effect is not None:
                    effect.resize(obj.size())
        return False


def przygotuj_typografie(app: QApplication) -> None:
    if app.property("fontyPremium"):
        return
    directory = Path(__file__).with_name("zasoby") / "fonty"
    for file in sorted(directory.rglob("*.ttf")):
        if QFontDatabase.addApplicationFont(str(file)) < 0:
            raise RuntimeError("Nie można wczytać lokalnego fontu: " + file.name)
    app.setFont(QFont(FONT, 10))
    events = WygladPremium(app)
    events.setObjectName("wygladPremium")
    app.installEventFilter(events)
    app.setProperty("fontyPremium", True)
