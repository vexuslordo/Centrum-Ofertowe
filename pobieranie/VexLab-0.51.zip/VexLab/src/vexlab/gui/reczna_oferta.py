"""Ręczne tworzenie treści Oferty z tym samym lokalnym zapisem co paczki."""

from dataclasses import replace
from pathlib import Path
from typing import cast

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QListWidgetItem,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.edytor_opisu import EdytorOpisu
from vexlab.gui.podglad_oferty import ObrazyOferty
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.nowe_szkice_allegro import adres_zdjecia
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.reczna_oferta import przygotuj_reczna
from vexlab.przypadki_uzycia.szkice import SzkiceOfert
from vexlab.przypadki_uzycia.zdjecia_ofert import PlikiZdjecOfert, lokalne_zdjecie


class RecznaOferta(QDialog):
    zmieniono = Signal()
    wysylka_zadana = Signal(object)

    def __init__(
        self,
        parent: QWidget,
        szkice: SzkiceOfert,
        uruchom: Uruchom,
        zdjecia: PodgladZdjec | None = None,
        allegro: bool = True,
        pliki_zdjec: PlikiZdjecOfert | None = None,
    ) -> None:
        super().__init__(parent)
        self.pliki_zdjec = pliki_zdjec
        self.lokalne: tuple[str, ...] = ()
        self.szkice, self.uruchom = szkice, uruchom
        self.trwa = False
        self.setWindowTitle("Utwórz ofertę ręcznie")
        ekran = self.screen().availableGeometry()
        width, height = max(320, ekran.width() - 48), max(320, ekran.height() - 72)
        self.setMinimumSize(min(800, width), min(560, height))
        self.resize(min(1160, width), min(800, height))
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        title = etykieta("Nowa oferta")
        title.setObjectName("tytulStronyAllegro")
        layout.addWidget(title)
        layout.addWidget(
            etykieta(
                "Wpisz dane i przygotuj opis. Zapiszesz szkic lokalnie, "
                "a ustawienia Allegro uzupełnisz w kolejnym kroku."
            )
        )
        tabs = QTabWidget()
        layout.addWidget(tabs, 1)
        page = QWidget()
        form = QFormLayout(page)
        self.sku, self.tytul, self.ean, self.cena = (QLineEdit() for _ in range(4))
        self.sku.setMaxLength(100)
        self.tytul.setMaxLength(75)
        self.ean.setMaxLength(13)
        self.cena.setMaxLength(30)
        for label, field in (
            ("SKU *", self.sku),
            ("Tytuł *", self.tytul),
            ("EAN (opcjonalnie)", self.ean),
            ("Cena (opcjonalnie)", self.cena),
        ):
            field.setAccessibleName(label)
            form.addRow(label, field)
        form.addRow(
            etykieta("Walutę ceny, ilość, kategorię i parametry wskażesz w przygotowaniu Allegro.")
        )
        self.galeria = QPlainTextEdit()
        self.galeria.setAccessibleName("Adresy zdjęć oferty")
        self.galeria.setMaximumHeight(95)
        self.galeria.setPlaceholderText(
            "Adresy HTTPS zdjęć — każdy w osobnym wierszu, maks. 16. Pierwsze zdjęcie jest główne."
        )
        self.dysk = QPushButton("Dodaj zdjęcia z dysku…")
        self.dysk.setEnabled(pliki_zdjec is not None)
        self.dysk.clicked.connect(self.dodaj_pliki)
        form.addRow("Zdjęcia z dysku", self.dysk)
        self.lista_plikow = etykieta("Dodano z dysku: 0")
        form.addRow(self.lista_plikow)
        self.wyczysc_pliki = QPushButton("Usuń zdjęcia z tej oferty")
        self.wyczysc_pliki.clicked.connect(self.usun_pliki)
        form.addRow(self.wyczysc_pliki)
        form.addRow("Zdjęcia HTTPS", self.galeria)
        self.miniatury = ObrazyOferty(self, zdjecia, uruchom, miniatury=True)
        self.finished.connect(lambda _: self.miniatury.zamknij())
        self.pola_miniatur = QWidget()
        self.miniatury_layout = QHBoxLayout(self.pola_miniatur)
        self.miniatury_layout.setContentsMargins(4, 4, 4, 4)
        self.pasek_zdjec = QScrollArea()
        self.pasek_zdjec.setWidgetResizable(True)
        self.pasek_zdjec.setWidget(self.pola_miniatur)
        self.pasek_zdjec.setMinimumHeight(96)
        self.pasek_zdjec.setMaximumHeight(112)
        form.addRow("Galeria", self.pasek_zdjec)
        dane_scroll = QScrollArea()
        dane_scroll.setWidgetResizable(True)
        dane_scroll.setWidget(page)
        tabs.addTab(dane_scroll, "1. Dane i zdjęcia")
        empty = OfertaPodglad(1, "", "", "", "", "", "", (), (), ())
        self.opis = EdytorOpisu(empty, self, zdjecia, uruchom, podpis_zdjec="Zdjęcia oferty")
        tabs.addTab(self.opis, "2. Opis i podgląd")
        self.finished.connect(lambda _: self.opis.obrazy.zamknij())
        for field in (self.sku, self.tytul, self.ean, self.cena):
            field.textChanged.connect(self._dane_podgladu)
        self.galeria.textChanged.connect(self._galeria)
        self.info = etykieta(
            "Zapis lokalny nie tworzy Produktu w katalogu i nie uruchamia sprzedaży."
        )
        layout.addWidget(self.info)
        buttons = QHBoxLayout()
        self.zapis = QPushButton("Zapisz szkic lokalnie")
        self.przygotuj = QPushButton("Zapisz i przygotuj Allegro…")
        self.przygotuj.setObjectName("primary")
        self.przygotuj.setVisible(allegro)
        self.zamknij = QPushButton("Zamknij")
        buttons.addStretch()
        for b in (self.zapis, self.przygotuj, self.zamknij):
            buttons.addWidget(b)
        layout.addLayout(buttons)
        self.zapis.clicked.connect(lambda: self.zapisz(False))
        self.przygotuj.clicked.connect(lambda: self.zapisz(True))
        self.zamknij.clicked.connect(self.reject)

    def _dane_podgladu(self) -> None:
        self.opis.tytul = self.tytul.text()
        self.opis.oferta = replace(
            self.opis.oferta,
            sku=self.sku.text(),
            tytul=self.tytul.text(),
            ean=self.ean.text(),
            cena=self.cena.text(),
        )

    def usun_pliki(self) -> None:
        self.lokalne = ()
        self.lista_plikow.setText("Dodano z dysku: 0")
        self._galeria()

    def dodaj_pliki(self) -> None:
        if self.trwa or self.pliki_zdjec is None:
            return
        files, _ = QFileDialog.getOpenFileNames(
            self, "Dodaj zdjęcia oferty", "", "Zdjęcia (*.jpg *.jpeg *.png *.webp)"
        )
        if not files:
            return
        if len(self._adresy()) + len(files) > 16:
            self.info.setText("W ofercie może być maksymalnie 16 zdjęć.")
            return
        store = self.pliki_zdjec
        self.trwa = True
        self.setEnabled(False)
        self.info.setText("Przygotowanie kopii zdjęć…")

        def ok(w: object) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.lokalne = tuple(dict.fromkeys((*self.lokalne, *cast(tuple[str, ...], w))))
            self.lista_plikow.setText(f"Dodano z dysku: {len(self.lokalne)}")
            self._galeria()
            self.info.setText("Zdjęcia zachowane w danych użytkownika. Oryginały możesz przenieść.")

        def error(k: str, text: str) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.info.setText(text)

        self.uruchom(lambda: store.importuj(tuple(Path(f) for f in files)), ok, error)

    def _adresy(self) -> tuple[str, ...]:
        return self.lokalne + tuple(
            line.strip() for line in self.galeria.toPlainText().splitlines() if line.strip()
        )

    def _galeria(self) -> None:
        urls = tuple(
            dict.fromkeys(u for u in self._adresy() if adres_zdjecia(u) or lokalne_zdjecie(u))
        )[:16]
        self.opis.oferta = replace(self.opis.oferta, zdjecia=urls)
        self.opis.galeria.clear()
        while self.miniatury_layout.count():
            layout_item = self.miniatury_layout.takeAt(0)
            widget = layout_item.widget() if layout_item is not None else None
            if widget is not None:
                widget.deleteLater()
        for i, url in enumerate(urls, 1):
            item = QListWidgetItem(f"Zdjęcie {i} • {url}")
            item.setData(Qt.ItemDataRole.UserRole, url)
            self.opis.galeria.addItem(item)
            mini = self.miniatury.obraz(url)
            mini.setToolTip("Zdjęcie główne" if i == 1 else f"Zdjęcie {i}")
            self.miniatury_layout.addWidget(mini)
        self.miniatury_layout.addStretch()

    def zapisz(self, allegro: bool) -> None:
        if self.trwa:
            return
        try:
            oferta = przygotuj_reczna(
                self.sku.text(),
                self.tytul.text(),
                self.ean.text(),
                self.cena.text(),
                self.opis.opis(),
                self._adresy(),
                self.opis.wynik_sekcji(),
            )
            plan = self.szkice.zaplanuj((oferta,), "Utworzono ręcznie")
            if plan.bledy:
                raise ValueError("; ".join(plan.bledy))
        except ValueError as exc:
            self.info.setText(str(exc))
            return
        self.trwa = True
        self.setEnabled(False)
        self.info.setText("Zapisywanie szkicu…")

        def ok(w: object) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.info.setText("Szkic zapisany lokalnie. Znajdziesz go w zakładce Szkice.")
            self.zmieniono.emit()
            self.accept()
            if allegro:
                self.wysylka_zadana.emit((oferta,))

        def blad(kod: str, text: str) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.info.setText(text)

        self.uruchom(lambda: self.szkice.zapisz(plan), ok, blad)

    def reject(self) -> None:
        if not self.trwa:
            super().reject()
