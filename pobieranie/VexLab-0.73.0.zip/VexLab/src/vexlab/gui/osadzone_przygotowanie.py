"""Umieszcza istniejące kontrolki Allegro w panelach jednej zakładki."""

from typing import TYPE_CHECKING, cast

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QBoxLayout,
    QDialogButtonBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.uklad_nowych_ofert import sekcja
from vexlab.gui.wiersze_nowych_ofert import WierszNowejOferty
from vexlab.gui.zaznaczanie_przygotowania import ZaznaczaniePrzygotowania

if TYPE_CHECKING:
    from vexlab.gui.centrum_nowych_ofert import CentrumNowychOfert
    from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow


class OsadzonePrzygotowanie:
    def __init__(self, centrum: "CentrumNowychOfert") -> None:
        self.centrum = centrum
        self.dialog: DialogNowychSzkicow | None = None
        self.przeniesione: list[QWidget] = []
        self.wybor: ZaznaczaniePrzygotowania | None = None
        self.ustawienia = QToolButton()
        self.ustawienia.setText("Ustawienia paczki")
        self.ustawienia.setCheckable(True)
        self.ustawienia.setChecked(True)
        self.ustawienia.toggled.connect(centrum.uklad.lewy.setVisible)
        self.ustawienia.setParent(centrum.page)
        self.ustawienia.hide()
        action = centrum.uklad.menu.addAction("Panel ustawień")
        action.setCheckable(True)
        action.setChecked(True)
        action.toggled.connect(self.ustawienia.setChecked)
        self.ustawienia.toggled.connect(action.setChecked)

    def _przenies(self, widget: QWidget, layout: QBoxLayout) -> None:
        layout.addWidget(widget)
        widget.show()
        self.przeniesione.append(widget)

    def _praca_zmieniona(self, *_: object) -> None:
        self.centrum.odswiez(wymus=True)

    def _akcja_pomocy(self, akcja: str) -> None:
        if akcja == "producent" and self.dialog is not None:
            self.ustawienia.setChecked(True)
            self.dialog.producent_lokalny.setFocus()

    def _ustaw_lewy_panel(self, d: "DialogNowychSzkicow") -> None:
        u = self.centrum.uklad
        host = QWidget()
        outer = QVBoxLayout(host)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(14)
        dane = sekcja("1. Ustawienia paczki", outer)
        cast(QHBoxLayout, d.formularz.layout()).setDirection(QBoxLayout.Direction.TopToBottom)
        self._przenies(d.formularz, dane)
        if d.katalog_uzytkownika is not None:
            dane.addWidget(QLabel("Producent lokalny *"))
            self._przenies(d.producent_lokalny, dane)
            self._przenies(d.info_katalogu, dane)
        allegro = sekcja("2. Ustawienia Allegro", outer)
        for widget in (
            d.produkt_przycisk,
            d.nowy_przycisk,
            d.sprzedaz_przycisk,
            d.vat_przycisk,
            d.przelicznik_przycisk,
            d.kompletny,
        ):
            self._przenies(widget, allegro)
        d.kompletny.setText("Dane do publikacji")
        masowa = sekcja("3. Masowa edycja", outer)
        for widget in (d.masowa, d.parametry_masowe, d.popraw_przycisk, d.duplikaty_przycisk):
            self._przenies(widget, masowa)
        for control in self.przeniesione:
            control.setMinimumWidth(0)
            control.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        u.kontrolki_layout.addWidget(host)
        u.wskazowka.hide()
        u.import_group.hide()

    def osadz(self, dialog: "DialogNowychSzkicow") -> None:
        if self.dialog is dialog:
            return
        if self.dialog is not None:
            raise ValueError("Najpierw zakończ obecne przygotowanie.")
        self.dialog = dialog
        c, page, u = self.centrum, self.centrum.page, self.centrum.uklad
        self._recznie_wlaczone = page.recznie.isEnabled()
        dialog.setWindowFlags(Qt.WindowType.Widget)
        cast(QVBoxLayout, dialog.layout()).setContentsMargins(0, 0, 0, 0)
        dialog.tytul_przygotowania.hide()
        self._ustaw_lewy_panel(dialog)
        dialog.karty_ustawien.hide()
        dialog.pasek_wyboru.hide()
        self._przenies(dialog.opis_konta, u.konto)
        self._przenies(dialog.zakres, u.konto)
        self._przenies(dialog.pasek, u.operacja)
        dialog.pasek.setObjectName("postepPrzygotowania")
        dialog.pasek.setMaximumHeight(16)
        dialog.pasek.hide()
        self._przenies(dialog.info, u.operacja)
        self._przenies(dialog.podsumowanie, u.operacja)
        dialog.podsumowanie.hide()
        self._przenies(dialog.pasek_akcji, u.akcje)
        u.narzedzia.addWidget(dialog.filtr)
        dialog.filtr.show()
        self.przeniesione.append(dialog.filtr)
        # Dodatkowe działania są dostępne w tym samym menu nagłówka.
        u.menu.addMenu(dialog.menu_dzialan).setText("Działania Allegro")
        cast(QHBoxLayout, dialog.pasek_akcji.layout()).addWidget(dialog.utworz_przycisk)
        dialog.utworz_przycisk.setMinimumHeight(36)
        dialog.utworz_przycisk.setMinimumWidth(210)
        dialog.pracuj_w_programie.hide()
        dialog.notatka_szkicu.hide()
        dialog.przyciski_zamkniecia.button(QDialogButtonBox.StandardButton.Close).setText(
            "Zakończ przygotowanie"
        )
        dialog.pomoc_wysylki.ustaw_pionowo()
        dialog.pomoc_wysylki.akcja.connect(self._akcja_pomocy)
        c.panel.wstaw_pomoc(dialog.pomoc_wysylki)
        self.przeniesione.append(dialog.pomoc_wysylki)
        c.panel.tryb_przygotowania(True)
        u.tresc.addWidget(dialog)
        u.tresc.setCurrentWidget(dialog)
        dialog.show()
        page.recznie.setEnabled(False)
        page.przygotuj_allegro.hide()
        page.zapisz_szkice.setText("Zapisz źródłową paczkę lokalnie")
        page.zapisz_szkice.setToolTip("Zapisuje dane z ZIP przed poprawkami w przygotowaniu.")
        page.info.hide()
        c.hint.hide()
        dialog.status_delegowany = True
        delegate = WierszNowejOferty(
            dialog.tabela,
            tytul=1,
            sku=0,
            status=4,
            ean=lambda row: dialog.oferty[row].ean,
            oznaczenie=c.odznaka_wiersza,
        )
        dialog.tabela.setItemDelegateForColumn(1, delegate)
        dialog.tabela.setItemDelegateForColumn(4, delegate)
        dialog._pokaz_wyniki()
        self.wybor = ZaznaczaniePrzygotowania(dialog.tabela, dialog.zaznacz_widoczne)
        dialog.tabela.setColumnHidden(0, True)
        dialog.tabela.setColumnHidden(5, True)  # ID pozostaje w danych i panelu szczegółów.
        for col, width in ((2, 115), (3, 105), (4, 150), (6, 55), (7, 76)):
            dialog.tabela.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.Fixed)
            dialog.tabela.setColumnWidth(col, width)
        header = dialog.tabela.horizontalHeaderItem(1)
        if header is not None:
            header.setText("Produkt / SKU / EAN")
        dialog.filtr_prezentacji = c.pasuje_do_filtrow
        dialog.tabela.currentCellChanged.connect(c.pokaz_panel)
        dialog.filtr.currentIndexChanged.connect(c.filtruj)
        dialog.praca_zmieniona.connect(self._praca_zmieniona)
        c.odswiez(wymus=True)

    def zakoncz(self, dialog: "DialogNowychSzkicow") -> None:
        if self.dialog is not dialog:
            return
        c, page, u = self.centrum, self.centrum.page, self.centrum.uklad
        dialog.filtr_prezentacji = None
        dialog.tabela.currentCellChanged.disconnect(c.pokaz_panel)
        dialog.filtr.currentIndexChanged.disconnect(c.filtruj)
        dialog.praca_zmieniona.disconnect(self._praca_zmieniona)
        dialog.pomoc_wysylki.akcja.disconnect(self._akcja_pomocy)
        u.menu.removeAction(dialog.menu_dzialan.menuAction())
        for widget in self.przeniesione:
            widget.hide()
            widget.setParent(dialog)
        self.przeniesione.clear()
        u.tresc.setCurrentWidget(page.tabela)
        u.tresc.removeWidget(dialog)
        dialog.hide()
        dialog.setParent(page)
        self.dialog = None
        self.wybor = None
        u.wyczysc_kontrolki()
        u.wskazowka.show()
        u.import_group.show()
        c.panel.tryb_przygotowania(False)
        page.recznie.setEnabled(self._recznie_wlaczone)
        page.przygotuj_allegro.setVisible(page.allegro_dostepne)
        page.zapisz_szkice.setText("Zapisz szkice lokalnie")
        page.zapisz_szkice.setToolTip("")
        page.info.show()
        c.odswiez(wymus=True)
