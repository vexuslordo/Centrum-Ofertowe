from dataclasses import replace

from tests.integration.test_zamowienia_allegro import API, Czas, sesja
from vexlab.gui.zamowienia_allegro import StronaZamowien
from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro


def test_auto_w_tle_zachowuje_filtry_wybor_i_stary_wynik_przy_bledzie(qtbot):
    jobs, current = [], [sesja()]
    page = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()),
        lambda *args: jobs.append(args),
        lambda: current[0],
    )
    qtbot.addWidget(page)
    assert page.auto.isActive() and page.auto.interval() == 600_000
    assert page.isHidden() and not jobs
    # Rzeczywisty sygnał zegara, bez oczekiwania dziesięciu minut w teście.
    page.auto.start(1)
    qtbot.waitUntil(lambda: len(jobs) == 1)
    fn, ok, error = jobs.pop()
    ok(fn())
    assert page.model.rowCount() == 2 and page.auto.interval() == 600_000
    page.szukaj.setText("00123")
    page.realizacja.setCurrentIndex(page.realizacja.findData("NEW"))
    page.tabela.selectRow(1)
    selected = page.model.rows[1].id
    page.model.zaznaczone.add(selected)
    old = page.raport
    page.auto.start(1)
    qtbot.waitUntil(lambda: len(jobs) == 1)
    assert page.raport is old and page.model.rowCount() == 2
    fn, ok, error = jobs.pop()
    # Zajęty odczyt nie powoduje równoległego pobrania.
    page._auto_odswiez()
    assert not jobs
    ok(fn())
    assert page.szukaj.text() == "00123" and page.realizacja.currentData() == "NEW"
    assert page.model.rows[page.tabela.currentIndex().row()].id == selected
    assert selected in page.model.zaznaczone
    old = page.raport
    page.auto.start(1)
    qtbot.waitUntil(lambda: len(jobs) == 1)
    fn, ok, error = jobs.pop()
    error("SIEC", "Nie udało się odświeżyć")
    assert page.raport is old and "Nie udało" in page.info.text()
    current[0] = None
    page.polaczenie()
    assert not page.auto.isActive() and page.model.rowCount() == 0
    page._auto_odswiez()
    assert not jobs


def test_auto_nie_pobiera_bez_uprawnien_lub_po_wygasnieciu(qtbot):
    for session in (replace(sesja(), wygasa=0), replace(sesja(), aplikacja=None)):
        jobs = []
        page = StronaZamowien(
            OdczytajZamowieniaAllegro(API(), Czas()),
            lambda *args, target=jobs: target.append(args),
            lambda selected=session: selected,
        )
        qtbot.addWidget(page)
        page._auto_odswiez()
        assert not page.auto.isActive() and not jobs
