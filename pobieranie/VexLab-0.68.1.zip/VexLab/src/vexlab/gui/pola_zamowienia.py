"""Wyrównane dane szczegółów zamówienia: ikony, wartości i kopiowanie."""

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QApplication,
    QGridLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QWidget,
)

from vexlab.gui.design_system import ikona


class PolaZamowienia(QWidget):
    def __init__(self, pola: tuple[tuple[str, str, bool], ...]) -> None:
        super().__init__()
        self.setObjectName("polaZamowienia")
        self.pola: dict[str, QLabel] = {}
        self.kopiuj: dict[str, QPushButton] = {}
        self.ikony: dict[str, QLabel] = {}
        grid = QGridLayout(self)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(4)
        grid.setColumnStretch(2, 1)
        for row, (name, symbol, copy) in enumerate(pola):
            icon = QLabel()
            icon.setPixmap(ikona(symbol).pixmap(14, 14))
            icon.setFixedSize(16, 16)
            caption = QLabel(name)
            caption.setObjectName("etykietaPolaZamowienia")
            caption.setAlignment(Qt.AlignmentFlag.AlignTop)
            value = QLabel("—")
            value.setTextFormat(Qt.TextFormat.PlainText)
            value.setWordWrap(True)
            value.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            grid.addWidget(icon, row, 0, Qt.AlignmentFlag.AlignTop)
            grid.addWidget(caption, row, 1, Qt.AlignmentFlag.AlignTop)
            grid.addWidget(value, row, 2)
            self.pola[name], self.ikony[name] = value, icon
            if copy:
                button = QPushButton()
                button.setIcon(ikona("kopiuj"))
                button.setFixedSize(18, 18)
                button.setObjectName("kopiujPoleZamowienia")
                button.setToolTip("Kopiuj: " + name)
                button.clicked.connect(lambda checked=False, n=name: self._kopiuj(n))
                grid.addWidget(button, row, 3, Qt.AlignmentFlag.AlignTop)
                self.kopiuj[name] = button
        self.wyczysc()

    def ustaw(self, name: str, value: str) -> None:
        self.pola[name].setText(value or "—")
        self.pola[name].setToolTip(value)
        self.pola[name].setStyleSheet("")
        if name in self.kopiuj:
            self.kopiuj[name].setEnabled(bool(value))

    def _kopiuj(self, name: str) -> None:
        if self.kopiuj[name].isEnabled():
            QApplication.clipboard().setText(self.pola[name].text())

    def wyczysc(self) -> None:
        for name in self.pola:
            self.ustaw(name, "")
        if "Kraj" in self.ikony:
            self.ikony["Kraj"].setPixmap(ikona("globus").pixmap(14, 14))

    def kraj(self, code: str) -> None:
        nazwy = {
            "PL": "Polska",
            "CZ": "Czechy",
            "SK": "Słowacja",
            "HU": "Węgry",
            "DE": "Niemcy",
            "AT": "Austria",
            "LT": "Litwa",
            "UA": "Ukraina",
        }
        self.ustaw("Kraj", nazwy.get(code, code))
        self.ikony["Kraj"].setPixmap(ikona("globus").pixmap(14, 14))
        if code in {"PL", "CZ", "HU", "SK"}:
            path = Path(__file__).with_name("zasoby") / "flagi" / (code.lower() + ".svg")
            self.ikony["Kraj"].setPixmap(QIcon(str(path)).pixmap(16, 10))
