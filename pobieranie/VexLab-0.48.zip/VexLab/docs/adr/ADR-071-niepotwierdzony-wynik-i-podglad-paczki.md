# ADR-071 — niepotwierdzone wyniki oraz spójny podgląd paczki

Właściciel zgłasza: „przesłano 0 z 43” sugeruje brak wysyłki mimo 43 wyników
Wymaga sprawdzenia. Wymaga też paneli jak spokojne kafelki Dashboardu i
miniatur na liście Oferty z paczki.

Podsumowanie rozróżnia potwierdzony zapis (stan i ID), niewysłane,
odrzucone, pominięte oraz niepotwierdzony wynik. Niepotwierdzony nie oznacza
braku oferty na koncie. Widoczny przycisk Sprawdź wyniki wysyłki uruchamia
istniejący odczyt; tworzenie niepotwierdzonych pozycji jest zablokowane
w UI. Trwały rejestr i blokady serwisu pozostają bez zmian. Znane ID próby
z rejestru pozostaje w wyniku i tabeli także po błędzie potwierdzenia.
Samo ID nie jest liczone jako potwierdzenie zgodności całego szkicu.
Nie udajemy diagnozy konkretnych 43 wyników bez raportu/odpowiedzi konta.

Panele używają dokładnie wspólnej funkcji operacyjnego tła Dashboardu,
neutralnej bazy i subtelnego akcentu, z typografią obu motywów. Nie zmieniamy
Dashboardu ani danych. Historyczny mocny wariant KPI nadal dostępny.

Tabela paczki ma 64×64 miniatury w wizualnie pierwszej kolumnie, wiersze76,
zachowane logiczne indeksy pozostałych kolumn. Istniejący port i komponent
ObrazyOferty zapewniają proporcje, biały kwadrat, odczyty w tle i cache.
Wczytanie/zmiana paczki czyści wiersze i wyłącza stary odbiornik odpowiedzi,
aby opóźnione zdjęcia nie trafiały do nowych produktów. Numer, SKU, EAN,
cena, liczby zdjęć/sekcji i problemy pozostają. Bez zmiany ZIP-a lub bazy.
