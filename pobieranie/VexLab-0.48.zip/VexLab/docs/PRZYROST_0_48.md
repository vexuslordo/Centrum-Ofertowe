# VexLab 0.48 — czytelne wyniki i miniatury paczki

## Wynik niepotwierdzony to nie brak wysyłki

Zamiast „przesłano 0 z 43” program pokaże:
**„Niepotwierdzony wynik: 43 — oferty mogą już być na Allegro”**.
Oddzielnie liczy potwierdzone szkice, niewysłane, odrzucone i pominięte.

Przy takich wynikach przycisk **Sprawdź wyniki wysyłki** jest widoczny od
razu na dole. Odczyt korzysta z istniejącej próby, nie wysyła kolejnego POST.
Tworzenie niepotwierdzonych pozycji jest zablokowane w interfejsie.
Znane ID Allegro pozostaje w tabeli także po błędzie porównania danych.
Szczegóły przyczyny znajdziesz po wybraniu wiersza i w raporcie.

Sama zmiana komunikatu nie potwierdza obecności konkretnych 43 ofert:
trzeba odczytać wyniki. Rejestr, ochrona przed duplikatem i wymagania
potwierdzenia pozostają bez zmian. Nie uruchamiamy sprzedaży.

## Wygląd i zdjęcia

- Dwa górne panele mają spokojne tło jak operacyjne kafelki Dashboardu:
  neutralna baza, delikatny akcent i cienki obrys, oba motywy.
- **Oferty z paczki** mają miniatury 64×64 po lewej, takie jak Allegro.
  Zdjęcia widocznych wierszy pobierają się w tle. Brak zdjęcia nie blokuje.
- Zmiana paczki usuwa stare miniatury i ignoruje ich opóźnione odpowiedzi.
- Zachowano wszystkie funkcje, logo, dane i pliki użytkownika, SKU/EAN/ceny.

Podglądy syntetyczne:
[panele ciemne](screenshots/vexlab-przygotowanie-048-dark.png),
[jasne](screenshots/vexlab-przygotowanie-048-light.png),
[paczka ciemna](screenshots/vexlab-paczka-048-dark.png),
[jasna](screenshots/vexlab-paczka-048-light.png),
[niepotwierdzony wynik](screenshots/vexlab-wyniki-048-dark.png).

Testy: 43 niepotwierdzone pozycje, rozdzielenie od niewysłanych/odrzuconych,
odczyt przetwarzania bez ponownego POST, zachowanie ID po konflikcie danych,
miniatury i zmiana paczki, oba motywy i DPI200%. Testy transportu kontrolowane;
nie diagnozowano prywatnego konta użytkownika. Brak migracji bazy.

Pierwotna robocza poprawka 0.47.2 została rozszerzona na polecenie właściciela
przed publikacją; wszystkie zmiany zawiera ZIP 0.48.
