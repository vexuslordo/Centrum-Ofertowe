from dataclasses import replace

import pytest
from PySide6.QtWidgets import QMessageBox, QWidget

from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow, zapisz_raport
from vexlab.przypadki_uzycia.nowe_szkice_allegro import WynikTworzenia


def panel(qtbot, fixture, oferty=None):
    service, api, repo, s, o, u = fixture
    jobs = []
    parent = QWidget()
    qtbot.addWidget(parent)
    w = DialogNowychSzkicow(parent, service, s, oferty or (o,), lambda *args: jobs.append(args))
    w.kompletny.setChecked(False)
    w._parent_test = parent
    w.waluta.setCurrentIndex(w.waluta.findData("PLN"))
    for i in range(len(w.oferty)):
        w.ustawienia[i] = u
    w.show()
    return w, jobs


def wykonaj(jobs):
    funkcja, sukces, blad = jobs[-1]
    try:
        wynik = funkcja()
    except Exception as e:
        raise AssertionError("Błąd zadania testowego") from e
    sukces(wynik)


def test_plan_wymaga_potwierdzenia_z_domyslnym_nie(qtbot, nowe_szkice_fixture, monkeypatch):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    api = nowe_szkice_fixture[1]
    w.przygotuj()
    assert not w.utworz_przycisk.isEnabled() and w.trwa
    wykonaj(jobs)
    assert w.utworz_przycisk.isEnabled() and "POST" not in api.calls
    potwierdzenia = []

    def odmowa(*args):
        potwierdzenia.append(args)
        return QMessageBox.StandardButton.No

    monkeypatch.setattr(QMessageBox, "question", odmowa)
    w.tworz()
    assert len(jobs) == 1 and potwierdzenia[-1][-1] == QMessageBox.StandardButton.No
    assert "INACTIVE" in potwierdzenia[-1][2] and "testowy" in potwierdzenia[-1][2]
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    w.tworz()
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Utworzono szkic" and w.eksport.isEnabled()
    w.wyslij(True)
    wykonaj(jobs)
    assert api.calls.count("POST") == 1
    w.waluta.setCurrentIndex(w.waluta.findData("EUR"))
    assert not w.plany and not w.utworz_przycisk.isEnabled()


def test_powtorzone_sku_i_bledna_cena_maja_raport_przed_wysylka(qtbot, nowe_szkice_fixture):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(
        qtbot,
        nowe_szkice_fixture,
        (o, replace(o, sku="test-1"), replace(o, sku="INNY", cena="brak")),
    )
    w.przygotuj()
    wykonaj(jobs)
    assert len(w.wyniki) == 3 and all(p.bledy for p in w.plany)
    assert "Powtórzone" in w.wyniki[0].komunikat
    assert "cenę" in w.wyniki[2].komunikat
    assert not w.utworz_przycisk.isEnabled()


@pytest.mark.parametrize("zmiana", [False, True])
def test_anulowanie_i_zmiana_sesji_blokuja_dalsza_serie(qtbot, nowe_szkice_fixture, zmiana):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    w.wyslij(False)
    if zmiana:
        w.zmiana_sesji()
    else:
        w.reject()
        assert w.isVisible() and w.trwa
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Wstrzymano"
    assert "POST" not in nowe_szkice_fixture[1].calls
    if zmiana:
        assert not w.utworz_przycisk.isEnabled() and w.eksport.isEnabled()
    w.reject()


def test_nieznany_wynik_wstrzymuje_reszte_i_pozwala_zachowac_raport(qtbot, nowe_szkice_fixture):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(qtbot, nowe_szkice_fixture, (o, replace(o, sku="DRUGI")))
    w.przygotuj()
    wykonaj(jobs)
    nowe_szkice_fixture[1].awaria = "timeout"
    w.wyslij(False)
    wykonaj(jobs)
    assert [x.stan for x in w.wyniki] == ["Wymaga sprawdzenia", "Wstrzymano"]
    assert nowe_szkice_fixture[1].calls.count("POST") == 1
    assert w.eksport.isEnabled()


def test_raport_chroni_arkusz_i_nie_nadpisuje_pliku(tmp_path):
    p = tmp_path / "raport.csv"
    zapisz_raport(p, (WynikTworzenia("=CMD()", "Utworzono", "+niebezpieczne", "123"),))
    tekst = p.read_text(encoding="utf-8-sig")
    assert "'=CMD()" in tekst and "'+niebezpieczne" in tekst
    with pytest.raises(FileExistsError):
        zapisz_raport(p, ())
    assert p.read_text(encoding="utf-8-sig") == tekst


def test_wejscie_z_paczki_w_oknie_glownym_nie_wysyla_bez_potwierdzenia(
    qtbot, tmp_path, nowe_szkice_fixture
):
    from PySide6.QtCore import QSettings

    from vexlab.adaptery.czytnik_importu import CzytnikTabel
    from vexlab.adaptery.eksport_csv import EksportCSV
    from vexlab.adaptery.import_sqlite import ImportSQLite
    from vexlab.adaptery.katalog_sqlite import KatalogSQLite
    from vexlab.adaptery.paczki_zip import CzytnikZIP, ProfileJSON
    from vexlab.adaptery.preferencje import PreferencjeQt
    from vexlab.gui.okno import OknoVexLab
    from vexlab.przypadki_uzycia.allegro import PolaczAllegro
    from vexlab.przypadki_uzycia.eksport import EksportujKatalog
    from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
    from vexlab.przypadki_uzycia.katalog import KatalogProduktow
    from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek
    from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
    from vexlab.przypadki_uzycia.producenci import RejestrProducentow

    serwis, api, _, sesja, o, _ = nowe_szkice_fixture
    repo = KatalogSQLite(tmp_path / "local.sqlite3")
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), ImportSQLite(repo.plik), repo),
        paczki=PodgladPaczek(CzytnikZIP(), ProfileJSON()),
        allegro=PolaczAllegro(api, api),
        nowe_szkice=serwis,
    )
    qtbot.addWidget(w, before_close_func=lambda _: qtbot.waitUntil(lambda: not w._zadania))
    w.show()
    qtbot.waitUntil(lambda: not w._zadania)
    w.strona_allegro.sesja = sesja
    w.strona_paczek.oferty = (o,)
    w.strona_paczek.przygotuj_allegro.setEnabled(True)
    w.strona_paczek.przygotuj_allegro.click()
    assert w.dialog_nowych_szkicow is not None
    assert not w.dialog_nowych_szkicow.utworz_przycisk.isEnabled()
    assert "POST" not in api.calls
    assert w.model.rowCount() == 0
    w.dialog_nowych_szkicow.reject()
    assert w.dialog_nowych_szkicow is None


def test_katalog_jest_czytany_poza_watkiem_gui(qtbot, nowe_szkice_fixture):
    from threading import get_ident

    from PySide6.QtCore import QThreadPool

    from vexlab.gui.zadania import Zadanie

    w, _ = panel(qtbot, nowe_szkice_fixture)
    api = nowe_szkice_fixture[1]
    watki = []
    oryginal = api.produkt_szkicu

    def odczyt(*args):
        watki.append(get_ident())
        return oryginal(*args)

    api.produkt_szkicu = odczyt
    zadania = []
    pool = QThreadPool()

    def uruchom(f, sukces, blad):
        z = Zadanie(f)
        zadania.append(z)
        z.sygnaly.wynik.connect(sukces)
        z.sygnaly.blad.connect(blad)
        pool.start(z)

    w.uruchom = uruchom
    w.przygotuj()
    qtbot.waitUntil(lambda: not w.trwa)
    pool.waitForDone()
    assert watki and all(t != get_ident() for t in watki)
    assert w.utworz_przycisk.isEnabled()


@pytest.mark.parametrize("motyw", ["dark", "light"])
def test_nowy_produkt_kategoria_i_wspolne_parametry_bez_nadpisywania_cen(
    qtbot, qapp, nowe_produkty_fixture, monkeypatch, motyw
):
    from PySide6.QtWidgets import QCheckBox, QComboBox, QDialog, QPushButton

    from vexlab.gui.design_system import zastosuj_motyw
    from vexlab.przypadki_uzycia.powloka import Motyw

    zastosuj_motyw(qapp, Motyw.CIEMNY if motyw == "dark" else Motyw.JASNY)

    o = nowe_produkty_fixture[4]
    oferty = (o, replace(o, sku="DRUGI", cena="999.99", ean=""))
    w, jobs = panel(qtbot, nowe_produkty_fixture, oferty)
    # Przed wyborem nowej ścieżki brak wskazanego UUID.
    for i in range(2):
        w.ustawienia[i] = replace(w.ustawienia[i], nowy=False, kategoria="", zrodla=())
    w.tabela.selectRow(0)

    def wybierz_kategorie(d):
        assert "kategorię" in d.windowTitle()
        razem = d.findChild(QCheckBox)
        assert not razem.isChecked()
        search = next(b for b in d.findChildren(QPushButton) if b.text() == "Znajdź kategorie")
        search.click()
        assert w.trwa
        wykonaj(jobs)
        wybor = d.findChild(QComboBox)
        assert not wybor.currentData()
        wybor.setCurrentIndex(1)
        razem.setChecked(True)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", wybierz_kategorie)
    w.nowy_produkt()
    wykonaj(jobs)
    assert all(p.ustawienia.nowy for p in w.plany)
    assert "Nowy produkt" in w.tabela.item(0, 2).text()
    assert all(dict(p.ustawienia.wartosci)["kod"] == p.oferta.sku for p in w.plany)

    def uzupelnij(d):
        # Słownik stanu i dwa jawne źródła z paczki; cena tylko bieżącego wiersza.
        from PySide6.QtWidgets import QLineEdit

        cena = d.findChild(QLineEdit, "cena_szkicu")
        cena.setText("111.11")
        combos = d.findChildren(QComboBox)
        for c in combos:
            if "Kod producenta" in c.accessibleName():
                c.setCurrentIndex(c.findData("sku"))
            elif "EAN" in c.accessibleName():
                c.setCurrentIndex(c.findData("ean"))
            else:
                c.setCurrentIndex(c.findData("11323_1"))
        razem = d.findChild(QCheckBox, "stosuj_parametry_wspolne")
        assert not razem.isChecked()
        razem.setChecked(True)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", uzupelnij)
    w.uzupelnij()
    wykonaj(jobs)
    assert all(not p.bledy for p in w.plany)
    assert [p.ustawienia.cena or p.oferta.cena for p in w.plany] == ["111.11", "999.99"]
    assert [dict(p.ustawienia.wartosci)["kod"] for p in w.plany] == [o.sku, "DRUGI"]
    potwierdzenia = []
    monkeypatch.setattr(
        QMessageBox, "question", lambda *a: potwierdzenia.append(a) or QMessageBox.StandardButton.No
    )
    w.tworz()
    assert "NOWYCH PRODUKTÓW" in potwierdzenia[0][2]
    assert potwierdzenia[0][-1] == QMessageBox.StandardButton.No
    assert "POST" not in nowe_produkty_fixture[1].calls
    assert w.nowy_przycisk.isEnabled()


def test_zbiorowa_kategoria_nie_nadpisuje_dopasowanego_produktu(qtbot, nowe_produkty_fixture):
    o = nowe_produkty_fixture[4]
    w, jobs = panel(qtbot, nowe_produkty_fixture, (o, replace(o, sku="INNY")))
    w.ustawienia[1] = replace(
        w.ustawienia[1], produkt=nowe_produkty_fixture[1].produkt.id, nowy=False
    )
    w._zastosuj_kategorie(0, "123", True)
    wykonaj(jobs)
    assert w.plany[0].ustawienia.nowy
    assert not w.plany[1].ustawienia.nowy
    assert w.plany[1].ustawienia.produkt


def test_menu_dodatkowych_dzialan_zachowuje_dostepnosc_i_zaznaczenie(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.tabela.selectRow(0)
    w._menu_dzialan()
    actions = {button: action for action, button in w.akcje_dodatkowe}
    assert not actions[w.eksport].isEnabled()
    assert not actions[w.wynik_przycisk].isEnabled()
    actions[w.odznacz].trigger()
    assert not w.wybrane()
    w.przygotuj()
    assert w.anuluj.isVisible()
    wykonaj(jobs)
    w._menu_dzialan()
    assert actions[w.eksport].isEnabled()
    assert actions[w.wynik_przycisk].isEnabled()
    assert not w.anuluj.isVisible()
    calls = []
    w.eksport.clicked.disconnect()
    w.eksport.clicked.connect(lambda: calls.append(True))
    actions[w.eksport].trigger()
    assert calls == [True]
    w.zmiana_sesji()
    w._menu_dzialan()
    assert actions[w.eksport].isEnabled()
    assert not actions[w.sygnatury].isEnabled()
    assert not actions[w.uzupelnij_przycisk].isEnabled()


def test_gotowosc_jako_znak_a_wysylka_jako_potwierdzenie(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    znak = w.tabela.cellWidget(0, 4)
    assert znak is not None and "Gotowa" in znak.accessibleName()
    assert w.tabela.item(0, 4).text() == ""
    assert not w.podsumowanie.isVisible()
    w.wyslij(False)
    wykonaj(jobs)
    assert w.tabela.cellWidget(0, 4) is None
    assert w.tabela.item(0, 4).text() == "Utworzono szkic"
    assert "Potwierdzono zapis w Allegro: 1" in w.podsumowanie.text()
    assert w.podsumowanie.isVisible()


def test_miniatury_64_po_lewej_i_brak_zdjecia(qtbot, nowe_szkice_fixture):
    from PySide6.QtWidgets import QWidget

    from tests.gui.test_podglad_oferty import png
    from vexlab.gui.podglad_oferty import ObrazPodgladu
    from vexlab.przypadki_uzycia.media import ZdjecieDane
    from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec

    calls = []

    class Source:
        def pobierz_obraz(self, url):
            calls.append(url)
            return ZdjecieDane(url, png(), png())

    service, _, _, session, o, _ = nowe_szkice_fixture
    parent = QWidget()
    qtbot.addWidget(parent)
    w = DialogNowychSzkicow(
        parent,
        service,
        session,
        (o, replace(o, sku="2", zdjecia=(), sekcje=())),
        lambda f, ok, err: ok(f()),
        PodgladZdjec(Source()),
    )
    w.show()
    qtbot.waitUntil(lambda: bool(calls))
    assert w.tabela.horizontalHeader().logicalIndex(0) == 7
    images = w.tabela.findChildren(ObrazPodgladu)
    assert len(images) == 2
    assert all(image.width() == image.height() == 64 for image in images)
    assert any(not image.obraz.isNull() for image in images)
    assert any(image.accessibleName() == "Brak zdjęcia produktu" for image in images)
    assert calls == [o.zdjecia[0]]
    w.reject()
    assert not w.obrazy.aktywne


def test_czesciowa_wysylka_nie_oglasza_pelnego_sukcesu(qtbot, nowe_szkice_fixture, monkeypatch):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(qtbot, nowe_szkice_fixture, (o, replace(o, sku="DRUGI")))
    w.przygotuj()
    wykonaj(jobs)
    results = iter(
        (
            WynikTworzenia(o.sku, "Szkic kompletny", "Zapis potwierdzony", "12345"),
            WynikTworzenia("DRUGI", "Wynik nieznany", "Sprawdź odczytem", "67890"),
        )
    )
    monkeypatch.setattr(w.serwis, "utworz", lambda *args: next(results))
    w.wyslij(False)
    wykonaj(jobs)
    assert "Potwierdzono zapis w Allegro: 1" in w.podsumowanie.text()
    assert "Niepotwierdzony wynik: 1" in w.podsumowanie.text()


def test_sprawdzanie_i_ponowna_kontrola_przed_wysylka_blokuja_duplikat(qtbot, nowe_szkice_fixture):
    from vexlab.przypadki_uzycia.duplikaty_allegro import IstniejacaOferta, SprawdzDuplikatyAllegro

    w, jobs = panel(qtbot, nowe_szkice_fixture)
    api = nowe_szkice_fixture[1]
    o = nowe_szkice_fixture[4]

    class Existing:
        def kandydaci_duplikatow(self, s, pole, fraza):
            return (IstniejacaOferta("999", "Inny tytuł", o.sku, "ACTIVE"),)

    w.kontrola_duplikatow = SprawdzDuplikatyAllegro(Existing())
    w.przygotuj()
    wykonaj(jobs)
    w.sprawdz_duplikaty()
    wykonaj(jobs)
    assert w.tabela.item(0, 4).text() == "Już na Allegro"
    assert w.tabela.item(0, 5).text() == "999"
    assert "Aktywna" in w.wyniki[0].komunikat
    assert not w.utworz_przycisk.isEnabled()
    w.wyslij(False)
    wykonaj(jobs)
    assert "POST" not in api.calls and "zdjecie" not in api.calls
    assert w.wyniki[0].stan == "Już na Allegro"


def test_blad_sprawdzania_konta_blokuje_wysylke(qtbot, nowe_szkice_fixture):
    from vexlab.przypadki_uzycia.allegro import BladAllegro
    from vexlab.przypadki_uzycia.duplikaty_allegro import SprawdzDuplikatyAllegro

    w, jobs = panel(qtbot, nowe_szkice_fixture)

    class Failed:
        def kandydaci_duplikatow(self, *args):
            raise BladAllegro("SIEC", "Nie sprawdzono konta")

    w.kontrola_duplikatow = SprawdzDuplikatyAllegro(Failed())
    w.przygotuj()
    wykonaj(jobs)
    w.wyslij(False)
    fn, _, error = jobs[-1]
    try:
        fn()
    except BladAllegro as exc:
        error(exc.kod, str(exc))
    assert "POST" not in nowe_szkice_fixture[1].calls
    assert "Nie sprawdzono konta" in w.info.text()


def test_43_niepotwierdzone_wyniki_nie_oznaczaja_ze_nic_nie_wyslano():
    from vexlab.gui.nowe_szkice_allegro import podsumuj_wysylke

    wyniki = tuple(
        WynikTworzenia(str(i), "Wymaga sprawdzenia", "Odczyt niepotwierdzony") for i in range(43)
    )
    text = podsumuj_wysylke(wyniki)
    assert "Niepotwierdzony wynik: 43" in text
    assert "oferty mogą już być na Allegro" in text
    assert "Niewysłane: 0" in text
    assert "przesłano 0" not in text


def test_niewyslane_i_odrzucone_nie_sa_liczone_jako_nieznane():
    from vexlab.gui.nowe_szkice_allegro import podsumuj_wysylke

    text = podsumuj_wysylke(
        (
            WynikTworzenia("1", "Do poprawy", "Brak ceny"),
            WynikTworzenia("2", "Odrzucono", "HTTP 422"),
        )
    )
    assert "Niewysłane: 1" in text and "Odrzucone: 1" in text
    assert "Niepotwierdzony" not in text


def test_widoczny_odczyt_przetwarzania_potwierdza_bez_drugiego_post(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    api = nowe_szkice_fixture[1]
    api.async_mode, api.zakonczona = True, False
    w.przygotuj()
    wykonaj(jobs)
    w.wyslij(False)
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Przetwarzanie"
    assert not w.utworz_przycisk.isEnabled()
    assert w.wynik_przycisk.isVisible()
    assert "Niepotwierdzony wynik: 1" in w.podsumowanie.text()
    api.zakonczona = True
    w.wynik_przycisk.click()
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Utworzono szkic"
    assert api.calls.count("POST") == 1
    assert not w.wynik_przycisk.isVisible()
    assert "Potwierdzono zapis w Allegro: 1" in w.podsumowanie.text()


def test_znane_id_zostaje_po_konflikcie_danych_odczytu(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    w.wyslij(False)
    wykonaj(jobs)
    ident = w.wyniki[0].ident
    w.ilosc.setValue(5)
    w.przygotuj()
    wykonaj(jobs)
    w.wyslij(True)
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Wymaga sprawdzenia"
    assert w.wyniki[0].ident == ident
    assert w.tabela.item(0, 5).text() == ident
    assert nowe_szkice_fixture[1].calls.count("POST") == 1
