"""Przegląd planu ZIP → INACTIVE, jawne dane konta, raport i anulowanie serii."""

import csv
from collections import Counter
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from threading import Event
from typing import cast

from PySide6.QtCore import QEvent, QObject, Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.kafelek_kpi import PanelDashboardu
from vexlab.gui.masowa_paczka_allegro import MasowaPaczkaAllegro
from vexlab.gui.podglad_oferty import ObrazyOferty
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.gui.ustawienia_sprzedazy_allegro import DaneSprzedazyAllegro
from vexlab.gui.vat_allegro import VATAllegro
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.duplikaty_allegro import (
    IstniejacaOferta,
    SprawdzDuplikatyAllegro,
    opis_duplikatow,
)
from vexlab.przypadki_uzycia.edycja_paczki_allegro import zmien_parametry
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    KategoriaSzkicu,
    NoweSzkiceAllegro,
    PlanNowegoSzkicu,
    ProduktSzkicu,
    UstawieniaSzkicu,
    WynikTworzenia,
    domyslne_zrodlo,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.sygnatury_allegro import APISygnatur, napraw_sygnature
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import SlownikiSprzedazy


def zapisz_raport(
    plik: Path, wyniki: tuple[WynikTworzenia, ...], konto: str = "", srodowisko: str = ""
) -> None:
    def pole(v: str) -> str:
        return (
            "'" + v
            if v.lstrip().startswith(("=", "+", "-", "@")) or v.startswith(("\t", "\r", "\n"))
            else v
        )

    with plik.open("x", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(("Konto", "Środowisko", "SKU", "Wynik", "ID Allegro", "Informacja"))
        for w in wyniki:
            writer.writerow(
                tuple(pole(v) for v in (konto, srodowisko, w.sku, w.stan, w.ident, w.komunikat))
            )


def podsumuj_wysylke(wyniki: tuple[WynikTworzenia, ...]) -> str:
    potwierdzone = {"Utworzono szkic", "Szkic kompletny", "Szkic do poprawy"}
    niewyslane = {"Nie wysłano", "Nie sprawdzono", "Do poprawy", "Wstrzymano", "Anulowano"}
    zapisane = sum(w.stan in potwierdzone and bool(w.ident) for w in wyniki)
    pominiete = sum(w.stan == "Już na Allegro" for w in wyniki)
    odrzucone = sum(w.stan == "Odrzucono" for w in wyniki)
    bez_proby = sum(w.stan in niewyslane for w in wyniki)
    nieznane = len(wyniki) - zapisane - pominiete - odrzucone - bez_proby
    tekst = f"Potwierdzono zapis w Allegro: {zapisane}. "
    if nieznane:
        tekst += (
            f"Niepotwierdzony wynik: {nieznane} — oferty mogą już być na Allegro. "
            "Kliknij „Sprawdź wyniki wysyłki”; nie twórz ich ponownie. "
        )
    tekst += (
        f"Niewysłane: {bez_proby}. Odrzucone: {odrzucone}. "
        f"Już na Allegro (pominięte): {pominiete}. "
    )
    poprawki = sum(w.stan == "Szkic do poprawy" for w in wyniki)
    if poprawki:
        tekst += f"Zapisane szkice do poprawy: {poprawki}. "
    return tekst + "Ta operacja nie uruchamia sprzedaży."


class DialogNowychSzkicow(QDialog):
    postep = Signal(int, str)

    def __init__(
        self,
        parent: QWidget,
        serwis: NoweSzkiceAllegro,
        sesja: SesjaAllegro,
        oferty: tuple[OfertaPodglad, ...],
        uruchom: Uruchom,
        zdjecia: PodgladZdjec | None = None,
        duplikaty: SprawdzDuplikatyAllegro | None = None,
    ) -> None:
        super().__init__(parent)
        self.serwis, self.sesja, self.oferty, self.uruchom = serwis, sesja, oferty, uruchom
        self.plany: tuple[PlanNowegoSzkicu, ...] = ()
        self.wyniki: tuple[WynikTworzenia, ...] = ()
        self.ilosci: dict[int, int] = {}
        self.ustawienia: dict[int, UstawieniaSzkicu] = {}
        self.trwa = self.nieaktualny = False
        self.kontrola_duplikatow = duplikaty
        self.duplikaty: dict[int, tuple[IstniejacaOferta, ...]] = {}
        self.stop = Event()
        self.obrazy = ObrazyOferty(self, zdjecia, uruchom, miniatury=True)
        self._miniatury: dict[int, str] = {}
        self.timer_miniatur = QTimer(self)
        self.timer_miniatur.setSingleShot(True)
        self.timer_miniatur.timeout.connect(self._miniatury_widoczne)
        self.finished.connect(lambda _: self.obrazy.zamknij())
        self.finished.connect(lambda _: self.timer_miniatur.stop())
        self.setWindowTitle("Nowe szkice Allegro z paczki ZIP")
        self.resize(1280, 760)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)
        tytul = etykieta("Przygotuj oferty Allegro")
        tytul.setObjectName("tytulStronyAllegro")
        layout.addWidget(tytul)
        konto = etykieta(
            f"Konto: {sesja.konto.login} • {sesja.srodowisko.value} • {len(oferty)} pozycji"
        )
        konto.setObjectName("opis")
        layout.addWidget(konto)
        self.kompletny = QCheckBox("Przygotuj komplet danych do publikacji")
        self.kompletny.setChecked(True)
        self.kompletny.setToolTip(
            "Wymaga GPSR, dostawy i warunków. Publikacja sprzedaży nadal osobno."
        )
        self.formularz = QWidget()
        form = QHBoxLayout(self.formularz)
        form.setContentsMargins(0, 0, 0, 0)
        form.setSpacing(12)
        self.waluta = QComboBox()
        self.waluta.setAccessibleName("Waluta cen brutto z paczki")
        self.waluta.addItem("Wybierz walutę cen brutto", "")
        for waluta in ("PLN", "EUR", "CZK", "HUF"):
            self.waluta.addItem(waluta, waluta)
        self.ilosc = QSpinBox()
        self.ilosc.setAccessibleName("Ilość w każdym nowym szkicu")
        self.ilosc.setRange(0, 10000000)
        self.ilosc.setValue(1)
        self.waluta.setMinimumWidth(100)
        self.ilosc.setMaximumWidth(110)
        self.ilosc.setToolTip("Wspólna ilość. Wyjątki możesz ustawić w tabeli lub edycji masowej.")
        form.addWidget(etykieta("Waluta cen brutto"))
        form.addWidget(self.waluta, 1)
        form.addWidget(etykieta("Domyślna ilość"))
        form.addWidget(self.ilosc)
        self.sprawdz_przycisk = QPushButton("Sprawdź paczkę")
        self.produkt_przycisk = QPushButton("Wybierz produkt Allegro…")
        self.nowy_przycisk = QPushButton("Nowy produkt w Allegro…")
        self.nowy_przycisk.setToolTip(
            "Produkt nie istnieje w katalogu? Wybierz kategorię i przygotuj jego zgłoszenie."
        )
        self.uzupelnij_przycisk = QPushButton("Dane wybranej oferty…")
        self.utworz_przycisk = QPushButton("Utwórz szkice w Allegro…")
        self.utworz_przycisk.setObjectName("primary")
        self.wynik_przycisk = QPushButton("Sprawdź wyniki wysyłki")
        self.eksport = QPushButton("Eksportuj raport…")
        self.sygnatury = QPushButton("Popraw stare sygnatury…")
        self.sygnatury.setToolTip(
            "Dla szkiców utworzonych wcześniej z tej paczki: zamień vexlab-… na SKU."
        )
        self.anuluj = QPushButton("Zatrzymaj serię")
        self.anuluj.clicked.connect(self.stop.set)
        self.przyciski: tuple[QPushButton, ...] = (
            self.sprawdz_przycisk,
            self.produkt_przycisk,
            self.uzupelnij_przycisk,
            self.utworz_przycisk,
            self.wynik_przycisk,
            self.eksport,
        )
        self.parametry_masowe = QPushButton("Parametry produktów…")
        self.sprzedaz_przycisk = QPushButton("GPSR, dostawa i warunki…")
        self.vat_przycisk = QPushButton("VAT według krajów…")
        self.przyciski += (self.nowy_przycisk, self.sprzedaz_przycisk, self.vat_przycisk)
        przygotowanie = QHBoxLayout()
        przygotowanie.setSpacing(16)
        for naglowek, opis, widgets in (
            (
                "1. Dane produktów",
                "SKU, EAN i ceny pozostają osobne dla każdego produktu.",
                (self.formularz,),
            ),
            (
                "2. Ustawienia Allegro",
                "Ustaw dla zaznaczonych produktów lub wszystkich widocznych.",
                (self.kompletny,),
            ),
        ):
            karta = PanelDashboardu("produkty" if widgets[0] is self.formularz else "aktywne")
            karta.setObjectName("karta")
            card = QVBoxLayout(karta)
            card.setContentsMargins(16, 14, 16, 14)
            card.setSpacing(12)
            label = etykieta(naglowek)
            label.setObjectName("tytulSekcjiAllegro")
            card.addWidget(label)
            hint = etykieta(opis)
            hint.setObjectName("opis")
            card.addWidget(hint)
            buttons = QHBoxLayout()
            if widgets[0] is self.formularz:
                card.addWidget(self.formularz)
                buttons.addWidget(self.produkt_przycisk)
                buttons.addWidget(self.nowy_przycisk)
                buttons.addWidget(self.parametry_masowe)
                card.addLayout(buttons)
            else:
                buttons.addWidget(self.sprzedaz_przycisk)
                buttons.addWidget(self.vat_przycisk)
                card.addLayout(buttons)
                card.addWidget(self.kompletny)
            przygotowanie.addWidget(karta, 1)
        layout.addLayout(przygotowanie)
        wybor = QHBoxLayout()
        self.wszystkie = QPushButton("Zaznacz widoczne")
        self.odznacz = QPushButton("Odznacz")
        self.masowa = QPushButton("Edytuj dane…")
        self.filtr = QComboBox()
        for nazwa in ("Wszystkie pozycje", "Gotowe", "Do poprawy"):
            self.filtr.addItem(nazwa)
        self.filtr.setAccessibleName("Filtr gotowości paczki")
        self.zakres = etykieta("Wybrane: 0")
        self.zakres.setWordWrap(False)
        self.zakres.setObjectName("opis")
        self.duplikaty_przycisk = QPushButton("Sprawdź duplikaty")
        self.duplikaty_przycisk.clicked.connect(self.sprawdz_duplikaty)
        self.przyciski += (self.duplikaty_przycisk,)
        self.wiecej = QPushButton("Więcej działań")
        self.menu_dzialan = QMenu(self.wiecej)
        self.wiecej.setMenu(self.menu_dzialan)
        self.akcje_dodatkowe = []
        for button in (
            self.uzupelnij_przycisk,
            self.odznacz,
            self.wynik_przycisk,
            self.eksport,
            self.sygnatury,
        ):
            action = self.menu_dzialan.addAction(button.text())
            action.triggered.connect(button.click)
            self.akcje_dodatkowe.append((action, button))
            button.setParent(self)
            button.hide()
        self.menu_dzialan.aboutToShow.connect(self._menu_dzialan)
        for widget in (self.wszystkie, self.masowa, self.duplikaty_przycisk):
            wybor.addWidget(widget)
        wybor.addStretch(1)
        wybor.addWidget(self.zakres)
        wybor.addWidget(self.filtr)
        wybor.addWidget(self.wiecej)
        layout.addLayout(wybor)
        self.przyciski += (self.wszystkie, self.odznacz, self.masowa, self.parametry_masowe)
        self.tabela = QTableWidget(len(oferty), 8)
        self.tabela.setHorizontalHeaderLabels(
            (
                "SKU",
                "Nazwa produktu",
                "Produkt Allegro",
                "Cena brutto",
                "Gotowość / wynik",
                "ID Allegro",
                "Ilość",
                "Zdjęcie",
            )
        )
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.verticalHeader().hide()
        self.tabela.verticalHeader().setDefaultSectionSize(76)
        self.tabela.setShowGrid(False)
        self.tabela.setWordWrap(False)
        self.tabela.setAlternatingRowColors(True)
        header = self.tabela.horizontalHeader()
        header.setStretchLastSection(False)
        header.moveSection(7, 0)
        self.tabela.setColumnWidth(7, 84)
        header.setSectionResizeMode(7, QHeaderView.ResizeMode.Fixed)
        self.tabela.viewport().installEventFilter(self)
        self.tabela.verticalScrollBar().valueChanged.connect(
            lambda _: self.timer_miniatur.start(40)
        )
        self.timer_miniatur.start(0)
        for col, width in ((0, 140), (3, 115), (4, 150), (5, 105), (6, 65)):
            self.tabela.setColumnWidth(col, width)
        for col in (1, 2):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.Stretch)
        self.tabela.setAccessibleName("Plan i wyniki tworzenia szkiców z ZIP")
        for i, o in enumerate(oferty):
            for j, tekst in enumerate(
                (o.sku, o.tytul, "Do sprawdzenia", o.cena, "Nie sprawdzono", "", "1")
            ):
                item = QTableWidgetItem(tekst)
                item.setToolTip(tekst)
                self.tabela.setItem(i, j, item)
        layout.addWidget(self.tabela, 1)
        self.pasek = QProgressBar()
        self.pasek.hide()
        layout.addWidget(self.pasek)
        self.info = etykieta(
            "Uzupełnij dane i kliknij „Sprawdź paczkę”. "
            "Wybierz wiersz, aby zobaczyć szczegóły braków."
        )
        self.info.setObjectName("opis")
        layout.addWidget(self.info)
        self.podsumowanie = etykieta("")
        self.podsumowanie.setObjectName("tytulSekcjiAllegro")
        self.podsumowanie.hide()
        layout.addWidget(self.podsumowanie)
        bottom = QHBoxLayout()
        note = etykieta("Zapisujemy szkice. Sprzedaż uruchomisz osobno.")
        note.setObjectName("opis")
        bottom.addWidget(note, 1)
        bottom.addWidget(self.anuluj)
        bottom.addWidget(self.wynik_przycisk)
        self.wynik_przycisk.hide()
        bottom.addWidget(self.sprawdz_przycisk)
        bottom.addWidget(self.utworz_przycisk)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        close.rejected.connect(self.reject)
        bottom.addWidget(close)
        layout.addLayout(bottom)
        self.sprawdz_przycisk.clicked.connect(self.przygotuj)
        self.produkt_przycisk.clicked.connect(self.wybierz_produkt)
        self.sprzedaz_przycisk.clicked.connect(self.ustaw_sprzedaz)
        self.vat_przycisk.clicked.connect(self.ustaw_vat)
        self.kompletny.toggled.connect(self.uniewaznij)
        self.nowy_przycisk.clicked.connect(self.nowy_produkt)
        self.uzupelnij_przycisk.clicked.connect(self.uzupelnij)
        self.utworz_przycisk.clicked.connect(self.tworz)
        self.wynik_przycisk.clicked.connect(lambda: self.wyslij(True))
        self.eksport.clicked.connect(self.eksportuj)
        self.sygnatury.clicked.connect(self.popraw_sygnatury)
        self.przyciski += (self.sygnatury,)
        self.waluta.currentIndexChanged.connect(self.uniewaznij)
        self.ilosc.valueChanged.connect(self.uniewaznij)
        self.wszystkie.clicked.connect(self.zaznacz_widoczne)
        self.odznacz.clicked.connect(self.tabela.clearSelection)
        self.masowa.clicked.connect(self.edytuj_masowo)
        self.parametry_masowe.clicked.connect(lambda: self.uzupelnij(True))
        self.filtr.currentIndexChanged.connect(self._filtruj)
        self.postep.connect(self._postep)
        self.tabela.itemSelectionChanged.connect(self._szczegoly_wyniku)
        self._przyciski()

    def eventFilter(self, obiekt: QObject, zdarzenie: QEvent) -> bool:
        if obiekt is self.tabela.viewport() and zdarzenie.type() in (
            QEvent.Type.Show,
            QEvent.Type.Resize,
        ):
            self.timer_miniatur.start(0)
        return super().eventFilter(obiekt, zdarzenie)

    def _miniatury_widoczne(self) -> None:
        if not self.isVisible():
            return
        for row in range(len(self.oferty)):
            if self.tabela.isRowHidden(row) or not self.tabela.visualRect(
                self.tabela.model().index(row, 7)
            ).intersects(self.tabela.viewport().rect()):
                continue
            o = self.oferty[row]
            url = next(iter(o.zdjecia), "") or next(
                (e.adres for section in o.sekcje for e in section if e.typ == "obraz"), ""
            )
            if self._miniatury.get(row) == url:
                continue
            self._miniatury[row] = url
            image = self.obrazy.obraz(url)
            if not url:
                image.setText("—")
                image.setAccessibleName("Brak zdjęcia produktu")
            host = QWidget()
            box = QHBoxLayout(host)
            box.setContentsMargins(4, 4, 4, 4)
            box.addWidget(image, 0, Qt.AlignmentFlag.AlignCenter)
            self.tabela.setCellWidget(row, 7, host)

    def _menu_dzialan(self) -> None:
        for action, button in self.akcje_dodatkowe:
            action.setEnabled(button.isEnabled())

    def wybrane(self) -> tuple[int, ...]:
        return tuple(
            sorted(
                i.row()
                for i in self.tabela.selectionModel().selectedRows()
                if not self.tabela.isRowHidden(i.row())
            )
        )

    def zakres_wysylki(self) -> tuple[int, ...]:
        return self.wybrane() or tuple(
            i for i in range(len(self.plany)) if not self.tabela.isRowHidden(i)
        )

    def _mozna_wyslac(self, i: int) -> bool:
        return (
            i < len(self.plany)
            and not self.plany[i].bledy
            and not self.duplikaty.get(i)
            and (
                i >= len(self.wyniki)
                or self.wyniki[i].stan
                not in {"Wymaga sprawdzenia", "Wynik nieznany", "Przetwarzanie"}
            )
        )

    def _wybor(self) -> None:
        rows = self.wybrane()
        gotowe = sum(self._mozna_wyslac(i) for i in rows if i < len(self.plany))
        self.zakres.setText(f"Wybrane: {len(rows)} • gotowe: {gotowe}")
        self.utworz_przycisk.setEnabled(
            not self.trwa
            and not self.nieaktualny
            and any(self._mozna_wyslac(i) for i in self.zakres_wysylki() if i < len(self.plany))
        )
        self.utworz_przycisk.setText(
            "Utwórz zaznaczone szkice…" if rows else "Utwórz gotowe szkice…"
        )

    def _filtruj(self) -> None:
        self.timer_miniatur.start(0)
        for i in range(len(self.oferty)):
            ready = i < len(self.plany) and not self.plany[i].bledy
            hide = (self.filtr.currentIndex() == 1 and not ready) or (
                self.filtr.currentIndex() == 2 and ready
            )
            if hide:
                for col in range(self.tabela.columnCount()):
                    self._komorka(i, col).setSelected(False)
            self.tabela.setRowHidden(i, hide)
        self._wybor()

    def zaznacz_widoczne(self) -> None:
        self.tabela.selectAll()
        self._filtruj()

    def popraw_sygnatury(self) -> None:
        rows = self.wybrane()
        if not rows or self.trwa or self.nieaktualny:
            self.info.setText("Zaznacz pozycje z wcześniej utworzonymi szkicami.")
            return
        if (
            QMessageBox.question(
                self,
                "Popraw sygnatury własnych szkiców",
                f"Konto: {self.sesja.konto.login}. Sprawdzić {len(rows)} pozycji "
                "i zamienić stare sygnatury vexlab-… na ich SKU? Zmienione zostaną "
                "wyłącznie własne, zarejestrowane szkice INACTIVE.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return

        def praca() -> tuple[WynikTworzenia, ...]:
            wyniki = (
                list(self.wyniki)
                if len(self.wyniki) == len(self.oferty)
                else [WynikTworzenia(o.sku, "Nie sprawdzono", "") for o in self.oferty]
            )
            for row in rows:
                if self.stop.is_set():
                    break
                try:
                    wyniki[row] = napraw_sygnature(
                        self.serwis,
                        cast(APISygnatur, self.serwis.api),
                        self.sesja,
                        self.oferty[row].sku,
                    )
                except BladAllegro as exc:
                    wyniki[row] = WynikTworzenia(
                        self.oferty[row].sku, "Wymaga sprawdzenia", str(exc)
                    )
                    break
                if wyniki[row].stan == "Wynik nieznany":
                    break
            return tuple(wyniki)

        def gotowe(w: object) -> None:
            self.wyniki = cast(tuple[WynikTworzenia, ...], w)
            self._pokaz_wyniki()
            self.info.setText(
                "Sprawdzono sygnatury. Zachowaj raport. Możesz ponownie sprawdzić "
                "operacje w toku tym samym przyciskiem."
            )

        self._zadanie(praca, gotowe)

    def ustaw_vat(self) -> None:
        if self.trwa or self.nieaktualny:
            return
        rows = self.wybrane() or tuple(
            i for i in range(len(self.oferty)) if not self.tabela.isRowHidden(i)
        )
        if not rows:
            return
        if any(i >= len(self.plany) or self.plany[i].produkt is None for i in rows):
            QMessageBox.information(
                self,
                "VAT — wybierz kategorię",
                "Najpierw wybierz kategorię lub produkt Allegro i sprawdź paczkę.",
            )
            return
        categories = {cast(ProduktSzkicu, self.plany[i].produkt).kategoria for i in rows}
        if len(categories) != 1:
            QMessageBox.information(
                self,
                "VAT — jedna kategoria",
                "Stawki zależą od kategorii. Zaznacz grupę ofert jednej kategorii.",
            )
            return
        category = next(iter(categories))
        d = VATAllegro(
            self,
            category,
            len(rows),
            self._ustawienia(rows[0]).vat,
            lambda: self.serwis.api.vat_kategorii(self.sesja, category, True),
            lambda ident: self.serwis.api.vat_oferty(self.sesja, ident, category),
            self.uruchom,
            lambda: not self.nieaktualny,
            konto=self.sesja.konto.login,
        )
        if d.exec() == QDialog.DialogCode.Accepted and not self.nieaktualny:
            for i in rows:
                self.ustawienia[i] = replace(self._ustawienia(i), vat=d.wynik)
            self.uniewaznij()
            self.przygotuj()

    def ustaw_sprzedaz(self) -> None:
        if self.trwa or self.nieaktualny:
            return
        rows = self.wybrane() or tuple(
            i for i in range(len(self.oferty)) if not self.tabela.isRowHidden(i)
        )
        if not rows:
            return

        d = DaneSprzedazyAllegro(
            self,
            SlownikiSprzedazy((), (), (), (), (), ()),
            self._ustawienia(rows[0]).sprzedaz,
            len(rows),
            pobierz=lambda: self.serwis.api.slowniki_sprzedazy(self.sesja, True, True),
            uruchom=self.uruchom,
            aktualne=lambda: not self.nieaktualny,
        )
        if d.exec() == QDialog.DialogCode.Accepted and d.wynik and not self.nieaktualny:
            for row in rows:
                self.ustawienia[row] = replace(self._ustawienia(row), sprzedaz=d.wynik)
            self.uniewaznij()
            self.przygotuj()

    def edytuj_masowo(self) -> None:
        rows = self.wybrane()
        if not rows or self.trwa or self.nieaktualny:
            self.info.setText("Zaznacz pozycje do edycji (Ctrl/Shift lub Zaznacz widoczne).")
            return
        d = MasowaPaczkaAllegro(self, tuple((self.oferty[i], self._ustawienia(i)) for i in rows))
        if d.exec() != QDialog.DialogCode.Accepted or self.nieaktualny or not d.wynik:
            return
        oferty = list(self.oferty)
        for i, (o, u) in zip(rows, d.wynik, strict=True):
            oferty[i], self.ustawienia[i], self.ilosci[i] = o, u, u.ilosc
        self.oferty = tuple(oferty)
        self.uniewaznij()
        self.przygotuj()

    def _szczegoly_wyniku(self) -> None:
        self._wybor()
        row = self.tabela.currentRow()
        if not self.trwa and 0 <= row < len(self.wyniki):
            self.info.setText(self.wyniki[row].komunikat[:1200])

    def _postep(self, numer: int, sku: str) -> None:
        self.info.setText(
            f"Pozycja {numer}/{len(self.oferty)} • {sku}. Żądania już wysłanego nie można cofnąć."
        )

    def _przyciski(self) -> None:
        for b in self.przyciski:
            b.setEnabled(not self.trwa and not self.nieaktualny)
        self.utworz_przycisk.setEnabled(
            not self.trwa and not self.nieaktualny and any(not p.bledy for p in self.plany)
        )
        self.wynik_przycisk.setEnabled(not self.trwa and not self.nieaktualny and bool(self.plany))
        self.wynik_przycisk.setVisible(
            any(
                w.stan in {"Wynik nieznany", "Wymaga sprawdzenia", "Przetwarzanie"}
                for w in self.wyniki
            )
        )
        self.eksport.setEnabled(not self.trwa and bool(self.wyniki))
        self.formularz.setEnabled(not self.trwa and not self.nieaktualny)
        self.kompletny.setEnabled(not self.trwa and not self.nieaktualny)
        self.anuluj.setEnabled(self.trwa)
        self.anuluj.setVisible(self.trwa)
        self._wybor()

    def uniewaznij(self) -> None:
        self.duplikaty.clear()
        self.plany = ()
        self._przyciski()
        self.info.setText("Ustawienia zmienione. Sprawdź paczkę ponownie.")

    def zmiana_sesji(self) -> None:
        self.nieaktualny = True
        self.stop.set()
        self.info.setText(
            "Sesja konta zmieniła się. Zatrzymano dalsze żądania; zachowaj "
            "raport i otwórz plan ponownie."
        )
        self._przyciski()

    def _zadanie(self, funkcja: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self.trwa or self.nieaktualny:
            return
        self.trwa = True
        self.stop.clear()
        self.pasek.setRange(0, 0)
        self.pasek.show()
        self._przyciski()

        def gotowe(wynik: object) -> None:
            self.trwa = False
            self.pasek.hide()
            sukces(wynik)
            self._przyciski()

        def blad(kod: str, opis: str) -> None:
            self.trwa = False
            self.pasek.hide()
            self.info.setText(opis)
            self._przyciski()

        self.uruchom(funkcja, gotowe, blad)

    def _ustawienia(self, i: int) -> UstawieniaSzkicu:
        return replace(
            self.ustawienia.get(i, UstawieniaSzkicu("", 1)),
            waluta=str(self.waluta.currentData()),
            ilosc=self.ilosci.get(i, self.ilosc.value()),
            gotowosc=self.kompletny.isChecked(),
        )

    def przygotuj(self) -> None:
        self.duplikaty.clear()
        self.plany = ()
        ustawienia = tuple(self._ustawienia(i) for i in range(len(self.oferty)))
        duplikaty = Counter(o.sku.strip().casefold() for o in self.oferty)

        def zadanie() -> tuple[PlanNowegoSzkicu, ...]:
            wynik = []
            for i, (o, u) in enumerate(zip(self.oferty, ustawienia, strict=True)):
                if self.stop.is_set():
                    break
                self.postep.emit(i + 1, o.sku)
                p = self.serwis.przygotuj(self.sesja, o, u)
                if duplikaty[o.sku.strip().casefold()] > 1:
                    p = replace(
                        p,
                        bledy=(
                            *p.bledy,
                            "Powtórzone SKU w paczce. Rozdziel pozycje przed wysyłką.",
                        ),
                    )
                wynik.append(p)
            return tuple(wynik)

        def gotowe(w: object) -> None:
            self.plany = cast(tuple[PlanNowegoSzkicu, ...], w)
            self.wyniki = tuple(
                WynikTworzenia(
                    p.oferta.sku,
                    "Do poprawy" if p.bledy else "Gotowa do utworzenia",
                    "; ".join(p.bledy)
                    or "Sprawdź nazwę dopasowanego produktu przed potwierdzeniem.",
                )
                for p in self.plany
            )
            self.wyniki += tuple(
                WynikTworzenia(
                    o.sku, "Nie sprawdzono", "Sprawdzanie zostało przerwane. Nie wysłano tworzenia."
                )
                for o in self.oferty[len(self.plany) :]
            )
            self._pokaz_plan()
            self.info.setText(
                f"Sprawdzono {len(self.plany)} pozycji. "
                f"Gotowe: {sum(not p.bledy for p in self.plany)}. "
                "Wymagania warunkowe i gotowość do "
                f"sprzedaży ostatecznie ocenia Allegro."
            )

        self._zadanie(zadanie, gotowe)

    def _komorka(self, row: int, col: int) -> QTableWidgetItem:
        item = self.tabela.item(row, col)
        if item is None:
            item = QTableWidgetItem()
            self.tabela.setItem(row, col, item)
        return item

    def _pokaz_plan(self) -> None:
        for i, p in enumerate(self.plany):
            self._komorka(i, 2).setText(
                ("Nowy produkt • " if p.ustawienia.nowy else "") + p.produkt.nazwa
                if p.produkt
                else "Wybierz lub utwórz produkt"
            )
            self._komorka(i, 2).setToolTip(
                f"{p.produkt.nazwa}\n{p.produkt.id}" if p.produkt else ""
            )
            self._komorka(i, 1).setText(p.oferta.tytul)
            self._komorka(i, 1).setToolTip(p.oferta.tytul)
            self._komorka(i, 6).setText(str(p.ustawienia.ilosc))
            self._komorka(i, 3).setText(
                (p.ustawienia.cena or p.oferta.cena) + " " + p.ustawienia.waluta
            )
        self._pokaz_wyniki()
        self._filtruj()

    def _pokaz_wyniki(self) -> None:
        for i, w in enumerate(self.wyniki):
            item = self._komorka(i, 4)
            item.setData(Qt.ItemDataRole.AccessibleTextRole, w.stan)
            if w.stan == "Gotowa do utworzenia":
                item.setText("")
                znak = QLabel()
                znak.setPixmap(ikona("aktywne", "#55B294").pixmap(24, 24))
                znak.setAlignment(Qt.AlignmentFlag.AlignCenter)
                znak.setAccessibleName("Gotowa do utworzenia szkicu")
                znak.setToolTip("Gotowa do utworzenia szkicu. " + w.komunikat)
                self.tabela.setCellWidget(i, 4, znak)
            else:
                poprzedni = self.tabela.cellWidget(i, 4)
                if poprzedni is not None:
                    poprzedni.hide()
                self.tabela.removeCellWidget(i, 4)
                item.setText(w.stan)
            self._komorka(i, 4).setToolTip(w.komunikat)
            self._komorka(i, 5).setText(w.ident)

    def wybierz_produkt(self) -> None:
        i = self.tabela.currentRow()
        if not 0 <= i < len(self.oferty) or self.trwa or self.nieaktualny:
            return
        d = QDialog(self)
        d.setWindowTitle("Wybierz istniejący produkt z Katalogu Allegro")
        d.resize(700, 240)
        layout = QVBoxLayout(d)
        fraza = QLineEdit(self.oferty[i].ean or self.oferty[i].tytul)
        fraza.setAccessibleName("EAN lub nazwa produktu Allegro")
        search = QPushButton("Szukaj w Katalogu Allegro")
        wybor = QComboBox()
        wybor.setAccessibleName("Wyniki wyszukiwania produktów Allegro")
        info = etykieta("Wybór nie tworzy ani nie zmienia produktu w katalogu.")
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Wybierz")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
        for widget in (fraza, search, wybor, info, buttons):
            layout.addWidget(widget)

        def szukaj() -> None:
            query = fraza.text().strip()
            self.trwa = True
            self._przyciski()
            d.setEnabled(False)

            def gotowe(w: object) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                wybor.clear()
                for p in cast(tuple[ProduktSzkicu, ...], w):
                    wybor.addItem(p.nazwa + " • " + p.id, p.id)
                buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(wybor.count() > 0)
                info.setText("Wybierz właściwy produkt. Dla kolejnych wyników zawęź wyszukiwanie.")

            def blad(k: str, m: str) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                info.setText(m)

            self.uruchom(lambda: self.serwis.api.znajdz_produkty(self.sesja, query), gotowe, blad)

        def wybierz() -> None:
            if self.nieaktualny:
                d.reject()
                return
            self.ustawienia[i] = replace(
                self._ustawienia(i),
                produkt=str(wybor.currentData()),
                wartosci=(),
                nowy=False,
                kategoria="",
                zrodla=(),
            )
            d.accept()
            self.uniewaznij()
            self.przygotuj()

        search.clicked.connect(szukaj)
        buttons.accepted.connect(wybierz)
        buttons.rejected.connect(d.reject)
        d.exec()

    def _zastosuj_kategorie(
        self, i: int, kategoria: str, wszystkie: bool, wiersze: tuple[int, ...] = ()
    ) -> None:
        for row in range(len(self.oferty)):
            u = self._ustawienia(row)
            dopasowany = (
                row < len(self.plany)
                and self.plany[row].produkt is not None
                and not self.plany[row].ustawienia.nowy
            )
            if row == i or row in wiersze or (wszystkie and not u.produkt and not dopasowany):
                self.ustawienia[row] = replace(
                    u, nowy=True, kategoria=kategoria, produkt="", wartosci=(), zrodla=()
                )
        self.uniewaznij()
        self.przygotuj()

    def nowy_produkt(self) -> None:
        i = self.tabela.currentRow()
        if not 0 <= i < len(self.oferty) or self.trwa or self.nieaktualny:
            self.info.setText("Zaznacz pozycję, dla której chcesz przygotować nowy produkt.")
            return
        rows = self.wybrane()
        d = QDialog(self)
        d.setWindowTitle("Nowy produkt • wybierz kategorię Allegro")
        d.resize(850, 320)
        layout = QVBoxLayout(d)
        layout.addWidget(
            etykieta(
                "To przygotuje zgłoszenie do Katalogu Allegro. "
                "Wysłanie wymaga późniejszego potwierdzenia."
            )
        )
        fraza = QLineEdit(self.oferty[i].tytul)
        fraza.setAccessibleName("Nazwa produktu lub kategorii")
        szukaj = QPushButton("Znajdź kategorie")
        wybor = QComboBox()
        wybor.setAccessibleName("Kategoria nowego produktu Allegro")
        razem = QCheckBox("Zastosuj kategorię do wszystkich pozycji bez produktu Allegro")
        info = etykieta(
            f"Wybrany zakres: {len(rows) or 1} pozycji. "
            "Program pobierze wymagane parametry kategorii."
        )
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        ok = buttons.button(QDialogButtonBox.StandardButton.Ok)
        ok.setText("Wybierz kategorię")
        ok.setEnabled(False)
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        for widget in (fraza, szukaj, wybor, razem, info, buttons):
            layout.addWidget(widget)

        def search() -> None:
            query = fraza.text().strip()
            self.trwa = True
            self._przyciski()
            d.setEnabled(False)

            def gotowe(w: object) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                wybor.clear()
                wybor.addItem("Wybierz kategorię…", "")
                for k in cast(tuple[KategoriaSzkicu, ...], w):
                    wybor.addItem(k.nazwa + " • " + k.id, k.id)
                info.setText(
                    "Wybierz kategorię z listy."
                    if wybor.count() > 1
                    else "Brak kategorii. Zmień wyszukiwaną nazwę."
                )

            def blad(k: str, opis: str) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                info.setText(opis)

            self.uruchom(lambda: self.serwis.api.kategorie(self.sesja, query), gotowe, blad)

        wybor.currentIndexChanged.connect(lambda: ok.setEnabled(bool(wybor.currentData())))
        szukaj.clicked.connect(search)
        buttons.accepted.connect(d.accept)
        buttons.rejected.connect(d.reject)
        if d.exec() == QDialog.DialogCode.Accepted and not self.nieaktualny and wybor.currentData():
            self._zastosuj_kategorie(i, str(wybor.currentData()), razem.isChecked(), rows)

    def _zastosuj_parametry(
        self,
        i: int,
        cena: str,
        wartosci: tuple[tuple[str, str], ...],
        zrodla: tuple[tuple[str, str], ...],
        wszystkie: bool,
    ) -> None:
        p = self.plany[i]
        self.ustawienia[i] = replace(p.ustawienia, cena=cena, wartosci=wartosci, zrodla=zrodla)
        if wszystkie and p.ustawienia.nowy:
            for row in range(len(self.oferty)):
                u = self._ustawienia(row)
                if row != i and u.nowy and u.kategoria == p.ustawienia.kategoria:
                    self.ustawienia[row] = replace(u, wartosci=wartosci, zrodla=zrodla)
        self.uniewaznij()
        self.przygotuj()

    def uzupelnij(self, masowo: bool = False) -> None:
        i = self.tabela.currentRow()
        wybrane = self.wybrane()
        if masowo and wybrane and i not in wybrane:
            i = wybrane[0]
        if not 0 <= i < len(self.plany) or self.trwa:
            return
        p = self.plany[i]
        if p.produkt is None:
            if masowo:
                self.info.setText("Najpierw wybierz kategorię lub produkt i sprawdź paczkę.")
                return
            self.wybierz_produkt()
            return
        rows = self.wybrane() if masowo else (i,)
        if masowo and (
            not rows
            or any(
                row >= len(self.plany)
                or self.plany[row].produkt is None
                or cast(ProduktSzkicu, self.plany[row].produkt).kategoria != p.produkt.kategoria
                or self.plany[row].ustawienia.nowy != p.ustawienia.nowy
                for row in rows
            )
        ):
            self.info.setText(
                "Parametry zbiorcze wymagają tej samej kategorii i trybu produktu. "
                "Wybierz zgodne pozycje."
            )
            return
        d = QDialog(self)
        d.setWindowTitle("Uzupełnij dane szkicu • " + p.oferta.sku)
        d.resize(700, 600)
        outer = QVBoxLayout(d)
        outer.addWidget(etykieta(p.produkt.nazwa + " • kategoria " + p.produkt.kategoria))
        tabs = QTabWidget()
        outer.addWidget(tabs, 1)
        forms = []
        for nazwa in ("Wymagane", "Dodatkowe"):
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            host = QWidget()
            form = QFormLayout(host)
            form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
            form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
            scroll.setWidget(host)
            tabs.addTab(scroll, nazwa)
            forms.append(form)
        form = forms[0]
        outer.insertWidget(
            1,
            etykieta(
                "SKU i EAN są pobierane z każdej pozycji paczki. Uzupełnij "
                "wymagane pola; pozostałe są w Dodatkowe."
            ),
        )
        advanced = QCheckBox("Zaawansowane: zmień źródła wartości")
        source_rows: list[tuple[QFormLayout, QWidget]] = []
        cena = QLineEdit(p.ustawienia.cena or p.oferta.cena)
        cena.setObjectName("cena_szkicu")
        if not masowo:
            form.addRow("Cena brutto (" + p.ustawienia.waluta + ")", cena)
        else:
            outer.addWidget(
                etykieta(
                    f"Zaznaczono {len(rows)} pozycji. "
                    "Zaznacz wyłącznie parametry do wspólnej zmiany."
                )
            )
        zmieniane: dict[str, QCheckBox] = {}
        pola: dict[str, QComboBox | QLineEdit] = {}
        zrodla: dict[str, QComboBox] = {}
        for req in p.produkt.parametry:
            produktowy = req.produktowy or (p.ustawienia.nowy and req.wymagany_produkt)
            wymagany = req.wymagany or (produktowy and req.wymagany_produkt)
            form = forms[0 if wymagany else 1]
            if req.produktowy and not p.ustawienia.nowy:
                continue
            value = dict(p.ustawienia.wartosci).get(req.id, "")
            if req.typ == "dictionary":
                pole = QComboBox()
                pole.addItem("Wybierz wartość", "")
                for ident, nazwa in req.slownik:
                    pole.addItem(nazwa, ident)
                pole.setCurrentIndex(max(0, pole.findData(value)))
                pola[req.id] = pole
            else:
                tekst = QLineEdit(value)
                tekst.setMaxLength(1000)
                pola[req.id] = tekst
            pola[req.id].setAccessibleName(req.nazwa)
            pola[req.id].setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            if isinstance(pola[req.id], QComboBox):
                box = cast(QComboBox, pola[req.id])
                box.setMinimumContentsLength(18)
                box.setSizeAdjustPolicy(
                    QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
                )
            produktowy = req.produktowy or (p.ustawienia.nowy and req.wymagany_produkt)
            wymagany = req.wymagany or (produktowy and req.wymagany_produkt)
            nazwa = req.nazwa + (" *" if wymagany else "")
            if masowo:
                check = QCheckBox(nazwa)
                zmieniane[req.id] = check
                form.addRow(check, pola[req.id])
            else:
                label = QLabel(nazwa)
                label.setWordWrap(True)
                label.setToolTip("Parametr produktu" if produktowy else "Parametr oferty")
                form.addRow(label, pola[req.id])
            if p.ustawienia.nowy and req.typ != "dictionary":
                source = QComboBox()
                source.setAccessibleName("Źródło parametru " + req.nazwa)
                jawny_kod = domyslne_zrodlo(req) == "sku"
                if jawny_kod:
                    source.addItem("Z paczki — SKU każdego produktu", "sku")
                    source.addItem(
                        "Wpisz ręcznie — wspólna wartość" if masowo else "Wpisz ręcznie", ""
                    )
                    if dict(p.ustawienia.zrodla).get(req.id) == "ean":
                        source.addItem("EAN z paczki — wcześniejsze ustawienie", "ean")
                else:
                    source.addItem("Wspólna wartość wpisana powyżej", "")
                    source.addItem("SKU z każdej pozycji paczki", "sku")
                    source.addItem("EAN z każdej pozycji paczki", "ean")
                source.setCurrentIndex(
                    max(0, source.findData(dict(p.ustawienia.zrodla).get(req.id, "")))
                )
                widget = pola[req.id]
                widget.setEnabled(not bool(source.currentData()))
                source.currentIndexChanged.connect(
                    lambda _i, combo=source, control=widget: control.setEnabled(
                        not bool(combo.currentData())
                    )
                )
                if masowo:
                    checkbox = zmieniane[req.id]
                    source.activated.connect(
                        lambda _idx, checkbox=checkbox: checkbox.setChecked(True)
                    )
                    source.currentIndexChanged.connect(
                        lambda _idx, checkbox=checkbox: (
                            checkbox.setChecked(True) if checkbox else None
                        )
                    )
                    if isinstance(widget, QLineEdit):
                        widget.textEdited.connect(
                            lambda _text, checkbox=checkbox: (
                                checkbox.setChecked(True) if checkbox else None
                            )
                        )
                widget.setToolTip(
                    (
                        "Wybierz poniżej wpisanie ręczne albo SKU z każdej pozycji paczki."
                        if jawny_kod
                        else "Wartość z bieżącej pozycji. Dla każdej oferty pobierana osobno. "
                        "Źródło zmienisz w Zaawansowane."
                    )
                    if source.currentData()
                    else ""
                )
                zrodla[req.id] = source
                source.setMinimumContentsLength(18)
                source.setSizeAdjustPolicy(
                    QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
                )
                form.addRow("Sposób uzupełniania" if jawny_kod else "Źródło", source)
                if not jawny_kod:
                    form.setRowVisible(source, False)
                    source_rows.append((form, source))
        advanced.toggled.connect(
            lambda visible: [f.setRowVisible(w, visible) for f, w in source_rows]
        )
        outer.addWidget(advanced)
        outer.addWidget(
            etykieta(
                "* Parametry wymagane. Ograniczenia i wymagania warunkowe "
                "dodatkowo sprawdza Allegro. GPSR i dostawę ustawisz przyciskiem "
                "„GPSR, dostawa i warunki…” w głównym oknie."
            )
        )
        razem = QCheckBox("Zastosuj parametry i źródła do nowych produktów w tej samej kategorii")
        razem.setObjectName("stosuj_parametry_wspolne")
        razem.setVisible(p.ustawienia.nowy and not masowo)
        outer.addWidget(razem)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Zastosuj")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.accepted.connect(d.accept)
        buttons.rejected.connect(d.reject)
        outer.addWidget(buttons)
        if d.exec() == QDialog.DialogCode.Accepted:
            wartosci = tuple(
                (ident, str(w.currentData()) if isinstance(w, QComboBox) else w.text())
                for ident, w in pola.items()
            )
            sources = tuple(
                (ident, str(w.currentData())) for ident, w in zrodla.items() if w.currentData()
            )
            if masowo:
                chosen = {ident for ident, check in zmieniane.items() if check.isChecked()}
                if not chosen:
                    self.info.setText("Nie zaznaczono parametrów do zmiany.")
                    return
                for row in rows:
                    self.ustawienia[row] = zmien_parametry(
                        self._ustawienia(row),
                        tuple(v for v in wartosci if v[0] in chosen),
                        tuple(v for v in sources if v[0] in chosen),
                    )
                self.uniewaznij()
                self.przygotuj()
            else:
                self._zastosuj_parametry(
                    i, cena.text().strip(), wartosci, sources, razem.isChecked()
                )

    def sprawdz_duplikaty(self) -> None:
        if self.kontrola_duplikatow is None:
            self.info.setText("Sprawdzanie konta jest niedostępne. Otwórz okno z programu VexLab.")
            return
        rows = self.wybrane() or tuple(
            i for i in range(len(self.oferty)) if not self.tabela.isRowHidden(i)
        )
        kontrola = self.kontrola_duplikatow

        def gotowe(w: object) -> None:
            matches = cast(tuple[tuple[IstniejacaOferta, ...], ...], w)
            if self.nieaktualny:
                return
            self.duplikaty.update(zip(rows, matches, strict=True))
            wyniki = (
                list(self.wyniki)
                if len(self.wyniki) == len(self.oferty)
                else [WynikTworzenia(o.sku, "Nie sprawdzono", "") for o in self.oferty]
            )
            for row, items in zip(rows, matches, strict=True):
                if items:
                    wyniki[row] = WynikTworzenia(
                        self.oferty[row].sku,
                        "Już na Allegro",
                        opis_duplikatow(items),
                        items[0].ident,
                    )
                elif wyniki[row].stan == "Już na Allegro":
                    p = self.plany[row] if row < len(self.plany) else None
                    wyniki[row] = WynikTworzenia(
                        self.oferty[row].sku,
                        "Gotowa do utworzenia" if p and not p.bledy else "Nie sprawdzono",
                        "Nie znaleziono dopasowania na koncie.",
                    )
            self.wyniki = tuple(wyniki)
            self._pokaz_wyniki()
            self.info.setText(
                f"Sprawdzono konto: {len(rows)} pozycji. "
                f"Znaleziono istniejące oferty dla {sum(bool(x) for x in matches)} pozycji. "
                "Znalezione pozycje zostaną pominięte. Wybierz wiersz, aby zobaczyć ID i status."
            )

        self._zadanie(
            lambda: kontrola.sprawdz(self.sesja, tuple(self.oferty[i] for i in rows)), gotowe
        )

    def tworz(self) -> None:
        rows = self.zakres_wysylki()
        gotowe = sum(self._mozna_wyslac(i) for i in rows if i < len(self.plany))
        if not gotowe or self.nieaktualny or self.trwa:
            return
        nowych = sum(
            not p.bledy and p.ustawienia.nowy for i, p in enumerate(self.plany) if i in rows
        )
        katalog = (
            f"\nUWAGA: dla {nowych} pozycji wyślesz definicje NOWYCH PRODUKTÓW "
            "do Katalogu Allegro. "
            "Allegro może utworzyć produkty lub dopasować istniejące. "
            "Potwierdzasz także ten skutek katalogowy.\n"
            if nowych
            else ""
        )
        if (
            QMessageBox.question(
                self,
                "Utwórz nowe szkice Allegro",
                f"Konto: {self.sesja.konto.login}\nŚrodowisko: "
                f"{self.sesja.srodowisko.value}\n\nUtworzyć {gotowe} nowych "
                f"szkiców INACTIVE? Pozostałe pozycje zostaną pominięte.\nWaluta: "
                f"{self.waluta.currentData()}, ilość w szkicu: "
                f"według planu. Zakres: {len(rows)} pozycji.\nSprawdź produkty, ceny i "
                f"parametry. Zdjęcia zostaną przesłane do Allegro.\nOferty nie "
                f"zostaną opublikowane do sprzedaży.{katalog}",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            == QMessageBox.StandardButton.Yes
        ):
            self.wyslij(False)

    def wyslij(self, sprawdzenie: bool) -> None:
        if not self.plany or self.nieaktualny or self.trwa:
            return
        plany = self.plany
        rows = self.zakres_wysylki()
        poprzednie = self.wyniki

        def praca() -> tuple[WynikTworzenia, ...]:
            istniejace: dict[int, tuple[IstniejacaOferta, ...]] = {}
            if not sprawdzenie and self.kontrola_duplikatow is not None:
                nowe = tuple(
                    i
                    for i in rows
                    if i < len(plany)
                    and not plany[i].bledy
                    and self.serwis.rejestr.odczytaj(
                        self.serwis.klucz(self.sesja, plany[i].oferta.sku)
                    )
                    is None
                )
                checks = self.kontrola_duplikatow.sprawdz(
                    self.sesja, tuple(plany[i].oferta for i in nowe)
                )
                istniejace = dict(zip(nowe, checks, strict=True))
            wynik = []
            zatrzymano = False
            for i, p in enumerate(plany):
                self.postep.emit(i + 1, p.oferta.sku)
                if i not in rows:
                    wynik.append(
                        poprzednie[i]
                        if i < len(poprzednie)
                        else WynikTworzenia(p.oferta.sku, "Pominięto", "Poza zakresem wysyłki.")
                    )
                elif self.stop.is_set() or zatrzymano:
                    wynik.append(
                        WynikTworzenia(
                            p.oferta.sku, "Wstrzymano", "Nie wykonano kolejnego żądania."
                        )
                    )
                elif istniejace.get(i):
                    items = istniejace[i]
                    wynik.append(
                        WynikTworzenia(
                            p.oferta.sku, "Już na Allegro", opis_duplikatow(items), items[0].ident
                        )
                    )
                elif p.bledy:
                    wynik.append(WynikTworzenia(p.oferta.sku, "Do poprawy", "; ".join(p.bledy)))
                else:
                    try:
                        w = (
                            self.serwis.sprawdz(self.sesja, p)
                            if sprawdzenie
                            else self.serwis.utworz(self.sesja, p, self.stop.is_set)
                        )
                        wynik.append(w)
                        zatrzymano = w.stan in {"Wynik nieznany", "Wymaga sprawdzenia"}
                    except BladAllegro as exc:
                        stan = "Odrzucono" if exc.kod == "ODRZUCONO" else "Wymaga sprawdzenia"
                        ident = ""
                        try:
                            proba = self.serwis.rejestr.odczytaj(
                                self.serwis.klucz(self.sesja, p.oferta.sku)
                            )
                            if proba is not None:
                                ident = proba.ident
                        except (BladAllegro, OSError):
                            pass
                        wynik.append(WynikTworzenia(p.oferta.sku, stan, str(exc), ident))
                        zatrzymano = exc.kod in {
                            "WYGASLA",
                            "AUTORYZACJA",
                            "NIEZNANY",
                            "REJESTR",
                        } or any(f"HTTP {n}" in str(exc) for n in (401, 403, 429))
            wynik.extend(
                WynikTworzenia(
                    o.sku, "Nie sprawdzono", "Pozycja nie została sprawdzona ani wysłana."
                )
                for o in self.oferty[len(plany) :]
            )
            return tuple(wynik)

        def gotowe(w: object) -> None:
            self.wyniki = cast(tuple[WynikTworzenia, ...], w)
            self._pokaz_wyniki()
            wskazane = tuple(w for i, w in enumerate(self.wyniki) if i in rows)
            self.podsumowanie.setText(podsumuj_wysylke(wskazane))
            self.podsumowanie.show()
            liczby = Counter(w.stan for w in self.wyniki)
            self.info.setText(
                " • ".join(f"{nazwa}: {ile}" for nazwa, ile in liczby.items())
                + ". Zachowaj raport. Niepotwierdzony wynik sprawdź przyciskiem "
                "„Sprawdź wyniki wysyłki”."
            )

        self._zadanie(praca, gotowe)

    def eksportuj(self) -> None:
        nazwa, _ = QFileDialog.getSaveFileName(
            self, "Zapisz raport", "raport-szkicow-allegro.csv", "CSV (*.csv)"
        )
        if nazwa:
            try:
                zapisz_raport(
                    Path(nazwa), self.wyniki, self.sesja.konto.login, self.sesja.srodowisko.value
                )
            except OSError:
                self.info.setText(
                    "Nie zapisano raportu. Wybierz nową nazwę; istniejące pliki nie są nadpisywane."
                )

    def reject(self) -> None:
        if self.trwa:
            self.stop.set()
            self.info.setText(
                "Zatrzymywanie serii po bieżącym żądaniu. Zaczekaj na raport przed zamknięciem."
            )
            return
        super().reject()
