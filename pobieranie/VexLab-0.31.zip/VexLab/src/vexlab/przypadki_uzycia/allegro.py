"""Połączenie Allegro: autoryzacja, bezpieczne wznowienie i odczyt szkiców."""

from dataclasses import dataclass, field
from enum import Enum
from threading import RLock
from typing import Protocol

from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu
from vexlab.rdzen.kontrakty import BladTechniczny


class SrodowiskoAllegro(Enum):
    PRODUKCJA = "Allegro"
    SANDBOX = "Allegro Sandbox"


class BladAllegro(BladTechniczny):
    def __init__(self, kod: str, komunikat: str) -> None:
        super().__init__(komunikat)
        self.kod = kod


@dataclass(frozen=True)
class AplikacjaAllegro:
    klient: str
    sekret: str = field(repr=False)
    srodowisko: SrodowiskoAllegro = SrodowiskoAllegro.PRODUKCJA

    def sprawdz(self) -> None:
        if not self.klient or not self.sekret or len(self.klient) > 512 or len(self.sekret) > 1024:
            raise BladAllegro("KONFIGURACJA", "Podaj Client ID i Client Secret aplikacji Allegro.")
        if any(ord(c) < 33 for c in self.klient + self.sekret) or ":" in self.klient:
            raise BladAllegro("KONFIGURACJA", "Dane aplikacji zawierają niedozwolone znaki.")


@dataclass(frozen=True)
class KodUrzadzenia:
    kod: str = field(repr=False)
    kod_uzytkownika: str = field(repr=False)
    adres: str = field(repr=False)
    waznosc: int
    odstep: int


@dataclass(frozen=True)
class TokenAllegro:
    wartosc: str = field(repr=False)
    waznosc: int
    odswiezanie: str = field(default="", repr=False)


@dataclass(frozen=True)
class KontoAllegro:
    id: str
    login: str


@dataclass(frozen=True)
class SesjaAllegro:
    konto: KontoAllegro
    srodowisko: SrodowiskoAllegro
    token: str = field(repr=False)
    wygasa: float
    odswiezanie: str = field(default="", repr=False)
    aplikacja: AplikacjaAllegro | None = field(default=None, repr=False)


@dataclass(frozen=True)
class SzkicAllegro:
    id: str
    tytul: str


@dataclass(frozen=True)
class StronaSzkicowAllegro:
    szkice: tuple[SzkicAllegro, ...]
    lacznie: int
    offset: int
    limit: int


@dataclass(frozen=True)
class SzczegolySzkicuAllegro:
    id: str
    tytul: str
    sku: str
    cena: str
    waluta: str
    stan: int | None
    kategoria: str
    zdjecia: tuple[str, ...]
    sekcje: tuple[tuple[ElementPodgladu, ...], ...]


@dataclass(frozen=True)
class ZapamietaneAllegro:
    aplikacja: AplikacjaAllegro = field(repr=False)
    konto: KontoAllegro
    odswiezanie: str = field(repr=False)


class MagazynAllegro(Protocol):
    def odczytaj(self) -> ZapamietaneAllegro | None: ...
    def zapisz(self, dane: ZapamietaneAllegro) -> None: ...
    def usun(self) -> None: ...


class APISesjiAllegro(Protocol):
    def rozpocznij(self, aplikacja: AplikacjaAllegro) -> KodUrzadzenia: ...
    def token(self, aplikacja: AplikacjaAllegro, kod: str) -> TokenAllegro: ...
    def odnow(self, aplikacja: AplikacjaAllegro, token: str) -> TokenAllegro: ...
    def konto(self, srodowisko: SrodowiskoAllegro, token: str) -> KontoAllegro: ...
    def szkice(self, sesja: SesjaAllegro, offset: int, limit: int) -> StronaSzkicowAllegro: ...
    def szkic(self, sesja: SesjaAllegro, id_szkicu: str) -> SzczegolySzkicuAllegro: ...


class CzasMonotoniczny(Protocol):
    def teraz(self) -> float: ...


class PolaczAllegro:
    def __init__(
        self, api: APISesjiAllegro, czas: CzasMonotoniczny, magazyn: MagazynAllegro | None = None
    ) -> None:
        self._api, self._czas, self._magazyn = api, czas, magazyn
        self._blokada = RLock()

    @property
    def mozna_zapamietac(self) -> bool:
        return self._magazyn is not None

    def zapamietaj(self, sesja: SesjaAllegro) -> None:
        with self._blokada:
            if self._magazyn is None or sesja.aplikacja is None or not sesja.odswiezanie:
                raise BladAllegro("MAGAZYN", "Nie można zapamiętać tego połączenia.")
            self._magazyn.zapisz(
                ZapamietaneAllegro(sesja.aplikacja, sesja.konto, sesja.odswiezanie)
            )

    def zapomnij(self) -> None:
        with self._blokada:
            if self._magazyn is not None:
                self._magazyn.usun()

    def przywroc(self) -> SesjaAllegro | None:
        with self._blokada:
            if self._magazyn is None:
                return None
            zapis = self._magazyn.odczytaj()
            if zapis is None:
                return None
            poczatek = self.teraz()
            token = self._api.odnow(zapis.aplikacja, zapis.odswiezanie)
            # Refresh token może rotować: zapis przed /me chroni nowy token
            # również wtedy, gdy sam odczyt profilu chwilowo się nie powiedzie.
            nowy = token.odswiezanie or zapis.odswiezanie
            self._magazyn.zapisz(ZapamietaneAllegro(zapis.aplikacja, zapis.konto, nowy))
            konto = self._api.konto(zapis.aplikacja.srodowisko, token.wartosc)
            if konto.id != zapis.konto.id:
                raise BladAllegro("KONTO", "Allegro zwróciło inne konto. Usuń zapisane połączenie.")
            wygasa = poczatek + token.waznosc
            if self.teraz() >= wygasa:
                raise BladAllegro("WYGASLA", "Sesja wygasła. Ponów połączenie.")
            return SesjaAllegro(
                konto, zapis.aplikacja.srodowisko, token.wartosc, wygasa, nowy, zapis.aplikacja
            )

    def teraz(self) -> float:
        return self._czas.teraz()

    def rozpocznij(self, aplikacja: AplikacjaAllegro) -> KodUrzadzenia:
        aplikacja.sprawdz()
        return self._api.rozpocznij(aplikacja)

    def sprawdz(self, aplikacja: AplikacjaAllegro, kod: str) -> SesjaAllegro:
        aplikacja.sprawdz()
        poczatek = self.teraz()
        token = self._api.token(aplikacja, kod)
        wygasa = poczatek + token.waznosc
        konto = self._api.konto(aplikacja.srodowisko, token.wartosc)
        if self.teraz() >= wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        return SesjaAllegro(
            konto, aplikacja.srodowisko, token.wartosc, wygasa, token.odswiezanie, aplikacja
        )

    def szkice(self, sesja: SesjaAllegro, offset: int = 0, limit: int = 50) -> StronaSzkicowAllegro:
        if self.teraz() >= sesja.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        if limit != 50 or offset < 0 or offset > 9950 or offset % limit:
            raise BladAllegro("STRONA", "Nieprawidłowa strona szkiców Allegro.")
        return self._api.szkice(sesja, offset, limit)

    def szkic(self, sesja: SesjaAllegro, id_szkicu: str) -> SzczegolySzkicuAllegro:
        if self.teraz() >= sesja.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        if not id_szkicu.isascii() or not id_szkicu.isdigit() or len(id_szkicu) > 100:
            raise BladAllegro("SZKIC", "Nieprawidłowy identyfikator szkicu Allegro.")
        wynik = self._api.szkic(sesja, id_szkicu)
        if self.teraz() >= sesja.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        return wynik


@dataclass(frozen=True)
class OdpowiedzAllegro:
    status: int
    dane: bytes = field(repr=False)


class TransportAllegro(Protocol):
    def wyslij(
        self, metoda: str, url: str, naglowki: dict[str, str], dane: bytes | None
    ) -> OdpowiedzAllegro: ...
