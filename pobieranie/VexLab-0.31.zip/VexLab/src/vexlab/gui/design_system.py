"""Wspólne tokeny i ikony własne. UI-REF-01 pozostaje wzorcem układu."""

from pathlib import Path

from PySide6.QtCore import QByteArray, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPalette, QPixmap
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QApplication

from vexlab.przypadki_uzycia.powloka import Motyw

SCIEZKI = {
    "widok_kafelki": "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
    "widok_lista": "M8 5h13 M8 12h13 M8 19h13 M3 5h.1 M3 12h.1 M3 19h.1",
    "wiecej": "M4 12h.1 M12 12h.1 M20 12h.1",
    "dodaj": "M12 4v16 M4 12h16",
    "edytuj": "M15 4l5 5 M4 16L17 3l4 4L8 20l-5 1z",
    "kopiuj": "M8 8h13v13H8z M16 8V3H3v13h5",
    "filtr": "M3 4h18l-7 8v7l-4 2v-9z",
    "powrot": "M20 12H4 M10 6l-6 6 6 6",
    "pobierz": "M12 3v12 M7 10l5 5 5-5 M4 15v6h16v-6",
    "dashboard": "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
    "produkt": "M3 7l9-5 9 5v10l-9 5-9-5z M3 7l9 5 9-5 M12 12v10 M7 4l10 6",
    "oferta": "M3 3h9l9 9-9 9-9-9z M7 7h.01",
    "plik": "M5 2h9l5 5v15H5z M14 2v6h5 M8 12h8 M8 16h6",
    "ustawienia": "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M12 2v3 M12 19v3 M2 12h3 "
    "M19 12h3 M5 5l2 2 M17 17l2 2 M5 19l2-2 M17 7l2-2",
    "wykres": "M3 3v18h18 M7 15l4-5 4 3 6-8",
    "synchronizacja": "M20 7a9 9 0 0 0-15-2L2 8 M2 3v5h5 M4 17a9 9 0 0 0 15 2l3-3 M22 21v-5h-5",
    "szukaj": "M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14 M15 15l7 7",
    "blad": "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18 M12 7v6 M12 16v1",
    "uzytkownik": "M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M4 22v-3a8 8 0 0 1 16 0v3",
}


# Wspólna paleta kafelków i menu; przyciemniona na życzenie właściciela.
PALETA_KPI = {
    "produkty": ("#1E3C5F", "#1C3657", "#1C3354", "#61A7E5", "#518AC9"),
    "aktywne": ("#1F5043", "#1D4B41", "#1F4842", "#62C8A1", "#55B294"),
    "szkice": ("#573A2D", "#543C2F", "#543E33", "#DDA876", "#C28A68"),
    "bledy": ("#3D2B55", "#372752", "#33274F", "#AF82E0", "#9568C3"),
}


SCIEZKI.update(
    {
        "cennik": "M6 3h12v18l-3-2-3 2-3-2-3 2z M9 7h6 M9 11h2 M14 11h1 M9 15h6",
        "producent": "M3 21V9l6 3V7l6 5V3h4l2 18z M6 16h2 M11 16h2 M16 16h2",
        "media": "M3 4h18v16H3z M3 16l5-5 4 4 3-3 6 6 M16 7h.01",
        "ai": "M12 2l2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z M20 2v4 M18 4h4",
        "szkic": "M5 3h9l4 4v4 M5 3v18h6 M14 3v5h5 M11 19l8-8 3 3-8 8-4 1z",
        "aktywne": "M21 11v1a9 9 0 1 1-5.3-8.2 M8 11l4 4L22 4",
        "masowa": "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M15 17l3 3 5-6",
        "zmiana_cen": "M3 18l6-6 4 3 8-10 M15 5h6v6 M3 22h18",
        "szablon": "M3 3h18v18H3z M3 9h18 M10 9v12",
        "kolejka": "M3 5h12 M3 10h8 M3 15h7 M17 11a5 5 0 1 0 0 10 5 5 0 0 0 0-10 M17 13v3l2 1",
        "raport": "M5 2h10l4 4v16H5z M15 2v5h5 M8 18v-4 M12 18V9 M16 18v-6",
        "historia": "M3 10a9 9 0 1 1 1 8 M3 4v6h6 M12 7v6l4 2",
        "statystyki": "M11 3a9 9 0 1 0 10 10H11z M15 2v7h7a9 9 0 0 0-7-7",
        "pomoc": "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18 M9 9a3 3 0 0 1 6 0c0 2-3 2-3 5 M12 17h.01",
    }
)

IKONY_MENU = {
    "Dashboard": ("dashboard", "#7FAEFF", "#2162C5"),
    "Produkty": ("produkt", "#52C9D4", "#087A87"),
    "Cenniki": ("cennik", "#E8BE6A", "#996714"),
    "Producenci": ("producent", "#B9A0F3", "#7D4DB4"),
    "Zdjęcia i media": ("media", "#F0A3BE", "#B83B73"),
    "Kreator opisów (AI)": ("ai", "#B59BF8", "#8052C7"),
    "Nowe oferty": ("oferta", "#6DDDD6", "#077E7D"),
    "Szkice": ("szkic", "#F0C47D", "#9C6B24"),
    "Aktywne oferty": ("aktywne", "#82D5A2", "#247C4D"),
    "Masowa edycja": ("masowa", "#9BAAFF", "#5366C4"),
    "Zmiana cen": ("zmiana_cen", "#F2B578", "#B96819"),
    "Szablony układów": ("szablon", "#DBA3ED", "#9954AE"),
    "Synchronizacja": ("synchronizacja", "#74CDE7", "#137B99"),
    "Kolejka zadań": ("kolejka", "#8CB6E8", "#416DA8"),
    "Raporty": ("raport", "#82D6C4", "#177D6E"),
    "Historia operacji": ("historia", "#DDBE87", "#926B31"),
    "Statystyki": ("statystyki", "#B7ABF5", "#6F58B7"),
    "Ustawienia": ("ustawienia", "#B5C4D8", "#52637C"),
    "Pomoc i poradnik": ("pomoc", "#8FC7F1", "#347EB3"),
}


def ikona_menu(nazwa: str, ciemny: bool) -> QIcon:
    if nazwa in {"Allegro", "PrestaShop"}:
        plik = "allegro.svg" if nazwa == "Allegro" else "prestashop.svg"
        return QIcon(str(Path(__file__).with_name("zasoby") / plik))
    symbol, jasniejszy, ciemniejszy = IKONY_MENU.get(nazwa, ("plik", "#B5C4D8", "#52637C"))
    kolor = jasniejszy if ciemny else ciemniejszy
    svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">'
        f'<rect x="1" y="1" width="22" height="22" rx="6" fill="{kolor}" opacity=".12"/>'
        f'<path d="{SCIEZKI[symbol]}" fill="none" stroke="{kolor}" stroke-width="1.8" '
        'stroke-linecap="round" stroke-linejoin="round"/></svg>'
    )
    renderer = QSvgRenderer(QByteArray(svg.encode()))
    pixmap = QPixmap(48, 48)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    renderer.render(painter)
    painter.end()
    pixmap.setDevicePixelRatio(2)
    return QIcon(pixmap)


def ikona(nazwa: str, kolor: str = "#A3AEC1") -> QIcon:
    sciezka = SCIEZKI.get(nazwa, SCIEZKI["plik"])
    svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">'
        f'<path d="{sciezka}" fill="none" stroke="{kolor}" stroke-width="1.7" '
        'stroke-linecap="round" stroke-linejoin="round"/></svg>'
    )
    renderer = QSvgRenderer(QByteArray(svg.encode()))
    pixmap = QPixmap(48, 48)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    renderer.render(painter)
    painter.end()
    pixmap.setDevicePixelRatio(2)
    return QIcon(pixmap)


def logo_aplikacji() -> QIcon:
    return QIcon(str(Path(__file__).with_name("zasoby") / "vexlabs.png"))


def styl_grup_menu(ciemny: bool) -> str:
    # Tak jak kafelki KPI: ta sama paleta i biały tekst w obu motywach.
    warianty = {
        "PRODUKTY": "produkty",
        "OFERTY": "aktywne",
        "SPRZEDAŻ": "szkice",
        "ANALITYKA": "produkty",
        "NARZĘDZIA": "bledy",
    }
    style = []
    for grupa, wariant in warianty.items():
        gora, srodek, dol, poswiata, obrys = PALETA_KPI[wariant]
        tlo = (
            f"qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {gora}, stop:0.55 {srodek}, stop:1 {dol})"
        )
        hover = QColor(srodek).lighter(112).name()
        selektor = f'QToolButton#grupaMenu[grupa="{grupa}"]'
        style.append(f"""
            {selektor} {{ background: {tlo}; color: #FFFFFF; border-color: {obrys}; }}
            {selektor}:hover {{ background: {hover}; border-color: {poswiata}; }}
            {selektor}:checked {{ background: {tlo}; border-color: {poswiata}; }}
            {selektor}:pressed {{ background: {srodek}; border-color: #FFFFFF; }}
            {selektor}:focus {{ border: 2px solid #FFFFFF; padding: 7px 6px; }}
        """)
    return "\n".join(style)


def zastosuj_motyw(app: QApplication, motyw: Motyw) -> None:
    if not app.property("styl_vexlab"):
        app.setStyle("Fusion")
        app.setProperty("styl_vexlab", True)
    ciemny = motyw == Motyw.CIEMNY or (
        motyw == Motyw.SYSTEMOWY and app.styleHints().colorScheme() == Qt.ColorScheme.Dark
    )
    if ciemny:
        tlo, panel, kontrolka, tekst, opis, linia = (
            "#121923",
            "#1C2533",
            "#202C3C",
            "#EDF2FA",
            "#AEBBD0",
            "#354255",
        )
        powloka, gora_przycisku, dol_przycisku = "#17202D", "#223145", "#1C2939"
        aktywne_tlo, zaznaczenie, wybrany_tekst = "#303E52", "#254650", "#F1FAFC"
        stopka_przycisku, pole, naprowadzenie = "#1A2331", "#182231", "#253549"
    else:
        tlo, panel, kontrolka, tekst, opis, linia = (
            "#F1F4F9",
            "#FFFFFF",
            "#F7F9FC",
            "#17263A",
            "#52637C",
            "#D9E1ED",
        )
        powloka, gora_przycisku, dol_przycisku = "#EAF0F7", "#FFFFFF", "#F8FAFD"
        aktywne_tlo, zaznaczenie, wybrany_tekst = "#EDF2F8", "#DCECF0", "#163F4B"
        stopka_przycisku, pole, naprowadzenie = "#BBC8D9", "#FFFFFF", "#EDF4F8"
    ostrzezenie = "#F4C678" if ciemny else "#865011"
    akcent = "#E0B967" if ciemny else "#AC7D29"
    fokus_primary = "#96D0FF" if ciemny else "#075BA7"
    obrys_przycisku = "#2C3D52" if ciemny else "#D5DFEC"
    hover_przycisku = "#2A3D55" if ciemny else "#EDF5FF"
    nacisniety_przycisk = "#182638" if ciemny else "#DEECFC"
    niebieski = "#279CFF" if ciemny else "#1674D1"
    paleta = QPalette()
    for rola, kolor in (
        (QPalette.ColorRole.Window, tlo),
        (QPalette.ColorRole.WindowText, tekst),
        (QPalette.ColorRole.Base, pole),
        (QPalette.ColorRole.AlternateBase, kontrolka),
        (QPalette.ColorRole.Text, tekst),
        (QPalette.ColorRole.Button, kontrolka),
        (QPalette.ColorRole.ButtonText, tekst),
        (QPalette.ColorRole.ToolTipBase, panel),
        (QPalette.ColorRole.ToolTipText, tekst),
        (QPalette.ColorRole.Highlight, zaznaczenie),
        (QPalette.ColorRole.HighlightedText, wybrany_tekst),
        (QPalette.ColorRole.PlaceholderText, opis),
        (QPalette.ColorRole.Accent, akcent),
    ):
        paleta.setColor(rola, QColor(kolor))
    for rola in (
        QPalette.ColorRole.Text,
        QPalette.ColorRole.ButtonText,
        QPalette.ColorRole.WindowText,
    ):
        paleta.setColor(QPalette.ColorGroup.Disabled, rola, QColor(opis))
    app.setPalette(paleta)
    zasoby = Path(__file__).with_name("zasoby")
    wariant = "dark" if ciemny else "light"
    dol = (zasoby / f"chevron-down-{wariant}.svg").as_posix()
    gora = (zasoby / f"chevron-up-{wariant}.svg").as_posix()
    check = (zasoby / "check.svg").as_posix()
    style_grup = styl_grup_menu(ciemny)
    app.setStyleSheet(f"""
        QWidget {{ color: {tekst};
            font-family: 'Segoe UI Variable Text', 'Segoe UI', 'Inter', 'DejaVu Sans';
            font-size: 13px; }}
        QMainWindow, QDialog, QWidget#app, QWidget#strona {{ background: {tlo}; }}
        QScrollArea, QStackedWidget {{ border: none; background: transparent; }}
        QScrollArea > QWidget > QWidget {{ background: {tlo}; }}
        QFrame#naglowek {{ background: {powloka}; border: none;
            border-bottom: 1px solid {linia}; }}
        QFrame#nawigacja {{ background: {powloka}; border: none; }}
        QFrame#karta {{ background: {panel}; border: 1px solid {linia}; border-radius: 12px; }}
        QFrame[wariant_kpi] QLabel {{ color: #FFFFFF; background: transparent; }}
        QLabel#kpiTytul {{ font-size: 14px; font-weight: 600; }}
        QLabel#kpiLiczba {{ font-size: 28px; font-weight: 600; }}
        QLabel#kpiPodpis {{ font-size: 12px; font-weight: 400; }}
        QLabel {{ background: transparent; border: none; }}
        QLabel#marka {{ font-family: 'Segoe UI Variable Display', 'Segoe UI', 'DejaVu Sans';
            font-size: 28px; font-weight: 600; }}
        QLabel#tytul {{ font-size: 17px; font-weight: 600; }}
        QLabel#opis {{ color: {opis}; }}
        QLabel#grupa {{ color: {opis}; font-size: 10px; font-weight: 600; }}
        QFrame#sekcjaMenu, QFrame#pozycjeMenu {{ background: transparent; border: none; }}
        QToolButton#grupaMenu {{ background: transparent; border: 1px solid {linia};
            border-radius: 13px; padding: 8px 7px; margin-top: 5px;
            color: {opis}; font-weight: 600; text-align: left; }}
        QToolButton#grupaMenu:hover {{ background: {panel}; color: {tekst}; }}
        QToolButton#grupaMenu:checked {{ background: {panel}; color: {tekst}; }}

        QLabel#liczba {{ font-size: 32px; font-weight: 600; color: #EDF2FA; }}
        QLabel#ostrzezenie {{ color: {ostrzezenie}; }}
        QPushButton, QToolButton {{
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 {gora_przycisku}, stop:1 {dol_przycisku});
            border: 1px solid {obrys_przycisku}; border-radius: 10px;
            font-weight: 400; padding: 9px 14px; min-height: 18px; }}
        QPushButton:hover, QToolButton:hover {{ background: {hover_przycisku};
            border-color: {niebieski}; }}
        QPushButton:pressed, QToolButton:pressed {{ background: {nacisniety_przycisk};
            border-color: {niebieski}; }}
        QPushButton:focus, QToolButton:focus {{ border: 2px solid {niebieski};
            padding: 8px 13px; }}
        QPushButton:disabled, QToolButton:disabled {{ color: {opis}; background: {tlo};
            border-color: {linia}; }}
        QPushButton#primary {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
            stop:0 #078EFF, stop:1 #0576E8); color: #FFFFFF;
            border-color: #1599FF; font-weight: 600; }}
        QPushButton#primary:hover {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
            stop:0 #249EFF, stop:1 #0B84F3); border-color: #65BBFF; }}
        QPushButton#primary:pressed {{ background: #0866CA; border-color: #0759B3; }}
        QPushButton#primary:focus {{ border: 2px solid {fokus_primary}; padding: 8px 13px; }}
        QPushButton#primary:disabled {{ background: {kontrolka}; color: {opis};
            border-color: {linia}; }}
        QPushButton#primary::menu-indicator {{ image: url("{dol}");
            subcontrol-origin: padding; subcontrol-position: center right;
            width: 14px; height: 14px; right: 10px; }}
        QPushButton[pasekAkcji="true"] {{ padding: 10px 18px; min-height: 28px;
            border-radius: 11px; }}
        QPushButton[pasekAkcji="true"]:focus {{ padding: 9px 17px; }}
        QPushButton#kartaAkcji {{ padding: 0; min-height: 54px; border-radius: 10px;
            text-align: left; }}
        QPushButton#kartaAkcji:focus {{ padding: 0; }}
        QPushButton#kartaAkcji QLabel#tytulAkcji {{ font-size: 12px; font-weight: 600; }}
        QPushButton#kartaAkcji QLabel#opisAkcji {{ font-size: 11px; color: {opis}; }}
        QPushButton#kartaAkcji:disabled QLabel {{ color: {opis}; }}
        QWidget#filtryProducentow {{ background: transparent; }}
        QScrollArea#przewijanieProducentow > QWidget > QWidget {{ background: transparent; }}
        QPushButton[chipProducenta="true"] {{ padding: 7px 9px; border-radius: 8px;
            min-height: 18px; font-size: 12px; }}
        QPushButton[chipProducenta="true"]:checked {{ background: #126DCE;
            color: #FFFFFF; border-color: #237DDC; }}
        QPushButton[chipProducenta="true"]:focus {{ padding: 6px 8px; }}
        QToolButton#menuAkcji[chipProducenta="true"] {{ padding: 7px 28px 7px 9px;
            border-radius: 8px; min-height: 18px; font-size: 12px; }}
        QToolButton#menuAkcji[chipProducenta="true"]:focus {{ padding: 6px 27px 6px 8px; }}
        QToolButton:checked {{ background: {zaznaczenie}; border-color: {niebieski}; }}
        QToolButton[kompaktowyFiltr="true"] {{ padding: 0; border-radius: 8px;
            min-width: 34px; max-width: 34px; min-height: 34px; max-height: 34px; }}
        QToolButton[kompaktowyFiltr="true"]:focus {{ padding: 0;
            min-width: 32px; max-width: 32px; min-height: 32px; max-height: 32px; }}
        QToolButton[kompaktowyFiltr="true"]::menu-indicator {{ image: none;
            width: 0; height: 0; }}
        QListView#kafelkiProduktow {{ background: transparent; border: none; }}
        QLineEdit, QComboBox, QSpinBox {{ background: {pole};
            border: 1px solid {linia}; border-bottom: 2px solid {stopka_przycisku};
            border-radius: 7px; padding: 7px 12px; min-height: 18px; }}
        QLineEdit:hover, QComboBox:hover, QSpinBox:hover {{ border-bottom-color: {opis}; }}
        QLineEdit:focus, QComboBox:focus, QSpinBox:focus {{ border-bottom-color: {akcent};
            background: {panel}; }}
        QLineEdit:disabled, QComboBox:disabled, QSpinBox:disabled {{ color: {opis};
            background: {kontrolka}; }}
        QLineEdit, QPlainTextEdit, QTextEdit {{ selection-background-color: {zaznaczenie};
            selection-color: {wybrany_tekst}; }}
        QLineEdit QToolButton {{ background: transparent; border: none;
            padding: 0; margin: 0; min-height: 0; min-width: 0;
            border-radius: 0; }}
        QLineEdit QToolButton:hover, QLineEdit QToolButton:pressed,
        QLineEdit QToolButton:focus {{ background: transparent; border: none;
            padding: 0; margin: 0; }}
        QPlainTextEdit, QTextBrowser, QTextEdit {{ background: {pole}; color: {tekst};
            border: 1px solid {linia}; border-bottom: 2px solid {stopka_przycisku};
            border-radius: 8px; padding: 10px; }}
        QPlainTextEdit:focus, QTextEdit:focus {{ border-bottom-color: {akcent}; }}
        QGroupBox {{ background: transparent; border: 1px solid {linia}; border-radius: 9px;
            margin-top: 14px; padding-top: 12px; }}
        QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 6px;
            font-weight: 600; }}
        QTabWidget::pane {{ background: {panel}; border: 1px solid {linia}; border-radius: 9px; }}
        QTabBar::tab {{ background: transparent; color: {opis};
            border: 1px solid transparent; border-bottom: 2px solid transparent;
            border-top-left-radius: 7px; border-top-right-radius: 7px; padding: 9px 18px; }}
        QTabBar::tab:hover {{ background: {aktywne_tlo}; color: {tekst}; }}
        QTabBar::tab:selected {{ background: {panel}; color: {tekst};
            border-bottom: 2px solid {akcent}; font-weight: 600; }}
        QTabBar::tab:focus {{ border-left-color: {akcent}; border-right-color: {akcent}; }}
        QToolButton#nav {{ background: transparent; border: none;
            border-left: 3px solid transparent; border-radius: 12px;
            text-align: left; padding: 5px 8px; font-weight: 400; }}
        QPushButton#zwinMenu {{ border-radius: 12px; }}
        QToolButton#nav:hover {{ background: {aktywne_tlo}; }}
        QToolButton#nav:checked {{ background: {zaznaczenie}; color: {wybrany_tekst};
            border-left: 3px solid {akcent}; font-weight: 600; }}
        QToolButton#nav:focus {{ border-right: 1px solid {akcent}; }}
        QToolButton#menuAkcji {{ padding-right: 32px; }}
        QToolButton#menuAkcji::menu-indicator {{ image: url("{dol}");
            subcontrol-origin: padding; subcontrol-position: center right;
            width: 14px; height: 14px; right: 8px; }}
        QComboBox {{ padding-right: 32px; }}
        QComboBox::drop-down {{ subcontrol-origin: padding; subcontrol-position: top right;
            width: 28px; border: none; background: transparent; }}
        QComboBox::down-arrow {{ image: url("{dol}"); width: 14px; height: 14px; }}
        QSpinBox {{ padding-right: 28px; }}
        QSpinBox::up-button, QSpinBox::down-button {{ subcontrol-origin: border;
            width: 24px; border: none; background: transparent; }}
        QSpinBox::up-button {{ subcontrol-position: top right; }}
        QSpinBox::down-button {{ subcontrol-position: bottom right; }}
        QSpinBox::up-arrow {{ image: url("{gora}"); width: 12px; height: 12px; }}
        QSpinBox::down-arrow {{ image: url("{dol}"); width: 12px; height: 12px; }}
        QCheckBox, QRadioButton {{ spacing: 8px; }}
        QCheckBox::indicator, QGroupBox::indicator {{ width: 16px; height: 16px;
            border: 1px solid {linia}; border-radius: 4px; background: {pole}; }}
        QCheckBox::indicator:checked, QGroupBox::indicator:checked {{ background: #28616C;
            border-color: #4C8791; image: url("{check}"); }}
        QCheckBox::indicator:focus {{ border: 2px solid {akcent}; }}
        QRadioButton::indicator {{ width: 16px; height: 16px; border-radius: 9px;
            border: 1px solid {opis}; background: {pole}; }}
        QRadioButton::indicator:checked {{ border: 5px solid {akcent};
            width: 8px; height: 8px; background: {pole}; }}
        QComboBox QAbstractItemView, QListWidget {{ background: {panel}; color: {tekst};
            selection-background-color: {zaznaczenie}; selection-color: {wybrany_tekst}; }}
        QListWidget {{ border: 1px solid {linia}; border-radius: 9px; padding: 4px; }}
        QListWidget::item {{ padding: 8px; border-radius: 5px; }}
        QListWidget::item:hover {{ background: {naprowadzenie}; }}
        QListWidget::item:selected {{ background: {zaznaczenie}; color: {wybrany_tekst}; }}
        QListWidget:focus, QTableView:focus {{ border-color: {akcent}; }}
        QTableView {{ background: {panel}; alternate-background-color: {kontrolka};
            border: 1px solid {linia}; border-radius: 9px; gridline-color: {linia};
            selection-background-color: {zaznaczenie}; selection-color: {wybrany_tekst}; }}
        QTableView::item {{ padding: 5px 8px; border: none; }}
        QTableView::item:hover {{ background: {naprowadzenie}; }}
        QTableView::item:selected {{ background: {zaznaczenie}; color: {wybrany_tekst}; }}
        QHeaderView, QTableCornerButton::section {{ background: {kontrolka}; border: none; }}
        QHeaderView::section {{ background: {kontrolka}; color: {opis};
            border: none; border-bottom: 1px solid {linia}; padding: 10px 8px; font-weight: 600; }}
        QMenu {{ background: {panel}; color: {tekst}; border: 1px solid {linia};
            border-radius: 8px; padding: 5px; }}
        QMenu::item {{ border-radius: 5px; padding: 7px 22px; }}
        QMenu::item:selected {{ background: {zaznaczenie}; color: {wybrany_tekst}; }}
        QMenu::item:disabled {{ color: {opis}; }}
        QMenu::separator {{ height: 1px; background: {linia}; margin: 4px 10px; }}
        QStatusBar {{ background: {powloka}; color: {opis}; border-top: 1px solid {linia}; }}
        QStatusBar::item {{ border: none; }}
        QToolTip {{ background: {panel}; color: {tekst}; border: 1px solid {linia};
            border-radius: 6px; padding: 8px; }}
        QProgressBar {{ background: {kontrolka}; color: {tekst};
            border: 1px solid {linia}; border-radius: 5px; text-align: center; }}
        QProgressBar::chunk {{ background: {akcent}; border-radius: 4px; }}
        QScrollBar:horizontal {{ height: 9px; background: transparent; margin: 1px; }}
        QScrollBar::handle:horizontal {{ background: {linia};
            border-radius: 3px; min-width: 28px; }}
        QScrollBar::handle:horizontal:hover {{ background: {opis}; }}
        QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
        QScrollBar:vertical {{ width: 9px; background: transparent; margin: 1px; }}
        QScrollBar::handle:vertical {{ background: {linia}; border-radius: 3px; min-height: 28px; }}
        QScrollBar::handle:vertical:hover {{ background: {opis}; }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
        {style_grup}
    """)
    app.setProperty("motyw_ciemny", ciemny)
    app.setProperty("pasek_tytulu", [ciemny, powloka, tekst])


def kolor_statusu_cennika(stan: str, ciemny: bool) -> QColor | None:
    kolory = {
        "Nowy": ("#82D5A2", "#247C4D"),
        "Aktualny": ("#82D5A2", "#247C4D"),
        "Aktualny / bazowy": ("#82D5A2", "#247C4D"),
        "Inna cena": ("#E8BE6A", "#996714"),
        "Do poprawy": ("#F09B9F", "#AA303B"),
    }
    para = kolory.get(stan)
    return QColor(para[0 if ciemny else 1]) if para else None
