"""Kompaktowe, wyśrodkowane odznaki zgodne z paletą programu."""

from PySide6.QtCore import QModelIndex, QPersistentModelIndex, QRect, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPalette
from PySide6.QtWidgets import QStyledItemDelegate, QStyleOptionViewItem

from vexlab.gui.statusy_zamowien import kolory_odznaki


class OdznakaZamowienia(QStyledItemDelegate):
    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        row = index.data(Qt.ItemDataRole.UserRole)
        if row is None:
            super().paint(painter, option, index)
            return
        ciemny = option.palette.color(QPalette.ColorRole.Base).lightness() < 128
        tlo, tekst, obramowanie = kolory_odznaki(row.realizacja, ciemny)
        font = QFont(option.font)
        font.setPixelSize(11)
        metrics = QFontMetrics(font)
        available = max(0, option.rect.width() - 12)
        text = metrics.elidedText(
            str(index.data() or ""), Qt.TextElideMode.ElideRight, max(0, available - 16)
        )
        width = min(available, metrics.horizontalAdvance(text) + 16)
        height = min(22, max(0, option.rect.height() - 8))
        rect = QRect(0, 0, width, height)
        rect.moveCenter(option.rect.center())
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setFont(font)
        painter.setPen(QColor(obramowanie))
        painter.setBrush(QColor(tlo))
        painter.drawRoundedRect(rect, 6, 6)
        painter.setPen(QColor(tekst))
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)
        painter.restore()
