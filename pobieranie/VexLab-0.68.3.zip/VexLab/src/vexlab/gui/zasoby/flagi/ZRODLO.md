# Flagi państwowe

SVG: https://flagcdn.com/pl.svg, https://flagcdn.com/cz.svg,
https://flagcdn.com/hu.svg, https://flagcdn.com/sk.svg (Flagpedia/Flagcdn).
Pobrano 2026-11-18. Dokumentacja źródła: https://flagpedia.net/download/api
Flagi są zasobami interfejsu, dostępnymi offline. Pliki sprawdzono pod kątem
skryptów i zewnętrznych odwołań; flaga SK zachowuje herb i lokalne odwołanie SVG.
Kod kraju jest odczytywany z Allegro; aplikacja nie przypisuje Polsce innych krajów.
