"""Panel zamówienia: wyrównane pola, kraj, adresy i lista produktów."""

from PySide6.QtCore import QDateTime, QEvent, QObject, QSize, Qt, Signal
from PySide6.QtGui import QIcon, QPalette, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.karta_adresu import KartaAdresu
from vexlab.gui.pola_zamowienia import PolaZamowienia
from vexlab.gui.statusy_zamowien import (
    PLATNOSC,
    REALIZACJA,
    TYP_PLATNOSCI,
    etykieta,
    kolor,
    kolory_odznaki,
    stan_platnosci,
)
from vexlab.przypadki_uzycia.zamowienia_allegro import ZamowienieAllegro


class PanelZamowienia(QFrame):
    otworz = Signal()
    zamknij = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("panelZamowienia")
        self.setMinimumWidth(280)
        self.setMaximumWidth(420)
        self._kod = ""
        self._platnosc = ""
        self._styl: tuple[str, str, str] | None = None
        box = QVBoxLayout(self)
        box.setContentsMargins(12, 12, 12, 12)
        top = QHBoxLayout()
        top.addWidget(QLabel("Szczegóły zamówienia"), 1)
        self.odswiez = QPushButton("↻")
        self.odswiez.setFixedWidth(24)
        self.odswiez.setToolTip("Odśwież szczegóły zamówienia")
        top.addWidget(self.odswiez)
        close = QPushButton("×")
        close.setFixedWidth(24)
        close.clicked.connect(self.zamknij.emit)
        top.addWidget(close)
        box.addLayout(top)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        body = QWidget()
        self.obszar_przewijania, self.body = scroll, body
        scroll.viewport().installEventFilter(self)
        inside = QVBoxLayout(body)
        inside.setContentsMargins(0, 0, 0, 0)
        inside.setSpacing(6)
        self.status = QLabel()
        inside.addWidget(self.status)
        id_row = QHBoxLayout()
        self.numer = self.label()
        self.numer.setObjectName("numerZamowienia")
        id_row.addWidget(self.numer, 1)
        self.kopiuj_id = QPushButton()
        self.kopiuj_id.setIcon(ikona("kopiuj"))
        self.kopiuj_id.setFixedSize(18, 18)
        self.kopiuj_id.setObjectName("kopiujPoleZamowienia")
        self.kopiuj_id.setToolTip("Kopiuj numer zamówienia")
        self.kopiuj_id.clicked.connect(self._kopiuj_numer)
        id_row.addWidget(self.kopiuj_id)
        inside.addLayout(id_row)
        self.foto = self.fotografia(150, "fotoZamowienia")
        inside.addWidget(self.foto)
        gallery = QHBoxLayout()
        self.miniatury = [self.fotografia(40, "malaFotografiaZamowienia") for _ in range(3)]
        for photo in self.miniatury:
            gallery.addWidget(photo)
        inside.addLayout(gallery)
        self.produkt, self.sku = self.label(), self.label()
        self.produkt.setStyleSheet("font-weight:600; font-size:13px")
        self.sku.setObjectName("etykietaPolaZamowienia")
        inside.addWidget(self.produkt)
        inside.addWidget(self.sku)
        self.naglowek(inside, "Informacje o kliencie")
        self.klient = PolaZamowienia(
            (
                ("Kupujący", "uzytkownik", True),
                ("Imię i nazwisko", "uzytkownik", False),
                ("E-mail", "poczta", True),
                ("Telefon", "telefon", True),
                ("Kraj", "globus", False),
            )
        )
        inside.addWidget(self.klient)
        self.naglowek(inside, "Informacje o zamówieniu")
        self.dane = PolaZamowienia(
            (
                ("Kwota", "monety", False),
                ("Płatność", "platnosc", False),
                ("Sposób zapłaty", "platnosc", False),
                ("Dostawa", "dostawa", False),
                ("Status", "plik", False),
                ("Data zakupu", "kalendarz", False),
            )
        )
        inside.addWidget(self.dane)
        self.adresy_button = QToolButton()
        self.adresy_button.setText("Pokaż adresy")
        self.adresy_button.setObjectName("przelaczAdresyZamowienia")
        self.adresy_button.setCheckable(True)
        self.adresy_button.setArrowType(Qt.ArrowType.RightArrow)
        self.adresy_button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        inside.addWidget(self.adresy_button)
        self.adresy = QWidget()
        address_layout = QVBoxLayout(self.adresy)
        address_layout.setContentsMargins(0, 2, 0, 2)
        address_layout.setSpacing(8)
        self.adres_dostawy = KartaAdresu("Adres dostawy", "uzytkownik")
        self.punkt_odbioru = KartaAdresu("Punkt odbioru", "lokalizacja")
        address_layout.addWidget(self.adres_dostawy)
        address_layout.addWidget(self.punkt_odbioru)
        inside.addWidget(self.adresy)
        self.adresy_button.toggled.connect(self._adresy)
        self.naglowek(inside, "Produkty w zamówieniu")
        self.pozycje = QListWidget()
        self.pozycje.setObjectName("produktyZamowienia")
        self.pozycje.setIconSize(QSize(40, 40))
        self.pozycje.setWordWrap(True)
        self.pozycje.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        inside.addWidget(self.pozycje)
        inside.addStretch()
        scroll.setWidget(body)
        box.addWidget(scroll, 1)
        actions = QGridLayout()
        self.nadaj = QPushButton("Nadaj przesyłkę")
        self.nadaj.setObjectName("primary")
        self.etykieta = QPushButton("Drukuj etykietę")
        self.napisz = QPushButton("Wiadomość")
        self.otworz_button = QPushButton("Otwórz w Allegro ↗")
        for i, b in enumerate((self.nadaj, self.etykieta, self.napisz, self.otworz_button)):
            actions.addWidget(b, i // 2, i % 2)
        for b in (self.nadaj, self.etykieta):
            b.setEnabled(False)
            b.setToolTip("Nadawanie przesyłek i etykiety wymagają kolejnego etapu integracji.")
        self.napisz.setToolTip(
            "Bezpośrednie wiadomości w programie będą dostępne w kolejnym etapie."
        )
        self.napisz.setEnabled(False)
        self.otworz_button.setToolTip(
            "Otwiera listę zamówień w Allegro Sales Center. "
            "Numer wybranego zamówienia skopiujesz przy jego ID."
        )
        self.otworz_button.clicked.connect(self.otworz.emit)
        box.addLayout(actions)
        self.wyczysc()

    def _adresy(self, expanded: bool) -> None:
        self.adresy.setVisible(expanded)
        self.adresy_button.setText("Ukryj adresy" if expanded else "Pokaż adresy")
        self.adresy_button.setArrowType(
            Qt.ArrowType.DownArrow if expanded else Qt.ArrowType.RightArrow
        )

    def _kopiuj_numer(self) -> None:
        if self.kopiuj_id.isEnabled():
            QApplication.clipboard().setText(self.numer.toolTip())

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if obj is self.obszar_przewijania.viewport() and event.type() == QEvent.Type.Resize:
            self.body.setFixedWidth(max(1, self.obszar_przewijania.viewport().width()))
        return super().eventFilter(obj, event)

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.PaletteChange and hasattr(self, "status"):
            self._styl_statusu()
            if hasattr(self, "dane") and self._platnosc:
                self.dane.pola["Płatność"].setStyleSheet("color:" + kolor(self._platnosc).name())

    def _styl_statusu(self) -> None:
        if not self._kod:
            return
        ciemny = self.palette().color(QPalette.ColorRole.Base).lightness() < 128
        colors = kolory_odznaki(self._kod, ciemny)
        if colors == self._styl:
            return
        self._styl = colors
        background, foreground, border = colors
        self.status.setStyleSheet(
            f"color:{foreground}; background:{background}; border:1px solid {border};"
            "border-radius:6px; padding:2px 8px; font-size:11px"
        )

    @staticmethod
    def label() -> QLabel:
        label = QLabel()
        label.setWordWrap(True)
        label.setTextFormat(Qt.TextFormat.PlainText)
        label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        return label

    @staticmethod
    def fotografia(height: int, name: str) -> QLabel:
        label = QLabel("—")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setFixedHeight(height)
        label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        label.setObjectName(name)
        return label

    @staticmethod
    def naglowek(box: QVBoxLayout, title: str) -> None:
        heading = QLabel(title)
        heading.setStyleSheet("font-weight:600; margin-top:4px")
        box.addWidget(heading)

    def wyczysc(self) -> None:
        self._kod, self._styl, self._platnosc = "", None, ""
        self.status.setText("Wybierz zamówienie")
        self.status.setStyleSheet("")
        self.status.setFixedWidth(180)
        for label in (self.numer, self.produkt, self.sku):
            label.clear()
            label.setToolTip("")
        self.adres_dostawy.wyczysc()
        self.punkt_odbioru.wyczysc()
        self.klient.wyczysc()
        self.dane.wyczysc()
        self.pozycje.clear()
        self.pozycje.setFixedHeight(60)
        self.adresy_button.setChecked(False)
        self.adresy.hide()
        for photo in (self.foto, *self.miniatury):
            photo.clear()
            photo.setText("—")
        for b in (self.napisz, self.otworz_button, self.kopiuj_id):
            b.setEnabled(False)

    def ustaw(self, r: ZamowienieAllegro) -> None:
        self.wyczysc()
        self._kod = r.realizacja
        self.status.setText(etykieta(r.realizacja, REALIZACJA))
        self._styl_statusu()
        self.status.setFixedWidth(
            min(180, self.status.fontMetrics().horizontalAdvance(self.status.text()) + 20)
        )
        self.numer.setText("ID: " + r.id)
        self.numer.setToolTip(r.id)
        self.kopiuj_id.setEnabled(True)
        self.produkt.setText(r.pozycje[0].nazwa if r.pozycje else "Brak pozycji")
        self.sku.setText("SKU: " + (r.pozycje[0].sku or "—") if r.pozycje else "")
        for name, value in (
            ("Kupujący", r.kupujacy),
            ("Imię i nazwisko", r.klient),
            ("E-mail", r.email),
            ("Telefon", r.telefon),
        ):
            self.klient.ustaw(name, value)
        self.klient.kraj(r.kraj)
        date = (
            QDateTime.fromString(r.kupiono, Qt.DateFormat.ISODate)
            .toLocalTime()
            .toString("dd.MM.yyyy HH:mm")
        )
        self._platnosc = payment = stan_platnosci(r)
        source_operator = r.operator_platnosci.strip()
        operator = {
            "PAYU": "PayU",
            "P24": "Przelewy24",
            "ALLEGRO_FINANCE": "Allegro Finance",
            "ALLEGRO_PAY": "Allegro Pay",
            "ALLEGRO": "Allegro",
            "PRZELEWY24": "Przelewy24",
        }.get(source_operator.upper(), source_operator)
        method = etykieta(r.platnosc, TYP_PLATNOSCI)
        if operator:
            method += " · " + operator
        for name, value in (
            ("Kwota", r.kwota),
            ("Płatność", "◆ " + PLATNOSC[payment]),
            ("Sposób zapłaty", method),
            ("Dostawa", r.dostawa),
            ("Status", etykieta(r.realizacja, REALIZACJA)),
            ("Data zakupu", date),
        ):
            self.dane.ustaw(name, value)
        self.dane.pola["Płatność"].setStyleSheet("color:" + kolor(payment).name())
        self.dane.pola["Płatność"].setToolTip("Sposób zapłaty: " + method)
        self.dane.pola["Sposób zapłaty"].setToolTip(
            method + "\nAllegro nie udostępnia tu szczegółu BLIK/karta."
        )
        address = r.adres_dostawy or (r.adres if not r.punkt_odbioru else "")
        self.adres_dostawy.ustaw(address)
        self.punkt_odbioru.ustaw(r.punkt_odbioru)
        self.punkt_odbioru.setVisible(bool(r.punkt_odbioru))
        for p in r.pozycje:
            item = QListWidgetItem(f"{p.nazwa}  ·  {p.ilosc} szt.\nSKU: {p.sku or '—'}")
            item.setData(Qt.ItemDataRole.UserRole, p.oferta_id)
            item.setToolTip(item.text())
            self.pozycje.addItem(item)
        self.pozycje.setFixedHeight(min(180, max(60, len(r.pozycje) * 58)))
        self.otworz_button.setEnabled(True)

    def miniatura_pozycji(self, ident: str, icon: QIcon) -> None:
        for n in range(self.pozycje.count()):
            item = self.pozycje.item(n)
            if item is not None and item.data(Qt.ItemDataRole.UserRole) == ident:
                item.setIcon(icon)

    def zdjecie(self, data: bytes) -> None:
        pix = QPixmap()
        if data and pix.loadFromData(data):
            self.foto.setPixmap(
                pix.scaled(
                    max(100, min(350, self.foto.width())),
                    150,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
            self.miniatury[0].setPixmap(
                pix.scaled(
                    100,
                    40,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
            first = self.pozycje.item(0)
            if first is not None:
                self.miniatura_pozycji(first.data(Qt.ItemDataRole.UserRole), QIcon(pix))
        else:
            self.foto.setText("Brak dostępnego zdjęcia")
