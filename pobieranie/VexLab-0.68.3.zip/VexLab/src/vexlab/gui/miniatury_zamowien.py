"""Odczyt zdjęć tylko widocznych ofert, bez lokalnego zapisu i bez blokowania listy."""

from collections import OrderedDict
from typing import TYPE_CHECKING, cast

from PySide6.QtCore import QEvent, QObject, Qt, QTimer
from PySide6.QtGui import QIcon, QPixmap
from shiboken6 import isValid

from vexlab.rdzen.kontrakty import BladTechniczny

if TYPE_CHECKING:
    from vexlab.gui.zamowienia_allegro import StronaZamowien


class MiniaturyZamowien(QObject):
    def __init__(self, page: "StronaZamowien") -> None:
        super().__init__(page)
        self.page = page
        self.cache: OrderedDict[str, QIcon | None] = OrderedDict()
        self.trwa = False
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(80)
        self.timer.timeout.connect(self.pobierz)
        page.tabela.viewport().installEventFilter(self)
        page.tabela.verticalScrollBar().valueChanged.connect(self.zaplanuj)
        page.karty.viewport().installEventFilter(self)
        page.karty.verticalScrollBar().valueChanged.connect(self.zaplanuj)
        page.model.modelReset.connect(self.zaplanuj)
        page.model.miniatury = self.cache

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if event.type() in (QEvent.Type.Show, QEvent.Type.Resize, QEvent.Type.Paint):
            self.zaplanuj()
        return False

    def zaplanuj(self) -> None:
        if not self.timer.isActive():
            self.timer.start()

    def reset(self) -> None:
        self.cache.clear()
        self.timer.stop()

    def pobierz(self) -> None:
        p = self.page
        if (
            self.trwa
            or not isValid(p)
            or not p.isVisible()
            or p.uc.obrazy is None
            or p.raport is None
        ):
            return
        session = p.sesja()
        if session is None:
            return
        first = max(0, p.tabela.rowAt(0))
        last = p.tabela.rowAt(p.tabela.viewport().height() - 1)
        if last < 0:
            last = min(p.model.rowCount() - 1, first + 30)
        visible = p.model.rows[first : last + 1]
        if p.widoki.currentIndex() == 1:
            viewport = p.karty.viewport().rect()
            visible = tuple(
                r
                for n, r in enumerate(p.model.rows)
                if p.karty.visualRect(p.model.index(n, 2)).intersects(viewport)
            )
        ids = tuple(
            dict.fromkeys(
                r.pozycje[0].oferta_id
                for r in visible
                if r.pozycje and r.pozycje[0].oferta_id and r.pozycje[0].oferta_id not in self.cache
            )
        )[:4]
        if not ids:
            return
        report = p.raport
        self.trwa = True

        def read() -> dict[str, bytes]:
            result = {}
            for ident in ids:
                if p.sesja() is not session or p.raport is not report:
                    break
                try:
                    result[ident] = p.uc.miniatura(session, ident)
                except BladTechniczny:
                    result[ident] = b""
            return result

        def done(value: object) -> None:
            self.trwa = False
            if not isValid(p):
                return
            if p.sesja() is not session or p.raport is not report:
                self.zaplanuj()
                return
            rows = cast(dict[str, bytes], value)
            for ident in ids:
                icon = None
                data = rows.get(ident, b"")
                pix = QPixmap()
                if data and len(data) <= 512 * 1024 and pix.loadFromData(data):
                    icon = QIcon(
                        pix.scaled(
                            48,
                            48,
                            Qt.AspectRatioMode.KeepAspectRatio,
                            Qt.TransformationMode.SmoothTransformation,
                        )
                    )
                self.cache[ident] = icon
                self.cache.move_to_end(ident)
            while len(self.cache) > 128:
                self.cache.popitem(last=False)
            if p.model.rowCount():
                p.model.dataChanged.emit(
                    p.model.index(0, 1),
                    p.model.index(p.model.rowCount() - 1, 1),
                    [Qt.ItemDataRole.DecorationRole],
                )
            p.karty.viewport().update()
            self.zaplanuj()

        p.uruchom(read, done, lambda *_: done({}))
