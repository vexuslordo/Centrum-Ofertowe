"""Połączenie i odczyt kategorii PrestaShop, bez zapisów do sklepu."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import (
    QAbstractTableModel,
    QDateTime,
    QModelIndex,
    QPersistentModelIndex,
    QSortFilterProxyModel,
    Qt,
    Signal,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QSplitter,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona_menu
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta as etykieta_bazowa
from vexlab.przypadki_uzycia.prestashop import (
    BladPresta,
    KategoriaPresta,
    KonfiguracjaPresta,
    PolaczPresta,
    SlownikiPresta,
)

Indeks = QModelIndex | QPersistentModelIndex


def etykieta(tekst: str, styl: str = "", zawijaj: bool = False) -> QLabel:
    label = etykieta_bazowa(tekst)
    label.setObjectName(styl)
    label.setWordWrap(zawijaj)
    return label


class ModelKategorii(QAbstractTableModel):
    def __init__(self) -> None:
        super().__init__()
        self.pozycje: tuple[KategoriaPresta, ...] = ()

    def ustaw(self, pozycje: tuple[KategoriaPresta, ...]) -> None:
        self.beginResetModel()
        self.pozycje = pozycje
        self.endResetModel()

    def rowCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else len(self.pozycje)

    def columnCount(self, parent: Indeks = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else 4

    def data(self, index: Indeks, role: int = Qt.ItemDataRole.DisplayRole) -> object:
        if not index.isValid() or not 0 <= index.row() < len(self.pozycje):
            return None
        k = self.pozycje[index.row()]
        if role == Qt.ItemDataRole.UserRole:
            return k
        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.ToolTipRole):
            return (k.id, k.nazwa, k.rodzic, "Aktywna" if k.aktywna else "Nieaktywna")[
                index.column()
            ]
        return None

    def headerData(
        self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole
    ) -> object:
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return ("ID", "Kategoria sklepu", "ID nadrzędnej", "Status")[section]
        return None


class StronaPresta(QWidget):
    stan = Signal(str)
    ustawienia_zadane = Signal()

    def __init__(self, serwis: PolaczPresta, uruchom: Uruchom) -> None:
        super().__init__()
        self.serwis, self.uruchom = serwis, uruchom
        self._trwa = False
        self._sprawdzone: KonfiguracjaPresta | None = None
        self._pamiec: KonfiguracjaPresta | None = None
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 18, 24, 18)
        layout.setSpacing(16)
        self._odczytano = False
        self._naglowek(layout)
        self._metryki(layout)
        self.panel_polaczenia = QWidget(self)
        self.panel_polaczenia.hide()
        auth = QVBoxLayout(self.panel_polaczenia)
        auth.addWidget(etykieta("PrestaShop", "tytul"))
        auth.addWidget(etykieta("Połączenie Webservice · PrestaShop 1.6.1.24", "opis"))
        form = QFormLayout()
        self.adres = QLineEdit()
        self.adres.setPlaceholderText("https://adres-twojego-sklepu.pl/")
        self.adres.setAccessibleName("Adres HTTPS sklepu PrestaShop")
        self.klucz = QLineEdit()
        self.klucz.setEchoMode(QLineEdit.EchoMode.Password)
        self.klucz.setAccessibleName("Klucz Webservice PrestaShop")
        self.klucz.setMaxLength(32)
        form.addRow("Adres sklepu", self.adres)
        form.addRow("Klucz Webservice", self.klucz)
        auth.addLayout(form)
        auth.addWidget(
            etykieta(
                "W panelu PrestaShop: Zaawansowane → Webservice. Włącz API i nadaj kluczowi "
                "uprawnienia GET do shops, languages i categories.",
                "opis",
                True,
            )
        )
        actions = QHBoxLayout()
        self.polacz = QPushButton("Sprawdź połączenie")
        self.polacz.setObjectName("primary")
        self.zapisz = QPushButton("Zapamiętaj połączenie i wybór")
        self.usun = QPushButton("Usuń zapamiętane połączenie")
        for b in (self.polacz, self.zapisz, self.usun):
            actions.addWidget(b)
        auth.addLayout(actions)
        self.status = etykieta(
            "Podaj adres sklepu i klucz Webservice. Nie używaj adresu panelu administratora.",
            "opis",
            True,
        )
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        auth.addWidget(self.status)
        auth.addStretch()
        self.informacja = etykieta(
            "Połącz sklep w Ustawienia → Integracje → PrestaShop.", "opis", True
        )
        wybory = QHBoxLayout()
        self.sklep, self.jezyk = QComboBox(), QComboBox()
        self.sklep.setAccessibleName("Docelowy sklep PrestaShop")
        self.jezyk.setAccessibleName("Język kategorii PrestaShop")
        self.sklep.addItem("Wybierz sklep", "")
        self.jezyk.addItem("Wybierz język", "")
        self.pobierz = QPushButton("Pobierz kategorie")
        for w in (self.sklep, self.jezyk, self.pobierz):
            wybory.addWidget(w)
        layout.addLayout(wybory)
        self.filtr = QLineEdit()
        self.filtr.setPlaceholderText("Szukaj kategorii po nazwie lub ID…")
        self.filtr.setAccessibleName("Szukaj kategorii PrestaShop")
        layout.addWidget(self.filtr)
        self.model = ModelKategorii()
        self.proxy = QSortFilterProxyModel(self)
        self.proxy.setSourceModel(self.model)
        self.proxy.setFilterKeyColumn(-1)
        self.proxy.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.tabela = QTableView()
        self.tabela.setModel(self.proxy)
        self.tabela.setAccessibleName("Kategorie wybranego sklepu i języka PrestaShop")
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.tabela.setColumnWidth(0, 80)
        self.tabela.setColumnWidth(2, 150)
        self.tabela.setColumnWidth(3, 115)
        self.tabela.verticalHeader().hide()
        self.tabela.setMinimumHeight(220)
        self.tabela.setShowGrid(False)
        self.tabela.verticalHeader().setDefaultSectionSize(48)
        splitter = QSplitter()
        splitter.addWidget(self.tabela)
        szczegoly = QFrame()
        szczegoly.setObjectName("szczegolyAllegro")
        details = QVBoxLayout(szczegoly)
        details.setContentsMargins(16, 16, 16, 16)
        details.addWidget(etykieta("Szczegóły kategorii", "tytulSekcjiAllegro"))
        self.nazwa_kategorii = etykieta("Wybierz kategorię z listy", "tytulOfertyAllegro", True)
        details.addWidget(self.nazwa_kategorii)
        self.dane_kategorii = etykieta("", "opis", True)
        details.addWidget(self.dane_kategorii)
        details.addStretch()
        szczegoly.setMinimumWidth(240)
        splitter.addWidget(szczegoly)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter, 1)
        layout.addWidget(self.informacja)
        self.wybrana = etykieta("Nie wybrano kategorii docelowej.", "opis", True)
        self.wybrana.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.wybrana)
        self.postep = QProgressBar()
        self.postep.setRange(0, 0)
        self.postep.hide()
        layout.addWidget(self.postep)
        layout.addWidget(
            etykieta(
                "Ten etap pobiera ustawienia. Produkty i kategorie w sklepie pozostają bez zmian.",
                "opis",
                True,
            )
        )
        self.polacz.clicked.connect(self.sprawdz)
        self.pobierz.clicked.connect(self.pobierz_kategorie)
        self.zapisz.clicked.connect(self.zapamietaj)
        self.usun.clicked.connect(self.usun_polaczenie)
        self.adres.textChanged.connect(self._uniewaznij)
        self.klucz.textChanged.connect(self._uniewaznij)
        self.sklep.currentIndexChanged.connect(self._wybor_kontekstu)
        self.jezyk.currentIndexChanged.connect(self._wybor_kontekstu)
        self.filtr.textChanged.connect(self.proxy.setFilterFixedString)
        self.tabela.selectionModel().currentRowChanged.connect(lambda *_: self._wybor_kategorii())
        self.model.modelReset.connect(self._odswiez_metryki)
        self.stan.connect(self._stan_naglowka)
        self._przyciski()

    def _naglowek(self, layout: QVBoxLayout) -> None:
        row = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(ikona_menu("PrestaShop", True).pixmap(42, 42))
        row.addWidget(logo)
        texts = QVBoxLayout()
        texts.addWidget(etykieta("PrestaShop", "tytulStronyAllegro"))
        texts.addWidget(etykieta("Twój sklep · kategorie i ustawienia sprzedaży", "opisAllegro"))
        self.stan_polaczenia = etykieta("Nie sprawdzono", "statusPolaczeniaAllegro")
        texts.addWidget(self.stan_polaczenia)
        row.addLayout(texts)
        row.addStretch()
        self.ustawienia = QPushButton("Ustawienia połączenia")
        self.ustawienia.setProperty("akcjaAllegro", True)
        self.ustawienia.clicked.connect(self.ustawienia_zadane.emit)
        row.addWidget(self.ustawienia)
        layout.addLayout(row)
        self.ostatni_odczyt = etykieta("Ostatni odczyt: —", "podpisAllegro")
        layout.addWidget(self.ostatni_odczyt)

    def _metryki(self, layout: QVBoxLayout) -> None:
        row = QHBoxLayout()
        self.liczniki: list[QLabel] = []
        for nazwa, kolor in (
            ("Kategorie", "fioletowy"),
            ("Aktywne", "zielony"),
            ("Nieaktywne", "zloty"),
            ("Sklep", "niebieski"),
            ("Język", "pomaranczowy"),
        ):
            card = QFrame()
            card.setObjectName("kpiAllegro")
            card.setProperty("wariantAllegro", kolor)
            box = QVBoxLayout(card)
            box.setContentsMargins(16, 12, 16, 12)
            box.addWidget(etykieta(nazwa, "opisAllegro"))
            value = etykieta(
                "—", "licznikAllegro" if len(self.liczniki) < 3 else "tytulSekcjiAllegro", True
            )
            self.liczniki.append(value)
            box.addWidget(value)
            row.addWidget(card, 1)
        layout.addLayout(row)

    def _odswiez_metryki(self) -> None:
        rows = self.model.pozycje
        for label, value in zip(
            self.liczniki[:3],
            (len(rows), sum(k.aktywna for k in rows), sum(not k.aktywna for k in rows)),
            strict=True,
        ):
            label.setText(str(value) if self._odczytano else "—")
        for label, combo in zip(self.liczniki[3:], (self.sklep, self.jezyk), strict=True):
            label.setText(combo.currentText() if combo.currentData() else "—")
            label.setToolTip(combo.currentText())
        if not self._odczytano:
            self.ostatni_odczyt.setText("Ostatni odczyt: —")
        self.nazwa_kategorii.setText("Wybierz kategorię z listy")
        self.dane_kategorii.clear()

    def _stan_naglowka(self, tekst: str) -> None:
        self.stan_polaczenia.setText(tekst)
        self.stan_polaczenia.setProperty("polaczono", tekst.startswith("Połączono"))
        self.stan_polaczenia.style().unpolish(self.stan_polaczenia)
        self.stan_polaczenia.style().polish(self.stan_polaczenia)

    def _komunikat(self, tekst: str) -> None:
        self.status.setText(tekst)
        self.informacja.setText(tekst)

    def _przyciski(self) -> None:
        for w in (self.adres, self.klucz, self.polacz, self.sklep, self.jezyk, self.tabela):
            w.setEnabled(not self._trwa)
        self.pobierz.setEnabled(
            not self._trwa
            and self._sprawdzone is not None
            and bool(self.sklep.currentData())
            and bool(self.jezyk.currentData())
        )
        self.zapisz.setEnabled(
            not self._trwa and self._sprawdzone is not None and self.serwis.magazyn is not None
        )
        self.usun.setEnabled(not self._trwa and self.serwis.magazyn is not None)
        if self.serwis.magazyn is None:
            self.zapisz.setToolTip("Bezpieczne zapamiętywanie klucza wymaga Windows.")

    def _uniewaznij(self) -> None:
        self._sprawdzone = None
        self.sklep.clear()
        self.jezyk.clear()
        self._odczytano = False
        self.model.ustaw(())
        self.wybrana.setText("Nie wybrano kategorii docelowej.")
        self.stan.emit("Nie sprawdzono")
        self._przyciski()

    def _wybor_kontekstu(self) -> None:
        self._odczytano = False
        self.model.ustaw(())
        self.wybrana.setText("Nie wybrano kategorii docelowej.")
        self._przyciski()

    def _konfiguracja(self) -> KonfiguracjaPresta:
        return KonfiguracjaPresta(
            self.adres.text(),
            self.klucz.text(),
            self.sklep.currentData() or "",
            self.jezyk.currentData() or "",
            self._kategoria(),
        ).sprawdz()

    def _kategoria(self) -> str:
        index = self.tabela.currentIndex()
        item = self.proxy.data(index, Qt.ItemDataRole.UserRole)
        return item.id if isinstance(item, KategoriaPresta) and item.aktywna else ""

    def _wybor_kategorii(self) -> None:
        item = self.proxy.data(self.tabela.currentIndex(), Qt.ItemDataRole.UserRole)
        if isinstance(item, KategoriaPresta):
            self.nazwa_kategorii.setText(item.nazwa)
            self.dane_kategorii.setText(
                f"ID: {item.id}\nKategoria nadrzędna: {item.rodzic}\n"
                f"Status: {'Aktywna' if item.aktywna else 'Nieaktywna'}"
            )
            self.wybrana.setText(
                f"Wybrana kategoria: {item.nazwa} · ID {item.id}"
                if item.aktywna
                else "Kategoria nieaktywna — wybierz aktywną kategorię."
            )

        else:
            self.nazwa_kategorii.setText("Wybierz kategorię z listy")
            self.dane_kategorii.clear()
            self.wybrana.setText("Nie wybrano kategorii docelowej.")

    def _zadanie(self, funkcja: Callable[[], object], sukces: Callable[[object], None]) -> None:
        self._trwa = True
        self.postep.show()
        self._przyciski()

        def ok(w: object) -> None:
            self._trwa = False
            self.postep.hide()
            sukces(w)
            self._przyciski()

        def blad(_kod: str, tekst: str) -> None:
            self._trwa = False
            self.postep.hide()
            self._komunikat(tekst)
            self.stan.emit("Błąd odczytu")
            self._przyciski()

        self.uruchom(funkcja, ok, blad)

    def sprawdz(self) -> None:
        if self._trwa:
            return
        try:
            k = self._konfiguracja()
        except BladPresta as e:
            self._komunikat(str(e))
            return
        pamiec = (
            self._pamiec
            if self._pamiec and (self._pamiec.adres, self._pamiec.klucz) == (k.adres, k.klucz)
            else None
        )
        self._sprawdzone = None
        self._odczytano = False
        self.model.ustaw(())
        self._komunikat("Sprawdzanie połączenia i uprawnień…")

        def ok(w: object) -> None:
            dane = cast(SlownikiPresta, w)
            for combo, rows, tytul, ident in (
                (
                    self.sklep,
                    dane.sklepy,
                    "Wybierz sklep",
                    k.sklep or (pamiec.sklep if pamiec else ""),
                ),
                (
                    self.jezyk,
                    dane.jezyki,
                    "Wybierz język",
                    k.jezyk or (pamiec.jezyk if pamiec else ""),
                ),
            ):
                combo.clear()
                combo.addItem(tytul, "")
                for row in rows:
                    if row.aktywna:
                        combo.addItem(row.nazwa, row.id)
                selected = combo.findData(ident)
                combo.setCurrentIndex(selected if selected > 0 else 1 if combo.count() == 2 else 0)
            self._sprawdzone = k
            self._komunikat("Połączono. Wybierz sklep i język, a następnie pobierz kategorie.")
            self.stan.emit("Połączono — odczyt")

        self._zadanie(lambda: self.serwis.sprawdz(k), ok)

    def pobierz_kategorie(self) -> None:
        if self._trwa or self._sprawdzone is None:
            return
        k = self._konfiguracja()
        self._odczytano = False
        self.model.ustaw(())
        self._komunikat("Pobieranie kategorii wybranego sklepu i języka…")

        def ok(w: object) -> None:
            dane = cast(tuple[KategoriaPresta, ...], w)
            self._odczytano = True
            self.model.ustaw(dane)
            self.ostatni_odczyt.setText(
                "Ostatni odczyt: " + QDateTime.currentDateTime().toString("dd.MM.yyyy HH:mm")
            )
            self._komunikat(f"Pobrano kategorii: {len(dane)}. Wybierz kategorię docelową.")
            if self._pamiec and (k.adres, k.sklep, k.jezyk) == (
                self._pamiec.adres,
                self._pamiec.sklep,
                self._pamiec.jezyk,
            ):
                for i, item in enumerate(dane):
                    if item.id == self._pamiec.kategoria and item.aktywna:
                        self.tabela.setCurrentIndex(
                            self.proxy.mapFromSource(self.model.index(i, 0))
                        )
                        break
            self.stan.emit("Połączono — odczyt")

        self._zadanie(lambda: self.serwis.kategorie(k), ok)

    def zapamietaj(self) -> None:
        if self._trwa or self._sprawdzone is None:
            return
        k = self._konfiguracja()

        def ok(_w: object) -> None:
            self._pamiec = k
            self._komunikat("Zapamiętano połączenie i wybór w danych Twojego użytkownika Windows.")

        self._zadanie(lambda: self.serwis.zapamietaj(k), ok)

    def przywroc(self) -> None:
        def ok(w: object) -> None:
            k = cast(KonfiguracjaPresta | None, w)
            if k:
                self._uniewaznij()
                self.adres.setText(k.adres)
                self.klucz.setText(k.klucz)
                self._pamiec = k
                self._komunikat("Wczytano zapamiętane ustawienia. Kliknij „Sprawdź połączenie”.")

        self._zadanie(self.serwis.przywroc, ok)

    def usun_polaczenie(self) -> None:
        if self._trwa:
            return

        def ok(_w: object) -> None:
            self._pamiec = None
            self.adres.clear()
            self.klucz.clear()
            self._komunikat("Usunięto zapamiętane połączenie PrestaShop.")
            self.stan.emit("Niepołączono")

        self._zadanie(self.serwis.usun, ok)
