"""Wynik rzeczywistego lokalnego odczytu metadanych, na żądanie użytkownika."""

from typing import cast

from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.srodowisko_gt import RaportSrodowiskaGT, SprawdzSrodowiskoGT


class PanelSrodowiskaGT(QWidget):
    def __init__(self, serwis: SprawdzSrodowiskoGT | None, uruchom: Uruchom) -> None:
        super().__init__()
        self.serwis, self.uruchom = serwis, uruchom
        self.trwa = False
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        tytul = QLabel("Subiekt GT — przygotowanie połączenia")
        tytul.setObjectName("tytul")
        layout.addWidget(tytul)
        opis = QLabel("Sprawdź wersję składników InsERT GT i sterowniki SQL na tym komputerze.")
        opis.setWordWrap(True)
        layout.addWidget(opis)
        buttons = QHBoxLayout()
        self.sprawdz = QPushButton("Sprawdź środowisko")
        self.sprawdz.setAccessibleName("Sprawdź lokalne środowisko Subiekta GT")
        self.sprawdz.setEnabled(serwis is not None)
        self.sprawdz.clicked.connect(self.wykonaj)
        self.kopiuj = QPushButton("Kopiuj raport")
        self.kopiuj.setEnabled(False)
        self.kopiuj.clicked.connect(self._kopiuj)
        buttons.addWidget(self.sprawdz)
        buttons.addWidget(self.kopiuj)
        buttons.addStretch()
        layout.addLayout(buttons)
        self.info = QLabel("Połączenie z serwerem nie jest jeszcze skonfigurowane.")
        self.info.setWordWrap(True)
        self.info.setObjectName("opis")
        layout.addWidget(self.info)
        self.raport = QPlainTextEdit()
        self.raport.setReadOnly(True)
        self.raport.setAccessibleName("Raport lokalnego środowiska Subiekta GT")
        self.raport.setMinimumHeight(150)
        self.raport.setMaximumHeight(240)
        self.raport.hide()
        layout.addWidget(self.raport)

    def wykonaj(self) -> None:
        serwis = self.serwis
        if serwis is None or self.trwa:
            return
        self.trwa = True
        self.sprawdz.setEnabled(False)
        self.kopiuj.setEnabled(False)
        self.raport.clear()
        self.raport.hide()
        self.info.setText("Sprawdzanie lokalnego środowiska…")

        def gotowe(wynik: object) -> None:
            raport = cast(RaportSrodowiskaGT, wynik)
            self.trwa = False
            self.sprawdz.setEnabled(True)
            self.kopiuj.setEnabled(True)
            self.raport.setPlainText(raport.tekst)
            self.raport.show()
            self.info.setText(
                "Sprawdzenie dostępne wyłącznie na Windows."
                if not raport.srodowisko.obslugiwany
                else "Sprawdzenie zakończone z uwagami. Odczyt może być niepełny."
                if raport.srodowisko.uwagi
                else "Sprawdzenie zakończone. Połączenie z serwerem nie było sprawdzane."
            )

        def blad(kod: str, komunikat: str) -> None:
            self.trwa = False
            self.sprawdz.setEnabled(True)
            self.info.setText(f"Nie udało się sprawdzić środowiska. {komunikat}")

        self.uruchom(serwis.wykonaj, gotowe, blad)

    def _kopiuj(self) -> None:
        if self.kopiuj.isEnabled():
            QApplication.clipboard().setText(self.raport.toPlainText())
