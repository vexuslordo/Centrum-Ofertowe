"""OAuth Device Flow i odczyt ofert według stanów; brak poleceń zapisu."""

import base64
import json
from typing import Any
from urllib.parse import urlencode, urlsplit

from vexlab.kanaly.szkic_allegro import mapuj_oferte, mapuj_pozycje, mapuj_szkic
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    BladAllegro,
    KodUrzadzenia,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StatusOfertyAllegro,
    StronaSzkicowAllegro,
    SzczegolySzkicuAllegro,
    TokenAllegro,
    TransportAllegro,
)


def hosty(srodowisko: SrodowiskoAllegro) -> tuple[str, str]:
    if srodowisko == SrodowiskoAllegro.PRODUKCJA:
        return "https://allegro.pl", "https://api.allegro.pl"
    return "https://allegro.pl.allegrosandbox.pl", "https://api.allegro.pl.allegrosandbox.pl"


def tekst(d: dict[str, Any], nazwa: str, limit: int = 1024) -> str:
    v = d.get(nazwa)
    if not isinstance(v, str) or not v or len(v) > limit or any(ord(c) < 32 for c in v):
        raise ValueError(nazwa)
    return v


def liczba(d: dict[str, Any], nazwa: str, minimum: int, maksimum: int) -> int:
    v = d.get(nazwa)
    if type(v) is not int or not minimum <= v <= maksimum:
        raise ValueError(nazwa)
    return v


class AllegroAPI:
    def __init__(self, transport: TransportAllegro) -> None:
        self._transport = transport

    def oferta(self, sesja: SesjaAllegro, ident: str) -> SzczegolySzkicuAllegro:
        if not ident.isascii() or not ident.isdigit() or len(ident) > 100:
            raise BladAllegro("OFERTA", "Nieprawidłowy identyfikator oferty Allegro.")
        dane = self._get(sesja.srodowisko, sesja.token, "/sale/product-offers/" + ident)
        return mapuj_oferte(dane, ident)

    def szkic(self, sesja: SesjaAllegro, id_szkicu: str) -> SzczegolySzkicuAllegro:
        if not id_szkicu.isascii() or not id_szkicu.isdigit() or len(id_szkicu) > 100:
            raise BladAllegro("SZKIC", "Nieprawidłowy identyfikator szkicu Allegro.")
        dane = self._get(sesja.srodowisko, sesja.token, "/sale/product-offers/" + id_szkicu)
        return mapuj_szkic(dane, id_szkicu)

    def _json(
        self, metoda: str, url: str, naglowki: dict[str, str], dane: bytes | None = None
    ) -> dict[str, Any]:
        response = self._transport.wyslij(metoda, url, naglowki, dane)
        try:
            value = json.loads(response.dane)
        except (ValueError, UnicodeError):
            value = None
        if response.status != 200:
            code = value.get("error") if isinstance(value, dict) else None
            stany = {
                "authorization_pending": ("OCZEKIWANIE", "Oczekiwanie na zgodę w Allegro."),
                "slow_down": ("WOLNIEJ", "Allegro wymaga dłuższego odstępu sprawdzeń."),
                "access_denied": ("ODMOWA", "Odmówiono zgody. Rozpocznij połączenie ponownie."),
                "expired_token": ("WYGASLA", "Kod zgody wygasł. Połącz konto ponownie."),
                "invalid_client": ("APLIKACJA", "Sprawdź dane aplikacji i środowisko Allegro."),
                "invalid_grant": ("WYGASLA", "Zgoda wygasła lub jest nieprawidłowa."),
                "invalid_scope": (
                    "UPRAWNIENIA",
                    "Aplikacja Allegro nie udostępnia wybranych uprawnień. "
                    "Włącz allegro:api:profile:read oraz allegro:api:sale:offers:read "
                    "w konfiguracji aplikacji Allegro; dla zapisu także "
                    "allegro:api:sale:offers:write. "
                    "Połącz konto ponownie.",
                ),
            }
            if isinstance(code, str) and code in stany:
                raise BladAllegro(*stany[code])
            if response.status == 401:
                raise BladAllegro(
                    "AUTORYZACJA", "Allegro odrzuciło autoryzację. Połącz konto ponownie."
                )
            if response.status == 403:
                sciezka = urlsplit(url).path
                if sciezka == "/me":
                    raise BladAllegro(
                        "UPRAWNIENIA",
                        "Allegro odmówiło odczytu profilu konta (HTTP 403). "
                        "Sprawdź uprawnienie allegro:api:profile:read w konfiguracji "
                        "aplikacji Allegro, następnie połącz konto i zatwierdź zgodę ponownie.",
                    )
                if sciezka.startswith("/sale/"):
                    raise BladAllegro(
                        "UPRAWNIENIA",
                        "Allegro odmówiło odczytu ofert (HTTP 403). "
                        "Sprawdź uprawnienie allegro:api:sale:offers:read w konfiguracji "
                        "aplikacji Allegro. Po zmianie uprawnień połącz konto ponownie.",
                    )
                raise BladAllegro("UPRAWNIENIA", "Brak uprawnień aplikacji do odczytu tego zasobu.")
            if response.status == 429:
                raise BladAllegro("LIMIT", "Limit Allegro. Odczekaj przed ponowną próbą.")
            raise BladAllegro("HTTP", f"Allegro zwróciło HTTP {response.status}. Spróbuj później.")
        if not isinstance(value, dict):
            raise BladAllegro("ODPOWIEDZ", "Allegro zwróciło nieprawidłową odpowiedź.")
        return value

    @staticmethod
    def _basic(aplikacja: AplikacjaAllegro) -> dict[str, str]:
        aplikacja.sprawdz()
        auth = base64.b64encode(f"{aplikacja.klient}:{aplikacja.sekret}".encode()).decode("ascii")
        return {
            "Authorization": "Basic " + auth,
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        }

    def rozpocznij(self, aplikacja: AplikacjaAllegro) -> KodUrzadzenia:
        baza, _ = hosty(aplikacja.srodowisko)
        d = self._json(
            "POST",
            baza + "/auth/oauth/device",
            self._basic(aplikacja),
            urlencode(
                {
                    "client_id": aplikacja.klient,
                    "scope": "allegro:api:profile:read allegro:api:sale:offers:read"
                    + (" allegro:api:sale:offers:write" if aplikacja.zapis_szkicow else ""),
                }
            ).encode(),
        )
        try:
            # Stały host autoryzacji: nigdy adres logowania podany przez import oferty.
            adres = tekst(d, "verification_uri_complete", 4096)
            u, b = urlsplit(adres), urlsplit(baza)
            if u.scheme != "https" or u.netloc != b.netloc or u.fragment or u.username:
                raise ValueError("adres")
            return KodUrzadzenia(
                tekst(d, "device_code"),
                tekst(d, "user_code", 100),
                adres,
                liczba(d, "expires_in", 1, 86400),
                liczba(d, "interval", 1, 3600),
            )
        except (ValueError, TypeError):
            raise BladAllegro("ODPOWIEDZ", "Nieprawidłowy kod autoryzacji Allegro.") from None

    def token(self, aplikacja: AplikacjaAllegro, kod: str) -> TokenAllegro:
        baza, _ = hosty(aplikacja.srodowisko)
        d = self._json(
            "POST",
            baza + "/auth/oauth/token",
            self._basic(aplikacja),
            urlencode(
                {"grant_type": "urn:ietf:params:oauth:grant-type:device_code", "device_code": kod}
            ).encode(),
        )
        return self._token(d)

    def odnow(self, aplikacja: AplikacjaAllegro, token: str) -> TokenAllegro:
        baza, _ = hosty(aplikacja.srodowisko)
        d = self._json(
            "POST",
            baza + "/auth/oauth/token",
            self._basic(aplikacja),
            urlencode({"grant_type": "refresh_token", "refresh_token": token}).encode(),
        )
        return self._token(d)

    @staticmethod
    def _token(d: dict[str, Any]) -> TokenAllegro:
        try:
            if tekst(d, "token_type").casefold() != "bearer":
                raise ValueError("token_type")
            refresh = tekst(d, "refresh_token", 16384) if "refresh_token" in d else ""
            return TokenAllegro(
                tekst(d, "access_token", 16384), liczba(d, "expires_in", 1, 86400), refresh
            )
        except (ValueError, TypeError):
            raise BladAllegro("ODPOWIEDZ", "Nieprawidłowa odpowiedź autoryzacji Allegro.") from None

    def _get(self, srodowisko: SrodowiskoAllegro, token: str, sciezka: str) -> dict[str, Any]:
        _, api = hosty(srodowisko)
        return self._json(
            "GET",
            api + sciezka,
            {
                "Authorization": "Bearer " + token,
                "Accept": "application/vnd.allegro.public.v1+json",
            },
        )

    def konto(self, srodowisko: SrodowiskoAllegro, token: str) -> KontoAllegro:
        d = self._get(srodowisko, token, "/me")
        try:
            return KontoAllegro(tekst(d, "id", 100), tekst(d, "login", 200))
        except ValueError:
            raise BladAllegro("ODPOWIEDZ", "Nie można potwierdzić konta Allegro.") from None

    def szkice(self, sesja: SesjaAllegro, offset: int, limit: int) -> StronaSzkicowAllegro:
        return self.oferty(sesja, StatusOfertyAllegro.SZKIC, offset, limit)

    def oferty(
        self,
        sesja: SesjaAllegro,
        status: StatusOfertyAllegro | None,
        offset: int,
        limit: int,
    ) -> StronaSzkicowAllegro:
        return self.szukaj_ofert(sesja, status, offset, limit, "name", "")

    def szukaj_ofert(
        self,
        sesja: SesjaAllegro,
        status: StatusOfertyAllegro | None,
        offset: int,
        limit: int,
        pole: str,
        fraza: str,
    ) -> StronaSzkicowAllegro:
        parametry: dict[str, str | int] = {"offset": offset, "limit": limit}
        if fraza:
            if pole not in {"name", "external.id", "offer.id"}:
                raise BladAllegro("SZUKAJ", "Niepoprawne pole wyszukiwania.")
            parametry[pole] = fraza
        if status is not None:
            parametry["publication.status"] = status.value
        q = urlencode(parametry)
        d = self._get(sesja.srodowisko, sesja.token, "/sale/offers?" + q)
        try:
            offers = d.get("offers")
            total = liczba(d, "totalCount", 0, 1000000000)
            if not isinstance(offers, list) or len(offers) > limit:
                raise ValueError("offers")
            items = []
            for p in offers:
                if not isinstance(p, dict) or (
                    status is not None and p.get("publication", {}).get("status") != status.value
                ):
                    raise ValueError("status")
                items.append(mapuj_pozycje(p))
            if len({p.id for p in items}) != len(items):
                raise ValueError("duplikat")
            return StronaSzkicowAllegro(tuple(items), total, offset, limit)
        except (ValueError, TypeError, AttributeError):
            raise BladAllegro("ODPOWIEDZ", "Nieprawidłowa lista ofert Allegro.") from None
