"""Przegląd planu ZIP → INACTIVE, jawne dane konta, raport i anulowanie serii."""

import csv
from collections import Counter
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from threading import Event
from typing import cast

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.masowa_paczka_allegro import MasowaPaczkaAllegro
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.edycja_paczki_allegro import zmien_parametry
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    KategoriaSzkicu,
    NoweSzkiceAllegro,
    PlanNowegoSzkicu,
    ProduktSzkicu,
    UstawieniaSzkicu,
    WynikTworzenia,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad


def zapisz_raport(
    plik: Path, wyniki: tuple[WynikTworzenia, ...], konto: str = "", srodowisko: str = ""
) -> None:
    def pole(v: str) -> str:
        return (
            "'" + v
            if v.lstrip().startswith(("=", "+", "-", "@")) or v.startswith(("\t", "\r", "\n"))
            else v
        )

    with plik.open("x", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(("Konto", "Środowisko", "SKU", "Wynik", "ID Allegro", "Informacja"))
        for w in wyniki:
            writer.writerow(
                tuple(pole(v) for v in (konto, srodowisko, w.sku, w.stan, w.ident, w.komunikat))
            )


class DialogNowychSzkicow(QDialog):
    postep = Signal(int, str)

    def __init__(
        self,
        parent: QWidget,
        serwis: NoweSzkiceAllegro,
        sesja: SesjaAllegro,
        oferty: tuple[OfertaPodglad, ...],
        uruchom: Uruchom,
    ) -> None:
        super().__init__(parent)
        self.serwis, self.sesja, self.oferty, self.uruchom = serwis, sesja, oferty, uruchom
        self.plany: tuple[PlanNowegoSzkicu, ...] = ()
        self.wyniki: tuple[WynikTworzenia, ...] = ()
        self.ilosci: dict[int, int] = {}
        self.ustawienia: dict[int, UstawieniaSzkicu] = {}
        self.trwa = self.nieaktualny = False
        self.stop = Event()
        self.setWindowTitle("Nowe szkice Allegro z paczki ZIP")
        self.resize(1280, 760)
        layout = QVBoxLayout(self)
        tytul = etykieta("Nowe szkice Allegro")
        tytul.setObjectName("tytul")
        layout.addWidget(tytul)
        layout.addWidget(
            etykieta(
                f"Konto: {sesja.konto.login} • {sesja.srodowisko.value} • {len(oferty)} pozycji"
            )
        )
        layout.addWidget(
            etykieta(
                "Sprawdź dopasowania i dane. Utworzenie szkiców nie uruchamia "
                "sprzedaży. Zdjęcia HTTPS zostaną przesłane do Allegro."
            )
        )
        self.formularz = QWidget()
        form = QFormLayout(self.formularz)
        self.waluta = QComboBox()
        self.waluta.setAccessibleName("Waluta cen brutto z paczki")
        self.waluta.addItem("Wybierz walutę cen brutto", "")
        for waluta in ("PLN", "EUR", "CZK", "HUF"):
            self.waluta.addItem(waluta, waluta)
        self.ilosc = QSpinBox()
        self.ilosc.setAccessibleName("Ilość w każdym nowym szkicu")
        self.ilosc.setRange(0, 10000000)
        self.ilosc.setValue(1)
        form.addRow("Waluta (jawnie dla całej paczki)", self.waluta)
        form.addRow("Domyślna ilość (wyjątki w tabeli)", self.ilosc)
        layout.addWidget(self.formularz)
        actions = QHBoxLayout()
        self.sprawdz_przycisk = QPushButton("Sprawdź paczkę")
        self.produkt_przycisk = QPushButton("Wybierz produkt Allegro…")
        self.nowy_przycisk = QPushButton("Nowy produkt w Allegro…")
        self.nowy_przycisk.setToolTip(
            "Produkt nie istnieje w katalogu? Wybierz kategorię i przygotuj jego zgłoszenie."
        )
        self.uzupelnij_przycisk = QPushButton("Uzupełnij wybraną…")
        self.utworz_przycisk = QPushButton("Utwórz szkice w Allegro…")
        self.utworz_przycisk.setObjectName("primary")
        self.wynik_przycisk = QPushButton("Sprawdź wyniki wysyłki")
        self.eksport = QPushButton("Eksportuj raport…")
        self.anuluj = QPushButton("Zatrzymaj serię")
        self.anuluj.clicked.connect(self.stop.set)
        self.przyciski: tuple[QPushButton, ...] = (
            self.sprawdz_przycisk,
            self.produkt_przycisk,
            self.uzupelnij_przycisk,
            self.utworz_przycisk,
            self.wynik_przycisk,
            self.eksport,
        )
        for b in self.przyciski[:4]:
            actions.addWidget(b)
        layout.addLayout(actions)
        nowe = QHBoxLayout()
        nowe.addWidget(self.nowy_przycisk)
        nowe.addWidget(
            etykieta(
                "Brak produktu w katalogu? Przygotuj nowy produkt, potem uzupełnij parametry."
            ),
            1,
        )
        layout.addLayout(nowe)
        self.przyciski += (self.nowy_przycisk,)
        wybor = QHBoxLayout()
        self.wszystkie = QPushButton("Zaznacz widoczne")
        self.odznacz = QPushButton("Odznacz")
        self.masowa = QPushButton("Edytuj zaznaczone…")
        self.parametry_masowe = QPushButton("Parametry zaznaczonych…")
        self.filtr = QComboBox()
        for nazwa in ("Wszystkie pozycje", "Gotowe", "Do poprawy"):
            self.filtr.addItem(nazwa)
        self.filtr.setAccessibleName("Filtr gotowości paczki")
        self.zakres = etykieta("Zaznaczono: 0")
        for widget in (
            self.wszystkie,
            self.odznacz,
            self.masowa,
            self.parametry_masowe,
            self.filtr,
            self.zakres,
        ):
            wybor.addWidget(widget)
        layout.addLayout(wybor)
        self.przyciski += (self.wszystkie, self.odznacz, self.masowa, self.parametry_masowe)
        self.tabela = QTableWidget(len(oferty), 7)
        self.tabela.setHorizontalHeaderLabels(
            (
                "SKU",
                "Tytuł z paczki",
                "Produkt Allegro",
                "Cena brutto",
                "Wynik",
                "ID Allegro",
                "Ilość",
            )
        )
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.verticalHeader().hide()
        self.tabela.verticalHeader().setDefaultSectionSize(40)
        self.tabela.setShowGrid(False)
        header = self.tabela.horizontalHeader()
        header.setStretchLastSection(False)
        for col, width in ((0, 115), (3, 120), (4, 200), (5, 130)):
            self.tabela.setColumnWidth(col, width)
        for col in (1, 2):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.Stretch)
        self.tabela.setAccessibleName("Plan i wyniki tworzenia szkiców z ZIP")
        for i, o in enumerate(oferty):
            for j, tekst in enumerate(
                (o.sku, o.tytul, "Do sprawdzenia", o.cena, "Nie sprawdzono", "", "1")
            ):
                self.tabela.setItem(i, j, QTableWidgetItem(tekst))
        layout.addWidget(self.tabela, 1)
        bottom = QHBoxLayout()
        for b in (self.wynik_przycisk, self.eksport, self.anuluj):
            bottom.addWidget(b)
        layout.addLayout(bottom)
        self.pasek = QProgressBar()
        self.pasek.hide()
        layout.addWidget(self.pasek)
        self.info = etykieta(
            "Wybierz walutę i sprawdź dane. Braki zostaną wskazane przy każdej pozycji."
        )
        layout.addWidget(self.info)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        close.rejected.connect(self.reject)
        layout.addWidget(close)
        self.sprawdz_przycisk.clicked.connect(self.przygotuj)
        self.produkt_przycisk.clicked.connect(self.wybierz_produkt)
        self.nowy_przycisk.clicked.connect(self.nowy_produkt)
        self.uzupelnij_przycisk.clicked.connect(self.uzupelnij)
        self.utworz_przycisk.clicked.connect(self.tworz)
        self.wynik_przycisk.clicked.connect(lambda: self.wyslij(True))
        self.eksport.clicked.connect(self.eksportuj)
        self.waluta.currentIndexChanged.connect(self.uniewaznij)
        self.ilosc.valueChanged.connect(self.uniewaznij)
        self.wszystkie.clicked.connect(self.zaznacz_widoczne)
        self.odznacz.clicked.connect(self.tabela.clearSelection)
        self.masowa.clicked.connect(self.edytuj_masowo)
        self.parametry_masowe.clicked.connect(lambda: self.uzupelnij(True))
        self.filtr.currentIndexChanged.connect(self._filtruj)
        self.postep.connect(self._postep)
        self.tabela.itemSelectionChanged.connect(self._szczegoly_wyniku)
        self._przyciski()

    def wybrane(self) -> tuple[int, ...]:
        return tuple(
            sorted(
                i.row()
                for i in self.tabela.selectionModel().selectedRows()
                if not self.tabela.isRowHidden(i.row())
            )
        )

    def zakres_wysylki(self) -> tuple[int, ...]:
        return self.wybrane() or tuple(
            i for i in range(len(self.plany)) if not self.tabela.isRowHidden(i)
        )

    def _wybor(self) -> None:
        rows = self.wybrane()
        gotowe = sum(not self.plany[i].bledy for i in rows if i < len(self.plany))
        self.zakres.setText(f"Zaznaczono: {len(rows)} • gotowe: {gotowe}")
        self.utworz_przycisk.setEnabled(
            not self.trwa
            and not self.nieaktualny
            and any(not self.plany[i].bledy for i in self.zakres_wysylki() if i < len(self.plany))
        )
        self.utworz_przycisk.setText(
            "Utwórz zaznaczone szkice…" if rows else "Utwórz gotowe szkice…"
        )

    def _filtruj(self) -> None:
        for i in range(len(self.oferty)):
            ready = i < len(self.plany) and not self.plany[i].bledy
            hide = (self.filtr.currentIndex() == 1 and not ready) or (
                self.filtr.currentIndex() == 2 and ready
            )
            if hide:
                for col in range(self.tabela.columnCount()):
                    self._komorka(i, col).setSelected(False)
            self.tabela.setRowHidden(i, hide)
        self._wybor()

    def zaznacz_widoczne(self) -> None:
        self.tabela.selectAll()
        self._filtruj()

    def edytuj_masowo(self) -> None:
        rows = self.wybrane()
        if not rows or self.trwa or self.nieaktualny:
            self.info.setText("Zaznacz pozycje do edycji (Ctrl/Shift lub Zaznacz widoczne).")
            return
        d = MasowaPaczkaAllegro(self, tuple((self.oferty[i], self._ustawienia(i)) for i in rows))
        if d.exec() != QDialog.DialogCode.Accepted or self.nieaktualny or not d.wynik:
            return
        oferty = list(self.oferty)
        for i, (o, u) in zip(rows, d.wynik, strict=True):
            oferty[i], self.ustawienia[i], self.ilosci[i] = o, u, u.ilosc
        self.oferty = tuple(oferty)
        self.uniewaznij()
        self.przygotuj()

    def _szczegoly_wyniku(self) -> None:
        self._wybor()
        row = self.tabela.currentRow()
        if not self.trwa and 0 <= row < len(self.wyniki):
            self.info.setText(self.wyniki[row].komunikat[:1200])

    def _postep(self, numer: int, sku: str) -> None:
        self.info.setText(
            f"Pozycja {numer}/{len(self.oferty)} • {sku}. Żądania już wysłanego nie można cofnąć."
        )

    def _przyciski(self) -> None:
        for b in self.przyciski:
            b.setEnabled(not self.trwa and not self.nieaktualny)
        self.utworz_przycisk.setEnabled(
            not self.trwa and not self.nieaktualny and any(not p.bledy for p in self.plany)
        )
        self.wynik_przycisk.setEnabled(not self.trwa and not self.nieaktualny and bool(self.plany))
        self.eksport.setEnabled(not self.trwa and bool(self.wyniki))
        self.formularz.setEnabled(not self.trwa and not self.nieaktualny)
        self.anuluj.setEnabled(self.trwa)
        self._wybor()

    def uniewaznij(self) -> None:
        self.plany = ()
        self._przyciski()
        self.info.setText("Ustawienia zmienione. Sprawdź paczkę ponownie.")

    def zmiana_sesji(self) -> None:
        self.nieaktualny = True
        self.stop.set()
        self.info.setText(
            "Sesja konta zmieniła się. Zatrzymano dalsze żądania; zachowaj "
            "raport i otwórz plan ponownie."
        )
        self._przyciski()

    def _zadanie(self, funkcja: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self.trwa or self.nieaktualny:
            return
        self.trwa = True
        self.stop.clear()
        self.pasek.setRange(0, 0)
        self.pasek.show()
        self._przyciski()

        def gotowe(wynik: object) -> None:
            self.trwa = False
            self.pasek.hide()
            sukces(wynik)
            self._przyciski()

        def blad(kod: str, opis: str) -> None:
            self.trwa = False
            self.pasek.hide()
            self.info.setText(opis)
            self._przyciski()

        self.uruchom(funkcja, gotowe, blad)

    def _ustawienia(self, i: int) -> UstawieniaSzkicu:
        return replace(
            self.ustawienia.get(i, UstawieniaSzkicu("", 1)),
            waluta=str(self.waluta.currentData()),
            ilosc=self.ilosci.get(i, self.ilosc.value()),
        )

    def przygotuj(self) -> None:
        self.plany = ()
        ustawienia = tuple(self._ustawienia(i) for i in range(len(self.oferty)))
        duplikaty = Counter(o.sku.strip().casefold() for o in self.oferty)

        def zadanie() -> tuple[PlanNowegoSzkicu, ...]:
            wynik = []
            for i, (o, u) in enumerate(zip(self.oferty, ustawienia, strict=True)):
                if self.stop.is_set():
                    break
                self.postep.emit(i + 1, o.sku)
                p = self.serwis.przygotuj(self.sesja, o, u)
                if duplikaty[o.sku.strip().casefold()] > 1:
                    p = replace(
                        p,
                        bledy=(
                            *p.bledy,
                            "Powtórzone SKU w paczce. Rozdziel pozycje przed wysyłką.",
                        ),
                    )
                wynik.append(p)
            return tuple(wynik)

        def gotowe(w: object) -> None:
            self.plany = cast(tuple[PlanNowegoSzkicu, ...], w)
            self.wyniki = tuple(
                WynikTworzenia(
                    p.oferta.sku,
                    "Do poprawy" if p.bledy else "Gotowa do utworzenia",
                    "; ".join(p.bledy)
                    or "Sprawdź nazwę dopasowanego produktu przed potwierdzeniem.",
                )
                for p in self.plany
            )
            self.wyniki += tuple(
                WynikTworzenia(
                    o.sku, "Nie sprawdzono", "Sprawdzanie zostało przerwane. Nie wysłano tworzenia."
                )
                for o in self.oferty[len(self.plany) :]
            )
            self._pokaz_plan()
            self.info.setText(
                f"Sprawdzono {len(self.plany)} pozycji. "
                f"Gotowe: {sum(not p.bledy for p in self.plany)}. "
                "Wymagania warunkowe i gotowość do "
                f"sprzedaży ostatecznie ocenia Allegro."
            )

        self._zadanie(zadanie, gotowe)

    def _komorka(self, row: int, col: int) -> QTableWidgetItem:
        item = self.tabela.item(row, col)
        if item is None:
            item = QTableWidgetItem()
            self.tabela.setItem(row, col, item)
        return item

    def _pokaz_plan(self) -> None:
        for i, p in enumerate(self.plany):
            self._komorka(i, 2).setText(
                ("Nowy produkt • " if p.ustawienia.nowy else "") + p.produkt.nazwa
                if p.produkt
                else "Wybierz lub utwórz produkt"
            )
            self._komorka(i, 2).setToolTip(p.produkt.id if p.produkt else "")
            self._komorka(i, 1).setText(p.oferta.tytul)
            self._komorka(i, 6).setText(str(p.ustawienia.ilosc))
            self._komorka(i, 3).setText(
                (p.ustawienia.cena or p.oferta.cena) + " " + p.ustawienia.waluta
            )
        self._pokaz_wyniki()
        self._filtruj()

    def _pokaz_wyniki(self) -> None:
        for i, w in enumerate(self.wyniki):
            self._komorka(i, 4).setText(w.stan)
            self._komorka(i, 4).setToolTip(w.komunikat)
            self._komorka(i, 5).setText(w.ident)

    def wybierz_produkt(self) -> None:
        i = self.tabela.currentRow()
        if not 0 <= i < len(self.oferty) or self.trwa or self.nieaktualny:
            return
        d = QDialog(self)
        d.setWindowTitle("Wybierz istniejący produkt z Katalogu Allegro")
        d.resize(700, 240)
        layout = QVBoxLayout(d)
        fraza = QLineEdit(self.oferty[i].ean or self.oferty[i].tytul)
        fraza.setAccessibleName("EAN lub nazwa produktu Allegro")
        search = QPushButton("Szukaj w Katalogu Allegro")
        wybor = QComboBox()
        wybor.setAccessibleName("Wyniki wyszukiwania produktów Allegro")
        info = etykieta("Wybór nie tworzy ani nie zmienia produktu w katalogu.")
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Wybierz")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
        for widget in (fraza, search, wybor, info, buttons):
            layout.addWidget(widget)

        def szukaj() -> None:
            query = fraza.text().strip()
            self.trwa = True
            self._przyciski()
            d.setEnabled(False)

            def gotowe(w: object) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                wybor.clear()
                for p in cast(tuple[ProduktSzkicu, ...], w):
                    wybor.addItem(p.nazwa + " • " + p.id, p.id)
                buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(wybor.count() > 0)
                info.setText("Wybierz właściwy produkt. Dla kolejnych wyników zawęź wyszukiwanie.")

            def blad(k: str, m: str) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                info.setText(m)

            self.uruchom(lambda: self.serwis.api.znajdz_produkty(self.sesja, query), gotowe, blad)

        def wybierz() -> None:
            if self.nieaktualny:
                d.reject()
                return
            self.ustawienia[i] = replace(
                self._ustawienia(i),
                produkt=str(wybor.currentData()),
                wartosci=(),
                nowy=False,
                kategoria="",
                zrodla=(),
            )
            d.accept()
            self.uniewaznij()
            self.przygotuj()

        search.clicked.connect(szukaj)
        buttons.accepted.connect(wybierz)
        buttons.rejected.connect(d.reject)
        d.exec()

    def _zastosuj_kategorie(
        self, i: int, kategoria: str, wszystkie: bool, wiersze: tuple[int, ...] = ()
    ) -> None:
        for row in range(len(self.oferty)):
            u = self._ustawienia(row)
            dopasowany = (
                row < len(self.plany)
                and self.plany[row].produkt is not None
                and not self.plany[row].ustawienia.nowy
            )
            if row == i or row in wiersze or (wszystkie and not u.produkt and not dopasowany):
                self.ustawienia[row] = replace(
                    u, nowy=True, kategoria=kategoria, produkt="", wartosci=(), zrodla=()
                )
        self.uniewaznij()
        self.przygotuj()

    def nowy_produkt(self) -> None:
        i = self.tabela.currentRow()
        if not 0 <= i < len(self.oferty) or self.trwa or self.nieaktualny:
            self.info.setText("Zaznacz pozycję, dla której chcesz przygotować nowy produkt.")
            return
        rows = self.wybrane()
        d = QDialog(self)
        d.setWindowTitle("Nowy produkt • wybierz kategorię Allegro")
        d.resize(850, 320)
        layout = QVBoxLayout(d)
        layout.addWidget(
            etykieta(
                "To przygotuje zgłoszenie do Katalogu Allegro. "
                "Wysłanie wymaga późniejszego potwierdzenia."
            )
        )
        fraza = QLineEdit(self.oferty[i].tytul)
        fraza.setAccessibleName("Nazwa produktu lub kategorii")
        szukaj = QPushButton("Znajdź kategorie")
        wybor = QComboBox()
        wybor.setAccessibleName("Kategoria nowego produktu Allegro")
        razem = QCheckBox("Zastosuj kategorię do wszystkich pozycji bez produktu Allegro")
        info = etykieta(
            f"Wybrany zakres: {len(rows) or 1} pozycji. "
            "Program pobierze wymagane parametry kategorii."
        )
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        ok = buttons.button(QDialogButtonBox.StandardButton.Ok)
        ok.setText("Wybierz kategorię")
        ok.setEnabled(False)
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        for widget in (fraza, szukaj, wybor, razem, info, buttons):
            layout.addWidget(widget)

        def search() -> None:
            query = fraza.text().strip()
            self.trwa = True
            self._przyciski()
            d.setEnabled(False)

            def gotowe(w: object) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                wybor.clear()
                wybor.addItem("Wybierz kategorię…", "")
                for k in cast(tuple[KategoriaSzkicu, ...], w):
                    wybor.addItem(k.nazwa + " • " + k.id, k.id)
                info.setText(
                    "Wybierz kategorię z listy."
                    if wybor.count() > 1
                    else "Brak kategorii. Zmień wyszukiwaną nazwę."
                )

            def blad(k: str, opis: str) -> None:
                self.trwa = False
                self._przyciski()
                d.setEnabled(True)
                info.setText(opis)

            self.uruchom(lambda: self.serwis.api.kategorie(self.sesja, query), gotowe, blad)

        wybor.currentIndexChanged.connect(lambda: ok.setEnabled(bool(wybor.currentData())))
        szukaj.clicked.connect(search)
        buttons.accepted.connect(d.accept)
        buttons.rejected.connect(d.reject)
        if d.exec() == QDialog.DialogCode.Accepted and not self.nieaktualny and wybor.currentData():
            self._zastosuj_kategorie(i, str(wybor.currentData()), razem.isChecked(), rows)

    def _zastosuj_parametry(
        self,
        i: int,
        cena: str,
        wartosci: tuple[tuple[str, str], ...],
        zrodla: tuple[tuple[str, str], ...],
        wszystkie: bool,
    ) -> None:
        p = self.plany[i]
        self.ustawienia[i] = replace(p.ustawienia, cena=cena, wartosci=wartosci, zrodla=zrodla)
        if wszystkie and p.ustawienia.nowy:
            for row in range(len(self.oferty)):
                u = self._ustawienia(row)
                if row != i and u.nowy and u.kategoria == p.ustawienia.kategoria:
                    self.ustawienia[row] = replace(u, wartosci=wartosci, zrodla=zrodla)
        self.uniewaznij()
        self.przygotuj()

    def uzupelnij(self, masowo: bool = False) -> None:
        i = self.tabela.currentRow()
        if not 0 <= i < len(self.plany) or self.trwa:
            return
        p = self.plany[i]
        if p.produkt is None:
            if masowo:
                self.info.setText("Najpierw wybierz kategorię lub produkt i sprawdź paczkę.")
                return
            self.wybierz_produkt()
            return
        rows = self.wybrane() if masowo else (i,)
        if masowo and (
            not rows
            or any(
                row >= len(self.plany)
                or self.plany[row].produkt is None
                or cast(ProduktSzkicu, self.plany[row].produkt).kategoria != p.produkt.kategoria
                or self.plany[row].ustawienia.nowy != p.ustawienia.nowy
                for row in rows
            )
        ):
            self.info.setText(
                "Parametry zbiorcze wymagają tej samej kategorii i trybu produktu. "
                "Wybierz zgodne pozycje."
            )
            return
        d = QDialog(self)
        d.setWindowTitle("Uzupełnij dane szkicu • " + p.oferta.sku)
        d.resize(700, 600)
        outer = QVBoxLayout(d)
        outer.addWidget(etykieta(p.produkt.nazwa + " • kategoria " + p.produkt.kategoria))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        host = QWidget()
        form = QFormLayout(host)
        cena = QLineEdit(p.ustawienia.cena or p.oferta.cena)
        if not masowo:
            form.addRow("Cena brutto (" + p.ustawienia.waluta + ")", cena)
        else:
            outer.addWidget(
                etykieta(
                    f"Zaznaczono {len(rows)} pozycji. "
                    "Zaznacz wyłącznie parametry do wspólnej zmiany."
                )
            )
        zmieniane: dict[str, QCheckBox] = {}
        pola: dict[str, QComboBox | QLineEdit] = {}
        zrodla: dict[str, QComboBox] = {}
        for req in p.produkt.parametry:
            if req.produktowy and not p.ustawienia.nowy:
                continue
            value = dict(p.ustawienia.wartosci).get(req.id, "")
            if req.typ == "dictionary":
                pole = QComboBox()
                pole.addItem("Wybierz wartość", "")
                for ident, nazwa in req.slownik:
                    pole.addItem(nazwa, ident)
                pole.setCurrentIndex(max(0, pole.findData(value)))
                pola[req.id] = pole
            else:
                tekst = QLineEdit(value)
                tekst.setMaxLength(1000)
                pola[req.id] = tekst
            pola[req.id].setAccessibleName(req.nazwa)
            produktowy = req.produktowy or (p.ustawienia.nowy and req.wymagany_produkt)
            wymagany = req.wymagany or (produktowy and req.wymagany_produkt)
            nazwa = (
                req.nazwa
                + (" *" if wymagany else "")
                + (" • produkt" if produktowy else " • oferta")
            )
            if masowo:
                check = QCheckBox(nazwa)
                zmieniane[req.id] = check
                form.addRow(check, pola[req.id])
            else:
                form.addRow(nazwa, pola[req.id])
            if p.ustawienia.nowy and req.typ != "dictionary":
                source = QComboBox()
                source.setAccessibleName("Źródło parametru " + req.nazwa)
                source.addItem("Wspólna wartość wpisana powyżej", "")
                source.addItem("SKU z każdej pozycji paczki", "sku")
                source.addItem("EAN z każdej pozycji paczki", "ean")
                source.setCurrentIndex(
                    max(0, source.findData(dict(p.ustawienia.zrodla).get(req.id, "")))
                )
                zrodla[req.id] = source
                form.addRow("Źródło • " + req.nazwa, source)
        scroll.setWidget(host)
        outer.addWidget(scroll)
        outer.addWidget(
            etykieta(
                "* Parametry wymagane. Ograniczenia i wymagania warunkowe "
                "dodatkowo sprawdza Allegro. Dane dostawy/GPSR i gotowość do "
                "sprzedaży wymagają osobnego uzupełnienia."
            )
        )
        razem = QCheckBox("Zastosuj parametry i źródła do nowych produktów w tej samej kategorii")
        razem.setVisible(p.ustawienia.nowy and not masowo)
        outer.addWidget(razem)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Zastosuj")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.accepted.connect(d.accept)
        buttons.rejected.connect(d.reject)
        outer.addWidget(buttons)
        if d.exec() == QDialog.DialogCode.Accepted:
            wartosci = tuple(
                (ident, str(w.currentData()) if isinstance(w, QComboBox) else w.text())
                for ident, w in pola.items()
            )
            sources = tuple(
                (ident, str(w.currentData())) for ident, w in zrodla.items() if w.currentData()
            )
            if masowo:
                chosen = {ident for ident, check in zmieniane.items() if check.isChecked()}
                if not chosen:
                    self.info.setText("Nie zaznaczono parametrów do zmiany.")
                    return
                for row in rows:
                    self.ustawienia[row] = zmien_parametry(
                        self._ustawienia(row),
                        tuple(v for v in wartosci if v[0] in chosen),
                        tuple(v for v in sources if v[0] in chosen),
                    )
                self.uniewaznij()
                self.przygotuj()
            else:
                self._zastosuj_parametry(
                    i, cena.text().strip(), wartosci, sources, razem.isChecked()
                )

    def tworz(self) -> None:
        rows = self.zakres_wysylki()
        gotowe = sum(not self.plany[i].bledy for i in rows if i < len(self.plany))
        if not gotowe or self.nieaktualny or self.trwa:
            return
        nowych = sum(
            not p.bledy and p.ustawienia.nowy for i, p in enumerate(self.plany) if i in rows
        )
        katalog = (
            f"\nUWAGA: dla {nowych} pozycji wyślesz definicje NOWYCH PRODUKTÓW "
            "do Katalogu Allegro. "
            "Allegro może utworzyć produkty lub dopasować istniejące. "
            "Potwierdzasz także ten skutek katalogowy.\n"
            if nowych
            else ""
        )
        if (
            QMessageBox.question(
                self,
                "Utwórz nowe szkice Allegro",
                f"Konto: {self.sesja.konto.login}\nŚrodowisko: "
                f"{self.sesja.srodowisko.value}\n\nUtworzyć {gotowe} nowych "
                f"szkiców INACTIVE? Pozostałe pozycje zostaną pominięte.\nWaluta: "
                f"{self.waluta.currentData()}, ilość w szkicu: "
                f"według planu. Zakres: {len(rows)} pozycji.\nSprawdź produkty, ceny i "
                f"parametry. Zdjęcia zostaną przesłane do Allegro.\nOferty nie "
                f"zostaną opublikowane do sprzedaży.{katalog}",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            == QMessageBox.StandardButton.Yes
        ):
            self.wyslij(False)

    def wyslij(self, sprawdzenie: bool) -> None:
        if not self.plany or self.nieaktualny or self.trwa:
            return
        plany = self.plany
        rows = self.zakres_wysylki()
        poprzednie = self.wyniki

        def praca() -> tuple[WynikTworzenia, ...]:
            wynik = []
            zatrzymano = False
            for i, p in enumerate(plany):
                self.postep.emit(i + 1, p.oferta.sku)
                if i not in rows:
                    wynik.append(
                        poprzednie[i]
                        if i < len(poprzednie)
                        else WynikTworzenia(p.oferta.sku, "Pominięto", "Poza zakresem wysyłki.")
                    )
                elif self.stop.is_set() or zatrzymano:
                    wynik.append(
                        WynikTworzenia(
                            p.oferta.sku, "Wstrzymano", "Nie wykonano kolejnego żądania."
                        )
                    )
                elif p.bledy:
                    wynik.append(WynikTworzenia(p.oferta.sku, "Do poprawy", "; ".join(p.bledy)))
                else:
                    try:
                        w = (
                            self.serwis.sprawdz(self.sesja, p)
                            if sprawdzenie
                            else self.serwis.utworz(self.sesja, p, self.stop.is_set)
                        )
                        wynik.append(w)
                        zatrzymano = w.stan in {"Wynik nieznany", "Wymaga sprawdzenia"}
                    except BladAllegro as exc:
                        stan = "Odrzucono" if exc.kod == "ODRZUCONO" else "Wymaga sprawdzenia"
                        wynik.append(WynikTworzenia(p.oferta.sku, stan, str(exc)))
                        zatrzymano = exc.kod in {
                            "WYGASLA",
                            "AUTORYZACJA",
                            "NIEZNANY",
                            "REJESTR",
                        } or any(f"HTTP {n}" in str(exc) for n in (401, 403, 429))
            wynik.extend(
                WynikTworzenia(
                    o.sku, "Nie sprawdzono", "Pozycja nie została sprawdzona ani wysłana."
                )
                for o in self.oferty[len(plany) :]
            )
            return tuple(wynik)

        def gotowe(w: object) -> None:
            self.wyniki = cast(tuple[WynikTworzenia, ...], w)
            self._pokaz_wyniki()
            liczby = Counter(w.stan for w in self.wyniki)
            self.info.setText(
                " • ".join(f"{nazwa}: {ile}" for nazwa, ile in liczby.items())
                + ". Zachowaj raport. Nieznany wynik wymaga sprawdzenia, bez ponawiania POST."
            )

        self._zadanie(praca, gotowe)

    def eksportuj(self) -> None:
        nazwa, _ = QFileDialog.getSaveFileName(
            self, "Zapisz raport", "raport-szkicow-allegro.csv", "CSV (*.csv)"
        )
        if nazwa:
            try:
                zapisz_raport(
                    Path(nazwa), self.wyniki, self.sesja.konto.login, self.sesja.srodowisko.value
                )
            except OSError:
                self.info.setText(
                    "Nie zapisano raportu. Wybierz nową nazwę; istniejące pliki nie są nadpisywane."
                )

    def reject(self) -> None:
        if self.trwa:
            self.stop.set()
            self.info.setText(
                "Zatrzymywanie serii po bieżącym żądaniu. Zaczekaj na raport przed zamknięciem."
            )
            return
        super().reject()
