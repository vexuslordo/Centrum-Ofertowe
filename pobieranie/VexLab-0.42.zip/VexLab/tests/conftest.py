"""Wspólne izolowane fixture'y; nigdy nie są ładowane przez aplikację."""

import pytest

from vexlab.przypadki_uzycia.katalog import DaneProduktu


@pytest.fixture
def stare_powiazania():
    """Odtwarza relacje istniejące przed 0.20, do testów ich dalszej ochrony."""

    def powiaz(serwis, katalog, repo):
        for d in serwis.lista():
            if d.produkt_id is not None:
                continue
            produkt = next(
                (p for p in katalog.wyszukaj() if p.sku.casefold() == d.oferta.sku.casefold()), None
            )
            if produkt is None:
                produkt = katalog.dodaj(DaneProduktu(d.oferta.tytul, d.oferta.sku))
            with repo._polaczenie() as conn:
                conn.execute(
                    "UPDATE szkice SET produkt_id=?,wersja_produktu=? WHERE id=?",
                    (str(produkt.id), produkt.wersja, str(d.id)),
                )

    return powiaz


@pytest.fixture
def nowe_szkice_fixture(tmp_path):
    """Izolowany katalog i API; brak prawdziwych kont i żądań sieciowych."""
    from copy import deepcopy

    from vexlab.adaptery.rejestr_tworzenia_allegro import RejestrTworzeniaJSON
    from vexlab.przypadki_uzycia.allegro import (
        AplikacjaAllegro,
        BladAllegro,
        KontoAllegro,
        SesjaAllegro,
        SrodowiskoAllegro,
    )
    from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
        NoweSzkiceAllegro,
        ParametrSzkicu,
        ProbaTworzenia,
        ProduktSzkicu,
        UstawieniaSzkicu,
    )
    from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad

    class API:
        czas = 100
        calls = []
        wyniki = {}
        awaria = ""
        async_mode = False
        zakonczona = True
        produkt = ProduktSzkicu(
            "c9e39cae-9cb6-11e9-a2a3-2a2ae2dbcce4",
            "Produkt testowy",
            "123",
            (ParametrSzkicu("11323", "Stan", "dictionary", True, (("11323_1", "Nowy"),)),),
        )

        def __init__(self):
            self.calls, self.wyniki = [], {}

        def teraz(self):
            return self.czas

        def znajdz_produkty(self, s, fraza, gtin=False):
            self.calls.append("szukaj")
            return (self.produkt,)

        def produkt_szkicu(self, s, ident):
            self.calls.append("produkt")
            return self.produkt

        def wyslij_zdjecie(self, s, url):
            self.calls.append("zdjecie")
            if self.awaria == "zdjecie":
                raise BladAllegro("ZDJECIE", "Nie przesłano zdjęcia.")
            return "https://a.allegroimg.com/test/" + str(len(self.calls))

        def utworz_szkic(self, s, dane):
            self.calls.append("POST")
            if self.awaria == "odrzucono":
                raise BladAllegro("ODRZUCONO", "HTTP 422. Wymagany parametr.")
            d = deepcopy(dane)
            d["id"] = "12345678"
            self.wyniki[d["external"]["id"]] = d
            if self.awaria == "timeout":
                raise BladAllegro("NIEZNANY", "Timeout po wysłaniu.")
            return ProbaTworzenia(
                "",
                "",
                202 if self.async_mode else 201,
                d["id"],
                "operation" if self.async_mode else "",
            )

        def znajdz_szkic(self, s, external):
            self.calls.append("znajdz")
            return self.wyniki.get(external)

        def odczytaj_szkic(self, s, ident):
            self.calls.append("GET")
            return next(d for d in self.wyniki.values() if d["id"] == ident)

        def operacja_tworzenia(self, s, ident, operacja):
            self.calls.append("operacja")
            return self.zakonczona

    api = API()
    rejestr = RejestrTworzeniaJSON(tmp_path / "tworzenie")
    service = NoweSzkiceAllegro(api, rejestr, api)
    sesja = SesjaAllegro(
        KontoAllegro("123", "testowy"),
        SrodowiskoAllegro.SANDBOX,
        "test-token",
        3700,
        aplikacja=AplikacjaAllegro("test-client", "test-secret", zapis_szkicow=True),
    )
    o = OfertaPodglad(
        1,
        "TEST-1",
        "Testowy produkt do motocykla",
        "<p>Opis</p>",
        "5901234123457",
        "123.40",
        "",
        ("https://images.example.org/produkt.jpg",),
        (
            (
                ElementPodgladu("tekst", "<p>Opis</p>"),
                ElementPodgladu("obraz", adres="https://images.example.org/produkt.jpg"),
            ),
        ),
        (),
    )
    u = UstawieniaSzkicu("PLN", 1, wartosci=(("11323", "11323_1"),))
    return service, api, rejestr, sesja, o, u


@pytest.fixture
def nowe_produkty_fixture(nowe_szkice_fixture):
    from copy import deepcopy
    from dataclasses import replace

    from vexlab.przypadki_uzycia.nowe_szkice_allegro import KategoriaSzkicu, ParametrSzkicu

    serwis, api, repo, s, o, u = nowe_szkice_fixture
    api.produkt = replace(
        api.produkt,
        parametry=api.produkt.parametry
        + (
            ParametrSzkicu("kod", "Kod producenta", "string", False, (), True, True),
            ParametrSzkicu("ean", "EAN", "string", False, (), True, False),
        ),
    )
    api.kategorie = lambda *a: (KategoriaSzkicu("123", "Motoryzacja / Części"),)

    def nowy(s, kategoria, odswiez=False):
        api.calls.append("nowy-swiezy" if odswiez else "nowy")
        return replace(api.produkt, id="", nazwa="Kategoria", kategoria=kategoria)

    api.nowy_produkt = nowy
    api.katalog = None
    api.przeslane = None
    original = api.utworz_szkic

    def utworz(s, dane):
        api.przeslane = deepcopy(dane)
        definition = dane["productSet"][0]["product"]
        dane = deepcopy(dane)
        if "id" not in definition:
            api.katalog = deepcopy(definition)
            dane["productSet"] = [
                {"product": {"id": api.produkt.id, "publication": {"status": "LISTED"}}}
            ]
        return original(s, dane)

    api.utworz_szkic = utworz

    def potwierdz(s, ident, nazwa, kategoria, parametry):
        api.calls.append("katalog-GET")
        return bool(
            api.katalog
            and ident == api.produkt.id
            and api.katalog["name"] == nazwa
            and api.katalog["category"] == {"id": kategoria}
            and api.katalog["parameters"] == parametry
        )

    api.potwierdz_nowy = potwierdz
    u = replace(u, nowy=True, kategoria="123", zrodla=(("kod", "sku"), ("ean", "ean")))
    return serwis, api, repo, s, o, u
