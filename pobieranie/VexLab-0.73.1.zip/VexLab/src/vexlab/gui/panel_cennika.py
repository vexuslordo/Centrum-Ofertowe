"""Szczegóły pozycji i branding źródła. Bez obliczeń cen i operacji biznesowych."""

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.branding_cennikow import BrandingCennikow
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.cenniki import CennikDTO, PozycjaCennika
from vexlab.przypadki_uzycia.ceny_cennika import etykieta_cennika


class PanelCennika(QFrame):
    logo_zadane = Signal()
    historia_zadana = Signal()
    roznice_zadane = Signal()
    producent_zadany = Signal()

    def __init__(self, branding: BrandingCennikow, dodaj: QPushButton) -> None:
        super().__init__()
        self.branding = branding
        self.setObjectName("panelCennika")
        self.setMinimumWidth(0)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        title = etykieta("Szczegóły produktu")
        title.setObjectName("tytulCennika")
        layout.addWidget(title)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        body = QWidget()
        box = QVBoxLayout(body)
        box.setContentsMargins(0, 8, 0, 8)
        box.setSpacing(12)
        self.logo = QLabel("—")
        self.logo.setFixedHeight(90)
        self.logo.setStyleSheet("font-size:28px;font-weight:600;")
        self.logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo.setAccessibleName("Logo producenta cennika")
        box.addWidget(self.logo)
        self.producent = etykieta("Wybierz cennik")
        self.producent.setObjectName("tytulCennika")
        box.addWidget(self.producent)
        self.wydanie = etykieta("")
        self.wydanie.setObjectName("opis")
        box.addWidget(self.wydanie)
        logo_button = QPushButton("Ustaw logo producenta…")
        logo_button.clicked.connect(self.logo_zadane)
        logo_button.setToolTip("Własny plik PNG, JPG lub WebP. Bez pobierania z internetu.")
        self.logo_przycisk = logo_button
        box.addWidget(logo_button)
        self.pola: dict[str, QLabel] = {}
        for key in (
            "Produkt",
            "SKU",
            "EAN",
            "Status",
            "Cena brutto",
            "Cena netto",
            "VAT",
            "Cena bazowa",
            "Zmiana ceny",
            "Źródło",
            "Dane dodatkowe",
        ):
            frame = QFrame()
            frame.setObjectName("poleCennika")
            column = QVBoxLayout(frame)
            column.setContentsMargins(0, 8, 0, 6)
            column.setSpacing(3)
            caption = etykieta(key)
            caption.setObjectName("opis")
            column.addWidget(caption)
            value = etykieta("—")
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            value.setAccessibleName(key)
            column.addWidget(value)
            self.pola[key] = value
            box.addWidget(frame)
        box.addStretch()
        scroll.setWidget(body)
        layout.addWidget(scroll, 1)
        for text, callback in (
            ("Historia wydań", self.historia_zadana.emit),
            ("Pokaż różnice", self.roznice_zadane.emit),
            ("Otwórz producenta", self.producent_zadany.emit),
        ):
            button = QPushButton(text)
            button.setMinimumHeight(36)
            button.clicked.connect(callback)
            if text == "Historia wydań":
                self.historia = button
            elif text == "Otwórz producenta":
                self.otworz = button
            else:
                self.roznice = button
            layout.addWidget(button)
        dodaj.setMinimumHeight(40)
        dodaj.setObjectName("primary")
        layout.insertWidget(2, dodaj)
        self.ustaw(None, None)

    def ustaw(self, cennik: CennikDTO | None, row: PozycjaCennika | None) -> None:
        for label in self.pola.values():
            label.setText("—")
        self.logo.clear()
        self.logo.setText("—")
        self.producent.setText(cennik.producent or "Bez producenta" if cennik else "Wybierz cennik")
        self.wydanie.setText(f"{cennik.nazwa} · {cennik.rok}\n{cennik.status}" if cennik else "")
        self.logo_przycisk.setEnabled(cennik is not None)
        self.historia.setEnabled(cennik is not None)
        self.roznice.setEnabled(cennik is not None)
        self.otworz.setEnabled(cennik is not None and cennik.producent_id is not None)
        if cennik:
            icon = self.branding.logo(cennik)
            if not icon.isNull():
                self.logo.setPixmap(icon.pixmap(180, 80))
            else:
                self.logo.setText((cennik.producent or cennik.nazwa)[:2].upper())
            self.pola["Źródło"].setText(f"{cennik.nazwa}\n{cennik.zrodlo}\n{cennik.wczytano_utc}")
        if row is None:
            self.pola["Produkt"].setText("Wybierz pozycję z listy")
            return
        data = row.pozycja.dane
        for key, value in (
            ("Produkt", data.nazwa),
            ("SKU", data.sku),
            ("EAN", data.ean or "—"),
            ("Status", row.stan),
            ("Zmiana ceny", row.roznica),
        ):
            self.pola[key].setText(value)
        price = row.pozycja.cena
        if price and price.tekst:
            formatted = etykieta_cennika(price.tekst, price.waluta, price.rodzaj)
            lines = formatted.splitlines()
            if len(lines) == 2 and lines[0].startswith("Brutto:"):
                self.pola["Cena brutto"].setText(lines[0].removeprefix("Brutto: "))
                self.pola["Cena netto"].setText(
                    lines[1].removeprefix("Netto: ").replace(" (VAT 23%)", "")
                )
                self.pola["VAT"].setText("23%")
            else:
                self.pola["Cena brutto"].setText(formatted)
        if row.cena_bazowa:
            self.pola["Cena bazowa"].setText(
                row.cena_bazowa.etykieta
                + " · "
                + row.cena_bazowa.rodzaj
                + "\n"
                + row.cena_bazowa.zrodlo
            )
        extra = [
            f"Wiersz źródłowy: {row.pozycja.wiersz}",
            row.problem,
            row.porownanie,
            data.opis,
            *(f"{f.nazwa}: {f.wartosc}" for f in row.pozycja.pola_cennika),
        ]
        self.pola["Dane dodatkowe"].setText("\n".join(filter(None, extra)))
