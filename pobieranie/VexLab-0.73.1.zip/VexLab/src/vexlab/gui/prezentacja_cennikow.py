"""Kompozycja centrum cenników. Zachowuje istniejące kontrolki, selekcję i scenariusze."""

from functools import partial
from typing import TYPE_CHECKING, cast

from PySide6.QtCore import QItemSelectionModel, QPoint, QSettings, Qt
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import (
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMenu,
    QPushButton,
    QSizePolicy,
    QSplitter,
    QStyledItemDelegate,
    QTableWidgetItem,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.branding_cennikow import BrandingCennikow
from vexlab.gui.kafelek_kpi import KafelekKPI
from vexlab.gui.panel_cennika import PanelCennika
from vexlab.gui.wiersze_cennikow import KartaCennika, WierszCennika

if TYPE_CHECKING:
    from vexlab.gui.cenniki import StronaCennikow


class PrezentacjaCennikow:
    def __init__(self, page: "StronaCennikow", settings: QSettings | None = None) -> None:
        self.page = page
        self.branding = BrandingCennikow(settings)
        self.techniczny = False
        self._tryb = ""
        self._kolumny_kpi = 0
        self._ciemny: bool | None = None
        p = page
        p.biblioteka.setObjectName("centrumCennikow")
        p.panel_listy.setObjectName("panelCennika")
        p.szczegoly.setObjectName("panelCennika")
        left = cast(QVBoxLayout, p.panel_listy.layout())
        title = QLabel("Producenci i cenniki")
        title.setObjectName("tytulCennika")
        left.insertWidget(0, title)
        left.insertWidget(1, p.szukaj)
        p.szukaj.setPlaceholderText("Szukaj producenta, cennika lub roku…")
        left.setContentsMargins(10, 12, 10, 10)
        cast(QVBoxLayout, p.szczegoly.layout()).setContentsMargins(10, 10, 10, 10)
        p.tabela.setShowGrid(False)
        p.tabela.setStyleSheet(
            "QTableWidget {background:transparent;border:0;}"
            "QTableWidget::item {background:transparent;border:0;}"
            "QTableWidget::item:selected {background:transparent;}"
        )
        p.tabela.horizontalHeader().hide()
        p.tabela.horizontalScrollBar().hide()
        p.tabela.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        p.tabela.verticalHeader().setDefaultSectionSize(108)
        p.tabela.setItemDelegateForColumn(0, KartaCennika(self.branding))
        p.tabela.horizontalHeader().setStretchLastSection(False)
        p.tabela.horizontalHeader().setMinimumSectionSize(1)
        p.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        p.tabela.setMinimumWidth(0)
        self.panel = PanelCennika(self.branding, p.dodaj_przycisk)
        p.podzial.addWidget(self.panel)
        p.podzial.setChildrenCollapsible(False)
        self.panel.logo_zadane.connect(self._logo)
        self.panel.historia_zadana.connect(self._historia)
        self.panel.roznice_zadane.connect(partial(p.status_pozycji.setCurrentText, "Inna cena"))
        self.panel.producent_zadany.connect(self._producent)
        p.wiersze.currentCellChanged.connect(lambda *_: self.wybor())
        self._kpi()
        self.workspace = QWidget()
        workspace_layout = QVBoxLayout(self.workspace)
        workspace_layout.setContentsMargins(0, 0, 0, 0)
        workspace_layout.setSpacing(12)
        workspace_layout.addWidget(self.kpi_host)
        self.detale_podzial = QSplitter(Qt.Orientation.Horizontal)
        self.detale_podzial.setChildrenCollapsible(False)
        self.detale_podzial.addWidget(p.szczegoly)
        self.detale_podzial.addWidget(self.panel)
        self.detale_podzial.setStretchFactor(0, 1)
        workspace_layout.addWidget(self.detale_podzial, 1)
        p.podzial.addWidget(self.workspace)
        p.podzial.setStretchFactor(0, 0)
        p.podzial.setStretchFactor(1, 1)
        self._kompozycja_naglowka()
        self._chipy()
        self.detale_przycisk = QPushButton("Szczegóły")
        self.detale_przycisk.setCheckable(True)
        self.detale_przycisk.setChecked(True)
        self.detale_przycisk.toggled.connect(self.panel.setVisible)
        self.detale_przycisk.setToolTip("Pokaż lub schowaj panel szczegółów wybranej pozycji.")
        self.panel.setMinimumWidth(0)
        p.filtr.setPlaceholderText("Szukaj nazwy produktu lub SKU…")
        p.filtr.setToolTip(
            "Wyszukiwanie obejmuje cały cennik według nazwy i SKU. EAN jest w szczegółach."
        )
        row = QHBoxLayout()
        row.addWidget(p.filtr, 1)
        row.addWidget(p.status_pozycji)
        row.addWidget(self.detale_przycisk)
        cast(QVBoxLayout, p.szczegoly.layout()).insertLayout(3, row)
        self.kolumny_akcja = p.menu.addAction("Kolumny źródłowe")
        self.kolumny_akcja.setCheckable(True)
        self.kolumny_akcja.toggled.connect(self._tryb_kolumn)
        p.menu.addAction("Ustaw logo producenta…", self._logo)
        p.menu.addAction("Usuń przypisanie logo", self._usun_logo)
        self.delegat = WierszCennika(p.wiersze)
        self.surowy = QStyledItemDelegate(p.wiersze)
        p.wiersze.setItemDelegate(self.delegat)
        p.wiersze.setShowGrid(False)
        p.wiersze.setAlternatingRowColors(True)
        p.wiersze.verticalHeader().setDefaultSectionSize(72)
        p.wiersze.horizontalHeader().setMinimumHeight(48)
        p.wiersze.horizontalHeader().setStretchLastSection(False)
        p.wiersze.horizontalHeader().sectionClicked.connect(self._naglowek)
        p.status_pozycji.currentTextChanged.connect(self._stan_chipow)
        self.kolumny()
        self.kontekst()
        self.motyw()

    def _kompozycja_naglowka(self) -> None:
        layout = cast(QVBoxLayout, self.page.biblioteka.layout())
        title_item, subtitle_item, actions_item = (
            layout.takeAt(0),
            layout.takeAt(0),
            layout.takeAt(0),
        )
        row = QHBoxLayout()
        labels = QVBoxLayout()
        for item in (title_item, subtitle_item):
            widget = item.widget() if item else None
            if widget:
                labels.addWidget(widget)
        row.addLayout(labels, 1)
        actions = actions_item.layout() if actions_item else None
        if actions:
            row.addLayout(actions)
        layout.insertLayout(0, row)
        self.page.dodaj_cennik_przycisk.setText("Importuj cennik")
        self.page.naglowek.setObjectName("tytulCennika")

    def _kpi(self) -> None:
        host = QWidget()
        host.setMinimumWidth(0)
        self.kpi_layout = QGridLayout(host)
        self.kpi_layout.setContentsMargins(0, 0, 0, 0)
        self.kpi_layout.setSpacing(10)
        self.kpi: dict[str, KafelekKPI] = {}
        for i, (key, title, symbol, color) in enumerate(
            (
                ("produkty", "Produkty w cenniku", "Produkty", "#008E78"),
                ("srednia", "Średnia cena", "Cenniki", "#997017"),
                ("zmiany", "Inna cena", "Raporty", "#6A478C"),
                ("bledy", "Do poprawy", "Historia operacji", "#AF2635"),
            )
        ):
            card = KafelekKPI(title, "produkty", "Wybierz cennik", symbol=symbol, akcent=color)
            card.setMinimumWidth(0)
            card.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
            self.kpi[key] = card
            self.kpi_layout.addWidget(card, 0, i)
        self.kpi["srednia"].podpis.setText("Wskaźnik niedostępny")
        self.kpi["srednia"].setToolTip("Obecny odczyt nie udostępnia średniej ceny całego cennika.")
        layout = cast(QVBoxLayout, self.page.szczegoly.layout())
        layout.insertWidget(0, host)
        self.kpi_host = host

    def _chipy(self) -> None:
        host = QWidget()
        grid = QGridLayout(host)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setSpacing(8)
        self.chipy: dict[str, QPushButton] = {}
        for i, (label, status) in enumerate(
            (
                ("Wszystkie", "Wszystkie pozycje"),
                ("Nowe", "Nowy"),
                ("Zmiana ceny", "Inna cena"),
                ("W katalogu", "W katalogu"),
                ("Do poprawy", "Do poprawy"),
            )
        ):
            button = QPushButton(label)
            button.setCheckable(True)
            button.setMinimumHeight(28)
            button.setObjectName("chipCennika")
            button.setAccessibleName("Filtr cennika: " + label)
            button.clicked.connect(partial(self.page.status_pozycji.setCurrentText, status))
            self.chipy[status] = button
            grid.addWidget(button, 0, i)
        extras = QToolButton()
        extras.setText("Więcej filtrów")
        extras.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu = QMenu(extras)
        for label in ("Wzrost", "Spadek", "Brak w katalogu", "Do synchronizacji"):
            action = menu.addAction(label)
            action.setEnabled(False)
            action.setToolTip("Ten filtr nie jest dostępny w obecnym odczycie cennika.")
        menu.setToolTipsVisible(True)
        extras.setMenu(menu)
        grid.addWidget(extras, 0, 5)
        cast(QVBoxLayout, self.page.szczegoly.layout()).insertWidget(2, host)
        self._stan_chipow()

    def _stan_chipow(self) -> None:
        for status, button in self.chipy.items():
            button.setChecked(self.page.status_pozycji.currentText() == status)

    def _naglowek(self, column: int) -> None:
        if column == 0 and not self.techniczny:
            if self.page._indeksy_wyboru():
                self.page.wiersze.clearSelection()
            else:
                self.page.wiersze.selectAll()

    def _tryb_kolumn(self, enabled: bool) -> None:
        self.techniczny = enabled
        self.kolumny()

    def kolumny(self) -> None:
        table = self.page.wiersze
        for col in range(table.columnCount()):
            table.setColumnHidden(col, not self.techniczny and col not in (0, 6, 1, 3, 5))
        header = table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        for col, width in ((0, 34), (6, 120), (1, 360), (3, 180), (5, 145)):
            table.setColumnWidth(col, width)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        labels = (
            (
                (0, "Wiersz"),
                (1, "Nazwa"),
                (3, "Brutto / netto · VAT 23%"),
                (5, "Różnica"),
                (6, "Stan"),
            )
            if self.techniczny
            else ((0, "☐"), (1, "Produkt"), (3, "Cena"), (5, "Zmiana"), (6, "Status"))
        )
        table.setProperty("checkbox_cennika", not self.techniczny)
        for col, label in labels:
            cast(QTableWidgetItem, table.horizontalHeaderItem(col)).setText(label)
        if self.techniczny:
            table.setItemDelegate(self.surowy)
        else:
            table.setItemDelegate(self.delegat)

    def lista(self) -> None:
        self.page.tabela.clearSpans()
        for i in range(self.page.tabela.rowCount()):
            self.page.tabela.setSpan(i, 0, 1, 4)
        self.page.tabela.viewport().update()

    def kontekst(self) -> None:
        c, index = self.page.cennik, self.page.indeks
        self.kpi["produkty"].liczba.setText(str(c.liczba) if c else "—")
        self.kpi["produkty"].podpis.setText("Pozycje całego cennika" if c else "Wybierz cennik")
        for key, status in (("zmiany", "Inna cena"), ("bledy", "Do poprawy")):
            self.kpi[key].liczba.setText(
                str(sum(p.stan == status for p in index.pozycje)) if index else "—"
            )
            self.kpi[key].podpis.setText("Cały cennik" if index else "Brak odczytu")
        if c:
            self.page.metryka.setToolTip(self.page.metryka.text())
            self.page.metryka.setText(
                f"{c.producent or 'Bez producenta'} · {c.liczba} pozycji"
                + (" · Porównanie z poprzednim wydaniem" if c.poprzedni_id else "")
            )
        self.wybor()

    def wybor(self) -> None:
        p = self.page
        cell = p.wiersze.currentIndex()
        row = p.pozycje[cell.row()] if cell.isValid() and 0 <= cell.row() < len(p.pozycje) else None
        self.panel.ustaw(p.cennik, row)

    def _logo(self) -> None:
        c = self.page.cennik
        if c is None:
            self.page.info.setText("Wybierz jeden cennik, aby ustawić logo producenta.")
            return
        path, _ = QFileDialog.getOpenFileName(
            self.page, "Logo producenta", "", "Obrazy (*.png *.jpg *.jpeg *.webp)"
        )
        if path:
            try:
                self.branding.ustaw(c, path)
            except (OSError, ValueError) as exc:
                self.page.info.setText(str(exc))
                return
            self.wybor()
            self.page.tabela.viewport().update()

    def _usun_logo(self) -> None:
        if self.page.cennik:
            self.branding.usun(self.page.cennik)
            self.wybor()
            self.page.tabela.viewport().update()

    def _historia(self) -> None:
        c = self.page.cennik
        if c is None:
            return
        rows = [
            x
            for x in self.page.cenniki
            if x.id == c.id
            or x.id == c.poprzedni_id
            or c.producent_id is not None
            and x.producent_id == c.producent_id
        ]
        menu = QMenu(self.page)
        for source in rows:
            action = menu.addAction(f"{source.nazwa} · {source.rok} · {source.status}")
            action.triggered.connect(partial(self._wybierz_cennik, str(source.id)))
        menu.aboutToHide.connect(menu.deleteLater)
        menu.popup(self.panel.historia.mapToGlobal(QPoint(0, self.panel.historia.height())))

    def _wybierz_cennik(self, ident: str) -> None:
        p = self.page
        p.szukaj.clear()
        for i in range(p.tabela.rowCount()):
            c = cast(QTableWidgetItem, p.tabela.item(i, 0)).data(Qt.ItemDataRole.UserRole)
            if str(c.id) == ident:
                p.tabela.selectionModel().select(
                    p.tabela.model().index(i, 0),
                    QItemSelectionModel.SelectionFlag.ClearAndSelect
                    | QItemSelectionModel.SelectionFlag.Rows,
                )
                p.tabela.scrollTo(p.tabela.model().index(i, 0))
                break

    def _producent(self) -> None:
        if self.page.cennik and self.page.cennik.producent_id:
            self.page.producent_zadany.emit(self.page.cennik.producent)

    def rozmiar(self, width: int) -> None:
        mode = "maly" if width < 1100 else "kompakt" if width < 1600 else "pelny"
        columns = 4 if self.kpi_host.width() >= 750 else 2
        if columns != self._kolumny_kpi:
            self._kolumny_kpi = columns
            for i, card in enumerate(self.kpi.values()):
                self.kpi_layout.removeWidget(card)
                self.kpi_layout.addWidget(card, i // columns, i % columns)
        if mode == self._tryb:
            return
        self._tryb = mode
        self.page.podzial.setOrientation(
            Qt.Orientation.Vertical if mode == "maly" else Qt.Orientation.Horizontal
        )
        self.page.panel_listy.setMaximumHeight(210 if mode == "maly" else 16777215)
        self.detale_przycisk.setChecked(mode == "pelny")
        self.page.podzial.setSizes(
            [210, 600]
            if mode == "maly"
            else [320 if mode == "pelny" else 250, max(450, width - 340)]
        )
        self.detale_podzial.setSizes([max(500, width - 760), 380 if mode == "pelny" else 320])

    def motyw(self) -> None:
        dark = self.page.palette().color(QPalette.ColorRole.Window).lightness() < 128
        if dark == self._ciemny:
            return
        self._ciemny = dark
        border = "#203B51" if dark else "#CDDBEE"
        panel = "#0D1D2B" if dark else "#FFFFFF"
        self.page.biblioteka.setStyleSheet(f"""
            QFrame#panelCennika, QWidget#panelCennika {{
                background:{panel};border:1px solid {border};border-radius:10px;}}
            QFrame#panelCennika QLabel, QWidget#panelCennika QLabel {{
                border:0;background:transparent;}}
            QLabel#tytulCennika {{font-size:14px;font-weight:600;}}
            QLabel#liczbaDashboardu {{font-size:22px;font-weight:600;}}
            QLabel#podpisDashboardu {{font-size:11px;}}
            QFrame#poleCennika {{border:0;border-top:1px solid {border};border-radius:0;}}
            QPushButton#chipCennika {{border-radius:14px;padding:4px 10px;}}
        """)
