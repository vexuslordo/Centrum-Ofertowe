"""Drobne komponenty paneli przygotowania, oparte na obecnych kolorach VexLab."""

from PySide6.QtCore import QSize, Qt
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.statusy_zamowien import kolory_odznaki

TONY = {
    "zielony": "NEW",
    "zloty": "SUSPENDED",
    "czerwony": "CANCELLED",
    "szary": "",
    "niebieski": "PROCESSING",
}


def separator(layout: QVBoxLayout) -> None:
    line = QFrame()
    line.setFrameShape(QFrame.Shape.HLine)
    line.setObjectName("separatorPaneluOfert")
    layout.addWidget(line)


def odznaka(label: QLabel, text: str, ton: str) -> None:
    dark = QApplication.palette().color(QApplication.palette().ColorRole.Window).lightness() < 128
    bg, fg, border = kolory_odznaki(TONY[ton], dark)
    label.setText(text)
    label.setStyleSheet(
        f"background:{bg};color:{fg};border:1px solid {border};"
        "border-radius:5px;padding:4px 8px;font-size:11px;"
    )


class WierszUstawienia(QFrame):
    def __init__(self, button: QPushButton, nazwa: str, symbol: str) -> None:
        super().__init__()
        self.setObjectName("wierszUstawieniaOfert")
        box = QHBoxLayout(self)
        box.setContentsMargins(3, 0, 5, 0)
        box.setSpacing(2)
        button.setText(nazwa)
        button.setIcon(ikona(symbol))
        button.setIconSize(QSize(14, 14))
        button.setObjectName("akcjaUstawieniaOfert")
        button.setMinimumWidth(0)
        button.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        button.setFixedHeight(28)
        box.addWidget(button, 1)
        self.opis = QLabel("—")
        self.opis.setObjectName("opisUstawieniaOfert")
        self.opis.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.opis.setMaximumWidth(85)
        box.addWidget(self.opis)

    def ustaw(self, text: str, poprawne: bool) -> None:
        self.opis.setText(text)
        self.opis.setToolTip(text)
        dark = (
            QApplication.palette().color(QApplication.palette().ColorRole.Window).lightness() < 128
        )
        _, fg, _ = kolory_odznaki("NEW" if poprawne else "", dark)
        self.opis.setStyleSheet(f"color:{fg};font-size:10px;background:transparent;border:0;")
