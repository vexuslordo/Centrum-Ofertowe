from dataclasses import replace

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget

from tests.integration.test_statusy_produktow_allegro import API, produkty, sesja
from vexlab.gui.katalog import ModelProduktow
from vexlab.gui.statusy_produktow_allegro import StatusyProduktowAllegro
from vexlab.przypadki_uzycia.allegro import KontoAllegro
from vexlab.przypadki_uzycia.statusy_produktow_allegro import OdczytajStatusyProduktow


def test_zmiana_konta_ignoruje_stare_odczyty_i_czyści_zielen(qtbot):
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs, aktualna = [], [sesja()]
    c = StatusyProduktowAllegro(
        OdczytajStatusyProduktow(API()), lambda *a: jobs.append(a), lambda: aktualna[0], parent
    )
    c.polaczenie()
    stary = jobs.pop()
    stary_wynik = stary[0]()
    aktualna[0] = replace(aktualna[0], konto=KontoAllegro("inne", "Inne"))
    c.polaczenie()
    nowy = jobs.pop()
    stary[1](stary_wynik)
    assert c.snapshot is None
    nowy[1](nowy[0]())
    assert c.oznacz(produkty())[0].allegro_aktywne
    aktualna[0] = None
    c.polaczenie()
    assert not c.oznacz(produkty())[0].allegro_aktywne


def test_odswiezenie_blad_i_anulowanie_usuwaja_zielen(qtbot):
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs, s = [], sesja()
    c = StatusyProduktowAllegro(
        OdczytajStatusyProduktow(API()), lambda *a: jobs.append(a), lambda: s, parent
    )
    c.polaczenie()
    fn, ok, error = jobs.pop()
    ok(fn())
    m = ModelProduktow()
    m.ustaw(list(c.oznacz(produkty())))
    assert m.index(0, 6).data(Qt.ItemDataRole.UserRole + 3) is True
    assert "ID 10" in m.index(0, 6).data(Qt.ItemDataRole.ToolTipRole)
    c.odswiez()
    assert not c.oznacz(produkty())[0].allegro_aktywne
    jobs.pop()[2]("SIEC", "Brak odpowiedzi")
    assert c.snapshot is None and "Brak odpowiedzi" in c.komunikat
    c.odswiez()
    fn, ok, error = jobs.pop()
    result = fn()
    c.anuluj()
    ok(result)
    assert c.snapshot is None and not c.trwa


def test_rzeczywisty_model_okna_przebudowa_strony_i_odlaczenie(qtbot, tmp_path):
    from types import SimpleNamespace

    from PySide6.QtCore import QSettings

    from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
    from vexlab.adaptery.czytnik_importu import CzytnikTabel
    from vexlab.adaptery.eksport_csv import EksportCSV
    from vexlab.adaptery.preferencje import PreferencjeQt
    from vexlab.gui.okno import OknoVexLab
    from vexlab.przypadki_uzycia.eksport import EksportujKatalog
    from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
    from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
    from vexlab.przypadki_uzycia.katalog_allegro import KatalogZAllegro
    from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
    from vexlab.przypadki_uzycia.producenci import RejestrProducentow

    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    katalog = KatalogProduktow(repo, repo)
    katalog.dodaj(DaneProduktu("Produkt testowy", "SKU-1"))
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "p.ini"), QSettings.Format.IniFormat)),
            "Test",
            "test",
        ),
        katalog,
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
        katalog_allegro=KatalogZAllegro(API(), repo, None),
    )
    qtbot.addWidget(w, before_close_func=lambda _: qtbot.waitUntil(lambda: not w._zadania))
    w.show()
    qtbot.waitUntil(lambda: not w._zadania and w._katalog_wczytany)
    assert not w.model.produkty[0].allegro_aktywne
    w.strona_allegro = SimpleNamespace(sesja=sesja())
    w.statusy_produktow.polaczenie()
    qtbot.waitUntil(lambda: not w._zadania and not w.statusy_produktow.trwa)
    assert w.model.produkty[0].allegro_aktywne
    w.odswiez()
    qtbot.waitUntil(lambda: not w._zadania)
    assert w.model.produkty[0].allegro_aktywne
    w.strona_allegro.sesja = None
    w.statusy_produktow.polaczenie()
    assert not w.model.produkty[0].allegro_aktywne
    assert not w.tabela_produktow.horizontalHeader().highlightSections()
    w.close()
