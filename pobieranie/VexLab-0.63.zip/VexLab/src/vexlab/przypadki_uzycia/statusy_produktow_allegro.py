"""Odczyt stanu ofert po dokładnym SKU, bez zmiany produktów i powiązań."""

from collections.abc import Callable
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from typing import Protocol

from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.katalog import ProduktDTO
from vexlab.przypadki_uzycia.katalog_allegro import OfertaKatalogu


@dataclass(frozen=True)
class StatusyOfertProduktow:
    konto: str
    srodowisko: str
    kiedy: str
    oferty: tuple[OfertaKatalogu, ...]


class APIStatusowProduktow(Protocol):
    def lista_statusow(
        self, s: SesjaAllegro, stop: Callable[[], bool], postep: Callable[[int, int], None]
    ) -> tuple[OfertaKatalogu, ...]: ...


class OdczytajStatusyProduktow:
    def __init__(self, api: APIStatusowProduktow) -> None:
        self.api = api

    def odczytaj(
        self, s: SesjaAllegro, stop: Callable[[], bool], postep: Callable[[int, int], None]
    ) -> StatusyOfertProduktow:
        rows = self.api.lista_statusow(s, stop, postep)
        if stop():
            raise BladAllegro("ANULOWANO", "Anulowano odczyt statusów produktów.")
        ids = [o.ident for o in rows]
        if len(set(ids)) != len(ids) or any(
            not o.ident.isascii() or not o.ident.isdigit() or not o.status for o in rows
        ):
            raise BladAllegro("STATUSY", "Niepełny lub niepoprawny odczyt statusów ofert.")
        return StatusyOfertProduktow(
            s.konto.id, s.srodowisko.value, datetime.now(UTC).isoformat(timespec="seconds"), rows
        )


def oznacz_statusy(
    produkty: tuple[ProduktDTO, ...],
    snapshot: StatusyOfertProduktow | None,
    s: SesjaAllegro | None,
    komunikat: str = "Połącz konto i sprawdź statusy Allegro.",
) -> tuple[ProduktDTO, ...]:
    if (
        snapshot is None
        or s is None
        or (snapshot.konto, snapshot.srodowisko) != (s.konto.id, s.srodowisko.value)
    ):
        return tuple(
            replace(p, allegro="", allegro_opis=komunikat, allegro_aktywne=False) for p in produkty
        )
    po_sku: dict[str, list[OfertaKatalogu]] = {}
    for o in snapshot.oferty:
        if o.sku.strip():
            po_sku.setdefault(o.sku.strip().casefold(), []).append(o)
    wynik = []
    for p in produkty:
        rows = po_sku.get(p.sku.strip().casefold(), [])
        aktywne = sum(o.status == "ACTIVE" for o in rows)
        opis = (
            f"Konto: {s.konto.login} • {s.srodowisko.value} • odczyt: {snapshot.kiedy}\n"
            + (
                "\n".join(f"ID {o.ident} • {o.status}" for o in rows[:20])
                if rows
                else "Nie znaleziono oferty z tym SKU na połączonym koncie."
            )
            + "\nDopasowanie po pełnym SKU. Dostępność lokalna jest osobnym polem."
        )
        wynik.append(
            replace(
                p,
                allegro=f"Aktywne: {aktywne}" if aktywne else "",
                allegro_opis=opis,
                allegro_aktywne=bool(aktywne),
            )
        )
    return tuple(wynik)
