"""Jawna nowa próba po odczycie konta; poprzedni dziennik jest archiwizowany."""

from dataclasses import dataclass
from uuid import uuid4

from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.duplikaty_allegro import SprawdzDuplikatyAllegro, opis_duplikatow
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    NoweSzkiceAllegro,
    PlanNowegoSzkicu,
    ProbaTworzenia,
    skrot,
)


@dataclass(frozen=True)
class KontrolaPonowienia:
    konto: str
    srodowisko: str
    sku: str
    zrodlo: str
    poprzednia: ProbaTworzenia
    czas: float


class PrzygotujNowaProbe:
    def __init__(self, serwis: NoweSzkiceAllegro) -> None:
        self.serwis = serwis

    def _brak_oferty(self, s: SesjaAllegro, p: PlanNowegoSzkicu, proba: ProbaTworzenia) -> None:
        api = self.serwis.api
        if proba.ident and api.czy_istnieje_oferta(s, proba.ident):
            raise BladAllegro(
                "ISTNIEJE",
                f"Oferta ID {proba.ident} istnieje na tym koncie. "
                "Otwórz ją w zakładce Allegro zamiast tworzyć drugą.",
            )
        if proba.operacja and api.operacja_w_toku(s, proba.ident, proba.operacja):
            raise BladAllegro(
                "PRZETWARZANIE",
                "Allegro nadal przetwarza poprzednią próbę. Nie odblokowano tworzenia.",
            )
        duplikaty = SprawdzDuplikatyAllegro(api).sprawdz(s, (p.oferta,))[0]
        techniczna = api.znajdz_szkic(s, "vexlab-" + self.serwis.klucz(s, p.oferta.sku))
        if duplikaty or techniczna is not None:
            raise BladAllegro(
                "ISTNIEJE",
                "Znaleziono możliwą wcześniejszą ofertę: "
                + opis_duplikatow(duplikaty)
                + (f" ID {techniczna.get('id')}" if techniczna else ""),
            )

    def sprawdz(self, s: SesjaAllegro, p: PlanNowegoSzkicu) -> KontrolaPonowienia:
        self.serwis._sesja(s)
        if (p.konto, p.srodowisko) != (s.konto.id, s.srodowisko.value):
            raise BladAllegro("KONTO", "Plan dotyczy innego konta lub środowiska.")
        proba = self.serwis.rejestr.odczytaj(self.serwis.klucz(s, p.oferta.sku))
        if proba is None:
            raise BladAllegro(
                "BRAK", "Brak zapisanej blokady dla tego SKU. Sprawdź paczkę ponownie."
            )
        self._brak_oferty(s, p, proba)
        return KontrolaPonowienia(
            s.konto.id,
            s.srodowisko.value,
            p.oferta.sku,
            self.serwis._zrodlo(p),
            proba,
            self.serwis.czas.teraz(),
        )

    def potwierdz(
        self,
        s: SesjaAllegro,
        p: PlanNowegoSzkicu,
        kontrola: KontrolaPonowienia,
        zaakceptowano_ryzyko: bool = False,
    ) -> None:
        self.serwis._sesja(s)
        if (p.konto, p.srodowisko) != (s.konto.id, s.srodowisko.value):
            raise BladAllegro("KONTO", "Plan dotyczy innego konta lub środowiska.")
        if (
            not zaakceptowano_ryzyko
            or (kontrola.konto, kontrola.srodowisko, kontrola.sku, kontrola.zrodlo)
            != (s.konto.id, s.srodowisko.value, p.oferta.sku, self.serwis._zrodlo(p))
            or not 0 <= self.serwis.czas.teraz() - kontrola.czas <= 120
        ):
            raise BladAllegro(
                "POTWIERDZENIE",
                "Ponów kontrolę i jawnie potwierdź nową próbę dla tego konta i SKU.",
            )
        key = self.serwis.klucz(s, p.oferta.sku)
        if self.serwis.rejestr.odczytaj(key) != kontrola.poprzednia:
            raise BladAllegro("KONFLIKT", "Poprzednia próba zmieniła się. Niczego nie odblokowano.")
        self._brak_oferty(s, p, kontrola.poprzednia)
        archiwum = skrot(["NOWA-PROBA-ARCHIWUM-V1", key, str(uuid4())])
        self.serwis.rejestr.rozpocznij(archiwum, kontrola.poprzednia)
        if self.serwis.rejestr.odczytaj(key) != kontrola.poprzednia:
            raise BladAllegro("KONFLIKT", "Próba zmieniła się podczas kontroli. Zachowano blokadę.")
        self.serwis.rejestr.usun(key)
