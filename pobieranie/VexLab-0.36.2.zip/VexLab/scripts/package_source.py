"""Przenośny ZIP źródeł bez środowiska, cache, sekretów i baz użytkownika."""

import argparse
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
ELEMENTY = (
    "README.md",
    "AGENTS.md",
    "ARCHITECTURE_CONSTITUTION.md",
    "DOMAIN_MODEL.md",
    "ADR_INDEX.md",
    "UI_UX_DESIGN_SYSTEM.md",
    "ROADMAP.md",
    "JAK_URUCHOMIC.txt",
    "Uruchom VexLab.cmd",
    "pyproject.toml",
    "uv.lock",
    ".python-version",
    ".gitignore",
    ".importlinter",
    "src",
    "tests",
    "scripts",
    "docs",
    "assets",
    ".github",
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Spakuj źródła VexLab do pobrania")
    parser.add_argument("--output", type=Path, required=True)
    argumenty = parser.parse_args()
    with ZipFile(argumenty.output, "w", ZIP_DEFLATED) as archive:
        for nazwa in ELEMENTY:
            element = ROOT / nazwa
            if not element.exists():
                raise FileNotFoundError(element)
            pliki = sorted(element.rglob("*")) if element.is_dir() else [element]
            for plik in pliki:
                if not plik.is_file() or "__pycache__" in plik.parts:
                    continue
                if plik.name.startswith(".env") or plik.suffix in {".pyc", ".pyo"}:
                    continue
                if any(
                    token in plik.name for token in (".sqlite", ".db", ".pem", ".key", ".dpapi")
                ):
                    continue
                archive.write(plik, Path("VexLab") / plik.relative_to(ROOT))
    with ZipFile(argumenty.output) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Niepoprawna suma pliku w ZIP")
        for wymagany in (
            "docs/PRZYROST_0_36.md",
            "docs/adr/ADR-058-odczyt-ofert-allegro.md",
            "tests/application/test_oferty_allegro.py",
            "docs/PRZYROST_0_35.md",
            "src/vexlab/gui/dashboard.py",
            "src/vexlab/przypadki_uzycia/dashboard.py",
            "tests/gui/test_dashboard.py",
            "tests/integration/test_dashboard.py",
            "docs/PRZYROST_0_34.md",
            "assets/VEX_LOGO.md",
            "src/vexlab/gui/zasoby/vex-logo.png",
            "tests/gui/test_logo.py",
            "docs/POPRAWKA_0_33_1.md",
            "docs/PRZYROST_0_33.md",
            "docs/adr/ADR-056-przestrzen-allegro.md",
            "src/vexlab/gui/obszar_allegro.py",
            "docs/PRZYROST_0_32.md",
            "src/vexlab/gui/integracje_dashboard.py",
            "src/vexlab/gui/zasoby/allegro-wordmark.svg",
            "tests/gui/test_integracje_dashboard.py",
            "docs/POPRAWKA_0_31_2.md",
            "docs/POPRAWKA_0_31_1.md",
            "docs/PRZYROST_0_31.md",
            "docs/adr/ADR-055-podglad-szkicu-allegro.md",
            "src/vexlab/kanaly/szkic_allegro.py",
            "src/vexlab/gui/szkic_allegro.py",
            "docs/POPRAWKA_0_30_10.md",
            "docs/POPRAWKA_0_30_9.md",
            "docs/POPRAWKA_0_30_8.md",
            "docs/POPRAWKA_0_30_7.md",
            "docs/POPRAWKA_0_30_6.md",
            "docs/POPRAWKA_0_30_5.md",
            "docs/POPRAWKA_0_30_4.md",
            "docs/POPRAWKA_0_30_3.md",
            "docs/POPRAWKA_0_30_2.md",
            "docs/POPRAWKA_0_30_1.md",
            "docs/PRZYROST_0_30.md",
            "src/vexlab/gui/filtry_katalogu.py",
            "src/vexlab/gui/widoki_katalogu.py",
            "tests/gui/test_filtry_katalogu.py",
            "docs/PRZYROST_0_29.md",
            "src/vexlab/gui/kafelek_kpi.py",
            "tests/gui/test_kafelek_kpi.py",
            "src/vexlab/gui/zasoby/kpi/produkty.svg",
            "src/vexlab/gui/zasoby/kpi/aktywne.svg",
            "src/vexlab/gui/zasoby/kpi/szkice.svg",
            "src/vexlab/gui/zasoby/kpi/bledy.svg",
            "assets/KPI_ICONS_ATTRIBUTION.md",
            "assets/FONT_AWESOME_FREE_LICENSE.txt",
            "docs/PRZYROST_0_28.md",
            "src/vexlab/gui/ustawienia.py",
            "tests/gui/test_ustawienia.py",
            "docs/PRZYROST_0_27.md",
            "src/vexlab/gui/przyciski.py",
            "tests/gui/test_przyciski.py",
            "docs/POPRAWKA_0_26_1.md",
            "docs/PRZYROST_0_26.md",
            "docs/adr/ADR-054-pamiec-polaczenia-allegro.md",
            "src/vexlab/adaptery/sekrety_allegro.py",
            "tests/integration/test_sekrety_allegro.py",
            "tests/application/test_pamiec_allegro.py",
            "docs/PRZYROST_0_25.md",
            "docs/adr/ADR-053-sesja-allegro.md",
            "src/vexlab/przypadki_uzycia/allegro.py",
            "src/vexlab/kanaly/allegro.py",
            "src/vexlab/adaptery/allegro_http.py",
            "src/vexlab/gui/allegro.py",
            "tests/gui/test_allegro.py",
            "tests/integration/test_allegro_api.py",
            "tests/integration/test_allegro_http.py",
            "tests/application/test_allegro.py",
            "docs/PRZYROST_0_24.md",
            "docs/adr/ADR-052-przygotowanie-odczytu-gt.md",
            "src/vexlab/przypadki_uzycia/srodowisko_gt.py",
            "src/vexlab/adaptery/srodowisko_gt.py",
            "src/vexlab/gui/srodowisko_gt.py",
            "tests/gui/test_srodowisko_gt.py",
            "tests/integration/test_srodowisko_gt.py",
            "tests/application/test_odczyt_katalogu.py",
            "tests/application/test_srodowisko_gt.py",
            "docs/PRZYROST_0_23.md",
            "docs/adr/ADR-051-strony-cennika.md",
            "src/vexlab/przypadki_uzycia/strony_cennika.py",
            "src/vexlab/adaptery/cenniki_odczyt_sqlite.py",
            "src/vexlab/adaptery/format_cennika.py",
            "src/vexlab/gui/strony_cennika.py",
            "src/vexlab/gui/wybor_tabeli.py",
            "tests/gui/test_strony_cennika.py",
            "tests/integration/test_strony_cennika.py",
            "docs/PRZYROST_0_22.md",
            "docs/adr/ADR-050-strony-katalogu.md",
            "src/vexlab/gui/strony_katalogu.py",
            "src/vexlab/adaptery/strony_katalogu_sqlite.py",
            "tests/gui/test_strony_katalogu.py",
            "tests/integration/test_strony_katalogu.py",
            "docs/PRZYROST_0_21.md",
            "docs/adr/ADR-049-miniatury-na-zadanie.md",
            "src/vexlab/gui/miniatury_katalogu.py",
            "tests/gui/test_miniatury_katalogu.py",
            "tests/integration/test_miniatury_katalogu.py",
            "docs/POPRAWKA_0_20_4.md",
            "src/vexlab/adaptery/pasek_tytulu.py",
            "tests/gui/test_pasek_tytulu.py",
            "docs/POPRAWKA_0_20_3.md",
            "docs/POPRAWKA_0_20_2.md",
            "src/vexlab/gui/sekcja_menu.py",
            "src/vexlab/gui/tekst_podgladu.py",
            "docs/POPRAWKA_0_20_1.md",
            "tests/conftest.py",
            "tests/fixtures/schemat_10.sql",
            "tests/integration/test_migracja_11.py",
            "docs/PRZYROST_0_20.md",
            "docs/adr/ADR-048-szkice-bez-zakladania-produktow.md",
            "src/vexlab/przypadki_uzycia/profile_cennikow.py",
            "src/vexlab/adaptery/profile_cennikow_json.py",
            "src/vexlab/gui/profile_cennikow.py",
            "docs/PRZYROST_0_19.md",
            "Uruchom VexLab.cmd",
            "src/vexlab/gui/producenci.py",
            "src/vexlab/gui/importowanie.py",
            "src/vexlab/gui/cenniki.py",
            "src/vexlab/gui/podglad_oferty.py",
            "src/vexlab/adaptery/cenniki_sqlite.py",
            "src/vexlab/adaptery/podglad_zdjec.py",
            "tests/fixtures/schemat_7.sql",
            "tests/fixtures/schemat_8.sql",
            "tests/fixtures/schemat_9.sql",
            "src/vexlab/adaptery/czytnik_importu.py",
            "src/vexlab/adaptery/import_sqlite.py",
            "tests/fixtures/schemat_2.sql",
            "tests/fixtures/schemat_3.sql",
            "tests/fixtures/schemat_4.sql",
            "tests/fixtures/schemat_5.sql",
            "src/vexlab/gui/dopasowania.py",
            "src/vexlab/gui/masowa.py",
            "src/vexlab/gui/paczki_ofert.py",
            "src/vexlab/gui/zasoby/vexlabs.png",
            "src/vexlab/gui/zasoby/chevron-down-dark.svg",
            "src/vexlab/gui/zasoby/check.svg",
            "src/vexlab/gui/zasoby/allegro.svg",
            "src/vexlab/gui/zasoby/prestashop.svg",
            "assets/SIMPLE_ICONS_LICENSE.txt",
            "src/vexlab/gui/zasoby/SIMPLE_ICONS_LICENSE.txt",
            "src/vexlab/gui/zasoby/IKONY_MAREK.md",
            "src/vexlab/adaptery/zdjecia_shopify.py",
            "tests/fixtures/schemat_1.sql",
            "src/vexlab/gui/szkice.py",
            "src/vexlab/gui/edytor_opisu.py",
            "src/vexlab/adaptery/szkice_sqlite.py",
            "src/vexlab/domena/oferta.py",
            "tests/fixtures/schemat_6.sql",
            "uv.lock",
        ):
            if f"VexLab/{wymagany}" not in archive.namelist():
                raise RuntimeError(f"Niekompletny ZIP: {wymagany}")
        print(f"{argumenty.output}: {len(archive.namelist())} plików")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
