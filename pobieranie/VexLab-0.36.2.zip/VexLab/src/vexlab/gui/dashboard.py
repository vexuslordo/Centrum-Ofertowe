"""Główny obszar Dashboardu. Dane nieznane pozostają jawnie nieznane."""

from collections.abc import Callable
from datetime import datetime
from functools import partial
from typing import cast

from PySide6.QtCharts import QChart, QChartView, QLineSeries, QValueAxis
from PySide6.QtCore import QDateTime, QMargins, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPaintEvent, QPen, QResizeEvent
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QButtonGroup,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QTableWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.kafelek_kpi import KafelekKPI
from vexlab.przypadki_uzycia.allegro import LicznikiAllegro
from vexlab.przypadki_uzycia.dashboard import StanDashboardu
from vexlab.przypadki_uzycia.powloka import PreferencjePowloki

NAZWY = {
    "kpi": "Wskaźniki KPI",
    "sprzedaz": "Sprzedaż i przychód",
    "integracje": "Status integracji",
    "alerty": "Alerty systemowe",
    "top": "Top produkty",
    "zamowienia": "Ostatnie zamówienia",
    "system": "Kolejka i status systemu",
    "magazyn": "Stany magazynowe",
    "aktywnosc": "Aktywność systemu",
    "ai": "AI Center",
    "akcje": "Szybkie akcje",
}


def tekst(wartosc: str, rola: str = "") -> QLabel:
    label = QLabel(wartosc)
    if rola:
        label.setObjectName(rola)
    label.setWordWrap(True)
    return label


def przycisk(nazwa: str, akcja: Callable[[], None] | None = None) -> QPushButton:
    b = QPushButton(nazwa)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    if akcja is not None:
        b.clicked.connect(akcja)
    return b


class UdzialKanalow(QWidget):
    """Neutralny stan pustki, nie procenty z przykładowych danych."""

    def __init__(self) -> None:
        super().__init__()
        self.setFixedSize(108, 108)
        self.setAccessibleName("Udział kanałów: brak danych sprzedaży")

    def paintEvent(self, event: QPaintEvent) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QPen(QColor("#284153"), 14))
        painter.drawEllipse(15, 10, 80, 80)
        painter.setPen(QColor("#93ABC2"))
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "—\nBrak odczytu")


class EdytorDashboardu(QDialog):
    zmiana = Signal(object, object)

    def __init__(self, preferencje: PreferencjePowloki, parent: QWidget) -> None:
        super().__init__(parent)
        self.setWindowTitle("Dostosuj Dashboard")
        self.resize(390, 500)
        layout = QVBoxLayout(self)
        layout.addWidget(
            tekst(
                "Zaznacz sekcje i przeciągnij je, aby zmienić kolejność. "
                "Zmiany zapisują się automatycznie."
            )
        )
        self.lista = QListWidget()
        self.lista.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.lista.setAccessibleName("Widoczność i kolejność sekcji Dashboardu")
        for id in preferencje.dashboard_kolejnosc:
            item = QListWidgetItem(NAZWY[id])
            item.setData(Qt.ItemDataRole.UserRole, id)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(
                Qt.CheckState.Unchecked
                if id in preferencje.dashboard_ukryte
                else Qt.CheckState.Checked
            )
            self.lista.addItem(item)
        layout.addWidget(self.lista)
        self.blad = tekst("", "blad")
        layout.addWidget(self.blad)
        zamknij = przycisk("Zamknij", self.accept)
        layout.addWidget(zamknij)
        self.lista.itemChanged.connect(self._zmiana)
        self.lista.model().rowsMoved.connect(self._zmiana)

    def _zmiana(self) -> None:
        items = [self.lista.item(i) for i in range(self.lista.count())]
        self.zmiana.emit(
            tuple(i.data(Qt.ItemDataRole.UserRole) for i in items),
            tuple(
                i.data(Qt.ItemDataRole.UserRole)
                for i in items
                if i.checkState() == Qt.CheckState.Unchecked
            ),
        )


class DashboardView(QScrollArea):
    cel = Signal(str)
    alert = Signal(str)
    dostosuj = Signal()

    def __init__(self, preferencje: PreferencjePowloki) -> None:
        super().__init__()
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.kolejnosc = preferencje.dashboard_kolejnosc
        self.ukryte = preferencje.dashboard_ukryte
        self._szeroki: bool | None = None
        self._ciemny: bool | None = None
        self.sekcje: dict[str, QWidget] = {}
        self.karty: dict[str, KafelekKPI] = {}
        self.alerty: dict[str, QPushButton] = {}
        self.zawartosc = QWidget()
        self.zawartosc.setObjectName("dashboardNowy")
        self.layout_glowny = QVBoxLayout(self.zawartosc)
        self.layout_glowny.setContentsMargins(14, 12, 14, 12)
        self.layout_glowny.setSpacing(10)
        self._naglowek()
        self.siatka = QGridLayout()
        self.siatka.setSpacing(10)
        self.layout_glowny.addLayout(self.siatka)
        self.layout_glowny.addStretch()
        self._kpi()
        self._sprzedaz()
        self._integracje()
        self._alerty()
        self._tabela(
            "top",
            "Top produkty (30 dni)",
            ["#", "Produkt", "Sprzedano", "Przychód"],
            "Brak odczytu sprzedaży. Ranking pojawi się po udostępnieniu danych kanałów.",
            ("Sprzedaż", "Przychód", "Marża"),
        )
        self._tabela(
            "zamowienia",
            "Ostatnie zamówienia",
            ["Numer", "Źródło", "Klient", "Kwota", "Status"],
            "Obsługa zamówień jest w przygotowaniu.",
        )
        frame, layout = self._panel("system", "Kolejka zadań")
        layout.addWidget(tekst("—", "liczbaDashboardu"))
        layout.addWidget(tekst("Oczekujących zadań", "podpisDashboardu"))
        layout.addWidget(tekst("Kolejka synchronizacji w przygotowaniu.", "podpisDashboardu"))
        layout.addWidget(tekst("Status systemu", "tytulDashboardu"))
        self.stan_systemu = tekst("Odczytywanie katalogu…", "podpisDashboardu")
        layout.addWidget(self.stan_systemu)
        layout.addStretch()
        self._tabela(
            "magazyn",
            "Stany magazynowe — produkty do uzupełnienia",
            ["Produkt", "SKU", "Stan"],
            "Brak wspólnego odczytu magazynu. Stany ofert Allegro nie są stanem całego katalogu.",
            ("≤ 3", "4–10", "> 10"),
        )
        self._tabela(
            "aktywnosc",
            "Aktywność systemu",
            ["Czas", "Operacja", "Szczegóły"],
            "Brak wspólnego rejestru operacji. Historia importów pozostaje w Cennikach.",
        )
        self._ai()
        self.akcje, self.akcje_layout = self._panel("akcje", "Szybkie akcje")
        self.przyciski_akcji: list[QPushButton] = []
        akcje = (
            ("＋ Dodaj produkt", "dodaj", "#076BD0", True),
            ("Nowa oferta Allegro", "Nowe oferty", "#94430D", True),
            ("Produkt PrestaShop", "PrestaShop", "#8C1850", False),
            ("Import CSV / XLSX", "Cenniki", "#39326F", True),
            ("Synchronizuj wszystko", "Synchronizacja", "#15497F", False),
            ("Generuj opisy AI", "Kreator opisów (AI)", "#483574", False),
            ("Dodaj zdjęcia", "Zdjęcia i media", "#176457", True),
            ("Raport sprzedaży", "Raporty", "#166148", False),
            ("Aktualizuj ceny", "Zmiana cen", "#776020", False),
            ("Zarządzaj błędami", "korekty", "#7F2635", True),
        )
        self.grid_akcji = QGridLayout()
        self.akcje_layout.addLayout(self.grid_akcji)
        for nazwa, cel, kolor, dostepna in akcje:
            b = przycisk(nazwa, partial(self.cel.emit, cel))
            b.setEnabled(dostepna)
            b.setMinimumHeight(33)
            b.setStyleSheet(
                f"QPushButton {{background:{kolor};color:white;border:1px solid {kolor};"
                "border-radius:6px;padding:6px;} QPushButton:disabled {color:#A5B1C2;}"
            )
            if not dostepna:
                b.setToolTip("Funkcja w przygotowaniu; nie wykonuje operacji.")
            self.przyciski_akcji.append(b)
        self.info = tekst("Odczytywanie katalogu…", "podpisDashboardu")
        self.layout_glowny.addWidget(self.info)
        self.setWidget(self.zawartosc)
        self.rozmiesc(True)
        self.odswiez_motyw()

    def _naglowek(self) -> None:
        self.naglowek_layout = QGridLayout()
        self._header_widgets: list[QWidget] = [tekst("▣  Dashboard", "naglowekDashboardu")]
        self.opis_naglowka = tekst(
            "Wszystkie kluczowe informacje o Twojej sprzedaży w jednym miejscu.",
            "podpisDashboardu",
        )
        self.opis_naglowka.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self._header_widgets.append(self.opis_naglowka)
        self.zegar = tekst("", "zegarDashboardu")
        self._header_widgets.append(self.zegar)
        self._czas()
        timer = QTimer(self)
        timer.timeout.connect(self._czas)
        timer.start(1000)
        self.zakres = "30 dni"
        self.okres = QButtonGroup(self)
        for i, nazwa in enumerate(("Dzisiaj", "7 dni", "30 dni", "90 dni", "Rok")):
            b = przycisk(nazwa)
            b.setCheckable(True)
            b.setChecked(i == 2)
            self.okres.addButton(b)
            self._header_widgets.append(b)
        self.okres.buttonClicked.connect(self._zmien_okres)
        dostosuj = przycisk("⚙", self.dostosuj.emit)
        dostosuj.setAccessibleName("Dostosuj Dashboard")
        self._header_widgets.append(dostosuj)
        self.layout_glowny.addLayout(self.naglowek_layout)

    def _zmien_okres(self, button: QPushButton) -> None:
        self.zakres = button.text()
        self.karty["obrot"].tytul.setText(f"Obrót ({self.zakres})")
        self.karty["marza"].tytul.setText(f"Marża ({self.zakres})")

    def _czas(self) -> None:
        self.zegar.setText(QDateTime.currentDateTime().toString("dd.MM.yyyy  HH:mm"))

    def _panel(self, id: str, nazwa: str) -> tuple[QFrame, QVBoxLayout]:
        frame = QFrame()
        frame.setObjectName("panelDashboardu")
        frame.setMinimumWidth(0)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(11, 10, 11, 10)
        layout.setSpacing(4)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.addWidget(tekst(nazwa, "tytulDashboardu"))
        self.sekcje[id] = frame
        return frame, layout

    def _kpi(self) -> None:
        frame = QWidget()
        self.grid_kpi = QGridLayout(frame)
        self.grid_kpi.setContentsMargins(0, 0, 0, 0)
        self.grid_kpi.setSpacing(10)
        self.sekcje["kpi"] = frame
        for id, nazwa, symbol, kolor in (
            ("produkty", "Produkty", "Produkty", "#008E78"),
            ("allegro", "Aktywne Allegro", "Allegro", "#DB5400"),
            ("presta", "Produkty PrestaShop", "PrestaShop", "#A51B61"),
            ("zamowienia", "Zamówienia", "Nowe oferty", "#0662BB"),
            ("obrot", "Obrót (30 dni)", "Cenniki", "#997017"),
            ("marza", "Marża (30 dni)", "Raporty", "#00824D"),
            ("bledy", "Błędy", "Historia operacji", "#AF2635"),
        ):
            self.karty[id] = KafelekKPI(
                nazwa, "produkty", "Brak historii", symbol=symbol, akcent=kolor
            )

    def _zakladki(self, layout: QVBoxLayout, nazwy: tuple[str, ...], *, obok: bool = False) -> None:
        pasek = QHBoxLayout()
        if obok:
            item = layout.takeAt(0)
            widget = item.widget() if item is not None else None
            if widget is not None:
                cast(QLabel, widget).setWordWrap(False)
                widget.setMinimumWidth(170)
                pasek.addWidget(widget)
        grupa = QButtonGroup(self)
        for i, nazwa in enumerate(nazwy):
            b = przycisk(nazwa)
            b.setCheckable(True)
            b.setChecked(i == 0)
            grupa.addButton(b)
            pasek.addWidget(b)
        pasek.addStretch()
        layout.addLayout(pasek)

    def _sprzedaz(self) -> None:
        _, layout = self._panel("sprzedaz", "Sprzedaż i przychód")
        self._zakladki(layout, ("Przychód", "Zamówienia", "Obrót", "Marża"), obok=True)
        layout.addWidget(tekst("● Allegro      ● PrestaShop", "podpisDashboardu"))
        wykres = QChart()
        wykres.legend().hide()
        wykres.setMargins(QMargins(0, 0, 0, 0))
        wykres.setBackgroundVisible(False)
        wykres.setPlotAreaBackgroundVisible(False)
        seria = QLineSeries()
        wykres.addSeries(seria)
        for orientacja in (Qt.AlignmentFlag.AlignBottom, Qt.AlignmentFlag.AlignLeft):
            os = QValueAxis()
            os.setRange(0, 1)
            os.setLabelsVisible(False)
            os.setGridLineColor(QColor("#193348"))
            wykres.addAxis(os, orientacja)
            seria.attachAxis(os)
        self.wykres = QChartView(wykres)
        self.wykres.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.wykres.setMinimumHeight(95)
        self.wykres.setMaximumHeight(108)
        obszar = QHBoxLayout()
        obszar.addWidget(self.wykres, 1)
        udzial = QWidget()
        kolumna = QVBoxLayout(udzial)
        kolumna.setContentsMargins(0, 0, 0, 0)
        kolumna.addWidget(tekst("Łączny przychód: —", "podpisDashboardu"))
        kolumna.addWidget(UdzialKanalow())
        obszar.addWidget(udzial)
        layout.addLayout(obszar, 1)
        layout.addWidget(
            tekst(
                "Brak danych sprzedaży w wybranym okresie — "
                "odczyt zamówień i finansów w przygotowaniu.",
                "podpisDashboardu",
            )
        )

    def _integracje(self) -> None:
        _, layout = self._panel("integracje", "Status integracji")
        self.statusy: dict[str, QLabel] = {}
        for nazwa in ("Allegro", "PrestaShop", "OpenAI", "SMTP (e-mail)", "API systemu"):
            row = QHBoxLayout()
            row.addWidget(tekst(nazwa), 1)
            status = tekst(
                "●  Niepołączono" if nazwa == "Allegro" else "●  W przygotowaniu",
                "podpisDashboardu",
            )
            self.statusy[nazwa] = status
            row.addWidget(status, 2)
            layout.addLayout(row)
        layout.addWidget(
            tekst("Synchronizacja: —    Błędy: —    Oczekujące: —", "podpisDashboardu")
        )
        self.zarzadzaj_przycisk = przycisk(
            "Zarządzaj integracjami", lambda: self.cel.emit("integracje")
        )
        layout.addWidget(self.zarzadzaj_przycisk)
        layout.addStretch()

    def _alerty(self) -> None:
        _, layout = self._panel("alerty", "Alerty systemowe")
        for id, nazwa in (
            ("zdjecia", "Produkty bez zdjęć"),
            ("ean", "Produkty bez EAN"),
            ("producent", "Produkty bez producenta"),
            ("opis", "Produkty bez opisu"),
            ("korekty", "Błędy importu"),
        ):
            b = przycisk(f"△  {nazwa}     —", partial(self.alert.emit, id))
            b.setFixedHeight(22)
            b.setProperty("nazwa_alertu", nazwa)
            self.alerty[id] = b
            layout.addWidget(b)
        layout.addWidget(
            tekst(
                "Kategorie, publikacja, synchronizacja i stany: brak odczytu.", "podpisDashboardu"
            )
        )

    def _tabela(
        self, id: str, nazwa: str, kolumny: list[str], pustka: str, zakladki: tuple[str, ...] = ()
    ) -> None:
        _, layout = self._panel(id, nazwa)
        if zakladki:
            self._zakladki(layout, zakladki)
        tabela = QTableWidget(0, len(kolumny))
        tabela.setAccessibleName(nazwa)
        tabela.setHorizontalHeaderLabels(kolumny)
        from PySide6.QtWidgets import QHeaderView

        tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        tabela.horizontalHeader().setMinimumSectionSize(26)
        tabela.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        tabela.setStyleSheet(
            "QHeaderView::section {font-size:10px;padding:4px;} QTableWidget {font-size:10px;}"
        )
        tabela.verticalHeader().hide()
        tabela.setMinimumWidth(0)
        tabela.setMinimumHeight(52)
        tabela.setMaximumHeight(84)
        tabela.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Expanding)
        layout.addWidget(tabela, 1)
        layout.addWidget(tekst(pustka, "podpisDashboardu"))

    def _ai(self) -> None:
        _, layout = self._panel("ai", "AI Center")
        item = layout.takeAt(0)
        tytul = item.widget() if item is not None else None
        naglowek = QHBoxLayout()
        if tytul is not None:
            naglowek.addWidget(tytul, 1)
        self.ai_otworz = przycisk("Otwórz kreatora", lambda: self.cel.emit("Kreator opisów (AI)"))
        self.ai_otworz.setToolTip("Otwórz moduł opisów AI; integracja jest w przygotowaniu.")
        naglowek.addWidget(self.ai_otworz)
        layout.addLayout(naglowek)
        self.ai_grid = QGridLayout()
        self.ai_grid.setSpacing(7)
        self.ai_wartosci: dict[str, QLabel] = {}
        self.ai_kafelki: list[tuple[QFrame, str, str, QLabel]] = []
        for i, (id, nazwa, symbol, kolor) in enumerate(
            (
                ("opisy", "Wygenerowane opisy", "ai_opisy", "#9255F0"),
                ("seo", "Sugestie SEO", "ai", "#8ABFEC"),
                ("bez_opisu", "Produkty bez opisu", "produkt", "#F0A515"),
                ("bez_zdjec", "Produkty bez zdjęć", "media", "#EC428B"),
                ("optymalizacja", "Optymalizacje tytułów", "globus", "#08CBA0"),
            )
        ):
            tile = QFrame()
            tile.setObjectName("kafelekAI")
            tile.setFixedHeight(49)
            box = QHBoxLayout(tile)
            box.setContentsMargins(7, 6, 7, 6)
            box.setSpacing(8)
            obraz = QLabel()
            obraz.setObjectName("ikonaAI")
            obraz.setFixedSize(28, 28)
            obraz.setAlignment(Qt.AlignmentFlag.AlignCenter)
            obraz.setPixmap(ikona(symbol, kolor).pixmap(QSize(20, 20)))
            obraz.setAccessibleName(f"Ikona: {nazwa}")
            box.addWidget(obraz)
            kolumna = QVBoxLayout()
            kolumna.setContentsMargins(0, 0, 0, 0)
            kolumna.setSpacing(1)
            podpis = tekst(nazwa, "podpisAI")
            kolumna.addWidget(podpis)
            dol = QHBoxLayout()
            value = tekst("—", "wartoscAI")
            dol.addWidget(value, 1)
            zmiana = tekst("—", "zmianaAI")
            zmiana.setToolTip("Brak porównywalnych danych historycznych.")
            dol.addWidget(zmiana)
            kolumna.addLayout(dol)
            box.addLayout(kolumna, 1)
            self.ai_wartosci[id] = value
            self.ai_kafelki.append((tile, kolor, id, obraz))
            self.ai_grid.addWidget(tile, i // 2, i % 2)
        layout.addLayout(self.ai_grid)
        layout.addStretch()

    def _motyw_ai(self, ciemny: bool) -> None:
        for tile, kolor, id, obraz in self.ai_kafelki:
            akcent = QColor(kolor)
            tlo = "#101E2D" if ciemny else "#F4F8FD"
            przyciemniony = akcent.darker(430 if ciemny else 110).name()
            koniec = przyciemniony if ciemny else akcent.lighter(185).name()
            ramka = kolor if id == "opisy" else ("#20394E" if ciemny else "#CDDBEE")
            tile.setStyleSheet(f"""
                QFrame#kafelekAI {{
                    background:qlineargradient(x1:0,y1:0,x2:1,y2:1,
                    stop:0 {tlo},stop:1 {koniec});
                    border:1px solid {ramka};border-radius:7px;
                }}
                QLabel {{background:transparent;border:0;}}
                QLabel#podpisAI {{color:{"#ADBFDC" if ciemny else "#415B79"};font-size:10px;}}
                QLabel#wartoscAI {{color:{"#F1F5FF" if ciemny else "#142C48"};
                    font-size:15px;font-weight:600;}}
                QLabel#zmianaAI {{color:{"#8396B2" if ciemny else "#627994"};font-size:10px;}}
            """)
            obraz.setStyleSheet(f"background:{przyciemniony};border-radius:7px;")

    def ustaw_stan(self, stan: StanDashboardu) -> None:
        self.karty["produkty"].liczba.setText(f"{stan.produkty:,}".replace(",", " "))
        for id, wartosc in (
            ("zdjecia", stan.bez_zdjec),
            ("ean", stan.bez_ean),
            ("producent", stan.bez_producenta),
            ("opis", stan.bez_opisu),
            ("korekty", stan.do_poprawy),
        ):
            b = self.alerty[id]
            b.setText(f"△  {b.property('nazwa_alertu')}     {wartosc}")
            b.setEnabled(wartosc > 0)
        self.ai_wartosci["bez_opisu"].setText(str(stan.bez_opisu))
        self.ai_wartosci["bez_zdjec"].setText(str(stan.bez_zdjec))
        self.stan_systemu.setText(
            "●  Katalog lokalny dostępny\nIntegracje i kolejka: zgodnie ze stanem obok."
        )
        self.info.setText(
            ("Katalog jest pusty • " if stan.produkty == 0 else "")
            + f"Katalog lokalny: {stan.produkty} produktów • "
            f"Odczyt {datetime.now().strftime('%H:%M:%S')} • Dane kanałów: brak odczytu"
        )

    def ustaw_liczniki_allegro(self, dane: LicznikiAllegro | None, komunikat: str = "") -> None:
        karta = self.karty["allegro"]
        karta.liczba.setText(str(dane.aktywne) if dane is not None else "—")
        karta.podpis.setText(
            "Odczyt " + datetime.now().strftime("%H:%M") if dane else "Brak odczytu"
        )
        karta.setToolTip(
            komunikat or "Liczba ofert ACTIVE całego konta z Allegro API; cache do 30 s."
        )

    def ustaw_allegro(self, login: str | None) -> None:
        label = self.statusy["Allegro"]
        label.setText(f"●  Połączono: {login}" if login else "●  Niepołączono")
        label.setStyleSheet("color:#16C777;" if login else "")

    def rozmiesc(self, szeroki: bool, *, wymus: bool = False) -> None:
        if self._szeroki == szeroki and not wymus:
            return
        self._szeroki = szeroki
        for i, widget in enumerate(self._header_widgets):
            self.naglowek_layout.removeWidget(widget)
            if szeroki:
                self.naglowek_layout.addWidget(widget, 0, i)
            elif i < 3:
                self.naglowek_layout.addWidget(widget, 0, i * 2, 1, 2)
            else:
                self.naglowek_layout.addWidget(widget, 1, i - 3)
        for i in range(9):
            self.naglowek_layout.setColumnStretch(i, int(szeroki and i == 1))
        self.opis_naglowka.setVisible(szeroki)
        for widget in self.sekcje.values():
            self.siatka.removeWidget(widget)
            widget.setVisible(False)
        for i in range(12):
            self.siatka.setColumnStretch(i, 1 if szeroki else int(i < 2))
        mapa = {
            "kpi": (0, 0, 12),
            "sprzedaz": (1, 0, 7),
            "integracje": (1, 7, 5),
            "alerty": (2, 0, 3),
            "top": (2, 3, 4),
            "zamowienia": (2, 7, 3),
            "system": (2, 10, 2),
            "magazyn": (3, 0, 4),
            "aktywnosc": (3, 4, 4),
            "ai": (3, 8, 4),
            "akcje": (4, 0, 12),
        }
        r, c = 0, 0
        for id in (x for x in self.kolejnosc if x not in self.ukryte):
            w = self.sekcje[id]
            span = mapa[id][2] if szeroki else 2
            limit = 12 if szeroki else 2
            if c + span > limit:
                r, c = r + 1, 0
            self.siatka.addWidget(w, r, c, 1, span)
            c += span
            w.setVisible(True)
        for i, card in enumerate(self.karty.values()):
            self.grid_kpi.removeWidget(card)
            n = 7 if szeroki else 3
            self.grid_kpi.addWidget(card, i // n, i % n)
        for i, b in enumerate(self.przyciski_akcji):
            self.grid_akcji.removeWidget(b)
            n = 10 if szeroki else 3
            self.grid_akcji.addWidget(b, i // n, i % n)

    def odswiez_motyw(self) -> None:
        ciemny = bool(cast(QApplication, QApplication.instance()).property("motyw_ciemny"))
        if self._ciemny == ciemny:
            return
        self._ciemny = ciemny
        tlo, panel, krawedz, kolor, opis = (
            ("#081522", "#101F2D", "#203B51", "#F0F5FF", "#9DB3CE")
            if ciemny
            else ("#EDF3FA", "#FFFFFF", "#CDDBEE", "#132B46", "#536B87")
        )
        self.zawartosc.setStyleSheet(f"""
            QWidget#dashboardNowy {{background:{tlo};}}
            QFrame#panelDashboardu, QFrame#metrykaDashboardu {{
                background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {panel},stop:1 {tlo});
                border:1px solid {krawedz};border-radius:9px;}}
            QLabel {{background:transparent;color:{kolor};border:0;}}
            QLabel#podpisDashboardu {{color:{opis};font-size:10px;}}
            QLabel#naglowekDashboardu {{font-size:24px;font-weight:600;}}
            QLabel#tytulDashboardu {{font-size:13px;font-weight:600;}}
            QLabel#liczbaDashboardu {{font-size:20px;font-weight:600;}}
            QPushButton {{font-size:10px;min-height:16px;padding:4px 7px;}}
            QLabel#zegarDashboardu {{color:{opis};font-size:14px;}}
        """)
        self.wykres.setBackgroundBrush(QColor(tlo))
        self._motyw_ai(ciemny)

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        if hasattr(self, "przyciski_akcji"):
            self.rozmiesc(self.viewport().width() >= 1150)
