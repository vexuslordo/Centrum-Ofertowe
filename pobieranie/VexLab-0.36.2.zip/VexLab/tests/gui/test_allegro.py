from PySide6.QtWidgets import QLineEdit

from vexlab.gui.allegro import StronaAllegro
from vexlab.przypadki_uzycia.allegro import (
    KodUrzadzenia,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StronaSzkicowAllegro,
    SzkicAllegro,
)


class Serwis:
    mozna_zapamietac = False
    czas = 100

    def teraz(self):
        return self.czas


def panel(qtbot):
    jobs = []
    w = StronaAllegro(Serwis(), lambda *a: jobs.append(a))
    qtbot.addWidget(w)
    w.klient.setText("test-client")
    w.sekret.setText("test-secret")
    return w, jobs


def kod():
    return KodUrzadzenia("test-device", "TEST-CODE", "https://allegro.pl/potwierdz", 600, 5)


def sesja():
    return SesjaAllegro(
        KontoAllegro("123", "testowy"), SrodowiskoAllegro.PRODUKCJA, "test-access", 3700
    )


def test_brak_sukcesu_przed_me_oraz_token_i_sekret_nie_sa_tekstami_gui(qtbot):
    w, jobs = panel(qtbot)
    stany = []
    w.stan.connect(stany.append)
    assert w.sekret.echoMode() == QLineEdit.EchoMode.Password
    w.rozpocznij()
    w.rozpocznij()
    assert len(jobs) == 1 and not w.sekret.text() and not w.odswiez.isEnabled()
    jobs[-1][1](kod())
    assert not stany and w.timer.isActive() and w.timer.interval() == 5000
    w.timer.stop()
    w._sprawdz()
    assert not stany
    jobs[-1][1](sesja())
    assert stany == ["Allegro: testowy"] and w.aplikacja is None and w.kod is None
    assert "test-secret" not in w.info.text() and "test-access" not in w.info.text()
    assert not w.otworz.isEnabled() and w.trwa
    jobs[-1][1](StronaSzkicowAllegro((SzkicAllegro("1", "Test"),), 51, 0, 50))
    assert w.tabela.rowCount() == 1 and w.nastepna.isEnabled() and "51" in w.zakres.text()
    w.anuluj()
    assert w.sesja is None and not w.wygasanie.isActive() and w.tabela.rowCount() == 0


def test_pending_slow_down_i_odmowa(qtbot):
    w, jobs = panel(qtbot)
    w.rozpocznij()
    jobs[-1][1](kod())
    w.timer.stop()
    w._sprawdz()
    jobs[-1][2]("OCZEKIWANIE", "Oczekiwanie")
    assert w.timer.interval() == 5000 and w.aplikacja is not None
    w.timer.stop()
    w._sprawdz()
    jobs[-1][2]("WOLNIEJ", "Wolniej")
    assert w.timer.interval() == 10000
    w.timer.stop()
    w._sprawdz()
    jobs[-1][2]("ODMOWA", "Odmówiono zgody")
    assert w.aplikacja is None and not w.timer.isActive() and w.polacz.isEnabled()
    assert w.info.text() == "Odmówiono zgody"


def test_anulowanie_ignoruje_spozniona_autoryzacje_i_nie_otwiera_przegladarki(qtbot, monkeypatch):
    from vexlab.gui import allegro as m

    monkeypatch.setattr(
        m.QDesktopServices, "openUrl", lambda *a: (_ for _ in ()).throw(AssertionError())
    )
    w, jobs = panel(qtbot)
    w.rozpocznij()
    jobs[-1][1](kod())
    w.timer.stop()
    w._sprawdz()
    w.anuluj()
    jobs[-1][1](sesja())
    assert w.sesja is None and w.polacz.isEnabled() and not w.odswiez.isEnabled()
    assert w.tabela.rowCount() == 0


def test_wygasniecie_kodu_lub_sesji_czysci_stan(qtbot):
    w, jobs = panel(qtbot)
    w.rozpocznij()
    jobs[-1][1](kod())
    w.serwis.czas = 701
    w.timer.stop()
    w._sprawdz()
    assert w.aplikacja is None and len(jobs) == 1 and "wygasł" in w.info.text()
    w.sesja = sesja()
    w.serwis.czas = 4000
    w._waznosc()
    assert w.sesja is None and "wygasła" in w.info.text()


def test_blad_odczytu_nie_pozostawia_starej_listy(qtbot):
    w, jobs = panel(qtbot)
    w.sesja = sesja()
    w._przyciski()
    w.pobierz()
    jobs[-1][1](StronaSzkicowAllegro((SzkicAllegro("1", "T"),), 1, 0, 50))
    assert w.tabela.rowCount() == 1
    w.pobierz()
    jobs[-1][2]("SIEC", "Brak odpowiedzi")
    assert w.tabela.rowCount() == 0 and "Nie pobrano" in w.zakres.text()
    assert w.odswiez.isEnabled() and w.sesja is not None
    w.anuluj()


def test_worker_zachowuje_rodzaj_pending_bez_sekretow(qtbot):
    from vexlab.gui.zadania import Zadanie
    from vexlab.przypadki_uzycia.allegro import BladAllegro

    def pending():
        raise BladAllegro("OCZEKIWANIE", "Oczekiwanie na zgodę")

    z = Zadanie(pending)
    wyniki = []
    z.sygnaly.blad.connect(lambda *a: wyniki.append(a))
    z.run()
    assert wyniki == [("OCZEKIWANIE", "Oczekiwanie na zgodę")]


def panel_z_pamiecia(qtbot):
    class Pamiec(Serwis):
        mozna_zapamietac = True

        def przywroc(self):
            return None

        def zapomnij(self):
            return None

    jobs = []
    w = StronaAllegro(Pamiec(), lambda *a: jobs.append(a))
    qtbot.addWidget(w)
    w.klient.setText("test-client")
    w.sekret.setText("test-secret")
    return w, jobs


def test_zapis_przed_sukcesem_pamieci_i_rozlaczenie_usuwa_zapis(qtbot):
    w, jobs = panel_z_pamiecia(qtbot)
    w.rozpocznij()
    jobs[-1][1](kod())
    w.timer.stop()
    w._sprawdz()
    jobs[-1][1](sesja())
    assert w.dysk_trwa and not w.rozlacz.isEnabled() and not w.zapamietane
    jobs[-1][1](None)
    assert w.zapamietane and "zapamiętane" in w.info.text()
    jobs[-1][1](StronaSzkicowAllegro((), 0, 0, 50))
    w.rozlacz_i_zapomnij()
    assert w.sesja is None and w.dysk_trwa
    jobs[-1][1](None)
    assert not w.zapamietane and w.polacz.isEnabled() and "usunięte" in w.info.text()


def test_awaria_zapisu_daje_sesje_bez_falszywej_pamieci(qtbot):
    w, jobs = panel_z_pamiecia(qtbot)
    w.rozpocznij()
    jobs[-1][1](kod())
    w.timer.stop()
    w._sprawdz()
    jobs[-1][1](sesja())
    jobs[-1][2]("MAGAZYN", "Odmowa Windows")
    assert w.sesja is not None and not w.zapamietane
    assert "tylko do zamknięcia" in w.info.text()
    w.anuluj()


def test_automatyczne_przywrocenie_i_wygasniecie_odnawiaja_sesje(qtbot):
    w, jobs = panel_z_pamiecia(qtbot)
    w.przywroc()
    assert w.dysk_trwa and w.sesja is None and "Wznawianie" in w.info.text()
    jobs[-1][1](sesja())
    assert w.zapamietane and w.sesja is not None
    jobs[-1][1](StronaSzkicowAllegro((), 0, 0, 50))
    w.serwis.czas = 4000
    w._waznosc()
    assert w.dysk_trwa and w.sesja is None
    jobs[-1][2]("WYGASLA", "Zgoda cofnięta")
    assert not w.polacz.isEnabled() and w.rozlacz.isEnabled() and w.ponow.isEnabled()
    assert "Nie udało się wznowić" in w.info.text()


def test_nieudane_zapomnienie_pozwala_ponowic_i_nie_obiecuje_usuniecia(qtbot):
    w, jobs = panel_z_pamiecia(qtbot)
    w.zapamietane = True
    w.rozlacz_i_zapomnij()
    jobs[-1][2]("MAGAZYN", "Nie można usunąć")
    assert w.zapamietane and w.rozlacz.isEnabled()
    assert w.info.text() == "Nie można usunąć"


def test_pusta_konfiguracja_odslania_dane_i_nie_wysyla_zadania(qtbot):
    w, jobs = panel(qtbot)
    w.klient.clear()
    w.sekret.clear()
    w.rozpocznij()
    assert not jobs and w.dane_aplikacji.przelacz.isChecked()
    assert "Uzupełnij dane" in w.info.text()


def test_polaczone_konto_chowa_dane_i_akcje_pierwszego_logowania(qtbot):
    w, jobs = panel_z_pamiecia(qtbot)
    w.dane_aplikacji.ustaw_otwarte(True)
    w._polaczono(sesja(), True)
    assert not w.dane_aplikacji.przelacz.isChecked()
    assert w.polacz.isHidden() and w.otworz.isHidden() and w.ponow.isHidden()
    assert not w.rozlacz.isHidden() and w.zapamietaj.isHidden()
    assert "testowy" in w.info.text() and "zapamiętane" in w.info.text()
    w.anuluj()


def test_podglad_wybranego_szkicu_i_zamkniecie_po_rozlaczeniu(qtbot):
    from vexlab.przypadki_uzycia.allegro import SzczegolySzkicuAllegro
    from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu

    w, jobs = panel(qtbot)
    w.sesja = sesja()
    w.pobierz()
    jobs[-1][1](StronaSzkicowAllegro((SzkicAllegro("123", "Test"),), 1, 0, 50))
    assert not w.podglad_przycisk.isEnabled()
    w.tabela.selectRow(0)
    assert w.podglad_przycisk.isEnabled()
    w.podglad_przycisk.click()
    assert w.trwa and not w.podglad_przycisk.isEnabled()
    wynik = SzczegolySzkicuAllegro(
        "123",
        "Tytuł z Allegro",
        "SKU",
        "10.00",
        "PLN",
        1,
        "456",
        (),
        ((ElementPodgladu("tekst", "<h1>Opis</h1><script>sekret</script>"),),),
    )
    jobs[-1][1](wynik)
    assert w.podglad is not None and w.podglad.szczegoly == wynik
    from vexlab.gui.tekst_podgladu import TekstPodgladu

    assert all("sekret" not in t.toPlainText() for t in w.podglad.findChildren(TekstPodgladu))
    w.anuluj()
    assert w.podglad is None


def test_spozniony_podglad_po_rozlaczeniu_jest_ignorowany(qtbot):
    w, jobs = panel(qtbot)
    w.sesja = sesja()
    w.pobierz()
    jobs[-1][1](StronaSzkicowAllegro((SzkicAllegro("123", "Test"),), 1, 0, 50))
    w.tabela.selectRow(0)
    w.pokaz_szkic()
    callback = jobs[-1][1]
    w.anuluj()
    callback(object())
    assert w.podglad is None and not w.trwa


def test_brak_dostepu_do_ofert_nie_rozlacza_potwierdzonego_konta(qtbot):
    w, jobs = panel(qtbot)
    stany = []
    w.stan.connect(stany.append)
    w._polaczono(sesja(), False)
    jobs[-1][2]("UPRAWNIENIA", "Brak uprawnień do odczytu ofert.")
    assert w.sesja is not None and w.sesja.konto.login == "testowy"
    assert stany == ["Allegro: testowy"]
    assert w.odswiez.isEnabled() and "Brak uprawnień" in w.info.text()


def test_panel_po_zmianie_wiersza_nie_pokazuje_ceny_poprzedniego_szkicu(qtbot):
    from vexlab.przypadki_uzycia.allegro import SzczegolySzkicuAllegro

    w, jobs = panel(qtbot)
    w.resize(1400, 850)
    w.show()
    w.sesja = sesja()
    w.pobierz()
    jobs[-1][1](
        StronaSzkicowAllegro((SzkicAllegro("1", "Pierwszy"), SzkicAllegro("2", "Drugi")), 2, 0, 50)
    )
    w.tabela.selectRow(0)
    qtbot.waitUntil(lambda: len(jobs) == 2)
    pierwszy = jobs[-1][1]
    w.tabela.selectRow(1)
    qtbot.waitUntil(lambda: w._panel_oczekuje)
    pierwszy(SzczegolySzkicuAllegro("1", "Pierwszy", "A", "10.00", "PLN", 1, "", (), ()))
    assert w.obszar.id.text() == "ID Allegro: 2"
    assert w.obszar.pola["Cena"].text() == "—"
    qtbot.waitUntil(lambda: len(jobs) == 3)
    jobs[-1][1](SzczegolySzkicuAllegro("2", "Drugi", "B", "20.00", "PLN", 2, "", (), ()))
    assert w.obszar.pola["Cena"].text() == "20,00 PLN"
    assert w.podglad is None
    w.anuluj()
    assert w.obszar.id.text() == "ID Allegro: —"
    assert w.obszar.liczniki["Szkice"].text() == "—"


def test_uklad_ma_prawdziwy_licznik_szkicow_i_jawne_niedostepne_operacje(qtbot):
    from PySide6.QtWidgets import QPushButton

    w, jobs = panel(qtbot)
    w.sesja = sesja()
    w.pobierz()
    jobs[-1][1](
        StronaSzkicowAllegro(
            (SzkicAllegro("1", "Pierwszy", "SKU-1", "12.50", "PLN", 4),), 83, 0, 50
        )
    )
    assert w.obszar.liczniki["Szkice"].text() == "83"
    assert w.obszar.liczniki["Aktywne oferty"].text() == "—"
    assert w.tabela.item(0, 3).text() == "SKU-1"
    assert w.tabela.item(0, 4).text() == "12,50 PLN"
    buttons = w.findChildren(QPushButton)
    assert all(
        not b.isEnabled()
        for b in buttons
        if b.text() in {"Publikuj", "Zakończ", "Usuń", "Edytuj ofertę"}
    )
    w.obszar._zaznacz(True)
    assert w.obszar.zaznaczenie.text() == "Zaznaczono: 1"
    w.obszar.szukaj.setText("brak")
    assert w.tabela.isRowHidden(0)
    with qtbot.waitSignal(w.nowa_oferta_zadana):
        next(b for b in buttons if b.text() == "Nowa oferta").click()


def test_aktywne_oferty_maja_wlasny_status_strony_i_reset_po_rozlaczeniu(qtbot):
    from vexlab.przypadki_uzycia.allegro import StatusOfertyAllegro as Status

    w, jobs = panel(qtbot)
    calls = []

    def oferty(s, status, offset):
        calls.append((status, offset))
        p = SzkicAllegro("123", "Oferta aktywna", status=Status.AKTYWNA)
        return StronaSzkicowAllegro((p,), 50001, offset, 50)

    w.serwis.oferty = oferty
    w.sesja = sesja()
    w._przyciski()
    w.obszar.taby[Status.AKTYWNA].click()
    assert w.trwa and w.status_listy == Status.AKTYWNA
    jobs[-1][1](jobs[-1][0]())
    assert calls == [(Status.AKTYWNA, 0)]
    assert "Limit przeglądania tej wersji: 10 000" in w.zakres.text()
    assert w.obszar.liczniki["Aktywne oferty"].text() == "50001"
    assert w.obszar.liczniki["Szkice"].text() == "—"
    assert w.tabela.item(0, 7).text() == "● Aktywna"
    w.nastepna.click()
    assert w.tabela.rowCount() == 0
    wynik = jobs[-1][0]()
    callback = jobs[-1][1]
    assert calls[-1] == (Status.AKTYWNA, 50)
    w.anuluj()
    callback(wynik)
    assert w.sesja is None and w.tabela.rowCount() == 0
    assert w.obszar.liczniki["Aktywne oferty"].text() == "—"


def test_mieszana_lista_i_szczegoly_pokazuja_faktyczny_stan(qtbot):
    from vexlab.przypadki_uzycia.allegro import StatusOfertyAllegro as Status
    from vexlab.przypadki_uzycia.allegro import SzczegolySzkicuAllegro

    w, jobs = panel(qtbot)
    w.sesja = sesja()
    w._przyciski()
    w.obszar.taby[None].click()
    jobs[-1][1](
        StronaSzkicowAllegro(
            (
                SzkicAllegro("123", "Aktywna", status=Status.AKTYWNA),
                SzkicAllegro("124", "Koniec", status=Status.ZAKONCZONA),
            ),
            2,
            0,
            50,
        )
    )
    assert w.tabela.item(1, 7).text() == "● Zakończona"
    w.tabela.selectRow(0)
    w.obszar.pokaz_szczegoly(
        SzczegolySzkicuAllegro("123", "Aktywna", "", "", "", 2, "", (), (), Status.ZAKONCZONA)
    )
    assert "Zakończona" in w.obszar.status_oferty.text()
    assert "zmienił" in w.obszar.uwaga.text()
    assert w.obszar.liczniki["Szkice"].text() == "—"
    w.anuluj()


def test_stara_odpowiedz_panelu_nie_konczy_nowego_odczytu_po_zmianie_zakladki(qtbot):
    from vexlab.przypadki_uzycia.allegro import StatusOfertyAllegro as Status
    from vexlab.przypadki_uzycia.allegro import SzczegolySzkicuAllegro

    w, jobs = panel(qtbot)
    w.show()
    w.sesja = sesja()
    w.pobierz()
    jobs[-1][1](StronaSzkicowAllegro((SzkicAllegro("123", "Szkic"),), 1, 0, 50))
    w.tabela.selectRow(0)
    qtbot.waitUntil(lambda: len(jobs) == 2)
    stary = jobs[-1][1]
    w.obszar.taby[Status.AKTYWNA].click()
    jobs[-1][1](
        StronaSzkicowAllegro((SzkicAllegro("123", "Aktywna", status=Status.AKTYWNA),), 1, 0, 50)
    )
    w.tabela.selectRow(0)
    qtbot.waitUntil(lambda: len(jobs) == 4)
    assert w._panel_trwa
    stary(SzczegolySzkicuAllegro("123", "Stara odpowiedź", "", "", "", None, "", (), ()))
    assert w._panel_trwa and w.obszar.tytul.text() != "Stara odpowiedź"
    jobs[-1][1](
        SzczegolySzkicuAllegro("123", "Aktualna", "", "", "", None, "", (), (), Status.AKTYWNA)
    )
    assert not w._panel_trwa and w.obszar.tytul.text() == "Aktualna"
    w.anuluj()


def test_wznawianie_czysci_dane_poprzedniej_sesji_przed_odpowiedzia(qtbot):
    w, jobs = panel(qtbot)

    class Pamiec(Serwis):
        mozna_zapamietac = True

        def przywroc(self):
            return None

    w.serwis = Pamiec()
    w.sesja = sesja()
    w.obszar.ustaw_konto("poprzednie_konto")
    w.obszar.tytul.setText("Poprzednia oferta")
    w.obszar.liczniki["Aktywne oferty"].setText("777")
    w.ostatnia_strona = StronaSzkicowAllegro((), 777, 0, 50)
    w.przywroc()
    assert w.sesja is None and w.ostatnia_strona is None
    assert w.obszar.konto.text() == "Konto: —"
    assert w.obszar.liczniki["Aktywne oferty"].text() == "—"
    assert w.obszar.tytul.text() != "Poprzednia oferta"
    jobs[-1][1](None)
    assert not w.trwa


def test_miniatury_i_braki_maja_jednakowe_kwadraty_bez_myslnika_obok(qtbot):
    from vexlab.gui.podglad_oferty import ObrazPodgladu

    w, jobs = panel(qtbot)
    w.resize(1200, 800)
    w.show()
    w.sesja = sesja()
    w.pobierz()
    jobs[-1][1](
        StronaSzkicowAllegro(
            (
                SzkicAllegro("123", "Ze zdjęciem", zdjecie="https://a.allegroimg.com/fixture.jpg"),
                SzkicAllegro("124", "Bez zdjęcia"),
            ),
            2,
            0,
            50,
        )
    )
    from PySide6.QtCore import QBuffer, QIODevice, Qt
    from PySide6.QtGui import QImage

    image = QImage(100, 50, QImage.Format.Format_RGB32)
    image.fill(Qt.GlobalColor.blue)
    out = QBuffer()
    out.open(QIODevice.OpenModeFlag.WriteOnly)
    image.save(out, "PNG")
    w.obszar.obrazy_tabeli.cache["https://a.allegroimg.com/fixture.jpg"] = bytes(out.data())
    w.obszar._miniatury_widoczne()
    for row in range(2):
        obraz = w.tabela.cellWidget(row, 2).findChild(ObrazPodgladu)
        assert obraz.width() == obraz.height() == 64
        assert w.tabela.rowHeight(row) == 76
        assert w.tabela.item(row, 2).text() == ""
    assert not w.tabela.cellWidget(0, 2).findChild(ObrazPodgladu).pixmap().isNull()
    w.anuluj()
