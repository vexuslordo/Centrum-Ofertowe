"""Centrum wiadomości: odczyt stron, bez lokalnej kopii i operacji zapisu."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.wiadomosci_allegro import (
    MAKS_OFFSET_WATKOW,
    MAKS_OFFSET_WIADOMOSCI,
    ROZMIAR_STRONY,
    OdczytajWiadomosciAllegro,
    StronaWatkow,
    StronaWiadomosci,
    WatekAllegro,
)


class PanelWiadomosci(QWidget):
    konto_zmienione = Signal()

    def __init__(
        self,
        uc: OdczytajWiadomosciAllegro,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
        login: str,
        parent: QWidget | None = None,
        *,
        pobierz_od_razu: bool = True,
    ) -> None:
        super().__init__(parent)
        self.uc, self.uruchom, self.sesja = uc, uruchom, sesja
        self._sesja = sesja()
        self._zamkniete = False
        self._nr = 0
        self._watek_nr = 0
        self._trwa = False
        self._watki: StronaWatkow | None = None
        self._wiadomosci: StronaWiadomosci | None = None
        self._wybrany = ""
        self._watki_offset = 0
        self._wiadomosci_offset = 0
        self.setWindowTitle("Wiadomości Allegro · odczyt")
        box = QVBoxLayout(self)
        box.setContentsMargins(20, 20, 20, 20)
        box.setSpacing(12)
        self.opis = QLabel(
            "Rozmowy konta Allegro. Filtr loginu dotyczy bieżącej strony; "
            "rozmowa może dotyczyć wielu zamówień."
        )
        self.opis.setWordWrap(True)
        box.addWidget(self.opis)
        toolbar = QHBoxLayout()
        self.filtr = QLineEdit(login)
        self.filtr.setPlaceholderText("Filtr loginu na bieżącej stronie")
        self.filtr.setAccessibleName("Filtr loginu rozmówcy na bieżącej stronie")
        toolbar.addWidget(self.filtr, 1)
        self.odswiez = QPushButton("Odśwież rozmowy")
        toolbar.addWidget(self.odswiez)
        box.addLayout(toolbar)
        split = QSplitter()
        left = QWidget()
        lb = QVBoxLayout(left)
        lb.setContentsMargins(0, 0, 0, 0)
        self.lista = QListWidget()
        self.lista.setAccessibleName("Rozmowy Allegro")
        lb.addWidget(self.lista, 1)
        nav = QHBoxLayout()
        self.poprzednie = QPushButton("← Rozmowy")
        self.nastepne = QPushButton("Rozmowy →")
        nav.addWidget(self.poprzednie)
        nav.addWidget(self.nastepne)
        lb.addLayout(nav)
        split.addWidget(left)
        right = QWidget()
        rb = QVBoxLayout(right)
        rb.setContentsMargins(0, 0, 0, 0)
        self.tytul = QLabel("Wybierz rozmowę")
        self.tytul.setTextFormat(Qt.TextFormat.PlainText)
        header = QHBoxLayout()
        header.addWidget(self.tytul, 1)
        self.odswiez_rozmowe = QPushButton("Odśwież rozmowę")
        header.addWidget(self.odswiez_rozmowe)
        rb.addLayout(header)
        self.tresc = QPlainTextEdit()
        self.tresc.setReadOnly(True)
        self.tresc.setUndoRedoEnabled(False)
        self.tresc.setAccessibleName("Treść rozmowy Allegro")
        rb.addWidget(self.tresc, 1)
        messages_nav = QHBoxLayout()
        self.nowsze = QPushButton("← Nowsze wiadomości")
        self.starsze = QPushButton("Starsze wiadomości →")
        messages_nav.addWidget(self.nowsze)
        messages_nav.addWidget(self.starsze)
        rb.addLayout(messages_nav)
        split.addWidget(right)
        split.setSizes([300, 660])
        box.addWidget(split, 1)
        self.stan = QLabel("Nie pobrano rozmów.")
        self.stan.setWordWrap(True)
        self.stan.setTextFormat(Qt.TextFormat.PlainText)
        box.addWidget(self.stan)
        bottom = QHBoxLayout()
        bottom.addWidget(QLabel("Odczyt nie oznacza wiadomości jako przeczytanych na Allegro."), 1)
        box.addLayout(bottom)
        self.filtr.textChanged.connect(self._pokaz_watki)
        self.lista.currentItemChanged.connect(self._wybierz)
        self.odswiez.clicked.connect(lambda: self.pobierz_watki(self._offset_watkow()))
        self.odswiez_rozmowe.clicked.connect(
            lambda: self.pobierz_wiadomosci(self._offset_wiadomosci())
        )
        self.poprzednie.clicked.connect(
            lambda: self.pobierz_watki(max(0, self._offset_watkow() - ROZMIAR_STRONY))
        )
        self.nastepne.clicked.connect(
            lambda: self.pobierz_watki(self._offset_watkow() + ROZMIAR_STRONY)
        )
        self.nowsze.clicked.connect(
            lambda: self.pobierz_wiadomosci(max(0, self._offset_wiadomosci() - ROZMIAR_STRONY))
        )
        self.starsze.clicked.connect(
            lambda: self.pobierz_wiadomosci(self._offset_wiadomosci() + ROZMIAR_STRONY)
        )
        self.timer = QTimer(self)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self._sprawdz_konto)
        self.timer.start()
        self._przyciski()
        if pobierz_od_razu:
            self.aktywuj()

    def _offset_watkow(self) -> int:
        return self._watki_offset

    def _offset_wiadomosci(self) -> int:
        return self._wiadomosci_offset

    def _aktualne(self) -> bool:
        return not self._zamkniete and self._sesja is not None and self.sesja() is self._sesja

    def _sprawdz_konto(self) -> None:
        if not self._zamkniete:
            self.polaczenie()

    def polaczenie(self) -> None:
        session = self.sesja()
        if session is self._sesja:
            return
        self._wyczysc()
        self._sesja = session
        self._zamkniete = False
        self._trwa = False
        self._watki_offset = self._wiadomosci_offset = 0
        self.timer.start()
        self._przyciski()
        self.stan.setText("Zmieniono połączenie. Odśwież rozmowy aktualnego konta.")
        self.konto_zmienione.emit()

    def aktywuj(self) -> None:
        self.polaczenie()
        session = self._sesja
        if session is None:
            self.stan.setText("Połącz konto w Integracje → Allegro, aby odczytać wiadomości.")
        elif session.aplikacja is None or not session.aplikacja.odczyt_wiadomosci:
            self.stan.setText(
                "W Integracje → Allegro włącz Odczyt wiadomości i zatwierdź uprawnienia."
            )
        elif self._watki is None and not self._trwa:
            self.pobierz_watki(0)

    def _wyczysc(self) -> None:
        self._zamkniete = True
        self.timer.stop()
        self._nr += 1
        self._watek_nr += 1
        self._watki = None
        self._wiadomosci = None
        self._sesja = None
        self._wybrany = ""
        self.lista.clear()
        self.tresc.clear()
        self.filtr.clear()
        self.tytul.clear()
        self.stan.clear()

    def _przyciski(self) -> None:
        ready = not self._trwa and self._aktualne()
        self.odswiez.setEnabled(ready)
        self.odswiez_rozmowe.setEnabled(ready and bool(self._wybrany))
        self.poprzednie.setEnabled(ready and self._offset_watkow() > 0)
        self.nastepne.setEnabled(
            ready
            and self._watki is not None
            and len(self._watki.pozycje) == ROZMIAR_STRONY
            and self._offset_watkow() < MAKS_OFFSET_WATKOW
        )
        self.nowsze.setEnabled(ready and self._offset_wiadomosci() > 0)
        self.starsze.setEnabled(
            ready
            and self._wiadomosci is not None
            and len(self._wiadomosci.pozycje) == ROZMIAR_STRONY
            and self._offset_wiadomosci() < MAKS_OFFSET_WIADOMOSCI
        )

    def pobierz_watki(self, offset: int) -> None:
        s = self._sesja
        if not self._aktualne() or self._trwa or s is None:
            return
        self._watki_offset = offset
        self._nr += 1
        nr = self._nr
        self._watek_nr += 1
        self._trwa = True
        self._watki = None
        self._wiadomosci = None
        self._wybrany = ""
        self.lista.clear()
        self.tresc.clear()
        self.tytul.setText("Wybierz rozmowę")
        self.stan.setText("Pobieranie strony rozmów…")
        self._przyciski()

        def gotowe(value: object) -> None:
            if not self._aktualne() or nr != self._nr:
                return
            self._trwa = False
            self._watki = cast(StronaWatkow, value)
            self._pokaz_watki()
            self._przyciski()

        def blad(kod: str, komunikat: str) -> None:
            if not self._aktualne() or nr != self._nr:
                return
            self._trwa = False
            self.stan.setText(komunikat)
            self._przyciski()

        self.uruchom(lambda: self.uc.watki(s, offset), gotowe, blad)

    def _pokaz_watki(self) -> None:
        if self._zamkniete:
            return
        self._watek_nr += 1
        self._trwa = False if self._watki is not None else self._trwa
        self._wiadomosci = None
        self._wybrany = ""
        self.lista.clear()
        self.tresc.clear()
        self.tytul.setText("Wybierz rozmowę")
        if self._watki is not None:
            fraza = self.filtr.text().strip().casefold()
            for row in self._watki.pozycje:
                if fraza and fraza not in row.login.casefold():
                    continue
                label = ("● " if not row.przeczytany else "") + (
                    row.login or "Rozmówca niedostępny"
                )
                item = QListWidgetItem(label + "\n" + (row.ostatnia or "Brak daty"))
                item.setData(Qt.ItemDataRole.UserRole, row)
                self.lista.addItem(item)
            self.stan.setText(
                f"Strona rozmów {self._offset_watkow() // ROZMIAR_STRONY + 1} · "
                f"widoczne: {self.lista.count()} z {len(self._watki.pozycje)}. "
                "Filtr dotyczy tylko tej strony."
            )
        self._przyciski()

    def _wybierz(self) -> None:
        item = self.lista.currentItem()
        row = item.data(Qt.ItemDataRole.UserRole) if item else None
        self._watek_nr += 1
        self._wiadomosci = None
        self._wybrany = row.id if isinstance(row, WatekAllegro) else ""
        self.tresc.clear()
        if isinstance(row, WatekAllegro):
            self._wiadomosci_offset = 0
            self.tytul.setText("Rozmowa · " + (row.login or "Rozmówca niedostępny"))
            # Zmiana wyboru unieważnia poprzedni odczyt, ale nie blokuje nowego.
            self._trwa = False
            self.pobierz_wiadomosci(0)
        self._przyciski()

    def pobierz_wiadomosci(self, offset: int) -> None:
        s, ident = self._sesja, self._wybrany
        if not self._aktualne() or self._trwa or s is None or not ident:
            return
        self._wiadomosci_offset = offset
        self._watek_nr += 1
        nr = self._watek_nr
        self._trwa = True
        self._wiadomosci = None
        self.tresc.clear()
        self.stan.setText("Pobieranie strony wiadomości…")
        self._przyciski()

        def gotowe(value: object) -> None:
            if not self._aktualne() or nr != self._watek_nr or ident != self._wybrany:
                return
            self._trwa = False
            page = cast(StronaWiadomosci, value)
            self._wiadomosci = page
            blocks = []
            for row in page.pozycje:
                lines = [f"{row.autor} · {row.kiedy} · {row.status}"]
                if row.temat:
                    lines.append(row.temat)
                lines.append(row.tekst)
                if row.zalaczniki:
                    lines.append("Załączniki (bez pobierania): " + ", ".join(row.zalaczniki))
                if row.dodatkowe_zalaczniki:
                    lines.append("Dodatkowe załączniki dostępne na Allegro.")
                blocks.append("\n".join(lines))
            self.tresc.setPlainText("\n\n".join(blocks))
            self.stan.setText(
                f"Strona wiadomości {offset // ROZMIAR_STRONY + 1} · "
                f"{len(page.pozycje)} wiadomości, od najnowszych."
                if page.pozycje
                else "Brak wiadomości na tej stronie."
            )
            self._przyciski()

        def blad(kod: str, komunikat: str) -> None:
            if not self._aktualne() or nr != self._watek_nr or ident != self._wybrany:
                return
            self._trwa = False
            self.stan.setText(komunikat)
            self._przyciski()

        self.uruchom(lambda: self.uc.wiadomosci(s, ident, offset), gotowe, blad)


class OknoWiadomosci(QDialog):
    """Ten sam panel w oknie otwieranym ze szczegółów zamówienia."""

    def __init__(
        self,
        uc: OdczytajWiadomosciAllegro,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
        login: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Wiadomości Allegro · odczyt")
        self.resize(1000, 660)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.panel = PanelWiadomosci(uc, uruchom, sesja, login, self)
        layout.addWidget(self.panel)
        zamknij = QPushButton("Zamknij")
        layout.addWidget(zamknij, 0, Qt.AlignmentFlag.AlignRight)
        zamknij.clicked.connect(self.reject)
        self.panel.konto_zmienione.connect(self.reject)
        self.finished.connect(self.panel._wyczysc)
