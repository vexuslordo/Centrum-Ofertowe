from dataclasses import replace

from tests.integration.test_wiadomosci_allegro import Czas, Transport, sesja, watek, wiadomosc
from vexlab.gui.wiadomosci_allegro import OknoWiadomosci
from vexlab.kanaly.wiadomosci_allegro import WiadomosciAllegroAPI
from vexlab.przypadki_uzycia.wiadomosci_allegro import OdczytajWiadomosciAllegro


def okno(qtbot, login=""):
    t = Transport(
        {"threads": [watek(), watek("thread-2", "drugi_testowy")], "offset": 0, "limit": 20}
    )
    uc = OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(t), Czas())
    jobs, account = [], [sesja()]
    w = OknoWiadomosci(uc, lambda *a: jobs.append(a), lambda: account[0], login)
    qtbot.addWidget(w)
    w.show()
    return w, t, jobs, account


def zakoncz(jobs):
    fn, ok, error = jobs.pop(0)
    ok(fn())


def test_filtr_biezacej_strony_odczyt_plaintext_i_brak_zapisu(qtbot):
    dialog, t, jobs, _ = okno(qtbot, "rozmowca_testowy")
    w = dialog.panel
    zakoncz(jobs)
    assert w.lista.count() == 1 and not w.nastepne.isEnabled()
    assert "tylko tej strony" in w.stan.text()
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    w.lista.setCurrentRow(0)
    zakoncz(jobs)
    assert "<b>bez HTML</b>" in w.tresc.toPlainText()
    assert "test.txt" in w.tresc.toPlainText() and w.tresc.isReadOnly()
    assert all(c[0] == "GET" for c in t.calls)
    w.filtr.clear()
    assert w.lista.count() == 2 and not w.tresc.toPlainText()
    w.parent().reject()
    assert not w.lista.count() and not w.filtr.text()


def test_spozniona_odpowiedz_poprzedniej_rozmowy_nie_nadpisuje_wybranej(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    zakoncz(jobs)
    w.lista.setCurrentRow(0)
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    fn, old_ok, old_error = jobs.pop(0)
    old = fn()
    w.lista.setCurrentRow(1)
    old_ok(old)
    old_error("HTTP", "stary blad")
    assert not w.tresc.toPlainText() and "stary blad" not in w.stan.text()
    t.payload = {
        "messages": [dict(wiadomosc(thread="thread-2"), text="Druga rozmowa")],
        "offset": 0,
        "limit": 20,
    }
    zakoncz(jobs)
    assert "Druga rozmowa" in w.tresc.toPlainText()


def test_zmiana_konta_czysci_i_odrzuca_spozniony_wynik(qtbot):
    dialog, _, jobs, account = okno(qtbot)
    w = dialog.panel
    fn, ok, error = jobs.pop(0)
    result = fn()
    account[0] = replace(account[0], konto=replace(account[0].konto, id="inne"))
    w._sprawdz_konto()
    ok(result)
    error("HTTP", "spozniony blad")
    assert not w.isVisible() and w._sesja is None
    assert w.lista.count() == 0 and not w.tresc.toPlainText() and not w.stan.text()


def test_zamkniecie_podczas_odczytu_i_blad_pozwalaja_ponowic(qtbot):
    dialog, _, jobs, _ = okno(qtbot)
    w = dialog.panel
    fn, ok, error = jobs.pop(0)
    error("LIMIT", "Limit Allegro")
    assert "Limit Allegro" in w.stan.text() and w.odswiez.isEnabled()
    w.odswiez.click()
    fn, ok, error = jobs.pop(0)
    result = fn()
    w.parent().reject()
    ok(result)
    assert not w.lista.count()


def test_paginacja_watkow_i_wiadomosci_ma_osobne_offsety(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    t.payload["threads"] = [watek(f"thread-{i}") for i in range(20)]
    zakoncz(jobs)
    assert w.nastepne.isEnabled() and not w.poprzednie.isEnabled()
    w.nastepne.click()
    t.payload = {"threads": [watek()], "offset": 20, "limit": 20}
    zakoncz(jobs)
    assert w.poprzednie.isEnabled() and not w.nastepne.isEnabled()
    w.lista.setCurrentRow(0)
    t.payload = {
        "messages": [wiadomosc(f"message-{i}") for i in range(20)],
        "offset": 0,
        "limit": 20,
    }
    zakoncz(jobs)
    assert w.starsze.isEnabled()
    w.starsze.click()
    t.payload = {"messages": [], "offset": 20, "limit": 20}
    zakoncz(jobs)
    assert w.nowsze.isEnabled() and not w.starsze.isEnabled()
    assert w._offset_watkow() == 20


def test_blad_dalszej_strony_zachowuje_powrot_i_jawne_ponowienie(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    t.payload["threads"] = [watek(f"thread-{i}") for i in range(20)]
    zakoncz(jobs)
    w.nastepne.click()
    jobs.pop(0)[2]("HTTP", "Błąd testowy")
    assert w.poprzednie.isEnabled() and w._offset_watkow() == 20
    w.odswiez.click()
    t.payload = {"threads": [watek()], "offset": 20, "limit": 20}
    zakoncz(jobs)
    w.lista.setCurrentRow(0)
    jobs.pop(0)[2]("HTTP", "Błąd rozmowy")
    assert w.odswiez_rozmowe.isEnabled()
    w.odswiez_rozmowe.click()
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    zakoncz(jobs)
    assert "Treść syntetyczna" in w.tresc.toPlainText()


def test_przycisk_zamowienia_otwiera_rozmowy_i_zmiana_konta_zamyka(qtbot):
    from tests.integration.test_zamowienia_allegro import API
    from vexlab.gui.zamowienia_allegro import StronaZamowien
    from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro

    jobs, account = [], [sesja()]
    messages = OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(Transport({})), Czas())
    page = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()),
        lambda *a: jobs.append(a),
        lambda: account[0],
        wiadomosci=messages,
    )
    qtbot.addWidget(page)
    assert not page.panel.napisz.isEnabled()
    page.pobierz_liste()
    zakoncz(jobs)
    page.tabela.selectRow(0)
    assert page.panel.napisz.isEnabled()
    page.panel.napisz.click()
    dialog = page.okno_wiadomosci
    assert dialog is not None and dialog.panel.filtr.text() == "kupujacy_testowy"
    account[0] = None
    page.polaczenie()
    assert page.okno_wiadomosci is None and dialog.panel._zamkniete
