"""Malowanie kart źródeł i zgrupowanych pól. Istniejące kolumny/dane pozostają w modelu."""

from collections.abc import Callable

from PySide6.QtCore import QModelIndex, QPersistentModelIndex, QRect, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPalette
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionViewItem,
)

from vexlab.gui.branding_cennikow import BrandingCennikow
from vexlab.gui.design_system import kolor_statusu_cennika
from vexlab.gui.premium import MONO, DelegatDanych
from vexlab.przypadki_uzycia.cenniki import CennikDTO


def linia(
    painter: QPainter,
    rect: QRect,
    value: str,
    offset: int,
    *,
    bold: bool = False,
    muted: bool = False,
    palette: QPalette,
    techniczne: bool = False,
) -> None:
    font = QFont(painter.font())
    if techniczne:
        font.setFamily(MONO)
    font.setPixelSize(12 if bold else 11)
    font.setWeight(QFont.Weight.DemiBold if bold else QFont.Weight.Normal)
    painter.setFont(font)
    painter.setPen(
        palette.color(QPalette.ColorRole.PlaceholderText if muted else QPalette.ColorRole.Text)
    )
    text = QFontMetrics(font).elidedText(value, Qt.TextElideMode.ElideRight, rect.width())
    painter.drawText(
        QRect(rect.left(), rect.top() + offset, rect.width(), 20),
        Qt.AlignmentFlag.AlignVCenter,
        text,
    )


class KartaCennika(QStyledItemDelegate):
    def __init__(self, branding: BrandingCennikow) -> None:
        super().__init__()
        self.branding = branding

    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        row = index.data(Qt.ItemDataRole.UserRole)
        if not isinstance(row, CennikDTO):
            return
        painter.save()
        painter.setClipRect(option.rect)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        visible = option.rect
        if isinstance(option.widget, QAbstractItemView):
            visible = visible.intersected(option.widget.viewport().rect())
        rect = visible.adjusted(2, 3, -2, -3)
        pal = QApplication.palette()
        background = pal.color(QPalette.ColorRole.Window)
        background.setAlpha(255)
        painter.fillRect(visible, background)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        painter.setBrush(
            pal.brush(QPalette.ColorRole.Highlight if selected else QPalette.ColorRole.Base)
        )
        color = pal.color(QPalette.ColorRole.Highlight if selected else QPalette.ColorRole.Text)
        color.setAlpha(200 if selected else 35)
        painter.setPen(color)
        painter.drawRoundedRect(rect, 10, 10)
        image = QRect(rect.left() + 8, rect.top() + 10, 54, 54)
        logo = self.branding.logo(row)
        if not logo.isNull():
            logo.paint(painter, image)
        else:
            painter.setPen(pal.color(QPalette.ColorRole.PlaceholderText))
            painter.drawRoundedRect(image, 7, 7)
            font = QFont(option.font)
            font.setPixelSize(20)
            font.setWeight(QFont.Weight.DemiBold)
            painter.setFont(font)
            painter.drawText(
                image, Qt.AlignmentFlag.AlignCenter, (row.producent or row.nazwa)[:2].upper()
            )
        text = rect.adjusted(70, 5, -6, 0)
        linia(painter, text, row.producent or "Bez producenta", 0, bold=True, palette=pal)
        linia(painter, text, f"{row.liczba:,} produktów".replace(",", " "), 18, palette=pal)
        linia(painter, text, "Aktualny: " + str(row.rok), 36, muted=True, palette=pal)
        status_color = kolor_statusu_cennika(
            row.status, pal.color(QPalette.ColorRole.Base).lightness() < 128
        )
        painter.setPen(status_color or pal.color(QPalette.ColorRole.PlaceholderText))
        painter.drawText(
            QRect(text.left(), rect.top() + 55, text.width(), 18),
            Qt.AlignmentFlag.AlignVCenter,
            "● " + row.status,
        )
        painter.restore()


class WierszCennika(DelegatDanych):
    def __init__(
        self, parent: QAbstractItemView, opis: Callable[[int], str] = lambda _: ""
    ) -> None:
        super().__init__(parent)
        self.opis = opis

    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        base = QStyleOptionViewItem(option)
        self.initStyleOption(base, index)
        base.text = ""
        style = option.widget.style() if option.widget else QApplication.style()
        if style:
            style.drawControl(QStyle.ControlElement.CE_ItemViewItem, base, painter, option.widget)
        painter.save()
        painter.setClipRect(option.rect)
        rect = option.rect.adjusted(10, 7, -10, -5)
        pal = option.palette
        model = index.model()
        if model is None:
            painter.restore()
            return

        def value(column: int) -> str:
            return str(index.sibling(index.row(), column).data() or "")

        if index.column() == 0:
            painter.setPen(
                pal.color(
                    QPalette.ColorRole.HighlightedText
                    if option.state & QStyle.StateFlag.State_Selected
                    else QPalette.ColorRole.PlaceholderText
                )
            )
            check = QRect(option.rect.center().x() - 6, option.rect.center().y() - 6, 12, 12)
            painter.drawRoundedRect(check, 2, 2)
            if option.state & QStyle.StateFlag.State_Selected:
                painter.drawText(check, Qt.AlignmentFlag.AlignCenter, "✓")
        elif index.column() == 1:
            linia(painter, rect, value(1), 0, bold=True, palette=pal)
            linia(painter, rect, self.opis(index.row()), 20, muted=True, palette=pal)

        elif index.column() == 2:
            linia(painter, rect, value(2), 10, palette=pal, techniczne=True)
        elif index.column() == 3:
            lines = value(3).replace(" (VAT 23%)", "\nVAT 23%").splitlines()
            for i, text in enumerate(lines[:1]):
                linia(
                    painter,
                    rect,
                    text.removeprefix("Brutto: "),
                    i * 19,
                    bold=i == 0,
                    muted=i > 0,
                    techniczne=True,
                    palette=pal,
                )
        elif index.column() == 6:
            state = value(6)
            color = kolor_statusu_cennika(
                state, pal.color(QPalette.ColorRole.Base).lightness() < 128
            )
            color = color or pal.color(QPalette.ColorRole.PlaceholderText)
            badge = QRect(rect.left(), option.rect.center().y() - 13, rect.width(), 26)
            fill = QColor(color)
            fill.setAlpha(25)
            painter.setBrush(fill)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(badge, 7, 7)
            painter.setPen(color)
            font = QFont(option.font)
            font.setPixelSize(11)
            font.setWeight(QFont.Weight.DemiBold)
            painter.setFont(font)
            text = QFontMetrics(font).elidedText(
                "● " + state, Qt.TextElideMode.ElideRight, badge.width() - 10
            )
            painter.drawText(badge.adjusted(5, 0, -5, 0), Qt.AlignmentFlag.AlignCenter, text)
        elif index.column() == 5:
            lines = value(5).splitlines()
            first = lines[0].strip() if lines else "—"
            ciemny = pal.color(QPalette.ColorRole.Base).lightness() < 128
            code = (
                "Do poprawy"
                if first.startswith("+")
                else "Aktualny"
                if first.startswith(("-", "0,00 "))
                else ""
            )
            color = kolor_statusu_cennika(code, ciemny) if code else None
            painter.setPen(color or pal.color(QPalette.ColorRole.Text))
            font = QFont(option.font)
            font.setWeight(QFont.Weight.DemiBold)
            font.setPixelSize(12)
            painter.setFont(font)
            metrics = QFontMetrics(font)
            for i, text in enumerate(lines[:2]):
                text = metrics.elidedText(text, Qt.TextElideMode.ElideRight, rect.width())
                painter.drawText(
                    QRect(rect.left(), rect.top() + 10 + i * 20, rect.width(), 20),
                    Qt.AlignmentFlag.AlignVCenter,
                    text,
                )
        painter.restore()
