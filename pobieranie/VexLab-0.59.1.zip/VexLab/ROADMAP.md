# VexLab — plan rozwoju

Wersja 0.3 • 2026-11-02 • plan do zatwierdzenia, bez deklaracji wykonania etapów.

## 1. Zasady planu

WYMAGANIE: rozwój przebiega przez 12 wskazanych etapów, z pierwszeństwem modelu domenowego przed integracjami. Nazwy i kolejność etapów wynikają z polecenia. Zadania szczegółowe, zależności i bramki poniżej są PROPOZYCJAMI. Nie nadano terminów, budżetu ani obsady, ponieważ ich nie ustalono.

Stan historyczny przed etapem 1: przygotowano siedem dokumentów nowego projektu. Aktualny stan opisują sekcje kolejnych przyrostów poniżej. Plan nie wymaga wcześniejszego repozytorium ani dokumentacji. Nie ma implementacji, schematu bazy, działającego CI ani potwierdzonej wersji zależności. Żaden etap implementacyjny nie jest oznaczony jako ukończony.

Każdy etap ma dowody odbioru: zmienione artefakty, wyniki testów, otwarte decyzje, ryzyka i osobę zatwierdzającą. Niespełniona bramka blokuje tylko zależne prace. Dokumentacja, testowanie i bezpieczeństwo są pracą ciągłą; etap 11 nie oznacza odkładania ich do końca.

## 2. Etap 1 — przygotowanie środowiska

**Cel:** odtwarzalne środowisko Windows, zgodne wersje i wspólny standard pracy.

**Zależności:** wybór miejsca na nowe repozytorium, decyzja o wersji Pythona i sposobie zarządzania zależnościami.

**Prace P:** utworzyć repozytorium nowego projektu i umieścić w nim uzgodnioną dokumentację; ustalić wersje Windows i Pythona; utworzyć izolowane środowisko; przygotować `pyproject.toml`, przypięte zależności i grupy developerskie; skonfigurować pytest, ruff, mypy, import-linter, bandit i pip-audit; opisać CI. Nie wybierać biblioteki UI tylko dlatego, że łatwo ją zainstalować.

**Artefakty P:** instrukcja uruchamiania zgodna z rzeczywistą konfiguracją, rejestr wersji, minimalny przebieg CI i lista otwartych decyzji.

**Kryteria ukończenia P:** druga czysta instalacja środowiska odtwarza ten sam zestaw; narzędzia uruchamiają się z tego środowiska; brak sekretów i danych biznesowych w repozytorium; dokumentacja nie odwołuje się do nieistniejących punktów startu.

**Testy P:** instalacja w czystym środowisku; test wykrywania próbnego błędu formatu, typowania i importu; kontrola kompletności audytu zależności. Próbne naruszenia usunąć po weryfikacji. Pusty zbiór testów nie jest dowodem poprawności aplikacji.

## 3. Etap 2 — fundament architektoniczny

**Cel:** sześć warstw, porty i mechanizm składania bez zależności zwrotnych.

**Zależności:** etap 1; decyzja P-01 i rozstrzygnięcie K-01.

**Prace P:** zatwierdzić graf importów z konstytucji; utworzyć strukturę pakietów; zaprojektować minimalne kontrakty błędów, zegara i korelacji; umieścić porty w przypadkach użycia; określić punkt składania; zaprojektować granice testów. Nie tworzyć uniwersalnego frameworka bez scenariusza.

**Artefakty P:** kontrakty import-linter, diagram zależności, testy granic i przykład izolowanego przepływu technicznego bez danych biznesowych.

**Kryteria ukończenia P:** domena ładuje się bez Qt i bazy; GUI nie importuje implementacji infrastruktury; `kanaly` i `adaptery` pozostają niezależne; bootstrap jest jawnie wyłączonym z kontraktu punktem zewnętrznym, a nie furtką dla usług biznesowych.

**Testy P:** zakazy importów, test wymienności portu, test uruchomienia bez kont i danych użytkownika. Przegląd dynamicznych zależności uzupełnia lint.

## 4. Etap 3 — model domenowy

**Cel:** zatwierdzone znaczenie 16 bytów i najważniejszych scenariuszy.

**Zależności:** etap 2; dostęp do właściciela projektu i przegląd propozycji nowego modelu.

**Prace P:** przeprowadzić przegląd kart DOMAIN_MODEL; zatwierdzić pola, agregaty, liczności i właścicieli; ustalić semantykę pieniędzy, czasu i ID; rozdzielić stan zamierzony od obserwowanego; uzgodnić duplikaty, archiwizację i konflikt wersji. Nie budować domeny ze schematu API Allegro.

**Artefakty P:** zatwierdzony model, macierz własności pól, scenariusze akceptacyjne, ADR zmieniające status propozycji oraz kod domeny dopiero po tych decyzjach.

**Kryteria ukończenia P:** wszystkie 16 kart mają właściciela, źródło prawdy, granicę i operacje; nieustalone reguły mają jawnie wyłączony zakres; każdy zatwierdzony niezmiennik ma scenariusz sprawdzenia. Szkicowa obecność 16 klas nie wystarcza.

**Testy P:** pozytywne, graniczne i odrzucające dla niezmienników; odrębność ról i tożsamości; historyczne dane transakcji; bez Qt, SQL i sieci.

## 5. Etap 4 — baza danych i migracje

**Cel:** trwały zapis zgodny z zatwierdzonym modelem, bezpieczna aktualizacja i odtworzenie.

**Zależności:** etap 3; P-04 i P-08; decyzja o lokalizacji danych i topologii instalacji.

**Prace P:** wybrać mechanizm dostępu i migracji; zmapować agregaty na tabele bez utożsamiania tych pojęć; ustalić klucze i indeksy; wdrożyć repozytoria i transakcje; zaprojektować współbieżny zapis, kopie i diagnostykę awarii. Zdefiniować wspierane ścieżki aktualizacji.

**Artefakty P:** schemat, rejestr migracji, adaptery portów, procedura kopii/odtworzenia i test czystej instalacji.

**Kryteria ukończenia P:** nowa baza ma zero rekordów biznesowych; zapis nie jest częściowy po błędzie; wersja aplikacji nie otwiera nieobsługiwanego schematu; odtworzenie sprawdzone na kopii. Nie stosować demonstracyjnych seedów.

**Testy P:** prawdziwy SQLite w katalogu tymczasowym; ograniczenia, rollback, konflikty zapisu, zerwane połączenie, brak miejsca symulowany kontrolowanie, migracja ze wspieranych wersji, awaria w trakcie oraz integralność odtworzonej kopii.

## 6. Etap 5 — Design System i powłoka PySide6

**Cel:** odtworzenie powłoki i dashboardu UI-REF-01 w PySide6 oraz wspólnego Design Systemu. Układ wzorca jest wymaganiem, nie dowolną propozycją stylistyczną.

**Zależności:** etap 2 oraz zatwierdzone pojęcia z etapu 3; P-05; strategia wykonywania zadań. Można opracowywać prototyp niezależnie od finalnego repozytorium danych.

**Prace P:** zatwierdzić tokeny, motywy i komponenty; stworzyć galerię stanów; powłokę z nawigacją; modele widoków; puste, błędne i ładujące stany; mechanizm zadań i postępu. Przed QFluentWidgets zamknąć bramkę techniczno-licencyjną. Ustalić sprzęt i skalę testów.

**Artefakty P:** galeria, prototyp powłoki, testy dostępności, raport porównania biblioteki i alternatywy, pomiary pętli UI.

**Kryteria ukończenia P:** wszystkie wspólne komponenty działają w obu motywach; preferencja systemowa i ograniczony ruch są obsługiwane; żadna operacja nie blokuje GUI; nie ma demonstracyjnych klientów i kont.

**Testy P:** macierz DPI z systemu UI, Narrator, klawiatura i fokus, duży tekst, wielomonitorowość, pomiar kontrastu i opóźnień. Przekroczenie proponowanego celu wymaga oceny, nie ukrycia wyniku.

## 7. Etap 6 — podstawowe moduły biznesowe

**Cel:** przygotować spójne miejsca pracy dla zatwierdzonych obszarów.

**Zależności:** etapy 3 i 5; etap 4 dla rzeczywistego odczytu. Rozstrzygnięcie K-02 jest wymagane przed traktowaniem modułów jako funkcjonalnych.

**Prace P:** ustalić kolejność modułów; rekomendacja: Katalog → konfiguracja sprzedaży → Oferty → obsługa sprzedaży → komunikacja. Zaprojektować listy, szczegóły, formularze, filtry i kontrakty zapytań. W tym etapie przygotować układ i adaptery prezentacji; nie pisać reguł biznesowych w GUI dla ominięcia etapu 7.

**Artefakty P:** mapy ekranów, makiety, modele prezentacji, scenariusze wejścia/wyjścia i zachowania bez danych.

**Kryteria ukończenia P:** każdy ekran ma spójne stany, zakres i akcję; pole „Dostawca” nie zastępuje „Producent”; aktywne konto jest jawne; brak pozornie działających przycisków. Operacje niewdrożone nie są przedstawiane jako ukończone.

**Testy P:** nawigacja, zachowanie filtrów i fokusu, formularz po błędzie, brak wyników vs pusta instalacja, brak zależności GUI od SQL. Zestawy danych wyłącznie syntetyczne, izolowane od produkcji.

## 8. Etap 7 — przypadki użycia

**Cel:** działające pionowe scenariusze od UI przez aplikację i domenę do portów.

**Zależności:** etapy 3–6; P-06 dla trwałej pracy. Etapy 6 i 7 realizować iteracyjnie w obrębie małego scenariusza; numeracja nie uzasadnia logiki w GUI.

**Prace P:** dla każdego przypadku opisać wejście, wynik, warunki, transakcję, błędy i uprawnienia; podłączyć porty; kontrolować wersje i duplikaty. Rekomendowane pierwsze scenariusze do akceptacji: utworzenie Produktu, zmiana danych, utworzenie szkicu Oferty i odczyt listy. Nie traktować ich jako zgody na publikację zewnętrzną.

**Artefakty P:** kontrakty komend/zapytań, implementacje przypadków i testy przepływu, dokumentacja błędów.

**Kryteria ukończenia P:** GUI nie zna repozytorium; błąd nie gubi formularza; zapis chroni niezmienniki; działania wymagające decyzji pozostają wyłączone. Każdy scenariusz ma potwierdzony wynik biznesowy.

**Testy P:** sukces, błędne wejście, odmowa, konflikt wersji, awaria portu, rollback i ponowne uruchomienie, jeśli dotyczy. Test integracyjny pełnego lokalnego przepływu bez aktywnych API.

## 9. Etap 8 — integracje sprzedażowe

**Cel:** pierwsza wymienna integracja bez podporządkowania jej modelu domenowego.

**Zależności:** etap 7; P-03, P-06 i P-07; kolejność wdrożenia Allegro i PrestaShop, sandbox, autoryzacja oraz kompletne mapowanie pól. Allegro i PrestaShop są wymaganymi integracjami wzorca. Ich kolejność pozostaje otwarta. Subiekt GT pozostaje przyszłym kierunkiem, niewymaganym przez ten ekran.

**Prace P:** kontrakty konektora, DTO, mapowanie statusów i identyfikatorów, paginacja, limity, timeouty, deduplikacja i uzgadnianie wyniku. Osobno testować odczyt/import i skutki zewnętrzne. Utworzyć ścieżkę obsługi konfliktu i niewspieranego statusu.

**Artefakty P:** tabela mapowania, kontrakty integracji, raport autoryzacji i zakresów, procedura awarii oraz testy sandbox.

**Kryteria ukończenia P:** dwa konta są izolowane; import jest powtarzalny bez duplikatów; restart nie gubi pracy; wynik nieznany jest widoczny; odłączenie konta nie kasuje danych. Pierwsze rzeczywiste publikacje wymagają jawnego zakresu pilotażu.

**Testy P:** 401/403, limity, timeout przed i po skutku, błędny JSON, nowy status, duplikaty i zmiana kolejności zdarzeń, cofnięcie autoryzacji. Testy domyślnie nie wykonują prawdziwej sprzedaży ani wysyłki.

## 10. Etap 9 — automatyzacje

**Cel:** kontrolowane reakcje Reguł na Zdarzenia z widocznymi Operacjami.

**Zależności:** etapy 7–8 dla automatyzowanych scenariuszy; zatwierdzona semantyka Reguły, Zdarzenia i Operacji oraz ograniczenia skutków.

**Prace P:** wersjonowanie definicji; walidacja; symulacja bez skutków; aktywacja/pauza; deduplikacja; wykrywanie cykli; ograniczenia pracy i historia przyczyny. Nie udostępniać dowolnego `eval` jako edytora reguł.

**Artefakty P:** specyfikacja języka warunków, macierz przejść wykonania, historia użytej wersji, panel Operacji.

**Kryteria ukończenia P:** każda automatyczna czynność ma przyczynę i wersję reguły; pauza ma określony wpływ na pracę już rozpoczętą; błąd jednej Reguły nie uruchamia nieskończonych ponowień.

**Testy P:** duplikat zdarzenia, pętla, konflikt Reguł, restart, równoległe wykonanie, błędna definicja i nieznana wersja payloadu. Symulacja nie wysyła nic do systemu produkcyjnego.

## 11. Etap 10 — analityka

**Cel:** wiarygodne wskaźniki o jasno opisanym znaczeniu.

**Zależności:** stabilne dane z etapów 7–9 i zatwierdzone definicje metryk. Nie obliczać przychodu bez rozstrzygnięcia walut, anulowań, podatków i zakresu dat.

**Prace P:** słownik metryk; modele odczytu/projekcje; filtrowanie po kontekście; czas ostatniej aktualizacji; uzgadnianie wyników z danymi źródłowymi; eksport z kontrolą zakresu danych osobowych.

**Artefakty P:** definicje liczników i mianowników, źródła pól, reguły czasu i walut, pulpity z pustymi stanami.

**Kryteria ukończenia P:** wskaźnik jest odtwarzalny; brak danych różni się od zera; waluty nie są mieszane; projekcja ma opis aktualności. Nie wstawiać fikcyjnych wyników dla nowej instalacji.

**Testy P:** granice dat i stref, anulowania, korekty, różne waluty, porównanie projekcji z wyliczeniem referencyjnym oraz koszt zapytań na zatwierdzonym wolumenie.

## 12. Etap 11 — testy wydajności i bezpieczeństwa

**Cel:** kwalifikacja całości i usunięcie ryzyk przed dystrybucją; kontrole narzędziowe działają już od etapu 1.

**Zależności:** wdrożony zakres wydania, sprzęt i dane referencyjne, model zagrożeń, polityka retencji i kopii.

**Prace P:** pomiary list, wyszukiwania, importu i długich Operacji; analiza pamięci; blokady SQLite; awarie i odtworzenie; przegląd tokenów, logów i załączników; audyt zależności i licencji; kontrola granic architektonicznych.

**Artefakty P:** raport z warunkami pomiaru, wyniki wszystkich siedmiu narzędzi jakości, rejestr ryzyk i wyjątków, raport przywrócenia danych.

**Kryteria ukończenia P:** spełnione zatwierdzone cele; żadna znana krytyczna luka bez rozstrzygnięcia; wyjątki mają właściciela i termin; brak sekretów w diagnostyce; rzeczywiście sprawdzone odtworzenie. Priorytety ryzyka i zasady blokowania wydania wymagają zatwierdzenia.

**Testy P:** obciążenie i długotrwała praca, przerwanie zasilania symulowane na kopii, pełny dysk, uszkodzony import, niebezpieczna ścieżka załącznika, odmowa dostępu do magazynu sekretów, pomiary GUI podczas synchronizacji.

## 13. Etap 12 — dystrybucja Windows

**Cel:** instalowalne, aktualizowalne i obsługiwalne wydanie.

**Zależności:** etap 11, P-09, komplet licencji i wspierana macierz Windows. Narzędzie pakowania i sposób aktualizacji są NIEUSTALONE.

**Prace P:** reproducowalny pakiet, metadane wersji, podpisywanie według przyjętej polityki, zasoby i licencje, instalacja bez narzędzi developerskich, aktualizacja schematu, diagnostyka i instrukcja wsparcia. Ustalić zachowanie deinstalacji względem danych użytkownika.

**Artefakty P:** instalator/pakiet, sumy kontrolne, wykaz zależności i licencji, release notes, instrukcja instalacji/aktualizacji/odtworzenia.

**Kryteria ukończenia P:** działa na czystej wspieranej maszynie; nowa instalacja ma pusty katalog biznesowy; aktualizacja zachowuje dane i preferencje; niezgodna wersja nie uszkadza schematu; deinstalacja nie usuwa danych bez świadomej decyzji. Procedura powrotu uwzględnia zgodność schematu, nie tylko starszy plik EXE.

**Testy P:** czysta instalacja, aktualizacja każdej wspieranej wersji, brak uprawnień administratora w normalnej pracy, ścieżki ze spacjami i polskimi znakami, Defender według polityki organizacji, DPI, start offline, przerwana aktualizacja, odtworzenie kopii i deinstalacja.

## 14. Zależności i zakres pierwszego wydania

Ścieżka bazowa: 1 → 2 → 3 → 4; etap 5 po 2 i przeglądzie 3; następnie iteracja 6↔7 → 8 → 9 → 10 → 11 → 12. Zakres 9–10 może trafić do późniejszych wydań wyłącznie po jawnej decyzji; nie jest to automatyczna zmiana wymaganego planu.

Nie zatwierdzono MVP. Propozycja pierwszego przyrostu do rozmowy: lokalny Katalog, szkic Oferty, pusta instalacja, kopia/odtworzenie i wspólna powłoka, bez skutków zewnętrznych. Kolejny przyrost może wprowadzić jedną integrację. Decyzję o zakresie powiązać z P/Q/K w [ADR_INDEX](ADR_INDEX.md), nie z domyślnym wyborem platformy.

## 15. Definicja ukończenia przyrostu — propozycja

Przyrost ma zatwierdzony scenariusz, zgodny model, właściwe źródła prawdy, testy i kontrole jakości, obsługę błędów i awarii, dostępne UI oraz aktualną dokumentację. Wykonane sprawdzenia mają dowód; niewykonane są wymienione. Nie przenosić niejawnie długu do późniejszego etapu. Ukończenie wymaga przeglądu, a nie wyłącznie działającej demonstracji.

## 16. Aktualizacja zakresu według UI-REF-01

WYMAGANIE: docelowy interfejs i wszystkie widoczne opcje mają odpowiadać [ekranowi użytkownika](assets/UI_REFERENCE.png). Dokładna specyfikacja jest w UI_UX_DESIGN_SYSTEM, sekcje 15–23. Układ nie wymaga ponownego wyboru kierunku stylistycznego. Zadania i szczegóły techniczne poniżej są P, a wymagany zakres funkcji wynika z polecenia aktualizacji.

### 16.1. Włączenie do 12 istniejących etapów

| Etap | Dodatkowe prace | Dodatkowa bramka i dowód |
|---|---|---|
| 1 — Środowisko | Dodać referencję do dokumentacji; ustalić narzędzie porównań wizualnych i bibliotekę wykresów; źródła ikon/logo | Zapis źródła UI-REF-01; brak narzucenia Pythona 3.10.12 i limitów z makiety |
| 2 — Fundament | Porty modeli odczytu, generatora AI, importu pliku, magazynu mediów i pracy w tle | GUI nie importuje parsera, klienta AI, SQLite ani konektora platformy |
| 3 — Model | Cenniki, źródła cen i ilości, media, układy, akceptacja AI, KPI i problemy | Rozstrzygnięte ADR-013–ADR-016 dla implementowanego przyrostu; brak ukrytego siedemnastego bytu |
| 4 — Baza | Projekcje dashboardu, trwałość Operacji, dane zatwierdzonych rozszerzeń | Pusta instalacja; migracja i odtworzenie; brak nazw kont i producentów z obrazu |
| 5 — Design System | Odtworzyć nagłówek, menu, KPI, pasek działań, panele, stopkę, miniatury i stany | Porównanie 1536×1024 z referencją, DPI, jasny/ciemny, klawiatura i Narrator |
| 6 — Moduły | Cenniki, media, AI, edycja masowa, ceny, szablony, podstrony platform, kolejka, raporty i pomoc | Każda pozycja wzorca ma poprawną trasę i spójny widok; brak fałszywych sukcesów |
| 7 — Przypadki użycia | Podłączyć wyszukiwanie, kreatory, import, podgląd zmian, walidację, akceptację opisów i wyniki | Test pełnego lokalnego scenariusza, konfliktu wersji i zachowania formularza po błędzie |
| 8 — Integracje | Allegro i PrestaShop; pobieranie, publikacja, synchronizacja cen, stany połączenia i limitów | Dwa konektory w planie; sandboxy, wiele kont, częściowe połączenie, wynik nieznany |
| 9 — Automatyzacja | Kolejka dla importu, cen, AI, mediów, publikacji i walidacji, gdzie praca jest długotrwała | Restart, deduplikacja, bezpieczne ponowienie; brak autopublikacji AI |
| 10 — Analityka | Cztery KPI, historia, wykres dwóch serii, okresy, tooltip i tabela danych | Definicje metryk, pusta baza, brak porównania, anulowania, strefy i waluty |
| 11 — Kwalifikacja | Testy dużej galerii, masowych zmian, złośliwych plików/HTML i danych wejścia AI | Brak wycieku sekretów; UI reaguje podczas pracy; obraz/AI traktowane jako dane |
| 12 — Dystrybucja | Spakować zasoby, ikony, wykresy i licencje; sprawdzić świeży profil | Wygląd po instalacji zgodny z wzorcem bez obecności demonstracyjnych rekordów |

### 16.2. Proponowane pionowe przyrosty

**A — wierna powłoka i dashboard lokalny.** Zależności: zatwierdzony graf importów, tokeny i modele odczytu. Zakres: menu ze wzorca, globalne szukanie, cztery KPI, ostatnie Produkty, Operacje, dolne panele i stopka; stany puste i niepołączone. Dane demonstracyjne tylko do odrębnego testu wizualnego. Odbiór: porównanie wizualne i brak fałszywych aktywnych integracji.

**B — przygotowanie katalogu i ofert.** Zależności: model cen/mediów/układów i lokalne przypadki użycia. Zakres: Cenniki/import, galeria, nowe Oferty i szkice, masowa edycja, zmiana cen, kreator układu i kopiowanie, sprawdzenie błędów. Odbiór: podgląd, walidacja, zapis i raport per obiekt; brak skutków zewnętrznych bez potwierdzenia.

**C — integracje i kolejka.** Zależności: sandboxy, macierz źródeł, bezpieczeństwo kont i trwałe Operacje. Zakres: Allegro i PrestaShop, pobieranie, publikacja, uzgadnianie cen, karty integracji i historia. Odbiór: timeout po skutku, wiele kont, duplikat, przerwanie/restart i częściowy sukces.

**D — AI i analityka.** Zależności: port generatora, wybrany dostawca i warunki danych; definicje metryk. Zakres: kreator opisów i kafel AI, świadoma akceptacja, raporty, wykres i delty KPI. Odbiór: brak automatycznej publikacji, odrzucenie wyniku bez zmiany Produktu, metryki zgodne z danymi, obsługa braku porównania.

Przyrosty są propozycją kolejności, nie usunięciem części funkcji. Wcześniejszy pomysł MVP z sekcji 14 nie definiuje kompletności nowego zakresu. Pełna zgodność z ekranem wymaga funkcjonalnych wejść wszystkich jego opcji. Harmonogram i granice wydań pozostają otwarte.

### 16.3. Rejestr odbioru wzorca

Dla każdej opcji prowadzić wpis: identyfikator funkcji, element ekranu, przypadek użycia, model/port, stan implementacji, test, wynik i różnice. Obowiązkowe przypadki: nowa baza; podłączone dwa systemy; tylko jeden dostępny; wiele kont; brak sieci; błędny import; częściowa edycja masowa; nieznany wynik publikacji; niedostępny AI; brak pliku zdjęcia; 200% DPI. Wydanie nie może deklarować pełnej zgodności, gdy kafle jedynie wyświetlają „gotowe” bez wykonania.

## 17. Stan realizacji po pierwszym przyroście

Data: 2026-11-02. Nazwa programu: VexLab (ADR-018).

- Etap 1: środowisko Linux przygotowane, zależności przypięte, druga czysta
  instalacja zweryfikowana, narzędzia jakości działają. CI Windows/Linux
  zapisano; wykonanie CI i odbiór na Windows pozostają niezweryfikowane.
- Etap 2: sześć warstw, zewnętrzny bootstrap, porty technicznej diagnostyki,
  zegar, korelacja i kontrolowane błędy. Kontrakty importów i testy negatywne
  działają. Nie ma biznesowego modelu, trwałych danych, GUI ani integracji.
- Porty biznesowych modeli odczytu, AI, importu i mediów z sekcji 16.1
  celowo pozostają do konkretnych scenariuszy po przeglądzie modelu; nie
  wprowadzono nieuzgodnionych DTO tylko dla zapełnienia katalogów.

Dowody, konflikty i ograniczenia: [raport](docs/RAPORT_ETAPY_1_2.md).
Status nie oznacza pełnego odbioru etapu 1 na Windows ani realizacji etapu 3.

## 18. Przyrost 0.2 — lokalny katalog i pierwsza powłoka

Bieżące polecenie rozszerza poprzedni zakres techniczny. Właściciel wybrał
obowiązkowe, unikalne SKU bez rozróżniania wielkości liter. Wykonano mały
pionowy przyrost etapów 3–7 w zakresie wyłącznie tego scenariusza:
minimalny Produkt, porty, SQLite z początkowym schematem i kopią, GUI dodania,
edycji i wyszukiwania. Nie oznacza to zamknięcia całych etapów 3–7.
Działa powłoka, nawigacja, motywy, Ctrl+K i zapis preferencji. Integracje,
Oferty, ceny, magazyn, media, AI i analityka pozostają niewdrożone.
Dowody i ograniczenia: [raport przyrostu](docs/RAPORT_PRZYROST_0_2.md).

## 19. Przyrost 0.3 — Producenci

Wdrożono kolejny pionowy scenariusz: producent z nazwą i aktywnością,
opcjonalne pojedyncze przypisanie do Produktu, odczyt nazwy w katalogu,
GUI, trwałość i migrację schematu 1→2 z kopią. To ograniczony zakres
zatwierdzony w ADR-022, nie ukończenie całych etapów 3–7.
Raport: [przyrost 0.3](docs/RAPORT_PRZYROST_0_3.md).

## Przyrost 0.4 — przegląd istniejącego katalogu

Wdrożono wspólne filtrowanie producenta i nazwy/SKU, szczegóły oraz eksport
widocznych wyników do CSV (ADR-024). Nie zmieniono schematu 2 ani modelu.
Nie oznacza to zakończenia etapów integracyjnych. Import katalogów, profile
Allegro → PrestaShop i kurierzy są odłożone zgodnie z ADR-023.

## Planowany przyrost — import paczki Produktów

Wymaganie właściciela: import wielu Produktów np. z cennika producenta,
z wyborem Producenta. Wejście obok ręcznego dodawania i przejście z jego
formularza; wybór pliku, mapowanie kolumn, podgląd i zatwierdzenie.
Propozycja pierwszego zakresu: nazwa, SKU, opis i producent, bez nadpisywania
istniejących Produktów. Import cen wymaga odrębnego ustalenia ich modelu.
Przeanalizowano przykładowy XLSX Evotech; inne cenniki mają być obsługiwane
przez wybór arkusza, wiersza nagłówków i mapowanie kolumn. W próbce wykryto
powtarzające się SKU oraz brak kodu; właściciel zaakceptował jawne
wykluczanie konfliktowych wierszy w podglądzie, bez scalania i nadpisywania.
Wykluczone pozycje mają pozostać na osobnej liście „Do poprawy”, dostępnej
po restarcie, z powodem błędu i możliwością korekty oraz późniejszego dodania
lub jawnego powiązania z istniejącym Produktem. Nie są kategorią asortymentu
ani gotowymi Produktami; ponowna walidacja obowiązuje przed zatwierdzeniem.
Dopasowanie do motocykla pozostaje opcjonalne: katalog obejmuje też produkty
uniwersalne i niezwiązane z motocyklami.
Dowody i proponowane mapowanie: [analiza przykładu](docs/ANALIZA_IMPORTU_EVOTECH.md).
Minimalny zakres wdrożono w 0.5 (ADR-027); [scenariusz ADR-026](docs/adr/ADR-026-import-paczki-produktow-propozycja.md).

## Przyszły przyrost — dokumenty Subiekt → Allegro

WYMAGANIE właściciela, 2026-11-02: po wydrukowaniu faktury lub paragonu
w Subiekcie VexLab automatycznie przekazuje dokument do właściwego zamówienia
Allegro. W tym zakresie działa jako łącznik, bez trwałego archiwum dokumentów
i danych nabywców. Funkcja jest zaplanowana, nie jest wdrożona.

Zakres etapów 8–9; termin i kolejność względem pozostałych integracji otwarte.
Przed realizacją sprawdzić mechanizm wykrywania wydruku w Subiekcie, API
Allegro dla obu rodzajów dokumentów, formaty, autoryzację, powiązanie
zamówienia i konta oraz ewentualne licencje. Uzgodnić ponowienia bez
duplikatów i zachowanie po restarcie przy wymaganiu braku przechowywania.
Minimalne metadane techniczne i pliki tymczasowe nie są domyślnie dozwolone.

Odbiór: poprawny dokument we właściwym zamówieniu, potwierdzone przekazanie,
obsługa ponownego wydruku, awarii i nieznanego wyniku oraz kontrola braku
pozostawionej treści dokumentów. Istniejący lokalny katalog pozostaje bez zmian.
Szczegóły i otwarte decyzje: [ADR-025](docs/adr/ADR-025-dokumenty-subiekt-allegro.md).

## Wymaganie integracyjne — dopasowania do motocykli

Lokalnie wybrane dopasowania do motocykli muszą być dostępne do przekazania
do PrestaShop i Allegro, z mapowaniem właściwym dla kanału i podglądem
ograniczeń przed publikacją. Nie ograniczać ich do lokalnego filtra.
Przed wdrożeniem uzgodnić model dopasowań i sprawdzić możliwości API oraz
konfiguracji sklepu. Produkty uniwersalne i niezwiązane z motocyklami
nie wymagają wskazania pojazdu. Brak wsparcia nie może powodować cichej
utraty informacji. Szczegóły: [ADR-023](docs/adr/ADR-023-przyszle-integracje.md).
Funkcja niewdrożona.

## PrestaShop — wybór kategorii z docelowego sklepu

Decyzja właściciela, 2026-11-02: przy wysyłaniu ofert pobierać kategorie
z wybranego sklepu PrestaShop i umożliwić wskazanie kategorii docelowej
z podglądem przed wysłaniem. Uwzględnić kategorie motocykli, produktów
uniwersalnych i pozostałego asortymentu. Kategoria sklepu pozostaje odrębna
od dopasowania Produktu do motocykla, przekazywanego także do Allegro.
Identyfikatory kategorii są właściwe dla sklepu, nie dla wspólnego katalogu.
Weryfikacja API, uprawnień i nieaktualnych kategorii należy do przyszłego
przyrostu integracyjnego. Pobieranie nie upoważnia do zmiany drzewa sklepu.
Szczegóły: [ADR-023](docs/adr/ADR-023-przyszle-integracje.md). Niewdrożone.

## Przyrost 0.5 — lokalny import i Do poprawy

Wdrożono XLSX/CSV UTF-8, jawne mapowanie kolumn i producenta, podgląd,
atomowy zapis wybranych Produktów i odłożenie pozostałych do trwałej listy.
Działa późniejsza korekta/dodanie oraz przypisanie zgodnego SKU do Produktu
bez nadpisania danych. Schemat 3 z kopią przed migracją.
Nie jest to pełny import cen ani dopasowań do motocykli. Kategorie PrestaShop,
Allegro, kurierzy i dokumenty Subiekta nadal przyszłe.
Raport: [0.5](docs/RAPORT_PRZYROST_0_5.md).

## Kolejne źródła katalogu — API dostawców i producentów

Wymaganie właściciela: połączenia z API magazynów dostawców/producentów
w celu pobierania ich baz produktów do wspólnego lokalnego katalogu.
Najpierw wybrać jednego partnera i sprawdzić jego dokumentację, zakres
danych, autoryzację, limity i koszty. Potem wdrożyć konkretny konektor,
mapowanie, paginację, podgląd, raport oraz obsługę pozycji Do poprawy.
Ceny i stany magazynowe wymagają osobnego ustalenia zasad synchronizacji.
Nie utożsamiać dostawcy z producentem ani kodów różnych partnerów ze wspólnym
SKU bez jawnego mapowania. Właściciel potwierdził odłożenie tej możliwości na przyszłość, bez wybranego
partnera. Funkcja niewdrożona; nie blokuje importu plików.
Szczegóły: [ADR-028](docs/adr/ADR-028-katalogi-api-dostawcow-i-producentow.md).

## Przyrost 0.5.2 i dalsze przygotowanie danych

Wdrożono opis z kilku pól, opcjonalne dołączenie pełnej nazwy źródłowej
(z modelem/rocznikami, jeśli podane) oraz podgląd opisu przed zapisem.
Bez zgadywania dopasowań i bez zmiany już dodanych Produktów.
Kolejny zakres: sugerowane ceny sprzedaży z walutą źródłową GBP/EUR/PLN
i netto/brutto, bez automatycznej zmiany cen Oferty. Model cennika i reguły
przeliczenia pozostają do przygotowania. Tłumaczenie nazw na polski z
podglądem: wskazano OpenAI API, lecz po wyjaśnieniu opłat nie uzgodniono
budżetu — płatne podłączenie wstrzymane. Nie wykonano wywołań.
Szczegóły: [ADR-029](docs/adr/ADR-029-opis-waluty-i-tlumaczenie.md).

## Przyrost 0.6 — ceny źródłowe, operacje na katalogu i pojedyncze zdjęcia

Wdrożono sugerowane ceny sprzedaży w walucie źródłowej z netto/brutto,
podgląd i uzupełnianie ich braków po SKU bez kasowania istniejących danych.
Wielokrotny wybór/Ctrl+A, usuwanie wybranych lub wyników filtra z potwierdzeniem
i kopią oraz masowa zmiana producenta/opisu z kontrolą wersji i kopią.
Działa też pełniejszy opis z pól źródłowych. Szczegóły: ADR-029/030.

Adres Producenta jest opcjonalną daną użytkownika. Pierwszy scenariusz mediów:
pobranie kandydatów po dokładnym SKU z publicznego katalogu Shopify, podgląd
i wybór w formularzu pojedynczego Produktu, atomowy zapis i miniatura.
Bez zaszytej domeny. Próba rzeczywistej witryny online/Windows pozostaje
do odbioru. Masowe pobieranie zdjęć w imporcie nadal przyszłe. ADR-031.

Schemat 4 z kopią. Nie wdrożono przeliczania walut/VAT, cen Ofert, modelu
dopasowań, publikacji, katalogów partnerów API ani płatnego tłumaczenia.
Przyrost nie zamyka całych etapów roadmapy. Raport: docs/RAPORT_PRZYROST_0_6.md.

## Poprawka 0.6.1 — 2026-11-03

Usunięto blokowanie GUI podczas odtwarzania dużego zaznaczenia po edycji
masowej: wybór przywracany zbiorczo po ID, licznik bez budowania DTO całej
selekcji. Formularz pokazuje stan zapisu. Test scenariusza 2375 Produktów
i nieprzyległych wierszy po sortowaniu. Bez zmiany domeny, zależności
lub schematu 4. Raport: [0.6.1](docs/POPRAWKA_RESPONSYWNOSCI_0_6_1.md).


## Przyrost 0.7 — lokalna galeria — 2026-11-03

Wdrożono dodawanie plików JPG/PNG/WebP do istniejącego Produktu, podgląd,
zmianę kolejności i usuwanie. Pierwsze zdjęcie jest miniaturą. Zmiany robocze
wymagają zapisu; zapis w tle, z kopią i kontrolą wersji, bez migracji.
Menu Zdjęcia i media prowadzi do wyboru Produktu w katalogu. ADR-032.
Masowe pobieranie po SKU i odbiór rzeczywistej witryny pozostają otwarte.
Właściciel potwierdził działanie 0.6.1 na Windows; odbiór 0.7 jeszcze otwarty.
Pozostałe integracje i nieuzgodniony model dopasowań pozostają przyszłym zakresem.


## Poprawka 0.7.1 — osobny widok mediów

Na zgłoszenie właściciela z 2026-11-03 rozdzielono strony Produkty i Zdjęcia
i media. W mediach wybór jednego produktu, miniatury, filtry i otwieranie
galerii (także Enter/dwuklik). Bez operacji usuwania Produktów i importu.
Schemat, domena i zależności bez zmian.


## Potwierdzenie 0.7.1 i kolejny krok — 2026-11-03

Właściciel potwierdził działanie 0.7.1 i polecił kontynuację roadmapy.
Przygotowano konkretną propozycję opcjonalnych dopasowań Produktu do
wielu motocykli (ADR-033), z przykładami produktów uniwersalnych oraz
pozostałego asortymentu. Pola i liczność wymagają decyzji właściciela
według ADR-023 i AGENTS §3; bez zmiany schematu lub kodu do czasu decyzji.


## Przyrost 0.8 — zaakceptowane dopasowania motocykli

2026-11-03 właściciel zaakceptował propozycję ADR-033 odpowiedzią „tak”.
Wdrożono opcjonalną listę zero–wiele dopasowań Produktu, edytor i podgląd,
walidację marki/modelu/roczników/duplikatów oraz atomowy zapis z Produktem.
Strukturalne DTO jest niezależne od platform; brak dopasowań dozwolony
również dla uniwersalnego i pozostałego asortymentu. Bez domyślnych słowników.
Migracja 4→5 z kopią; starsze dane zachowane. Dotychczasowa edycja masowa,
import cen i zarządzanie zdjęciami zachowują listę dopasowań.
Mapowanie do API Allegro/PrestaShop, pobieranie kategorii i automatyczne
wydobywanie dopasowań z importu pozostają kolejnymi pracami, nie są wdrożone.
Raport: [0.8](docs/PRZYROST_0_8.md).


## Przyrost 0.9 — import dopasowań

Po potwierdzeniu działania 0.8 przez właściciela wdrożono jawny wybór kolumn
marki/modelu/roczników/wariantu przy imporcie XLSX/CSV. Podgląd dopasowań,
walidacja i trwałe surowe dane w Do poprawy; korekta i ponowne dodanie.
Jeden wiersz → jedno dopasowanie; puste pola dozwolone, bez zgadywania
z nazw i automatycznego scalania SKU. Model ADR-033 bez zmian.
Schemat 6 z kopią, istniejące dopasowania Produktów zachowane. ADR-034.
Publikacja, mapowania API, kategorie PrestaShop i analiza tytułów pozostają
przyszłe. Raport: [0.9](docs/PRZYROST_0_9.md).


## Obowiązkowy audyt przy wersji 1.0 — wymaganie właściciela

2026-11-03 właściciel wymaga szczegółowego audytu technicznego i audytu
z perspektywy użytkownika: czy interfejs jest przyjazny i intuicyjny.
Zaplanowano jako punkt kontrolny kandydata 1.0, z raportami, listą napraw
oraz ponownym sprawdzeniem. Nie jest wykonany i nie zastępują go testy
przyrostów. Plan: [audyt 1.0](docs/AUDYT_1_0_PLAN.md).
Numer 0.9 nie oznacza automatycznego przejścia do 1.0; możliwe kolejne 0.x.
Zakres biznesowy 1.0 i data pozostają nieustalone.

## Kolejny obszar B — lokalne szkice Ofert

Przygotowano [ADR-035](docs/adr/ADR-035-lokalne-szkice-ofert-propozycja.md):
jeden istniejący Produkt na szkic, wiele szkiców tego samego Produktu,
własny tytuł/opis, początkowo bez konta i publikacji. Status PROPOZYCJA,
nie wdrożono modelu ani migracji. Liczność i własność prezentacji wymagają
decyzji według AGENTS §3 i otwartych punktów modelu Oferty.


## Poprawka 0.9.1 — odrębny widok Masowej edycji

Zgłoszenie właściciela 2026-11-03: Masowa edycja dublowała ekran Produktów.
Usunięto alias; osobny wybór produktów, licznik, filtry, zaznaczanie wyników
oraz akcja wspólnej zmiany producenta/opisu. Bez dodawania, importu i usuwania
Produktów na tej stronie. Wyszukiwanie pozostaje w obszarze pracy.
Proces zapisu, kopia i kontrola wersji wspólne ze skrótem w Produkty;
zaznaczenia osobne. Bez migracji lub nowych reguł domeny.
Propozycja lokalnych szkiców ADR-035 nadal czeka na decyzję; bieżące zgłoszenie
jej nie zatwierdza. Audyt 1.0 nadal obowiązkowy i zaplanowany.
Raport: [0.9.1](docs/POPRAWKA_0_9_1.md).


## Wymaganie: import paczek gotowych ofert ZIP

2026-11-03 właściciel wymaga importu już gotowych ofert, oprócz produktów
z cennika, i wskazał ZIP jako format paczki. Zachowanie gotowej treści
i powiązanych zdjęć zależnie od rzeczywistej zawartości; osobny podgląd
i zatwierdzenie. Najpierw analiza małej reprezentatywnej paczki, potem
kontrakt, mapowanie i model zapisu. Nie zgadywać struktury ZIP ani SKU.
Samo dodanie paczki nie publikuje ofert. Funkcja niewdrożona.
Szczegóły: [ADR-036](docs/adr/ADR-036-paczki-gotowych-ofert-zip.md).


## Analiza paczki Evotech i konfiguracja użytkownika

2026-11-03 otrzymano przykład ZIP: 200 gotowych ofert i 51 pozycji odłożonych.
Przeanalizowano JSON/CSV, zgodność SKU i sekcji; zdjęcia są linkami.
Właściciel wymaga różnych ustawień producentów jako danych użytkownika,
bez zaszycia układu w kodzie. Oddzielić profil odczytu, zachowany układ
każdej oferty i ustawienia publikacji konta. Import nadal niewdrożony.
[Analiza](docs/ANALIZA_PACZKI_OFERT_EVOTECH.md), ADR-036.


## Doprecyzowanie celu ZIP → Allegro i przyrost 0.10

Właściciel wymaga pełnego procesu wysyłki gotowych ofert z ZIP do Allegro,
z wymaganymi ustawieniami pobieranymi/dobieranymi przez program i API.
Należy odczytać rzeczywiste wymagania kategorii i ustawienia konta, dobrać
według profilu użytkownika, sprawdzić braki i raportować wysyłkę. Sam podgląd
nie kończy tego wymagania. Bez domyślnych ustawień producentów w kodzie.

Wdrożono pierwszy etap 0.10 (ADR-037): osobna strona Nowe oferty, odczyt ZIP,
mapowanie listy rekordów JSON i struktury sekcji, podgląd oraz profile JSON
jako dane użytkownika. Brak zapisu Ofert i publikacji; schemat 6 bez zmian.
Test rzeczywistej przykładowej paczki: 200 ofert, 800 sekcji, 335 linków zdjęć.
CSV z 51 odłożonymi pozycjami na razie widoczny w inwentarzu, bez importu.

Równolegle wdrożono jawne polecenie właściciela: logo VexLabs bez białego
tła i paleta zgodna z nim, przy zachowaniu kompozycji UI-REF-01.
Nazwa programu i katalog danych VexLab pozostają zachowane.
Raport: [0.10](docs/PRZYROST_0_10.md). Audyt 1.0 nadal zaplanowany, niewykonany.


## Przyrost 0.10.1 — gotowy ZIP i lokalny katalog

Na zgłoszenie właściciela uproszczono główny proces: profil odczytu
jest danymi wewnątrz ZIP, jeden profil uruchamia podgląd automatycznie.
Wiele profili → wybór z listy, błąd profilu → jawny komunikat. Brak
ręcznego mapowania przy gotowej paczce. Autor może użyć konfiguracji
zaawansowanej; producent i nazwy źródeł nadal nie są wbudowane.

Na dodatkowe polecenie właściciela paczka może tworzyć Produkty w lokalnej
bazie jednym przyciskiem po podglądzie. Zachowanie istniejących SKU,
walidacja nowych, błędne do trwałego Do poprawy. Pola: SKU, nazwa,
tekst opisu i opcjonalny producent; bez domyślnego kopiowania ceny Oferty,
EAN, tekstowych dopasowań i zdalnych obrazów do Produktu. Schemat 6 bez zmian.
Przygotowano oddzielny gotowy ZIP Evotech z profilem (nie seed programu).
Wysyłka z ustawieniami API Allegro nadal do wdrożenia; nie uznano jej
za wykonaną na podstawie odczytu i lokalnego importu.
[Raport](docs/POPRAWKA_0_10_1.md). Audyt 1.0 nadal zaplanowany.


## Przyrost 0.11 — zapamiętane układy i modernizacja UI

Zgoda właściciela na zapamiętywanie profili wdrożona: raz wskazany układ
jest ustawieniem użytkownika, kolejne ZIP-y rozpoznawane po strukturze,
również po restarcie. Niejednoznaczność → wybór z listy, zmiana struktury
→ jednorazowe wskazanie profilu. Edytor mapowania wyłącznie zaawansowany,
poza głównym przebiegiem. Brak seedów i zależności od producenta. ADR-038.

Na polecenie właściciela odświeżono kontrolki, typografię, menu i stany
interakcji, zachowując kompozycję i kolorystykę logo. Oba motywy,
bez wymiany stosu UI. Schemat 6 bez zmian. Raport: [0.11](docs/PRZYROST_0_11.md).

## Uzgodnione porównania cen — do wdrożenia integracyjnego

Właściciel wybrał aktualny cennik producenta jako źródło kolumny Cena.
Allegro/PrestaShop mają pokazywać ceny pobrane z ich API dla właściwego
konta/oferty. Równa lub wyższa od bazowej zielona, niższa czerwona;
brak/stare/nieporównywalne dane neutralne i czas ostatniego odczytu.
Bez cichego mieszania walut/netto/brutto lub wyboru spośród kilku kont.
Wymaga rzeczywistych odczytów i kontraktów, nie jest wdrożone w 0.11.
Szczegóły: [ADR-039](docs/adr/ADR-039-ceny-bazowe-i-kanalow.md).

## Następny proponowany przyrost 0.12 — trwałe szkice z paczek

2026-11-04 po potwierdzeniu działania 0.11 przygotowano rozszerzenie
[ADR-035](docs/adr/ADR-035-lokalne-szkice-ofert-propozycja.md): gotowy ZIP
→ podsumowanie → lokalne Produkty i zachowane szkice → osobna lista po
restarcie. Zachowanie HTML, sekcji i galerii; bez nadpisywania Produktów,
bez duplikatu po ponowieniu i bez publikacji. Nowe relacje, usuwanie
powiązanych Produktów i migracja 6→7 pozostają propozycją do decyzji
właściciela. Kod i baza nie zostały zmienione na podstawie samego planu.


## Przyrost 0.12 — trwałe lokalne szkice z ZIP

2026-11-05 właściciel zatwierdził ADR-035 w zakresie gotowych paczek,
relację Produkt 1 → wiele szkiców i doprecyzował przyszłą wysyłkę do
**szkiców Allegro**, z osobną publikacją. Wdrożono atomowy zapis
brakujących Produktów i ofert, zachowanie układu i danych źródłowych,
pominięcie identycznych ofert, osobny widok Szkice, wyszukiwanie,
podgląd, edycję tytułu/opisu i usuwanie. Schemat 7 z kopią; stare migracje
bez zmian. Dane i konfiguracje wyłącznie użytkownika, bez seedów.
Wysyłka do Allegro, odczyt wymagań API i ceny kanałów pozostają niewdrożone.
Raport: [0.12](docs/PRZYROST_0_12.md). Audyt 1.0 nadal zaplanowany.


## Przyrost 0.13 — wizualna edycja szkicu

2026-11-05 właściciel zlecił opis z formatowaniem i przeciąganie sekcji.
ADR-040: edytor wizualny, układy tekst/obraz, kolejność przeciąganiem lub
strzałkami, formatowanie, podgląd, atomowy zapis sekcji i pełnego opisu.
Dane użytkownika, schemat 7 bez migracji. Bez sieciowych miniatur w edytorze.
Integracja wysyłki do szkiców Allegro pozostaje przyszłym etapem.
Raport: [0.13](docs/PRZYROST_0_13.md). Audyt 1.0 nadal zaplanowany.


## Poprawka 0.13.1 — usuwanie wielu szkiców

Na polecenie właściciela z 2026-11-05 dodano wielokrotny wybór, zaznaczanie
wszystkich wyników, licznik, usuwanie zaznaczonych i wyników filtra.
Z potwierdzeniem i kopią, atomowo z kontrolą wersji, bez usuwania Produktów.
Schemat 7 i zakres integracji bez zmian. [Raport](docs/POPRAWKA_0_13_1.md).


## Przyrost 0.14 — wygląd Windows 11

Na polecenie właściciela z 2026-11-05 wdrożono nowy wspólny styl jasny/
ciemny inspirowany Windows 11, z zachowaniem układu, menu i funkcji.
Kolorystyka/logo marki zachowane. Bez zmian modeli, danych, bazy lub
integracji; schemat 7 bez migracji. [Raport](docs/PRZYROST_0_14.md).


## Poprawka 0.14.1 — kolorowe ikony menu

Na polecenie właściciela z 2026-11-05 dodano kolorowe symbole funkcji
oraz znaki Allegro i PrestaShop. Palety obu motywów, zasoby offline,
bez zmiany nazw, kolejności lub działania. Schemat 7 bez migracji.
[Raport](docs/POPRAWKA_0_14_1.md).


## Przyrost 0.15 — porządek w akcjach Produktów

Polecenie właściciela z 2026-11-05: skrócić pasek wielu przycisków i dodać
menu pod prawym przyciskiem myszy. Wdrożono Więcej akcji, wspólne akcje
kontekstowe, właściwy wybór celu i obsługę klawiatury. Funkcje oraz baza
bez zmian; schemat 7. [Raport](docs/PRZYROST_0_15.md).


## Poprawka 0.15.1 — krótsze nazwy

Polecenie właściciela z 2026-11-05: skrócić etykiety menu Produktów.
Wyłącznie tekst i dymki, zachowane operacje i zabezpieczenia. Schemat 7.
[Raport](docs/POPRAWKA_0_15_1.md).


Przyrost 0.16 — polecenia właściciela 2026-11-05: Cenniki mają własną
bibliotekę dokumentów z nazwą, producentem, rokiem i wydaniem. Zapis źródła
nie tworzy Produktów; wybrane pozycje dodawane z PPM → Dodaj do katalogu.
Usuwanie dokumentów po potwierdzeniu i kopii pozostawia Produkty. Schemat 8,
zachować definicje i sumy migracji 1–7 (ADR-041). Z Produktów usunięto
przycisk importu kierujący do Cenników. Zdjęcia HTTPS w edytorze szkicu oraz
podgląd całej oferty z układem sekcji, przez port i odczyt w tle (ADR-042).
To zastępuje wcześniejsze ograniczenie braku pobierania obrazów w edytorze;
pozostały HTML nadal nie pobiera zasobów. Bez udawania integracji Allegro.
Raport docs/PRZYROST_0_16.md.


Przyrost 0.17 — właściciel 2026-11-06 zaakceptował pięć usprawnień Cenników
(ADR-043): podgląd obok listy, statusy Nowy / W katalogu / Inna cena /
Do poprawy, porównanie ceny z zapisaną ceną bazową w Decimal i ustawienie
Aktualny/Archiwalny per producent. Trzy główne akcje i menu/PPM. Ustawienie
nie nadpisuje cen Produktów; nie zgadywać walut/VAT, bez producenta brak
aktualnego cennika. Schemat 9 z kopią, zachować migracje 1–8 i ich sumy.
Szczegóły i ograniczenia: docs/PRZYROST_0_17.md.


Poprawka 0.17.1 (ADR-044), zgłoszenie właściciela 2026-11-06: jawny
wariant usuwania Produktów z powiązanymi lokalnymi szkicami po dodatkowym
potwierdzeniu ich liczby, domyślnie Nie. Domyślna blokada pozostaje;
rozszerzony zapis tylko po drugim potwierdzeniu, w jednej transakcji
z kontrolą ID/wersji szkiców i Produktów oraz kopią. Bez operacji w
kanałach sprzedaży. Wyraźne ostrzeżenie przy błędzie. Schemat 9 bez migracji.
Raport docs/POPRAWKA_0_17_1.md.

## Kierunek po poprawce 0.17.1 — katalog odczytywany z Subiekta

WYMAGANIE właściciela 2026-11-06, podczas poprawki usuwania: docelowym
źródłem katalogu ma być Subiekt, wyłącznie do odczytu. Import paczki ofert
nie może tworzyć kartotek w Subiekcie ani dopisywać Produktów do katalogu.
Dotychczasowe lokalne szkice i przyszłe oferty wymagają rozdzielenia od
procesu zakładania lokalnych Produktów. To osobny przyszły etap, nie zmiana
wdrożona w 0.17.1. Nie uruchamiać zapisów ani usuwania w Subiekcie.

Właściciel wskazał obawę o zużycie dysku. Plan techniczny do dopracowania
przy wdrożeniu: odczyt stronicowany, zdjęcia na żądanie, ograniczony i
czyszczony cache; limity i retencja kopii zamiast nieograniczonego gromadzenia
pełnych baz i mediów. Same tekstowe kartoteki zwykle zajmują znacznie mniej
niż obrazy/załączniki i kopie. Dokładne limity nie zostały ustalone.

Przed implementacją opisać w ADR właściciela pól, powiązanie Oferty z
zewnętrznym Produktem lub brak dopasowania, identyfikację SKU/ID, odświeżanie,
tryb offline i migrację dotychczasowych danych. Nie usuwać ich automatycznie.
Obecny model szkicu wymaga lokalnego Produktu; trzeba go jawnie zmienić,
a nie tworzyć fikcyjnych kartotek dla obejścia ograniczenia. Bez zapisu tej
spornej relacji w schemacie do czasu zaprojektowania nowego procesu.


Przyrost 0.18 (ADR-045), polecenie właściciela 2026-11-06: opcjonalny
EAN-8/EAN-13 w mapowaniu i zapisanym cenniku, Do poprawy, formularzu
Produktu, szczegółach i eksporcie CSV. Tekst, zachowane zera, kontrola
cyfry kontrolnej, bez generowania i unikalności EAN; SKU nadal kluczem.
Schemat 10 z kopią, zachować migracje 1–9. Brak EAN jest poprawny.
Przyszły odczyt katalogu z Subiekta i rozdzielenie ZIP pozostają osobnym
etapem bez zapisów w Subiekcie. Raport docs/PRZYROST_0_18.md.


PROPOZYCJA z rozmowy 2026-11-06 — automatyzacja różnych cenników: lokalne
profile mapowania zapisywane jako dane użytkownika. Pierwszy import
proponuje arkusz/nagłówki/kolumny i pokazuje próbkę do zatwierdzenia; kolejne
pliki zgodnego układu używają profilu do podglądu. Jeden producent może
mieć kilka układów, rozpoznawanie po strukturze zamiast samej nazwie pliku
lub producenta. Zmiana struktury/niejednoznaczność wymaga przeglądu. Waluta
i netto/brutto jawnie zatwierdzone. Główny ekran plik/producent/rok/podgląd,
mapowanie w Ustawieniach importu. Bez płatnego AI w podstawowej obsłudze.
W 0.18 był to zapis propozycji, bez implementacji. Kontynuację po 0.18
opisuje przyrost 0.19 i ADR-047 poniżej.

## WYMAGANIE 2026-11-06 — podgląd i edycja rzeczywistych szkiców Allegro

Właściciel chce w zakładce Szkice widzieć szkice znajdujące się na wybranym
koncie Allegro i edytować je w VexLab, bez przechodzenia na stronę Allegro.
Etap integracji API: uwierzytelnienie właściwego konta, stronicowany odczyt
szkiców, podgląd zdjęć i rzeczywistej treści, edycja obsługiwanych przez API
pól oraz jawny zapis zmian do wskazanego szkicu. Dokładny zakres pól i
formatów potwierdzić w aktualnej dokumentacji API podczas wdrożenia.

Rozróżnić lokalne szkice i szkice na Allegro, z identyfikatorem konta/oferty,
stanem odświeżenia i niezapisanymi zmianami. Obsłużyć konflikty równoczesnej
edycji, błędy/limity, wygaśnięcie autoryzacji i nieznany wynik zapisu, bez
ślepego ponawiania tworzenia ofert. Zapis edycji szkicu nie uruchamia sprzedaży;
publikacja wymaga osobnego działania. Brak zaszytych kont lub ustawień
producentów. Bez zakładania Produktów w Subiekcie lub katalogu z importu ZIP.
Funkcja zaplanowana, nie wdrożona w przyroście 0.18.

## WYMAGANIE 2026-11-06 — wspólna obsługa zamówień Allegro i PrestaShop

Właściciel wskazał wzorzec rozwijanego menu Zamówienia z licznikami.
Zaplanować wspólną listę zamówień pobieranych przez API Allegro i PrestaShop,
z filtrem kanału i konta/sklepu oraz rozwijanymi widokami: Do zrobienia,
Wszystkie, Po terminie, Nowe, Indywidualne, W realizacji, Wysłane, Zwroty
i Anulowane. Liczniki mają wynikać z rzeczywistych danych dla wybranego
zakresu; pokazywać aktualność odczytu i błędy synchronizacji. Nie kopiować
liczb demonstracyjnych ze zrzutu. Zachować dotychczasowy układ aplikacji.

Doprecyzowanie właściciela: zapewnić wyraźny podział na widoki Wszystkie
kanały, Allegro i PrestaShop oraz możliwość filtrowania według kanału.
Filtry statusu i konta/sklepu działają łącznie z wybranym kanałem, a liczniki
odnoszą się do tego samego zakresu co wyświetlana lista zamówień.

Kliknięcie widoku filtruje listę; szczegóły zamówienia pokazują kanał,
numer zamówienia, pozycje, płatność, dostawę i status dostępny przez API.
Oddzielić status płatności, realizacji i zwrotu. Nie utożsamiać automatycznie
statusów obu platform; mapowania do wspólnych widoków oraz własne statusy
przechowywać jako ustawienia użytkownika. Znaczenie widoku Indywidualne
i reguły terminu wymagają doprecyzowania przed implementacją, bez zgadywania.

Etap integracji zamówień: najpierw odczyt, filtrowanie, szczegóły i liczniki,
następnie uzgodnione operacje obsługi zamówienia zgodne z możliwościami API.
Przycisk Nowe zamówienie z obrazu jest inspiracją; ręczne tworzenie zamówień
i jego skutki w kanałach wymagają osobnego ustalenia. Uwzględnić stronicowanie,
identyfikację po kanale/koncie/ID, brak duplikatów po ponowieniu i ochronę
danych klientów. Model i granice transakcji opisać przed zmianą schematu.
Funkcja zaplanowana, niewdrożona; nie rozszerza bieżącego przyrostu 0.18.

## Przyrost 0.18 — rozszerzenie poprawek na polecenie właściciela

Wdrożenie lokalne opisuje docs/PRZYROST_0_18.md i ADR-046: aktualizacja
cenników z historią, bazowa z wybranego cennika, jawne statusy i przyczyny,
reset kreatora, precyzja ceny XLSX, własne szybkie akcje i seryjne zdjęcia
zaznaczenia z własnego źródła Shopify. Raport audytu technicznego:
docs/AUDYT_TECHNICZNY_0_18.md. Odbiór Windows i Evotech na żywo otwarty.
Integracje zamówień i szkiców Allegro pozostają przyszłym etapem.

## Przyrost 0.19 — rozpoznawanie układów cenników

Kontynuacja 2026-11-06 po poleceniu „działaj dalej”: lokalne profile
mapowania i propozycje dla nowych układów (ADR-047). Pełne mapowanie/próbka
w rozwijanych Ustawieniach importu; producent zawsze widoczny. Jeden znany
układ uruchamia podgląd, kilka dopasowań wymaga wyboru. Osobny zapis profilu
użytkownika, cennika i Produktów; bez płatnego AI i migracji schematu 10.
Zakres i ograniczenia: docs/PRZYROST_0_19.md. Integracje pozostają przyszłe.

## Przyrost 0.20 — ZIP szkiców bez tworzenia kartotek

Kontynuacja po 0.19 realizuje wcześniejszy kierunek właściciela: paczki ofert
zapisują samodzielne szkice bez zakładania Produktów. Dawne dane i powiązania
zachowane. Schemat 11 z kopią; migracje 1–10 niezmienione. ADR-048 i raport
docs/PRZYROST_0_20.md. Nie wdraża połączeń z kanałami ani Subiektem.

2026-11-06 właściciel potwierdził **Subiekt GT** (odpowiedź na pytanie o wersję).
Przyszły katalog jest wyłącznie do odczytu. Plan przygotowania konektora:
docs/SUBIEKT_GT_ODCZYT_PLAN.md. Mechanizm dostępu i bezpieczne przechowywanie
sekretów wymagają przygotowania; nie zgadywać instalacji, licencji ani danych
logowania. Import paczki nigdy nie uruchamia zakładania kartotek w GT.

## Poprawka 0.20.1 — belki nawigacji

Na polecenie właściciela grupy Produkty, Oferty, Sprzedaż, Analityka i Narzędzia
rozwijają się po kliknięciu. Zachowane nazwy/kolejność/ikony i globalne zwijanie.
Stan grup zapisany jako ustawienie użytkownika, bez migracji schematu 11.
Raport docs/POPRAWKA_0_20_1.md. Dalsze etapy integracji pozostają bez zmian.

Dodatkowo w 0.20.1: zgodnie z poleceniem właściciela podgląd oferty ZIP
oraz podgląd zapisanego szkicu pokazują galerię i obrazy sekcji przez wspólny
mechanizm odczytu w tle. Zastępuje wcześniejszy widok samych adresów w tym
oknie. Brak automatycznego zapisu obrazów na dysku i zmian treści ofert.

## Poprawka 0.20.2 — kolory i zaokrąglenie menu

Na polecenie właściciela grupy menu otrzymały turkus/fiolet/złoto/niebieski/
lawendowy w obu motywach i większe zaokrąglenia. Zachowane działanie menu,
kolejność i ikony. Bez zmian danych lub schematu 11. Raport docs/POPRAWKA_0_20_2.md.

## Poprawka 0.20.3 — dopracowanie hierarchii menu

Po akceptacji właściciela: delikatniejsze zwinięte belki, mocniejsze
rozwinięte, większe odstępy i wyrównane marginesy. Responsywne szerokości
zabezpieczają zaokrąglenia przed wychodzeniem poza obszar menu. Raport
docs/POPRAWKA_0_20_3.md. Bez zmian funkcji i schematu 11.

## Poprawka 0.20.4 — pasek tytułu Windows

Na polecenie właściciela 2026-11-07: natywna ramka podąża za motywem
aplikacji. Windows 11 — kolory nagłówka; Windows 10 — ciemny wariant
systemowy, zależnie od obsługi DWM. Standardowe zachowanie okna zachowane.
Raport docs/POPRAWKA_0_20_4.md. Odbiór natywny Windows pozostaje otwarty.

## Przyrost 0.21 — miniatury na żądanie

Kontynuacja właściciela 2026-11-07: realizacja części planu ograniczania
zużycia zasobów przed dużym katalogiem GT. GUI pobiera tylko metadane zdjęć,
a BLOB miniatur wyłącznie dla widocznych produktów, w tle i z ograniczonym
cache w pamięci. Zaznaczanie, eksport i operacje masowe zachowane.
ADR-049 i docs/PRZYROST_0_21.md. Schemat 11 bez migracji.

**Pozostaje:** stronicowanie rekordów katalogu/cenników, przygotowanie
wspieranego dostępu do instalacji Subiekta GT tylko do odczytu, następnie
rzeczywiste konektory sprzedaży z autoryzacją i bezpiecznym magazynem
sekretów. Odczyt szkiców i zamówień wymaga tych konektorów. Retencja kopii
nadal nieustalona; nie usuwać ich automatycznie. Integracje niewdrożone.
Użytkownik potwierdził działanie poprawki paska tytułu 0.20.4 na swoim
komputerze; nie zastępuje to pełnej macierzy odbioru Windows.

## Przyrost 0.22 — stronicowanie katalogu

Kontynuacja właściciela 2026-11-07: rekordy przeglądanego katalogu pobierane
stronami z SQLite, bez ładowania pełnych opisów wszystkich Produktów przy
starcie. Globalne filtry/sortowanie, wielostronicowy wybór i pełny zakres
eksportu/usuwania zachowane. ADR-050 i docs/PRZYROST_0_22.md. Schemat 11.

**Pozostaje:** osobne stronicowanie pozycji Cenników, przygotowanie dostępu
do rzeczywistej instalacji Subiekta GT tylko do odczytu i konektory kanałów.
Nie wybrano jeszcze SQL/Sfery ani magazynu sekretów. Integracja GT i odczyt
zamówień/szkiców platform nadal niewdrożone. Retencja kopii nieustalona.

## Przyrost 0.23 — strony Cenników i ustalenie topologii GT

Kontynuacja 2026-11-07: pozycje Cenników mają strony i lekki indeks ocen.
Pełne dane odczytywane dla strony/wyboru; filtrowanie, duplikaty i ceny
obejmują cały dokument. Globalny wybór zachowany. Schemat 11, bez migracji.
ADR-051 i docs/PRZYROST_0_23.md.

Właściciel potwierdził **serwer z bazą danych i klient Subiekta GT na laptopie**.
Następny etap integracyjny: ustalić wspierany sposób dostępu, wersję/instancję
i autoryzację bez zbierania haseł w rozmowie. Zdalny konektor wyłącznie
do odczytu wymaga testu na rzeczywistej instalacji. Nie jest wdrożony.
Retencja kopii i integracje kanałów nadal pozostają w planie.


Przyrost 0.24 (2026-11-07): port OdczytKatalogu i serwis przeglądania
wydzielone od lokalnych komend. Ustawienia → Subiekt GT — przygotowanie
połączenia → Sprawdź środowisko / Kopiuj raport: ręczny odczyt lokalnych
metadanych Windows w tle. Nie testuje serwera, Sfery ani licencji.
Brak konektora GT, migracji i nowych zależności. Licencja Sfery nieustalona.
ADR-052 i docs/PRZYROST_0_24.md. Zachować dotychczasową edycję lokalną;
przyszłe źródło GT wymaga zewnętrznej tożsamości i blokady komend zapisu.


2026-11-08 — właściciel potwierdził brak Sfery, wskazał S2S e-mo, następnie
wybrał docelową integrację bez pośredników i odłożenie GT. Nie uznawać
wcześniejszej propozycji bezpośredniego SQL za ostateczny wybór mechanizmu.
Teraz priorytet Allegro; właściciel ma aplikację produkcyjną.
Przyrost 0.25/ADR-053: sesja Device Flow wyłącznie w pamięci, /me i lista
szkiców INACTIVE. Edycja/zapis zdalnych szkiców nadal kolejny krok, bez
publikacji. Nie utrwalać sekretów pod pretekstem zapamiętywania sesji.
Raport i instrukcja: docs/PRZYROST_0_25.md.


Przyrost 0.26 — polecenie właściciela 2026-11-08: konfiguracja Allegro
w Ustawienia → Integracje, z zapamiętaniem na Windows. Zastępuje zakaz
utrwalania z sesji 0.25 w tym jawnym zakresie. ADR-054: port MagazynAllegro,
DPAPI bieżącego użytkownika, wyłącznie szyfrogram, odnowienie tokenu oraz /me
przed sukcesem. Rozłącz i zapomnij usuwa zapis; zamknięcie go zachowuje.
Schemat 11 i zależności bez zmian. Raport docs/PRZYROST_0_26.md.
Allegro jest docelowym wspólnym obszarem wszystkich operacji kanału: nowe
zamówienia i ich obsługa, szkice, aktywne oferty, ceny/stany i dalsze działania
udostępniane przez API. Tylko konfiguracja konta jest w Ustawieniach. Nie
utożsamiać panelu Allegro z samą listą szkiców. Te przyszłe procesy i wspólna
filtracja zamówień po Allegro/PrestaShop wymagają kolejnych implementacji;
nie dodawać udawanych statystyk lub działań w tym przyroście.


Poprawka 0.26.1 — polecenie właściciela 2026-11-08: Ustawienia → Integracje
to wspólne miejsce konfiguracji Allegro, Subiekta GT i przyszłych integracji.
Osobne zakładki, zachowana diagnostyka i zapamiętywanie Allegro. Skrót
z Allegro wybiera jego zakładkę. GT nadal odłożony; nie dodawać fikcyjnych
połączeń. Schemat 11 i zależności bez zmian. docs/POPRAWKA_0_26_1.md.


Przyrost 0.27 — polecenie właściciela 2026-11-08: przyciski jak na nowym
screenie referencyjnym. Niebieskie główne akcje, ciemne pomocnicze, ikony,
zaokrąglenia i karty szybkich akcji z opisem. To zastępuje złote wypełnienie
przycisków; logo, układ i grupy menu zachowane. Nie kopiować liczb/kont
z demonstracji. Nie włączać niewdrożonych funkcji. Menu nowej oferty oraz
odczyt Allegro prowadzą wyłącznie do już zaimplementowanych procesów.
Schemat 11 bez zmian. Szczegóły docs/PRZYROST_0_27.md.


Przyrost 0.28 — właściciel 2026-11-08 zaakceptował podział Ustawień:
Ogólne / Integracje / Dane i kopie / O programie. W Integracjach lista usług
ze stanem i konfiguracja obok; Dane aplikacji Allegro zwijane, akcje zależne
od rzeczywistego stanu połączenia. Nie zastępować obszarów pracy ustawieniami
konta. GT i PrestaShop nadal w przygotowaniu. Kopia dotychczasowa, diagnostyka
istniejącym przypadkiem użycia. Schemat 11 i zależności bez zmian.
Szczegóły docs/PRZYROST_0_28.md.


Przyrost 0.29 — polecenie właściciela 2026-11-08: kafelki KPI mają mieć
pełne białe ikony na kolorowych polach 56 px oraz jasne niebieskie/zielone/
pomarańczowe/fioletowe tła jak na dostarczonym wycinku. Paleta PALETA_KPI,
komponent KafelekKPI, lokalne SVG z licencjami i atrybucją. Nie przywracać
samych cienkich ikon. Nie kopiować demonstracyjnych metryk/procentów.
Schemat 11 i zależności bez zmian. docs/PRZYROST_0_29.md.


Przyrost 0.30 (2026-11-08): pasek producentów wyłącznie z rejestru użytkownika, bez stałych marek; wyszukiwanie nazwa/SKU/EAN, filtry zdjęcia/ceny, lista i kafelki ze wspólnym wyborem oraz akcje wierszy. Schemat 11 bez zmian. Szczegóły: docs/PRZYROST_0_30.md.


Przyrost 0.31: podgląd rzeczywistego szkicu Allegro (tytuł, cena, galeria, opis) z listy INACTIVE. Bez zapisu i publikacji; edycja pozostaje kolejnym etapem. Schemat 11 bez zmian. [Raport](docs/PRZYROST_0_31.md), [ADR-055](docs/adr/ADR-055-podglad-szkicu-allegro.md).


Przyrost 0.33: ekran Allegro według referencji 2026-11-09 — nagłówek, KPI, zakładki, filtry, tabela i panel szczegółów. Odczyt INACTIVE działa; pozostałe stany, metryki i polecenia zapisu są jawnie niedostępne, bez danych demo. [Opis](docs/PRZYROST_0_33.md), [ADR-056](docs/adr/ADR-056-przestrzen-allegro.md).

### Dashboard 0.35 — wykonany układ, kolejne źródła

Wdrożono nową kompozycję według referencji, lokalne agregaty jakości, cache,
filtry i zapamiętywany układ sekcji. Dalsze kroki wymagają rzeczywistych,
ograniczonych odczytów: aktywne oferty, zamówienia Allegro/PrestaShop,
statystyki okresów, finansowe definicje marży, wspólny magazyn i progi,
rejestr operacji, synchronizacja/kolejka oraz AI/SMTP. Pełny zakres promptu
nie jest ukończony przez samą obecność sekcji. Szczegóły ADR-057 i raport 0.35.

### Przyrost 0.36 — odczyt stanów ofert i liczników Allegro

Wdrożono Wszystkie/ACTIVE/INACTIVE/ACTIVATING/ENDED w obecnym obszarze Allegro,
podgląd szczegółów i licznik ACTIVE na Dashboardzie. Odczyty w tle,
ograniczony cache i ochrona przed spóźnionymi wynikami. Schemat 11 bez zmian.
ADR-058 i docs/PRZYROST_0_36.md. Nie wdrożono zapisu ani publikacji.
Następny etap Allegro: przygotowanie edycji i jawnego zapisu szkicu z kontrolą
aktualności/konfliktów po potwierdzeniu kontraktu aktualnego API. Zamówienia
i ich statystyki wymagają kolejnego odczytu; Subiekt GT nadal odłożony.

### Przyrost 0.37 — przygotowanie edycji zdalnego szkicu

Wdrożono formularz propozycji tytułu/opisu INACTIVE, wspólny wizualny edytor,
lokalny zapis/odczyt pliku roboczego i ręczne sprawdzanie aktualności przez GET.
Zmiany użytkownika nie giną przy konflikcie, błędzie lub rozłączeniu.
**Zapis do Allegro nadal niewdrożony**: wymaga potwierdzenia bieżącego
kontraktu i warunków konfliktu, a developer.allegro.pl jest poza dozwoloną
siecią środowiska. Projekt dodania tej domeny zapisany, oczekuje przeglądu
oraz publikacji konfiguracji. Nie zgadywać obsługi If-Match/ETag ani uznawać
porównania dwóch GET za atomowe zabezpieczenie zapisu. Bez rozszerzenia
uprawnień i transportu mutacji. ADR-059 i docs/PRZYROST_0_37.md.


Przyrost 0.38 — kontynuacja roadmapy 2026-11-09: właściciel dostarczył
swagger.yaml, co zastępuje blokadę dokumentacji z 0.37. Potwierdzany PATCH
wyłącznie zmienionego tytułu/opisu INACTIVE, preflight z kontrolą kontekstu
oraz jawne ostrzeżenie o braku atomowego zapisu warunkowego. 200 wymaga
GET, 202 ręcznego sprawdzenia operacji/treści; bez automatycznych ponowień.
Trwały techniczny rejestr blokuje nieznany wynik po restarcie. Bez wymuszania
konfliktu, publikacji, zmian Produktów i migracji. Opcjonalna zgoda zapisu
wymaga offers:write i ponownego połączenia; stary odczyt zachowany.
ADR-060 i docs/PRZYROST_0_38.md. Dalsze etapy: inne pola i tworzenie szkiców,
zamówienia/metryki — osobne procesy, bez obchodzenia blokad tego zapisu.


## Przyrost 0.39 — ekran Allegro do oceny, 2026-11-10

Polecenie właściciela: spokojny, profesjonalny wzorzec najpierw tylko w Allegro,
z zachowaniem funkcji, logo i miniatur. Płaskie panele, spójna typografia,
odstępy i czytelniejsza tabela w obu motywach. Nieczynne przyszłe działania
zebrane w menu; nowego stylu nie przenosić na resztę bez oceny właściciela.
Zmiana zgody na zapis przez osobny Device Flow bez usuwania połączenia:
stara sesja/zapis zachowane do sukcesu, to samo konto/środowisko, obsługa
anulowania/odmowy. Schemat 11 i dane użytkownika bez zmian. Właściciel
potwierdził zapis tytułu/opisu w 0.38. Raport: docs/PRZYROST_0_39.md.
Następny etap: ZIP → nowe szkice Allegro, zdjęcia, walidacja i raport;
publikacja jako osobna potwierdzana akcja. W 0.39 niewdrożony.


Poprawka 0.39.1 — polecenie właściciela 2026-11-10: KPI Allegro mają
kolorystykę Dashboardu (granatowa baza i subtelna kolorowa poświata), zamiast
płaskich teł 0.39. Statusy tabeli i szczegółów: Aktywna zielona, Zakończona
czerwona, Szkic żółty; czytelne także po zaznaczeniu i w obu motywach.
Bez zmiany funkcji, układu, logo, miniatur, danych lub schematu 11.
Raport: docs/POPRAWKA_0_39_1.md.


## Przyrost 0.40 — nowe szkice Allegro z ZIP, 2026-11-12

Właściciel potwierdził 0.39.1 i zlecił kolejny etap. Wdrożono plan paczki,
dopasowanie istniejących produktów Katalogu Allegro, odczyt parametrów,
zdjęcia przez upload HTTPS i potwierdzane tworzenie wyłącznie INACTIVE.
Raport pozycji, bezpieczny CSV, anulowanie między żądaniami i trwały
rejestr zapobiegający ponawianiu nieznanych wyników. Produkty lokalne/GT
bez zmian; brak publikacji i tworzenia nowych kartotek Allegro.
Pierwszy zakres: obrazy podane linkami HTTPS, pojedyncze wartości parametrów;
warunkowe wymagania, dostawa i GPSR dodatkowo walidowane przez Allegro,
bez zgadywania ustawień. Nie utożsamiać INACTIVE z gotowością do sprzedaży.
Schemat 11, bez migracji i nowych zależności. ADR-061 i docs/PRZYROST_0_40.md.
Nie wykonywano testowych zapisów na koncie właściciela. Kolejny odbiór:
jedna rzeczywista pozycja i raport; rozszerzenie ustawień publikacji osobno.


## Poprawka 0.40.1 — rozpoznanie gotowych ofert, 2026-11-13

Właściciel dostarczył ZIP do reprodukcji nieznanego układu. Dodano jawny
kontrakt listy obiektów sku/title/html/images/sections, z opcjonalnymi
EAN/ceną/tekstem dopasowania. Bez reguł producenta lub nazw plików. Własne
profile nadrzędne, kilka zbiorów → wybór; błędy rekordów pozostają widoczne.
Rzeczywista paczka: 200 ofert, 800 sekcji, 201 zdjęć galerii; parser i GUI
sprawdzone na pustym katalogu profili, źródło bez zmian. Schemat 11.
Raport docs/POPRAWKA_0_40_1.md i ADR-062. Bez publikacji na Allegro.

Dalsze wymagania właściciela z rozmowy: Allegro jest całym obszarem obsługi
kanału — zamówienia i ich realizacja, oferty, rozliczenia oraz wnioski o zwrot
prowizji, zgodnie z API. Konfiguracja w Ustawienia → Integracje. Obowiązkowy
osobny formularz Allegro → Nowa oferta → Utwórz ręcznie, bez ZIP-a i bez
obowiązkowego lokalnego Produktu. Import ZIP jako druga ścieżka. Zapis szkicu
i osobno potwierdzana publikacja. Formularz ręczny i pozostałe nowe obszary
nie są wdrożone w 0.40.1; nie uznawać importera za całość modułu Allegro.


Poprawka 0.40.2 — pełny podgląd domyślnie z galerią i sekcjami oraz poprawne
podłączenie portu zdjęć bez zapisywania lokalnego szkicu. Oba motywy,
przewijanie długiej treści i maksymalizacja. Schemat 11, dane bez zmian.
Raport docs/POPRAWKA_0_40_2.md.
Właściciel zgłosił również nowe produkty nieobecne w Katalogu Allegro:
konieczna osobna ścieżka kategorii/parametrów i jawnego zgłoszenia produktu,
bez wymuszania dopasowania do cudzej kartoteki. To rozszerza wcześniejszy
zakres wyłącznie istniejących produktów; publikacja oferty nadal osobno.


Przyrost 0.41 — polecenie właściciela 2026-11-13 rozszerza dotychczasowy
zakres o nowe produkty nieobecne w Katalogu Allegro. Oddzielny, jawny tryb
kategorii/parametrów, wspólne szablony i źródła SKU/EAN. Jeden potwierdzany
POST definiuje produkt i szkic INACTIVE; potwierdzenie ujawnia skutek
katalogowy. GET oferty i produktu, trwała deduplikacja i blokada nieznanych
wyników. Bez publikacji sprzedaży, lokalnych Produktów/GT lub migracji.
ADR-063 i docs/PRZYROST_0_41.md. Formularz ręczny bez ZIP-a oraz zamówienia,
obsługa i zwroty prowizji pozostają wymaganym kolejnym zakresem.


Przyrost 0.42 — polecenia właściciela 2026-11-13: masowa edycja w oknie
przygotowania ZIP (wybór, tytuły/ceny/ilości, wspólne wybrane parametry),
automatyczne SKU/EAN z każdej pozycji oraz wyszukiwanie całego konta Allegro
przez API i lista Wszystkie. Źródłowe dane/ZIP i schemat 11 bez zmian.
Konto/środowisko i trwała blokada ponowień zachowane; publikacja osobno.
Wszystkie do 100 000 w pamięci, strony do kontraktowego offset+limit 10 mln,
bez cichego obcinania. ADR-064/065 i docs/PRZYROST_0_42.md. Nie zastępuje
ręcznego formularza bez ZIP-a ani przyszłej obsługi całego kanału Allegro.


Przyrost 0.43 — polecenia właściciela 2026-11-13: GPSR, dostawa/lokalizacja,
warunki i faktura w nowych szkicach, GET potwierdza zapis. sale:settings:read
w Device Flow, odnowienie zgody bez zmiany checkboxa. Producent kategorii
i GPSR odrębne. Bez generowania instrukcji/seedów lub nowych rejestrów.
Sygnatura nowych ofert = SKU. Potwierdzana naprawa dawnych sygnatur tylko
własnych zapisanych INACTIVE, osobny trwały rejestr PATCH/202. Bez cichego
przepisywania cen, treści lub GPSR dawnych ofert. Parametry Wymagane/Dodatkowe,
źródła zaawansowane, automatyczne SKU/EAN per pozycja. Schemat 11 bez zmian.
Publikacja osobno; komplet wymaga pozytywnej walidacji Allegro, bez obietnicy
przy braku dowodu. ADR-066 i docs/PRZYROST_0_43.md. Dalsze zakresy zachowane.


Poprawka 0.43.1 — zgłoszenie właściciela: GPSR/dostawa nie otwiera się.
Formularz pokazuje się przed żądaniami API, listy w tle, widoczny status
błędu i ponowienie. Odczyty częściowe nie blokują pozostałych zakładek;
błędy wybranych wymaganych danych nadal blokują wysyłkę przed uploadem.
Brak zapisu po błędzie lub zmianie sesji. Schemat i dane bez zmian.
Raport docs/POPRAWKA_0_43_1.md.


Poprawka 0.43.2 — właściciel 2026-11-13 usunął wymóg ręcznej lokalizacji:
domyślnie adres z konta Allegro przez pominięcie location w POST. Opcjonalna
inna lokalizacja nadal dostępna, jawnie wybierana i walidowana w całości.
Istniejące własne lokalizacje i odciski zachowane. Bez migracji i zmian
GPSR lub zgód. docs/POPRAWKA_0_43_2.md.

Doprecyzowanie 0.43.2: właściciel wymaga widocznego wyboru ręcznego numeru
katalogowego albo SKU każdej pozycji paczki, bez szukania w Zaawansowane.
Masowo ręczny kod jest wspólny tylko dla wskazanych pozycji; tryb paczki
pozostawia indywidualne kody i EAN. Zmiana trybu jawnie zaznacza parametr.


Przyrost 0.44 — VAT według krajów na polecenie właściciela. Jawny wybór
krajów i stawek, metadane kategorii GET /sale/tax-settings, opcjonalna kopia
z własnej oferty tej samej kategorii. Bez automatycznego rozpoznawania
aktywnych rynków lub przeliczania cen brutto. POST taxSettings i GET
potwierdzający, bez ponownego POST po niepewnym wyniku. Bez migracji,
nowych zgód i publikacji sprzedaży. ADR-067, docs/PRZYROST_0_44.md.


Poprawka 0.44.1 — zgłoszenie właściciela: pusta lista VAT. Pomijanie
value:null („Wybierz”) w metadanych; OUT_OF_SCOPE_OF_VAT → 0.00 przy
zachowaniu etykiety i wymogu zwolnienia. Nieznane kody nadal odrzucane.
Bez migracji, zmiany cen i publikacji sprzedaży. docs/POPRAWKA_0_44_1.md.


Przyrost 0.45 — właściciel wymaga prostszego i nowocześniejszego okna
nowych szkiców, zgodnego z Dashboardem. Jeden ekran do oceny: dwie sekcje,
edycja nad tabelą, walidacja/tworzenie na dole, rzadsze działania w menu.
Zachować funkcje i ich blokady, logo, miniatury i dane. ADR-068. Poprawka
VAT 0.44.1 włączona w ZIP 0.45, bez osobnej publikacji 0.44.1.


Poprawka 0.45.1 — zgłoszenie właściciela: wąskie okno GPSR/dostawy.
Minimalna geometria w jednostkach logicznych, rozmiar początkowy po
zbudowaniu formularza, ograniczone dostępnym ekranem. Okno nadal
rozszerzalne, zakładki i funkcje zachowane. docs/POPRAWKA_0_45_1.md.


Przyrost 0.46 — właściciel: miniatury 64×64 w planie Allegro, kolory
Dashboardu, znak zamiast Gotowa i informacja po wysyłce. Wspólne komponenty
obrazów/palety, odczyt w tle, podsumowanie tylko potwierdzonych ID, oddzielne
błędy/unknown. Stan DTO/raport bez zmian. ADR-069, docs/PRZYROST_0_46.md.


Przyrost 0.47 — właściciel wymaga kontroli opublikowanych ofert, aby nie
dublować. API całego konta po SKU oraz dokładnym tytule/EAN, bez filtra
statusu; wyniki Już na Allegro z ID, pominięcie przed nowym POST. Błędy
i niepełny odczyt blokują. ADR-070, docs/PRZYROST_0_47.md.

Kolejny etap właściciela: wspólne przygotowanie i wybór kanałów Allegro /
PrestaShop / oba, właściwy układ treści, równoległa obsługa wysyłek i wyniki
per kanał z ochroną przed duplikacją przy ponowieniu. Teraz bez wdrażania
publikacji PrestaShop. Dotychczasowa osobna publikacja Allegro zachowana.


Doprecyzowanie właściciela w 0.47: przycisk Parametry produktów przeniesiony
do lewego panelu Dane produktów; ten sam formularz masowy i zakres zaznaczenia.


Poprawka 0.47.1 — właściciel wymaga widocznego wskazania na listach wyboru.
QComboBox w trybie listy zamiast menu, kontrastowe niebieskie zaznaczenie
z białym tekstem i akcentem, bez zmiany wartości i obsługi parametrów.
Oba motywy, test renderowanego koloru i klawiatury. docs/POPRAWKA_0_47_1.md.


Przyrost 0.48 — właściciel: niepotwierdzone 43 pozycje nie oznaczają
przesłano0. Osobne liczniki, widoczny odczyt, zachowane ID i blokada tworzenia
niepotwierdzonych w UI. Panele jak operacyjne kafelki Dashboardu; miniatury
64×64 także w Ofertach z paczki, reset starych odczytów. ADR-071. Bez zmiany
bazy lub użytkowych danych, bez ponownego POST. docs/PRZYROST_0_48.md.


Przyrost 0.49 — właściciel zaakceptował uzupełnianie istniejących Produktów
z własnych ofert Allegro i wymaga nazwy Producenta w bazie. Parametr Producent/
Marka ze słownika kategorii, nigdy Producent GPSR. Nowy wpis rejestru albo
jednoznaczne aktywne dopasowanie po nazwie; zachowane lokalne przypisania.
Wspólny Produkt, osobne powiązania env/konto/ID; SKU wymagane, EAN nie scala.
Podgląd, jawny import do500 pozycji/partię, galerie do16 i64MiB, zachowane
ręczne pola, atomowy zapis z kopią. Ręczna dostępność niezależna od stanu
magazynu i publikacji, filtry i osobne potwierdzane kończenie aktywnych
ofert bieżącego konta. Unknown tylko GET, znacznik przed PATCH. Schemat11→12
z kopią/rollback i bez destrukcji starych danych. ADR-072, docs/PRZYROST_0_49.md.

Doprecyzowanie właściciela: sekcja Oferty (Nowe/Szkice/Aktywne) ma być miejscem
wspólnej pracy dla Allegro i PrestaShop, z osobnymi ustawieniami i wynikami
kanałów. Import Produktów przygotowuje powiązania; nie zastępuje tej sekcji.
Synchronizacja zmian i publikacja PrestaShop oraz Subiekt nadal kolejnymi etapami.


Poprawka 0.49.1 — krótkie liczniki wyniku wysyłki, Do wysłania zamiast Gotowe w walidacji. Import listy konta po100 z adaptacyjnym zmniejszeniem przy ROZMIAR; bez zmiany bazy i limitu HTTP. docs/POPRAWKA_0_49_1.md.


Poprawka 0.49.2 — pasek postępu i liczniki pobierania listy ofert, sprawdzania i przygotowania zdjęć; wynik zapisu i suma bieżącej listy. Błąd zachowuje ostatni postęp. Bez migracji. docs/POPRAWKA_0_49_2.md.


Przyrost 0.50 — właściciel wymaga nazwanych własnych informacji bezpieczeństwa i kodów taryfy jako danych użytkownika zachowanych przy aktualizacji. ADR-073. Port + atomowe pliki w szablony_ofert, bez seedów i migracji. Jawny wybór/zapis/usunięcie, taryfa także w edycji masowej. Zawiera pasek postępu importu 0.49.2 (nieopublikowany osobno). docs/PRZYROST_0_50.md.


Przyrost 0.51 — realizacja wymaganego formularza ręcznej oferty bez ZIP/Produktu oraz wejście z lokalnych Szkiców do istniejącego przygotowania Allegro. Właściciel dodatkowo wymaga zdjęć z dysku: normalizowane kopie JPEG w danych użytkownika, odwołania SHA256, podgląd i binarny upload /sale/images po potwierdzeniu. ADR-074. Bez migracji i publikacji sprzedaży. Dane zachowane. docs/PRZYROST_0_51.md.


Przyrost 0.52 — osobno potwierdzana publikacja INACTIVE przez komendy ACTIVATE, odczyt ACTIVE jako jedyny sukces, trwały dziennik i bez ponawiania PUT po nieznanym wyniku. Wybrane ID bieżącego konta, odcisk danych przed zleceniem, bez wznawiania ENDED. ADR-075. Równocześnie poprawka błędu pobierania produktów: do3 ponowień GET i wznowienie pełnych stron w pamięci po kontroli początku/licznika; brak częściowego importu. Schemat katalogu12 bez zmian. docs/PRZYROST_0_52.md.


Przyrost 0.53 — właściciel wymaga prostszej edycji jak w Allegro i drag & drop. Jeden przewijany ręczny formularz z edytowanymi bezpośrednio kartami, bez bocznej listy/zagnieżdżonych zakładek. Pliki do galerii/opisu (tylko kopiowanie), miniatury do opisu i sekcje za uchwyt; przyciski alternatywne. Zachowane układy, formatowanie, źródło bez zmian przy otwarciu, podgląd i istniejący zapis/API. Schemat12 bez zmian. ADR-076, docs/PRZYROST_0_53.md.

0.54: nowoczesny wygląd ręcznego edytora, bez zmian danych i funkcji. [ADR-077](docs/adr/ADR-077-nowoczesny-edytor-oferty.md).

0.55: wspólny edytor Nowych ofert i zapisanych Szkiców: SKU/EAN, cena, zdjęcia i opis. Aktualizacja tego samego ID z kontrolą wersji i kopią, bez zmian Produktu lub ofert na kanałach. Wspólne przygotowanie kanałów i PrestaShop pozostają kolejnym etapem. [ADR-078](docs/adr/ADR-078-wspolny-edytor-zapisanych-szkicow.md).

## Kolejny etap — edycja wysłanych i aktywnych ofert Allegro

**Status: wdrożony zakres 0.56 opisany poniżej i w PRZYROST_0_56.md.**
EAN: jednoznaczny istniejący produkt, ta sama kategoria, pojedynczy produkt bez
automatycznych dopasowań/TecDoc. Szersze korekty katalogu i zestawy pozostają
kolejnym zakresem. Polecenie właściciela z 2026-11-16.
Rozszerzenie wspólnego miejsca pracy Oferty po przyroście 0.55.

**Cel:** poprawianie istniejących ofert na Allegro, pojedynczo i masowo,
bez ponownego tworzenia oferty i bez zmiany jej ID. Zakres obejmuje wysłane
szkice INACTIVE oraz oferty aktywne ACTIVE. Osobne opublikowanie szkicu
pozostaje odrębną czynnością.

**Zakres użytkowy:**

- Wejście z listy Allegro i obszaru Oferty: jedna oferta lub zaznaczona grupa.
  Widoczne konto, środowisko, ID i aktualny status każdej oferty.
- Edycja tytułu, SKU/sygnatury oraz EAN. Pojedynczo: proste pola formularza.
  Masowo: tabela wartości dla każdej oferty oraz operacje na tytułach
  (znajdź/zamień, dodaj przed lub po tytule).
- SKU i EAN pozostają indywidualne dla każdej oferty. Zastosowanie wspólnej
  operacji nie może przypadkowo nadać jednego kodu wszystkim pozycjom.
- Podgląd „przed → po” z wyborem pól i ofert do zapisania. Zmiany wysyłane
  dopiero po jawnym zatwierdzeniu konkretnego zakresu.
- Postęp oraz proste liczniki: Zapisane, Do poprawy, Do sprawdzenia,
  Pominięte. Wynik i przyczyna dla każdej pozycji, możliwość zachowania raportu.

**Wymagania dla EAN:** odczytać powiązanie oferty z produktem Katalogu Allegro
oraz ograniczenia API dla bieżącej kategorii. Rozróżnić korektę danych od
zmiany powiązanego produktu. Jeżeli zmiana EAN wymaga wskazania innego
produktu, pokazać znaleziony produkt i skutki zmiany powiązania w podglądzie.
Nie przedstawiać EAN jako dowolnego pola tekstowego, które zawsze da się
nadpisać; nie zmieniać po cichu wspólnego produktu Katalogu Allegro.
Zestawy produktów wymagają jednoznacznego wskazania edytowanego elementu.

**Wymagania zapisu:**

- Odczyt świeżych danych przed zapisem i wykrywanie zmian od czasu podglądu.
  Konflikt pozostawia propozycję do poprawienia zamiast nadpisywać cudzy zapis.
- Częściowa aktualizacja wyłącznie zatwierdzonych pól. Tytuł/SKU nie mogą
  powodować ubocznej zmiany produktu, opisu, ceny, ilości, GPSR, dostawy,
  warunków sprzedaży ani statusu publikacji.
- Sieć w tle, możliwość zatrzymania serii po bieżącym żądaniu. Błąd jednej
  pozycji ma własny wynik; nie oznacza sukcesu całej grupy.
- Sukces dopiero po odczycie potwierdzającym zapis. Trwały rejestr prób,
  obsługa odpowiedzi asynchronicznej oraz sprawdzanie nieznanego wyniku
  bez ponownego wysyłania zmiany. Ponowne otwarcie programu zachowuje blokadę.
- Zmiana konta lub środowiska nie może przenieść przygotowanych zmian
  na inne konto. Uprawnienia do zapisu sprawdzane przed wysyłką.
- Lokalny Produkt i lokalny Szkic nie są automatycznie nadpisywane edycją
  kanału. Wspólna synchronizacja Allegro/PrestaShop pozostaje osobnym etapem.

**Kryteria odbioru:** edycja jednej i wielu ofert INACTIVE/ACTIVE; zachowane
ID i statusy; różne SKU/EAN w grupie; walidacja tytułów i kodów; brak zmian
w niewskazanych polach; anulowanie bez zapisu; konflikt; odmowa API; timeout
przed/po skutku; asynchroniczny zapis; restart i sprawdzenie wyniku bez
ponowienia; częściowy sukces serii; oba motywy, klawiatura i większe DPI.
Testy automatyczne bez rzeczywistych zmian na koncie użytkownika.


0.56: wdrożenie edycji INACTIVE/ACTIVE, pojedynczo i masowo, tytuł/SKU/EAN z podglądem i osobnym potwierdzeniem. EAN wymaga jednoznacznego istniejącego produktu tej samej kategorii; zestawy/TecDoc/dopasowania wymagają edycji EAN w Allegro. Wspólny rejestr prób z dawnym zapisem szkiców, GET-only po nieznanym wyniku. Brak migracji i zmian lokalnych Produktów/Szkiców. [ADR-079](docs/adr/ADR-079-edycja-zdalnych-ofert.md).

0.57 — właściciel wymaga automatycznych Produktów z paczki, zdjęcia/SKU/EAN/ceny, wyboru lub ręcznej nazwy Producenta i eksportu/importu danych użytkownika. Ten zakres zastępuje wcześniejszy brak tworzenia Produktów przez przygotowanie Allegro. Zapis przed POST, osobny wynik lokalny, powiązanie po potwierdzeniu Allegro. ZIP v1 przenosi dane i do5 zdjęć galerii lokalnej; import atomowy, braki uzupełniane po SKU bez nadpisywania własnych pól. Schemat12 bez zmian. [ADR-080](docs/adr/ADR-080-produkty-z-paczek-i-przenosny-katalog.md).

0.57.1 — na polecenie właściciela: natywna maksymalizacja okna przygotowania ofert Allegro, przywrócenie oraz dwuklik w pasek tytułu Windows. Zachowany modalny QDialog, rozciąganie tabeli i wybór pozycji. Bez zmian danych i API. [Poprawka](docs/POPRAWKA_0_57_1.md).

0.58 — zaakceptowany kolejny krok: oferta z jednego lokalnego Produktu, ten sam edytor, kopie zdjęć, SKU/EAN/cena i producent/waluta źródła; lokalny FK i wersja, metadane w istniejącym JSON, bez migracji. Netto/inne waluty wymagają świadomej ceny brutto. Dodatkowo praca w programie podczas wysyłki paczki: niemodalne okno, ukrycie bez zamknięcia i stały przycisk powrotu/postęp. Dotychczasowa ochrona QRunnable zachowana, wspólny timer sprzątania. [ADR-081](docs/adr/ADR-081-oferta-z-lokalnego-produktu.md).


0.59 — cenniki: domyślna opcja pełnego brutto, VAT 23% zgodnie z decyzją
właściciela. Źródłowe netto przeliczane przed zaokrągleniem HALF_UP do
jednostki; obok netto z zaokrąglonego brutto (dwa miejsca). Widoczny wybór
reguły w imporcie, zapamiętywany w profilu. Istniejące ceny bez przepisania.
Bez migracji. [ADR-082](docs/adr/ADR-082-pelne-brutto-cennikow.md).

0.59.1 — szczegóły powodów i poprawek ofert pod przyciskiem na dole okna,
bez dodatkowych kolumn. Powód zatrzymania serii i pełne komunikaty API.
[Poprawka](docs/POPRAWKA_0_59_1.md).
