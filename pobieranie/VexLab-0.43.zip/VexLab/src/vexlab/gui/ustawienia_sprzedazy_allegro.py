"""Jedno okno GPSR/dostawy/warunków dla wskazanej grupy ofert."""

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QPlainTextEdit,
    QScrollArea,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import (
    CZASY,
    WOJEWODZTWA,
    SlownikiSprzedazy,
    UstawieniaSprzedazy,
    WyborSprzedazy,
    sprawdz_ustawienia,
)


class DaneSprzedazyAllegro(QDialog):
    def __init__(
        self,
        parent: QWidget,
        slowniki: SlownikiSprzedazy,
        ustawienia: UstawieniaSprzedazy | None,
        liczba: int,
    ) -> None:
        super().__init__(parent)
        self.wynik: UstawieniaSprzedazy | None = None
        u = ustawienia or UstawieniaSprzedazy()
        self.setWindowTitle(f"GPSR, dostawa i warunki • {liczba} ofert")
        self.resize(850, 730)
        layout = QVBoxLayout(self)
        layout.addWidget(
            etykieta(
                f"Wspólne ustawienia dla {liczba} wskazanych ofert. "
                "SKU, EAN, ceny i ilości pozostają osobne."
            )
        )
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)

        def page(nazwa: str) -> QFormLayout:
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            host = QWidget()
            form = QFormLayout(host)
            form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
            form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
            scroll.setWidget(host)
            self.tabs.addTab(scroll, nazwa)
            return form

        def wybor(
            nazwa: str,
            rows: tuple[WyborSprzedazy, ...],
            current: str,
            wyjatek: tuple[str, str] | None = None,
        ) -> QComboBox:
            box = QComboBox()
            box.setAccessibleName(nazwa)
            box.setMinimumContentsLength(20)
            box.setSizeAdjustPolicy(
                QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
            )
            box.addItem("Wybierz…", "")
            if wyjatek:
                box.addItem(*wyjatek)
            for w in rows:
                box.addItem(w.nazwa + (" • " + w.opis if w.opis else ""), w.id)
                box.setItemData(box.count() - 1, w.opis, 3)
            box.setCurrentIndex(max(0, box.findData(current)))
            return box

        gpsr = page("1. GPSR")
        self.producent = wybor("Producent GPSR", slowniki.producenci, u.producent)
        self.osoba = wybor(
            "Osoba odpowiedzialna w UE",
            slowniki.osoby,
            u.osoba,
            ("Nie dotyczy — producent nie wymaga dodatkowej osoby", "nie_dotyczy"),
        )
        gpsr.addRow("Producent GPSR *", self.producent)
        gpsr.addRow("Osoba odpowiedzialna w UE *", self.osoba)
        self.bezpieczenstwo = QPlainTextEdit(u.bezpieczenstwo)
        self.bezpieczenstwo.setAccessibleName("Informacje o bezpieczeństwie produktu")
        self.bezpieczenstwo.setPlaceholderText(
            "Wklej ostrzeżenia i instrukcje bezpieczeństwa właściwe dla tych "
            "produktów (do 5000 znaków)."
        )
        self.bezpieczenstwo.setMinimumHeight(180)
        gpsr.addRow("Informacje o bezpieczeństwie *", self.bezpieczenstwo)
        gpsr.addRow(
            etykieta(
                "Dane pochodzą z rejestrów Twojego konta Allegro. Parametr "
                "kategorii „Producent” to osobne pole. Brakujący wpis dodaj w "
                "ustawieniach Allegro, potem pobierz listy ponownie."
            )
        )
        dostawa = page("2. Dostawa")
        self.dostawa = wybor("Cennik dostaw", slowniki.dostawy, u.dostawa)
        dostawa.addRow("Cennik dostaw *", self.dostawa)
        times = tuple(
            WyborSprzedazy(v, label)
            for v, label in zip(
                CZASY,
                (
                    "Natychmiast",
                    "24 godziny",
                    "2 dni",
                    "3 dni",
                    "4 dni",
                    "5 dni",
                    "7 dni",
                    "10 dni",
                    "14 dni",
                    "21 dni",
                    "30 dni",
                    "60 dni",
                ),
                strict=True,
            )
        )
        self.czas = wybor("Czas wysyłki", times, u.czas)
        dostawa.addRow("Czas wysyłki *", self.czas)
        self.kraj = QLineEdit(u.kraj)
        self.kraj.setMaxLength(2)
        self.kraj.setPlaceholderText("np. PL")
        self.miasto = QLineEdit(u.miasto)
        self.miasto.setMaxLength(50)
        self.kod = QLineEdit(u.kod)
        self.kod.setMaxLength(12)
        self.wojewodztwo = wybor(
            "Województwo nadania",
            tuple(WyborSprzedazy(v, v.replace("_", " ").title()) for v in WOJEWODZTWA),
            u.wojewodztwo,
        )
        for label, widget in (
            ("Kraj nadania *", self.kraj),
            ("Miejscowość *", self.miasto),
            ("Kod pocztowy *", self.kod),
            ("Województwo (Polska) *", self.wojewodztwo),
        ):
            widget.setAccessibleName(label)
            dostawa.addRow(label, widget)
        warunki = page("3. Warunki sprzedaży")
        self.zwroty = wybor("Warunki zwrotów", slowniki.zwroty, u.zwroty)
        self.reklamacje = wybor("Warunki reklamacji", slowniki.reklamacje, u.reklamacje)
        self.gwarancja = wybor(
            "Gwarancja", slowniki.gwarancje, u.gwarancja, ("Brak dodatkowej gwarancji", "brak")
        )
        self.faktura = wybor(
            "Rodzaj faktury",
            tuple(
                WyborSprzedazy(v, label)
                for v, label in (
                    ("VAT", "Faktura VAT"),
                    ("VAT_MARGIN", "Faktura VAT marża"),
                    ("WITHOUT_VAT", "Faktura bez VAT"),
                    ("NO_INVOICE", "Nie wystawiam faktury"),
                )
            ),
            u.faktura,
        )
        for label, widget in (
            ("Zwroty *", self.zwroty),
            ("Reklamacje *", self.reklamacje),
            ("Gwarancja *", self.gwarancja),
            ("Faktura *", self.faktura),
        ):
            warunki.addRow(label, widget)
        self.info = etykieta("Wypełnij trzy zakładki. Zapis ustawień nie uruchamia sprzedaży.")
        layout.addWidget(self.info)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText(f"Zastosuj do {liczba} ofert")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.accepted.connect(self.zapisz)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def zapisz(self) -> None:
        u = UstawieniaSprzedazy(
            str(self.producent.currentData()),
            str(self.osoba.currentData()),
            self.bezpieczenstwo.toPlainText().strip(),
            str(self.dostawa.currentData()),
            str(self.czas.currentData()),
            str(self.zwroty.currentData()),
            str(self.reklamacje.currentData()),
            str(self.gwarancja.currentData()),
            self.kraj.text().strip().upper(),
            self.miasto.text().strip(),
            self.kod.text().strip(),
            str(self.wojewodztwo.currentData()),
            str(self.faktura.currentData()),
        )
        bledy = sprawdz_ustawienia(u)
        if bledy:
            self.info.setText("\n".join(bledy))
            return
        self.wynik = u
        self.accept()
