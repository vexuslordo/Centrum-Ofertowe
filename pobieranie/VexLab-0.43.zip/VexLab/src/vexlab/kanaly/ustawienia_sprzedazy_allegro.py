"""Odczyt nazw i odwołań do ustawień konta, bez tworzenia rejestrów GPSR."""

from collections.abc import Callable
from typing import Any
from urllib.parse import urlencode
from uuid import UUID

from vexlab.kanaly.allegro import tekst
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro, SrodowiskoAllegro
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import SlownikiSprzedazy, WyborSprzedazy


def pobierz_slowniki(
    get: Callable[[SrodowiskoAllegro, str, str], dict[str, Any]], s: SesjaAllegro
) -> SlownikiSprzedazy:
    def lista(path: str, key: str, paged: bool = False) -> tuple[WyborSprzedazy, ...]:
        wynik: list[WyborSprzedazy] = []
        offset = 0
        while True:
            url = path + ("?" + urlencode({"limit": 100, "offset": offset}) if paged else "")
            try:
                d = get(s.srodowisko, s.token, url)
            except BladAllegro as exc:
                if exc.kod in {"UPRAWNIENIA", "AUTORYZACJA"} or "403" in str(exc):
                    raise BladAllegro(
                        "UPRAWNIENIA",
                        "Odczyt GPSR i warunków wymaga allegro:api:sale:settings:read. "
                        "Włącz je w aplikacji Allegro, następnie Ustawienia → Integracje → "
                        "Allegro → Zmień uprawnienia.",
                    ) from None
                raise
            try:
                rows = d[key]
                if not isinstance(rows, list):
                    raise ValueError("rows")
                for r in rows:
                    ident = str(UUID(tekst(r, "id")))
                    details = r.get("producerData") or r.get("personalData") or {}
                    opis = ""
                    if isinstance(details, dict):
                        address = details.get("address") or {}
                        if isinstance(address, dict):
                            opis = " • ".join(
                                str(v)
                                for v in (
                                    details.get("tradeName") or details.get("name"),
                                    address.get("countryCode"),
                                    address.get("city"),
                                )
                                if v
                            )
                    wynik.append(WyborSprzedazy(ident, tekst(r, "name"), opis))
                if len({w.id for w in wynik}) != len(wynik):
                    raise ValueError("duplikat")
                if not paged:
                    break
                total = d["totalCount"]
                if type(total) is not int or not 0 <= total <= 50000:
                    raise ValueError("total")
                if len(wynik) == total:
                    break
                if not rows or len(wynik) > total:
                    raise ValueError("niepełne")
                offset += len(rows)
            except (KeyError, ValueError, TypeError, AttributeError):
                raise BladAllegro(
                    "ODPOWIEDZ",
                    "Niepełna lub niepoprawna lista ustawień sprzedaży. Nie wybieraj "
                    "zastępczych danych.",
                ) from None
        return tuple(wynik)

    return SlownikiSprzedazy(
        lista("/sale/responsible-producers", "responsibleProducers", True),
        lista("/sale/responsible-persons", "responsiblePersons", True),
        lista("/sale/shipping-rates", "shippingRates"),
        lista("/after-sales-service-conditions/return-policies?limit=60", "returnPolicies"),
        lista("/after-sales-service-conditions/implied-warranties?limit=60", "impliedWarranties"),
        lista("/after-sales-service-conditions/warranties?limit=60", "warranties"),
    )
