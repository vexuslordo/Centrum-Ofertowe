from dataclasses import replace

from PySide6.QtWidgets import QCheckBox, QComboBox, QDialog

from tests.gui.test_masowa_paczka_allegro import select
from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from vexlab.gui.ustawienia_sprzedazy_allegro import DaneSprzedazyAllegro


def test_komplet_domyslnie_wymagany_i_zapis_ustawien_tylko_do_wyboru(
    qtbot, sprzedaz_fixture, monkeypatch
):
    base = sprzedaz_fixture[:6]
    o = base[4]
    w, jobs = panel(qtbot, base, (o, replace(o, sku="2")))
    w.kompletny.setChecked(True)
    w.ustawienia[0] = replace(w.ustawienia[0], sprzedaz=None)
    w.ustawienia[1] = replace(w.ustawienia[1], sprzedaz=None)
    select(w, (0,))

    def edit(d):
        assert d.tabs.count() == 3
        assert not d.producent.currentData()
        u = sprzedaz_fixture[5].sprzedaz
        for name in (
            "producent",
            "osoba",
            "dostawa",
            "czas",
            "zwroty",
            "reklamacje",
            "gwarancja",
            "wojewodztwo",
            "faktura",
        ):
            box = getattr(d, name)
            box.setCurrentIndex(box.findData(getattr(u, name)))
        for name in ("kraj", "miasto", "kod"):
            getattr(d, name).setText(getattr(u, name))
        d.bezpieczenstwo.setPlainText(u.bezpieczenstwo)
        d.zapisz()
        assert d.wynik == u
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(DaneSprzedazyAllegro, "exec", edit)
    w.ustaw_sprzedaz()
    wykonaj(jobs)
    wykonaj(jobs)
    assert not w.plany[0].bledy and w.plany[1].bledy
    assert w.plany[0].ustawienia.sprzedaz == sprzedaz_fixture[5].sprzedaz
    assert "POST" not in base[1].calls


def test_parametry_sa_podzielone_i_zrodla_ukryte(qtbot, nowe_produkty_fixture, monkeypatch):
    w, jobs = panel(qtbot, nowe_produkty_fixture)
    w.przygotuj()
    wykonaj(jobs)
    select(w, (0,))

    def edit(d):
        from PySide6.QtWidgets import QLineEdit, QTabWidget

        tabs = d.findChild(QTabWidget)
        assert [tabs.tabText(i) for i in range(tabs.count())] == ["Wymagane", "Dodatkowe"]
        sources = [
            box for box in d.findChildren(QComboBox) if box.accessibleName().startswith("Źródło")
        ]
        assert sources and all(box.isHidden() for box in sources)
        advanced = next(c for c in d.findChildren(QCheckBox) if c.text().startswith("Zaawansowane"))
        advanced.setChecked(True)
        assert all(not box.isHidden() for box in sources)
        kod = next(c for c in d.findChildren(QLineEdit) if c.accessibleName() == "Kod producenta")
        assert not kod.isEnabled()
        source = next(c for c in sources if "Kod producenta" in c.accessibleName())
        source.setCurrentIndex(source.findData(""))
        assert kod.isEnabled()
        return QDialog.DialogCode.Rejected

    monkeypatch.setattr(QDialog, "exec", edit)
    w.uzupelnij()
    assert "POST" not in nowe_produkty_fixture[1].calls
