from dataclasses import replace
from threading import Thread

import pytest

from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    KontoAllegro,
    PolaczAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StronaSzkicowAllegro,
)
from vexlab.przypadki_uzycia.allegro import (
    StatusOfertyAllegro as Status,
)


class Czas:
    czas = 100

    def teraz(self):
        return self.czas


class API:
    def __init__(self):
        self.wywolania = []
        self.blad = False

    def oferty(self, sesja, status, offset, limit):
        self.wywolania.append((sesja.konto.id, status, offset, limit))
        if self.blad and status == Status.SZKIC:
            raise BladAllegro("UPRAWNIENIA", "Odmowa")
        return StronaSzkicowAllegro((), 50001 if status == Status.AKTYWNA else 3, offset, limit)


def sesja():
    return SesjaAllegro(KontoAllegro("1", "fixture"), SrodowiskoAllegro.PRODUKCJA, "test", 1000)


def test_liczniki_calego_konta_cache_ttl_i_izolacja_konta_srodowiska_tokena():
    api, zegar = API(), Czas()
    s, case = sesja(), PolaczAllegro(api, zegar)
    wynik = case.liczniki(s)
    assert (wynik.aktywne, wynik.szkice) == (50001, 3)
    assert all(call[2:] == (0, 1) for call in api.wywolania)
    assert case.liczniki(s) is wynik and len(api.wywolania) == 2
    zegar.czas += 30
    case.liczniki(s)
    assert len(api.wywolania) == 4
    for inne in (
        replace(s, konto=KontoAllegro("2", "inne")),
        replace(s, srodowisko=SrodowiskoAllegro.SANDBOX),
        replace(s, token="nowy"),
    ):
        before = len(api.wywolania)
        case.liczniki(inne)
        assert len(api.wywolania) == before + 2


def test_czesciowy_blad_nie_zapisuje_cache_i_wygasniecie_nie_zwraca_cache():
    api, zegar = API(), Czas()
    case, s = PolaczAllegro(api, zegar), sesja()
    case.liczniki(s)
    api.blad = True
    with pytest.raises(BladAllegro, match="Odmowa"):
        case.liczniki(s, odswiez=True)
    assert case._cache_licznikow is None
    zegar.czas = 1000
    przed = len(api.wywolania)
    with pytest.raises(BladAllegro) as blad:
        case.liczniki(s)
    assert blad.value.kod == "WYGASLA" and len(api.wywolania) == przed


def test_rownolegle_liczniki_wykonuja_jedna_pare_odczytow():
    api = API()
    case, s = PolaczAllegro(api, Czas()), sesja()
    wyniki = []
    watki = [Thread(target=lambda: wyniki.append(case.liczniki(s))) for _ in range(4)]
    for w in watki:
        w.start()
    for w in watki:
        w.join(timeout=2)
        assert not w.is_alive()
    assert len(api.wywolania) == 2 and len(wyniki) == 4


@pytest.mark.parametrize(
    "status,offset", [("ACTIVE", 0), (Status.AKTYWNA, -1), (None, 10000), (None, 1), (None, True)]
)
def test_nieprawidlowa_strona_nie_dociera_do_api(status, offset):
    api = API()
    with pytest.raises(BladAllegro):
        PolaczAllegro(api, Czas()).oferty(sesja(), status, offset)
    assert not api.wywolania


def test_sesja_wygasajaca_w_trakcie_odczytu_nie_daje_sukcesu():
    zegar = Czas()

    class Wolne(API):
        def oferty(self, *args):
            wynik = super().oferty(*args)
            zegar.czas = 1000
            return wynik

    with pytest.raises(BladAllegro) as blad:
        PolaczAllegro(Wolne(), zegar).oferty(sesja(), Status.AKTYWNA)
    assert blad.value.kod == "WYGASLA"
