"""Widok sekcji z obrazami ładowanymi asynchronicznie, bez wykonywania HTML."""

from collections import OrderedDict
from typing import cast

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QMouseEvent, QPixmap, QResizeEvent
from PySide6.QtWidgets import QHBoxLayout, QLabel, QScrollArea, QVBoxLayout, QWidget
from shiboken6 import isValid

from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import TekstPodgladu, etykieta
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec


class ObrazPodgladu(QLabel):
    klikniety = Signal()

    def __init__(self, url: str, *, kwadratowy: bool = False) -> None:
        super().__init__("Ładowanie zdjęcia…" if url else "Wybierz zdjęcie")
        self.kwadratowy = kwadratowy
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setWordWrap(True)
        self.setMinimumSize(120, 160)
        self.setMaximumHeight(380)
        self.setToolTip(url)
        self.obraz = QPixmap()
        if kwadratowy:
            self.setFixedSize(64, 64)
            self.setStyleSheet(
                "background:#FFFFFF;color:#6B7C90;border:1px solid #D5DDE5;border-radius:6px;"
            )
            self.setAccessibleName("Miniatura zdjęcia oferty")

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.klikniety.emit()
        super().mousePressEvent(event)

    def ustaw(self, dane: bytes) -> None:
        self.obraz.loadFromData(dane)
        self._skaluj()

    def _skaluj(self) -> None:
        if not self.obraz.isNull():
            if self.kwadratowy:
                self.setPixmap(
                    self.obraz.scaled(
                        max(1, self.width() - 8),
                        max(1, self.height() - 8),
                        Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation,
                    )
                )
                return
            scaled = self.obraz.scaled(
                max(1, self.width() - 16),
                min(360, self.maximumHeight() - 16),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            self.setPixmap(scaled)
            self.setMinimumHeight(min(self.maximumHeight(), scaled.height() + 16))

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        self._skaluj()


class TekstSekcji(TekstPodgladu):
    def __init__(self, html: str) -> None:
        super().__init__(html)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.document().documentLayout().documentSizeChanged.connect(self._wysokosc)

    def _wysokosc(self) -> None:
        self.setFixedHeight(max(80, int(self.document().size().height()) + 24))

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        self._wysokosc()


class ObrazyOferty:
    """Pamięć jednego edytora: 32 obrazy / 32 MiB, jeden odczyt naraz."""

    def __init__(
        self,
        parent: QWidget,
        serwis: PodgladZdjec | None,
        uruchom: Uruchom | None,
        *,
        miniatury: bool = False,
    ) -> None:
        self.parent, self.serwis, self.uruchom = parent, serwis, uruchom
        self.miniatury = miniatury
        self.cache: OrderedDict[str, bytes] = OrderedDict()
        self.czekaja: dict[str, list[ObrazPodgladu]] = {}
        self.kolejka: list[str] = []
        self.trwa = False
        self.aktywne = True
        self.nieudane: set[str] = set()

    def zamknij(self) -> None:
        self.aktywne = False
        self.kolejka.clear()
        self.czekaja.clear()

    def obraz(self, url: str) -> ObrazPodgladu:
        label = ObrazPodgladu(url, kwadratowy=self.miniatury)
        if not url:
            return label
        if url in self.cache:
            label.ustaw(self.cache[url])
            self.cache.move_to_end(url)
        elif self.serwis is None or self.uruchom is None:
            label.setText("Podgląd zdjęć niedostępny")
        elif url in self.nieudane:
            label.setText(
                "Nie udało się pobrać zdjęcia. Sprawdź adres i sieć; otwórz podgląd ponownie."
            )
        else:
            if url not in self.czekaja:
                if len(self.kolejka) >= 100:
                    label.setText("Podgląd ograniczony do 100 oczekujących zdjęć.")
                    return label
                self.czekaja[url] = []
                self.kolejka.append(url)
            self.czekaja[url].append(label)
            QTimer.singleShot(0, self._nastepny)
        return label

    def _nastepny(self) -> None:
        if (
            not self.aktywne
            or self.trwa
            or not self.kolejka
            or not isValid(self.parent)
            or not self.serwis
            or not self.uruchom
        ):
            return
        url = self.kolejka.pop(0)
        labels = self.czekaja[url]
        if not any(isValid(label) for label in labels):
            del self.czekaja[url]
            QTimer.singleShot(0, self._nastepny)
            return
        self.trwa = True
        serwis = self.serwis

        def gotowe(w: object) -> None:
            self.trwa = False
            if not self.aktywne or not isValid(self.parent):
                return
            obraz = cast(ZdjecieDane, w)
            dane = obraz.miniatura if self.miniatury else obraz.dane
            self.cache[url] = dane
            while len(self.cache) > 32 or sum(map(len, self.cache.values())) > 32 * 1024 * 1024:
                self.cache.popitem(last=False)
            for label in self.czekaja.pop(url, []):
                if isValid(label):
                    label.ustaw(dane)
            self._nastepny()

        def blad(k: str, tekst: str) -> None:
            self.trwa = False
            if not self.aktywne or not isValid(self.parent):
                return
            self.nieudane.add(url)
            for label in self.czekaja.pop(url, []):
                if isValid(label):
                    label.setText("Nie udało się pobrać zdjęcia")
                    label.setToolTip(tekst)
            self._nastepny()

        self.uruchom(lambda: serwis.pobierz(url), gotowe, blad)


class PodgladOferty(QScrollArea):
    def __init__(self, obrazy: ObrazyOferty) -> None:
        super().__init__()
        self.obrazy = obrazy
        self.setWidgetResizable(True)
        self.setAccessibleName("Pełna oferta — galeria i układ opisu")

    def pokaz(self, oferta: OfertaPodglad, sekcje: tuple[tuple[ElementPodgladu, ...], ...]) -> None:
        stary = self.takeWidget()
        if stary is not None:
            stary.deleteLater()
        host = QWidget()
        host.setMaximumWidth(1200)
        layout = QVBoxLayout(host)
        title = etykieta(oferta.tytul)
        title.setObjectName("marka")
        layout.addWidget(title)
        layout.addWidget(
            etykieta(f"SKU: {oferta.sku} • Podgląd układu; Allegro może wyświetlać go inaczej.")
        )
        if oferta.zdjecia:
            main = QWidget()
            main_layout = QVBoxLayout(main)
            main_layout.addWidget(self.obrazy.obraz(oferta.zdjecia[0]))
            layout.addWidget(main)
            thumbnails = QScrollArea()
            thumbnails.setWidgetResizable(True)
            thumbnails.setFixedHeight(128)
            strip = QWidget()
            strip_layout = QHBoxLayout(strip)

            def wybierz(url: str) -> None:
                item = main_layout.takeAt(0)
                widget = item.widget() if item is not None else None
                if widget is not None:
                    widget.deleteLater()
                main_layout.addWidget(self.obrazy.obraz(url))

            for url in oferta.zdjecia[:32]:
                miniatura = self.obrazy.obraz(url)
                miniatura.setMinimumSize(100, 90)
                miniatura.setMaximumSize(140, 100)
                miniatura.setCursor(Qt.CursorShape.PointingHandCursor)
                miniatura.klikniety.connect(lambda u=url: wybierz(u))
                strip_layout.addWidget(miniatura)
            strip_layout.addStretch()
            thumbnails.setWidget(strip)
            layout.addWidget(thumbnails)
            if len(oferta.zdjecia) > 32:
                layout.addWidget(
                    etykieta(
                        "Galeria podglądu: pierwsze 32 zdjęcia. "
                        "Sekcje poniżej zachowują cały układ."
                    )
                )
        for sekcja in sekcje:
            row = QHBoxLayout()
            for element in sekcja:
                widget = (
                    TekstSekcji(element.tekst)
                    if element.typ == "tekst"
                    else self.obrazy.obraz(element.adres)
                )
                row.addWidget(widget, 1)
            layout.addLayout(row)
        layout.addStretch()
        self.setWidget(host)
