"""Kafelki Dashboardu według wzoru: pełna ikona, jasny gradient i biała typografia."""

from pathlib import Path
from typing import cast

from PySide6.QtCore import QRectF, QSize, Qt
from PySide6.QtGui import (
    QColor,
    QIcon,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPaintEvent,
    QPen,
    QRadialGradient,
)
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout

from vexlab.gui.design_system import PALETA_KPI, ikona, ikona_menu


class KafelekKPI(QFrame):
    def __init__(
        self,
        tytul: str,
        wariant: str,
        podpis: str,
        *,
        symbol: str | None = None,
        akcent: str | None = None,
    ) -> None:
        super().__init__()
        self.akcent = akcent
        self.wariant = wariant
        if symbol is not None and akcent is not None:
            self._kompaktowy(tytul, symbol, akcent, podpis)
            return
        self.setProperty("wariant_kpi", wariant)
        self.setFixedHeight(120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 18, 16, 16)
        layout.setSpacing(22)
        obraz = QLabel()
        obraz.setFixedSize(56, 56)
        obraz.setAccessibleName(f"Ikona: {tytul}")
        plik = Path(__file__).with_name("zasoby") / "kpi" / f"{wariant}.svg"
        pixmap = QIcon(str(plik)).pixmap(112, 112)
        pixmap.setDevicePixelRatio(2)
        obraz.setPixmap(pixmap)
        layout.addWidget(obraz, 0, Qt.AlignmentFlag.AlignTop)
        tekst = QVBoxLayout()
        tekst.setContentsMargins(0, 3, 0, 0)
        tekst.setSpacing(4)
        self.tytul = QLabel(tytul)
        self.tytul.setObjectName("kpiTytul")
        self.liczba = QLabel("—")
        self.liczba.setObjectName("kpiLiczba")
        self.liczba.setAccessibleDescription(f"Liczba: {tytul}")
        self.podpis = QLabel(podpis)
        self.podpis.setObjectName("kpiPodpis")
        for label in (self.tytul, self.liczba, self.podpis):
            label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            tekst.addWidget(label)
        layout.addLayout(tekst, 1)

    def _kompaktowy(self, tytul: str, symbol: str, kolor: str, podpis: str) -> None:
        self.setObjectName("metrykaDashboardu")
        self.setMinimumWidth(130)
        self.setFixedHeight(105)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(11, 12, 10, 10)
        layout.setSpacing(10)
        obraz = QLabel()
        obraz.setAccessibleName(f"Ikona: {tytul}")
        obraz.setFixedSize(40, 40)
        sciezki = {
            "Produkty": "produkt",
            "Nowe oferty": "koszyk",
            "Cenniki": "monety",
            "Raporty": "wykres",
            "Historia operacji": "blad",
        }
        znak = ikona(sciezki[symbol], "#FFFFFF") if symbol in sciezki else ikona_menu(symbol, True)
        pixmap = znak.pixmap(QSize(25, 25))
        painter = QPainter(pixmap)
        painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceIn)
        painter.fillRect(pixmap.rect(), QColor("#FFFFFF"))
        painter.end()
        obraz.setPixmap(pixmap)
        obraz.setAlignment(Qt.AlignmentFlag.AlignCenter)
        obraz.setStyleSheet(f"background:{kolor};border-radius:9px;")
        layout.addWidget(obraz, 0, Qt.AlignmentFlag.AlignTop)
        tekst = QVBoxLayout()
        tekst.setSpacing(3)
        self.tytul = QLabel(tytul)
        self.tytul.setObjectName("podpisDashboardu")
        self.liczba = QLabel("—")
        self.liczba.setObjectName("liczbaDashboardu")
        self.liczba.setAccessibleDescription(f"Liczba: {tytul}")
        self.podpis = QLabel(podpis)
        self.podpis.setObjectName("podpisDashboardu")
        self.podpis.setToolTip("Zmiana i miniwykres wymagają porównywalnej historii odczytów.")
        for label in (self.tytul, self.liczba, self.podpis):
            tekst.addWidget(label)
        tekst.addStretch()
        layout.addLayout(tekst, 1)

    def _tlo_operacyjne(self) -> None:
        ciemny = bool(cast(QApplication, QApplication.instance()).property("motyw_ciemny"))
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 9, 9)
        painter.fillPath(path, QColor("#0D1B28" if ciemny else "#F6F9FE"))
        gradient = QRadialGradient(self.width() * 0.8, self.height(), self.width() * 0.7)
        kolor = QColor(cast(str, self.akcent))
        kolor.setAlpha(45 if ciemny else 25)
        gradient.setColorAt(0, kolor)
        kolor.setAlpha(0)
        gradient.setColorAt(1, kolor)
        painter.fillPath(path, gradient)
        painter.setPen(QPen(QColor("#203B51" if ciemny else "#CDDBEE"), 1))
        painter.drawPath(path)

    def paintEvent(self, event: QPaintEvent) -> None:
        if self.akcent is not None:
            self._tlo_operacyjne()
            return
        gora, srodek, dol, poswiata, obrys = PALETA_KPI[self.wariant]
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath()
        path.addRoundedRect(rect, 12, 12)
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        for stop, color in ((0.0, gora), (0.55, srodek), (1.0, dol)):
            gradient.setColorAt(stop, QColor(color))
        painter.fillPath(path, gradient)
        glow = QRadialGradient(self.width() * 0.18, self.height() * 0.05, self.width() * 0.85)
        kolor = QColor(poswiata)
        kolor.setAlpha(28)
        glow.setColorAt(0, kolor)
        kolor.setAlpha(0)
        glow.setColorAt(1, kolor)
        painter.fillPath(path, glow)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        kolor_obrysu = QColor(obrys)
        kolor_obrysu.setAlpha(110)
        painter.setPen(QPen(kolor_obrysu, 1))
        painter.drawPath(path)
