"""Połączenie Allegro, odczyt ofert i ograniczony cache liczników konta."""

from dataclasses import dataclass, field
from enum import Enum
from hashlib import sha256
from threading import Lock, RLock
from typing import Protocol

from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu
from vexlab.rdzen.kontrakty import BladTechniczny


class SrodowiskoAllegro(Enum):
    PRODUKCJA = "Allegro"
    SANDBOX = "Allegro Sandbox"


class BladAllegro(BladTechniczny):
    def __init__(self, kod: str, komunikat: str) -> None:
        super().__init__(komunikat)
        self.kod = kod


@dataclass(frozen=True)
class AplikacjaAllegro:
    klient: str
    sekret: str = field(repr=False)
    srodowisko: SrodowiskoAllegro = SrodowiskoAllegro.PRODUKCJA
    zapis_szkicow: bool = False

    def sprawdz(self) -> None:
        if not self.klient or not self.sekret or len(self.klient) > 512 or len(self.sekret) > 1024:
            raise BladAllegro("KONFIGURACJA", "Podaj Client ID i Client Secret aplikacji Allegro.")
        if any(ord(c) < 33 for c in self.klient + self.sekret) or ":" in self.klient:
            raise BladAllegro("KONFIGURACJA", "Dane aplikacji zawierają niedozwolone znaki.")


@dataclass(frozen=True)
class KodUrzadzenia:
    kod: str = field(repr=False)
    kod_uzytkownika: str = field(repr=False)
    adres: str = field(repr=False)
    waznosc: int
    odstep: int


@dataclass(frozen=True)
class TokenAllegro:
    wartosc: str = field(repr=False)
    waznosc: int
    odswiezanie: str = field(default="", repr=False)


@dataclass(frozen=True)
class KontoAllegro:
    id: str
    login: str


@dataclass(frozen=True)
class SesjaAllegro:
    konto: KontoAllegro
    srodowisko: SrodowiskoAllegro
    token: str = field(repr=False)
    wygasa: float
    odswiezanie: str = field(default="", repr=False)
    aplikacja: AplikacjaAllegro | None = field(default=None, repr=False)


class StatusOfertyAllegro(Enum):
    SZKIC = "INACTIVE"
    AKTYWNA = "ACTIVE"
    AKTYWOWANA = "ACTIVATING"
    ZAKONCZONA = "ENDED"


@dataclass(frozen=True)
class LicznikiAllegro:
    aktywne: int
    szkice: int


@dataclass(frozen=True)
class SzkicAllegro:
    id: str
    tytul: str
    sku: str = ""
    cena: str = ""
    waluta: str = ""
    stan: int | None = None
    zdjecie: str = ""
    status: StatusOfertyAllegro = StatusOfertyAllegro.SZKIC


@dataclass(frozen=True)
class StronaSzkicowAllegro:
    szkice: tuple[SzkicAllegro, ...]
    lacznie: int
    offset: int
    limit: int


@dataclass(frozen=True)
class SzczegolySzkicuAllegro:
    id: str
    tytul: str
    sku: str
    cena: str
    waluta: str
    stan: int | None
    kategoria: str
    zdjecia: tuple[str, ...]
    sekcje: tuple[tuple[ElementPodgladu, ...], ...]
    status: StatusOfertyAllegro = StatusOfertyAllegro.SZKIC


@dataclass(frozen=True)
class ZapamietaneAllegro:
    aplikacja: AplikacjaAllegro = field(repr=False)
    konto: KontoAllegro
    odswiezanie: str = field(repr=False)


class MagazynAllegro(Protocol):
    def odczytaj(self) -> ZapamietaneAllegro | None: ...
    def zapisz(self, dane: ZapamietaneAllegro) -> None: ...
    def usun(self) -> None: ...


class APISesjiAllegro(Protocol):
    def rozpocznij(self, aplikacja: AplikacjaAllegro) -> KodUrzadzenia: ...
    def token(self, aplikacja: AplikacjaAllegro, kod: str) -> TokenAllegro: ...
    def odnow(self, aplikacja: AplikacjaAllegro, token: str) -> TokenAllegro: ...
    def konto(self, srodowisko: SrodowiskoAllegro, token: str) -> KontoAllegro: ...
    def szkice(self, sesja: SesjaAllegro, offset: int, limit: int) -> StronaSzkicowAllegro: ...
    def oferty(
        self,
        sesja: SesjaAllegro,
        status: StatusOfertyAllegro | None,
        offset: int,
        limit: int,
    ) -> StronaSzkicowAllegro: ...
    def oferta(self, sesja: SesjaAllegro, ident: str) -> SzczegolySzkicuAllegro: ...
    def szkic(self, sesja: SesjaAllegro, id_szkicu: str) -> SzczegolySzkicuAllegro: ...


class CzasMonotoniczny(Protocol):
    def teraz(self) -> float: ...


class PolaczAllegro:
    def __init__(
        self, api: APISesjiAllegro, czas: CzasMonotoniczny, magazyn: MagazynAllegro | None = None
    ) -> None:
        self._api, self._czas, self._magazyn = api, czas, magazyn
        self._blokada = RLock()
        self._blokada_licznikow = Lock()
        self._cache_licznikow: tuple[tuple[str, str, str], float, LicznikiAllegro] | None = None

    @property
    def mozna_zapamietac(self) -> bool:
        return self._magazyn is not None

    def zapamietaj(self, sesja: SesjaAllegro) -> None:
        with self._blokada:
            if self._magazyn is None or sesja.aplikacja is None or not sesja.odswiezanie:
                raise BladAllegro("MAGAZYN", "Nie można zapamiętać tego połączenia.")
            self._magazyn.zapisz(
                ZapamietaneAllegro(sesja.aplikacja, sesja.konto, sesja.odswiezanie)
            )

    def zapomnij(self) -> None:
        with self._blokada:
            if self._magazyn is not None:
                self._magazyn.usun()

    def przywroc(self) -> SesjaAllegro | None:
        with self._blokada:
            if self._magazyn is None:
                return None
            zapis = self._magazyn.odczytaj()
            if zapis is None:
                return None
            poczatek = self.teraz()
            token = self._api.odnow(zapis.aplikacja, zapis.odswiezanie)
            # Refresh token może rotować: zapis przed /me chroni nowy token
            # również wtedy, gdy sam odczyt profilu chwilowo się nie powiedzie.
            nowy = token.odswiezanie or zapis.odswiezanie
            self._magazyn.zapisz(ZapamietaneAllegro(zapis.aplikacja, zapis.konto, nowy))
            konto = self._api.konto(zapis.aplikacja.srodowisko, token.wartosc)
            if konto.id != zapis.konto.id:
                raise BladAllegro("KONTO", "Allegro zwróciło inne konto. Usuń zapisane połączenie.")
            wygasa = poczatek + token.waznosc
            if self.teraz() >= wygasa:
                raise BladAllegro("WYGASLA", "Sesja wygasła. Ponów połączenie.")
            return SesjaAllegro(
                konto, zapis.aplikacja.srodowisko, token.wartosc, wygasa, nowy, zapis.aplikacja
            )

    def teraz(self) -> float:
        return self._czas.teraz()

    def rozpocznij(self, aplikacja: AplikacjaAllegro) -> KodUrzadzenia:
        aplikacja.sprawdz()
        return self._api.rozpocznij(aplikacja)

    def sprawdz(self, aplikacja: AplikacjaAllegro, kod: str) -> SesjaAllegro:
        aplikacja.sprawdz()
        poczatek = self.teraz()
        token = self._api.token(aplikacja, kod)
        wygasa = poczatek + token.waznosc
        konto = self._api.konto(aplikacja.srodowisko, token.wartosc)
        if self.teraz() >= wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        return SesjaAllegro(
            konto, aplikacja.srodowisko, token.wartosc, wygasa, token.odswiezanie, aplikacja
        )

    def szkice(self, sesja: SesjaAllegro, offset: int = 0, limit: int = 50) -> StronaSzkicowAllegro:
        if self.teraz() >= sesja.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        if limit != 50 or offset < 0 or offset > 9950 or offset % limit:
            raise BladAllegro("STRONA", "Nieprawidłowa strona szkiców Allegro.")
        wynik = self._api.szkice(sesja, offset, limit)
        self._sprawdz_sesje(sesja)
        return wynik

    def _sprawdz_sesje(self, sesja: SesjaAllegro) -> None:
        if self.teraz() >= sesja.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")

    def oferty(
        self,
        sesja: SesjaAllegro,
        status: StatusOfertyAllegro | None,
        offset: int = 0,
        limit: int = 50,
    ) -> StronaSzkicowAllegro:
        self._sprawdz_sesje(sesja)
        if status is not None and not isinstance(status, StatusOfertyAllegro):
            raise BladAllegro("STAN", "Nieprawidłowy stan ofert Allegro.")
        if type(offset) is not int or limit != 50 or not 0 <= offset <= 9950 or offset % limit:
            raise BladAllegro("STRONA", "Nieprawidłowa strona ofert Allegro.")
        wynik = self._api.oferty(sesja, status, offset, limit)
        self._sprawdz_sesje(sesja)
        return wynik

    def oferta(self, sesja: SesjaAllegro, ident: str) -> SzczegolySzkicuAllegro:
        self._sprawdz_sesje(sesja)
        if not ident.isascii() or not ident.isdigit() or len(ident) > 100:
            raise BladAllegro("OFERTA", "Nieprawidłowy identyfikator oferty Allegro.")
        wynik = self._api.oferta(sesja, ident)
        self._sprawdz_sesje(sesja)
        return wynik

    def liczniki(self, sesja: SesjaAllegro, *, odswiez: bool = False) -> LicznikiAllegro:
        self._sprawdz_sesje(sesja)
        klucz = (sesja.srodowisko.value, sesja.konto.id, sha256(sesja.token.encode()).hexdigest())
        with self._blokada_licznikow:
            self._sprawdz_sesje(sesja)
            cache = self._cache_licznikow
            if (
                not odswiez
                and cache is not None
                and cache[0] == klucz
                and self.teraz() - cache[1] < 30
            ):
                return cache[2]
            self._cache_licznikow = None
            aktywne = self._api.oferty(sesja, StatusOfertyAllegro.AKTYWNA, 0, 1).lacznie
            szkice = self._api.oferty(sesja, StatusOfertyAllegro.SZKIC, 0, 1).lacznie
            self._sprawdz_sesje(sesja)
            wynik = LicznikiAllegro(aktywne, szkice)
            self._cache_licznikow = (klucz, self.teraz(), wynik)
            return wynik

    def szkic(self, sesja: SesjaAllegro, id_szkicu: str) -> SzczegolySzkicuAllegro:
        if self.teraz() >= sesja.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        if not id_szkicu.isascii() or not id_szkicu.isdigit() or len(id_szkicu) > 100:
            raise BladAllegro("SZKIC", "Nieprawidłowy identyfikator szkicu Allegro.")
        wynik = self._api.szkic(sesja, id_szkicu)
        if self.teraz() >= sesja.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        return wynik


@dataclass(frozen=True)
class OdpowiedzAllegro:
    status: int
    dane: bytes = field(repr=False)
    lokalizacja: str = ""
    odstep: int = 0


class TransportAllegro(Protocol):
    def wyslij(
        self, metoda: str, url: str, naglowki: dict[str, str], dane: bytes | None
    ) -> OdpowiedzAllegro: ...
