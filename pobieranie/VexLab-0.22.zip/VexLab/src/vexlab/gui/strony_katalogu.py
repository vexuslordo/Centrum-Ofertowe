"""Kontrolki stron i wybór produktów niezależny od aktualnej strony Qt."""

from collections.abc import Callable
from uuid import UUID

from PySide6.QtCore import QItemSelection, QItemSelectionModel, QModelIndex, Qt, Signal
from PySide6.QtGui import QKeyEvent, QMouseEvent
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLabel, QPushButton, QTableView, QWidget

from vexlab.gui.katalog import ModelProduktow
from vexlab.przypadki_uzycia.katalog import ProduktDTO, StronaKatalogu


class TabelaKatalogu(QTableView):
    def __init__(
        self, wszystkie: Callable[[QTableView], None], odznacz: Callable[[QTableView], None]
    ) -> None:
        super().__init__()
        self.wszystkie, self.odznacz = wszystkie, odznacz

    def selectAll(self) -> None:
        self.wszystkie(self)

    def clearSelection(self) -> None:
        self.odznacz(self)

    def mousePressEvent(self, event: QMouseEvent) -> None:
        indeks = self.indexAt(event.position().toPoint())
        bez_modyfikatorow = not event.modifiers() & (
            Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier
        )
        if bez_modyfikatorow and (
            event.button() == Qt.MouseButton.LeftButton
            or (
                event.button() == Qt.MouseButton.RightButton
                and not self.selectionModel().isRowSelected(indeks.row(), QModelIndex())
            )
        ):
            self.odznacz(self)
        super().mousePressEvent(event)

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key.Key_Escape:
            self.odznacz(self)
            event.accept()
            return
        if (
            event.key() in (Qt.Key.Key_Up, Qt.Key.Key_Down, Qt.Key.Key_Home, Qt.Key.Key_End)
            and not event.modifiers()
        ):
            self.odznacz(self)
        super().keyPressEvent(event)


class PasekStron(QWidget):
    strona = Signal(int)
    rozmiar = Signal(int)

    def __init__(self) -> None:
        super().__init__()
        self.numer = 0
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.poprzednia = QPushButton("← Poprzednia")
        self.nastepna = QPushButton("Następna →")
        self.opis = QLabel("Odczytywanie…")
        self.opis.setWordWrap(True)
        self.opis.setAccessibleName("Bieżąca strona katalogu")
        self.ile = QComboBox()
        self.ile.setAccessibleName("Liczba produktów na stronie")
        for n in (100, 250, 500):
            self.ile.addItem(f"{n} na stronę", n)
        self.poprzednia.clicked.connect(lambda: self.strona.emit(self.numer - 1))
        self.nastepna.clicked.connect(lambda: self.strona.emit(self.numer + 1))
        self.ile.currentIndexChanged.connect(lambda: self.rozmiar.emit(self.ile.currentData()))
        layout.addWidget(self.poprzednia)
        layout.addWidget(self.opis, 1)
        layout.addWidget(self.ile)
        layout.addWidget(self.nastepna)
        self.setEnabled(False)

    def ustaw(self, dane: StronaKatalogu) -> None:
        self.numer = dane.numer
        stron = max(1, (dane.liczba + dane.rozmiar - 1) // dane.rozmiar)
        od = dane.numer * dane.rozmiar + 1 if dane.liczba else 0
        do = dane.numer * dane.rozmiar + len(dane.produkty)
        self.opis.setText(f"{dane.numer + 1} / {stron}  •  {od}–{do} z {dane.liczba}")
        self.ile.blockSignals(True)
        self.ile.setCurrentIndex(self.ile.findData(dane.rozmiar))
        self.ile.blockSignals(False)
        self.setEnabled(True)
        self.poprzednia.setEnabled(dane.numer > 0)
        self.nastepna.setEnabled(dane.numer + 1 < stron)


class WyborKatalogu:
    def __init__(
        self, model: ModelProduktow, produkt: Callable[[QModelIndex], ProduktDTO | None]
    ) -> None:
        self.model, self.produkt = model, produkt
        self.wybrane: dict[QTableView, dict[UUID, ProduktDTO]] = {}
        self.przywracanie = False

    def produkty(self, tabela: QTableView) -> tuple[ProduktDTO, ...]:
        wybor = self.wybrane.setdefault(tabela, {})
        if not self.przywracanie:
            for p in self.model.produkty:
                wybor.pop(p.id, None)
            for indeks in tabela.selectionModel().selectedRows(1):
                produkt = self.produkt(indeks)
                if produkt is not None:
                    wybor[produkt.id] = produkt
        return tuple(wybor.values())

    def identyfikatory(self, tabele: list[QTableView]) -> tuple[UUID, ...]:
        return tuple(dict.fromkeys(p.id for t in tabele for p in self.produkty(t)))

    def wyczysc(self, tabela: QTableView) -> None:
        self.wybrane[tabela] = {}
        tabela.selectionModel().clearSelection()

    def przywroc(self, tabele: list[QTableView], aktualne: tuple[ProduktDTO, ...]) -> None:
        nowe = {p.id: p for p in aktualne}
        for tabela in tabele:
            stare = self.wybrane.get(tabela, {})
            self.wybrane[tabela] = {pid: nowe[pid] for pid in stare if pid in nowe}
            self._ustaw_widoczne(tabela)

    def ustaw(self, tabela: QTableView, produkty: tuple[ProduktDTO, ...]) -> None:
        self.wybrane[tabela] = {p.id: p for p in produkty}
        self.przywracanie = True
        try:
            self._ustaw_widoczne(tabela)
        finally:
            self.przywracanie = False

    def _ustaw_widoczne(self, tabela: QTableView) -> None:
        wybor = QItemSelection()
        model = tabela.model()
        for i in range(model.rowCount()):
            p = self.produkt(model.index(i, 1))
            if p is not None and p.id in self.wybrane[tabela]:
                wybor.select(model.index(i, 0), model.index(i, model.columnCount() - 1))
        tabela.selectionModel().select(
            wybor,
            QItemSelectionModel.SelectionFlag.ClearAndSelect
            | QItemSelectionModel.SelectionFlag.Rows,
        )
        if wybor.indexes():
            tabela.selectionModel().setCurrentIndex(
                wybor.indexes()[0], QItemSelectionModel.SelectionFlag.NoUpdate
            )
