"""Sprawy posprzedażowe w zakładce Wiadomości. Dane wyłącznie w RAM."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import QSignalBlocker, Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.prezentacja_wiadomosci import data_wiadomosci, tekst_wiadomosci
from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.sprawy_allegro import (
    LIMIT_SPRAW,
    MAX_OFFSET_SPRAW,
    OdczytajSprawyAllegro,
    RodzajSprawy,
    SprawaAllegro,
    StronaHistoriiSprawy,
    StronaSpraw,
)

STATUSY_SPRAW = {
    "DISPUTE_CLOSED": "Dyskusja zamknięta",
    "DISPUTE_ONGOING": "Dyskusja w toku",
    "DISPUTE_UNRESOLVED": "Dyskusja nierozwiązana",
    "CLAIM_SUBMITTED": "Reklamacja zgłoszona",
    "CLAIM_ACCEPTED": "Reklamacja przyjęta",
    "CLAIM_REJECTED": "Reklamacja odrzucona",
    "CREATED": "Zwrot zgłoszony",
    "DISPATCHED": "Przesyłka nadana",
    "IN_TRANSIT": "W transporcie",
    "DELIVERED": "Przesyłka dostarczona",
    "FINISHED": "Zwrot zakończony",
    "FINISHED_APT": "Zakończony przez Allegro Protect",
    "REJECTED": "Zwrot odrzucony",
    "COMMISSION_REFUND_CLAIMED": "Wniosek o zwrot prowizji",
    "COMMISSION_REFUNDED": "Prowizja zwrócona",
    "WAREHOUSE_DELIVERED": "Dostarczono do magazynu Allegro",
    "WAREHOUSE_VERIFICATION": "Weryfikacja w magazynie",
}
ROLE_SPRAW = {
    "BUYER": "Kupujący",
    "SELLER": "Sprzedający",
    "ADMIN": "Allegro",
    "SYSTEM": "System",
    "FULFILLMENT": "Magazyn Allegro",
}


def szczegoly_sprawy(row: SprawaAllegro) -> str:
    lines = [
        row.rodzaj.value + " · " + (row.numer or row.id),
        "Status: " + STATUSY_SPRAW.get(row.status, row.status),
        "Kupujący: " + (row.login or "Brak loginu"),
        "Utworzono / otwarto: " + data_wiadomosci(row.kiedy),
    ]
    if row.zamowienie:
        lines.append("Zamówienie: " + row.zamowienie)
    if row.termin:
        lines.append("Termin decyzji: " + data_wiadomosci(row.termin))
    lines += ["", tekst_wiadomosci(row.temat)]
    if row.opis:
        lines += ["", tekst_wiadomosci(row.opis)]
    for title, values in (
        ("Pozycje zwrotu", row.pozycje),
        ("Przesyłki", row.przesylki),
        ("Oczekiwania kupującego", row.oczekiwania),
        ("Załączniki (bez pobierania)", row.zalaczniki),
    ):
        if values:
            lines += ["", title, *[tekst_wiadomosci(v) for v in values]]
    return "\n".join(lines)


class PanelSprawAllegro(QWidget):
    statystyki = Signal(object, int)

    def __init__(
        self, uc: OdczytajSprawyAllegro, uruchom: Uruchom, sesja: Callable[[], SesjaAllegro | None]
    ) -> None:
        super().__init__()
        self.uc, self.uruchom, self.sesja = uc, uruchom, sesja
        self._sesja = sesja()
        self.rodzaj = RodzajSprawy.ZWROT
        self._nr = self._det_nr = 0
        self.zajete = False
        self._wiecej = False
        self._blad = False
        self._offset = 0
        self._rows: tuple[SprawaAllegro, ...] = ()
        self._wybrana: SprawaAllegro | None = None
        self._historia = 0
        self._wiecej_historii = False
        self._detale_trwaja = False
        self._fraza = ""
        self._odczytano = False
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.opis = QLabel()
        self.opis.setWordWrap(True)
        layout.addWidget(self.opis)
        split = QSplitter()
        left = QWidget()
        lb = QVBoxLayout(left)
        lb.setContentsMargins(0, 0, 0, 0)
        self.lista = QListWidget()
        self.lista.setAccessibleName("Sprawy posprzedażowe Allegro")
        self.lista.setWordWrap(True)
        self.lista.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        lb.addWidget(self.lista, 1)
        self.ponow = QPushButton("Ponów wczytywanie")
        self.ponow.hide()
        lb.addWidget(self.ponow)
        self.ponow.clicked.connect(
            lambda: self._pobierz(self._offset + LIMIT_SPRAW if self._odczytano else 0)
        )
        split.addWidget(left)
        right = QWidget()
        rb = QVBoxLayout(right)
        rb.setContentsMargins(0, 0, 0, 0)
        self.detale = QPlainTextEdit()
        self.detale.setFont(self.font())
        self.detale.setReadOnly(True)
        self.detale.setUndoRedoEnabled(False)
        self.detale.setPlaceholderText("Wybierz sprawę, aby odczytać szczegóły.")
        self.detale.setAccessibleName("Szczegóły sprawy Allegro")
        rb.addWidget(self.detale, 1)
        self.chat = QPlainTextEdit()
        self.chat.setFont(self.font())
        self.chat.setReadOnly(True)
        self.chat.setUndoRedoEnabled(False)
        self.chat.setPlaceholderText("Korespondencja i zdarzenia sprawy pojawią się po odczycie.")
        self.chat.setAccessibleName("Historia dyskusji lub reklamacji Allegro")
        rb.addWidget(self.chat, 1)
        nav = QHBoxLayout()
        self.odswiez = QPushButton("Odśwież szczegóły")
        self.odswiez.clicked.connect(self.odswiez_wybrana)
        self.wczesniej, self.dalej = (
            QPushButton("← Poprzednie wpisy"),
            QPushButton("Kolejne wpisy →"),
        )
        nav.addWidget(self.odswiez)
        nav.addStretch(1)
        nav.addWidget(self.wczesniej)
        nav.addWidget(self.dalej)
        self.wczesniej.clicked.connect(
            lambda: self._pobierz_historie(max(0, self._historia - LIMIT_SPRAW))
        )
        self.dalej.clicked.connect(lambda: self._pobierz_historie(self._historia + LIMIT_SPRAW))
        rb.addLayout(nav)
        split.addWidget(right)
        split.setSizes([330, 850])
        layout.addWidget(split, 1)
        self.info = QLabel("Wybierz rodzaj sprawy.")
        self.info.setTextFormat(Qt.TextFormat.PlainText)
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        self.lista.currentItemChanged.connect(self._wybierz)
        self.lista.verticalScrollBar().valueChanged.connect(self._scroll)
        self._przyciski()

    @property
    def liczba(self) -> int:
        return len(self._rows) if self._odczytano else -1

    def _aktualne(self) -> bool:
        return self._sesja is not None and self.sesja() is self._sesja

    def wyczysc(self) -> None:
        self._nr += 1
        self._det_nr += 1
        self.zajete = self._detale_trwaja = False
        self._wiecej = self._blad = self._odczytano = False
        self._rows = ()
        self._fraza = ""
        self._wybrana = None
        self._offset = self._historia = 0
        self._wiecej_historii = False
        with QSignalBlocker(self.lista):
            self.lista.clear()
        self.detale.clear()
        self.chat.clear()
        self.info.clear()
        self._przyciski()

    def polaczenie(self) -> None:
        if self.sesja() is not self._sesja:
            self.wyczysc()
            self._sesja = self.sesja()
            self.info.setText("Zmieniono połączenie. Odśwież sprawy bieżącego konta.")

    def otworz(self, rodzaj: RodzajSprawy) -> None:
        self.polaczenie()
        if rodzaj != self.rodzaj:
            self.wyczysc()
            self.rodzaj = rodzaj
        self.opis.setText(
            rodzaj.value + " · dane z Allegro · wczytywanie przy przewijaniu · odczyt API beta"
        )
        self.chat.setVisible(rodzaj != RodzajSprawy.ZWROT)
        self.wczesniej.setVisible(rodzaj != RodzajSprawy.ZWROT)
        self.dalej.setVisible(rodzaj != RodzajSprawy.ZWROT)
        if not self._odczytano:
            self._pobierz(0)
        self._przyciski()

    def odswiez_liste(self) -> None:
        if not self.zajete:
            self.wyczysc()
            self._pobierz(0)

    def filtruj(self, fraza: str) -> None:
        self._fraza = fraza.strip().casefold()
        self._pokaz()

    def _pobierz(self, offset: int) -> None:
        session = self._sesja
        if self.zajete or not self._aktualne() or session is None or offset > MAX_OFFSET_SPRAW:
            return
        self._nr += 1
        nr, rodzaj = self._nr, self.rodzaj
        self.zajete, self._blad = True, False
        self.info.setText("Wczytywanie spraw…")
        self._przyciski()

        def ok(value: object) -> None:
            if not self._aktualne() or nr != self._nr or rodzaj != self.rodzaj:
                return
            page = cast(StronaSpraw, value)
            merged = {r.id: r for r in self._rows}
            merged.update((r.id, r) for r in page.pozycje)
            self._rows = tuple(merged.values())
            self._offset, self._wiecej = offset, page.wiecej and offset < MAX_OFFSET_SPRAW
            self.zajete, self._odczytano = False, True
            self._pokaz()
            self.info.setText(
                "Wczytano: "
                + str(len(self._rows))
                + (". Przewiń w dół po kolejne sprawy." if self._wiecej else ". Koniec listy.")
            )
            self._przyciski()

        def error(kod: str, text: str) -> None:
            if not self._aktualne() or nr != self._nr:
                return
            self.zajete, self._blad = False, True
            self.info.setText(text)
            self._przyciski()

        self.uruchom(lambda: self.uc.lista(session, rodzaj, offset), ok, error)

    def _pokaz(self) -> None:
        bar = self.lista.verticalScrollBar()
        value = bar.value()
        with QSignalBlocker(self.lista), QSignalBlocker(bar):
            self.lista.clear()
            for row in self._rows:
                text = " ".join((row.login, row.numer, row.temat, row.status, row.zamowienie))
                if self._fraza and self._fraza not in tekst_wiadomosci(text).casefold():
                    continue
                label = (row.numer or row.id) + " · " + (row.login or "Brak loginu")
                item = QListWidgetItem(
                    label
                    + "\n"
                    + STATUSY_SPRAW.get(row.status, row.status)
                    + "\n"
                    + tekst_wiadomosci(row.temat)
                )
                item.setData(Qt.ItemDataRole.UserRole, row)
                self.lista.addItem(item)
                if self._wybrana is not None and self._wybrana.id == row.id:
                    self.lista.setCurrentItem(item)
            self.lista.doItemsLayout()
            bar.setValue(value)

    def _scroll(self, value: int) -> None:
        bar = self.lista.verticalScrollBar()
        if self._wiecej and not self._blad and bar.maximum() > 0 and value >= bar.maximum() - 80:
            self._pobierz(self._offset + LIMIT_SPRAW)

    def _wybierz(self) -> None:
        item = self.lista.currentItem()
        row = item.data(Qt.ItemDataRole.UserRole) if item else None
        if not isinstance(row, SprawaAllegro):
            return
        self._det_nr += 1
        self._detale_trwaja = False
        self._historia = 0
        self._wiecej_historii = False
        self._wybrana = row
        self.detale.setPlainText(szczegoly_sprawy(row))
        self.chat.clear()
        self.odswiez_wybrana()

    def odswiez_wybrana(self) -> None:
        row, session = self._wybrana, self._sesja
        if row is None or session is None or not self._aktualne() or self._detale_trwaja:
            return
        self._det_nr += 1
        nr = self._det_nr
        self._detale_trwaja = True
        self._przyciski()

        def ok(value: object) -> None:
            if not self._aktualne() or nr != self._det_nr:
                return
            self._detale_trwaja = False
            result = cast(SprawaAllegro, value)
            self._wybrana = result
            self.detale.setPlainText(szczegoly_sprawy(result))
            self._przyciski()
            if result.rodzaj != RodzajSprawy.ZWROT:
                self._pobierz_historie(self._historia)

        self.uruchom(
            lambda: self.uc.szczegoly(session, row.rodzaj, row.id), ok, self._blad_szczegolow(nr)
        )

    def _blad_szczegolow(self, nr: int) -> Callable[[str, str], None]:
        def error(kod: str, text: str) -> None:
            if self._aktualne() and nr == self._det_nr:
                self._detale_trwaja = False
                self.info.setText(text)
                self._przyciski()

        return error

    def _pobierz_historie(self, offset: int) -> None:
        row, session = self._wybrana, self._sesja
        if (
            row is None
            or row.rodzaj == RodzajSprawy.ZWROT
            or session is None
            or not self._aktualne()
            or self._detale_trwaja
        ):
            return
        self._det_nr += 1
        nr = self._det_nr
        self._detale_trwaja = True
        self.chat.clear()
        self._przyciski()

        def ok(value: object) -> None:
            if not self._aktualne() or nr != self._det_nr:
                return
            page = cast(StronaHistoriiSprawy, value)
            self._historia, self._wiecej_historii = offset, page.wiecej
            blocks = []
            for entry in page.pozycje:
                text = (
                    f"{entry.autor} · {ROLE_SPRAW.get(entry.rola, entry.rola)} · "
                    f"{data_wiadomosci(entry.kiedy)}\n{tekst_wiadomosci(entry.tekst)}"
                )
                if entry.zalaczniki:
                    text += "\nZałączniki (bez pobierania): " + ", ".join(entry.zalaczniki)
                blocks.append(text)
            self.chat.setPlainText(
                "\n\n".join(blocks) if blocks else "Brak wpisów na tej stronie historii."
            )
            self._detale_trwaja = False
            self._przyciski()

        self.uruchom(
            lambda: self.uc.historia(session, row.rodzaj, row.id, offset),
            ok,
            self._blad_szczegolow(nr),
        )

    def _przyciski(self) -> None:
        self.ponow.setVisible(self._blad)
        self.ponow.setEnabled(not self.zajete and self._aktualne())
        self.odswiez.setEnabled(self._wybrana is not None and not self._detale_trwaja)
        self.wczesniej.setEnabled(self._historia > 0 and not self._detale_trwaja)
        self.dalej.setEnabled(self._wiecej_historii and not self._detale_trwaja)
        self.statystyki.emit(self.rodzaj, self.liczba)
