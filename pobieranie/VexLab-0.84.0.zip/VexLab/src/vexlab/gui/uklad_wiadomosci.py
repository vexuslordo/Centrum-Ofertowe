"""Czterokolumnowy układ Wiadomości 2.0. Wyłącznie warstwa widoku."""

from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QPalette, QResizeEvent
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.kafelek_kpi import KafelekKPI
from vexlab.gui.panele_wiadomosci import (
    EdytorOdpowiedzi,
    PanelKlienta,
    PanelVexAI,
    napis,
    przewijany_panel,
    przycisk_podgladu,
)
from vexlab.gui.prezentacja_wiadomosci import DelegatRozmow, WidokRozmowy
from vexlab.przypadki_uzycia.powloka import ODSWIEZANIE_WIADOMOSCI


def _panel(name: str) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName(name)
    box = QVBoxLayout(frame)
    box.setContentsMargins(10, 10, 10, 10)
    box.setSpacing(8)
    return frame, box


class WidokCentrumWiadomosci(QWidget):
    def __init__(self, login: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("centrumWiadomosci")
        self._tryb = -1
        self._konwersacja = False
        self._krotki: bool | None = None
        box = QVBoxLayout(self)
        box.setContentsMargins(14, 14, 14, 10)
        box.setSpacing(10)
        top = QHBoxLayout()
        icon = QLabel()
        icon.setPixmap(ikona("poczta", "#3B82F6").pixmap(24, 24))
        top.addWidget(icon)
        top.addWidget(napis("Wiadomości", "tytulCentrumWiadomosci"))
        self.opis = napis(
            "Obsługa rozmów Allegro • lokalne filtry wczytanych rozmów • "
            "pozostałe kanały w przygotowaniu",
            "opisWiadomosci",
        )
        top.addWidget(self.opis, 1)
        self.klient_button = QPushButton("Klient")
        self.ai_button = QPushButton("VexAI · BETA")
        for button in (self.klient_button, self.ai_button):
            button.setCheckable(True)
            top.addWidget(button)
        self.czestotliwosc = QComboBox()
        self.czestotliwosc.setAccessibleName("Częstotliwość odświeżania wybranego czatu")
        self.czestotliwosc.setToolTip(
            "Automatyczny odczyt widocznego, wybranego czatu. Bez zmiany szkicu."
        )
        for minutes in ODSWIEZANIE_WIADOMOSCI:
            self.czestotliwosc.addItem(
                "Auto: wyłączone" if not minutes else f"Auto: {minutes} min", minutes
            )
        top.addWidget(self.czestotliwosc)
        self.okres = QComboBox()
        for label, days in (
            ("Wszystkie daty", 0),
            ("Ostatni dzień", 1),
            ("Ostatnie 7 dni", 7),
            ("Ostatnie 30 dni", 30),
        ):
            self.okres.addItem(label, days)
        self.okres.setToolTip("Filtr dat ostatniej aktywności wśród wczytanych rozmów.")
        top.addWidget(self.okres)
        box.addLayout(top)
        kpi_row = QHBoxLayout()
        kpi_row.setSpacing(10)
        self.kpi: dict[str, KafelekKPI] = {}
        for key, title, symbol, color in (
            ("rozmowy", "Wczytane rozmowy", "poczta", "#3B82F6"),
            ("nieprzeczytane", "Nieodczytane rozmowy", "poczta", "#06B6D4"),
            ("oczekujace", "Oczekujące odpowiedzi", "kalendarz", "#F59E0B"),
            ("rozwiazane", "Rozwiązane (24h)", "zaznacz", "#10B981"),
            ("czas", "Średni czas odpowiedzi", "wykres", "#3B82F6"),
        ):
            caption = (
                "Wczytane do widoku" if key in ("rozmowy", "nieprzeczytane") else "Brak danych"
            )
            card = KafelekKPI(title, "produkty", caption, symbol="Produkty", akcent=color)
            card.ikona_tla = ikona(symbol, color)
            card.setMinimumWidth(0)
            card.setToolTip(
                "Rozmowy wczytane do widoku, nie cała skrzynka."
                if key in ("rozmowy", "nieprzeczytane")
                else "Brak danych w obecnym odczycie API. Nie obliczamy zastępczej wartości."
            )
            self.kpi[key] = card
            kpi_row.addWidget(card, 1)
        box.addLayout(kpi_row)
        self.filter_host = QWidget()
        filters = QHBoxLayout(self.filter_host)
        filters.setContentsMargins(0, 0, 0, 0)
        filters.setSpacing(6)
        self.filtry: dict[str, QPushButton] = {}
        for key, label in (
            ("wszystkie", "Wszystkie"),
            ("nieodczytane", "Nieodczytane"),
            ("oczekujace", "Oczekujące"),
            ("zwroty", "Zwroty"),
            ("reklamacje", "Reklamacje"),
            ("spory", "Otwarte dyskusje"),
            ("archiwum", "Archiwum"),
        ):
            button = QPushButton(label)
            button.setCheckable(True)
            button.setProperty("filtrWiadomosci", True)
            if key not in ("wszystkie", "nieodczytane"):
                button.setEnabled(False)
                button.setToolTip("Kategoria nie jest dostępna w obecnym odczycie rozmów.")
                button.setText(label + "  —")
            self.filtry[key] = button
            filters.addWidget(button)
        self.filtry["wszystkie"].setChecked(True)
        filters.addStretch(1)
        self.search_host = QWidget()
        search = QHBoxLayout(self.search_host)
        search.setContentsMargins(0, 0, 0, 0)
        self.filtr = QLineEdit(login)
        self.filtr.setClearButtonEnabled(True)
        self.filtr.setPlaceholderText("Szukaj loginu lub pobranego fragmentu • wczytane rozmowy…")
        self.filtr.setAccessibleName("Wyszukiwanie wśród wczytanych rozmów")
        search.addWidget(self.filtr, 1)
        self.odswiez = QPushButton()
        self.odswiez.setToolTip("Odśwież rozmowy")
        self.odswiez.setAccessibleName("Odśwież rozmowy")
        self.odswiez.setFixedWidth(34)
        self.odswiez.setIcon(ikona("synchronizacja", "#60A5FA"))
        search.addWidget(self.odswiez)
        self.toolbar = QGridLayout()
        self.toolbar.setContentsMargins(0, 0, 0, 0)
        self.toolbar.addWidget(self.filter_host, 0, 0)
        self.toolbar.addWidget(self.search_host, 0, 1)
        self.toolbar.setColumnStretch(1, 1)
        box.addLayout(self.toolbar)
        self.split = QSplitter()
        self.split.setChildrenCollapsible(False)
        self.lewy, lb = _panel("listaWiadomosci")
        header = QHBoxLayout()
        self.strona_rozmow = napis("Rozmowy", "naglowekKlienta")
        header.addWidget(self.strona_rozmow, 1)
        newest = QLabel("Najnowsze ↓")
        newest.setObjectName("opisWiadomosci")
        header.addWidget(newest)
        lb.addLayout(header)
        self.lista = QListWidget()
        self.lista.setItemDelegate(DelegatRozmow(self.lista))
        self.lista.setMouseTracking(True)
        self.lista.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.lista.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.lista.setAccessibleName("Rozmowy Allegro")
        lb.addWidget(self.lista, 1)
        self.pusto = napis("Odśwież skrzynkę, aby pobrać rozmowy.", "opisWiadomosci")
        lb.addWidget(self.pusto)
        self.ladowanie_listy = napis("", "opisWiadomosci")
        lb.addWidget(self.ladowanie_listy)
        self.ponow_liste = QPushButton("Ponów wczytywanie")
        self.ponow_liste.hide()
        lb.addWidget(self.ponow_liste)
        self.split.addWidget(self.lewy)
        self.klient = PanelKlienta()
        self.klient_scroll = przewijany_panel(self.klient)
        self.split.addWidget(self.klient_scroll)
        self.konwersacja, rb = _panel("konwersacjaWiadomosci")
        header = QHBoxLayout()
        self.wroc = QPushButton("← Rozmowy")
        self.wroc.clicked.connect(lambda: self.pokaz_konwersacje(False))
        header.addWidget(self.wroc)
        self.tytul = napis("Wybierz rozmowę", "naglowekSekcjiWiadomosci")
        header.addWidget(self.tytul, 1)
        self.odswiez_rozmowe = QPushButton("Odśwież")
        self.odswiez_rozmowe.setToolTip("Odśwież bieżącą stronę wiadomości")
        header.addWidget(self.odswiez_rozmowe)
        rb.addLayout(header)
        actions = QHBoxLayout()
        for label in ("Oznacz jako rozwiązane", "Dodaj tag", "Powiąż zamówienie"):
            actions.addWidget(przycisk_podgladu(label))
        rb.addLayout(actions)
        self.tresc = WidokRozmowy()
        self.tresc.setAccessibleName("Treść rozmowy Allegro")
        rb.addWidget(self.tresc, 1)
        nav = QHBoxLayout()
        self.nowsze, self.starsze = QPushButton("← Nowsze"), QPushButton("Starsze →")
        nav.addWidget(self.nowsze)
        self.strona_wiadomosci = napis("Wiadomości · —", "opisWiadomosci")
        nav.addWidget(self.strona_wiadomosci, 1)
        nav.addWidget(self.starsze)
        rb.addLayout(nav)
        self.edytor_button = QPushButton("Przygotuj odpowiedź / notatkę")
        self.edytor_button.setCheckable(True)
        self.edytor_button.setToolTip("Roboczo w pamięci sesji, bez wysyłania.")
        rb.addWidget(self.edytor_button)
        self.edytor = EdytorOdpowiedzi()
        self.edytor_button.toggled.connect(self.edytor.setVisible)
        rb.addWidget(self.edytor)
        self.split.addWidget(self.konwersacja)
        self.vexai = PanelVexAI()
        self.ai_scroll = przewijany_panel(self.vexai)
        self.split.addWidget(self.ai_scroll)
        self.split.setSizes([260, 205, 530, 270])
        for i in (0, 1, 3):
            self.split.setStretchFactor(i, 0)
        self.split.setStretchFactor(2, 1)
        self.tresc_zrodla = QStackedWidget()
        self.tresc_zrodla.addWidget(self.split)
        box.addWidget(self.tresc_zrodla, 1)
        self.stan = napis("Nie pobrano rozmów.", "opisWiadomosci")
        box.addWidget(self.stan)
        self.klient_button.toggled.connect(self.klient_scroll.setVisible)
        self.ai_button.toggled.connect(self.ai_scroll.setVisible)
        self.vexai.zamknij.connect(lambda: self.ai_button.setChecked(False))
        self._motyw()

    def pokaz_konwersacje(self, selected: bool) -> None:
        self._konwersacja = selected
        if self.width() < 720:
            self.lewy.setVisible(not selected)
            self.konwersacja.setVisible(selected)
        else:
            self.lewy.show()
            self.konwersacja.show()
        self.wroc.setVisible(self.width() < 720 and selected)

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        mode = 4 if self.width() >= 1250 else 3 if self.width() >= 950 else 2
        if mode != self._tryb:
            self._tryb = mode
            self.klient_button.setChecked(mode >= 3)
            self.ai_button.setChecked(mode == 4)
        if self.width() >= 1100:
            self.toolbar.addWidget(self.search_host, 0, 1)
        else:
            self.toolbar.addWidget(self.search_host, 1, 0, 1, 2)
        short = self.height() < 650
        self.edytor_button.setVisible(short)
        if short != self._krotki:
            self._krotki = short
            self.edytor_button.setChecked(not short)
            self.edytor.setVisible(not short)
        self.pokaz_konwersacje(self._konwersacja)

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.PaletteChange and hasattr(self, "split"):
            self._motyw()

    def _motyw(self) -> None:
        dark = self.palette().color(QPalette.ColorRole.Window).lightness() < 128
        panel, border, muted, foreground = (
            ("#0B1424", "#1D304B", "#91A5C8", "#E6ECFF")
            if dark
            else ("#FFFFFF", "#D8E3F1", "#526580", "#172235")
        )
        style = f"""
            QWidget#centrumWiadomosci QFrame#listaWiadomosci,
            QWidget#centrumWiadomosci QFrame#klientWiadomosci,
            QWidget#centrumWiadomosci QFrame#konwersacjaWiadomosci,
            QWidget#centrumWiadomosci QFrame#vexaiWiadomosci,
            QWidget#centrumWiadomosci QFrame#edytorWiadomosci {{
                background:{panel};border:1px solid {border};border-radius:10px;
            }}
            QWidget#centrumWiadomosci QLabel {{background:transparent;border:0;color:{foreground};}}
            QWidget#centrumWiadomosci QTabBar::tab {{
                padding:7px 8px;min-width:0;font-size:11px;
            }}
            QWidget#centrumWiadomosci QLabel#opisWiadomosci {{color:{muted};font-size:10px;}}
            QWidget#centrumWiadomosci QLabel#tytulCentrumWiadomosci {{
                font-size:23px;font-weight:600;
            }}
            QWidget#centrumWiadomosci QLabel#naglowekKlienta {{font-size:15px;font-weight:600;}}
            QWidget#centrumWiadomosci QLabel#naglowekSekcjiWiadomosci {{
                font-size:12px;font-weight:600;
            }}
            QWidget#centrumWiadomosci QLabel#liczbaWiadomosci {{
                font-size:22px;font-weight:600;font-family:"JetBrains Mono";
            }}
            QWidget#centrumWiadomosci QLabel#avatarKlienta {{
                background:#2849B8;color:white;border-radius:23px;font-size:22px;
            }}
            QWidget#centrumWiadomosci QLabel#badgeVexAI {{
                background:#5631C8;color:white;border-radius:5px;padding:3px;
            }}
            QWidget#centrumWiadomosci QListWidget {{background:transparent;border:0;padding:0;}}
            QWidget#centrumWiadomosci QPushButton[filtrWiadomosci="true"]:checked {{
                background:#124BC4;color:white;border:1px solid #3B82F6;
            }}
            QWidget#centrumWiadomosci QPushButton#przyciskWyslijWiadomosc {{
                background:#1857C6;color:#B8D2FF;
            }}
        """
        if self.styleSheet() != style:
            self.setStyleSheet(style)
