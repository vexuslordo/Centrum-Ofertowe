"""Centrum wiadomości: odczyt stron, bez lokalnej kopii i operacji zapisu."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import QDateTime, QEvent, QObject, QSignalBlocker, Qt, QTimer, Signal
from PySide6.QtGui import QWheelEvent
from PySide6.QtWidgets import QDialog, QListWidgetItem, QPushButton, QVBoxLayout, QWidget

from vexlab.gui.prezentacja_wiadomosci import data_wiadomosci, tekst_wiadomosci
from vexlab.gui.producenci import Uruchom
from vexlab.gui.sprawy_allegro import PanelSprawAllegro
from vexlab.gui.uklad_wiadomosci import WidokCentrumWiadomosci
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.powloka import sprawdz_odswiezanie_wiadomosci
from vexlab.przypadki_uzycia.sprawy_allegro import OdczytajSprawyAllegro, RodzajSprawy
from vexlab.przypadki_uzycia.wiadomosci_allegro import (
    MAKS_OFFSET_WATKOW,
    MAKS_OFFSET_WIADOMOSCI,
    ROZMIAR_STRONY,
    OdczytajWiadomosciAllegro,
    StronaWatkow,
    StronaWiadomosci,
    WatekAllegro,
)


class PanelWiadomosci(WidokCentrumWiadomosci):
    konto_zmienione = Signal()
    odswiezanie_zmienione = Signal(int)

    def __init__(
        self,
        uc: OdczytajWiadomosciAllegro,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
        login: str,
        parent: QWidget | None = None,
        *,
        pobierz_od_razu: bool = True,
        sprawy: OdczytajSprawyAllegro | None = None,
        odswiezanie_minuty: int = 10,
    ) -> None:
        super().__init__(login, parent)
        self.uc, self.uruchom, self.sesja = uc, uruchom, sesja
        self._zrodlo_spraw: RodzajSprawy | None = None
        self.panel_spraw: PanelSprawAllegro | None = None
        self._sesja = sesja()
        self._zamkniete = False
        self._nr = 0
        self._watek_nr = 0
        self._trwa = False
        self._trwa_listy = False
        self._ma_wiecej = False
        self._blad_listy = False
        self._wczytane: tuple[WatekAllegro, ...] = ()
        self._watki: StronaWatkow | None = None
        self._wiadomosci: StronaWiadomosci | None = None
        self._wybrany = ""
        self._watki_offset = 0
        self._wiadomosci_offset = 0
        self._robocze: dict[str, tuple[str, str]] = {}
        self._podglady: dict[str, tuple[str, str]] = {}
        self._filtr_status = "wszystkie"
        if sprawy is not None:
            self.panel_spraw = PanelSprawAllegro(sprawy, uruchom, sesja)
            self.tresc_zrodla.addWidget(self.panel_spraw)
            self.panel_spraw.statystyki.connect(self._kpi_sprawy)
            for key, kind in (
                ("zwroty", RodzajSprawy.ZWROT),
                ("reklamacje", RodzajSprawy.REKLAMACJA),
                ("spory", RodzajSprawy.DYSKUSJA),
            ):
                self.filtry[key].setEnabled(True)
                self.filtry[key].setToolTip("Odczytaj rzeczywiste sprawy Allegro.")
                self.filtry[key].clicked.connect(
                    lambda checked=False, k=kind: self._wybierz_zrodlo(k)
                )

        self.klient.notatka_zadana.connect(self._pokaz_notatke)
        self.edytor.zmieniono.connect(self._zapisz_robocze)
        self.edytor.zapisano.connect(self._potwierdz_robocze)
        self.okres.currentIndexChanged.connect(self._pokaz_watki)
        for key in ("wszystkie", "nieodczytane"):
            self.filtry[key].clicked.connect(lambda checked=False, k=key: self._ustaw_filtr(k))
        self.filtr.textChanged.connect(self._filtr_zrodla)
        self.lista.currentItemChanged.connect(self._wybierz)
        self.odswiez.clicked.connect(self._odswiez_zrodlo)
        self.ponow_liste.clicked.connect(self._ponow_liste)
        self.lista.verticalScrollBar().valueChanged.connect(self._przewinieto)
        self.lista.viewport().installEventFilter(self)
        self.odswiez_rozmowe.clicked.connect(
            lambda: self.pobierz_wiadomosci(self._offset_wiadomosci())
        )
        self.nowsze.clicked.connect(
            lambda: self.pobierz_wiadomosci(max(0, self._offset_wiadomosci() - ROZMIAR_STRONY))
        )
        self.starsze.clicked.connect(
            lambda: self.pobierz_wiadomosci(self._offset_wiadomosci() + ROZMIAR_STRONY)
        )
        self.auto_czat = QTimer(self)
        self.auto_czat.timeout.connect(self._automatycznie)
        self.ustaw_odswiezanie(odswiezanie_minuty)
        self.czestotliwosc.currentIndexChanged.connect(self._zmien_interwal)
        self.timer = QTimer(self)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self._sprawdz_konto)
        self.timer.start()
        self._przyciski()
        if pobierz_od_razu:
            self.aktywuj()

    def ustaw_odswiezanie(self, minuty: int) -> None:
        sprawdz_odswiezanie_wiadomosci(minuty)
        self._minuty = minuty
        with QSignalBlocker(self.czestotliwosc):
            self.czestotliwosc.setCurrentIndex(self.czestotliwosc.findData(minuty))
        self.auto_czat.stop()
        if minuty:
            self.auto_czat.start(minuty * 60_000)

    def _zmien_interwal(self) -> None:
        minuty = int(self.czestotliwosc.currentData())
        self.ustaw_odswiezanie(minuty)
        self.odswiezanie_zmienione.emit(minuty)

    def _automatycznie(self) -> None:
        if not self._minuty or not self.isVisible() or not self._aktualne():
            return
        if self._zrodlo_spraw is not None and self.panel_spraw is not None:
            self.panel_spraw.odswiez_wybrana()
        elif self._wybrany and not self._trwa:
            self.pobierz_wiadomosci(self._offset_wiadomosci())

    def _offset_watkow(self) -> int:
        return self._watki_offset

    def _offset_wiadomosci(self) -> int:
        return self._wiadomosci_offset

    def _aktualne(self) -> bool:
        return not self._zamkniete and self._sesja is not None and self.sesja() is self._sesja

    def _sprawdz_konto(self) -> None:
        if not self._zamkniete:
            self.polaczenie()

    def polaczenie(self) -> None:
        session = self.sesja()
        if session is self._sesja:
            return
        self._wyczysc()
        self._sesja = session
        self._zamkniete = False
        self._trwa = False
        self._watki_offset = self._wiadomosci_offset = 0
        self.timer.start()
        self.ustaw_odswiezanie(self._minuty)
        self._przyciski()
        self.stan.setText("Zmieniono połączenie. Odśwież rozmowy aktualnego konta.")
        self.konto_zmienione.emit()

    def aktywuj(self) -> None:
        self.polaczenie()
        session = self._sesja
        if session is None:
            self.stan.setText("Połącz konto w Integracje → Allegro, aby odczytać wiadomości.")
        elif session.aplikacja is None or not session.aplikacja.odczyt_wiadomosci:
            self.stan.setText(
                "W Integracje → Allegro włącz Odczyt wiadomości i zatwierdź uprawnienia."
            )
        elif self._watki is None and not self._trwa:
            self.pobierz_watki(0)

    def _wyczysc(self) -> None:
        self._zamkniete = True
        self.timer.stop()
        self.auto_czat.stop()
        self._nr += 1
        self._watek_nr += 1
        self._watki = None
        self._wczytane = ()
        self._trwa_listy = self._ma_wiecej = self._blad_listy = False
        self._wiadomosci = None
        self._sesja = None
        self._wybrany = ""
        if self.panel_spraw is not None:
            self.panel_spraw.wyczysc()
        for key, label in (
            ("wszystkie", "Wszystkie"),
            ("nieodczytane", "Nieodczytane"),
            ("zwroty", "Zwroty"),
            ("reklamacje", "Reklamacje"),
            ("spory", "Otwarte dyskusje"),
        ):
            self.filtry[key].setText(label + "  —")
        self._robocze.clear()
        self._podglady.clear()
        self.klient.ustaw(None)
        self.edytor.ustaw("", "")
        self.edytor.setEnabled(False)
        self._wyczysc_liste()
        self.tresc.clear()
        self.filtr.clear()
        self.tytul.clear()
        self.stan.clear()
        self._metryki()

    def _metryki(self) -> None:
        if self._zrodlo_spraw is not None and self.panel_spraw is not None:
            self._kpi_sprawy(self._zrodlo_spraw, self.panel_spraw.liczba)
            return
        self.kpi["rozmowy"].tytul.setText("Wczytane rozmowy")
        rows = self._wczytane if self._watki is not None else None
        self.kpi["rozmowy"].liczba.setText(str(len(rows)) if rows is not None else "—")
        self.kpi["nieprzeczytane"].liczba.setText(
            str(sum(not r.przeczytany for r in rows)) if rows is not None else "—"
        )
        self.strona_wiadomosci.setText(
            f"Strona {self._offset_wiadomosci() // ROZMIAR_STRONY + 1} · "
            f"{len(self._wiadomosci.pozycje)} wiadomości"
            if self._wiadomosci is not None
            else "Wiadomości · —"
        )
        self.strona_rozmow.setText(f"Rozmowy · {len(self._wczytane)}")
        for key, title, count in (
            ("wszystkie", "Wszystkie", len(rows) if rows is not None else None),
            (
                "nieodczytane",
                "Nieodczytane",
                sum(not r.przeczytany for r in rows) if rows is not None else None,
            ),
        ):
            self.filtry[key].setText(title + "  " + (str(count) if count is not None else "—"))
        self.pusto.setVisible(self.lista.count() == 0)
        if self._watki is not None:
            self.pusto.setText(
                "Brak pasujących rozmów wśród wczytanych."
                if self.filtr.text().strip()
                else "Brak wczytanych rozmów."
            )
        else:
            self.pusto.setText(
                "Pobieranie rozmów…" if self._trwa else "Odśwież skrzynkę, aby pobrać rozmowy."
            )

    def _stan_listy(self) -> None:
        self.ponow_liste.setVisible(self._blad_listy)
        self.ponow_liste.setEnabled(self._aktualne() and not self._trwa_listy)
        if self._trwa_listy:
            text = "Wczytywanie kolejnych rozmów…" if self._wczytane else "Wczytywanie rozmów…"
        elif self._blad_listy:
            text = "Nie udało się wczytać rozmów. Możesz ponowić."
        elif self._ma_wiecej:
            text = "Przewiń w dół, aby wczytać kolejne rozmowy."
        elif self._watki is not None:
            text = "Koniec listy rozmów."
        else:
            text = ""
        self.ladowanie_listy.setText(text)

    def _przyciski(self) -> None:
        self._metryki()
        self._stan_listy()
        ready = not self._trwa and self._aktualne()
        self.edytor_button.setEnabled(bool(self._wybrany) and self._aktualne())
        self.odswiez.setEnabled(ready and not self._trwa_listy)
        self.odswiez_rozmowe.setEnabled(ready and bool(self._wybrany))
        self.nowsze.setEnabled(ready and self._offset_wiadomosci() > 0)
        self.starsze.setEnabled(
            ready
            and self._wiadomosci is not None
            and len(self._wiadomosci.pozycje) == ROZMIAR_STRONY
            and self._offset_wiadomosci() < MAKS_OFFSET_WIADOMOSCI
        )

        if self._zrodlo_spraw is not None and self.panel_spraw is not None:
            self._kpi_sprawy(self._zrodlo_spraw, self.panel_spraw.liczba)

    def pobierz_watki(self, offset: int = 0) -> None:
        self._wczytaj_liste(offset, dolacz=False)

    def _wczytaj_liste(self, offset: int, *, dolacz: bool) -> None:
        session = self._sesja
        if not self._aktualne() or self._trwa_listy or session is None:
            return
        if not dolacz and self._trwa:
            return
        self._nr += 1
        nr = self._nr
        self._trwa_listy = True
        self._blad_listy = False
        if not dolacz:
            self._watek_nr += 1
            self._trwa = True
            self._podglady.clear()
            self._wczytane = ()
            self._watki = self._wiadomosci = None
            self._ma_wiecej = False
            self._wybrany = ""
            self._wyczysc_liste()
            self.tresc.clear()
            self.tytul.setText("Wybierz rozmowę")
            self.stan.setText("Pobieranie rozmów…")
        self._przyciski()

        def gotowe(value: object) -> None:
            if not self._aktualne() or nr != self._nr:
                return
            page = cast(StronaWatkow, value)
            merged = {row.id: row for row in self._wczytane}
            merged.update((row.id, row) for row in page.pozycje)
            self._wczytane = tuple(merged.values())
            self._watki, self._watki_offset = page, offset
            self._ma_wiecej = len(page.pozycje) == ROZMIAR_STRONY and offset < MAKS_OFFSET_WATKOW
            if dolacz:
                self._wypelnij_liste(zachowaj=True)
            else:
                self._trwa = False
                self._pokaz_watki()
            self._trwa_listy = False
            self._przyciski()

        def blad(kod: str, komunikat: str) -> None:
            if not self._aktualne() or nr != self._nr:
                return
            self._trwa_listy = False
            self._blad_listy = True
            if not dolacz:
                self._trwa = False
            self.stan.setText(komunikat)
            self._przyciski()

        self.uruchom(lambda: self.uc.watki(session, offset), gotowe, blad)

    def _doladuj_liste(self) -> None:
        if self._ma_wiecej and not self._blad_listy:
            self._wczytaj_liste(self._watki_offset + ROZMIAR_STRONY, dolacz=True)

    def _ponow_liste(self) -> None:
        self._blad_listy = False
        if self._watki is None:
            self.pobierz_watki(0)
        else:
            self._doladuj_liste()

    def _przewinieto(self, value: int) -> None:
        bar = self.lista.verticalScrollBar()
        if bar.maximum() > 0 and value >= bar.maximum() - 100:
            self._doladuj_liste()

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if (
            watched is self.lista.viewport()
            and isinstance(event, QWheelEvent)
            and (event.angleDelta().y() < 0 or event.pixelDelta().y() < 0)
        ):
            bar = self.lista.verticalScrollBar()
            if bar.value() >= bar.maximum() - 100:
                self._doladuj_liste()
        return super().eventFilter(watched, event)

    def _wyczysc_liste(self) -> None:
        with QSignalBlocker(self.lista):
            self.lista.clear()
        self.klient.ustaw(None)
        self.edytor.ustaw("", "")
        self.edytor.setEnabled(False)
        self.pokaz_konwersacje(False)

    def _pokaz_watki(self) -> None:
        if self._zamkniete:
            return
        with QSignalBlocker(self.lista):
            self._watek_nr += 1
            self._trwa = False if self._watki is not None else self._trwa
            self._wiadomosci = None
            self._wybrany = ""
            self._wyczysc_liste()
            self.tresc.clear()
            self.tytul.setText("Wybierz rozmowę")
            self._wypelnij_liste(zachowaj=False)
            self._przyciski()

    def _wypelnij_liste(self, *, zachowaj: bool) -> None:
        bar = self.lista.verticalScrollBar()
        scroll = bar.value() if zachowaj else 0
        selected = self._wybrany if zachowaj else ""
        fraza = self.filtr.text().strip().casefold()
        with QSignalBlocker(self.lista), QSignalBlocker(bar):
            if not zachowaj:
                self.lista.clear()
            existing: dict[str, QListWidgetItem] = {}
            for i in range(self.lista.count()):
                item = self.lista.item(i)
                row = item.data(Qt.ItemDataRole.UserRole)
                if isinstance(row, WatekAllegro):
                    existing[row.id] = item
            visible: set[str] = set()
            for row in self._wczytane:
                if not self._pasuje(row, fraza):
                    continue
                visible.add(row.id)
                label = ("● " if not row.przeczytany else "") + (
                    row.login or "Rozmówca niedostępny"
                )
                entry = existing.get(row.id)
                item = entry if entry is not None else QListWidgetItem()
                if entry is None:
                    self.lista.addItem(item)
                item.setText(label + "\n" + data_wiadomosci(row.ostatnia))
                item.setToolTip(label + " · " + data_wiadomosci(row.ostatnia))
                item.setData(Qt.ItemDataRole.UserRole, row)
                item.setData(
                    int(Qt.ItemDataRole.UserRole) + 1, self._podglady.get(row.id, ("", ""))
                )
                if row.id == selected and self.lista.currentItem() is not item:
                    self.lista.setCurrentItem(item)
            for ident, item in existing.items():
                if ident not in visible:
                    self.lista.takeItem(self.lista.row(item))
            self.lista.doItemsLayout()
            bar.setValue(scroll)
        if not zachowaj:
            self.stan.setText(
                f"Widoczne: {self.lista.count()} z {len(self._wczytane)}. "
                "Filtry obejmują tylko wczytane rozmowy."
            )

    def _wybierz(self) -> None:
        item = self.lista.currentItem()
        row = item.data(Qt.ItemDataRole.UserRole) if item else None
        self._watek_nr += 1
        self._wiadomosci = None
        self._wybrany = row.id if isinstance(row, WatekAllegro) else ""
        self.tresc.clear()
        self.klient.ustaw(row if isinstance(row, WatekAllegro) else None)
        self.edytor.setEnabled(isinstance(row, WatekAllegro))
        self.edytor.ustaw(*self._robocze.get(self._wybrany, ("", "")))
        self._podglad_notatki()
        self.pokaz_konwersacje(isinstance(row, WatekAllegro))
        if isinstance(row, WatekAllegro):
            self._wiadomosci_offset = 0
            self.tytul.setText("Rozmowa · " + (row.login or "Rozmówca niedostępny"))
            # Zmiana wyboru unieważnia poprzedni odczyt, ale nie blokuje nowego.
            self._trwa = False
            self.pobierz_wiadomosci(0)
        self._przyciski()

    def pobierz_wiadomosci(self, offset: int) -> None:
        s, ident = self._sesja, self._wybrany
        if not self._aktualne() or self._trwa or s is None or not ident:
            return
        self._wiadomosci_offset = offset
        self._watek_nr += 1
        nr = self._watek_nr
        self._trwa = True
        self._wiadomosci = None
        self.tresc.clear()
        self.stan.setText("Pobieranie strony wiadomości…")
        self._przyciski()

        def gotowe(value: object) -> None:
            if not self._aktualne() or nr != self._watek_nr or ident != self._wybrany:
                return
            self._trwa = False
            page = cast(StronaWiadomosci, value)
            self._wiadomosci = page
            self.tresc.ustaw(page.pozycje)
            if offset == 0 and page.pozycje:
                first = page.pozycje[0]
                preview = (
                    tekst_wiadomosci(first.temat),
                    " ".join(tekst_wiadomosci(first.tekst).split())[:180],
                )
                self._podglady[ident] = preview
                item = self.lista.currentItem()
                if item is not None:
                    item.setData(int(Qt.ItemDataRole.UserRole) + 1, preview)
                if first.temat:
                    self.tytul.setText(tekst_wiadomosci(first.temat))

            self.stan.setText(
                f"Strona wiadomości {offset // ROZMIAR_STRONY + 1} · "
                f"{len(page.pozycje)} wiadomości, od najnowszych."
                if page.pozycje
                else "Brak wiadomości na tej stronie."
            )
            self._przyciski()

        def blad(kod: str, komunikat: str) -> None:
            if not self._aktualne() or nr != self._watek_nr or ident != self._wybrany:
                return
            self._trwa = False
            self.stan.setText(komunikat)
            self._przyciski()

        self.uruchom(lambda: self.uc.wiadomosci(s, ident, offset), gotowe, blad)

    def _wybierz_zrodlo(self, rodzaj: RodzajSprawy) -> None:
        if self.panel_spraw is None:
            return
        self._zrodlo_spraw = rodzaj
        self.opis.setText(rodzaj.value + " • rzeczywisty odczyt Allegro • filtry wczytanych spraw")
        self.filtr.setPlaceholderText("Szukaj numeru, kupującego lub statusu • wczytane sprawy…")
        key = {
            RodzajSprawy.ZWROT: "zwroty",
            RodzajSprawy.REKLAMACJA: "reklamacje",
            RodzajSprawy.DYSKUSJA: "spory",
        }[rodzaj]
        for name, button in self.filtry.items():
            button.setChecked(name == key)
        with QSignalBlocker(self.filtr):
            self.filtr.clear()
        self.panel_spraw.filtruj("")
        self.tresc_zrodla.setCurrentWidget(self.panel_spraw)
        self.stan.hide()
        self.klient_button.hide()
        self.ai_button.hide()
        self.okres.hide()
        self.panel_spraw.otworz(rodzaj)
        self._kpi_sprawy(rodzaj, self.panel_spraw.liczba)

    def _kpi_sprawy(self, rodzaj: RodzajSprawy, count: int) -> None:
        if rodzaj != self._zrodlo_spraw or self.panel_spraw is None:
            return
        self.kpi["rozmowy"].tytul.setText("Wczytane: " + rodzaj.value.lower())
        self.kpi["rozmowy"].liczba.setText(str(count) if count >= 0 else "—")
        self.kpi["nieprzeczytane"].liczba.setText("—")
        key = {
            RodzajSprawy.ZWROT: "zwroty",
            RodzajSprawy.REKLAMACJA: "reklamacje",
            RodzajSprawy.DYSKUSJA: "spory",
        }[rodzaj]
        self.filtry[key].setText(rodzaj.value + "  " + (str(count) if count >= 0 else "—"))
        self.odswiez.setEnabled(self._aktualne() and not self.panel_spraw.zajete)

    def _filtr_zrodla(self) -> None:
        if self._zrodlo_spraw is not None and self.panel_spraw is not None:
            self.panel_spraw.filtruj(self.filtr.text())
        else:
            self._pokaz_watki()

    def _odswiez_zrodlo(self) -> None:
        if self._zrodlo_spraw is not None and self.panel_spraw is not None:
            self.panel_spraw.odswiez_liste()
        else:
            self.pobierz_watki(0)

    def _ustaw_filtr(self, key: str) -> None:
        self._zrodlo_spraw = None
        self.opis.setText("Obsługa rozmów Allegro • lokalne filtry wczytanych rozmów")
        self.filtr.setPlaceholderText("Szukaj loginu lub pobranego fragmentu • wczytane rozmowy…")
        self.tresc_zrodla.setCurrentWidget(self.split)
        self.stan.show()
        self.klient_button.show()
        self.ai_button.show()
        self.okres.show()
        for name in ("zwroty", "reklamacje", "spory"):
            self.filtry[name].setChecked(False)
        self._filtr_status = key
        for name in ("wszystkie", "nieodczytane"):
            self.filtry[name].setChecked(name == key)
        self._pokaz_watki()

    def _pasuje(self, row: WatekAllegro, fraza: str) -> bool:
        if self._filtr_status == "nieodczytane" and row.przeczytany:
            return False
        days = int(self.okres.currentData() or 0)
        if days:
            dt = QDateTime.fromString(row.ostatnia, Qt.DateFormat.ISODateWithMs)
            if not dt.isValid() or dt < QDateTime.currentDateTimeUtc().addDays(-days):
                return False
        preview = self._podglady.get(row.id, ("", ""))
        return not fraza or fraza in " ".join((row.login, *preview)).casefold()

    def _zapisz_robocze(self) -> None:
        if self._aktualne() and self._wybrany:
            self._robocze[self._wybrany] = self.edytor.dane()
            self._podglad_notatki()

    def _podglad_notatki(self) -> None:
        text = self.edytor.notatka.toPlainText()
        self.klient.notatka.setText(text[:300] or "Brak notatki w tej sesji.")

    def _pokaz_notatke(self) -> None:
        self.edytor_button.setChecked(True)
        self.edytor.tryby.setCurrentIndex(1)
        self.edytor.notatka.setFocus()

    def _potwierdz_robocze(self) -> None:
        self._zapisz_robocze()
        self.stan.setText(
            "Zachowano roboczo w pamięci tej sesji. Nie wysłano wiadomości. "
            "Zmiana lub odnowienie sesji albo zamknięcie usuwa treść."
        )


class OknoWiadomosci(QDialog):
    """Ten sam panel w oknie otwieranym ze szczegółów zamówienia."""

    def __init__(
        self,
        uc: OdczytajWiadomosciAllegro,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
        login: str,
        parent: QWidget | None = None,
        *,
        sprawy: OdczytajSprawyAllegro | None = None,
        odswiezanie_minuty: int = 10,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Wiadomości Allegro · odczyt")
        self.resize(1000, 660)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.panel = PanelWiadomosci(
            uc, uruchom, sesja, login, self, sprawy=sprawy, odswiezanie_minuty=odswiezanie_minuty
        )
        layout.addWidget(self.panel)
        zamknij = QPushButton("Zamknij")
        layout.addWidget(zamknij, 0, Qt.AlignmentFlag.AlignRight)
        zamknij.clicked.connect(self.reject)
        self.panel.konto_zmienione.connect(self.reject)
        self.finished.connect(self.panel._wyczysc)
