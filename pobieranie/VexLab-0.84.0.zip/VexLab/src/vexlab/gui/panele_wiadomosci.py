"""Panele centrum komunikacji. Brak integracji AI, zapisów kanału i danych demonstracyjnych."""

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont, QTextCharFormat, QTextListFormat
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona, ikona_menu
from vexlab.gui.prezentacja_wiadomosci import data_wiadomosci
from vexlab.przypadki_uzycia.wiadomosci_allegro import WatekAllegro

BRAK_FUNKCJI = "Podgląd interfejsu. Ta funkcja nie jest jeszcze podłączona."


def napis(text: str, name: str = "") -> QLabel:
    label = QLabel(text)
    label.setTextFormat(Qt.TextFormat.PlainText)
    label.setWordWrap(True)
    label.setMinimumWidth(0)
    label.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
    label.setObjectName(name)
    return label


def przycisk_podgladu(text: str) -> QPushButton:
    button = QPushButton(text)
    button.setEnabled(False)
    button.setToolTip(BRAK_FUNKCJI)
    return button


class PanelKlienta(QFrame):
    notatka_zadana = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("klientWiadomosci")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 16, 12, 12)
        layout.setSpacing(14)
        self.avatar = napis("?", "avatarKlienta")
        self.avatar.setFixedSize(46, 46)
        self.avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.login = napis("Wybierz rozmowę", "naglowekKlienta")
        self.login.setWordWrap(False)
        self.login.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        identity = QHBoxLayout()
        identity.addWidget(self.avatar)
        identity.addWidget(self.login, 1)
        layout.addLayout(identity)
        self.stan = napis("Dane dostępne po otwarciu rozmowy", "opisWiadomosci")
        layout.addWidget(self.stan)
        grid = QGridLayout()
        grid.setVerticalSpacing(14)
        self.pola: dict[str, QLabel] = {}
        for i, (key, title, symbol, color) in enumerate(
            (
                ("zakupy", "Zakupów", "koszyk", "#3B82F6"),
                ("wartosc", "Wartość klienta", "monety", "#F59E0B"),
                ("relacja", "Klient od", "kalendarz", "#8B5CF6"),
                ("platforma", "Platforma", "globus", "#FF5A00"),
            )
        ):
            icon = QLabel()
            icon.setFixedSize(30, 30)
            icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
            image = ikona_menu("Allegro", True) if key == "platforma" else ikona(symbol, color)
            icon.setPixmap(image.pixmap(20, 20))
            tint = QColor(color)
            tint.setAlpha(28)
            icon.setStyleSheet(
                f"background:{tint.name(QColor.NameFormat.HexArgb)};border-radius:8px;"
            )
            grid.addWidget(icon, i, 0)
            value = napis("—")
            self.pola[key] = value
            cell = QVBoxLayout()
            cell.setSpacing(2)
            cell.addWidget(value)
            cell.addWidget(napis(title, "opisWiadomosci"))
            grid.addLayout(cell, i, 1)
        layout.addLayout(grid)
        layout.addWidget(napis("Tagi", "naglowekSekcjiWiadomosci"))
        self.tagi = napis("Brak przypisanych tagów", "opisWiadomosci")
        layout.addWidget(self.tagi)
        layout.addWidget(przycisk_podgladu("+ Dodaj tag"))
        layout.addWidget(napis("Ostatnie zamówienia", "naglowekSekcjiWiadomosci"))
        layout.addWidget(
            napis(
                "Brak powiązanych zamówień. Historia zakupów nie jest dostępna w odczycie rozmów.",
                "opisWiadomosci",
            )
        )
        layout.addWidget(przycisk_podgladu("Powiąż zamówienie"))
        layout.addWidget(napis("Kontekst rozmowy", "naglowekSekcjiWiadomosci"))
        self.ostatnia = napis("—", "opisWiadomosci")
        layout.addWidget(self.ostatnia)
        layout.addWidget(napis("Notatki robocze", "naglowekSekcjiWiadomosci"))
        self.notatka = napis("Brak notatki w tej sesji.", "opisWiadomosci")
        layout.addWidget(self.notatka)
        self.dodaj_notatke = QPushButton("+ Notatka")
        self.dodaj_notatke.setEnabled(False)
        self.dodaj_notatke.clicked.connect(self.notatka_zadana.emit)
        layout.addWidget(self.dodaj_notatke)
        layout.addStretch(1)

    def ustaw(self, row: WatekAllegro | None) -> None:
        self.notatka.setText("Brak notatki w tej sesji.")
        self.dodaj_notatke.setEnabled(row is not None)
        self.avatar.setText((row.login[:1] or "?").upper() if row else "?")
        self.login.setText(row.login or "Rozmówca niedostępny" if row else "Wybierz rozmowę")
        self.login.setToolTip(row.login if row else "")
        self.stan.setText(
            ("Przeczytana" if row.przeczytany else "Nieodczytana")
            if row
            else "Dane dostępne po otwarciu rozmowy"
        )
        self.pola["platforma"].setText("Allegro" if row else "—")
        self.tagi.setText("Allegro" if row else "Brak przypisanych tagów")
        self.ostatnia.setText(
            "Ostatnia aktywność\n" + data_wiadomosci(row.ostatnia) if row else "—"
        )


class EdytorOdpowiedzi(QFrame):
    zmieniono = Signal()
    zapisano = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("edytorWiadomosci")
        box = QVBoxLayout(self)
        box.setContentsMargins(8, 8, 8, 8)
        box.setSpacing(6)
        self.tryby = QTabWidget()
        self.tryby.setDocumentMode(True)
        self.odpowiedz = QTextEdit()
        self.notatka = QTextEdit()
        self.odpowiedz.setAcceptRichText(False)
        self.notatka.setAcceptRichText(False)
        self.odpowiedz.setPlaceholderText("Napisz roboczą odpowiedź do klienta…")
        self.notatka.setPlaceholderText("Notatka robocza, wyłącznie w pamięci tej sesji…")
        self.odpowiedz.setAccessibleName("Robocza odpowiedź, bez wysyłania")
        self.notatka.setAccessibleName("Robocza notatka wewnętrzna")
        for title, editor in (("Odpowiedź", self.odpowiedz), ("Notatka wewnętrzna", self.notatka)):
            page = QWidget()
            vb = QVBoxLayout(page)
            vb.setContentsMargins(0, 4, 0, 0)
            tools = QHBoxLayout()
            for text, operation in (
                ("B", "bold"),
                ("I", "italic"),
                ("U", "underline"),
                ("• Lista", "list"),
            ):
                button = QPushButton(text)
                button.setMaximumWidth(58)
                button.setToolTip(
                    {
                        "bold": "Pogrubienie",
                        "italic": "Kursywa",
                        "underline": "Podkreślenie",
                        "list": "Lista",
                    }[operation]
                )
                button.clicked.connect(
                    lambda checked=False, e=editor, op=operation: self._formatuj(e, op)
                )
                tools.addWidget(button)
            tools.addWidget(przycisk_podgladu("↗ Link"))
            tools.addStretch(1)
            vb.addLayout(tools)
            vb.addWidget(editor)
            self.tryby.addTab(page, title)
            editor.textChanged.connect(self.zmieniono.emit)
        box.addWidget(self.tryby, 1)
        actions = QHBoxLayout()
        for text in ("Generuj AI", "Załącznik", "Szablony"):
            actions.addWidget(przycisk_podgladu(text))
        self.zapisz = QPushButton("Zapisz roboczo")
        self.zapisz.setToolTip("Wyłącznie w pamięci tej sesji. Bez pliku, bazy i wysyłania.")
        self.zapisz.clicked.connect(self.zapisano.emit)
        actions.addWidget(self.zapisz)
        self.wyslij = przycisk_podgladu("Wyślij")
        self.wyslij.setObjectName("przyciskWyslijWiadomosc")
        self.wyslij.setToolTip("Wysyłanie odpowiedzi nie jest jeszcze wdrożone.")
        actions.addWidget(self.wyslij)
        box.addLayout(actions)
        box.addWidget(
            napis(
                "Roboczo w pamięci sesji • bez wysyłania • znika po zmianie sesji lub zamknięciu",
                "opisWiadomosci",
            )
        )
        self.setMinimumHeight(185)
        self.setMaximumHeight(210)
        self.setEnabled(False)

    @staticmethod
    def _formatuj(editor: QTextEdit, operation: str) -> None:
        if operation == "list":
            editor.textCursor().createList(QTextListFormat.Style.ListDisc)
        else:
            fmt = QTextCharFormat()
            if operation == "bold":
                fmt.setFontWeight(
                    QFont.Weight.Normal
                    if editor.fontWeight() >= QFont.Weight.Bold
                    else QFont.Weight.Bold
                )
            elif operation == "italic":
                fmt.setFontItalic(not editor.fontItalic())
            else:
                fmt.setFontUnderline(not editor.fontUnderline())
            editor.mergeCurrentCharFormat(fmt)
        editor.setFocus()

    def ustaw(self, odpowiedz: str, notatka: str) -> None:
        self.blockSignals(True)
        self.odpowiedz.setHtml(odpowiedz)
        self.notatka.setHtml(notatka)
        self.blockSignals(False)

    def dane(self) -> tuple[str, str]:
        return self.odpowiedz.toHtml(), self.notatka.toHtml()


class PanelVexAI(QFrame):
    zamknij = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("vexaiWiadomosci")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        header = QHBoxLayout()
        header.addWidget(napis("VexAI", "naglowekKlienta"))
        header.addWidget(napis("BETA", "badgeVexAI"))
        header.addStretch(1)
        close = QPushButton("×")
        close.setAccessibleName("Zwiń panel VexAI")
        close.setFixedWidth(28)
        close.clicked.connect(self.zamknij.emit)
        header.addWidget(close)
        layout.addLayout(header)
        layout.addWidget(napis("Twój asystent w obsłudze klienta", "opisWiadomosci"))
        layout.addWidget(napis("Podgląd interfejsu • AI niepodłączone", "opisWiadomosci"))
        tabs = QTabWidget()
        tabs.setDocumentMode(True)
        analysis = QWidget()
        ab = QVBoxLayout(analysis)
        ab.setContentsMargins(0, 8, 0, 0)
        ab.addWidget(napis("Analiza rozmowy", "naglowekSekcjiWiadomosci"))
        fields = QGridLayout()
        for i, text in enumerate(
            ("Temat", "Produkt", "Powód", "Nastrój klienta", "Ryzyko sporu", "Rekomendacja")
        ):
            fields.addWidget(napis(text, "opisWiadomosci"), i, 0)
            fields.addWidget(napis("—"), i, 1)
        ab.addLayout(fields)
        ab.addWidget(napis("Podsumowanie", "naglowekSekcjiWiadomosci"))
        ab.addWidget(
            napis(
                "Nie wykonano analizy. Podsumowanie będzie dostępne po integracji AI.",
                "opisWiadomosci",
            )
        )
        ab.addWidget(napis("Sugestia odpowiedzi", "naglowekSekcjiWiadomosci"))
        self.sugestia = QTextEdit()
        self.sugestia.setReadOnly(True)
        self.sugestia.setPlaceholderText("Brak wygenerowanej sugestii.")
        ab.addWidget(self.sugestia, 1)
        ab.addWidget(przycisk_podgladu("Wstaw do edytora"))
        ab.addWidget(napis("Powiązane artykuły pomocy", "naglowekSekcjiWiadomosci"))
        ab.addWidget(napis("Brak skonfigurowanych źródeł pomocy.", "opisWiadomosci"))
        tabs.addTab(analysis, "Analiza")
        for title, text in (
            ("Sugestie", "Sugestie będą dostępne po integracji AI."),
            ("Szablony", "Brak skonfigurowanych szablonów odpowiedzi."),
        ):
            page = QWidget()
            vb = QVBoxLayout(page)
            vb.addWidget(napis(text, "opisWiadomosci"))
            vb.addStretch(1)
            tabs.addTab(page, title)
        layout.addWidget(tabs, 1)


def przewijany_panel(widget: QWidget) -> QScrollArea:
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    scroll.setFrameShape(QFrame.Shape.NoFrame)
    scroll.setWidget(widget)
    return scroll
