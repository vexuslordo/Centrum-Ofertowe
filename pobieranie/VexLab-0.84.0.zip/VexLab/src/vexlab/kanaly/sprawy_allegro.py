"""Oddzielny odczyt beta v1 zwrotów, reklamacji i dyskusji Allegro."""

from datetime import datetime
from typing import Any
from urllib.parse import urlencode
from uuid import UUID

from vexlab.kanaly.allegro import AllegroAPI, hosty
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.sprawy_allegro import (
    LIMIT_SPRAW,
    OTWARTE_DYSKUSJE,
    RodzajSprawy,
    SprawaAllegro,
    StronaHistoriiSprawy,
    StronaSpraw,
    WpisSprawy,
)
from vexlab.przypadki_uzycia.wiadomosci_allegro import sprawdz_id


def _text(d: dict[str, Any], key: str, limit: int = 20000, *, required: bool = False) -> str:
    value = d.get(key)
    if value is None and not required:
        return ""
    if not isinstance(value, str) or len(value) > limit or (required and not value):
        raise ValueError("tekst")
    if any(ord(c) < 32 and c not in "\n\r\t" for c in value):
        raise ValueError("znaki")
    return value


def _object(d: dict[str, Any], key: str) -> dict[str, Any]:
    value = d.get(key)
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("obiekt")
    return value


def _array(
    d: dict[str, Any], key: str, limit: int = 1000, *, required: bool = False
) -> list[dict[str, Any]]:
    if required and key not in d:
        raise ValueError("brak listy")
    rows = d.get(key, [])
    if (
        not isinstance(rows, list)
        or len(rows) > limit
        or any(not isinstance(r, dict) for r in rows)
    ):
        raise ValueError("lista")
    return rows


def _date(d: dict[str, Any], key: str, *, required: bool = False) -> str:
    text = _text(d, key, 50, required=required)
    if text and datetime.fromisoformat(text.replace("Z", "+00:00")).tzinfo is None:
        raise ValueError("data")
    return text


def _ident(d: dict[str, Any], *, uuid: bool = False) -> str:
    ident = _text(d, "id", 200, required=True)
    sprawdz_id(ident)
    if uuid:
        UUID(ident)
    return ident


def _pliki(d: dict[str, Any]) -> tuple[str, ...]:
    return tuple(_text(r, "fileName", 1000, required=True) for r in _array(d, "attachments", 100))


def _kwota(d: dict[str, Any]) -> str:
    # Wyłącznie odczyt kwoty i kodu waluty z tego samego obiektu, bez sum lub przeliczania.
    amount, currency = _text(d, "amount", 100), _text(d, "currency", 10)
    return amount + " " + currency if amount and currency else "—"


def _zwrot(d: dict[str, Any]) -> SprawaAllegro:
    items = []
    for row in _array(d, "items"):
        quantity = row.get("quantity")
        if type(quantity) is not int or quantity < 1:
            raise ValueError("ilosc")
        reason = _object(row, "reason")
        item = (
            f"{_text(row, 'name', 1000, required=True)} · {quantity} szt. · "
            f"{_kwota(_object(row, 'price'))}"
        )
        detail = " · ".join(
            v for v in (_text(reason, "type", 100), _text(reason, "userComment")) if v
        )
        items.append(item + ("\nPowód: " + detail if detail else ""))
    parcels = tuple(
        " · ".join(v for v in (_text(r, "carrierId", 100), _text(r, "waybill", 200)) if v)
        for r in _array(d, "parcels", 100)
    )
    rejection = _object(d, "rejection")
    return SprawaAllegro(
        _ident(d),
        RodzajSprawy.ZWROT,
        _text(d, "referenceNumber", 200),
        _text(_object(d, "buyer"), "login", 200),
        _date(d, "createdAt", required=True),
        _text(d, "status", 100, required=True),
        "Zwrot " + _text(d, "referenceNumber", 200),
        _text(d, "orderId", 200),
        " · ".join(v for v in (_text(rejection, "code", 100), _text(rejection, "reason")) if v),
        pozycje=tuple(items),
        przesylki=parcels,
    )


def _issue(d: dict[str, Any]) -> SprawaAllegro:
    kind = _text(d, "type", 100, required=True)
    if kind not in ("CLAIM", "DISPUTE"):
        raise ValueError("rodzaj")
    rodzaj = RodzajSprawy.REKLAMACJA if kind == "CLAIM" else RodzajSprawy.DYSKUSJA
    state, reason = _object(d, "currentState"), _object(d, "reason")
    expectations = tuple(
        " · ".join(
            v
            for v in (
                _text(r, "name", 100),
                _kwota(_object(r, "refund")) if r.get("refund") else "",
            )
            if v
        )
        for r in _array(d, "expectations", 100)
    )
    return SprawaAllegro(
        _ident(d, uuid=True),
        rodzaj,
        _text(d, "referenceNumber", 200),
        _text(_object(d, "buyer"), "login", 200),
        _date(d, "openedDate", required=True),
        _text(state, "status", 100, required=True),
        _text(d, "subject", 2000) or _text(reason, "type", 200) or rodzaj.value,
        _text(_object(d, "checkoutForm"), "id", 200),
        "\n".join(v for v in (_text(d, "description"), _text(reason, "description")) if v),
        _date(d, "decisionDueDate") or _date(state, "statusDueDate"),
        oczekiwania=expectations,
        zalaczniki=_pliki(d),
    )


class SprawyAllegroAPI(AllegroAPI):
    def _odczyt(
        self, s: SesjaAllegro, path: str, params: list[tuple[str, str | int]] | None = None
    ) -> dict[str, Any]:
        _, base = hosty(s.srodowisko)
        url = base + path + ("?" + urlencode(params) if params else "")
        try:
            return self._json(
                "GET",
                url,
                {
                    "Authorization": "Bearer " + s.token,
                    "Accept": "application/vnd.allegro.beta.v1+json",
                    "Accept-Language": "pl-PL",
                },
            )
        except BladAllegro as blad:
            if blad.kod == "UPRAWNIENIA":
                scope = (
                    "allegro:api:orders:read"
                    if path.startswith("/order/")
                    else "allegro:api:disputes"
                )
                raise BladAllegro(
                    "UPRAWNIENIA",
                    f"Allegro odmówiło odczytu spraw. Sprawdź {scope} "
                    "i zatwierdź uprawnienia ponownie.",
                ) from None
            raise

    def lista(self, s: SesjaAllegro, rodzaj: RodzajSprawy, offset: int) -> StronaSpraw:
        try:
            params: list[tuple[str, str | int]] = [("limit", LIMIT_SPRAW), ("offset", offset)]
            if rodzaj == RodzajSprawy.ZWROT:
                d = self._odczyt(s, "/order/customer-returns", params)
                raw = _array(d, "customerReturns", LIMIT_SPRAW, required=True)
                rows = tuple(_zwrot(r) for r in raw)
            else:
                statuses = (
                    OTWARTE_DYSKUSJE
                    if rodzaj == RodzajSprawy.DYSKUSJA
                    else ("CLAIM_SUBMITTED", "CLAIM_ACCEPTED", "CLAIM_REJECTED")
                )
                params += [("status", v) for v in statuses]
                d = self._odczyt(s, "/sale/issues", params)
                raw = _array(d, "issues", LIMIT_SPRAW, required=True)
                rows = tuple(
                    r
                    for r in (_issue(v) for v in raw)
                    if r.rodzaj == rodzaj
                    and (rodzaj != RodzajSprawy.DYSKUSJA or r.status in OTWARTE_DYSKUSJE)
                )
            if len({r.id for r in rows}) != len(rows):
                raise ValueError("duplikat")
            return StronaSpraw(rows, offset, len(raw) == LIMIT_SPRAW)
        except (ValueError, TypeError, KeyError, AttributeError):
            raise BladAllegro("ODPOWIEDZ", "Nieprawidłowa lista spraw Allegro.") from None

    def szczegoly(self, s: SesjaAllegro, rodzaj: RodzajSprawy, ident: str) -> SprawaAllegro:
        try:
            sprawdz_id(ident)
            if rodzaj == RodzajSprawy.ZWROT:
                row = _zwrot(self._odczyt(s, "/order/customer-returns/" + ident))
            else:
                UUID(ident)
                row = _issue(self._odczyt(s, "/sale/issues/" + ident))
            if row.id != ident or row.rodzaj != rodzaj:
                raise ValueError("tozsamosc")
            return row
        except (ValueError, TypeError, KeyError, AttributeError):
            raise BladAllegro("ODPOWIEDZ", "Nieprawidłowe szczegóły sprawy Allegro.") from None

    def historia(self, s: SesjaAllegro, ident: str, offset: int) -> StronaHistoriiSprawy:
        try:
            sprawdz_id(ident)
            UUID(ident)
            d = self._odczyt(
                s, "/sale/issues/" + ident + "/chat", [("limit", LIMIT_SPRAW), ("offset", offset)]
            )
            raw = _array(d, "chat", LIMIT_SPRAW, required=True)
            rows = []
            for r in raw:
                author = _object(r, "author")
                role = _text(author, "role", 100, required=True)
                rows.append(
                    WpisSprawy(
                        _ident(r),
                        _date(r, "createdAt", required=True),
                        role,
                        _text(author, "login", 200) or role,
                        _text(r, "text", 100000),
                        _pliki(r),
                    )
                )
            if len({r.id for r in rows}) != len(rows):
                raise ValueError("duplikat")
            return StronaHistoriiSprawy(tuple(rows), offset, len(raw) == LIMIT_SPRAW)
        except (ValueError, TypeError, KeyError, AttributeError):
            raise BladAllegro("ODPOWIEDZ", "Nieprawidłowa korespondencja sprawy Allegro.") from None
