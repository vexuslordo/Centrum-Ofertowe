"""Odczyt spraw posprzedażowych bieżącego konta. Bez decyzji i zapisu w kanale."""

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Protocol
from uuid import UUID

from vexlab.przypadki_uzycia.allegro import BladAllegro, CzasMonotoniczny, SesjaAllegro
from vexlab.przypadki_uzycia.wiadomosci_allegro import sprawdz_id

LIMIT_SPRAW = 20
MAX_OFFSET_SPRAW = 2_147_483_640
OTWARTE_DYSKUSJE = ("DISPUTE_ONGOING", "DISPUTE_UNRESOLVED")


class RodzajSprawy(StrEnum):
    ZWROT = "Zwroty"
    REKLAMACJA = "Reklamacje"
    DYSKUSJA = "Otwarte dyskusje"


@dataclass(frozen=True)
class SprawaAllegro:
    id: str
    rodzaj: RodzajSprawy
    numer: str = field(repr=False)
    login: str = field(repr=False)
    kiedy: str
    status: str
    temat: str = field(repr=False)
    zamowienie: str = field(default="", repr=False)
    opis: str = field(default="", repr=False)
    termin: str = ""
    pozycje: tuple[str, ...] = field(default=(), repr=False)
    przesylki: tuple[str, ...] = field(default=(), repr=False)
    oczekiwania: tuple[str, ...] = field(default=(), repr=False)
    zalaczniki: tuple[str, ...] = field(default=(), repr=False)


@dataclass(frozen=True)
class WpisSprawy:
    id: str
    kiedy: str
    rola: str
    autor: str = field(repr=False)
    tekst: str = field(repr=False)
    zalaczniki: tuple[str, ...] = field(default=(), repr=False)


@dataclass(frozen=True)
class StronaSpraw:
    pozycje: tuple[SprawaAllegro, ...] = field(repr=False)
    offset: int
    wiecej: bool


@dataclass(frozen=True)
class StronaHistoriiSprawy:
    pozycje: tuple[WpisSprawy, ...] = field(repr=False)
    offset: int
    wiecej: bool


class APISprawAllegro(Protocol):
    def lista(self, s: SesjaAllegro, rodzaj: RodzajSprawy, offset: int) -> StronaSpraw: ...
    def szczegoly(self, s: SesjaAllegro, rodzaj: RodzajSprawy, ident: str) -> SprawaAllegro: ...
    def historia(self, s: SesjaAllegro, ident: str, offset: int) -> StronaHistoriiSprawy: ...


class OdczytajSprawyAllegro:
    def __init__(self, api: APISprawAllegro, czas: CzasMonotoniczny) -> None:
        self.api, self.czas = api, czas

    def _sprawdz(self, s: SesjaAllegro, rodzaj: RodzajSprawy, offset: int = 0) -> None:
        if self.czas.teraz() >= s.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto Allegro ponownie.")
        if not isinstance(rodzaj, RodzajSprawy):
            raise BladAllegro("ZAKRES", "Nieprawidłowy rodzaj sprawy.")
        if type(offset) is not int or not 0 <= offset <= MAX_OFFSET_SPRAW or offset % LIMIT_SPRAW:
            raise BladAllegro("ZAKRES", "Nieprawidłowy zakres odczytu spraw.")
        app = s.aplikacja
        if rodzaj == RodzajSprawy.ZWROT:
            zgoda, label = app is not None and app.odczyt_zamowien, "Odczyt zamówień i zwrotów"
        else:
            zgoda, label = app is not None and app.odczyt_spraw, "Odczyt reklamacji i dyskusji"
        if not zgoda:
            raise BladAllegro(
                "UPRAWNIENIA",
                f"W Integracje → Allegro włącz {label} i zatwierdź uprawnienia ponownie.",
            )

    @staticmethod
    def _id(rodzaj: RodzajSprawy, ident: str) -> None:
        sprawdz_id(ident)
        if rodzaj != RodzajSprawy.ZWROT:
            try:
                UUID(ident)
            except ValueError:
                raise BladAllegro("SPRAWA", "Nieprawidłowy identyfikator sprawy.") from None

    def lista(self, s: SesjaAllegro, rodzaj: RodzajSprawy, offset: int = 0) -> StronaSpraw:
        self._sprawdz(s, rodzaj, offset)
        return self.api.lista(s, rodzaj, offset)

    def szczegoly(self, s: SesjaAllegro, rodzaj: RodzajSprawy, ident: str) -> SprawaAllegro:
        self._sprawdz(s, rodzaj)
        self._id(rodzaj, ident)
        return self.api.szczegoly(s, rodzaj, ident)

    def historia(
        self, s: SesjaAllegro, rodzaj: RodzajSprawy, ident: str, offset: int = 0
    ) -> StronaHistoriiSprawy:
        self._sprawdz(s, rodzaj, offset)
        self._id(rodzaj, ident)
        if rodzaj == RodzajSprawy.ZWROT:
            raise BladAllegro("SPRAWA", "Zwrot nie ma korespondencji dyskusji.")
        return self.api.historia(s, ident, offset)
