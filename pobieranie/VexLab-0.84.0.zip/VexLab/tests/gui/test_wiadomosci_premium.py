from PySide6.QtCore import QDateTime, Qt

from tests.gui.test_wiadomosci_allegro import okno, zakoncz
from tests.integration.test_wiadomosci_allegro import wiadomosc


def test_filtry_statusu_i_dat_dzialaja_na_stronie_bez_kolejnego_http(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    t.payload["threads"][0]["lastMessageDateTime"] = (
        QDateTime.currentDateTimeUtc().addSecs(-60).toString(Qt.DateFormat.ISODate)
    )
    t.payload["threads"][1]["lastMessageDateTime"] = (
        QDateTime.currentDateTimeUtc().addDays(-60).toString(Qt.DateFormat.ISODate)
    )
    t.payload["threads"][1]["read"] = True
    zakoncz(jobs)
    assert w.lista.count() == 2
    w.filtry["nieodczytane"].click()
    assert w.lista.count() == 1
    w.filtry["wszystkie"].click()
    assert w.lista.count() == 2
    w.okres.setCurrentIndex(w.okres.findData(7))
    assert w.lista.count() == 1
    assert w.kpi["rozmowy"].liczba.text() == "2"
    assert len(t.calls) == 1 and not jobs


def test_szkice_i_notatki_sa_oddzielne_per_watek_i_znikaja_po_zmianie_konta(qtbot):
    dialog, t, jobs, account = okno(qtbot)
    w = dialog.panel
    zakoncz(jobs)
    w.lista.setCurrentRow(0)
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    zakoncz(jobs)
    w.edytor.odpowiedz.setPlainText("Robocza odpowiedź testowa")
    w.edytor.notatka.setPlainText("Robocza notatka testowa")
    w.edytor.zapisz.click()
    assert "Nie wysłano" in w.stan.text()
    w.lista.setCurrentRow(1)
    assert not w.edytor.odpowiedz.toPlainText()
    t.payload = {"messages": [wiadomosc(thread="thread-2")], "offset": 0, "limit": 20}
    zakoncz(jobs)
    w.lista.setCurrentRow(0)
    assert w.edytor.odpowiedz.toPlainText() == "Robocza odpowiedź testowa"
    assert w.edytor.notatka.toPlainText() == "Robocza notatka testowa"
    account[0] = None
    w.polaczenie()
    assert not w._robocze and not w._podglady
    assert not w.edytor.odpowiedz.toPlainText() and not w.edytor.notatka.toPlainText()
    assert not w.klient.login.toolTip()
    assert all(call[0] == "GET" for call in t.calls)


def test_podglad_jest_z_pobranej_rozmowy_i_mozna_go_wyszukac_lokalnie(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    zakoncz(jobs)
    assert not w._podglady and len(t.calls) == 1
    w.lista.setCurrentRow(0)
    t.payload = {
        "messages": [dict(wiadomosc(), subject="Testowy temat zwrotu")],
        "offset": 0,
        "limit": 20,
    }
    zakoncz(jobs)
    w.filtr.setText("Testowy temat zwrotu")
    assert w.lista.count() == 1 and len(t.calls) == 2
    assert w.tytul.text() == "Wybierz rozmowę"
    w.lista.setCurrentRow(0)
    # Kolejny GET tylko po jawnym wyborze, nie po zmianie filtra.
    assert len(jobs) == 1


def test_brak_fikcyjnych_kpi_ai_i_zapisu_na_allegro(qtbot):
    dialog, _, jobs, _ = okno(qtbot)
    w = dialog.panel
    zakoncz(jobs)
    assert len(w.kpi) == 5
    for key in ("oczekujace", "rozwiazane", "czas"):
        assert w.kpi[key].liczba.text() == "—"
    for key in ("zwroty", "reklamacje", "spory", "archiwum"):
        assert not w.filtry[key].isEnabled()
    assert not w.edytor.wyslij.isEnabled()
    assert not w.vexai.sugestia.toPlainText()
    assert "AI niepodłączone" in " ".join(
        label.text() for label in w.vexai.findChildren(type(w.stan))
    )


def test_zamkniecie_czysci_szkic_i_oczekujacy_callback(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    zakoncz(jobs)
    w.lista.setCurrentRow(0)
    w.edytor.odpowiedz.setPlainText("Szkic przed zamknięciem")
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    fn, callback, error = jobs.pop(0)
    result = fn()
    dialog.reject()
    callback(result)
    assert not w._robocze and not w.tresc.toPlainText()
    assert not w.edytor.odpowiedz.toPlainText()


def test_uklad_czterech_kolumn_i_zwijanie_paneli_bez_odczytu_api(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    zakoncz(jobs)
    dialog.resize(1600, 1000)
    qtbot.waitUntil(lambda: w.ai_scroll.isVisible() and w.klient_scroll.isVisible())
    w.ai_button.click()
    assert not w.ai_scroll.isVisible()
    w.ai_button.click()
    assert w.ai_scroll.isVisible()
    dialog.resize(1000, 800)
    qtbot.waitUntil(lambda: not w.ai_scroll.isVisible())
    assert len(t.calls) == 1 and not jobs


def test_odswiezenie_listy_nie_wysyla_dodatkowego_get_wybranego_watku(qtbot):
    from tests.integration.test_wiadomosci_allegro import watek

    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    zakoncz(jobs)
    w.lista.setCurrentRow(0)
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    zakoncz(jobs)
    assert w._podglady
    w.odswiez.click()
    assert len(jobs) == 1 and not w._podglady
    t.payload = {"threads": [watek()], "offset": 0, "limit": 20}
    zakoncz(jobs)
    assert not jobs and len(t.calls) == 3


def test_w_niskim_oknie_edytor_jest_rozwijany_a_historia_czytelna(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    zakoncz(jobs)
    dialog.resize(1366, 660)
    qtbot.waitUntil(lambda: w.edytor_button.isVisible())
    assert not w.edytor.isVisible() and w.tresc.height() >= 120
    w.lista.setCurrentRow(0)
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    zakoncz(jobs)
    w.edytor_button.click()
    assert w.edytor.isVisible()
    w.klient.dodaj_notatke.click()
    assert w.edytor.tryby.currentIndex() == 1


def test_jasny_motyw_ma_jasne_karty_rozmow(qtbot, qapp):
    from vexlab.gui.design_system import zastosuj_motyw
    from vexlab.przypadki_uzycia.powloka import Motyw

    zastosuj_motyw(qapp, Motyw.JASNY)
    try:
        dialog, _, jobs, _ = okno(qtbot)
        w = dialog.panel
        zakoncz(jobs)
        image = w.lista.viewport().grab().toImage()
        assert image.pixelColor(10, 10).lightness() > 150
    finally:
        zastosuj_motyw(qapp, Motyw.CIEMNY)
