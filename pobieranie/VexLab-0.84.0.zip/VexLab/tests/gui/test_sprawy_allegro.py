from tests.integration.test_sprawy_allegro import chat, issue, serwis, sesja, zwrot
from tests.integration.test_wiadomosci_allegro import Czas, Transport
from vexlab.gui.wiadomosci_allegro import OknoWiadomosci
from vexlab.kanaly.wiadomosci_allegro import WiadomosciAllegroAPI
from vexlab.przypadki_uzycia.wiadomosci_allegro import OdczytajWiadomosciAllegro


def okno(qtbot):
    uc, transport = serwis({})
    msg = OdczytajWiadomosciAllegro(
        WiadomosciAllegroAPI(Transport({"threads": [], "offset": 0, "limit": 20})), Czas()
    )
    jobs, account = [], [sesja()]
    dialog = OknoWiadomosci(msg, lambda *a: jobs.append(a), lambda: account[0], "", sprawy=uc)
    qtbot.addWidget(dialog)
    dialog.show()
    zakoncz(jobs)
    return dialog, transport, jobs, account


def zakoncz(jobs, index=0):
    fn, callback, error = jobs.pop(index)
    callback(fn())


def test_zwroty_w_zakladce_z_rzeczywistymi_szczegolami_i_powrotem_do_rozmow(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    w.filtry["zwroty"].click()
    t.payload = {"count": 1, "customerReturns": [zwrot()]}
    zakoncz(jobs)
    p = w.panel_spraw
    assert p.lista.count() == 1 and w.kpi["rozmowy"].liczba.text() == "1"
    assert w.tresc_zrodla.currentWidget() is p
    p.lista.setCurrentRow(0)
    t.payload = zwrot()
    zakoncz(jobs)
    assert "Część testowa" in p.detale.toPlainText()
    assert "Przesyłka dostarczona" in p.detale.toPlainText()
    assert not p.chat.isVisible() and not jobs
    w.filtry["wszystkie"].click()
    assert w.tresc_zrodla.currentWidget() is w.split and w.kpi["rozmowy"].liczba.text() == "0"
    assert all(call[0] == "GET" for call in t.calls)


def test_reklamacja_ma_historie_i_spoznione_szczegoly_nie_zmieniaja_wyboru(qtbot):
    dialog, t, jobs, _ = okno(qtbot)
    w = dialog.panel
    w.filtry["reklamacje"].click()
    t.payload = {"issues": [issue(1), issue(2)]}
    zakoncz(jobs)
    p = w.panel_spraw
    p.lista.setCurrentRow(0)
    old_fn, old_ok, old_error = jobs.pop(0)
    t.payload = issue(1)
    old_result = old_fn()
    p.lista.setCurrentRow(1)
    old_ok(old_result)
    old_error("HTTP", "stary błąd")
    assert p._wybrana.id == issue(2)["id"] and "stary błąd" not in p.info.text()
    t.payload = issue(2)
    zakoncz(jobs)
    t.payload = {"chat": [dict(chat(), text="Treść &oacute; <img src='https://example.invalid'>")]}
    zakoncz(jobs)
    assert "Treść ó <img" in p.chat.toPlainText()
    assert "Termin decyzji" in p.detale.toPlainText()
    assert all(call[0] == "GET" for call in t.calls)


def test_zmiana_konta_czysci_sprawy_i_odrzuca_spozniony_wynik(qtbot):
    dialog, t, jobs, account = okno(qtbot)
    w = dialog.panel
    w.filtry["spory"].click()
    t.payload = {"issues": [issue(1, "DISPUTE")]}
    fn, callback, error = jobs.pop(0)
    result = fn()
    account[0] = None
    w.polaczenie()
    callback(result)
    error("HTTP", "stary błąd")
    p = w.panel_spraw
    assert not p._rows and not p.detale.toPlainText() and not p.chat.toPlainText()
    assert w.kpi["rozmowy"].liczba.text() == "—"
    assert all(
        w.filtry[key].text().endswith("—")
        for key in ("wszystkie", "nieodczytane", "zwroty", "reklamacje", "spory")
    )
