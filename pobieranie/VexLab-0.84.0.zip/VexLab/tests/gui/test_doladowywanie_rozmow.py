from tests.gui.test_wiadomosci_allegro import okno, zakoncz
from tests.integration.test_wiadomosci_allegro import watek, wiadomosc


def lista(qtbot):
    dialog, transport, jobs, account = okno(qtbot)
    transport.payload["threads"] = [watek(f"thread-{i}") for i in range(1, 21)]
    zakoncz(jobs)
    qtbot.waitUntil(lambda: dialog.panel.lista.verticalScrollBar().maximum() > 0)
    return dialog, transport, jobs, account


def test_przewijanie_dopisuje_bez_duplikatow_i_zachowuje_rozmowe_szkic_i_pozycje(qtbot):
    dialog, t, jobs, _ = lista(qtbot)
    w = dialog.panel
    w.lista.setCurrentRow(0)
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    zakoncz(jobs)
    before = w.tresc.toPlainText()
    w.edytor.odpowiedz.setPlainText("Szkic podczas przewijania")
    bar = w.lista.verticalScrollBar()
    bar.setValue(bar.maximum())
    scroll = bar.value()
    for _ in range(3):
        w._doladuj_liste()
    assert len(jobs) == 1
    t.payload = {
        "threads": [watek(f"thread-{i}") for i in range(19, 39)],
        "offset": 20,
        "limit": 20,
    }
    zakoncz(jobs)
    assert w.lista.count() == 38 and len(w._wczytane) == 38
    assert w.kpi["rozmowy"].liczba.text() == "38"
    assert w._wybrany == "thread-1" and w.tresc.toPlainText() == before
    assert w.edytor.odpowiedz.toPlainText() == "Szkic podczas przewijania"
    assert bar.value() == scroll and not jobs
    bar.setValue(bar.maximum())
    assert len(jobs) == 1
    t.payload = {"threads": [watek("thread-39"), watek("thread-40")], "offset": 40, "limit": 20}
    zakoncz(jobs)
    assert w.lista.count() == 40 and not w._ma_wiecej
    bar.setValue(bar.maximum())
    w._doladuj_liste()
    assert not jobs


def test_blad_doladowania_nie_kasuje_listy_i_wymaga_jawnego_ponowienia(qtbot):
    dialog, t, jobs, _ = lista(qtbot)
    w = dialog.panel
    bar = w.lista.verticalScrollBar()
    bar.setValue(bar.maximum())
    jobs.pop(0)[2]("LIMIT", "Limit testowy")
    assert w.lista.count() == 20 and w.ponow_liste.isVisible()
    for _ in range(3):
        w._doladuj_liste()
    assert not jobs
    w.ponow_liste.click()
    assert len(jobs) == 1
    t.payload = {"threads": [watek("thread-21")], "offset": 20, "limit": 20}
    zakoncz(jobs)
    assert w.lista.count() == 21 and not w.ponow_liste.isVisible()


def test_zmiana_konta_odrzuca_spozniona_doklejke(qtbot):
    dialog, t, jobs, account = lista(qtbot)
    w = dialog.panel
    w.lista.verticalScrollBar().setValue(w.lista.verticalScrollBar().maximum())
    fn, callback, error = jobs.pop(0)
    t.payload = {"threads": [watek("thread-21")], "offset": 20, "limit": 20}
    result = fn()
    account[0] = None
    w.polaczenie()
    callback(result)
    error("HTTP", "Spóźniony błąd")
    assert not w._wczytane and not w.lista.count()
    assert w.kpi["rozmowy"].liczba.text() == "—"


def test_odczyt_wiadomosci_i_doladowanie_listy_maja_osobne_generacje(qtbot):
    dialog, t, jobs, _ = lista(qtbot)
    w = dialog.panel
    w.lista.setCurrentRow(0)
    w.lista.verticalScrollBar().setValue(w.lista.verticalScrollBar().maximum())
    assert len(jobs) == 2
    fn, callback, _ = jobs.pop(1)
    t.payload = {"threads": [watek("thread-21")], "offset": 20, "limit": 20}
    callback(fn())
    assert w._wybrany == "thread-1"
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    zakoncz(jobs)
    assert "Treść syntetyczna" in w.tresc.toPlainText()
