import pytest
from PySide6.QtCore import QSettings

from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji, PreferencjePowloki
from vexlab.rdzen.kontrakty import BladTechniczny


def test_zapamietanie_interwalu_i_zgodnosc_starych_ustawien(tmp_path):
    settings = QSettings(str(tmp_path / "p.ini"), QSettings.Format.IniFormat)
    store = PreferencjeQt(settings)
    assert store.odczytaj().odswiezanie_wiadomosci_minuty == 10
    shell = PowlokaAplikacji(store, "test", "test")
    shell.ustaw_odswiezanie_wiadomosci(2)
    assert store.odczytaj().odswiezanie_wiadomosci_minuty == 2
    shell.ustaw_odswiezanie_wiadomosci(60)
    assert store.odczytaj().odswiezanie_wiadomosci_minuty == 60
    shell.ustaw_odswiezanie_wiadomosci(0)
    assert store.odczytaj().odswiezanie_wiadomosci_minuty == 0
    settings.setValue("allegro/wiadomosci_odswiezanie_minuty", "bad")
    assert store.odczytaj().odswiezanie_wiadomosci_minuty == 10


def test_awaria_zapisu_i_nieprawidlowy_interwal_nie_zmieniaja_preferencji():
    class Store:
        def odczytaj(self):
            return PreferencjePowloki()

        def zapisz(self, value):
            raise BladTechniczny("Testowa awaria zapisu")

    shell = PowlokaAplikacji(Store(), "test", "test")
    with pytest.raises(BladTechniczny):
        shell.ustaw_odswiezanie_wiadomosci(1)
    assert shell.preferencje.odswiezanie_wiadomosci_minuty == 10
    for value in (True, -1, 7, 1000):
        with pytest.raises(ValueError):
            shell.ustaw_odswiezanie_wiadomosci(value)
