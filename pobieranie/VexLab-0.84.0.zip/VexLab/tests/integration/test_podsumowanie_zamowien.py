import csv
from dataclasses import replace

import pytest

from tests.integration.test_zamowienia_allegro import API, Czas, raw, sesja
from vexlab.adaptery.eksport_zamowien_csv import EksportZamowienCSV
from vexlab.kanaly.zamowienia_allegro import mapuj_zamowienie
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.zamowienia_allegro import (
    OdczytajZamowieniaAllegro,
    RaportZamowien,
    obrot_zamowien,
)
from vexlab.rdzen.kontrakty import BladTechniczny


def raport(*rows):
    return RaportZamowien(
        "konto",
        "test",
        "sandbox",
        "2026-10-19T10:00:00+00:00",
        "2026-11-18T10:00:00+00:00",
        "czas",
        rows,
    )


def test_obrot_pelne_30_dni_waluty_i_anulowane():
    row = replace(mapuj_zamowienie(raw()), kupiono="2026-11-18T09:00:00Z")
    cancelled = replace(row, status="CANCELLED", kwota="999.00 PLN")
    assert obrot_zamowien(raport(row, cancelled))[0] == "123,00 PLN"
    mixed = obrot_zamowien(raport(row, replace(row, kwota="99.50 EUR")))
    assert mixed[0] == "Wiele walut" and "99,50 EUR" in mixed[1]
    assert obrot_zamowien(replace(raport(row), od="2026-11-11T10:00:00+00:00"))[0] == "—"
    assert obrot_zamowien(raport(replace(row, kupiono="")))[0] == "—"


def test_parser_zachowuje_dane_klienta_date_zakupu_i_id_oferty():
    data = raw()
    data["buyer"].update(
        firstName="Jan",
        lastName="Testowy",
        email="test@example.org",
        phoneNumber="123",
        address={"countryCode": "PL"},
    )
    data["lineItems"][0]["boughtAt"] = "2026-11-17T09:00:00Z"
    data["lineItems"][0]["offer"]["id"] = "1234"
    row = mapuj_zamowienie(data)
    assert (row.klient, row.email, row.telefon, row.kraj) == (
        "Jan Testowy",
        "test@example.org",
        "123",
        "PL",
    )
    assert row.kupiono == "2026-11-17T09:00:00Z" and row.pozycje[0].oferta_id == "1234"


def test_jawny_eksport_wybranych_bez_nadpisania_i_z_ochrona_formul(tmp_path):
    row = replace(mapuj_zamowienie(raw()), kupujacy="=SUM(1;2)", email="prywatny@example.org")
    report = replace(raport(row), srodowisko=sesja().srodowisko.value)
    uc = OdczytajZamowieniaAllegro(API(), Czas(), zapis=EksportZamowienCSV())
    path = tmp_path / "zamowienia.csv"
    assert uc.eksportuj(sesja(), report, (row,), path) == 1
    with path.open(encoding="utf-8-sig", newline="") as f:
        result = list(csv.reader(f, delimiter=";"))
    assert result[1][7].startswith("'=SUM")
    assert "prywatny@example.org" not in path.read_text(encoding="utf-8-sig")
    original = path.read_bytes()
    with pytest.raises(BladTechniczny):
        uc.eksportuj(sesja(), report, (row,), path)
    assert path.read_bytes() == original
    with pytest.raises(BladAllegro):
        uc.eksportuj(sesja(), replace(report, konto="inne"), (row,), tmp_path / "inne.csv")
    assert not (tmp_path / "inne.csv").exists()


def test_wybor_waluty_obrotu_nie_przelicza_innych_walut():
    row = replace(mapuj_zamowienie(raw()), kupiono="2026-11-18T09:00:00Z")
    mixed = raport(row, replace(row, kwota="50.00 EUR"))
    assert obrot_zamowien(mixed, "PLN")[0] == "123,00 PLN"
    assert obrot_zamowien(mixed, "EUR")[0] == "50,00 EUR"


def test_obrot_wybranego_jednego_dnia_wyklucza_starsze_i_anulowane():
    fresh = replace(mapuj_zamowienie(raw()), kupiono="2026-11-18T09:00:00Z", kwota="100.00 PLN")
    old = replace(fresh, kupiono="2026-11-16T09:00:00Z", kwota="900.00 PLN")
    cancelled = replace(fresh, status="CANCELLED", kwota="500.00 PLN")
    r = replace(raport(fresh, old, cancelled), od="2026-11-17T10:00:00+00:00")
    assert obrot_zamowien(r, "PLN", dni=1)[0] == "100,00 PLN"
    assert obrot_zamowien(r, "PLN", dni=30)[0] == "—"
