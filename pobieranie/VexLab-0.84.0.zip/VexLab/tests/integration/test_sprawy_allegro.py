from dataclasses import replace
from urllib.parse import parse_qs, urlsplit
from uuid import UUID

import pytest

from tests.integration.test_wiadomosci_allegro import Czas, Transport
from tests.integration.test_wiadomosci_allegro import sesja as sesja_wiadomosci
from vexlab.kanaly.sprawy_allegro import SprawyAllegroAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.sprawy_allegro import OdczytajSprawyAllegro, RodzajSprawy


def sesja():
    s = sesja_wiadomosci()
    return replace(s, aplikacja=replace(s.aplikacja, odczyt_spraw=True))


def issue(n=1, kind="CLAIM", status=None):
    return {
        "id": str(UUID(int=n)),
        "type": kind,
        "referenceNumber": "R/TEST",
        "openedDate": "2026-11-23T10:00:00Z",
        "decisionDueDate": "2026-12-07T10:00:00Z",
        "subject": "Temat testowy",
        "buyer": {"login": "klient_testowy"},
        "checkoutForm": {"id": str(UUID(int=100))},
        "currentState": {
            "status": status or ("CLAIM_SUBMITTED" if kind == "CLAIM" else "DISPUTE_ONGOING"),
            "chatActive": True,
        },
        "description": "Opis testowy",
        "expectations": [{"name": "REPAIR"}],
        "attachments": [{"fileName": "test.txt", "url": "https://example.invalid/file"}],
    }


def zwrot(n=1):
    return {
        "id": str(UUID(int=n)),
        "referenceNumber": "Z/TEST",
        "createdAt": "2026-11-23T10:00:00Z",
        "status": "DELIVERED",
        "orderId": str(UUID(int=100)),
        "buyer": {"login": "klient_testowy", "email": "fixture@example.invalid"},
        "items": [
            {
                "name": "Część testowa",
                "quantity": 1,
                "price": {"amount": "123.00", "currency": "PLN"},
                "reason": {"type": "MISTAKE", "userComment": "Powód testowy"},
            }
        ],
        "parcels": [{"carrierId": "TEST", "waybill": "TEST-1"}],
        "refund": {"bankAccount": {"accountNumber": "fixture-bank"}},
    }


def chat(n=1, role="BUYER"):
    return {
        "id": str(UUID(int=n)),
        "author": {"login": "klient_testowy", "role": role},
        "createdAt": "2026-11-23T10:00:00Z",
        "text": "Treść testowa",
        "attachments": [],
    }


def serwis(payload):
    t = Transport(payload)
    return OdczytajSprawyAllegro(SprawyAllegroAPI(t), Czas()), t


def test_odczyt_zwrotu_beta_orders_read_i_bez_danych_bankowych():
    uc, t = serwis({"count": 1, "customerReturns": [zwrot()]})
    page = uc.lista(sesja_wiadomosci(), RodzajSprawy.ZWROT)
    row = page.pozycje[0]
    assert row.zamowienie == str(UUID(int=100)) and "Część testowa" in row.pozycje[0]
    assert row.przesylki == ("TEST · TEST-1",)
    assert "fixture-bank" not in repr(row) and "klient_testowy" not in repr(page)
    call = t.calls[0]
    assert call[0] == "GET" and call[2]["Accept"] == "application/vnd.allegro.beta.v1+json"
    assert urlsplit(call[1]).path == "/order/customer-returns"
    assert parse_qs(urlsplit(call[1]).query) == {"limit": ["20"], "offset": ["0"]}


def test_otwarte_dyskusje_nie_obejmuja_zamknietych_ani_reklamacji():
    uc, t = serwis(
        {
            "issues": [
                issue(1, "DISPUTE"),
                issue(2, "DISPUTE", "DISPUTE_UNRESOLVED"),
                issue(3, "DISPUTE", "DISPUTE_CLOSED"),
                issue(4),
            ]
        }
    )
    page = uc.lista(sesja(), RodzajSprawy.DYSKUSJA)
    assert len(page.pozycje) == 2
    assert parse_qs(urlsplit(t.calls[0][1]).query)["status"] == [
        "DISPUTE_ONGOING",
        "DISPUTE_UNRESOLVED",
    ]
    assert t.calls[0][2]["Accept-Language"] == "pl-PL"


def test_reklamacja_szczegoly_i_korespondencja_systemowa():
    uc, t = serwis({"issues": [issue()]})
    page = uc.lista(sesja(), RodzajSprawy.REKLAMACJA)
    assert page.pozycje[0].termin == "2026-12-07T10:00:00Z"
    t.payload = issue()
    row = uc.szczegoly(sesja(), RodzajSprawy.REKLAMACJA, str(UUID(int=1)))
    assert row.oczekiwania == ("REPAIR",) and row.zalaczniki == ("test.txt",)
    system = chat(2, "SYSTEM")
    del system["author"]["login"]
    t.payload = {"chat": [chat(), system]}
    history = uc.historia(sesja(), RodzajSprawy.REKLAMACJA, row.id)
    assert history.pozycje[1].autor == "SYSTEM"
    assert "klient_testowy" not in repr(history)
    assert all(call[0] == "GET" for call in t.calls)
    assert all("beta.v1" in call[2]["Accept"] for call in t.calls)


@pytest.mark.parametrize("offset", [-1, True, 1, 2_147_483_660])
def test_zakres_przed_wywolaniem_portu(offset):
    uc, t = serwis({})
    with pytest.raises(BladAllegro):
        uc.lista(sesja(), RodzajSprawy.ZWROT, offset)
    assert not t.calls


def test_zgody_i_wygasniecie_bez_polaczenia_sieciowego():
    uc, t = serwis({})
    for s in (sesja_wiadomosci(), replace(sesja(), wygasa=0), replace(sesja(), aplikacja=None)):
        with pytest.raises(BladAllegro):
            uc.lista(s, RodzajSprawy.REKLAMACJA)
    for ident in ("../x", "x?foo=bar", "invalid"):
        with pytest.raises(BladAllegro):
            uc.szczegoly(sesja(), RodzajSprawy.REKLAMACJA, ident)
    assert not t.calls


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {"issues": None},
        {"issues": [issue(), issue()]},
        {"issues": [dict(issue(), openedDate="bad")]},
        {"issues": [dict(issue(), currentState={"status": 4})]},
    ],
)
def test_bledne_odpowiedzi_bez_falszywego_zera_i_ujawnienia_danych(payload):
    uc, _ = serwis(payload)
    with pytest.raises(BladAllegro) as exc:
        uc.lista(sesja(), RodzajSprawy.REKLAMACJA)
    assert "klient_testowy" not in str(exc.value)


@pytest.mark.parametrize(
    "status,kod", [(401, "AUTORYZACJA"), (403, "UPRAWNIENIA"), (429, "LIMIT"), (500, "HTTP")]
)
def test_blad_http_bez_automatycznego_ponowienia(status, kod):
    uc, t = serwis({"private": "fixture"})
    t.status = status
    with pytest.raises(BladAllegro) as exc:
        uc.lista(sesja(), RodzajSprawy.REKLAMACJA)
    assert exc.value.kod == kod and len(t.calls) == 1
    if status == 403:
        assert "allegro:api:disputes" in str(exc.value)


def test_pusta_strona_i_tozsamosc_szczegolow():
    uc, t = serwis({"issues": []})
    assert uc.lista(sesja(), RodzajSprawy.REKLAMACJA).pozycje == ()
    t.payload = issue(2)
    with pytest.raises(BladAllegro, match="szczegóły"):
        uc.szczegoly(sesja(), RodzajSprawy.REKLAMACJA, str(UUID(int=1)))


def test_oauth_disputes_jest_opcjonalny():
    t = Transport(
        {
            "device_code": "fixture",
            "user_code": "TEST",
            "verification_uri_complete": "https://allegro.pl.allegrosandbox.pl/auth",
            "expires_in": 600,
            "interval": 5,
        }
    )
    api = SprawyAllegroAPI(t)
    api.rozpocznij(sesja_wiadomosci().aplikacja)
    assert "allegro:api:disputes" not in parse_qs(t.calls[-1][3].decode())["scope"][0]
    api.rozpocznij(sesja().aplikacja)
    assert "allegro:api:disputes" in parse_qs(t.calls[-1][3].decode())["scope"][0].split()
