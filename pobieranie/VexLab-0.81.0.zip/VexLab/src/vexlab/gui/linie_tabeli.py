"""Subtelne separatory kolumn, niezależne od delegatów i modelu tabeli."""

from PySide6.QtCore import QEvent, QObject, Qt
from PySide6.QtGui import QColor, QPainter, QPaintEvent, QPen
from PySide6.QtWidgets import QTableView, QWidget


def kolor_separatora(ciemny: bool) -> str:
    return "#29384D" if ciemny else "#D7E1EC"


class LinieTabeli(QWidget):
    def __init__(self, tabela: QTableView) -> None:
        super().__init__(tabela.viewport())
        self.tabela = tabela
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setAutoFillBackground(False)
        tabela.viewport().installEventFilter(self)
        tabela.horizontalHeader().geometriesChanged.connect(self._odswiez)
        tabela.horizontalHeader().sectionResized.connect(self._odswiez)
        tabela.horizontalHeader().sectionMoved.connect(self._odswiez)
        tabela.horizontalScrollBar().valueChanged.connect(self._odswiez)
        tabela.verticalScrollBar().valueChanged.connect(self._odswiez)
        self._odswiez()
        self.show()

    def _odswiez(self, *_: object) -> None:
        self.setGeometry(self.tabela.viewport().rect())
        self.raise_()
        self.update()

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if event.type() in (QEvent.Type.Resize, QEvent.Type.Show):
            self._odswiez()
        return False

    def paintEvent(self, event: QPaintEvent) -> None:
        header = self.tabela.horizontalHeader()
        if header.isHidden():
            return  # Lista kart z ukrytym nagłówkiem nie jest tabelą danych.
        painter = QPainter(self)
        dark = self.tabela.palette().color(self.tabela.palette().ColorRole.Window).lightness() < 128
        pen = QPen(QColor(kolor_separatora(dark)), 1)
        pen.setCosmetic(True)
        painter.setPen(pen)
        for visual in range(header.count()):
            column = header.logicalIndex(visual)
            if header.isSectionHidden(column):
                continue
            x = header.sectionViewportPosition(column) + header.sectionSize(column) - 1
            if 0 <= x < self.width():
                painter.drawLine(x, 0, x, self.height())
