"""Prezentacja istniejących problemów paczki i planu Allegro. Bez nowej walidacji."""

from dataclasses import dataclass

from vexlab.przypadki_uzycia.nowe_szkice_allegro import PlanNowegoSzkicu, WynikTworzenia
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad

NAZWY_KONTROLI = (
    "Zdjęcia",
    "GPSR",
    "Parametry",
    "Producent lokalny",
    "Kategoria",
    "VAT",
    "EAN",
    "Produkt Allegro",
)
SLOWA = {
    "gpsr": ("gpsr", "dostaw", "warunk", "responsible"),
    "parametry": ("parametr", "parameter", "numer katalogowy"),
    "ean": ("ean", "gtin"),
    "kategoria": ("kategori", "category"),
    "zdjecia": ("zdję", "galeria", "image", "adres obrazu"),
    "vat": ("vat", "stawka podatku"),
    "opis": ("opis", "description", "sekcj", "html"),
    "produkt": ("produktu allegro", "produkt z katalogu", "produkt ręcznie", "producent"),
}


@dataclass(frozen=True)
class OznaczenieOferty:
    status: str
    ton: str
    gotowa: bool
    grupy: frozenset[str]
    problemy: tuple[str, ...]
    kontrole: tuple[tuple[str, str, str], ...]
    plan: PlanNowegoSzkicu | None = None


def oznacz_oferte(
    oferta: OfertaPodglad,
    plan: PlanNowegoSzkicu | None = None,
    wynik: WynikTworzenia | None = None,
    *,
    mozna_utworzyc: bool = False,
    trwa: bool = False,
    producent: str = "",
    producent_wymagany: bool = False,
    blad_operacji: str = "",
    zmieniona: bool = False,
) -> OznaczenieOferty:
    """Odczytujemy wynik kontroli; obecność pola nie jest dowodem poprawności."""
    errors = list(oferta.problemy)
    if plan:
        errors.extend(plan.bledy)
    if wynik and wynik.stan in {"Do poprawy", "Odrzucono", "Wstrzymano"} and wynik.komunikat:
        errors.append(wynik.komunikat)
    if blad_operacji:
        errors.append(blad_operacji)
    if zmieniona:
        errors.append("Dane tej pozycji zmieniono w przygotowaniu Allegro. Sprawdź je w tym oknie.")
    errors = list(dict.fromkeys(errors))
    text = " ".join(errors).casefold()
    groups = {key for key, words in SLOWA.items() if any(word in text for word in words)}
    if plan is not None and plan.ustawienia.nowy:
        groups.add("nowe")
    if errors:
        groups.add("bledy")
    missing_producer = plan is not None and producent_wymagany and not producent.strip()
    if missing_producer:
        errors.append("Wybierz lub wpisz producenta lokalnego w istniejącym przygotowaniu Allegro.")
        groups.update(("producent", "bledy"))
    state = wynik.stan if wynik else ""
    uncertain = state in {"Wynik nieznany", "Wymaga sprawdzenia", "Przetwarzanie"}
    saved = bool(
        wynik
        and (
            wynik.ident
            or state in {"Utworzono szkic", "Szkic kompletny", "Już na Allegro", "Szkic do poprawy"}
        )
    )
    ready = bool(
        plan
        and mozna_utworzyc
        and not trwa
        and not blad_operacji
        and not zmieniona
        and not missing_producer
        and not errors
        and not saved
        and not uncertain
    )
    if ready:
        status, tone = "Gotowe do szkicu", "zielony"
        groups.add("gotowe")
    elif trwa:
        status, tone = "Sprawdzanie / operacja", "szary"
    elif uncertain or blad_operacji:
        status, tone = (
            "Szkic · sprawdź dane" if wynik and wynik.odczytany_szkic else "Sprawdź wynik",
            "zloty",
        )
        groups.add("bledy")
        if wynik and wynik.komunikat and wynik.komunikat not in errors:
            errors.append(wynik.komunikat)
    elif state == "Wstrzymano":
        status, tone = "Wstrzymano", "zloty"
    elif saved:
        status, tone = "Zapisano / sprawdź dane", "niebieski"
    elif "ean" in groups:
        status, tone = "Problem z EAN", "czerwony"
    elif "gpsr" in groups:
        status, tone = "Brak / błąd GPSR", "zloty"
    elif "parametry" in groups:
        status, tone = "Sprawdź parametry", "zloty"
    elif "kategoria" in groups:
        status, tone = "Sprawdź kategorię", "zloty"
    elif missing_producer:
        status, tone = "Brak producenta", "zloty"
    elif errors:
        status, tone = "Wymaga poprawy", "czerwony"
    else:
        status, tone = "Do sprawdzenia", "szary"

    checks: list[tuple[str, str, str]] = []
    for name, key in zip(
        NAZWY_KONTROLI,
        ("zdjecia", "gpsr", "parametry", "producent", "kategoria", "vat", "ean", "produkt"),
        strict=True,
    ):
        label, color = "Nie sprawdzono", "szary"
        if key in groups:
            label, color = "Wymaga sprawdzenia", "czerwony"
        elif plan and not trwa and not blad_operacji and not zmieniona:
            if key == "zdjecia":
                label, color = "Brak błędu w planie", "zielony"
            elif key == "gpsr" and plan.ustawienia.sprzedaz is not None:
                label, color = "Ustawienia sprawdzone", "zielony"
            elif key == "parametry" and plan.produkt is not None:
                label, color = "Brak błędu w planie", "zielony"
            elif key == "producent" and producent.strip():
                label, color = "Wybrano lokalnie", "zielony"
            elif key == "producent" and not producent_wymagany:
                label = "Nie dotyczy zapisu lokalnego"
            elif key == "kategoria" and plan.produkt and plan.produkt.kategoria:
                label, color = "Kategoria w planie", "zielony"
            elif key == "vat" and plan.ustawienia.vat is not None:
                label, color = "Ustawienia sprawdzone", "zielony"
            elif (
                key == "ean"
                and not plan.ustawienia.nowy
                and (not plan.ustawienia.produkt or plan.ustawienia.automatyczny)
                and oferta.ean
                and plan.produkt
            ):
                label, color = "Sprawdzono przy dopasowaniu", "zielony"
            elif key == "produkt" and plan.produkt:
                label, color = (
                    (
                        "Definicja nowego produktu"
                        if plan.ustawienia.nowy
                        else "Dopasowany w planie"
                    ),
                    "zielony",
                )
        checks.append((name, label, color))
    return OznaczenieOferty(
        status, tone, ready, frozenset(groups), tuple(errors), tuple(checks), plan
    )
