"""Podgląd przenośnych danych użytkownika przed atomowym importem katalogu."""

from pathlib import Path
from typing import cast

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.podglad_oferty import ObrazPodgladu
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.katalog_uzytkownika import (
    KatalogUzytkownika,
    ProduktUzytkownika,
    WynikKatalogu,
)


class ImportProduktowUzytkownika(QDialog):
    zmieniono = Signal()

    def __init__(
        self, parent: QWidget, serwis: KatalogUzytkownika, plik: Path, uruchom: Uruchom
    ) -> None:
        super().__init__(parent)
        self.serwis, self.plik, self.uruchom = serwis, plik, uruchom
        self.dane: tuple[ProduktUzytkownika, ...] = ()
        self.trwa = False
        self.setWindowTitle("Import produktów ze zdjęciami")
        rect = self.screen().availableGeometry()
        self.setMinimumSize(min(780, rect.width() - 40), min(480, rect.height() - 60))
        self.resize(min(1200, rect.width() - 40), min(720, rect.height() - 60))
        layout = QVBoxLayout(self)
        header = etykieta("Importuj produkty użytkownika")
        header.setObjectName("tytulStronyAllegro")
        layout.addWidget(header)
        layout.addWidget(
            etykieta(
                "Wybierz produkty. Istniejące SKU zostaną zachowane; uzupełnimy puste pola. "
                "Producent, cena i zdjęcia zapiszą się lokalnie."
            )
        )
        self.tabela = QTableWidget(0, 7)
        self.tabela.setHorizontalHeaderLabels(
            ["Zdjęcie", "SKU / wybór", "Nazwa", "Producent", "EAN", "Cena", "Galeria"]
        )
        layout.addWidget(self.tabela, 1)
        self.info = etykieta("Wczytaj paczkę VexLab, aby zobaczyć produkty przed importem.")
        layout.addWidget(self.info)
        buttons = QHBoxLayout()
        self.pobierz = QPushButton("Wczytaj paczkę")
        self.pobierz.clicked.connect(self.odczytaj)
        buttons.addWidget(self.pobierz)
        buttons.addStretch()
        self.zapis = QPushButton("Importuj zaznaczone…")
        self.zapis.setObjectName("primary")
        self.zapis.setEnabled(False)
        self.zapis.clicked.connect(self.importuj)
        buttons.addWidget(self.zapis)
        self.zamknij = QPushButton("Zamknij")
        self.zamknij.clicked.connect(self.reject)
        buttons.addWidget(self.zamknij)
        layout.addLayout(buttons)

    def busy(self, value: bool) -> None:
        self.trwa = value
        self.pobierz.setEnabled(not value)
        self.zapis.setEnabled(not value and bool(self.dane))
        self.tabela.setEnabled(not value)
        self.zamknij.setEnabled(not value)

    def blad(self, _kod: str, text: str) -> None:
        self.busy(False)
        self.info.setText(text)

    def odczytaj(self) -> None:
        if self.trwa:
            return
        self.dane = ()
        self.tabela.setRowCount(0)
        self.busy(True)
        self.info.setText("Odczytywanie paczki i sprawdzanie zdjęć…")

        def ok(value: object) -> None:
            self.dane = cast(tuple[ProduktUzytkownika, ...], value)
            self.tabela.setRowCount(len(self.dane))
            for row, p in enumerate(self.dane):
                mini = ObrazPodgladu("", kwadratowy=True)
                mini.setAccessibleName("Miniatura produktu " + p.sku)
                if p.zdjecia:
                    mini.ustaw(p.zdjecia[0].miniatura)
                else:
                    mini.setText("Brak")
                self.tabela.setCellWidget(row, 0, mini)
                self.tabela.setRowHeight(row, 72)
                price = f"{p.cena.tekst} {p.cena.waluta} {p.cena.rodzaj}" if p.cena else "—"
                for col, text in enumerate(
                    (p.sku, p.nazwa, p.producent, p.ean, price, str(len(p.zdjecia)))
                ):
                    item = QTableWidgetItem(text)
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    if col == 0:
                        item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                        item.setCheckState(Qt.CheckState.Checked)
                    self.tabela.setItem(row, col + 1, item)
            self.tabela.resizeColumnsToContents()
            self.busy(False)
            self.info.setText(
                f"Wczytano: {len(self.dane)} produktów. Zapis nastąpi po potwierdzeniu."
            )

        self.uruchom(lambda: self.serwis.odczytaj(self.plik), ok, self.blad)

    def importuj(self) -> None:
        if self.trwa:
            return
        chosen = tuple(
            p
            for row, p in enumerate(self.dane)
            if cast(QTableWidgetItem, self.tabela.item(row, 1)).checkState()
            == Qt.CheckState.Checked
        )
        if not chosen:
            self.info.setText("Zaznacz produkty do importu.")
            return
        if (
            QMessageBox.question(
                self,
                "Importuj dane użytkownika",
                f"Zapisać {len(chosen)} produktów ze zdjęciami? Istniejących pól nie nadpiszemy. "
                "Przed zapisem powstanie kopia bazy.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        self.busy(True)

        def ok(value: object) -> None:
            result = cast(WynikKatalogu, value)
            self.busy(False)
            self.info.setText(result.tekst)
            self.zmieniono.emit()

        self.uruchom(lambda: self.serwis.importuj(chosen), ok, self.blad)

    def reject(self) -> None:
        if not self.trwa:
            super().reject()
