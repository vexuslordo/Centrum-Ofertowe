"""Tabela źródłowych pozycji, wybór wszystkich wyników niezależny od strony."""

from collections.abc import Callable

from PySide6.QtCore import QItemSelectionModel, Qt
from PySide6.QtGui import QKeyEvent, QMouseEvent
from PySide6.QtWidgets import QAbstractItemView, QHeaderView, QTableWidget

from vexlab.gui.wybor_tabeli import wybor_klawiatura, wybor_mysza


class TabelaPozycji(QTableWidget):
    def __init__(
        self, naglowki: list[str], wszystkie: Callable[[], None], odznacz: Callable[[], None]
    ) -> None:
        super().__init__(0, len(naglowki))
        self.wszystkie, self.odznacz = wszystkie, odznacz
        self.setHorizontalHeaderLabels(naglowki)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.horizontalHeader().setStretchLastSection(True)

    def selectAll(self) -> None:
        self.wszystkie()

    def clearSelection(self) -> None:
        self.odznacz()

    def mousePressEvent(self, event: QMouseEvent) -> None:
        index = self.indexAt(event.position().toPoint())
        if (
            index.isValid()
            and index.column() == 0
            and self.property("checkbox_cennika")
            and event.button() == Qt.MouseButton.LeftButton
            and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier
        ):
            self.selectionModel().select(
                index,
                QItemSelectionModel.SelectionFlag.Toggle | QItemSelectionModel.SelectionFlag.Rows,
            )
            self.selectionModel().setCurrentIndex(index, QItemSelectionModel.SelectionFlag.NoUpdate)
            event.accept()
            return
        wybor_mysza(self, event, self.odznacz)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        index = self.indexAt(event.position().toPoint())
        if (
            index.isValid()
            and index.column() == 0
            and self.property("checkbox_cennika")
            and event.button() == Qt.MouseButton.LeftButton
            and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier
        ):
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key.Key_Space and self.currentIndex().isValid():
            self.selectionModel().select(
                self.currentIndex(),
                QItemSelectionModel.SelectionFlag.Toggle | QItemSelectionModel.SelectionFlag.Rows,
            )
            event.accept()
            return
        if not wybor_klawiatura(event, self.odznacz):
            super().keyPressEvent(event)
