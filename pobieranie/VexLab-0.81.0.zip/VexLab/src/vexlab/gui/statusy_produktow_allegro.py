"""Odczyt kropek w tle, wyłącznie dla aktualnej sesji i kompletnej listy."""

from collections.abc import Callable
from threading import Event
from typing import cast

from PySide6.QtCore import QObject, QTimer, Signal

from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.katalog import ProduktDTO
from vexlab.przypadki_uzycia.statusy_produktow_allegro import (
    OdczytajStatusyProduktow,
    StatusyOfertProduktow,
    oznacz_statusy,
)


class StatusyProduktowAllegro(QObject):
    zmieniono = Signal()
    postep = Signal(int, int, int)

    def __init__(
        self,
        serwis: OdczytajStatusyProduktow | None,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
        parent: QObject,
    ) -> None:
        super().__init__(parent)
        self.serwis, self.uruchom, self.sesja = serwis, uruchom, sesja
        self.snapshot: StatusyOfertProduktow | None = None
        self.komunikat = "Nie sprawdzono ofert na połączonym koncie."
        self.trwa = False
        self._generacja = 0
        self._sesja: SesjaAllegro | None = None
        self._stop = Event()
        self.timer = QTimer(self)
        self.timer.setInterval(300_000)
        self.timer.timeout.connect(self.odswiez)
        self.postep.connect(self._postep)

    def oznacz(self, produkty: tuple[ProduktDTO, ...]) -> tuple[ProduktDTO, ...]:
        return oznacz_statusy(produkty, self.snapshot, self.sesja(), self.komunikat)

    def polaczenie(self) -> None:
        aktualna = self.sesja()
        if aktualna is self._sesja:
            return
        self._stop.set()
        self._generacja += 1
        self.trwa = False
        self.snapshot = None
        self.timer.stop()
        self._sesja = aktualna
        self.komunikat = "Połącz konto Allegro, aby sprawdzić aktywne oferty."
        self.zmieniono.emit()
        if aktualna is not None:
            self.odswiez()

    def anuluj(self) -> None:
        self._stop.set()
        self._generacja += 1
        self.trwa = False
        self.snapshot = None
        self.komunikat = "Anulowano sprawdzanie Allegro. Statusy niepotwierdzone."
        self.zmieniono.emit()

    def odswiez(self) -> None:
        s, serwis = self.sesja(), self.serwis
        if s is None or serwis is None or self.trwa:
            return
        self._sesja = s
        self._generacja += 1
        numer = self._generacja
        self._stop = stop = Event()
        self.snapshot = None
        self.trwa = True
        self.komunikat = "Sprawdzanie ofert Allegro…"
        self.zmieniono.emit()

        def ok(w: object) -> None:
            if numer != self._generacja or self.sesja() is not s:
                return
            self.snapshot = cast(StatusyOfertProduktow, w)
            self.trwa = False
            self.komunikat = (
                f"Allegro: sprawdzono {len(self.snapshot.oferty)} ofert konta {s.konto.login}."
            )
            self.timer.start()
            self.zmieniono.emit()

        def blad(_kod: str, tekst: str) -> None:
            if numer != self._generacja or self.sesja() is not s:
                return
            self.snapshot = None
            self.trwa = False
            self.komunikat = "Allegro: nie potwierdzono statusów. " + tekst
            self.zmieniono.emit()

        self.uruchom(
            lambda: serwis.odczytaj(
                s, stop.is_set, lambda n, total: self.postep.emit(numer, n, total)
            ),
            ok,
            blad,
        )

    def _postep(self, numer: int, n: int, total: int) -> None:
        if numer == self._generacja and self.trwa:
            self.komunikat = f"Allegro: sprawdzono {n} z {total} ofert…"
            self.zmieniono.emit()
