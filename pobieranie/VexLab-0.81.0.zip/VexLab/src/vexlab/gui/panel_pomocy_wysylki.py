"""Stała, kopiowalna wskazówka dla bieżącej oferty. Przyciski emitują wyłącznie intencję UI."""

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QBoxLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
)

from vexlab.gui.pomoc_wysylki_allegro import PomocWysylki


class PanelPomocyWysylki(QFrame):
    akcja = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self._akcja: str = ""
        self.setObjectName("karta")
        box = QVBoxLayout(self)
        box.setContentsMargins(10, 6, 10, 6)
        box.setSpacing(4)
        top = QHBoxLayout()
        self._naglowek = top
        self.tytul = QLabel("Co zrobić, aby przesłać ofertę?")
        self.tytul.setObjectName("tytulSekcjiAllegro")
        self.tytul.setTextFormat(Qt.TextFormat.PlainText)
        self.tytul.setWordWrap(True)
        self.tytul.setMaximumHeight(40)
        top.addWidget(self.tytul, 1)
        self.przycisk = QPushButton()
        self.przycisk.setObjectName("primary")
        self.przycisk.clicked.connect(lambda: self.akcja.emit(self._akcja))
        top.addWidget(self.przycisk)
        box.addLayout(top)
        fields = QHBoxLayout()
        self._pola = fields
        self.tresc = QPlainTextEdit()
        self.kroki = QPlainTextEdit()
        for caption, field, weight in (
            ("Pełny powód / wynik", self.tresc, 1),
            ("Co zrobić i gdzie poprawić", self.kroki, 2),
        ):
            column = QVBoxLayout()
            column.setSpacing(2)
            label = QLabel(caption)
            label.setObjectName("opis")
            column.addWidget(label)
            field.setReadOnly(True)
            field.setAccessibleName(caption)
            field.setMinimumHeight(60)
            field.setMaximumHeight(85)
            column.addWidget(field)
            fields.addLayout(column, weight)
        box.addLayout(fields)
        self.pokaz("", None, False)

    def ustaw_pionowo(self) -> None:
        """Ten sam powód i przycisk w wąskim panelu, bez zmiany obsługi akcji."""
        self._naglowek.setDirection(QBoxLayout.Direction.TopToBottom)
        self._pola.setDirection(QBoxLayout.Direction.TopToBottom)

    def pokaz(self, sku: str, pomoc: PomocWysylki | None, enabled: bool) -> None:
        if pomoc is None:
            self.tytul.setText("Co zrobić, aby przesłać ofertę?")
            self.tresc.setPlainText(
                "Wybierz wiersz. Zobaczysz pełny powód i następny krok dla tej oferty."
            )
            self.kroki.setPlainText("Wskazówka nie wysyła oferty automatycznie.")
            self.przycisk.hide()
            return
        self.tytul.setText(f"{sku} · {pomoc.tytul}")
        self.tresc.setPlainText(pomoc.powod)
        self.kroki.setPlainText(pomoc.kroki)
        self.tytul.setToolTip(self.tytul.text())
        self._akcja = pomoc.akcja
        self.przycisk.setText(pomoc.przycisk)
        self.przycisk.setVisible(bool(pomoc.akcja))
        self.przycisk.setEnabled(enabled)
