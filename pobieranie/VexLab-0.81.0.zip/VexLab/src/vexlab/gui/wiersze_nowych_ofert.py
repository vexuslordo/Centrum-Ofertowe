"""Dwuliniowy produkt i badge. Oryginalne wartości komórek pozostają bez zmian."""

from collections.abc import Callable

from PySide6.QtCore import QModelIndex, QPersistentModelIndex, QRect, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter
from PySide6.QtWidgets import (
    QApplication,
    QStyle,
    QStyleOptionViewItem,
    QWidget,
)

from vexlab.gui.panel_walidacji_oferty import KODY_TONOW
from vexlab.gui.premium import DelegatDanych, font_danych
from vexlab.gui.statusy_zamowien import kolory_odznaki


class WierszNowejOferty(DelegatDanych):
    def __init__(
        self,
        parent: QWidget,
        *,
        tytul: int = 2,
        sku: int = 1,
        status: int = 9,
        ean: Callable[[int], str] | None = None,
        oznaczenie: Callable[[int], tuple[str, str]] | None = None,
    ) -> None:
        super().__init__(parent)
        self.tytul = tytul
        self.sku = sku
        self.status = status
        self.ean = ean
        self.oznaczenie = oznaczenie

    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        if index.column() not in (self.tytul, self.status):
            super().paint(painter, option, index)
            return
        base = QStyleOptionViewItem(option)
        self.initStyleOption(base, index)
        base.text = ""
        style = option.widget.style() if option.widget else QApplication.style()
        if style:
            style.drawControl(QStyle.ControlElement.CE_ItemViewItem, base, painter, option.widget)
        painter.save()
        painter.setClipRect(option.rect)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = option.rect.adjusted(10, 0, -10, 0)
        font = QFont(option.font)
        if index.column() == self.tytul:
            font.setWeight(QFont.Weight.DemiBold)
            painter.setFont(font)
            painter.setPen(option.palette.color(option.palette.ColorRole.Text))
            title = QFontMetrics(font).elidedText(
                str(index.data() or ""), Qt.TextElideMode.ElideRight, rect.width()
            )
            painter.drawText(
                QRect(rect.left(), rect.center().y() - (29 if self.ean else 23), rect.width(), 22),
                Qt.AlignmentFlag.AlignVCenter,
                title,
            )
            font = font_danych(font)
            font.setPixelSize(11)
            font.setWeight(QFont.Weight.Normal)
            painter.setFont(font)
            painter.setPen(option.palette.color(option.palette.ColorRole.PlaceholderText))
            sku = "SKU: " + str(index.sibling(index.row(), self.sku).data() or "—")
            sku = QFontMetrics(font).elidedText(sku, Qt.TextElideMode.ElideRight, rect.width())
            painter.drawText(
                QRect(rect.left(), rect.center().y() + (-7 if self.ean else 2), rect.width(), 18),
                Qt.AlignmentFlag.AlignVCenter,
                sku,
            )
            if self.ean is not None:
                ean = QFontMetrics(font).elidedText(
                    "EAN: " + (self.ean(index.row()) or "—"),
                    Qt.TextElideMode.ElideRight,
                    rect.width(),
                )
                painter.drawText(
                    QRect(rect.left(), rect.center().y() + 11, rect.width(), 18),
                    Qt.AlignmentFlag.AlignVCenter,
                    ean,
                )
        else:
            text = str(index.data() or "")
            tone = str(index.data(Qt.ItemDataRole.UserRole) or "szary")
            if self.oznaczenie is not None:
                text, tone = self.oznaczenie(index.row())
            dark = option.palette.color(option.palette.ColorRole.Window).lightness() < 128
            bg, fg, border = kolory_odznaki(KODY_TONOW.get(tone, ""), dark)
            font.setPixelSize(11)
            font.setWeight(QFont.Weight.DemiBold)
            painter.setFont(font)
            text = QFontMetrics(font).elidedText(
                text, Qt.TextElideMode.ElideRight, rect.width() - 16
            )
            width = min(rect.width(), QFontMetrics(font).horizontalAdvance(text) + 16)
            badge = QRect(rect.left(), rect.center().y() - 14, width, 28)
            painter.setBrush(QColor(bg))
            painter.setPen(QColor(border))
            painter.drawRoundedRect(badge, 7, 7)
            painter.setPen(QColor(fg))
            painter.drawText(badge, Qt.AlignmentFlag.AlignCenter, text)
        painter.restore()
