"""Wspólny podgląd i jedna jawna zgoda na odblokowanie sprawdzonych pozycji."""

from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QHeaderView,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.ponowienie_szkicu_allegro import PartiaKontroliPonowien


class PodgladNowychProb(QDialog):
    def __init__(self, parent: QWidget, partia: PartiaKontroliPonowien, konto: str) -> None:
        super().__init__(parent)
        self.setWindowTitle("Nowa próba — zaznaczone oferty")
        self.resize(920, 560)
        self.setMinimumSize(700, 400)
        layout = QVBoxLayout(self)
        ile = sum(p.kontrola is not None for p in partia.pozycje)
        layout.addWidget(etykieta(f"Konto: {konto} • {partia.srodowisko}"))
        layout.addWidget(
            etykieta(
                f"Wybrano: {len(partia.pozycje)} • Do odblokowania: {ile} • "
                f"Pozostałe: {len(partia.pozycje) - ile}"
            )
        )
        self.tabela = QTableWidget(len(partia.pozycje), 3)
        self.tabela.setHorizontalHeaderLabels(("SKU", "Wynik kontroli", "Powód / co dalej"))
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.verticalHeader().hide()
        self.tabela.setColumnWidth(0, 180)
        self.tabela.setColumnWidth(1, 170)
        self.tabela.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        for i, pozycja in enumerate(partia.pozycje):
            for col, tekst in enumerate(
                (
                    pozycja.plan.oferta.sku,
                    "Do potwierdzenia" if pozycja.kontrola else "Nie odblokujemy",
                    pozycja.komunikat,
                )
            ):
                item = QTableWidgetItem(tekst)
                item.setToolTip(tekst)
                self.tabela.setItem(i, col, item)
        self.tabela.resizeRowsToContents()
        layout.addWidget(self.tabela, 1)
        uwaga = etykieta(
            "Poprzedni wynik może być nieznany, a odczyt Allegro opóźniony. "
            "Nowa próba może utworzyć duplikat. Sprawdź też panel Allegro. "
            "Odblokowanie nie wysyła ofert — później zatwierdzisz wysyłkę osobno."
        )
        uwaga.setWordWrap(True)
        layout.addWidget(uwaga)
        self.zgoda = QCheckBox("Potwierdzam brak ofert w Allegro i akceptuję ryzyko nowej próby.")
        layout.addWidget(self.zgoda)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        self.zatwierdz = buttons.button(QDialogButtonBox.StandardButton.Ok)
        self.zatwierdz.setText(f"Odblokuj sprawdzone ({ile})")
        self.zatwierdz.setEnabled(False)
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setDefault(True)
        self.zgoda.toggled.connect(lambda checked: self.zatwierdz.setEnabled(checked and ile > 0))
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
