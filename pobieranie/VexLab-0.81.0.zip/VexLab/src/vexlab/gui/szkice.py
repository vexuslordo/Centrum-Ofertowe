"""Osobny obszar lokalnych szkiców, bez publikacji i żądań sieciowych."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QHBoxLayout,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.paczki_ofert import SzczegolyPaczki
from vexlab.gui.producenci import Uruchom
from vexlab.gui.reczna_oferta import RecznaOferta
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.szkice import SzkicDTO, SzkiceOfert
from vexlab.przypadki_uzycia.zdjecia_ofert import PlikiZdjecOfert


class StronaSzkicow(QWidget):
    wysylka_zadana = Signal(object)
    przygotowanie_zadane = Signal(object, str, str)

    def __init__(
        self,
        serwis: SzkiceOfert,
        uruchom: Uruchom,
        parent: QWidget,
        zdjecia: PodgladZdjec | None = None,
        pliki_zdjec: PlikiZdjecOfert | None = None,
    ) -> None:
        super().__init__(parent)
        self.serwis, self.uruchom = serwis, uruchom
        self.zdjecia = zdjecia
        self.pliki_zdjec = pliki_zdjec
        self.dane: tuple[SzkicDTO, ...] = ()
        self.widoczne: tuple[SzkicDTO, ...] = ()
        self.trwa = False
        self.dialog: QDialog | None = None
        self.setObjectName("strona")
        layout = QVBoxLayout(self)
        tytul = etykieta("Szkice ofert")
        tytul.setObjectName("marka")
        layout.addWidget(tytul)
        layout.addWidget(
            etykieta(
                "Zapisane lokalnie. Zaznacz szkice i przygotuj dane Allegro. "
                "Uruchomienie sprzedaży jest osobną czynnością."
            )
        )
        akcje = QHBoxLayout()
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj po SKU lub tytule…")
        self.szukaj.setAccessibleName("Wyszukiwanie lokalnych szkiców")
        self.szukaj.textChanged.connect(self.filtruj)
        akcje.addWidget(self.szukaj, 1)
        for tekst, funkcja in (
            ("Odśwież", self.odswiez),
            ("Podgląd", self.podglad),
            ("Edytuj ofertę…", self.edytuj),
        ):
            b = QPushButton(tekst)
            b.clicked.connect(funkcja)
            akcje.addWidget(b)
        self.przygotuj_allegro = QPushButton("Przygotuj Allegro…")
        self.przygotuj_allegro.clicked.connect(self.wyslij)
        akcje.addWidget(self.przygotuj_allegro)
        layout.addLayout(akcje)
        self.tabela = QTableWidget(0, 4)
        self.tabela.setHorizontalHeaderLabels(["SKU", "Tytuł", "Stan", "Źródło / aktualność"])
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setColumnWidth(0, 170)
        self.tabela.setColumnWidth(1, 480)
        self.tabela.setColumnWidth(2, 150)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setAccessibleName("Zapisane szkice ofert")
        self.tabela.activated.connect(self.podglad)
        layout.addWidget(self.tabela, 1)
        wybor = QHBoxLayout()
        self.zaznacz_wszystkie = QPushButton("Zaznacz wszystkie wyniki")
        self.zaznacz_wszystkie.clicked.connect(self.tabela.selectAll)
        self.odznacz = QPushButton("Odznacz")
        self.odznacz.clicked.connect(self.tabela.clearSelection)
        self.usun_zaznaczone = QPushButton("Usuń zaznaczone szkice…")
        self.usun_zaznaczone.clicked.connect(lambda: self.usun(False))
        self.usun_wyniki = QPushButton("Usuń wszystkie wyniki…")
        self.usun_wyniki.clicked.connect(lambda: self.usun(True))
        for przycisk in (
            self.zaznacz_wszystkie,
            self.odznacz,
            self.usun_zaznaczone,
            self.usun_wyniki,
        ):
            wybor.addWidget(przycisk)
        layout.addLayout(wybor)
        self.info_wybor = etykieta(
            "Zaznaczono: 0. Ctrl/Shift — wiele szkiców; Ctrl+A — wszystkie wyniki."
        )
        self.tabela.itemSelectionChanged.connect(self._licznik)
        layout.addWidget(self.info_wybor)
        self.raport = etykieta("")
        layout.addWidget(self.raport)
        self.info = etykieta(
            "Brak zapisanych szkiców. Utwórz ofertę lub wczytaj ZIP w Nowe oferty."
        )
        layout.addWidget(self.info)

    def wyslij(self) -> None:
        rows = tuple(sorted(i.row() for i in self.tabela.selectionModel().selectedRows()))
        if self.trwa or not rows:
            self.info.setText("Zaznacz szkice do przygotowania Allegro.")
            return
        chosen = tuple(self.widoczne[i] for i in rows)
        currencies = {d.waluta_zrodlowa for d in chosen if d.waluta_zrodlowa}
        if len(currencies) > 1:
            self.info.setText("Wybrane szkice mają różne waluty. Wybierz jedną walutę na partię.")
            return
        currency = (
            chosen[0].waluta_zrodlowa
            if all(d.waluta_zrodlowa == chosen[0].waluta_zrodlowa for d in chosen)
            else ""
        )
        manufacturer = (
            chosen[0].producent_zrodlowy
            if all(d.producent_zrodlowy == chosen[0].producent_zrodlowy for d in chosen)
            else ""
        )
        self._przekaz(tuple(d.oferta for d in chosen), currency, manufacturer)

    def _przekaz(self, oferty: object, waluta: str, producent: str) -> None:
        self.przygotowanie_zadane.emit(oferty, waluta, producent)
        self.wysylka_zadana.emit(oferty)

    def _zadanie(self, funkcja: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self.trwa:
            return
        self.trwa = True
        self.setEnabled(False)

        def gotowe(wynik: object) -> None:
            self.trwa = False
            self.setEnabled(True)
            sukces(wynik)

        def blad(kod: str, tekst: str) -> None:
            self.trwa = False
            self.setEnabled(True)
            self.info.setText(tekst)

        self.uruchom(funkcja, gotowe, blad)

    def odswiez(self) -> None:
        self._zadanie(self.serwis.lista, self._wczytano)

    def _wczytano(self, wynik: object) -> None:
        self.dane = cast(tuple[SzkicDTO, ...], wynik)
        self.filtruj()

    def filtruj(self) -> None:
        self.tabela.clearSelection()
        self.tabela.setCurrentCell(-1, -1)
        tekst = self.szukaj.text().strip().casefold()
        self.widoczne = tuple(
            d for d in self.dane if tekst in (d.oferta.sku + " " + d.oferta.tytul).casefold()
        )
        self.tabela.setRowCount(len(self.widoczne))
        for i, d in enumerate(self.widoczne):
            for j, t in enumerate(
                (
                    d.oferta.sku,
                    d.oferta.tytul,
                    "Szkic lokalny",
                    d.zrodlo + (" • Produkt zmieniony" if d.zrodlo_zmienione else ""),
                )
            ):
                item = QTableWidgetItem(t)
                if j == 2:
                    item.setToolTip(
                        "Dawne powiązanie z lokalnym Produktem zostało zachowane."
                        if d.produkt_id is not None
                        else "Samodzielny szkic oferty; nie tworzy produktu w katalogu."
                    )
                self.tabela.setItem(i, j, item)
        self.info.setText(f"Szkice lokalne: {len(self.widoczne)} z {len(self.dane)}.")

    def _licznik(self) -> None:
        liczba = len(self.tabela.selectionModel().selectedRows(0))
        self.info_wybor.setText(
            f"Zaznaczono: {liczba}. Ctrl/Shift — wiele szkiców; Ctrl+A — wszystkie wyniki."
        )

    def _wybrany(self) -> SzkicDTO | None:
        wybrane = self.tabela.selectionModel().selectedRows(0)
        if len(wybrane) != 1 or not 0 <= wybrane[0].row() < len(self.widoczne):
            self.info.setText("Do podglądu lub edycji zaznacz dokładnie jeden szkic.")
            return None
        return self.widoczne[wybrane[0].row()]

    def podglad(self) -> None:
        d = self._wybrany()
        if d is not None:
            dialog = SzczegolyPaczki(d.oferta, self, self.zdjecia, self.uruchom)
            self.dialog = dialog
            dialog.setWindowTitle("Szkic lokalny — podgląd zapisanej treści")
            dialog.setModal(True)

            def zamknieto() -> None:
                if self.dialog is dialog:
                    self.dialog = None
                dialog.deleteLater()

            dialog.finished.connect(zamknieto)
            dialog.open()

    def edytuj(self) -> None:
        d = self._wybrany()
        if d is None:
            return
        dialog = RecznaOferta(
            self,
            self.serwis,
            self.uruchom,
            self.zdjecia,
            allegro=self.przygotuj_allegro.isEnabled(),
            pliki_zdjec=self.pliki_zdjec,
            szkic=d,
        )
        self.dialog = dialog
        dialog.zmieniono.connect(self.odswiez)
        dialog.wysylka_zadana.connect(
            lambda oferty: self._przekaz(oferty, dialog.waluta_zrodlowa, dialog.producent_zrodlowy)
        )
        dialog.setModal(True)
        dialog.open()

    def usun(self, wszystkie: bool = False) -> None:
        if self.trwa:
            return
        indeksy = {i.row() for i in self.tabela.selectionModel().selectedRows(0)}
        szkice = tuple(s for i, s in enumerate(self.widoczne) if wszystkie or i in indeksy)
        if not szkice:
            self.info.setText("Brak szkiców do usunięcia. Zaznacz szkice lub zmień filtr.")
            return
        zakres = "z bieżących wyników wyszukiwania" if wszystkie else "z zaznaczenia"
        if (
            QMessageBox.question(
                self,
                "Usuń lokalne szkice",
                f"Usunąć {len(szkice)} lokalnych szkiców {zakres}?\n"
                "Produkty pozostaną w katalogu. Przed usunięciem powstanie kopia bazy.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        self._zadanie(lambda: self.serwis.usun_wiele(szkice), self._usunieto)

    def _usunieto(self, wynik: object) -> None:
        self.raport.setText(f"Usunięto wskazane lokalne szkice. Kopia bazy: {wynik}")
        self.odswiez()
