"""Prezentacja rozmów: bez interpretowania HTML i adresów pochodzących z wiadomości."""

from html import escape
from typing import Any

from PySide6.QtCore import (
    QDateTime,
    QEvent,
    QModelIndex,
    QPersistentModelIndex,
    QRect,
    QSize,
    Qt,
    QUrl,
)
from PySide6.QtGui import QColor, QFont, QPainter, QPalette
from PySide6.QtWidgets import QStyle, QStyledItemDelegate, QStyleOptionViewItem, QTextBrowser

from vexlab.przypadki_uzycia.wiadomosci_allegro import WatekAllegro, WiadomoscAllegro

STATUSY = {
    "DELIVERED": "Dostarczona",
    "VERIFYING": "Weryfikowana",
    "BLOCKED": "Zablokowana",
    "INTERACTING": "W toku",
    "DISMISSED": "Odrzucona",
}


def data_wiadomosci(value: str) -> str:
    dt = QDateTime.fromString(value, Qt.DateFormat.ISODateWithMs)
    return dt.toLocalTime().toString("dd.MM.yyyy · HH:mm") if dt.isValid() else "Brak daty"


class DelegatRozmow(QStyledItemDelegate):
    def sizeHint(
        self, option: QStyleOptionViewItem, index: QModelIndex | QPersistentModelIndex
    ) -> QSize:
        return QSize(240, 82)

    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        row = index.data(Qt.ItemDataRole.UserRole)
        if not isinstance(row, WatekAllegro):
            super().paint(painter, option, index)
            return
        painter.save()
        painter.setClipRect(option.rect)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = option.rect.adjusted(3, 3, -3, -3)
        dark = option.palette.color(QPalette.ColorRole.Base).lightness() < 128
        active = bool(option.state & QStyle.StateFlag.State_Selected)
        hover = bool(option.state & QStyle.StateFlag.State_MouseOver)
        if active or hover:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(
                QColor("#1D2A40" if active else "#172235")
                if dark
                else QColor("#DBEAFE" if active else "#EFF6FF")
            )
            painter.drawRoundedRect(r, 8, 8)
        if active:
            painter.fillRect(QRect(r.left(), r.top() + 12, 3, r.height() - 24), QColor("#3B82F6"))
        avatar = QRect(r.left() + 12, r.top() + 17, 34, 34)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#153653" if dark else "#DBEAFE"))
        painter.drawRoundedRect(avatar, 10, 10)
        font = QFont(option.font)
        font.setWeight(QFont.Weight.DemiBold)
        painter.setFont(font)
        painter.setPen(QColor("#60A5FA" if dark else "#2563EB"))
        painter.drawText(avatar, Qt.AlignmentFlag.AlignCenter, (row.login[:2] or "?").upper())
        x = avatar.right() + 12
        width = max(0, r.right() - x - 14)
        painter.setPen(option.palette.color(QPalette.ColorRole.Text))
        title = option.fontMetrics.elidedText(
            row.login or "Rozmówca niedostępny", Qt.TextElideMode.ElideRight, max(0, width - 12)
        )
        painter.drawText(QRect(x, r.top() + 13, width, 20), Qt.AlignmentFlag.AlignVCenter, title)
        if not row.przeczytany:
            painter.setBrush(QColor("#06B6D4"))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(r.right() - 12, r.top() + 21, 5, 5)
        font.setWeight(QFont.Weight.Normal)
        font.setPixelSize(11)
        painter.setFont(font)
        painter.setPen(QColor("#94A3B8" if dark else "#526580"))
        painter.drawText(
            QRect(x, r.top() + 35, width, 16),
            Qt.AlignmentFlag.AlignVCenter,
            data_wiadomosci(row.ostatnia),
        )
        painter.setPen(
            QColor("#06B6D4" if not row.przeczytany else "#94A3B8")
            if dark
            else QColor("#087A95" if not row.przeczytany else "#526580")
        )
        painter.drawText(
            QRect(x, r.top() + 52, width, 16),
            Qt.AlignmentFlag.AlignVCenter,
            "Nieprzeczytana" if not row.przeczytany else "Przeczytana",
        )
        if option.state & QStyle.StateFlag.State_HasFocus:
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QColor("#3B82F6"))
            painter.drawRoundedRect(r.adjusted(1, 1, -1, -1), 8, 8)
        painter.restore()


class WidokRozmowy(QTextBrowser):
    def __init__(self) -> None:
        super().__init__()
        self._rows: tuple[WiadomoscAllegro, ...] = ()
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setReadOnly(True)
        self.setUndoRedoEnabled(False)
        self.setPlaceholderText("Wybierz rozmowę z listy po lewej, aby odczytać wiadomości.")
        self.document().setDocumentMargin(18)

    def loadResource(self, type: int, name: QUrl | str) -> Any:
        # Nie pobieramy żadnych zasobów, także gdy zmieni się zachowanie dokumentu Qt.
        return None

    def clear(self) -> None:
        self._rows = ()
        super().clear()

    def ustaw(self, rows: tuple[WiadomoscAllegro, ...]) -> None:
        self._rows = rows
        self._renderuj()

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.PaletteChange and hasattr(self, "_rows") and self._rows:
            self._renderuj()

    def _renderuj(self) -> None:
        dark = self.palette().color(QPalette.ColorRole.Base).lightness() < 128
        text = "#E2E8F0" if dark else "#172235"
        muted = "#94A3B8" if dark else "#526580"
        blocks = []
        for row in self._rows:
            color = (
                ("#172235" if row.rozmowca else "#153452")
                if dark
                else ("#F1F5F9" if row.rozmowca else "#E6F0FF")
            )
            body = escape(row.tekst).replace("\n", "<br>")
            subject = f"<p><b>{escape(row.temat)}</b></p>" if row.temat else ""
            files = ""
            if row.zalaczniki:
                files = (
                    "<p>Załączniki (bez pobierania): " + escape(", ".join(row.zalaczniki)) + "</p>"
                )
            if row.dodatkowe_zalaczniki:
                files += "<p>Dodatkowe załączniki dostępne na Allegro.</p>"
            role = "Rozmówca" if row.rozmowca else "Twoje konto"
            status = STATUSY.get(row.status, row.status)
            blocks.append(
                f'<table width="100%" cellspacing="0" cellpadding="14" bgcolor="{color}"><tr><td>'
                f'<p><b>{escape(row.autor)}</b> <span style="color:{muted}"> · {role}</span></p>'
                f'<p style="font-size:11px;color:{muted}">{escape(data_wiadomosci(row.kiedy))}'
                f' · {escape(status)}</p>{subject}<p style="white-space:pre-wrap">{body}</p>'
                f'<span style="color:{muted}">{files}</span></td></tr></table><p></p>'
            )
        self.setHtml(
            f'<html><body style="color:{text};font-size:13px">' + "".join(blocks) + "</body></html>"
        )
