"""Wspólny formularz pojedynczej i masowej edycji istniejących ofert."""

from collections import Counter
from collections.abc import Callable
from typing import cast

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.edycja_ofert_allegro import (
    EdytujOfertyAllegro,
    OfertaEdycji,
    ZmianaOferty,
    kody_z_arkusza,
)


class EdycjaOfertAllegro(QDialog):
    def __init__(
        self,
        parent: QWidget,
        serwis: EdytujOfertyAllegro,
        sesja: SesjaAllegro,
        ids: tuple[str, ...],
        uruchom: Uruchom,
        aktualne: Callable[[], bool],
    ) -> None:
        super().__init__(parent)
        self.serwis, self.sesja, self.ids = serwis, sesja, ids
        self.uruchom, self.aktualne = uruchom, aktualne
        self.bazy: dict[int, OfertaEdycji] = {}
        self.plany: dict[int, ZmianaOferty] = {}
        self.trwa, self.stop = False, False
        self.wyniki: dict[int, str] = {}
        self.setWindowTitle("Edytuj oferty Allegro")
        rect = self.screen().availableGeometry()
        self.setMinimumSize(min(980, rect.width() - 40), min(580, rect.height() - 60))
        self.resize(min(1400, rect.width() - 40), min(780, rect.height() - 60))
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        heading = etykieta("Edytuj oferty Allegro")
        heading.setObjectName("tytulStronyAllegro")
        layout.addWidget(heading)
        layout.addWidget(
            etykieta(f"Konto: {sesja.konto.login} • {sesja.srodowisko.value} • Oferty: {len(ids)}")
        )
        layout.addWidget(
            etykieta("Popraw wartości w kolumnach „po zmianie”, potem sprawdź podgląd i zapisz.")
        )
        layout.addWidget(
            etykieta(
                "EAN zmienia powiązanie z istniejącym produktem tej samej kategorii. "
                "Produkt pokażemy przed zapisem."
            )
        )
        tools = QGridLayout()
        self.pobierz = QPushButton("Pobierz / odśwież oferty")
        self.pobierz.clicked.connect(self.odczytaj)
        tools.addWidget(self.pobierz, 0, 0)
        self.sprawdz = QPushButton("Sprawdź wyniki zapisu")
        self.sprawdz.clicked.connect(self.sprawdz_wyniki)
        tools.addWidget(self.sprawdz, 0, 1)
        self.raport = QPushButton("Kopiuj raport")
        self.raport.clicked.connect(self.kopiuj_raport)
        tools.addWidget(self.raport, 1, 0)
        self.wklej_kody = QPushButton("Wklej SKU / EAN z arkusza…")
        self.wklej_kody.clicked.connect(self.wklej)
        tools.addWidget(self.wklej_kody, 1, 1)
        layout.addLayout(tools)
        titles = QHBoxLayout()
        self.szukaj, self.zamien, self.przed, self.po = (QLineEdit() for _ in range(4))
        for field, hint in (
            (self.szukaj, "Znajdź w tytule"),
            (self.zamien, "Zamień na"),
            (self.przed, "Dodaj przed tytułem"),
            (self.po, "Dodaj po tytule"),
        ):
            field.setPlaceholderText(hint)
            field.setAccessibleName(hint)
            titles.addWidget(field)
        self.zmien_tytuly = QPushButton("Zmień zaznaczone tytuły")
        self.zmien_tytuly.clicked.connect(self.tytuly)
        titles.addWidget(self.zmien_tytuly)
        layout.addLayout(titles)
        self.tabela = QTableWidget(len(ids), 10)
        self.tabela.setAccessibleName("Podgląd edycji ofert Allegro przed i po zmianie")
        self.tabela.setHorizontalHeaderLabels(
            [
                "Wybór / ID",
                "Status",
                "Tytuł\nteraz",
                "Tytuł\npo zmianie",
                "SKU\nteraz",
                "SKU\npo zmianie",
                "EAN\nteraz",
                "EAN\npo zmianie",
                "Produkt po zmianie EAN",
                "Wynik",
            ]
        )
        for i, ident in enumerate(ids):
            for j in range(10):
                item = QTableWidgetItem(ident if j == 0 else "")
                if j not in {3, 5, 7}:
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if j == 0:
                    item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    item.setCheckState(Qt.CheckState.Checked)
                self.tabela.setItem(i, j, item)
        for col, width in enumerate((140, 80, 180, 200, 150, 150, 160, 160, 190, 170)):
            self.tabela.setColumnWidth(col, width)
        self.tabela.verticalHeader().setDefaultSectionSize(64)
        self.tabela.itemChanged.connect(self.zmieniono)
        layout.addWidget(self.tabela, 1)
        self.postep = QProgressBar()
        self.postep.setRange(0, len(ids))
        layout.addWidget(self.postep)
        self.info = etykieta("Pobierz oferty, aby rozpocząć.")
        layout.addWidget(self.info)
        bottom = QHBoxLayout()
        self.zatrzymaj = QPushButton("Zatrzymaj")
        self.zatrzymaj.setEnabled(False)
        self.zatrzymaj.clicked.connect(lambda: setattr(self, "stop", True))
        bottom.addWidget(self.zatrzymaj)
        bottom.addStretch()
        self.podglad = QPushButton("Sprawdź podgląd zmian")
        self.podglad.clicked.connect(self.przygotuj)
        bottom.addWidget(self.podglad)
        self.zapis = QPushButton("Zapisz zmiany w Allegro…")
        self.zapis.setObjectName("primary")
        self.zapis.clicked.connect(self.zapisz)
        self.zapis.setEnabled(False)
        bottom.addWidget(self.zapis)
        self.zamknij = QPushButton("Zamknij")
        self.zamknij.clicked.connect(self.reject)
        bottom.addWidget(self.zamknij)
        layout.addLayout(bottom)

    def wklej(self) -> None:
        if self.trwa:
            return
        text, accepted = QInputDialog.getMultiLineText(
            self,
            "Wklej indywidualne kody",
            "Kolumny: ID Allegro, SKU, EAN (skopiuj z arkusza).\n"
            "Puste SKU lub EAN pozostawia dotychczasową wartość. Zmiany trafią do podglądu.",
            QApplication.clipboard().text(),
        )
        if not accepted:
            return
        rows = self.wybrane()
        try:
            parsed = kody_z_arkusza(text, tuple(self.ids[r] for r in rows if r in self.bazy))
        except BladAllegro as exc:
            self.info.setText(str(exc))
            return
        positions = {self.ids[r]: r for r in rows}
        for ident, sku, ean in parsed:
            if sku:
                self.ustaw(positions[ident], 5, sku)
            if ean:
                self.ustaw(positions[ident], 7, ean)
        self.plany.clear()
        self.zapis.setEnabled(False)
        self.info.setText(f"Wklejono kody dla {len(parsed)} ofert. Sprawdź podgląd zmian.")

    def kopiuj_raport(self) -> None:
        headers = [
            cast(QTableWidgetItem, self.tabela.horizontalHeaderItem(i)).text().replace("\n", " ")
            for i in range(self.tabela.columnCount())
        ]
        lines = ["\t".join(headers)]
        for row in range(len(self.ids)):
            lines.append(
                "\t".join(
                    self.tekst(row, col).replace("\n", " ").replace("\t", " ")
                    for col in range(self.tabela.columnCount())
                )
            )
        QApplication.clipboard().setText("\n".join(lines))
        self.info.setText("Raport skopiowany. Możesz wkleić go do arkusza lub pliku tekstowego.")

    def tekst(self, row: int, col: int) -> str:
        return cast(QTableWidgetItem, self.tabela.item(row, col)).text()

    def ustaw(self, row: int, col: int, value: str) -> None:
        self.tabela.blockSignals(True)
        item = cast(QTableWidgetItem, self.tabela.item(row, col))
        item.setText(value)
        item.setToolTip(value)
        self.tabela.blockSignals(False)

    def wybrane(self) -> tuple[int, ...]:
        return tuple(
            i
            for i in range(len(self.ids))
            if cast(QTableWidgetItem, self.tabela.item(i, 0)).checkState() == Qt.CheckState.Checked
        )

    def zmieniono(self, item: QTableWidgetItem) -> None:
        if item.column() in {0, 3, 5, 7}:
            self.plany.clear()
            self.zapis.setEnabled(False)
            self.info.setText("Dane zmienione. Sprawdź podgląd ponownie.")

    def tytuly(self) -> None:
        for row in self.wybrane():
            if row not in self.bazy:
                continue
            old = self.tekst(row, 3)
            new = old.replace(self.szukaj.text(), self.zamien.text()) if self.szukaj.text() else old
            self.ustaw(row, 3, self.przed.text() + new + self.po.text())
        self.plany.clear()
        self.zapis.setEnabled(False)
        self.info.setText("Tytuły zmienione w podglądzie. Sprawdź zmiany przed zapisem.")

    def seria(
        self,
        rows: tuple[int, ...],
        fn: Callable[[int], object],
        ok: Callable[[int, object], None],
        etap: str = "zapis",
    ) -> None:
        if self.trwa or not rows:
            return
        self.trwa, self.stop = True, False
        self.postep.setRange(0, len(rows))
        self.postep.setValue(0)
        controls = (
            self.pobierz,
            self.wklej_kody,
            self.sprawdz,
            self.zmien_tytuly,
            self.tabela,
            self.podglad,
            self.zapis,
            self.zamknij,
        )
        for widget in controls:
            widget.setEnabled(False)
        self.zatrzymaj.setEnabled(True)

        def finish() -> None:
            self.trwa = False
            for widget in controls:
                widget.setEnabled(True)
            self.zatrzymaj.setEnabled(False)
            self.zapis.setEnabled(bool(self.plany) and self.aktualne())
            counts = Counter(self.wyniki.values())
            if etap == "pobieranie":
                summary = (
                    f"Pobrano: {len(self.bazy)} z {len(self.ids)} • "
                    f"Do poprawy: {counts['Do poprawy']}"
                )
            elif etap == "podgląd":
                summary = f"Podgląd gotowy: {len(self.plany)} • Do poprawy: {counts['Do poprawy']}"
            else:
                summary = (
                    f"Zapisane: {counts['Zapisane']} • Do poprawy: {counts['Do poprawy']} • "
                    f"Do sprawdzenia: {counts['Do sprawdzenia']} • Pominięte: {counts['Pominięte']}"
                )
            self.info.setText(summary + (" • Zatrzymano" if self.stop else ""))

        def step(index: int) -> None:
            if index == len(rows) or self.stop or not self.aktualne():
                finish()
                return
            row = rows[index]
            self.info.setText(f"Przetwarzanie: {index + 1} z {len(rows)} • ID {self.ids[row]}")

            def success(result: object) -> None:
                if self.aktualne():
                    ok(row, result)
                else:
                    self.stop = True
                self.postep.setValue(index + 1)
                step(index + 1)

            def error(code: str, text: str) -> None:
                state = (
                    "Do sprawdzenia"
                    if code in {"NIEZNANY", "PRZETWARZANIE", "REJESTR"}
                    else "Do poprawy"
                )
                self.wyniki[row] = state
                self.ustaw(row, 9, state + ": " + text)
                self.plany.pop(row, None)
                self.postep.setValue(index + 1)
                step(index + 1)

            self.uruchom(lambda: fn(row), success, error)

        step(0)

    def odczytaj(self) -> None:
        if (
            self.bazy
            and QMessageBox.question(
                self,
                "Odśwież oferty",
                "Pobrać dane ponownie i zastąpić niezapisane zmiany?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        self.plany.clear()

        def ok(row: int, value: object) -> None:
            o = cast(OfertaEdycji, value)
            self.bazy[row] = o
            self.wyniki.pop(row, None)
            for col, text in (
                (1, o.status),
                (2, o.tytul),
                (3, o.tytul),
                (4, o.sku),
                (5, o.sku),
                (6, o.ean),
                (7, o.ean),
                (8, "Bez zmiany produktu"),
                (9, "Pobrano"),
            ):
                self.ustaw(row, col, text)

        rows = self.wybrane()
        for row in rows:
            self.bazy.pop(row, None)
        self.seria(
            rows, lambda row: self.serwis.odczytaj(self.sesja, self.ids[row]), ok, "pobieranie"
        )

    def przygotuj(self) -> None:
        self.plany.clear()
        rows = tuple(i for i in self.wybrane() if i in self.bazy)

        def ok(row: int, value: object) -> None:
            z = cast(ZmianaOferty, value)
            self.plany[row] = z
            self.wyniki.pop(row, None)
            self.ustaw(row, 8, z.nazwa_produktu or "Bez zmiany produktu")
            self.ustaw(row, 9, "Podgląd gotowy")

        values = {row: (self.tekst(row, 3), self.tekst(row, 5), self.tekst(row, 7)) for row in rows}
        self.seria(
            rows,
            lambda row: self.serwis.przygotuj(
                self.sesja,
                self.bazy[row],
                *values[row],
            ),
            ok,
            "podgląd",
        )

    def zapisz(self) -> None:
        rows = tuple(i for i in self.wybrane() if i in self.plany)
        if not rows or not self.aktualne():
            return
        if (
            QMessageBox.question(
                self,
                "Zapisz zmiany w Allegro",
                f"Zapisać zatwierdzone wartości tytułu, SKU i EAN dla {len(rows)} ofert?\n"
                "Zmiany dotyczą istniejących ofert na wskazanym koncie. "
                "Zmiana EAN przypisze produkt pokazany w podglądzie.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        plans = dict(self.plany)

        def ok(row: int, value: object) -> None:
            state = str(value)
            self.wyniki[row] = state
            self.ustaw(row, 9, state)
            self.plany.pop(row, None)

        self.seria(rows, lambda row: self.serwis.zapisz(self.sesja, plans[row], self.aktualne), ok)

    def sprawdz_wyniki(self) -> None:
        def ok(row: int, value: object) -> None:
            self.wyniki[row] = str(value)
            self.ustaw(row, 9, str(value))

        self.seria(self.wybrane(), lambda row: self.serwis.sprawdz(self.sesja, self.ids[row]), ok)

    def reject(self) -> None:
        if self.trwa:
            self.stop = True
            return
        super().reject()
