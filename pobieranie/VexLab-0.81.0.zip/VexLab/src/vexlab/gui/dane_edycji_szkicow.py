"""Metadane formularzy, oddzielone od walidacji i gotowości do wysyłki."""

from dataclasses import dataclass, replace

from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    PlanNowegoSzkicu,
    ProduktSzkicu,
    UstawieniaSzkicu,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad

KluczMetadanych = tuple[str, str]


@dataclass(frozen=True)
class DaneEdycjiSzkicu:
    oferta: OfertaPodglad
    ustawienia: UstawieniaSzkicu
    produkt: ProduktSzkicu


class MetadaneEdycjiSzkicow:
    def __init__(self) -> None:
        self.produkty: dict[KluczMetadanych, ProduktSzkicu] = {}

    @staticmethod
    def klucz(oferta: OfertaPodglad, ustawienia: UstawieniaSzkicu) -> KluczMetadanych | None:
        if ustawienia.nowy:
            return ("kategoria", ustawienia.kategoria) if ustawienia.kategoria else None
        if ustawienia.produkt:
            return "produkt", ustawienia.produkt
        return ("ean", oferta.ean) if oferta.ean else None

    def zapamietaj(self, plany: tuple[PlanNowegoSzkicu, ...]) -> None:
        for plan in plany:
            key = self.klucz(plan.oferta, plan.ustawienia)
            if key and plan.produkt is not None:
                self.produkty[key] = plan.produkt

    def odczytaj(
        self, oferta: OfertaPodglad, ustawienia: UstawieniaSzkicu
    ) -> DaneEdycjiSzkicu | None:
        key = self.klucz(oferta, ustawienia)
        product = self.produkty.get(key) if key else None
        if product is None:
            return None
        if ustawienia.nowy:
            product = replace(product, nazwa=oferta.tytul)
        return DaneEdycjiSzkicu(oferta, ustawienia, product)
