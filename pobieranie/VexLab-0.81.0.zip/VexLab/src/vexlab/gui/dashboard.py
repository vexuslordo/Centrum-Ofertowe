"""Główny obszar Dashboardu. Dane nieznane pozostają jawnie nieznane."""

from collections.abc import Callable
from datetime import datetime
from functools import partial
from typing import cast

from PySide6.QtCharts import QChart, QChartView, QLineSeries, QValueAxis
from PySide6.QtCore import QDateTime, QMargins, QSettings, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPaintEvent, QPen, QResizeEvent
from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMenu,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QTableWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.integracje_dashboard import PanelIntegracji
from vexlab.gui.kafelek_kpi import KafelekKPI
from vexlab.gui.premium import tlo_panelu
from vexlab.gui.tablica_dashboardu import PasekEdycjiDashboardu, TablicaDashboardu
from vexlab.gui.uklad_dashboardu import PamiecDashboardu, UkladDashboardu, UstawienieWidgetu
from vexlab.gui.zamowienia_dashboardu import ListaOstatnichZamowien
from vexlab.przypadki_uzycia.allegro import LicznikiAllegro
from vexlab.przypadki_uzycia.dashboard import StanDashboardu
from vexlab.przypadki_uzycia.powloka import PreferencjePowloki
from vexlab.przypadki_uzycia.zamowienia_dashboardu import RaportZamowienKanalu, podsumuj_zamowienia


def tekst(wartosc: str, rola: str = "") -> QLabel:
    label = QLabel(wartosc)
    if rola:
        label.setObjectName(rola)
    label.setWordWrap(True)
    label.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
    return label


def przycisk(nazwa: str, akcja: Callable[[], None] | None = None) -> QPushButton:
    b = QPushButton(nazwa)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    if akcja is not None:
        b.clicked.connect(akcja)
    return b


class UdzialKanalow(QWidget):
    """Neutralny stan pustki, nie procenty z przykładowych danych."""

    def __init__(self) -> None:
        super().__init__()
        self.setFixedSize(108, 108)
        self.setAccessibleName("Udział kanałów: brak danych sprzedaży")

    def paintEvent(self, event: QPaintEvent) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QPen(QColor("#284153"), 14))
        painter.drawEllipse(15, 10, 80, 80)
        painter.setPen(QColor("#93ABC2"))
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "—\nBrak odczytu")


class DashboardView(QScrollArea):
    cel = Signal(str)
    alert = Signal(str)
    odswiez_zamowienia = Signal()
    okres_zamowien = Signal(int)
    otworz_zamowienie = Signal(str, str)

    def __init__(
        self, preferencje: PreferencjePowloki, ustawienia: QSettings | None = None
    ) -> None:
        super().__init__()
        self.pamiec_ukladu = PamiecDashboardu(ustawienia)
        self.raporty_zamowien: dict[str, RaportZamowienKanalu] = {}
        self.bledy_zamowien: dict[str, str] = {}
        self._tabele: dict[str, QTableWidget] = {}
        self._opisy_tabel: dict[str, QLabel] = {}
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.kolejnosc = preferencje.dashboard_kolejnosc
        self.ukryte = preferencje.dashboard_ukryte
        self._szeroki: bool | None = None
        self._ciemny: bool | None = None
        self.sekcje: dict[str, QWidget] = {}
        self.karty: dict[str, KafelekKPI] = {}
        self.alerty: dict[str, QPushButton] = {}
        self.zawartosc = QWidget()
        self.zawartosc.setObjectName("dashboardNowy")
        self.layout_glowny = QVBoxLayout(self.zawartosc)
        self.layout_glowny.setContentsMargins(14, 12, 14, 12)
        self.layout_glowny.setSpacing(10)
        self._naglowek()
        self.layout_glowny.addStretch()
        self._kpi()
        self._sprzedaz()
        self._integracje()
        self._alerty()
        self._tabela(
            "top",
            "Top produkty (30 dni)",
            ["#", "Produkt", "Sprzedano", "Przychód"],
            "Brak odczytu sprzedaży. Ranking pojawi się po udostępnieniu danych kanałów.",
            ("Sprzedaż", "Przychód", "Marża"),
        )
        self._ostatnie_zamowienia()
        frame, layout = self._panel("system", "Kolejka zadań")
        layout.addWidget(tekst("—", "liczbaDashboardu"))
        layout.addWidget(tekst("Oczekujących zadań", "podpisDashboardu"))
        layout.addWidget(tekst("Kolejka synchronizacji w przygotowaniu.", "podpisDashboardu"))
        layout.addWidget(tekst("Status systemu", "tytulDashboardu"))
        self.stan_systemu = tekst("Odczytywanie katalogu…", "podpisDashboardu")
        layout.addWidget(self.stan_systemu)
        layout.addStretch()
        self._tabela(
            "magazyn",
            "Stany magazynowe — produkty do uzupełnienia",
            ["Produkt", "SKU", "Stan"],
            "Brak wspólnego odczytu magazynu. Stany ofert Allegro nie są stanem całego katalogu.",
            ("≤ 3", "4–10", "> 10"),
        )
        self._tabela(
            "aktywnosc",
            "Aktywność systemu",
            ["Czas", "Operacja", "Szczegóły"],
            "Brak wspólnego rejestru operacji. Historia importów pozostaje w Cennikach.",
        )
        self._ai()
        self.akcje, self.akcje_layout = self._panel("akcje", "Szybkie akcje")
        self.przyciski_akcji: list[QPushButton] = []
        akcje = (
            ("＋ Dodaj produkt", "dodaj", "#076BD0", True),
            ("Nowa oferta Allegro", "Nowe oferty", "#94430D", True),
            ("Produkt PrestaShop", "PrestaShop", "#8C1850", False),
            ("Import CSV / XLSX", "Cenniki", "#39326F", True),
            ("Synchronizuj wszystko", "Synchronizacja", "#15497F", False),
            ("Generuj opisy AI", "Kreator opisów (AI)", "#483574", False),
            ("Dodaj zdjęcia", "Zdjęcia i media", "#176457", True),
            ("Raport sprzedaży", "Raporty", "#166148", False),
            ("Aktualizuj ceny", "Zmiana cen", "#776020", False),
            ("Zarządzaj błędami", "korekty", "#7F2635", True),
            ("Zamówienia", "Zamówienia", "#15497F", True),
            ("Produkty", "Produkty", "#076BD0", True),
            ("Synchronizacja", "Synchronizacja", "#15497F", True),
        )
        self.grid_akcji = QGridLayout()
        self.akcje_layout.addLayout(self.grid_akcji)
        for nazwa, cel, kolor, dostepna in akcje:
            b = przycisk(nazwa, partial(self.cel.emit, cel))
            b.setParent(self.akcje)
            b.setEnabled(dostepna)
            b.setMinimumHeight(33)
            b.setObjectName("primary" if cel == "dodaj" else "skrotDashboardu")
            if not dostepna:
                b.setToolTip("Funkcja w przygotowaniu; nie wykonuje operacji.")
            b.setProperty("skrot_id", cel)
            b.setProperty("kolorSkrotu", kolor)
            self.przyciski_akcji.append(b)
        self.info = tekst("Odczytywanie katalogu…", "podpisDashboardu")
        self.layout_glowny.addWidget(self.info)
        self._szybkie_kpi()
        self._tablica()
        self.setWidget(self.zawartosc)
        self.rozmiesc(True)
        self.odswiez_motyw()

    def _naglowek(self) -> None:
        self.naglowek_layout = QGridLayout()
        self._header_widgets: list[QWidget] = [tekst("▣  Dashboard", "naglowekDashboardu")]
        self.opis_naglowka = tekst(
            "Wszystkie kluczowe informacje o Twojej sprzedaży w jednym miejscu.",
            "podpisDashboardu",
        )
        self.opis_naglowka.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self._header_widgets.append(self.opis_naglowka)
        self.zegar = tekst("", "zegarDashboardu")
        self._header_widgets.append(self.zegar)
        self._czas()
        timer = QTimer(self)
        timer.timeout.connect(self._czas)
        timer.start(1000)
        self.zakres = "30 dni"
        self.okres = QButtonGroup(self)
        for i, nazwa in enumerate(("Dzisiaj", "7 dni", "30 dni", "90 dni", "Rok")):
            b = przycisk(nazwa)
            b.setCheckable(True)
            b.setChecked(i == 2)
            self.okres.addButton(b)
            self._header_widgets.append(b)
        self.okres.buttonClicked.connect(self._zmien_okres)
        self.waluta_zamowien = QComboBox()
        self.waluta_zamowien.setAccessibleName("Waluta obrotu Dashboardu")
        self.waluta_zamowien.setToolTip("Waluta obrotu: kwoty zamówień rozliczonych w tej walucie.")
        self.waluta_zamowien.addItem("PLN", "PLN")
        self.waluta_zamowien.setFixedWidth(86)
        self._header_widgets.append(self.waluta_zamowien)
        dostosuj = przycisk("Dostosuj Dashboard", self._dostosuj)
        dostosuj.setAccessibleName("Dostosuj Dashboard")
        self._header_widgets.append(dostosuj)
        self.layout_glowny.addLayout(self.naglowek_layout)

    def _zmien_okres(self, button: QPushButton) -> None:
        self.zakres = button.text()
        self.karty["obrot"].tytul.setText(f"Obrót ({self.zakres})")
        self.karty["marza"].tytul.setText(f"Marża ({self.zakres})")
        self._odswiez_zamowienia()
        self.okres_zamowien.emit(self.dni_zamowien())

    def _czas(self) -> None:
        self.zegar.setText(QDateTime.currentDateTime().toString("dd.MM.yyyy  HH:mm"))

    def _panel(self, id: str, nazwa: str) -> tuple[QFrame, QVBoxLayout]:
        frame = QFrame()
        frame.setObjectName("panelDashboardu")
        frame.setMinimumWidth(0)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(11, 10, 11, 10)
        layout.setSpacing(4)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.addWidget(tekst(nazwa, "tytulDashboardu"))
        self.sekcje[id] = frame
        return frame, layout

    def _kpi(self) -> None:
        frame = QWidget()
        self.grid_kpi = QGridLayout(frame)
        self.grid_kpi.setContentsMargins(0, 0, 0, 0)
        self.grid_kpi.setSpacing(10)
        self.sekcje["kpi"] = frame
        for id, nazwa, symbol, kolor in (
            ("produkty", "Produkty", "Produkty", "#10B981"),
            ("allegro", "Aktywne Allegro", "Allegro", "#DB5400"),
            ("presta", "Produkty PrestaShop", "PrestaShop", "#A51B61"),
            ("zamowienia", "Zamówienia", "Zamówienia", "#0662BB"),
            ("obrot", "Obrót (30 dni)", "Cenniki", "#F59E0B"),
            ("marza", "Marża (30 dni)", "Raporty", "#00824D"),
            ("bledy", "Błędy", "Historia operacji", "#EF4444"),
        ):
            self.karty[id] = KafelekKPI(
                nazwa, "produkty", "Brak historii", symbol=symbol, akcent=kolor
            )

    def dni_zamowien(self) -> int:
        return {"Dzisiaj": 1, "7 dni": 7, "30 dni": 30, "90 dni": 90, "Rok": 365}[self.zakres]

    def ustaw_zamowienia(
        self, zrodlo: str, raport: RaportZamowienKanalu | None, blad: str = ""
    ) -> None:
        if raport is None:
            self.raporty_zamowien.pop(zrodlo, None)
        else:
            self.raporty_zamowien[zrodlo] = raport
        if blad:
            self.bledy_zamowien[zrodlo] = blad
        else:
            self.bledy_zamowien.pop(zrodlo, None)
        self._odswiez_zamowienia()

    def _odswiez_zamowienia(self) -> None:
        if not hasattr(self, "waluta_zamowien"):
            return
        code = str(self.waluta_zamowien.currentData() or "PLN")
        reports = tuple(self.raporty_zamowien.values())
        result = podsumuj_zamowienia(
            reports, self.dni_zamowien(), code, datetime.now().astimezone()
        )
        codes = result.waluty or (code,)
        if (
            tuple(self.waluta_zamowien.itemData(i) for i in range(self.waluta_zamowien.count()))
            != codes
        ):
            self.waluta_zamowien.blockSignals(True)
            self.waluta_zamowien.clear()
            for item in codes:
                self.waluta_zamowien.addItem(item, item)
            self.waluta_zamowien.setCurrentIndex(max(0, self.waluta_zamowien.findData(code)))
            self.waluta_zamowien.blockSignals(False)
            code = str(self.waluta_zamowien.currentData())
            result = podsumuj_zamowienia(
                reports, self.dni_zamowien(), code, datetime.now().astimezone()
            )
        self.waluta_zamowien.setEnabled(bool(reports))
        sources = ", ".join(r.zrodlo for r in reports) or "Brak odczytu zamówień"
        for name, value in (
            ("zamowienia", str(result.liczba) if result.liczba is not None else "—"),
            ("obrot", result.obrot),
        ):
            self.karty[name].liczba.setText(value)
            self.karty[name].podpis.setText(sources)
            self.karty[name].setToolTip(result.opis)
            self.karty[name].podpis.setToolTip(result.opis)
        self.karty["marza"].liczba.setText("—")
        self.karty["marza"].podpis.setText("Brak danych kosztowych")
        self.karty["bledy"].liczba.setText(
            str(len(self.bledy_zamowien)) if reports or self.bledy_zamowien else "—"
        )
        self.karty["bledy"].podpis.setText("Błędy obsługi zamówień")
        self.karty["bledy"].setToolTip(
            "\n".join(self.bledy_zamowien.values()) or "Brak błędów odczytu."
        )
        self.lista_zamowien.dane.ustaw(result.ostatnie)
        self._odswiez_szybkie_kpi()
        unread = [name for name in ("Allegro", "PrestaShop") if name not in self.raporty_zamowien]
        self._opisy_tabel["zamowienia"].setText(
            f"Ostatnie {len(result.ostatnie)} • {sources}"
            + (" • Brak odczytu: " + ", ".join(unread) if unread else "")
        )
        if not reports and not self.bledy_zamowien:
            self._opisy_tabel["zamowienia"].setText(
                "Połącz Allegro lub PrestaShop i odśwież zamówienia."
            )
        self._opisy_tabel["zamowienia"].setToolTip(result.opis)
        self._dopasuj_obrot()
        if hasattr(self, "info"):
            self.info.setText(
                "Zamówienia: " + sources + " • Dane pochodzą z ostatnich odczytów integracji."
            )

    def _ostatnie_zamowienia(self) -> None:
        _, layout = self._panel("zamowienia", "Ostatnie zamówienia")
        self.lista_zamowien = ListaOstatnichZamowien()
        self.lista_zamowien.clicked.connect(self._otworz_zamowienie)
        self.lista_zamowien.activated.connect(self._otworz_zamowienie)
        layout.addWidget(self.lista_zamowien, 1)
        self._opisy_tabel["zamowienia"] = tekst("", "podpisDashboardu")
        layout.addWidget(self._opisy_tabel["zamowienia"])
        actions = QHBoxLayout()
        actions.addWidget(przycisk("Odśwież", self.odswiez_zamowienia.emit))
        actions.addWidget(przycisk("Zobacz wszystkie →", lambda: self.cel.emit("Zamówienia")))
        actions.addStretch()
        layout.addLayout(actions)
        self.waluta_zamowien.currentIndexChanged.connect(self._odswiez_zamowienia)
        self._odswiez_zamowienia()

    def _otworz_zamowienie(self, index: object) -> None:
        from PySide6.QtCore import QModelIndex

        if isinstance(index, QModelIndex) and index.isValid():
            row = self.lista_zamowien.dane.rows[index.row()]
            self.otworz_zamowienie.emit(row.zrodlo, row.numer)

    def _szybkie_kpi(self) -> None:
        _, layout = self._panel("szybkie_kpi", "Szybkie KPI")
        self.szybkie_kpi: dict[str, QLabel] = {}
        grid = QGridLayout()
        for i, (key, title) in enumerate(
            (
                ("dzis", "Zamówienia dzisiaj"),
                ("obrot_dzis", "Obrót dzisiaj"),
                ("tydzien", "Obrót · 7 dni"),
                ("miesiac", "Obrót · 30 dni"),
                ("koszyk", "Średnia wartość koszyka"),
            )
        ):
            tile = QFrame()
            tile.setObjectName("kartaDanychZamowienia")
            column = QVBoxLayout(tile)
            column.addWidget(tekst(title, "podpisDashboardu"))
            value = tekst("—", "liczbaDashboardu")
            column.addWidget(value)
            self.szybkie_kpi[key] = value
            grid.addWidget(tile, i // 2, i % 2)
        self.szybkie_kpi["koszyk"].setToolTip("Średnia wartość koszyka jest jeszcze niedostępna.")
        layout.addLayout(grid)
        layout.addWidget(
            tekst(
                "Wybrana waluta · bez przeliczeń. — oznacza brak pełnych danych.",
                "podpisDashboardu",
            )
        )
        self._odswiez_szybkie_kpi()

    def _odswiez_szybkie_kpi(self) -> None:
        if not hasattr(self, "szybkie_kpi"):
            return
        reports = tuple(self.raporty_zamowien.values())
        code = str(self.waluta_zamowien.currentData() or "PLN")
        now = datetime.now().astimezone()
        for days, key in ((1, "obrot_dzis"), (7, "tydzien"), (30, "miesiac")):
            result = podsumuj_zamowienia(reports, days, code, now)
            self.szybkie_kpi[key].setText(result.obrot)
            self.szybkie_kpi[key].setToolTip(result.opis)
            if days == 1:
                self.szybkie_kpi["dzis"].setText(
                    str(result.liczba) if result.liczba is not None else "—"
                )
                self.szybkie_kpi["dzis"].setToolTip(result.opis)

    def _tablica(self) -> None:
        definitions = {
            "kpi": ("Wskaźniki KPI", "raport", "Pełna szerokość", "Raporty"),
            "sprzedaz": ("Sprzedaż i przychód", "raport", "2×1", "Raporty"),
            "zamowienia": ("Ostatnie zamówienia", "koszyk", "1×2", "Zamówienia"),
            "alerty": ("Alarmy", "ostrzezenie", "1×1", "Produkty"),
            "akcje": ("Skróty", "produkt", "2×1", "Produkty"),
            "integracje": ("Synchronizacja i integracje", "globus", "1×1", "integracje"),
            "system": ("Kolejka zadań", "plik", "1×1", "Kolejka zadań"),
            "magazyn": ("Stany magazynowe", "produkt", "2×1", "Produkty"),
            "aktywnosc": ("Aktywność systemu", "plik", "2×1", "Historia operacji"),
            "ai": ("AI Center", "ai", "1×1", "Kreator opisów (AI)"),
            "top": ("Top produkty", "produkt", "1×1", "Raporty"),
            "szybkie_kpi": ("Szybkie KPI", "raport", "1×1", "Raporty"),
        }
        default_order = (
            "kpi",
            "sprzedaz",
            "zamowienia",
            "alerty",
            "akcje",
            "szybkie_kpi",
            "integracje",
            "system",
            "magazyn",
            "aktywnosc",
            "ai",
            "top",
        )
        from vexlab.przypadki_uzycia.dashboard import SEKCJE_DASHBOARDU

        order = (
            default_order
            if self.kolejnosc == SEKCJE_DASHBOARDU
            else (*self.kolejnosc, "szybkie_kpi")
        )
        initial = UkladDashboardu(
            tuple(UstawienieWidgetu(key, definitions[key][2], key in self.ukryte) for key in order)
        )
        self.tablica = TablicaDashboardu(initial, self.pamiec_ukladu)
        self.tablica.domyslny = UkladDashboardu(
            tuple(UstawienieWidgetu(key, definitions[key][2]) for key in default_order)
        )
        self._stare_ukryte = self.ukryte
        self.pasek_edycji = PasekEdycjiDashboardu(self.tablica)
        self.layout_glowny.insertWidget(1, self.pasek_edycji)
        self.layout_glowny.insertWidget(2, self.tablica)
        self.tablica.modul.connect(self.cel)
        self.tablica.konfiguruj.connect(self._konfiguruj_skroty)
        self.tablica.rozmiar_zmieniony.connect(self._zaplanuj_kafelki)
        self._timer_kafelki = QTimer(self)
        self._timer_kafelki.setSingleShot(True)
        self._timer_kafelki.timeout.connect(self._dopasuj_kafelki)
        self.tablica.odswiez.connect(self._odswiez_widget)
        self.tablica.widok.connect(self._widok_widgetu)
        self.tablica.zmieniono.connect(self._dopasuj_kafelki)
        for key, (title, icon, _, target) in definitions.items():
            content = self.sekcje[key]
            for label in content.findChildren(QLabel):
                if label.objectName() == "tytulDashboardu":
                    label.hide()
            self.tablica.dodaj(
                key,
                title,
                icon,
                content,
                target,
                odswiez=key in ("zamowienia", "szybkie_kpi"),
                widoki=("Lista", "Karty") if key == "zamowienia" else (),
            )
        self.tablica.rozmiesc()

    def _zaplanuj_kafelki(self) -> None:
        if hasattr(self, "_timer_kafelki"):
            self._timer_kafelki.start(0)

    def _konfiguruj_skroty(self, ident: str) -> None:
        row = next(w for w in self.tablica.uklad.widgety if w.id == ident)
        selected = row.skroty
        if selected is None:
            selected = tuple(str(b.property("skrot_id")) for b in self.przyciski_akcji)
        menu = QMenu(self)
        for button in self.przyciski_akcji:
            key = str(button.property("skrot_id"))
            action = menu.addAction(button.text())
            action.setCheckable(True)
            action.setChecked(key in selected)
            values = tuple(k for k in selected if k != key) if key in selected else (*selected, key)
            action.triggered.connect(partial(self.tablica.ustaw, ident, skroty=values))
        menu.exec(
            self.tablica.ramki[ident].wiecej.mapToGlobal(
                self.tablica.ramki[ident].wiecej.rect().bottomLeft()
            )
        )

    def _dostosuj(self) -> None:
        self.tablica.rozpocznij()

    def _odswiez_widget(self, ident: str) -> None:
        if ident in ("zamowienia", "szybkie_kpi"):
            self.odswiez_zamowienia.emit()

    def _widok_widgetu(self, ident: str, name: str) -> None:
        if ident == "zamowienia":
            self.lista_zamowien.wariant(name)

    def _dopasuj_obrot(self) -> None:
        label = self.karty["obrot"].liczba
        font = QFont(label.font())
        font.setPixelSize(20)
        width = max(1, QFontMetrics(font).horizontalAdvance(label.text()))
        size = max(11, min(20, int(20 * max(1, label.width() - 2) / width)))
        label.setStyleSheet(f"font-size:{size}px; font-weight:600")

    def _zakladki(self, layout: QVBoxLayout, nazwy: tuple[str, ...], *, obok: bool = False) -> None:
        pasek = QHBoxLayout()
        if obok:
            item = layout.takeAt(0)
            widget = item.widget() if item is not None else None
            if widget is not None:
                cast(QLabel, widget).setWordWrap(False)
                widget.setMinimumWidth(170)
                pasek.addWidget(widget)
        grupa = QButtonGroup(self)
        for i, nazwa in enumerate(nazwy):
            b = przycisk(nazwa)
            b.setCheckable(True)
            b.setChecked(i == 0)
            grupa.addButton(b)
            pasek.addWidget(b)
        pasek.addStretch()
        layout.addLayout(pasek)

    def _sprzedaz(self) -> None:
        _, layout = self._panel("sprzedaz", "Sprzedaż i przychód")
        self._zakladki(layout, ("Przychód", "Zamówienia", "Obrót", "Marża"), obok=True)
        layout.addWidget(tekst("● Allegro      ● PrestaShop", "podpisDashboardu"))
        wykres = QChart()
        wykres.legend().hide()
        wykres.setMargins(QMargins(0, 0, 0, 0))
        wykres.setBackgroundVisible(False)
        wykres.setPlotAreaBackgroundVisible(False)
        seria = QLineSeries()
        wykres.addSeries(seria)
        for orientacja in (Qt.AlignmentFlag.AlignBottom, Qt.AlignmentFlag.AlignLeft):
            os = QValueAxis()
            os.setRange(0, 1)
            os.setLabelsVisible(False)
            os.setGridLineColor(QColor("#193348"))
            wykres.addAxis(os, orientacja)
            seria.attachAxis(os)
        self.wykres = QChartView(wykres)
        self.wykres.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.wykres.setMinimumHeight(95)
        self.wykres.setMaximumHeight(16777215)
        obszar = QHBoxLayout()
        obszar.addWidget(self.wykres, 1)
        udzial = QWidget()
        kolumna = QVBoxLayout(udzial)
        kolumna.setContentsMargins(0, 0, 0, 0)
        kolumna.addWidget(tekst("Łączny przychód: —", "podpisDashboardu"))
        kolumna.addWidget(UdzialKanalow())
        obszar.addWidget(udzial)
        layout.addLayout(obszar, 1)
        layout.addWidget(
            tekst(
                "Liczbę i wartość zamówień pokazują kafelki powyżej. "
                "Szczegółowy wykres sprzedaży jest w przygotowaniu.",
                "podpisDashboardu",
            )
        )

    def _integracje(self) -> None:
        self.panel_integracji = PanelIntegracji()
        self.panel_integracji.zarzadzaj.connect(lambda: self.cel.emit("integracje"))
        self.zarzadzaj_przycisk = self.panel_integracji.zarzadzaj_przycisk
        self.sekcje["integracje"] = self.panel_integracji

    def _alerty(self) -> None:
        _, layout = self._panel("alerty", "Alerty systemowe")
        for id, nazwa in (
            ("zdjecia", "Produkty bez zdjęć"),
            ("ean", "Produkty bez EAN"),
            ("producent", "Produkty bez producenta"),
            ("opis", "Produkty bez opisu"),
            ("korekty", "Błędy importu"),
        ):
            b = przycisk(f"△  {nazwa}     —", partial(self.alert.emit, id))
            b.setFixedHeight(22)
            b.setProperty("nazwa_alertu", nazwa)
            self.alerty[id] = b
            layout.addWidget(b)
        layout.addWidget(
            tekst(
                "Kategorie, publikacja, synchronizacja i stany: brak odczytu.", "podpisDashboardu"
            )
        )

    def _tabela(
        self, id: str, nazwa: str, kolumny: list[str], pustka: str, zakladki: tuple[str, ...] = ()
    ) -> None:
        _, layout = self._panel(id, nazwa)
        if zakladki:
            self._zakladki(layout, zakladki)
        tabela = QTableWidget(0, len(kolumny))
        tabela.setAccessibleName(nazwa)
        tabela.setHorizontalHeaderLabels(kolumny)

        tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        tabela.horizontalHeader().setMinimumSectionSize(26)
        tabela.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        tabela.setStyleSheet(
            "QHeaderView::section {font-size:10px;padding:4px;} QTableWidget {font-size:10px;}"
        )
        tabela.verticalHeader().hide()
        tabela.setMinimumWidth(0)
        tabela.setMinimumHeight(52)
        tabela.setMaximumHeight(84)
        tabela.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Expanding)
        layout.addWidget(tabela, 1)
        opis = tekst(pustka, "podpisDashboardu")
        layout.addWidget(opis)
        self._tabele[id], self._opisy_tabel[id] = tabela, opis

    def _ai(self) -> None:
        _, layout = self._panel("ai", "AI Center")
        item = layout.takeAt(0)
        tytul = item.widget() if item is not None else None
        naglowek = QHBoxLayout()
        if tytul is not None:
            naglowek.addWidget(tytul, 1)
        self.ai_otworz = przycisk("Otwórz kreatora", lambda: self.cel.emit("Kreator opisów (AI)"))
        self.ai_otworz.setToolTip("Otwórz moduł opisów AI; integracja jest w przygotowaniu.")
        naglowek.addWidget(self.ai_otworz)
        layout.addLayout(naglowek)
        self.ai_grid = QGridLayout()
        self.ai_grid.setSpacing(7)
        self.ai_wartosci: dict[str, QLabel] = {}
        self.ai_kafelki: list[tuple[QFrame, str, str, QLabel]] = []
        for i, (id, nazwa, symbol, kolor) in enumerate(
            (
                ("opisy", "Wygenerowane opisy", "ai_opisy", "#9255F0"),
                ("seo", "Sugestie SEO", "ai", "#8ABFEC"),
                ("bez_opisu", "Produkty bez opisu", "produkt", "#F0A515"),
                ("bez_zdjec", "Produkty bez zdjęć", "media", "#EC428B"),
                ("optymalizacja", "Optymalizacje tytułów", "globus", "#08CBA0"),
            )
        ):
            tile = QFrame()
            tile.setObjectName("kafelekAI")
            tile.setFixedHeight(49)
            box = QHBoxLayout(tile)
            box.setContentsMargins(7, 6, 7, 6)
            box.setSpacing(8)
            obraz = QLabel()
            obraz.setObjectName("ikonaAI")
            obraz.setFixedSize(28, 28)
            obraz.setAlignment(Qt.AlignmentFlag.AlignCenter)
            obraz.setPixmap(ikona(symbol, kolor).pixmap(QSize(20, 20)))
            obraz.setAccessibleName(f"Ikona: {nazwa}")
            box.addWidget(obraz)
            kolumna = QVBoxLayout()
            kolumna.setContentsMargins(0, 0, 0, 0)
            kolumna.setSpacing(1)
            podpis = tekst(nazwa, "podpisAI")
            kolumna.addWidget(podpis)
            dol = QHBoxLayout()
            value = tekst("—", "wartoscAI")
            dol.addWidget(value, 1)
            zmiana = tekst("—", "zmianaAI")
            zmiana.setToolTip("Brak porównywalnych danych historycznych.")
            dol.addWidget(zmiana)
            kolumna.addLayout(dol)
            box.addLayout(kolumna, 1)
            self.ai_wartosci[id] = value
            self.ai_kafelki.append((tile, kolor, id, obraz))
            self.ai_grid.addWidget(tile, i // 2, i % 2)
        layout.addLayout(self.ai_grid)
        layout.addStretch()

    def _motyw_ai(self, ciemny: bool) -> None:
        for tile, kolor, _id, obraz in self.ai_kafelki:
            akcent = QColor(kolor)
            tlo = "#121A2B" if ciemny else "#F4F8FD"
            przyciemniony = akcent.darker(430 if ciemny else 110).name()
            koniec = przyciemniony if ciemny else akcent.lighter(185).name()
            tile.setStyleSheet(f"""
                QFrame#kafelekAI {{
                    background:qlineargradient(x1:0,y1:0,x2:1,y2:1,
                    stop:0 {tlo},stop:1 {koniec});
                    border:0;border-radius:7px;
                }}
                QFrame#widgetDashboardu:hover {{border-color:{"#315A79" if ciemny else "#91ABC9"};}}
            QFrame#widgetDashboardu[edycja="true"] {{border:1px dashed #3B82F6;}}
            QFrame#widgetDashboardu QFrame#panelDashboardu {{background:transparent;border:0;}}
            QLabel {{background:transparent;border:0;}}
                QLabel#podpisAI {{color:{"#ADBFDC" if ciemny else "#415B79"};font-size:10px;}}
                QLabel#wartoscAI {{color:{"#F1F5FF" if ciemny else "#142C48"};
                    font-size:15px;font-weight:600;}}
                QLabel#zmianaAI {{color:{"#8396B2" if ciemny else "#627994"};font-size:10px;}}
            """)
            obraz.setStyleSheet(f"background:{przyciemniony};border-radius:7px;")

    def ustaw_stan(self, stan: StanDashboardu) -> None:
        self.karty["produkty"].liczba.setText(f"{stan.produkty:,}".replace(",", " "))
        for id, wartosc in (
            ("zdjecia", stan.bez_zdjec),
            ("ean", stan.bez_ean),
            ("producent", stan.bez_producenta),
            ("opis", stan.bez_opisu),
            ("korekty", stan.do_poprawy),
        ):
            b = self.alerty[id]
            b.setText(f"△  {b.property('nazwa_alertu')}     {wartosc}")
            b.setEnabled(wartosc > 0)
        self.ai_wartosci["bez_opisu"].setText(str(stan.bez_opisu))
        self.ai_wartosci["bez_zdjec"].setText(str(stan.bez_zdjec))
        self.stan_systemu.setText(
            "●  Katalog lokalny dostępny\nIntegracje i kolejka: zgodnie ze stanem obok."
        )
        self.info.setText(
            ("Katalog jest pusty • " if stan.produkty == 0 else "")
            + f"Katalog lokalny: {stan.produkty} produktów • "
            f"Odczyt {datetime.now().strftime('%H:%M:%S')} • "
            + "Zamówienia: "
            + (", ".join(self.raporty_zamowien) or "brak odczytu")
        )

    def ustaw_liczniki_allegro(self, dane: LicznikiAllegro | None, komunikat: str = "") -> None:
        self.panel_integracji.allegro.ustaw_liczbe_ofert(
            dane.aktywne if dane is not None else None, aktywne=True
        )
        karta = self.karty["allegro"]
        karta.liczba.setText(str(dane.aktywne) if dane is not None else "—")
        karta.podpis.setText(
            "Odczyt " + datetime.now().strftime("%H:%M") if dane else "Brak odczytu"
        )
        karta.setToolTip(
            komunikat or "Liczba ofert ACTIVE całego konta z Allegro API; cache do 30 s."
        )

    def ustaw_allegro(self, login: str | None) -> None:
        poprzedni = self.panel_integracji.allegro.wartosci[0].text()
        self.panel_integracji.allegro.ustaw(login)
        if login is None or poprzedni != login:
            self.ustaw_liczniki_allegro(None)

    def rozmiesc(self, szeroki: bool, *, wymus: bool = False) -> None:
        if self._szeroki == szeroki and not wymus:
            return
        self._szeroki = szeroki
        for i, widget in enumerate(self._header_widgets):
            self.naglowek_layout.removeWidget(widget)
            if szeroki:
                self.naglowek_layout.addWidget(widget, 0, i)
            elif i < 3:
                self.naglowek_layout.addWidget(widget, 0, i * 2, 1, 2)
            else:
                self.naglowek_layout.addWidget(widget, 1, i - 3)
        for i in range(len(self._header_widgets)):
            self.naglowek_layout.setColumnStretch(i, int(szeroki and i == 1))
        self.opis_naglowka.setVisible(szeroki)
        if hasattr(self, "tablica"):
            # Starsze wejścia konfiguracji nadal respektują widoczność sekcji.
            if self.ukryte != self._stare_ukryte:
                for ident in self.sekcje:
                    self.tablica.uklad = self.tablica.uklad.zmien(
                        ident, ukryty=ident in self.ukryte
                    )
                self._stare_ukryte = self.ukryte
            self.tablica.rozmiesc()
            QTimer.singleShot(0, self._dopasuj_kafelki)

    def _dopasuj_kafelki(self) -> None:
        width = self.sekcje["kpi"].width()
        n = next(
            count
            for minimum, count in ((1280, 7), (800, 4), (580, 3), (380, 2), (0, 1))
            if width >= minimum
        )
        for i, card in enumerate(self.karty.values()):
            self.grid_kpi.removeWidget(card)
            self.grid_kpi.addWidget(card, i // n, i % n)
        n = max(1, self.akcje.width() // 165)
        row = next(w for w in self.tablica.uklad.widgety if w.id == "akcje")
        visible = [
            b
            for b in self.przyciski_akcji
            if row.skroty is None or b.property("skrot_id") in row.skroty
        ]
        for button in self.przyciski_akcji:
            self.grid_akcji.removeWidget(button)
            if button not in visible:
                button.hide()
        for i, button in enumerate(visible):
            self.grid_akcji.addWidget(button, i // n, i % n)
            button.show()

    def odswiez_motyw(self) -> None:
        ciemny = bool(cast(QApplication, QApplication.instance()).property("motyw_ciemny"))
        if self._ciemny == ciemny:
            return
        self._ciemny = ciemny
        tlo, panel, _krawedz, kolor, opis = (
            ("#070B14", "#121A2B", "#1D2A40", "#F0F5FF", "#9DB3CE")
            if ciemny
            else ("#EDF3FA", "#FFFFFF", "#CDDBEE", "#132B46", "#536B87")
        )
        self.zawartosc.setStyleSheet(f"""
            QWidget#dashboardNowy {{background:{tlo};}}
            QFrame#panelDashboardu, QFrame#metrykaDashboardu, QFrame#widgetDashboardu {{
                background:{tlo_panelu(ciemny)};
                border:0;border-radius:9px;}}
            QFrame#widgetDashboardu:hover {{border-color:{"#315A79" if ciemny else "#91ABC9"};}}
            QFrame#widgetDashboardu[edycja="true"] {{border:1px dashed #3B82F6;}}
            QFrame#widgetDashboardu QFrame#panelDashboardu {{background:transparent;border:0;}}
            QLabel {{background:transparent;color:{kolor};border:0;}}
            QLabel#podpisDashboardu {{color:{opis};font-size:10px;}}
            QFrame#kartaKanalu QLabel#opis {{color:{opis};}}
            QFrame#kartaKanalu QLabel#statusKanalu[polaczono="true"] {{
                color:{"#16C777" if ciemny else "#12743F"};}}
            QFrame#kartaKanalu QLabel#statusKanalu[polaczono="false"] {{color:{opis};}}
            QLabel#naglowekDashboardu {{font-size:24px;font-weight:600;}}
            QLabel#tytulDashboardu {{font-size:13px;font-weight:600;}}
            QLabel#liczbaDashboardu {{font-size:20px;font-weight:600;}}
            QPushButton {{font-size:10px;min-height:16px;padding:4px 7px;}}
            QPushButton#skrotDashboardu {{background:{panel};border:0;text-align:left;}}
            QPushButton#skrotDashboardu:hover {{
                background:{"#172235" if ciemny else "#E8F0FC"};}}
            QLabel#zegarDashboardu {{color:{opis};font-size:14px;}}
        """)
        for button in self.przyciski_akcji:
            if button.objectName() != "skrotDashboardu":
                continue
            akcent = QColor(str(button.property("kolorSkrotu")))
            button.setStyleSheet(f"""
                QPushButton#skrotDashboardu {{
                    background:{akcent.name()};color:#FFFFFF;border:0;
                    border-radius:5px;text-align:left;padding:4px 7px;
                }}
                QPushButton#skrotDashboardu:enabled:hover {{
                    background:{akcent.lighter(120).name()};
                }}
                QPushButton#skrotDashboardu:enabled:pressed {{
                    background:{akcent.darker(115).name()};
                }}
                QPushButton#skrotDashboardu:focus {{
                    border:1px solid {"#A9D2FF" if ciemny else "#163F83"};
                }}
                QPushButton#skrotDashboardu:disabled {{
                    background:rgba({akcent.red()},{akcent.green()},{akcent.blue()},45);
                    color:{opis};
                }}
            """)
        self.wykres.setBackgroundBrush(QColor(tlo))
        self._motyw_ai(ciemny)

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        if hasattr(self, "przyciski_akcji"):
            self.rozmiesc(self.viewport().width() >= 1150)
            self._dopasuj_obrot()
