"""Wirtualizowana lista ostatnich zamówień. Wyłącznie prezentacja istniejących DTO."""

from collections.abc import Mapping
from datetime import datetime

from PySide6.QtCore import (
    QAbstractListModel,
    QModelIndex,
    QPersistentModelIndex,
    QRect,
    QRectF,
    QSize,
    Qt,
)
from PySide6.QtGui import QColor, QFont, QFontMetrics, QIcon, QPainter, QPainterPath, QPalette
from PySide6.QtWidgets import (
    QListView,
    QStyledItemDelegate,
    QStyleOptionViewItem,
)

from vexlab.gui.pola_zamowienia import flaga_kraju, nazwa_kraju
from vexlab.gui.premium import font_danych
from vexlab.gui.statusy_zamowien import kolory_odznaki
from vexlab.przypadki_uzycia.zamowienia_allegro import RaportZamowien, ZamowienieAllegro
from vexlab.przypadki_uzycia.zamowienia_dashboardu import ZamowienieDashboardu


def czas_wzgledny(value: str) -> str:
    try:
        date = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if date.tzinfo is None:
            date = date.astimezone()
        minutes = max(0, int((datetime.now().astimezone() - date).total_seconds() / 60))
        if minutes < 1:
            return "Przed chwilą"
        if minutes < 60:
            return f"{minutes} min temu"
        if minutes < 1440:
            return f"{minutes // 60} godz. temu"
        return date.astimezone().strftime("%d.%m · %H:%M")
    except ValueError:
        return "Brak daty zakupu"


class ModelOstatnichZamowien(QAbstractListModel):
    def __init__(self) -> None:
        super().__init__()
        self.rows: tuple[ZamowienieDashboardu, ...] = ()
        self.szczegoly: dict[str, ZamowienieAllegro] = {}
        self.ikony: Mapping[str, QIcon | None] = {}

    def ustaw(self, rows: tuple[ZamowienieDashboardu, ...]) -> None:
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def kontekst(self, raport: RaportZamowien | None, ikony: Mapping[str, QIcon | None]) -> None:
        self.szczegoly = {r.id: r for r in raport.pozycje} if raport else {}
        self.ikony = ikony if raport else {}
        self.odswiez_obrazy()

    def odswiez_obrazy(self) -> None:
        if self.rows:
            self.dataChanged.emit(self.index(0), self.index(len(self.rows) - 1))

    def rowCount(self, parent: QModelIndex | QPersistentModelIndex | None = None) -> int:
        return 0 if parent is not None and parent.isValid() else len(self.rows)

    def data(
        self, index: QModelIndex | QPersistentModelIndex, role: int = Qt.ItemDataRole.DisplayRole
    ) -> object:
        if not index.isValid() or not 0 <= index.row() < len(self.rows):
            return None
        row = self.rows[index.row()]
        detail = self.szczegoly.get(row.numer) if row.zrodlo == "Allegro" else None
        if role == Qt.ItemDataRole.UserRole:
            return row, detail
        if role == Qt.ItemDataRole.DecorationRole and detail and detail.pozycje:
            return self.ikony.get(detail.pozycje[0].oferta_id)
        if role in (
            Qt.ItemDataRole.DisplayRole,
            Qt.ItemDataRole.ToolTipRole,
            Qt.ItemDataRole.AccessibleTextRole,
        ):
            title = (
                detail.pozycje[0].nazwa if detail and detail.pozycje else "Zamówienie " + row.numer
            )
            delivery = detail.dostawa if detail else "Dostawa: brak danych w podglądzie"
            return (
                f"{title}\n{row.zrodlo} · {row.numer}\n{row.klient} · {delivery}\n"
                f"{row.kwota} {row.waluta} · {row.status}\nData zakupu: {row.kiedy}"
            )
        return None


class KartaOstatniegoZamowienia(QStyledItemDelegate):
    def __init__(self, parent: QListView) -> None:
        super().__init__(parent)
        self.karty = False

    def sizeHint(
        self, option: QStyleOptionViewItem, index: QModelIndex | QPersistentModelIndex
    ) -> QSize:
        return QSize(300, 146)

    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        value = index.data(Qt.ItemDataRole.UserRole)
        if not isinstance(value, tuple):
            return
        row, detail = value
        painter.save()
        painter.setClipRect(option.rect)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = option.rect.adjusted(3, 4, -3, -4)
        pal = option.palette
        from PySide6.QtWidgets import QStyle

        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        hover = bool(option.state & QStyle.StateFlag.State_MouseOver)
        painter.setBrush(
            pal.brush(QPalette.ColorRole.Highlight if selected else QPalette.ColorRole.Base)
        )
        border_color = pal.color(QPalette.ColorRole.Highlight if hover else QPalette.ColorRole.Text)
        border_color.setAlpha(110 if hover else 35)
        painter.setPen(border_color)
        painter.drawRoundedRect(rect, 8, 8)
        photo = QRect(rect.left() + 10, rect.top() + 12, 56, 56)
        path = QPainterPath()
        path.addRoundedRect(QRectF(photo), 8, 8)
        painter.save()
        painter.setClipPath(path)
        painter.fillPath(path, pal.brush(QPalette.ColorRole.AlternateBase))
        icon = index.data(Qt.ItemDataRole.DecorationRole)
        if isinstance(icon, QIcon):
            icon.paint(painter, photo)
        else:
            painter.setPen(pal.color(QPalette.ColorRole.PlaceholderText))
            painter.drawText(photo, Qt.AlignmentFlag.AlignCenter, "▧")
        painter.restore()
        left, right = photo.right() + 12, rect.right() - 12
        available = max(0, right - left)
        font = QFont(option.font)
        font.setWeight(QFont.Weight.DemiBold)
        painter.setFont(font)
        painter.setPen(
            pal.color(QPalette.ColorRole.HighlightedText if selected else QPalette.ColorRole.Text)
        )
        product = detail.pozycje[0] if detail and detail.pozycje else None
        title = product.nazwa if product else "Zamówienie " + row.numer
        if detail and len(detail.pozycje) > 1:
            title += f" · +{len(detail.pozycje) - 1} produkty"
        self._tekst(painter, QRect(left, rect.top() + 10, available, 22), title)
        font.setWeight(QFont.Weight.Normal)
        font.setPixelSize(11)
        painter.setFont(font)
        painter.setPen(pal.color(QPalette.ColorRole.PlaceholderText))
        painter.save()
        painter.setFont(font_danych(font))
        self._tekst(
            painter,
            QRect(left, rect.top() + 33, available, 18),
            "SKU: " + product.sku if product else row.zrodlo + " · " + row.numer,
        )
        painter.restore()
        painter.setPen(pal.color(QPalette.ColorRole.Text))
        self._tekst(painter, QRect(left, rect.top() + 53, available, 18), "Kupujący: " + row.klient)
        delivery = row.zrodlo + " · " + (detail.dostawa if detail else "Dostawa: brak danych")
        self._tekst(painter, QRect(left, rect.top() + 73, available, 18), delivery)
        # Ostatni rząd nie zależy od długości nazwy, loginu ani sposobu dostawy.
        bottom = rect.bottom() - 23
        painter.save()
        painter.setPen(pal.color(QPalette.ColorRole.Text))
        font.setWeight(QFont.Weight.DemiBold)
        painter.setFont(font_danych(font))
        self._tekst(
            painter,
            QRect(rect.left() + 10, bottom, min(115, rect.width() // 3), 20),
            row.kwota + " " + row.waluta,
        )
        painter.restore()
        ciemny = pal.color(QPalette.ColorRole.Base).lightness() < 128
        bg, fg, border = kolory_odznaki(row.kod_statusu, ciemny)
        statuswidth = min(130, max(65, rect.width() // 3))
        badge = QRect(rect.right() - statuswidth - 10, bottom - 1, statuswidth, 23)
        painter.setBrush(QColor(bg))
        painter.setPen(QColor(border))
        painter.drawRoundedRect(badge, 6, 6)
        painter.setPen(QColor(fg))
        self._tekst(painter, badge.adjusted(7, 0, -7, 0), "● " + row.status)
        font.setWeight(QFont.Weight.Normal)
        font.setPixelSize(10)
        painter.setFont(font)
        painter.setPen(pal.color(QPalette.ColorRole.PlaceholderText))
        country = nazwa_kraju(detail.kraj) if detail else ""
        extra = czas_wzgledny(row.kiedy) + (" · " + country if country else "")
        self._tekst(painter, QRect(left, rect.top() + 94, available, 18), extra)
        if country and detail:
            painter.drawPixmap(rect.left() + 10, rect.top() + 80, flaga_kraju(detail.kraj))
        painter.restore()

    @staticmethod
    def _tekst(painter: QPainter, rect: QRect, value: str) -> None:
        text = QFontMetrics(painter.font()).elidedText(
            value, Qt.TextElideMode.ElideRight, rect.width()
        )
        painter.drawText(rect, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, text)


class ListaOstatnichZamowien(QListView):
    def __init__(self) -> None:
        super().__init__()
        self.dane = ModelOstatnichZamowien()
        self.setModel(self.dane)
        self.karta = KartaOstatniegoZamowienia(self)
        self.setItemDelegate(self.karta)
        self.setMouseTracking(True)
        self.setAccessibleName("Ostatnie zamówienia Allegro i PrestaShop")
        self.setMinimumHeight(150)
        self.setMinimumWidth(0)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setUniformItemSizes(True)
        self.setResizeMode(QListView.ResizeMode.Adjust)
        self.setSpacing(2)

    def wariant(self, name: str) -> None:
        cards = name == "Karty"
        if self.karta.karty == cards:
            return
        self.karta.karty = cards
        self.setFlow(QListView.Flow.LeftToRight if cards else QListView.Flow.TopToBottom)
        self.setWrapping(cards)
        self.setGridSize(QSize(320, 152) if cards else QSize())
        self.doItemsLayout()
        self.viewport().update()
