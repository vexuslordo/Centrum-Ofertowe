"""Podgląd przed zgodą na cenę i modeless historia technicznych wyników."""

from collections.abc import Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDialogButtonBox,
    QHeaderView,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.przypadki_uzycia.aktualizacja_cen_allegro import PlanCen, ProbaCeny


def potwierdz_ceny(parent: QWidget, plan: PlanCen) -> bool:
    d = QDialog(parent)
    d.setWindowTitle("Zatwierdź aktualizację cen Allegro")
    d.resize(1000, 600)
    d.setSizeGripEnabled(True)
    box = QVBoxLayout(d)
    label = QLabel(
        f"Konto: {plan.raport.login} • {plan.raport.srodowisko}\n"
        f"Ofert: {len(plan.pozycje)}. Zmienisz cenę brutto na rynku głównym tych ofert.\n"
        "Powiązane reguły kursowe Allegro mogą przeliczyć ceny na innych rynkach."
    )
    label.setWordWrap(True)
    box.addWidget(label)
    tabela = QTableWidget(len(plan.pozycje), 5)
    tabela.setHorizontalHeaderLabels(
        ["SKU", "ID Allegro", "Obecna brutto", "Nowa brutto", "Różnica"]
    )
    tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    for i, p in enumerate(plan.pozycje):
        for j, text in enumerate(
            (
                p.sku,
                p.ident,
                f"{p.obecna} {p.waluta_obecna}",
                f"{p.docelowa} {p.waluta_docelowa}",
                f"{p.roznica} {p.waluta_docelowa}",
            )
        ):
            tabela.setItem(i, j, QTableWidgetItem(text))
    box.addWidget(tabela)
    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
    buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
    save = buttons.addButton("Zapisz ceny w Allegro", QDialogButtonBox.ButtonRole.AcceptRole)
    save.setObjectName("primary")
    buttons.accepted.connect(d.accept)
    buttons.rejected.connect(d.reject)
    box.addWidget(buttons)
    return d.exec() == QDialog.DialogCode.Accepted


class HistoriaCen(QDialog):
    def __init__(
        self,
        parent: QWidget,
        rows: tuple[ProbaCeny, ...],
        sprawdz: Callable[[tuple[str, ...]], None],
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Historia cen Allegro — wyniki i powody")
        self.resize(1100, 650)
        self.setSizeGripEnabled(True)
        box = QVBoxLayout(self)
        info = QLabel(
            "Gotowe = potwierdzona cena. Do sprawdzenia = wyłącznie odczyt "
            "wyniku, bez ponownej wysyłki."
        )
        info.setWordWrap(True)
        box.addWidget(info)
        self.tabela = QTableWidget(0, 7)
        self.tabela.setHorizontalHeaderLabels(
            ["Czas UTC", "SKU", "ID Allegro", "Przed", "Po", "Wynik", "Powód"]
        )
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeMode.Stretch)
        self.tabela.verticalHeader().hide()
        for col, width in enumerate((215, 135, 110, 90, 90, 145)):
            self.tabela.setColumnWidth(col, width)
        self.tabela.setWordWrap(True)
        box.addWidget(self.tabela)
        self.sprawdz = QPushButton("Sprawdź oczekujące wyniki")
        self.sprawdz.clicked.connect(
            lambda: sprawdz(tuple(p.id for p in self.rows if p.status == "Do sprawdzenia"))
        )
        box.addWidget(self.sprawdz)
        self.ustaw(rows)

    def ustaw(self, rows: tuple[ProbaCeny, ...]) -> None:
        self.rows = rows
        self.tabela.setRowCount(len(rows))
        for i, p in enumerate(rows):
            for j, text in enumerate(
                (
                    p.kiedy,
                    p.sku,
                    p.ident,
                    f"{p.przed} {p.waluta}",
                    f"{p.po} {p.waluta}",
                    p.status,
                    p.powod,
                )
            ):
                item = QTableWidgetItem(text)
                item.setToolTip(text)
                if j == 0:
                    item.setData(Qt.ItemDataRole.UserRole, p)
                self.tabela.setItem(i, j, item)
        self.tabela.resizeRowsToContents()
        self.sprawdz.setEnabled(any(p.status == "Do sprawdzenia" for p in rows))
