"""Układ jednej zakładki: nagłówek, KPI, ustawienia, tabela, szczegóły i akcje."""

from typing import TYPE_CHECKING

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMenu,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.elementy_paneli_ofert import odznaka

if TYPE_CHECKING:
    from vexlab.gui.centrum_nowych_ofert import CentrumNowychOfert


def sekcja(tytul: str, layout: QVBoxLayout) -> QVBoxLayout:
    label = QLabel(tytul)
    label.setObjectName("tytulSekcjiAllegro")
    label.setWordWrap(True)
    layout.addWidget(label)
    box = QVBoxLayout()
    box.setSpacing(6)
    layout.addLayout(box)
    return box


class UkladNowychOfert:
    def __init__(self, c: "CentrumNowychOfert", host: QWidget, layout: QVBoxLayout) -> None:
        page = c.page
        self.page = page
        # StronaPaczek tworzy kontrolki i ich połączenia; tutaj dostają jedno miejsce.
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget() if item else None
            if widget is not None:
                widget.hide()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        host.setObjectName("centrumNowychOfert")
        header = QHBoxLayout()
        text = QVBoxLayout()
        crumb = QLabel("Oferty › Nowe oferty")
        crumb.setObjectName("opis")
        text.addWidget(crumb)
        text.addWidget(page.tytul)
        page.opis_paczek.setText(
            "Wczytaj paczkę, uzupełnij dane i sprawdź oferty przed wysłaniem szkiców do Allegro."
        )
        page.opis_paczek.setObjectName("opis")
        text.addWidget(page.opis_paczek)
        header.addLayout(text, 1)
        page.wczytaj_paczke.setObjectName("")
        header.addWidget(page.wczytaj_paczke)
        header.addWidget(page.zapisz_szkice)
        self.wiecej = QPushButton("Więcej działań")
        self.menu = QMenu(self.wiecej)
        self.wiecej.setMenu(self.menu)
        for button in (page.recznie, c.podglad, c.szczegoly_przycisk):
            action = self.menu.addAction(button.text())
            if button is c.szczegoly_przycisk:
                action.setCheckable(True)
                action.setChecked(True)
                action.toggled.connect(button.setChecked)
                button.toggled.connect(action.setChecked)
            else:
                action.triggered.connect(button.click)
                self.menu.aboutToShow.connect(
                    lambda a=action, b=button: a.setEnabled(b.isEnabled())
                )
            button.setParent(page)
            button.hide()
        header.addWidget(self.wiecej)
        layout.addLayout(header)
        layout.addWidget(c.kpi_host)
        self.split = QSplitter(Qt.Orientation.Horizontal)
        self.split.setChildrenCollapsible(False)
        self.lewy = QFrame()
        self.lewy.setObjectName("lewyPanelPrzygotowania")
        self.lewy.setMinimumWidth(250)
        self.lewy.setMaximumWidth(300)
        left = QVBoxLayout(self.lewy)
        left.setContentsMargins(12, 12, 12, 12)
        left.setSpacing(8)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.viewport().setAutoFillBackground(False)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        content = QWidget()
        content.setObjectName("trescUstawienOfert")
        self.lewy_layout = QVBoxLayout(content)
        self.lewy_layout.setContentsMargins(0, 0, 0, 0)
        self.lewy_layout.setSpacing(10)
        self.import_group = QWidget()
        import_box = QVBoxLayout(self.import_group)
        import_box.setContentsMargins(0, 0, 0, 0)
        sekcja("Wczytanie paczki", import_box).addWidget(page.importowanie)
        self.lewy_layout.addWidget(self.import_group)
        self.wskazowka = QLabel("Wczytaj paczkę ZIP. Ustawienia Allegro pojawią się w tym panelu.")
        self.wskazowka.setWordWrap(True)
        self.wskazowka.setObjectName("opis")
        self.lewy_layout.addWidget(self.wskazowka)
        self.kontrolki = QWidget()
        self.kontrolki_layout = QVBoxLayout(self.kontrolki)
        self.kontrolki_layout.setContentsMargins(0, 0, 0, 0)
        self.lewy_layout.addWidget(self.kontrolki)
        self.lewy_layout.addStretch()
        scroll.setWidget(content)
        content.setAutoFillBackground(False)
        left.addWidget(scroll)
        self.scroll_ustawien = scroll
        center = QWidget()
        middle = QVBoxLayout(center)
        middle.setContentsMargins(0, 0, 0, 0)
        middle.setSpacing(8)
        middle.addWidget(c.filtry_host)
        self.narzedzia = QHBoxLayout()
        self.narzedzia.addWidget(c.szukaj, 1)
        self.narzedzia.addWidget(c.szczegoly_przycisk)
        c.szczegoly_przycisk.show()
        middle.addLayout(self.narzedzia)
        middle.addWidget(page.info)
        self.konto = QHBoxLayout()
        middle.addLayout(self.konto)
        self.tresc = QStackedWidget()
        self.tresc.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.tresc.addWidget(page.tabela)
        page.tabela.show()
        middle.addWidget(self.tresc, 1)
        self.split.addWidget(self.lewy)
        self.split.addWidget(center)
        self.split.addWidget(c.panel)
        self.split.setStretchFactor(1, 1)
        self.split.setSizes([270, 815, 300])
        layout.addWidget(self.split, 1)
        self.stopka = QFrame()
        self.stopka.setObjectName("stopkaPrzygotowania")
        footer = QVBoxLayout(self.stopka)
        footer.setContentsMargins(12, 8, 12, 8)
        footer.setSpacing(5)
        self.stopka_grid = QGridLayout()
        self.stopka_grid.setContentsMargins(0, 0, 0, 0)
        self.stopka_grid.setHorizontalSpacing(14)
        footer.addLayout(self.stopka_grid)
        self.postep_blok = QWidget()
        self.postep_blok.setFixedWidth(330)
        progress = QVBoxLayout(self.postep_blok)
        progress.setContentsMargins(0, 0, 0, 0)
        progress.setSpacing(4)
        self.postep_tytul = QLabel("Postęp przygotowania ofert")
        self.postep_tytul.setObjectName("tytulSekcjiAllegro")
        progress.addWidget(self.postep_tytul)
        self.licznik = QLabel("0 / 0 gotowych")
        self.licznik.setObjectName("opis")
        progress.addWidget(self.licznik)
        bar = QHBoxLayout()
        bar.setSpacing(6)
        self.postepy = QVBoxLayout()
        self.postepy.setContentsMargins(0, 0, 0, 0)
        self.postepy.addWidget(c.postep)
        bar.addLayout(self.postepy, 1)
        self.procent = QLabel("0%")
        self.procent.setObjectName("opis")
        bar.addWidget(self.procent)
        progress.addLayout(bar)
        self.odznaki_host = QWidget()
        badges = QHBoxLayout(self.odznaki_host)
        badges.setContentsMargins(0, 0, 0, 0)
        badges.setSpacing(6)
        self.odznaki: dict[str, QLabel] = {}
        for key, opis, tone in (
            ("gotowe", "0 gotowe", "zielony"),
            ("gpsr", "0 GPSR", "zloty"),
            ("parametry", "0 parametrów", "zloty"),
            ("ean", "0 EAN", "czerwony"),
        ):
            label = QLabel()
            odznaka(label, opis, tone)
            label.setFixedHeight(28)
            label.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
            badges.addWidget(label, 0, Qt.AlignmentFlag.AlignVCenter)
            self.odznaki[key] = label
        self.akcje_host = QWidget()
        self.akcje = QVBoxLayout(self.akcje_host)
        self.akcje.setContentsMargins(0, 0, 0, 0)
        self.poczatek = QHBoxLayout()
        self.poczatek.addStretch()
        self.poczatek.addWidget(page.przygotuj_allegro)
        self.akcje.addLayout(self.poczatek)
        self.operacja = QVBoxLayout()
        self.operacja.setContentsMargins(0, 0, 0, 0)

        footer.addLayout(self.operacja)
        c.podsumowanie.setParent(host)
        c.podsumowanie.hide()
        self._stopka_szeroka: bool | None = None
        self.rozmiar_stopki(page.width())
        layout.addWidget(self.stopka)
        page.przygotuj_allegro.setVisible(page.allegro_dostepne)
        page.zapisz_szkice.setVisible(page.szkice is not None)
        c.hint.setParent(host)
        c.hint.hide()
        page.opis_szkicow_lokalnych.hide()
        self.wczytywanie_wlaczone(True)

    def rozmiar_stopki(self, szerokosc: int) -> None:
        szeroka = szerokosc >= 1300
        if szeroka == self._stopka_szeroka:
            return
        self._stopka_szeroka = szeroka
        self.stopka_grid.addWidget(self.postep_blok, 0, 0)
        self.stopka_grid.addWidget(
            self.odznaki_host,
            0,
            1,
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
        )
        self.stopka_grid.addWidget(
            self.akcje_host,
            0 if szeroka else 1,
            3 if szeroka else 0,
            1,
            1 if szeroka else 4,
            Qt.AlignmentFlag.AlignRight,
        )
        self.stopka_grid.setColumnStretch(2, 1)

    def pokaz_importowanie(self) -> None:
        self.lewy.show()
        self.scroll_ustawien.ensureWidgetVisible(self.page.konfiguracja)

    def wczytywanie_wlaczone(self, wlaczone: bool) -> None:
        self.page.wczytaj_paczke.setEnabled(wlaczone)
        self.page.importowanie.setEnabled(wlaczone)

    def wyczysc_kontrolki(self) -> None:
        while self.kontrolki_layout.count():
            item = self.kontrolki_layout.takeAt(0)
            widget = item.widget() if item else None
            if widget is not None:
                widget.deleteLater()
