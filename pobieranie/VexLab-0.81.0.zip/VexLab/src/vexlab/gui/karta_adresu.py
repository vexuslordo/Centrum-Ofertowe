"""Karta adresu z hierarchią tekstu i jawnym kopiowaniem danych źródłowych."""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from vexlab.gui.design_system import ikona
from vexlab.gui.pola_zamowienia import flaga_kraju, nazwa_kraju


class KartaAdresu(QFrame):
    def __init__(self, title: str, symbol: str) -> None:
        super().__init__()
        self.setObjectName("kartaAdresuZamowienia")
        self._tekst = ""
        box = QVBoxLayout(self)
        box.setContentsMargins(10, 10, 10, 10)
        box.setSpacing(5)
        head = QHBoxLayout()
        icon = QLabel()
        icon.setPixmap(ikona(symbol).pixmap(16, 16))
        head.addWidget(icon)
        caption = QLabel(title)
        caption.setObjectName("tytulKartyAdresu")
        head.addWidget(caption, 1)
        self.kopiuj = QPushButton()
        self.kopiuj.setObjectName("kopiujPoleZamowienia")
        self.kopiuj.setIcon(ikona("kopiuj"))
        self.kopiuj.setFixedSize(22, 22)
        self.kopiuj.setToolTip("Kopiuj: " + title.lower())
        self.kopiuj.clicked.connect(self._kopiuj)
        head.addWidget(self.kopiuj)
        box.addLayout(head)
        self.nazwa = self.label("odbiorcaAdresu")
        self.szczegoly = self.label("trescAdresu")
        box.addWidget(self.nazwa)
        box.addWidget(self.szczegoly)
        self.kraj = QFrame()
        country_row = QHBoxLayout(self.kraj)
        country_row.setContentsMargins(0, 3, 0, 0)
        country_row.setSpacing(6)
        self.flaga, self.nazwa_kraju = QLabel(), self.label("krajAdresu")
        country_row.addWidget(self.flaga)
        country_row.addWidget(self.nazwa_kraju, 1)
        box.addWidget(self.kraj)
        self.wyczysc()

    @staticmethod
    def label(name: str) -> QLabel:
        label = QLabel()
        label.setObjectName(name)
        label.setWordWrap(True)
        label.setTextFormat(Qt.TextFormat.PlainText)
        label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        return label

    def ustaw(self, value: str) -> None:
        self.wyczysc()
        self._tekst = value.strip()
        lines = [line.strip() for line in value.splitlines() if line.strip()]
        code = lines.pop() if lines and len(lines[-1]) == 2 and lines[-1].isupper() else ""
        self.nazwa.setText(lines[0] if lines else "Nie podano adresu")
        self.szczegoly.setText("\n".join(lines[1:]))
        self.szczegoly.setVisible(bool(lines[1:]))
        self.kraj.setVisible(bool(code))
        if code:
            self.flaga.setPixmap(flaga_kraju(code))
            self.nazwa_kraju.setText(nazwa_kraju(code))
        self.kopiuj.setEnabled(bool(self._tekst))

    def _kopiuj(self) -> None:
        if self._tekst:
            QApplication.clipboard().setText(self._tekst)

    def text(self) -> str:
        return self._tekst

    def wyczysc(self) -> None:
        self._tekst = ""
        for label in (self.nazwa, self.szczegoly, self.nazwa_kraju, self.flaga):
            label.clear()
        self.kraj.hide()
        self.kopiuj.setEnabled(False)
