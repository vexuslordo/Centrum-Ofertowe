"""Bezpośrednia edycja kart opisu, bez drzewa sekcji i zakładek."""

from html import escape
from typing import cast
from uuid import uuid4

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.edytor_opisu import EdytorOpisu, html_edytora
from vexlab.gui.podglad_oferty import ObrazyOferty
from vexlab.gui.producenci import Uruchom
from vexlab.gui.przeciaganie_ofert import StrefaUpuszczania, TekstZPrzeciaganiem, UchwytSekcji
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec

UKLADY = (
    ("Sam tekst", ("tekst",)),
    ("Samo zdjęcie", ("obraz",)),
    ("Tekst i zdjęcie", ("tekst", "obraz")),
    ("Dwa zdjęcia", ("obraz", "obraz")),
)


class KartaOpisu(StrefaUpuszczania):
    def __init__(self, edytor: "OpisNaStronie", elementy: tuple[ElementPodgladu, ...]) -> None:
        super().__init__(edytor)
        self.edytor, self.elementy, self.ident = edytor, elementy, str(uuid4())
        self.setObjectName("kartaOpisu")
        self.layout_karty = QVBoxLayout(self)
        self.layout_karty.setContentsMargins(18, 16, 18, 18)
        self.layout_karty.setSpacing(14)
        toolbar = QHBoxLayout()
        toolbar.addWidget(UchwytSekcji(self.ident, self))
        self.uklad = QComboBox()
        self.uklad.setAccessibleName("Układ sekcji opisu")
        for name, kinds in UKLADY:
            self.uklad.addItem(name, kinds)
        current = tuple(e.typ for e in elementy)
        selected = next((i for i, (_, kinds) in enumerate(UKLADY) if kinds == current), -1)
        if selected < 0:
            self.uklad.addItem("Układ istniejący", current)
            selected = self.uklad.count() - 1
        self.uklad.setCurrentIndex(selected)
        toolbar.addWidget(self.uklad)
        toolbar.addStretch()
        for label, delta in (("↑", -1), ("↓", 1)):
            b = QToolButton()
            b.setText(label)
            b.setAccessibleName("Przesuń sekcję " + ("w górę" if delta < 0 else "w dół"))
            b.clicked.connect(lambda _=False, d=delta: edytor.przesun(self, d))
            toolbar.addWidget(b)
        remove = QToolButton()
        remove.setText("Usuń")
        remove.setAccessibleName("Usuń tę sekcję opisu")
        remove.clicked.connect(lambda: edytor.usun(self))
        toolbar.addWidget(remove)
        self.layout_karty.addLayout(toolbar)
        self.pola = QHBoxLayout()
        self.layout_karty.addLayout(self.pola)
        self.uklad.activated.connect(self.zmien_uklad)
        self.obraz.connect(lambda url: edytor.wstaw_obraz(self, url))
        self.pliki.connect(lambda files: edytor.pliki_do_opisu(self, None, files))
        self.sekcja.connect(lambda ident, after: edytor.przenies(ident, self, after))
        self.renderuj()

    def zmien_uklad(self) -> None:
        kinds = tuple(self.uklad.currentData())
        old = list(self.elementy)
        nowe = []
        for kind in kinds:
            idx = next((i for i, e in enumerate(old) if e.typ == kind), None)
            nowe.append(old.pop(idx) if idx is not None else ElementPodgladu(kind))
        if any(e.tekst.strip() or e.adres for e in old):
            answer = QMessageBox.question(
                self,
                "Zmienić układ?",
                "Nowy układ usunie część treści tej sekcji. Kontynuować?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                self.uklad.setCurrentIndex(
                    max(0, self.uklad.findData(tuple(e.typ for e in self.elementy)))
                )
                return
        self.elementy = tuple(nowe)
        self.edytor.zmieniony = True
        self.renderuj()

    def zmien_element(self, idx: int, element: ElementPodgladu) -> None:
        values = list(self.elementy)
        values[idx] = element
        self.elementy = tuple(values)
        self.edytor.zmieniony = True

    def renderuj(self) -> None:
        while self.pola.count():
            item = self.pola.takeAt(0)
            widget = item.widget() if item is not None else None
            if widget is not None:
                widget.hide()
                widget.deleteLater()
        for idx, element in enumerate(self.elementy):
            host = StrefaUpuszczania()
            host.setFrameShape(StrefaUpuszczania.Shape.NoFrame)
            col = QVBoxLayout(host)
            host.obraz.connect(lambda url, n=idx: self.edytor.wstaw_obraz(self, url, n))
            host.pliki.connect(lambda files, n=idx: self.edytor.pliki_do_opisu(self, n, files))
            host.sekcja.connect(lambda ident, after: self.edytor.przenies(ident, self, after))
            self.pola.addWidget(host, 1)
            if element.typ == "tekst":
                tools = QHBoxLayout()
                text = TekstZPrzeciaganiem(element.tekst)
                text.setMinimumHeight(150)
                text.setMaximumHeight(420)
                text.setPlaceholderText("Wpisz opis produktu…")
                text.setAccessibleName("Treść sekcji opisu")
                text.upuszczono.connect(lambda value: self.edytor.drop_na_tekst(self, value))
                for name, style in (
                    ("B", "bold"),
                    ("I", "italic"),
                    ("U", "underline"),
                    ("Lista", "list"),
                    ("Nagłówek", "heading"),
                ):
                    b = QToolButton()
                    b.setText(name)
                    b.setAccessibleName(
                        {"B": "Pogrubienie", "I": "Kursywa", "U": "Podkreślenie"}.get(name, name)
                    )
                    b.clicked.connect(lambda _=False, t=text, s=style: EdytorOpisu.formatuj(t, s))
                    tools.addWidget(b)
                tools.addStretch()
                col.addLayout(tools)
                col.addWidget(text)
                text.textChanged.connect(
                    lambda n=idx, t=text: self.zmien_element(
                        n, ElementPodgladu("tekst", html_edytora(t.toHtml()))
                    )
                )
            else:
                if element.adres:
                    col.addWidget(self.edytor.obrazy.obraz(element.adres))
                else:
                    label = etykieta("Przeciągnij tu zdjęcie z galerii lub z dysku")
                    label.setMinimumHeight(150)
                    col.addWidget(label)
                choose = QPushButton("Zmień zdjęcie" if element.adres else "Wybierz zdjęcie")
                choose.clicked.connect(lambda _=False, n=idx: self.edytor.wybierz_zdjecie(self, n))
                col.addWidget(choose)


class OpisNaStronie(StrefaUpuszczania):
    pliki_zadane = Signal(object)
    dodaj_zdjecia_zadane = Signal()
    podglad_zadany = Signal()

    def __init__(
        self, oferta: OfertaPodglad, parent: QWidget, zdjecia: PodgladZdjec | None, uruchom: Uruchom
    ) -> None:
        super().__init__(parent)
        self.setFrameShape(StrefaUpuszczania.Shape.NoFrame)
        self.oferta, self.tytul, self.zmieniony = oferta, oferta.tytul, False
        self.obrazy = ObrazyOferty(parent, zdjecia, uruchom)
        self.miniatury = ObrazyOferty(parent, zdjecia, uruchom, miniatury=True)
        self.adresy = oferta.zdjecia
        self.karty: list[KartaOpisu] = []
        self.cel_plikow: tuple[KartaOpisu | None, int | None] | None = None
        self.layout_opisu = QVBoxLayout(self)
        self.layout_opisu.setContentsMargins(0, 0, 0, 0)
        header = QHBoxLayout()
        heading = etykieta("03   Opis produktu")
        heading.setObjectName("naglowekSekcji")
        header.addWidget(heading, 1)
        preview = QPushButton("Podgląd oferty")
        preview.clicked.connect(self.podglad_zadany.emit)
        header.addWidget(preview)
        self.layout_opisu.addLayout(header)
        self.pole_kart = QVBoxLayout()
        self.pole_kart.setSpacing(18)
        self.layout_opisu.addLayout(self.pole_kart)
        for row in oferta.sekcje or ((ElementPodgladu("tekst", oferta.opis),),):
            self._dodaj(row)
        bottom = QHBoxLayout()
        for name, kinds in UKLADY:
            b = QPushButton("+ " + name)
            b.clicked.connect(lambda _=False, types=kinds: self.dodaj(types))
            bottom.addWidget(b)
        self.layout_opisu.addLayout(bottom)
        self.layout_opisu.addWidget(
            etykieta("Przeciągnij zdjęcie do opisu. Sekcje przestawisz za uchwyt ⠿.")
        )
        self.obraz.connect(lambda url: self.dodaj_zdjecie(url))
        self.pliki.connect(lambda files: self.pliki_do_opisu(None, None, files))
        self.sekcja.connect(lambda ident, _after: self.przenies(ident, None, True))

    def zamknij(self) -> None:
        self.obrazy.zamknij()
        self.miniatury.zamknij()

    def _dodaj(self, row: tuple[ElementPodgladu, ...], index: int | None = None) -> KartaOpisu:
        card = KartaOpisu(self, row)
        if index is None:
            index = len(self.karty)
        self.karty.insert(index, card)
        self.pole_kart.insertWidget(index, card)
        return card

    def dodaj(self, kinds: tuple[str, ...]) -> None:
        self._dodaj(tuple(ElementPodgladu(k) for k in kinds))
        self.zmieniony = True

    def usun(self, card: KartaOpisu) -> None:
        if card not in self.karty:
            return
        self.karty.remove(card)
        self.pole_kart.removeWidget(card)
        card.hide()
        card.deleteLater()
        self.zmieniony = True

    def przesun(self, card: KartaOpisu, delta: int) -> None:
        if card in self.karty:
            old = self.karty.index(card)
            self._przenies_na(card, max(0, min(len(self.karty) - 1, old + delta)))

    def _przenies_na(self, card: KartaOpisu, index: int) -> None:
        self.karty.remove(card)
        self.pole_kart.removeWidget(card)
        self.karty.insert(index, card)
        self.pole_kart.insertWidget(index, card)
        self.zmieniony = True

    def przenies(self, ident: str, target: KartaOpisu | None, after: bool) -> None:
        card = next((c for c in self.karty if c.ident == ident), None)
        if card is None or card is target:
            return
        others = [c for c in self.karty if c is not card]
        index = others.index(target) + int(after) if target in others else len(others)
        self._przenies_na(card, index)

    def dodaj_zdjecie(self, url: str) -> None:
        if url in self.adresy:
            self._dodaj((ElementPodgladu("obraz", adres=url),))
            self.zmieniony = True

    def wstaw_obraz(self, card: KartaOpisu, url: str, idx: int | None = None) -> None:
        if card not in self.karty or url not in self.adresy:
            return
        if (
            len(card.elementy) == 1
            and card.elementy[0].typ == "tekst"
            and not card.elementy[0].tekst.strip()
        ):
            card.elementy = (ElementPodgladu("obraz", adres=url),)
            card.uklad.setCurrentIndex(1)
            card.renderuj()
            self.zmieniony = True
            return
        if idx is None or card.elementy[idx].typ != "obraz":
            idx = next(
                (i for i, e in enumerate(card.elementy) if e.typ == "obraz" and not e.adres), None
            )
        if idx is not None and card.elementy[idx].typ == "obraz":
            card.zmien_element(idx, ElementPodgladu("obraz", adres=url))
            card.renderuj()
        else:
            index = self.karty.index(card) + 1
            self._dodaj((ElementPodgladu("obraz", adres=url),), index)
            self.zmieniony = True

    def drop_na_tekst(self, card: KartaOpisu, value: object) -> None:
        kind, data = cast(tuple[str, object], value)
        if kind == "obraz":
            self.wstaw_obraz(card, str(data))
        elif kind == "pliki":
            self.pliki_do_opisu(card, None, data)
        else:
            self.przenies(str(data), card, False)

    def pliki_do_opisu(self, card: KartaOpisu | None, idx: int | None, files: object) -> None:
        self.cel_plikow = (card, idx)
        self.pliki_zadane.emit(files)

    def anuluj_dodawanie(self) -> None:
        self.cel_plikow = None

    def set_galeria(self, urls: tuple[str, ...]) -> None:
        self.adresy = urls

    def przyjmij_pliki(self, urls: tuple[str, ...]) -> None:
        if self.cel_plikow is None:
            return
        card, idx = self.cel_plikow
        self.cel_plikow = None
        for url in urls:
            if url not in self.adresy:
                continue
            if card is not None and card in self.karty:
                if (
                    len(card.elementy) == 1
                    and card.elementy[0].typ == "tekst"
                    and not card.elementy[0].tekst.strip()
                ):
                    self.wstaw_obraz(card, url)
                    idx = None
                    continue
                if idx is None or card.elementy[idx].typ != "obraz":
                    idx = next(
                        (
                            i
                            for i, e in enumerate(card.elementy)
                            if e.typ == "obraz" and not e.adres
                        ),
                        None,
                    )
                if idx is not None:
                    self.wstaw_obraz(card, url, idx)
                else:
                    card = self._dodaj(
                        (ElementPodgladu("obraz", adres=url),), self.karty.index(card) + 1
                    )
                    self.zmieniony = True
            else:
                self.dodaj_zdjecie(url)
                card = self.karty[-1]
            idx = None

    def wybierz_zdjecie(self, card: KartaOpisu, idx: int) -> None:
        if not self.adresy:
            self.cel_plikow = (card, idx)
            self.dodaj_zdjecia_zadane.emit()
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Wybierz zdjęcie z galerii")
        dialog.resize(650, 400)
        layout = QVBoxLayout(dialog)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        host = QWidget()
        grid = QGridLayout(host)
        scroll.setWidget(host)
        layout.addWidget(scroll)
        for i, url in enumerate(self.adresy):
            box = QWidget()
            col = QVBoxLayout(box)
            col.addWidget(self.miniatury.obraz(url))
            b = QPushButton(f"Zdjęcie {i + 1}")

            def use(_checked: bool = False, adres: str = url) -> None:
                self.wstaw_obraz(card, adres, idx)
                dialog.accept()

            b.clicked.connect(use)
            col.addWidget(b)
            grid.addWidget(box, i // 4, i % 4)
        dialog.exec()

    def sekcje(self) -> tuple[tuple[ElementPodgladu, ...], ...]:
        return tuple(c.elementy for c in self.karty)

    def wynik_sekcji(self) -> tuple[tuple[ElementPodgladu, ...], ...]:
        return self.sekcje() if self.zmieniony else self.oferta.sekcje

    def opis(self) -> str:
        if not self.zmieniony:
            return self.oferta.opis
        return "".join(
            e.tekst if e.typ == "tekst" else f'<p><img src="{escape(e.adres, quote=True)}"></p>'
            for s in self.sekcje()
            for e in s
        )
