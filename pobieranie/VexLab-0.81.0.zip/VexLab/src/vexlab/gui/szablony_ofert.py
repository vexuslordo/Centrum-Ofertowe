"""Wybór i jawny zapis własnych treści użytkownika w formularzu."""

from collections.abc import Callable

from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QInputDialog,
    QMessageBox,
    QPushButton,
    QWidget,
)

from vexlab.przypadki_uzycia.szablony_ofert import SzablonyOfert
from vexlab.rdzen.kontrakty import BladTechniczny


class WyborSzablonu(QWidget):
    def __init__(
        self,
        parent: QWidget,
        biblioteka: SzablonyOfert,
        rodzaj: str,
        odczytaj: Callable[[], str],
        zastosuj: Callable[[str], None],
    ) -> None:
        super().__init__(parent)
        self.biblioteka, self.rodzaj = biblioteka, rodzaj
        self.odczytaj, self.zastosuj = odczytaj, zastosuj
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.wybor = QComboBox()
        self.wybor.setAccessibleName("Moje zapisane " + rodzaj)
        self.wybor.setMinimumContentsLength(18)
        self.wybor.setSizeAdjustPolicy(
            QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
        )
        self.zapis = QPushButton("Zapisz jako…")
        self.usuniecie = QPushButton("Usuń")
        layout.addWidget(self.wybor, 1)
        layout.addWidget(self.zapis)
        layout.addWidget(self.usuniecie)
        self.setToolTip(
            "Twoje dane, zachowane przy aktualizacji. Wybór wstawia wartość do formularza. "
            "Zapis jest niezależny od przycisku Zastosuj."
        )
        self.wybor.activated.connect(self.wstaw)
        self.zapis.clicked.connect(self.zapisz)
        self.usuniecie.clicked.connect(self.usun)
        self.odswiez()

    def odswiez(self, nazwa: str = "") -> None:
        self.wybor.clear()
        self.wybor.addItem("Wybierz zapisane…", None)
        try:
            for n, wartosc in self.biblioteka.lista(self.rodzaj):
                self.wybor.addItem(n, wartosc)
            self.wybor.setCurrentIndex(max(0, self.wybor.findText(nazwa)))
        except (BladTechniczny, ValueError) as exc:
            self.wybor.setToolTip(str(exc))
            self.wybor.setItemText(0, "Błąd odczytu — wpisz ręcznie")

    def wstaw(self, index: int) -> None:
        wartosc = self.wybor.itemData(index)
        if isinstance(wartosc, str):
            self.zastosuj(wartosc)

    def zapisz(self) -> None:
        wartosc = self.odczytaj()
        if not wartosc.strip():
            QMessageBox.information(self, "Moje zapisane", "Najpierw wpisz wartość w formularzu.")
            return
        nazwa, ok = QInputDialog.getText(
            self,
            "Zapisz własną wartość",
            "Nazwa, np. Crash pady:",
            text=self.wybor.currentText() if self.wybor.currentIndex() > 0 else "",
        )
        if not ok:
            return
        try:
            istnieje = any(
                n.strip().casefold() == nazwa.strip().casefold()
                for n, _ in self.biblioteka.lista(self.rodzaj)
            )
            if (
                istnieje
                and QMessageBox.question(
                    self,
                    "Zastąpić zapis?",
                    f"Zastąpić własną wartość „{nazwa}”?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No,
                )
                != QMessageBox.StandardButton.Yes
            ):
                return
            self.biblioteka.zapisz(self.rodzaj, nazwa, wartosc)
            self.odswiez(nazwa.strip())
        except (BladTechniczny, ValueError) as exc:
            QMessageBox.warning(self, "Nie zapisano", str(exc))

    def usun(self) -> None:
        if self.wybor.currentIndex() <= 0:
            return
        nazwa = self.wybor.currentText()
        if (
            QMessageBox.question(
                self,
                "Usunąć zapis?",
                f"Usunąć własną wartość „{nazwa}”? Tekst w formularzu pozostanie.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        try:
            self.biblioteka.usun(self.rodzaj, nazwa)
            self.odswiez()
        except (BladTechniczny, ValueError) as exc:
            QMessageBox.warning(self, "Nie usunięto", str(exc))
