"""Opcjonalny branding użytkownika. Bez wbudowanych marek, pobrań i danych katalogu."""

from pathlib import Path

from PySide6.QtCore import QSettings, Qt
from PySide6.QtGui import QIcon, QImageReader, QPixmap

from vexlab.przypadki_uzycia.cenniki import CennikDTO


def klucz_producenta(cennik: CennikDTO) -> str:
    return str(cennik.producent_id or cennik.id)


class BrandingCennikow:
    def __init__(self, ustawienia: QSettings | None = None) -> None:
        self.ustawienia = ustawienia
        self.cache: dict[str, QIcon] = {}

    def logo(self, cennik: CennikDTO) -> QIcon:
        key = klucz_producenta(cennik)
        if key not in self.cache:
            path = self.ustawienia.value("logo/" + key, "") if self.ustawienia else ""
            try:
                self.cache[key] = self._odczytaj(Path(str(path))) if path else QIcon()
            except (OSError, ValueError):
                self.cache[key] = QIcon()
        return self.cache[key]

    @staticmethod
    def _odczytaj(path: Path) -> QIcon:
        if not path.is_file() or path.stat().st_size > 2 * 1024 * 1024:
            raise ValueError("Wybierz obraz PNG, JPG lub WebP do 2 MB.")
        reader = QImageReader(str(path))
        size = reader.size()
        if (
            bytes(reader.format().data()).lower() not in (b"png", b"jpeg", b"jpg", b"webp")
            or not size.isValid()
            or max(size.width(), size.height()) > 2048
        ):
            raise ValueError("Wybierz obraz PNG, JPG lub WebP do 2048×2048 px.")
        image = reader.read()
        if image.isNull():
            raise ValueError("Nie można odczytać obrazu logo.")
        return QIcon(
            QPixmap.fromImage(image).scaled(
                360,
                160,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )

    def ustaw(self, cennik: CennikDTO, path: str) -> None:
        icon = self._odczytaj(Path(path))
        key = klucz_producenta(cennik)
        if self.ustawienia:
            self.ustawienia.setValue("logo/" + key, str(Path(path).absolute()))
            self.ustawienia.sync()
            if self.ustawienia.status() != QSettings.Status.NoError:
                raise OSError("Nie udało się zapisać ustawienia logo.")
        self.cache[key] = icon

    def usun(self, cennik: CennikDTO) -> None:
        key = klucz_producenta(cennik)
        if self.ustawienia:
            self.ustawienia.remove("logo/" + key)
            self.ustawienia.sync()
        self.cache.pop(key, None)
