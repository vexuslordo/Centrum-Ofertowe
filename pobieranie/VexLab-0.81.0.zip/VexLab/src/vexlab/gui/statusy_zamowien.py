"""Polskie etykiety kodów Allegro i kolory prezentacji; bez zmiany statusów."""

from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication

from vexlab.przypadki_uzycia.opisy_zamowien import (
    PLATNOSC as PLATNOSC,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    REALIZACJA as REALIZACJA,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    TYP_PLATNOSCI as TYP_PLATNOSCI,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    ZAKUP as ZAKUP,
)
from vexlab.przypadki_uzycia.opisy_zamowien import (
    etykieta as etykieta,
)
from vexlab.przypadki_uzycia.zamowienia_allegro import stan_platnosci as stan_platnosci


def kolor(kod: str) -> QColor:
    ciemny = QApplication.palette().color(QApplication.palette().ColorRole.Base).lightness() < 128
    paleta = {
        "oplacone": ("#10B981", "#137448"),
        "SENT": ("#10B981", "#137448"),
        "PICKED_UP": ("#10B981", "#137448"),
        "CANCELLED": ("#EF4444", "#B42339"),
        "RETURNED": ("#EF4444", "#B42339"),
        "czesciowo": ("#F59E0B", "#935600"),
        "oczekuje": ("#F59E0B", "#935600"),
        "PROCESSING": ("#3B82F6", "#1766A8"),
        "NEW": ("#3B82F6", "#1766A8"),
    }
    return QColor(paleta.get(kod, ("#B6C8DF", "#435E89"))[0 if ciemny else 1])


def kolory_odznaki(kod: str, ciemny: bool) -> tuple[str, str, str]:
    """Tło, tekst i obramowanie w stonowanej palecie kart programu."""
    wariant = {
        "NEW": "zielony",
        "READY_FOR_SHIPMENT": "niebieski",
        "PROCESSING": "niebieski",
        "READY_FOR_PICKUP": "niebieski",
        "SENT": "fioletowy",
        "PICKED_UP": "fioletowy",
        "CANCELLED": "czerwony",
        "RETURNED": "czerwony",
        "SUSPENDED": "zloty",
    }.get(kod, "szary")
    paleta = {
        "zielony": (("#102923", "#10B981", "#102923"), ("#E2F1E9", "#286349", "#B6D6C3")),
        "niebieski": (("#102340", "#60A5FA", "#102340"), ("#E5EFF9", "#2D608D", "#BAD0E6")),
        "fioletowy": (("#241B36", "#A78BFA", "#241B36"), ("#EEE8F5", "#685182", "#CEBFDE")),
        "czerwony": (("#2E1721", "#EF4444", "#2E1721"), ("#F5E7EC", "#8E465D", "#DFBFCA")),
        "zloty": (("#2C2418", "#F59E0B", "#2C2418"), ("#F4EEDC", "#786132", "#DBCCA8")),
        "szary": (("#1D2A40", "#94A3B8", "#1D2A40"), ("#EAF0F5", "#4E6077", "#C7D3DF")),
    }
    return paleta[wariant][0 if ciemny else 1]
