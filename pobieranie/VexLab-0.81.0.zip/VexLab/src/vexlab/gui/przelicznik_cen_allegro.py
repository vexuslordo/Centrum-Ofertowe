"""Kompaktowy wybór rynków i rzeczywistej reguły kursowej konta."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta as etykieta_bazowa
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.przelicznik_cen_allegro import (
    RYNKI_KURSOWE,
    PrzelicznikCen,
    RegulaKursowa,
    sprawdz_przelicznik,
)


def etykieta(tekst: str, styl: str = "", zawijaj: bool = False) -> QLabel:
    pole = etykieta_bazowa(tekst)
    pole.setObjectName(styl)
    pole.setWordWrap(zawijaj)
    return pole


class WyborPrzelicznika(QDialog):
    def __init__(
        self,
        parent: QWidget,
        sesja: SesjaAllegro,
        liczba: int,
        poprzedni: PrzelicznikCen | None,
        pobierz: Callable[[], tuple[RegulaKursowa, ...]],
        uruchom: Uruchom,
        aktualne: Callable[[], bool],
    ) -> None:
        super().__init__(parent)
        self.sesja, self._pobierz, self._uruchom, self._aktualne = sesja, pobierz, uruchom, aktualne
        self._zamkniete = self._busy = False
        self._reguly: tuple[RegulaKursowa, ...] = ()
        self._poprzedni = poprzedni
        self.wynik: PrzelicznikCen | None = None
        self.setWindowTitle(f"Przelicznik cen • {liczba} ofert")
        self.resize(590, 360)
        layout = QVBoxLayout(self)
        layout.addWidget(etykieta("Automatyczne ceny na rynkach Allegro", "tytul"))
        layout.addWidget(
            etykieta(
                f"Konto: {sesja.konto.login}. Cena bazowa: PLN na allegro.pl. "
                "Każda oferta zachowuje własną polską cenę.",
                zawijaj=True,
            )
        )
        self.stosuj = QCheckBox("Włącz przelicznik cen według kursu Allegro")
        self.stosuj.setChecked(poprzedni is not None)
        layout.addWidget(self.stosuj)
        self.regula = QComboBox()
        self.regula.setAccessibleName("Reguła przelicznika cen Allegro")
        form = QFormLayout()
        form.addRow("Reguła konta", self.regula)
        layout.addLayout(form)
        self.rynki: dict[str, QCheckBox] = {}
        for ident, nazwa, waluta in RYNKI_KURSOWE:
            pole = QCheckBox(f"{nazwa} · {waluta}")
            pole.setChecked(poprzedni is not None and ident in poprzedni.rynki)
            self.rynki[ident] = pole
            layout.addWidget(pole)
        layout.addWidget(
            etykieta(
                "Allegro przelicza i aktualizuje ceny. Reguła jest przypinana po utworzeniu "
                "szkicu. To ustawienie nie uruchamia sprzedaży ani nie włącza rynku.",
                zawijaj=True,
            )
        )
        self.status = etykieta("Pobieranie reguł z Allegro…", zawijaj=True)
        layout.addWidget(self.status)
        self.odswiez = QPushButton("Pobierz reguły ponownie")
        layout.addWidget(self.odswiez)
        self.buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Apply | QDialogButtonBox.StandardButton.Cancel
        )
        self.buttons.button(QDialogButtonBox.StandardButton.Apply).setText(f"Zastosuj ({liczba})")
        self.buttons.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.zastosuj)
        self.buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        self.finished.connect(self._zamknij)
        self.odswiez.clicked.connect(self.pobierz)
        self.stosuj.toggled.connect(self._stan)
        self._stan()
        QTimer.singleShot(0, self.pobierz)

    def _zamknij(self) -> None:
        self._zamkniete = True

    def _stan(self) -> None:
        for pole in (self.regula, *self.rynki.values()):
            pole.setEnabled(not self._busy and self.stosuj.isChecked() and bool(self._reguly))
        self.odswiez.setEnabled(not self._busy)
        self.buttons.button(QDialogButtonBox.StandardButton.Apply).setEnabled(
            not self._busy and (not self.stosuj.isChecked() or bool(self._reguly))
        )

    def pobierz(self) -> None:
        if self._busy or self._zamkniete or not self._aktualne():
            return
        self._busy = True
        self._reguly = ()
        ident = self.regula.currentData() or (self._poprzedni.regula if self._poprzedni else "")
        self.regula.clear()
        self.status.setText("Pobieranie reguł z Allegro…")
        self._stan()

        def ok(w: object) -> None:
            if self._zamkniete or not self._aktualne():
                return
            self._busy = False
            self._reguly = cast(tuple[RegulaKursowa, ...], w)
            for row in self._reguly:
                self.regula.addItem(row.nazwa, row.id)
            index = self.regula.findData(ident)
            if index >= 0:
                self.regula.setCurrentIndex(index)
            self.status.setText(
                "Wybierz rynki."
                if self._reguly
                else "Brak reguły EXCHANGE_RATE. Sprawdź reguły cenowe w Allegro."
            )
            self._stan()

        def blad(_kod: str, tekst: str) -> None:
            if self._zamkniete or not self._aktualne():
                return
            self._busy = False
            self.status.setText(tekst)
            self._stan()

        self._uruchom(self._pobierz, ok, blad)

    def zastosuj(self) -> None:
        if self._busy or not self._aktualne():
            return
        if not self.stosuj.isChecked():
            self.wynik = None
            self.accept()
            return
        u = PrzelicznikCen(
            self.regula.currentData() or "",
            tuple(r for r, p in self.rynki.items() if p.isChecked()),
            self.sesja.konto.id,
            self.sesja.srodowisko.value,
        )
        try:
            sprawdz_przelicznik(u, self.sesja, "PLN", self._reguly)
        except BladAllegro as exc:
            self.status.setText(str(exc))
            return
        self.wynik = u
        self.accept()
