"""Kafelki Dashboardu według wzoru: pełna ikona, jasny gradient i biała typografia."""

from pathlib import Path
from typing import cast

from PySide6.QtCore import QPoint, QRectF, Qt
from PySide6.QtGui import (
    QColor,
    QFont,
    QFontMetrics,
    QIcon,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPaintEvent,
    QPen,
    QRadialGradient,
    QResizeEvent,
)
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout

from vexlab.gui.design_system import PALETA_KPI, ikona, ikona_menu
from vexlab.gui.premium import MONO


class LiczbaKPI(QLabel):
    """Duża liczba dopasowana do miejsca, bez obcinania wartości lub zmiany danych."""

    def _font(self) -> QFont:
        font = QFont(MONO)
        font.setWeight(QFont.Weight.Bold)
        size = 36
        font.setPixelSize(size)
        while size > 10 and QFontMetrics(font).horizontalAdvance(self.text()) > self.width():
            size -= 1
            font.setPixelSize(size)
        return font

    def _dopasuj_wysokosc(self) -> None:
        bounds = QFontMetrics(self._font()).tightBoundingRect(self.text() or "—")
        height = max(18, bounds.height() + 4)
        if self.height() != height or self.minimumHeight() != height:
            self.setFixedHeight(height)

    def setText(self, text: str) -> None:
        super().setText(text)
        self._dopasuj_wysokosc()

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        self._dopasuj_wysokosc()

    def paintEvent(self, event: QPaintEvent) -> None:
        painter = QPainter(self)
        font = self._font()
        bounds = QFontMetrics(font).tightBoundingRect(self.text())
        painter.setFont(font)
        painter.setPen(self.palette().color(self.palette().ColorRole.Text))
        painter.drawText(QPoint(-bounds.left(), 2 - bounds.top()), self.text())


class KafelekKPI(QFrame):
    def __init__(
        self,
        tytul: str,
        wariant: str,
        podpis: str,
        *,
        symbol: str | None = None,
        akcent: str | None = None,
    ) -> None:
        super().__init__()
        self.ikona_tla = QIcon()
        self.akcent = akcent
        self.wariant = wariant
        if symbol is not None and akcent is not None:
            self._kompaktowy(tytul, symbol, akcent, podpis)
            return
        self.setProperty("wariant_kpi", wariant)
        self.setFixedHeight(120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 18, 16, 16)
        layout.setSpacing(22)
        obraz = QLabel()
        obraz.setFixedSize(56, 56)
        obraz.setAccessibleName(f"Ikona: {tytul}")
        plik = Path(__file__).with_name("zasoby") / "kpi" / f"{wariant}.svg"
        pixmap = QIcon(str(plik)).pixmap(112, 112)
        pixmap.setDevicePixelRatio(2)
        obraz.setPixmap(pixmap)
        layout.addWidget(obraz, 0, Qt.AlignmentFlag.AlignTop)
        tekst = QVBoxLayout()
        tekst.setContentsMargins(0, 3, 0, 0)
        tekst.setSpacing(4)
        self.tytul = QLabel(tytul)
        self.tytul.setObjectName("kpiTytul")
        self.liczba = QLabel("—")
        self.liczba.setObjectName("kpiLiczba")
        self.liczba.setAccessibleDescription(f"Liczba: {tytul}")
        self.podpis = QLabel(podpis)
        self.podpis.setObjectName("kpiPodpis")
        for label in (self.tytul, self.liczba, self.podpis):
            label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            tekst.addWidget(label)
        layout.addLayout(tekst, 1)

    def _kompaktowy(self, tytul: str, symbol: str, kolor: str, podpis: str) -> None:
        self.setObjectName("metrykaDashboardu")
        self.setMinimumWidth(130)
        self.setFixedHeight(88)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(2)
        sciezki = {
            "Produkty": "produkt",
            "Nowe oferty": "koszyk",
            "Cenniki": "monety",
            "Raporty": "wykres",
            "Historia operacji": "blad",
        }
        self.ikona_tla = (
            ikona(sciezki[symbol], kolor) if symbol in sciezki else ikona_menu(symbol, True)
        )
        self.liczba = LiczbaKPI("—")
        self.liczba.setObjectName("liczbaDashboardu")
        self.liczba.setFixedHeight(30)
        self.liczba.setAccessibleDescription(f"Liczba: {tytul}")
        self.tytul = QLabel(tytul)
        self.tytul.setObjectName("podpisDashboardu")
        self.podpis = QLabel(podpis)
        self.podpis.setObjectName("podpisDashboardu")
        for label in (self.liczba, self.tytul, self.podpis):
            label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
            layout.addWidget(label)
        layout.addStretch(0)

    def _tlo_operacyjne(self) -> None:
        maluj_panel_operacyjny(self, cast(str, self.akcent))

    def paintEvent(self, event: QPaintEvent) -> None:
        if self.akcent is not None:
            self._tlo_operacyjne()
            painter = QPainter(self)
            painter.setOpacity(0.12)
            self.ikona_tla.paint(painter, self.width() - 80, 18, 64, 64)
            painter.end()
            return
        maluj_panel_dashboardu(self, self.wariant)


class PanelDashboardu(QFrame):
    """Panel formularza z tym samym tłem co kafelki Dashboardu."""

    def __init__(self, wariant: str) -> None:
        super().__init__()
        self.wariant = wariant
        self.setProperty("panel_dashboardu", True)


def maluj_panel_dashboardu(self: QFrame, wariant: str) -> None:
    gora, srodek, dol, poswiata, obrys = PALETA_KPI[wariant]
    painter = QPainter(self)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
    path = QPainterPath()
    path.addRoundedRect(rect, 12, 12)
    gradient = QLinearGradient(0, 0, self.width(), self.height())
    for stop, color in ((0.0, gora), (0.55, srodek), (1.0, dol)):
        gradient.setColorAt(stop, QColor(color))
    painter.fillPath(path, gradient)
    glow = QRadialGradient(self.width() * 0.18, self.height() * 0.05, self.width() * 0.85)
    kolor = QColor(poswiata)
    kolor.setAlpha(28)
    glow.setColorAt(0, kolor)
    kolor.setAlpha(0)
    glow.setColorAt(1, kolor)
    painter.fillPath(path, glow)
    painter.setBrush(Qt.BrushStyle.NoBrush)
    kolor_obrysu = QColor(obrys)
    kolor_obrysu.setAlpha(110)
    painter.setPen(QPen(kolor_obrysu, 1))
    painter.drawPath(path)


def maluj_panel_operacyjny(self: QFrame, akcent: str) -> None:
    ciemny = bool(cast(QApplication, QApplication.instance()).property("motyw_ciemny"))
    painter = QPainter(self)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    path = QPainterPath()
    path.addRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 9, 9)
    painter.fillPath(path, QColor("#121A2B" if ciemny else "#F6F9FE"))
    gradient = QRadialGradient(self.width() * 0.8, self.height(), self.width() * 0.7)
    kolor = QColor(akcent)
    kolor.setAlpha(18 if ciemny else 12)
    gradient.setColorAt(0, kolor)
    kolor.setAlpha(0)
    gradient.setColorAt(1, kolor)
    painter.fillPath(path, gradient)
