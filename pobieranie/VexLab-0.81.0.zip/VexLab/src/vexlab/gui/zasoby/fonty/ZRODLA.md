# Lokalne fonty VexLab

Źródło Google Fonts / OFL, pobrane 21.11.2026:
- https://github.com/google/fonts/tree/main/ofl/geist — Geist Project Authors / Vercel.
- https://github.com/google/fonts/tree/main/ofl/jetbrainsmono — JetBrains Mono Project Authors.

Licencje i informacje copyright zachowano w plikach OFL.txt w obu katalogach.
Statyczne pliki Regular 400, Medium 500, SemiBold 600 i Bold 700 wygenerowano
z plików Geist[wght].ttf oraz JetBrainsMono[wght].ttf, używając
fontTools.varLib.instancer 4.61.1. Instancjonowano wyłącznie oś wght i ustawiono
odpowiadające nazwy stylów oraz klasy wag. Geometria glifów odpowiada instancjom
źródłowych fontów. fontTools nie jest zależnością uruchomieniową aplikacji.

Fonty są rejestrowane lokalnie przez QFontDatabase; żadne dane ani żądania
nie trafiają do Google, Vercel lub JetBrains podczas działania programu.
