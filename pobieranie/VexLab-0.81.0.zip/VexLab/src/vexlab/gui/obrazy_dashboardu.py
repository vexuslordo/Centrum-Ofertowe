"""Miniatury kart z istniejącego czytnika i cache zamówień; wyłącznie RAM."""

from typing import TYPE_CHECKING, cast

from PySide6.QtCore import QObject, Qt, QTimer
from PySide6.QtGui import QIcon, QPixmap
from shiboken6 import isValid

from vexlab.rdzen.kontrakty import BladTechniczny

if TYPE_CHECKING:
    from vexlab.gui.dashboard import DashboardView
    from vexlab.gui.zamowienia_allegro import StronaZamowien


class ObrazyDashboardu(QObject):
    def __init__(self, view: "DashboardView", page: "StronaZamowien") -> None:
        super().__init__(view)
        self.view, self.page = view, page
        self.trwa = False
        self.timer = QTimer(self)
        self.timer.setInterval(500)
        self.timer.timeout.connect(self.pobierz)
        self.timer.start()

    def pobierz(self) -> None:
        v, p = self.view, self.page
        if (
            self.trwa
            or p.miniatury.trwa
            or not v.isVisible()
            or not v.lista_zamowien.isVisible()
            or p.raport is None
            or p.uc.obrazy is None
        ):
            return
        session, report = p.sesja(), p.raport
        if session is None:
            return
        model = v.lista_zamowien.dane
        visible = [
            model.szczegoly[r.numer]
            for i, r in enumerate(model.rows)
            if r.zrodlo == "Allegro"
            and r.numer in model.szczegoly
            and v.lista_zamowien.visualRect(model.index(i)).intersects(
                v.lista_zamowien.viewport().rect()
            )
        ]
        ids = tuple(
            dict.fromkeys(
                r.pozycje[0].oferta_id
                for r in visible
                if r.pozycje
                and r.pozycje[0].oferta_id
                and r.pozycje[0].oferta_id not in p.miniatury.cache
            )
        )[:4]
        if not ids:
            return
        self.trwa = True

        def read() -> dict[str, bytes]:
            result = {}
            for ident in ids:
                if p.sesja() is not session or p.raport is not report:
                    break
                try:
                    result[ident] = p.uc.miniatura(session, ident)
                except BladTechniczny:
                    result[ident] = b""
            return result

        def done(value: object) -> None:
            self.trwa = False
            if (
                not isValid(v)
                or not isValid(p)
                or p.sesja() is not session
                or p.raport is not report
            ):
                return
            rows = cast(dict[str, bytes], value)
            for ident in ids:
                data = rows.get(ident, b"")
                pix = QPixmap()
                icon = None
                if data and len(data) <= 512 * 1024 and pix.loadFromData(data):
                    icon = QIcon(
                        pix.scaled(
                            56,
                            56,
                            Qt.AspectRatioMode.KeepAspectRatio,
                            Qt.TransformationMode.SmoothTransformation,
                        )
                    )
                p.miniatury.cache[ident] = icon
                p.miniatury.cache.move_to_end(ident)
            while len(p.miniatury.cache) > 128:
                p.miniatury.cache.popitem(last=False)
            model.odswiez_obrazy()

        p.uruchom(read, done, lambda *_: done({}))
