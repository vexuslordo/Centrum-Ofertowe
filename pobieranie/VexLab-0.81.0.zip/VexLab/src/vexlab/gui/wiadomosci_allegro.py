"""Centrum wiadomości: odczyt stron, bez lokalnej kopii i operacji zapisu."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.kafelek_kpi import KafelekKPI
from vexlab.gui.prezentacja_wiadomosci import DelegatRozmow, WidokRozmowy, data_wiadomosci
from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.wiadomosci_allegro import (
    MAKS_OFFSET_WATKOW,
    MAKS_OFFSET_WIADOMOSCI,
    ROZMIAR_STRONY,
    OdczytajWiadomosciAllegro,
    StronaWatkow,
    StronaWiadomosci,
    WatekAllegro,
)


class PanelWiadomosci(QWidget):
    konto_zmienione = Signal()

    def __init__(
        self,
        uc: OdczytajWiadomosciAllegro,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
        login: str,
        parent: QWidget | None = None,
        *,
        pobierz_od_razu: bool = True,
    ) -> None:
        super().__init__(parent)
        self.uc, self.uruchom, self.sesja = uc, uruchom, sesja
        self._sesja = sesja()
        self._zamkniete = False
        self._nr = 0
        self._watek_nr = 0
        self._trwa = False
        self._watki: StronaWatkow | None = None
        self._wiadomosci: StronaWiadomosci | None = None
        self._wybrany = ""
        self._watki_offset = 0
        self._wiadomosci_offset = 0
        self.setWindowTitle("Wiadomości Allegro · odczyt")
        box = QVBoxLayout(self)
        box.setContentsMargins(20, 20, 20, 20)
        box.setSpacing(12)
        naglowek = QLabel("Wiadomości")
        naglowek.setStyleSheet("font-size:22px;font-weight:600;background:transparent;")
        box.addWidget(naglowek)
        self.opis = QLabel(
            "Rozmowy konta Allegro. Filtr loginu dotyczy bieżącej strony; "
            "rozmowa może dotyczyć wielu zamówień."
        )
        self.opis.setWordWrap(True)
        box.addWidget(self.opis)
        kpi_row = QHBoxLayout()
        kpi_row.setSpacing(10)
        self.kpi: dict[str, KafelekKPI] = {}
        for key, title, symbol, color, caption in (
            (
                "rozmowy",
                "Rozmowy na stronie",
                "Aktywne oferty",
                "#3B82F6",
                "Bieżąca strona skrzynki",
            ),
            (
                "nieprzeczytane",
                "Nieprzeczytane na stronie",
                "Nowe oferty",
                "#06B6D4",
                "Status odczytany z Allegro",
            ),
            ("wiadomosci", "Wiadomości na stronie", "Szkice", "#10B981", "Bieżąca strona rozmowy"),
        ):
            card = KafelekKPI(title, "produkty", caption, symbol=symbol, akcent=color)
            card.ikona_tla = ikona("plik" if key == "wiadomosci" else "poczta", color)
            card.setMinimumWidth(0)
            self.kpi[key] = card
            kpi_row.addWidget(card, 1)
        box.addLayout(kpi_row)
        toolbar = QHBoxLayout()
        self.filtr = QLineEdit(login)
        self.filtr.setClearButtonEnabled(True)
        self.filtr.setPlaceholderText("Filtr loginu na bieżącej stronie")
        self.filtr.setAccessibleName("Filtr loginu rozmówcy na bieżącej stronie")
        toolbar.addWidget(self.filtr, 1)
        self.odswiez = QPushButton("Odśwież rozmowy")
        self.odswiez.setIcon(ikona("synchronizacja", "#60A5FA"))
        toolbar.addWidget(self.odswiez)
        box.addLayout(toolbar)
        split = QSplitter()
        left = QWidget()
        lb = QVBoxLayout(left)
        lb.setContentsMargins(0, 0, 0, 0)
        self.strona_rozmow = QLabel("Skrzynka rozmów")
        self.strona_rozmow.setStyleSheet("font-weight:600;background:transparent;")
        lb.addWidget(self.strona_rozmow)
        self.lista = QListWidget()
        self.lista.setItemDelegate(DelegatRozmow(self.lista))
        self.lista.setMouseTracking(True)
        self.pusto = QLabel("Odśwież skrzynkę, aby pobrać rozmowy.")
        self.pusto.setWordWrap(True)
        self.lista.setAccessibleName("Rozmowy Allegro")
        lb.addWidget(self.lista, 1)
        lb.addWidget(self.pusto)
        nav = QHBoxLayout()
        self.poprzednie = QPushButton("← Rozmowy")
        self.nastepne = QPushButton("Rozmowy →")
        nav.addWidget(self.poprzednie)
        nav.addWidget(self.nastepne)
        lb.addLayout(nav)
        split.addWidget(left)
        right = QWidget()
        rb = QVBoxLayout(right)
        rb.setContentsMargins(0, 0, 0, 0)
        self.tytul = QLabel("Wybierz rozmowę")
        self.tytul.setStyleSheet("font-weight:600;background:transparent;")
        self.tytul.setWordWrap(True)
        self.tytul.setTextFormat(Qt.TextFormat.PlainText)
        header = QHBoxLayout()
        header.addWidget(self.tytul, 1)
        self.odswiez_rozmowe = QPushButton("Odśwież rozmowę")
        self.strona_rozmow.setFixedHeight(self.odswiez_rozmowe.sizeHint().height())
        header.addWidget(self.odswiez_rozmowe)
        rb.addLayout(header)
        self.tresc = WidokRozmowy()
        self.tresc.setReadOnly(True)
        self.tresc.setUndoRedoEnabled(False)
        self.tresc.setAccessibleName("Treść rozmowy Allegro")
        rb.addWidget(self.tresc, 1)
        messages_nav = QHBoxLayout()
        self.nowsze = QPushButton("← Nowsze wiadomości")
        self.starsze = QPushButton("Starsze wiadomości →")
        messages_nav.addWidget(self.nowsze)
        messages_nav.addWidget(self.starsze)
        rb.addLayout(messages_nav)
        split.addWidget(right)
        split.setSizes([300, 660])
        box.addWidget(split, 1)
        self.stan = QLabel("Nie pobrano rozmów.")
        self.stan.setWordWrap(True)
        self.stan.setTextFormat(Qt.TextFormat.PlainText)
        box.addWidget(self.stan)
        bottom = QHBoxLayout()
        bottom.addWidget(QLabel("Odczyt nie oznacza wiadomości jako przeczytanych na Allegro."), 1)
        box.addLayout(bottom)
        self.filtr.textChanged.connect(self._pokaz_watki)
        self.lista.currentItemChanged.connect(self._wybierz)
        self.odswiez.clicked.connect(lambda: self.pobierz_watki(self._offset_watkow()))
        self.odswiez_rozmowe.clicked.connect(
            lambda: self.pobierz_wiadomosci(self._offset_wiadomosci())
        )
        self.poprzednie.clicked.connect(
            lambda: self.pobierz_watki(max(0, self._offset_watkow() - ROZMIAR_STRONY))
        )
        self.nastepne.clicked.connect(
            lambda: self.pobierz_watki(self._offset_watkow() + ROZMIAR_STRONY)
        )
        self.nowsze.clicked.connect(
            lambda: self.pobierz_wiadomosci(max(0, self._offset_wiadomosci() - ROZMIAR_STRONY))
        )
        self.starsze.clicked.connect(
            lambda: self.pobierz_wiadomosci(self._offset_wiadomosci() + ROZMIAR_STRONY)
        )
        self.timer = QTimer(self)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self._sprawdz_konto)
        self.timer.start()
        self._przyciski()
        if pobierz_od_razu:
            self.aktywuj()

    def _offset_watkow(self) -> int:
        return self._watki_offset

    def _offset_wiadomosci(self) -> int:
        return self._wiadomosci_offset

    def _aktualne(self) -> bool:
        return not self._zamkniete and self._sesja is not None and self.sesja() is self._sesja

    def _sprawdz_konto(self) -> None:
        if not self._zamkniete:
            self.polaczenie()

    def polaczenie(self) -> None:
        session = self.sesja()
        if session is self._sesja:
            return
        self._wyczysc()
        self._sesja = session
        self._zamkniete = False
        self._trwa = False
        self._watki_offset = self._wiadomosci_offset = 0
        self.timer.start()
        self._przyciski()
        self.stan.setText("Zmieniono połączenie. Odśwież rozmowy aktualnego konta.")
        self.konto_zmienione.emit()

    def aktywuj(self) -> None:
        self.polaczenie()
        session = self._sesja
        if session is None:
            self.stan.setText("Połącz konto w Integracje → Allegro, aby odczytać wiadomości.")
        elif session.aplikacja is None or not session.aplikacja.odczyt_wiadomosci:
            self.stan.setText(
                "W Integracje → Allegro włącz Odczyt wiadomości i zatwierdź uprawnienia."
            )
        elif self._watki is None and not self._trwa:
            self.pobierz_watki(0)

    def _wyczysc(self) -> None:
        self._zamkniete = True
        self.timer.stop()
        self._nr += 1
        self._watek_nr += 1
        self._watki = None
        self._wiadomosci = None
        self._sesja = None
        self._wybrany = ""
        self.lista.clear()
        self.tresc.clear()
        self.filtr.clear()
        self.tytul.clear()
        self.stan.clear()
        self._metryki()

    def _metryki(self) -> None:
        rows = self._watki.pozycje if self._watki else None
        self.kpi["rozmowy"].liczba.setText(str(len(rows)) if rows is not None else "—")
        self.kpi["nieprzeczytane"].liczba.setText(
            str(sum(not r.przeczytany for r in rows)) if rows is not None else "—"
        )
        self.kpi["wiadomosci"].liczba.setText(
            str(len(self._wiadomosci.pozycje)) if self._wiadomosci is not None else "—"
        )
        self.strona_rozmow.setText(
            f"Skrzynka rozmów · strona {self._offset_watkow() // ROZMIAR_STRONY + 1}"
        )
        self.pusto.setVisible(self.lista.count() == 0)
        if self._watki is not None:
            self.pusto.setText(
                "Brak rozmów dla tego filtra na bieżącej stronie."
                if self.filtr.text().strip()
                else "Brak rozmów na tej stronie."
            )
        else:
            self.pusto.setText(
                "Pobieranie rozmów…" if self._trwa else "Odśwież skrzynkę, aby pobrać rozmowy."
            )

    def _przyciski(self) -> None:
        self._metryki()
        ready = not self._trwa and self._aktualne()
        self.odswiez.setEnabled(ready)
        self.odswiez_rozmowe.setEnabled(ready and bool(self._wybrany))
        self.poprzednie.setEnabled(ready and self._offset_watkow() > 0)
        self.nastepne.setEnabled(
            ready
            and self._watki is not None
            and len(self._watki.pozycje) == ROZMIAR_STRONY
            and self._offset_watkow() < MAKS_OFFSET_WATKOW
        )
        self.nowsze.setEnabled(ready and self._offset_wiadomosci() > 0)
        self.starsze.setEnabled(
            ready
            and self._wiadomosci is not None
            and len(self._wiadomosci.pozycje) == ROZMIAR_STRONY
            and self._offset_wiadomosci() < MAKS_OFFSET_WIADOMOSCI
        )

    def pobierz_watki(self, offset: int) -> None:
        s = self._sesja
        if not self._aktualne() or self._trwa or s is None:
            return
        self._watki_offset = offset
        self._nr += 1
        nr = self._nr
        self._watek_nr += 1
        self._trwa = True
        self._watki = None
        self._wiadomosci = None
        self._wybrany = ""
        self.lista.clear()
        self.tresc.clear()
        self.tytul.setText("Wybierz rozmowę")
        self.stan.setText("Pobieranie strony rozmów…")
        self._przyciski()

        def gotowe(value: object) -> None:
            if not self._aktualne() or nr != self._nr:
                return
            self._trwa = False
            self._watki = cast(StronaWatkow, value)
            self._pokaz_watki()
            self._przyciski()

        def blad(kod: str, komunikat: str) -> None:
            if not self._aktualne() or nr != self._nr:
                return
            self._trwa = False
            self.stan.setText(komunikat)
            self._przyciski()

        self.uruchom(lambda: self.uc.watki(s, offset), gotowe, blad)

    def _pokaz_watki(self) -> None:
        if self._zamkniete:
            return
        self._watek_nr += 1
        self._trwa = False if self._watki is not None else self._trwa
        self._wiadomosci = None
        self._wybrany = ""
        self.lista.clear()
        self.tresc.clear()
        self.tytul.setText("Wybierz rozmowę")
        if self._watki is not None:
            fraza = self.filtr.text().strip().casefold()
            for row in self._watki.pozycje:
                if fraza and fraza not in row.login.casefold():
                    continue
                label = ("● " if not row.przeczytany else "") + (
                    row.login or "Rozmówca niedostępny"
                )
                item = QListWidgetItem(label + "\n" + data_wiadomosci(row.ostatnia))
                item.setToolTip(label + " · " + data_wiadomosci(row.ostatnia))
                item.setData(Qt.ItemDataRole.UserRole, row)
                self.lista.addItem(item)
            self.stan.setText(
                f"Strona rozmów {self._offset_watkow() // ROZMIAR_STRONY + 1} · "
                f"widoczne: {self.lista.count()} z {len(self._watki.pozycje)}. "
                "Filtr dotyczy tylko tej strony."
            )
        self._przyciski()

    def _wybierz(self) -> None:
        item = self.lista.currentItem()
        row = item.data(Qt.ItemDataRole.UserRole) if item else None
        self._watek_nr += 1
        self._wiadomosci = None
        self._wybrany = row.id if isinstance(row, WatekAllegro) else ""
        self.tresc.clear()
        if isinstance(row, WatekAllegro):
            self._wiadomosci_offset = 0
            self.tytul.setText("Rozmowa · " + (row.login or "Rozmówca niedostępny"))
            # Zmiana wyboru unieważnia poprzedni odczyt, ale nie blokuje nowego.
            self._trwa = False
            self.pobierz_wiadomosci(0)
        self._przyciski()

    def pobierz_wiadomosci(self, offset: int) -> None:
        s, ident = self._sesja, self._wybrany
        if not self._aktualne() or self._trwa or s is None or not ident:
            return
        self._wiadomosci_offset = offset
        self._watek_nr += 1
        nr = self._watek_nr
        self._trwa = True
        self._wiadomosci = None
        self.tresc.clear()
        self.stan.setText("Pobieranie strony wiadomości…")
        self._przyciski()

        def gotowe(value: object) -> None:
            if not self._aktualne() or nr != self._watek_nr or ident != self._wybrany:
                return
            self._trwa = False
            page = cast(StronaWiadomosci, value)
            self._wiadomosci = page
            self.tresc.ustaw(page.pozycje)
            self.stan.setText(
                f"Strona wiadomości {offset // ROZMIAR_STRONY + 1} · "
                f"{len(page.pozycje)} wiadomości, od najnowszych."
                if page.pozycje
                else "Brak wiadomości na tej stronie."
            )
            self._przyciski()

        def blad(kod: str, komunikat: str) -> None:
            if not self._aktualne() or nr != self._watek_nr or ident != self._wybrany:
                return
            self._trwa = False
            self.stan.setText(komunikat)
            self._przyciski()

        self.uruchom(lambda: self.uc.wiadomosci(s, ident, offset), gotowe, blad)


class OknoWiadomosci(QDialog):
    """Ten sam panel w oknie otwieranym ze szczegółów zamówienia."""

    def __init__(
        self,
        uc: OdczytajWiadomosciAllegro,
        uruchom: Uruchom,
        sesja: Callable[[], SesjaAllegro | None],
        login: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Wiadomości Allegro · odczyt")
        self.resize(1000, 660)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.panel = PanelWiadomosci(uc, uruchom, sesja, login, self)
        layout.addWidget(self.panel)
        zamknij = QPushButton("Zamknij")
        layout.addWidget(zamknij, 0, Qt.AlignmentFlag.AlignRight)
        zamknij.clicked.connect(self.reject)
        self.panel.konto_zmienione.connect(self.reject)
        self.finished.connect(self.panel._wyczysc)
