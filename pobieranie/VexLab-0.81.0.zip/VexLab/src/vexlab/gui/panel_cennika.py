"""Szczegóły pozycji i branding źródła. Bez obliczeń cen i operacji biznesowych."""

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QLabel,
    QMenu,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.branding_cennikow import BrandingCennikow
from vexlab.gui.premium import obraz_inspektora
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.cenniki import CennikDTO, PozycjaCennika
from vexlab.przypadki_uzycia.ceny_cennika import etykieta_cennika


class PanelCennika(QFrame):
    logo_zadane = Signal()
    historia_zadana = Signal()
    roznice_zadane = Signal()
    producent_zadany = Signal()

    def __init__(self, branding: BrandingCennikow, dodaj: QPushButton) -> None:
        super().__init__()
        self.branding = branding
        self.dodaj = dodaj
        self.setObjectName("szczegolyCennika")
        self.setMinimumWidth(0)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)
        title = etykieta("Szczegóły produktu")
        title.setObjectName("tytulCennika")
        layout.addWidget(title)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.viewport().setAutoFillBackground(False)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        body = QWidget()
        body.setObjectName("trescSzczegolowCennika")
        box = QVBoxLayout(body)
        box.setContentsMargins(0, 8, 0, 8)
        box.setSpacing(6)
        self.pusty = QFrame()
        self.pusty.setObjectName("pustyPanelCennika")
        empty = QVBoxLayout(self.pusty)
        empty.setContentsMargins(16, 22, 16, 22)
        empty.setSpacing(10)
        self.pusty_tytul = etykieta("Wybierz cennik")
        self.pusty_tytul.setObjectName("tytulCennika")
        self.pusty_opis = etykieta("Wybierz cennik po lewej, aby wyświetlić produkty.")
        self.pusty_opis.setObjectName("opis")
        empty.addWidget(self.pusty_tytul)
        empty.addWidget(self.pusty_opis)
        box.addWidget(self.pusty)
        self.logo = QLabel("—")
        self.logo.setFixedHeight(160)
        self.logo.setStyleSheet("font-size:28px;font-weight:600;")
        self.logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo.setAccessibleName("Logo producenta cennika")
        box.addWidget(self.logo)
        self.producent = etykieta("Wybierz cennik")
        self.producent.setObjectName("tytulCennika")
        box.addWidget(self.producent)
        self.wydanie = etykieta("")
        self.wydanie.setObjectName("opis")
        box.addWidget(self.wydanie)
        logo_button = QPushButton("Ustaw logo producenta…")
        logo_button.clicked.connect(self.logo_zadane)
        logo_button.setToolTip("Własny plik PNG, JPG lub WebP. Bez pobierania z internetu.")
        self.logo_przycisk = logo_button
        box.addWidget(logo_button)
        self.pola: dict[str, QLabel] = {}
        name = etykieta("Wybierz pozycję z listy")
        name.setObjectName("tytulCennika")
        self.pola["Produkt"] = name
        box.insertWidget(box.indexOf(self.logo) + 1, name)
        self.opis = etykieta("")
        self.opis.setObjectName("opis")
        box.insertWidget(box.indexOf(name) + 1, self.opis)
        self.dane_host = QFrame()
        self.dane_host.setObjectName("daneCennika")
        grid = QGridLayout(self.dane_host)
        grid.setContentsMargins(10, 12, 10, 12)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(8)
        grid.setColumnStretch(1, 1)
        for i, key in enumerate(
            (
                "SKU",
                "EAN",
                "Producent",
                "Cena brutto",
                "Cena netto",
                "VAT",
                "Status",
                "Zmiana ceny",
            )
        ):
            caption = etykieta(key)
            caption.setObjectName("opis")
            value = etykieta("—")
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            value.setAccessibleName(key)
            self.pola[key] = value
            grid.addWidget(caption, i, 0)
            grid.addWidget(value, i, 1)
        box.addWidget(self.dane_host)
        self.sekcje_dodatkowe: dict[str, QFrame] = {}
        for key in ("Cena bazowa", "Dane dodatkowe", "Źródło"):
            frame = QFrame()
            frame.setObjectName("poleCennika")
            column = QVBoxLayout(frame)
            column.setContentsMargins(0, 8, 0, 6)
            caption = etykieta(key)
            caption.setObjectName("tytulCennika")
            column.addWidget(caption)
            value = etykieta("—")
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            value.setAccessibleName(key)
            column.addWidget(value)
            self.pola[key] = value
            box.addWidget(frame)
            self.sekcje_dodatkowe[key] = frame
        box.addStretch()
        scroll.setWidget(body)
        body.setAutoFillBackground(False)
        scroll.viewport().setAutoFillBackground(False)
        layout.addWidget(scroll, 1)
        dodaj.setFixedHeight(36)
        dodaj.setObjectName("primary")
        layout.addWidget(dodaj)
        self.historia = QPushButton("Historia wydań")
        self.historia.setFixedHeight(34)
        self.historia.clicked.connect(self.historia_zadana)
        layout.addWidget(self.historia)
        self.otworz = QPushButton("Otwórz stronę producenta")
        self.otworz.setFixedHeight(34)
        self.otworz.clicked.connect(self.producent_zadany)
        layout.addWidget(self.otworz)
        self.roznice = QPushButton("Pokaż różnice", self)
        self.roznice.clicked.connect(self.roznice_zadane)
        self.roznice.hide()
        more = QToolButton()
        self.wiecej = more
        more.setText("Więcej akcji")
        more.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        more.setFixedHeight(32)
        more.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        menu = QMenu(more)
        menu.addAction("Pokaż różnice", self.roznice.click)
        menu.addAction("Ustaw logo producenta…", logo_button.click)
        more.setMenu(menu)
        layout.addWidget(more)
        logo_button.hide()
        self.ustaw(None, None)

    def ustaw(self, cennik: CennikDTO | None, row: PozycjaCennika | None) -> None:
        for label in self.pola.values():
            label.setText("—")
        self.opis.clear()
        self.opis.hide()
        self.logo.clear()
        self.logo.setText("—")
        self.producent.setText(cennik.producent or "Bez producenta" if cennik else "Wybierz cennik")
        self.wydanie.setText(f"{cennik.nazwa} · {cennik.rok}\n{cennik.status}" if cennik else "")
        self.logo_przycisk.setEnabled(cennik is not None)
        self.historia.setEnabled(cennik is not None)
        self.roznice.setEnabled(cennik is not None)
        self.otworz.setEnabled(cennik is not None and cennik.producent_id is not None)
        self.pusty.setVisible(row is None)
        self.pusty_tytul.setText("Wybierz produkt" if cennik else "Wybierz cennik")
        self.pusty_opis.setText(
            "Zaznacz pozycję w tabeli, aby zobaczyć jej cenę i szczegóły."
            if cennik
            else "Wybierz cennik po lewej, aby wyświetlić produkty."
        )
        self.logo.setVisible(row is not None)
        self.pola["Produkt"].setVisible(row is not None)
        self.dane_host.setVisible(row is not None)
        self.producent.hide()
        self.wydanie.hide()
        self.dodaj.setVisible(row is not None)
        for button in (self.historia, self.otworz, self.wiecej):
            button.setVisible(cennik is not None)
        for frame in self.sekcje_dodatkowe.values():
            frame.setVisible(row is not None)
        if cennik:
            self.pola["Producent"].setText(cennik.producent or "—")
            icon = self.branding.logo(cennik)
            if not icon.isNull():
                self.logo.setFixedHeight(160)
                self.logo.setPixmap(obraz_inspektora(icon.pixmap(235, 145), 235, 145))
            else:
                self.logo.setFixedHeight(56)
                self.logo.setText((cennik.producent or cennik.nazwa)[:2].upper())
            self.pola["Źródło"].setText(f"{cennik.nazwa}\n{cennik.zrodlo}\n{cennik.wczytano_utc}")
        if row is None:
            self.pola["Produkt"].setText("Wybierz pozycję z listy")
            return
        data = row.pozycja.dane
        self.opis.setText(data.opis.splitlines()[0][:180] if data.opis else "")
        self.opis.setToolTip(data.opis)
        self.opis.setVisible(bool(data.opis))
        for key, value in (
            ("Produkt", data.nazwa),
            ("SKU", data.sku),
            ("EAN", data.ean or "—"),
            ("Status", row.stan),
            ("Zmiana ceny", row.roznica),
        ):
            self.pola[key].setText(value)
        price = row.pozycja.cena
        if price and price.tekst:
            formatted = etykieta_cennika(price.tekst, price.waluta, price.rodzaj)
            lines = formatted.splitlines()
            if len(lines) == 2 and lines[0].startswith("Brutto:"):
                self.pola["Cena brutto"].setText(lines[0].removeprefix("Brutto: "))
                self.pola["Cena netto"].setText(
                    lines[1].removeprefix("Netto: ").replace(" (VAT 23%)", "")
                )
                self.pola["VAT"].setText("23%")
            else:
                self.pola["Cena brutto"].setText(formatted)
        if row.cena_bazowa:
            self.pola["Cena bazowa"].setText(
                row.cena_bazowa.etykieta
                + " · "
                + row.cena_bazowa.rodzaj
                + "\n"
                + row.cena_bazowa.zrodlo
            )
        extra = [
            f"Wiersz źródłowy: {row.pozycja.wiersz}",
            row.problem,
            row.porownanie,
            data.opis,
            *(f"{f.nazwa}: {f.wartosc}" for f in row.pozycja.pola_cennika),
        ]
        self.pola["Dane dodatkowe"].setText("\n".join(filter(None, extra)))
        self.sekcje_dodatkowe["Cena bazowa"].setVisible(row.cena_bazowa is not None)
