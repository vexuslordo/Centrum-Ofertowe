"""Osobne okno potwierdzanej publikacji rzeczywistych szkiców Allegro."""

from collections import Counter
from collections.abc import Callable
from threading import Event
from typing import cast

from PySide6.QtCore import QTimer, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QHBoxLayout,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.publikacja_allegro import (
    PlanPublikacji,
    PublikujSzkiceAllegro,
    WynikPublikacji,
)


class PublikacjaAllegro(QDialog):
    postep = Signal(int, int)

    def __init__(
        self,
        parent: QWidget,
        serwis: PublikujSzkiceAllegro,
        sesja: SesjaAllegro,
        ids: tuple[str, ...],
        uruchom: Uruchom,
        aktualne: Callable[[], bool],
    ) -> None:
        super().__init__(parent)
        self.serwis, self.sesja, self.ids = serwis, sesja, ids
        self.uruchom, self.aktualne = uruchom, aktualne
        self.plan: PlanPublikacji | None = None
        self.trwa = False
        self._zamkniete = False
        self.finished.connect(lambda _: setattr(self, "_zamkniete", True))
        self.stop = Event()
        self.setWindowTitle("Opublikuj szkice Allegro")
        rect = self.screen().availableGeometry()
        self.setMinimumSize(min(760, rect.width() - 40), min(480, rect.height() - 60))
        self.resize(min(1100, rect.width() - 40), min(700, rect.height() - 60))
        layout = QVBoxLayout(self)
        title = etykieta("Opublikuj szkice Allegro")
        title.setObjectName("tytulStronyAllegro")
        layout.addWidget(title)
        layout.addWidget(
            etykieta(f"Konto: {sesja.konto.login} • {sesja.srodowisko.value} • Wybrano: {len(ids)}")
        )
        layout.addWidget(
            etykieta(
                "Publikacja uruchamia sprzedaż. Sprawdź oferty i potwierdź ją osobnym przyciskiem."
            )
        )
        self.tabela = QTableWidget(0, 6)
        self.tabela.setHorizontalHeaderLabels(
            ("ID Allegro", "Tytuł", "Cena", "Ilość", "Stan / wynik", "Informacja")
        )
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setColumnWidth(1, 310)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.tabela, 1)
        self.pasek = QProgressBar()
        layout.addWidget(self.pasek)
        self.info = etykieta("Sprawdź aktualne dane przed publikacją.")
        layout.addWidget(self.info)
        row = QHBoxLayout()
        self.sprawdz = QPushButton("Sprawdź szkice")
        self.publikuj = QPushButton("Opublikuj…")
        self.publikuj.setObjectName("primary")
        self.publikuj.setEnabled(False)
        self.wynik = QPushButton("Sprawdź wynik")
        self.wynik.setEnabled(False)
        self.zamknij = QPushButton("Zamknij")
        for b in (self.sprawdz, self.publikuj, self.wynik, self.zamknij):
            row.addWidget(b)
        layout.addLayout(row)
        self.sprawdz.clicked.connect(self.przygotuj)
        self.publikuj.clicked.connect(self.potwierdz)
        self.wynik.clicked.connect(lambda: self.wykonaj(True))
        self.zamknij.clicked.connect(self.reject)
        self.postep.connect(self._postep)
        QTimer.singleShot(0, self.przygotuj)

    def _postep(self, i: int, n: int) -> None:
        if self.trwa:
            self.pasek.setRange(0, max(n, 1))
            self.pasek.setValue(i)
            self.pasek.setFormat(f"{i} z {n} · %p%")

    def _zadanie(self, fn: Callable[[], object], ok: Callable[[object], None]) -> None:
        if self._zamkniete or self.trwa or not self.aktualne():
            self.info.setText("Konto zmieniło się. Otwórz okno ponownie.")
            return
        self.trwa = True
        self.stop.clear()
        self.pasek.setRange(0, 0)
        for b in (self.sprawdz, self.publikuj, self.wynik):
            b.setEnabled(False)
        self.zamknij.setText("Zatrzymaj")

        def end() -> None:
            self.trwa = False
            self.pasek.setRange(0, 100)
            self.pasek.setValue(100)
            self.zamknij.setText("Zamknij")
            self.sprawdz.setEnabled(self.aktualne())
            self.wynik.setEnabled(self.plan is not None and self.aktualne())

        def success(w: object) -> None:
            end()
            if self.aktualne():
                ok(w)
            else:
                self.info.setText(
                    "Konto zmieniło się. Wysłana komenda pozostaje w rejestrze; "
                    "sprawdź ją na właściwym koncie."
                )

        def error(k: str, text: str) -> None:
            end()
            self.info.setText(text)
            self.pasek.setFormat("Przerwano")

        self.uruchom(fn, success, error)

    def _stop(self) -> bool:
        return self.stop.is_set() or not self.aktualne()

    def przygotuj(self) -> None:
        if self.trwa or self._zamkniete:
            return
        self.plan = None

        def ok(w: object) -> None:
            self.plan = cast(PlanPublikacji, w)
            self.tabela.setRowCount(len(self.plan.oferty))
            for i, p in enumerate(self.plan.oferty):
                for j, text in enumerate(
                    (
                        p.ident,
                        p.tytul,
                        f"{p.cena.replace('.', ',')} {p.waluta}",
                        str(p.ilosc),
                        {
                            "INACTIVE": "Szkic",
                            "ACTIVE": "Aktywna",
                            "ACTIVATING": "Aktywowanie",
                            "ENDED": "Zakończona",
                        }.get(p.status, p.status),
                        p.blad,
                    )
                ):
                    self.tabela.setItem(i, j, QTableWidgetItem(text))
            count = sum(p.status == "INACTIVE" and not p.blad for p in self.plan.oferty)
            self.info.setText(
                f"Do publikacji: {count}. Sprzedaż uruchomi dopiero przycisk Opublikuj."
            )
            self.publikuj.setEnabled(count > 0)
            self.wynik.setEnabled(True)

        self._zadanie(
            lambda: self.serwis.przygotuj(self.sesja, self.ids, self._stop, self.postep.emit), ok
        )

    def potwierdz(self) -> None:
        if self.plan is None or self.trwa or not self.aktualne():
            return
        count = sum(p.status == "INACTIVE" and not p.blad for p in self.plan.oferty)
        if count == 0:
            return
        answer = QMessageBox.question(
            self,
            "Uruchomić sprzedaż?",
            f"Opublikować {count} szkiców i uruchomić sprzedaż na koncie "
            f"{self.sesja.konto.login} ({self.sesja.srodowisko.value})?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.wykonaj(False)

    def wykonaj(self, tylko_odczyt: bool) -> None:
        plan = self.plan
        if plan is None:
            return

        def ok(w: object) -> None:
            results = cast(tuple[WynikPublikacji, ...], w)
            for i, r in enumerate(results):
                self.tabela.setItem(i, 4, QTableWidgetItem(r.stan))
                self.tabela.setItem(i, 5, QTableWidgetItem(r.opis))
                cast(QTableWidgetItem, self.tabela.item(i, 5)).setToolTip(r.opis)
            counts = Counter(r.stan for r in results)
            self.info.setText(
                f"Opublikowano: {counts['Opublikowano']} · "
                f"Do sprawdzenia: {counts['Do sprawdzenia']} · Błędy: {counts['Błąd']} · "
                f"Już aktywne: {counts['Już aktywna']} · "
                f"Pominięte / niewysłane: {counts['Pominięto'] + counts['Niewysłane']}"
            )
            self.wynik.setEnabled(True)

        self._zadanie(
            lambda: self.serwis.wykonaj(
                self.sesja, plan, self._stop, self.postep.emit, tylko_odczyt
            ),
            ok,
        )

    def reject(self) -> None:
        if self.trwa:
            self.stop.set()
            self.info.setText(
                "Zatrzymywanie. Wysłanej komendy nie można cofnąć; wynik będzie można sprawdzić."
            )
            return
        super().reject()
