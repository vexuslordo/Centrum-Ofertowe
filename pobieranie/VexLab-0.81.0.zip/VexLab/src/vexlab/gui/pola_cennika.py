"""Nazwane przez użytkownika pola dokumentu cennika i wybór kolumn źródła."""

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.przypadki_uzycia.importowanie import MapowaniePolaCennika


class PolaCennika(QGroupBox):
    zmieniono = Signal()

    def __init__(self) -> None:
        super().__init__("Własne pola cennika")
        self.kolumny: tuple[str, ...] = ()
        self.wiersze: list[tuple[QLineEdit, QComboBox, QWidget]] = []
        self.uklad = QVBoxLayout(self)
        opis = QLabel(
            "Dodaj własne nazwy pól i wybierz kolumny z pliku. "
            "Zapisz je przez Profil → Zapamiętaj układ…"
        )
        opis.setWordWrap(True)
        self.uklad.addWidget(opis)
        self.dodaj = QPushButton("+ Dodaj pole")
        self.dodaj.clicked.connect(lambda: self._dodaj())
        self.uklad.addWidget(self.dodaj)

    def _dodaj(self, nazwa: str = "", indeks: int | None = None) -> None:
        if len(self.wiersze) >= 20:
            return
        widget = QWidget()
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        label = QLineEdit(nazwa)
        label.setPlaceholderText("Nazwa własnego pola")
        label.setAccessibleName("Nazwa własnego pola cennika")
        label.setMaxLength(80)
        kolumna = QComboBox()
        kolumna.setAccessibleName("Kolumna własnego pola cennika")
        self._wypelnij(kolumna)
        kolumna.setCurrentIndex(kolumna.findData(indeks))
        usun = QPushButton("Usuń pole")
        row.addWidget(label, 1)
        row.addWidget(kolumna, 2)
        row.addWidget(usun)
        self.uklad.insertWidget(self.uklad.count() - 1, widget)
        self.wiersze.append((label, kolumna, widget))
        label.textChanged.connect(self.zmieniono)
        kolumna.currentIndexChanged.connect(self.zmieniono)
        usun.clicked.connect(lambda: self._usun(widget))
        self.dodaj.setEnabled(len(self.wiersze) < 20)
        self.zmieniono.emit()

    def _usun(self, widget: QWidget) -> None:
        self.wiersze = [r for r in self.wiersze if r[2] is not widget]
        widget.setParent(None)
        widget.deleteLater()
        self.dodaj.setEnabled(True)
        self.zmieniono.emit()

    def _wypelnij(self, box: QComboBox) -> None:
        box.blockSignals(True)
        box.clear()
        box.addItem("Wybierz kolumnę", None)
        for i, nazwa in enumerate(self.kolumny):
            box.addItem(f"Kolumna {i + 1}: {nazwa or 'bez nagłówka'}", i)
        box.blockSignals(False)

    def ustaw_kolumny(self, nazwy: tuple[str, ...]) -> None:
        self.kolumny = nazwy
        for _, box, _ in self.wiersze:
            self._wypelnij(box)

    def ustaw(self, pola: tuple[MapowaniePolaCennika, ...]) -> None:
        for _, _, widget in tuple(self.wiersze):
            self._usun(widget)
        for p in pola:
            self._dodaj(p.nazwa, p.kolumna)

    def mapowanie(self) -> tuple[MapowaniePolaCennika, ...]:
        # Walidacja nazw i indeksów należy do przypadku użycia.
        return tuple(
            MapowaniePolaCennika(
                label.text().strip(), box.currentData() if box.currentData() is not None else -1
            )
            for label, box, _ in self.wiersze
        )
