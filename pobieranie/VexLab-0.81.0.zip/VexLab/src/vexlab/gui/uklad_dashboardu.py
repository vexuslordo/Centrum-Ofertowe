"""Lokalny dokument układu UI; bez danych sprzedaży i zależności od ViewModeli."""

import json
from dataclasses import dataclass, replace
from typing import TypedDict, Unpack

from PySide6.QtCore import QSettings

ROZMIARY = {
    "1×1": (1, 1),
    "1×2": (1, 2),
    "2×1": (2, 1),
    "2×2": (2, 2),
    "3×1": (3, 1),
    "3×2": (3, 2),
    "Pełna szerokość": (3, 1),
}


class PolaWidgetu(TypedDict, total=False):
    skroty: tuple[str, ...] | None
    rozmiar: str
    ukryty: bool
    przypiety: bool
    widok: str
    kolumna: int
    wiersz: int


@dataclass(frozen=True)
class UstawienieWidgetu:
    id: str
    rozmiar: str = "1×1"
    ukryty: bool = False
    przypiety: bool = False
    widok: str = "Lista"
    kolumna: int = 0
    wiersz: int = 0
    skroty: tuple[str, ...] | None = None


@dataclass(frozen=True)
class UkladDashboardu:
    widgety: tuple[UstawienieWidgetu, ...]

    def zmien(self, ident: str, **pola: Unpack[PolaWidgetu]) -> "UkladDashboardu":
        return UkladDashboardu(
            tuple(replace(w, **pola) if w.id == ident else w for w in self.widgety)
        )

    def przesun(self, ident: str, cel: str, po: bool = False) -> "UkladDashboardu":
        source = next((w for w in self.widgety if w.id == ident), None)
        if source is None or source.przypiety or ident == cel:
            return self
        rows = [w for w in self.widgety if w.id != ident]
        index = next((i for i, w in enumerate(rows) if w.id == cel), len(rows))
        rows.insert(min(len(rows), index + int(po)), source)
        return UkladDashboardu(tuple(rows))


def rozmieszczenie(uklad: UkladDashboardu, kolumny: int) -> dict[str, tuple[int, int, int, int]]:
    """Deterministyczne pakowanie, przypięte pola rezerwowane przed pozostałymi."""
    zajete: set[tuple[int, int]] = set()
    result: dict[str, tuple[int, int, int, int]] = {}

    def wolne(x: int, y: int, width: int, height: int) -> bool:
        return x + width <= kolumny and all(
            (a, b) not in zajete for a in range(x, x + width) for b in range(y, y + height)
        )

    visible = [w for w in uklad.widgety if not w.ukryty]
    for w in sorted(visible, key=lambda w: not w.przypiety):
        width, height = ROZMIARY[w.rozmiar]
        width = kolumny if w.rozmiar == "Pełna szerokość" else min(width, kolumny)
        x, y = min(w.kolumna, kolumny - width), w.wiersz
        if not w.przypiety or not wolne(x, y, width, height):
            x, y = 0, 0
            while not wolne(x, y, width, height):
                x += 1
                if x + width > kolumny:
                    x, y = 0, y + 1
        result[w.id] = (x, y, width, height)
        zajete.update((a, b) for a in range(x, x + width) for b in range(y, y + height))
    return result


class PamiecDashboardu:
    """Jedna wersjonowana wartość QSettings; uszkodzony zapis nie blokuje startu."""

    KLUCZ = "dashboard/tablica_v1"

    def __init__(self, ustawienia: QSettings | None = None) -> None:
        self.ustawienia = ustawienia

    def odczytaj(self, domyslny: UkladDashboardu) -> UkladDashboardu:
        if self.ustawienia is None:
            return domyslny
        raw = self.ustawienia.value(self.KLUCZ, "")
        if not isinstance(raw, str) or len(raw) > 64_000:
            return domyslny
        try:
            doc = json.loads(raw)
            if not isinstance(doc, dict) or doc.get("wersja") != 1:
                return domyslny
            rows = doc.get("widgety")
            if not isinstance(rows, list) or len(rows) > 100:
                return domyslny
            known = {w.id for w in domyslny.widgety}
            seen: set[str] = set()
            result = []
            for r in rows:
                if not isinstance(r, dict) or r.get("id") not in known or r["id"] in seen:
                    continue
                if (
                    r.get("rozmiar") not in ROZMIARY
                    or r.get("widok") not in ("Lista", "Karty", "Tabela")
                    or any(type(r.get(k)) is not bool for k in ("ukryty", "przypiety"))
                    or any(
                        type(r.get(k)) is not int or not 0 <= r[k] <= 1000
                        for k in ("kolumna", "wiersz")
                    )
                ):
                    return domyslny
                shortcuts = r.get("skroty")
                if shortcuts is not None:
                    if (
                        not isinstance(shortcuts, list)
                        or len(shortcuts) > 50
                        or any(not isinstance(k, str) or len(k) > 80 for k in shortcuts)
                    ):
                        return domyslny
                    r["skroty"] = tuple(dict.fromkeys(shortcuts))
                result.append(UstawienieWidgetu(**r))
                seen.add(r["id"])
            result.extend(w for w in domyslny.widgety if w.id not in seen)
            return UkladDashboardu(tuple(result))
        except (ValueError, TypeError, KeyError):
            return domyslny

    def zapisz(self, uklad: UkladDashboardu) -> None:
        if self.ustawienia is None:
            return
        from dataclasses import asdict

        old = self.ustawienia.value(self.KLUCZ)
        self.ustawienia.setValue(
            self.KLUCZ,
            json.dumps(
                {"wersja": 1, "widgety": [asdict(w) for w in uklad.widgety]}, ensure_ascii=False
            ),
        )
        self.ustawienia.sync()
        if self.ustawienia.status() != QSettings.Status.NoError:
            if old is None:
                self.ustawienia.remove(self.KLUCZ)
            else:
                self.ustawienia.setValue(self.KLUCZ, old)
            raise OSError("Nie udało się zapisać układu. Sprawdź dostęp do katalogu ustawień.")
