"""Siatka widżetów, edycja i gesty. Nie pobiera ani nie przelicza danych sprzedaży."""

from functools import partial
from typing import Unpack
from uuid import uuid4

from PySide6.QtCore import QEvent, QMimeData, QPoint, QRect, Qt, QVariantAnimation, Signal
from PySide6.QtGui import (
    QDrag,
    QDragEnterEvent,
    QDragLeaveEvent,
    QDragMoveEvent,
    QDropEvent,
    QEnterEvent,
    QMouseEvent,
    QPainter,
    QPaintEvent,
    QPalette,
    QPen,
    QResizeEvent,
)
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMenu,
    QPushButton,
    QRubberBand,
    QScrollArea,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.uklad_dashboardu import (
    ROZMIARY,
    PamiecDashboardu,
    PolaWidgetu,
    UkladDashboardu,
    rozmieszczenie,
)

MIME = "application/x-vexlab-dashboard-widget"


class UchwytWidgetu(QLabel):
    przeciagany = Signal()

    def __init__(self, ident: str, token: str, parent: QWidget) -> None:
        super().__init__("⠿", parent)
        self.ident, self.token = ident, token
        self.start: QPoint | None = None
        self.setFixedWidth(22)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setAccessibleName("Przeciągnij widżet")
        self.setToolTip("Przeciągnij za ten uchwyt. Esc anuluje przeciąganie.")

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.start = event.position().toPoint()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if (
            self.start is None
            or not event.buttons() & Qt.MouseButton.LeftButton
            or (event.position().toPoint() - self.start).manhattanLength()
            < QApplication.startDragDistance()
        ):
            return
        self.start = None
        mime = QMimeData()
        mime.setData(MIME, (self.token + ":" + self.ident).encode())
        drag = QDrag(self)
        drag.setMimeData(mime)
        parent = self.parentWidget()
        if parent is not None:
            drag.setPixmap(parent.grab().scaledToWidth(240))
        self.przeciagany.emit()
        drag.exec(Qt.DropAction.MoveAction)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        self.start = None
        super().mouseReleaseEvent(event)


class UchwytRozmiaru(QLabel):
    zakonczono = Signal(int, int)

    def __init__(self, parent: QWidget) -> None:
        super().__init__("◢", parent)
        self.start: QPoint | None = None
        self.setFixedSize(22, 18)
        self.setCursor(Qt.CursorShape.SizeFDiagCursor)
        self.setAccessibleName("Zmień rozmiar widżetu")
        self.setToolTip("Przeciągnij, aby dopasować rozmiar do siatki.")

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.start = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if self.start is not None:
            delta = event.globalPosition().toPoint() - self.start
            self.start = None
            self.zakonczono.emit(delta.x(), delta.y())


class RamkaWidgetu(QFrame):
    menu = Signal(str)
    rozmiar = Signal(str, int, int)

    def __init__(self, ident: str, nazwa: str, symbol: str, tresc: QWidget, token: str) -> None:
        super().__init__()
        self.ident = ident
        self._podswietlenie = QVariantAnimation(self)
        self._podswietlenie.setDuration(140)
        self._podswietlenie.setStartValue(0.0)
        self._podswietlenie.setEndValue(0.0)
        self._podswietlenie.valueChanged.connect(lambda _: self.update())
        self.setObjectName("widgetDashboardu")
        self.setAccessibleName(nazwa)
        self.setMinimumWidth(0)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 7, 8, 7)
        layout.setSpacing(4)
        row = QHBoxLayout()
        self.uchwyt = UchwytWidgetu(ident, token, self)
        row.addWidget(self.uchwyt)
        self.symbol = QLabel()
        self.symbol.setPixmap(ikona(symbol).pixmap(16, 16))
        self.symbol.setAccessibleName("Ikona: " + nazwa)
        row.addWidget(self.symbol)
        title = QLabel(nazwa)
        title.setObjectName("tytulDashboardu")
        title.setMinimumWidth(0)
        title.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        row.addWidget(title, 1)
        self.pinezka = QLabel("⌖")
        self.pinezka.setToolTip("Przypięty: pozycja i rozmiar zablokowane")
        row.addWidget(self.pinezka)
        more = QToolButton()
        more.setText("⋯")
        more.setAccessibleName("Opcje widżetu: " + nazwa)
        more.clicked.connect(lambda: self.menu.emit(ident))
        self.wiecej = more
        row.addWidget(more)
        layout.addLayout(row)
        layout.addWidget(tresc, 1)
        self.rog = UchwytRozmiaru(self)
        self.rog.zakonczono.connect(lambda x, y: self.rozmiar.emit(ident, x, y))
        layout.addWidget(self.rog, 0, Qt.AlignmentFlag.AlignRight)

    def _animuj(self, value: float) -> None:
        previous = float(self._podswietlenie.currentValue() or 0)
        self._podswietlenie.stop()
        self._podswietlenie.setStartValue(previous)
        self._podswietlenie.setEndValue(value)
        self._podswietlenie.start()

    def enterEvent(self, event: QEnterEvent) -> None:
        super().enterEvent(event)
        self._animuj(1.0)

    def leaveEvent(self, event: QEvent) -> None:
        super().leaveEvent(event)
        self._animuj(0.0)

    def paintEvent(self, event: QPaintEvent) -> None:
        super().paintEvent(event)
        level = float(self._podswietlenie.currentValue() or 0)
        if level > 0:
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            color = self.palette().color(QPalette.ColorRole.Highlight)
            color.setAlphaF(level * 0.65)
            painter.setPen(QPen(color, 2))
            painter.drawRoundedRect(self.rect().adjusted(1, 1, -1, -1), 8, 8)

    def tryb(self, edycja: bool, przypiety: bool) -> None:
        if self.property("edycja") == edycja and self.pinezka.isHidden() == (not przypiety):
            return
        self.uchwyt.setVisible(edycja and not przypiety)
        self.rog.setVisible(edycja and not przypiety)
        self.pinezka.setVisible(przypiety)
        self.setProperty("edycja", edycja)
        self.style().unpolish(self)
        self.style().polish(self)


class TablicaDashboardu(QWidget):
    konfiguruj = Signal(str)
    rozmiar_zmieniony = Signal()
    modul = Signal(str)
    odswiez = Signal(str)
    widok = Signal(str, str)
    zmieniono = Signal()

    def __init__(self, domyslny: UkladDashboardu, pamiec: PamiecDashboardu) -> None:
        super().__init__()
        self.domyslny, self.pamiec = domyslny, pamiec
        self.uklad = pamiec.odczytaj(domyslny)
        self.zapisany = self.uklad
        self.edycja = False
        self._rozmieszczanie = False
        self.token = uuid4().hex
        self.ramki: dict[str, RamkaWidgetu] = {}
        self.warianty: dict[str, tuple[str, ...]] = {}
        self.nazwy: dict[str, str] = {}
        self.moduly: dict[str, str] = {}
        self.odswiezalne: set[str] = set()
        self.kolumny = 3
        self.pozycje: dict[str, tuple[int, int, int, int]] = {}
        self.miejsce: QRect | None = None
        self.cel_drop: tuple[str, bool] | None = None
        self.podglad = QRubberBand(QRubberBand.Shape.Rectangle, self)
        self.podglad.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAcceptDrops(True)
        self.grid = QGridLayout(self)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setSpacing(10)

    def dodaj(
        self,
        ident: str,
        nazwa: str,
        symbol: str,
        tresc: QWidget,
        modul: str,
        *,
        odswiez: bool = False,
        widoki: tuple[str, ...] = (),
    ) -> None:
        frame = RamkaWidgetu(ident, nazwa, symbol, tresc, self.token)
        frame.menu.connect(self._menu)
        frame.rozmiar.connect(self._gest_rozmiaru)
        self.ramki[ident], self.nazwy[ident], self.moduly[ident] = frame, nazwa, modul
        self.warianty[ident] = widoki
        if odswiez:
            self.odswiezalne.add(ident)

    def rozpocznij(self) -> None:
        if not self.edycja:
            self.zapisany = self.uklad
            self.edycja = True
            self.rozmiesc()
            self.zmieniono.emit()

    def zapisz(self) -> None:
        self.pamiec.zapisz(self.uklad)
        self.zapisany = self.uklad
        self.edycja = False
        self.rozmiesc()
        self.zmieniono.emit()

    def anuluj(self) -> None:
        self.uklad = self.zapisany
        self.edycja = False
        self.rozmiesc()
        self.zmieniono.emit()

    def resetuj(self) -> None:
        if self.edycja:
            self.uklad = self.domyslny
            self.rozmiesc()
            self.zmieniono.emit()

    def ustaw(self, ident: str, **pola: Unpack[PolaWidgetu]) -> None:
        if not self.edycja:
            self.rozpocznij()
        current = next(w for w in self.uklad.widgety if w.id == ident)
        if current.przypiety and any(k in pola for k in ("rozmiar", "kolumna", "wiersz")):
            return
        self.uklad = self.uklad.zmien(ident, **pola)
        self.rozmiesc()
        self.zmieniono.emit()

    def przesun(self, ident: str, cel: str, po: bool = False) -> None:
        if not self.edycja:
            return
        self.uklad = self.uklad.przesun(ident, cel, po)
        self.rozmiesc()
        self.zmieniono.emit()

    def rozmiesc(self) -> None:
        if self._rozmieszczanie:
            return
        self._rozmieszczanie = True
        self.setUpdatesEnabled(False)
        columns = 3 if self.width() >= 1080 else 2 if self.width() >= 680 else 1
        self.kolumny = columns
        for existing_frame in self.ramki.values():
            self.grid.removeWidget(existing_frame)
        # Kasujemy również stare rozciągnięcia: zwężenie nie zostawia pustych kolumn.
        for c in range(3):
            self.grid.setColumnStretch(c, int(c < columns))
            self.grid.setColumnMinimumWidth(c, 0)
        for r in range(self.grid.rowCount()):
            self.grid.setRowMinimumHeight(r, 0)
            self.grid.setRowStretch(r, 0)
        self.pozycje = rozmieszczenie(self.uklad, columns)
        for w in self.uklad.widgety:
            frame = self.ramki.get(w.id)
            if frame is None:
                continue
            frame.tryb(self.edycja, w.przypiety)
            self.widok.emit(w.id, w.widok)
            if w.ukryty:
                frame.hide()
                continue
            x, y, width, height = self.pozycje[w.id]
            frame.setMinimumHeight(
                150 if w.id == "kpi" and height == 1 else 205 * height + 10 * (height - 1)
            )
            self.grid.addWidget(frame, y, x, height, width)
            frame.show()
        self.grid.activate()
        self.updateGeometry()
        self.setUpdatesEnabled(True)
        self._rozmieszczanie = False
        self.update()

    def _menu(self, ident: str) -> None:
        w = next(w for w in self.uklad.widgety if w.id == ident)
        menu = QMenu(self)
        refresh = menu.addAction("Odśwież", partial(self.odswiez.emit, ident))
        refresh.setEnabled(ident in self.odswiezalne)
        if not refresh.isEnabled():
            refresh.setToolTip("Ten panel nie ma odrębnej operacji odświeżania.")
        menu.addAction("Przejdź do modułu", partial(self.modul.emit, self.moduly[ident]))
        if self.warianty[ident]:
            variants = menu.addMenu("Zmień widok")
            for name in self.warianty[ident]:
                action = variants.addAction(name, partial(self.ustaw, ident, widok=name))
                action.setCheckable(True)
                action.setChecked(w.widok == name)
        if ident == "akcje":
            menu.addAction("Konfiguruj skróty", partial(self.konfiguruj.emit, ident))
        menu.addSeparator()
        menu.addAction(
            "Odepnij" if w.przypiety else "Przypnij",
            partial(self._przypnij, ident, not w.przypiety),
        )
        sizes = menu.addMenu("Zmień rozmiar")
        sizes.setEnabled(not w.przypiety)
        for size in ROZMIARY:
            action = sizes.addAction(size, partial(self.ustaw, ident, rozmiar=size))
            action.setCheckable(True)
            action.setChecked(w.rozmiar == size)
        for after, label in ((False, "Przesuń wcześniej"), (True, "Przesuń później")):
            action = menu.addAction(label, partial(self._przesun_o_jeden, ident, after))
            action.setEnabled(not w.przypiety)
        menu.addAction("Ukryj", partial(self.ustaw, ident, ukryty=True))
        menu.exec(self.ramki[ident].wiecej.mapToGlobal(QPoint(0, 24)))

    def _przypnij(self, ident: str, przypiety: bool) -> None:
        x, y, _, _ = self.pozycje.get(ident, (0, 0, 1, 1))
        self.ustaw(ident, przypiety=przypiety)
        if przypiety:
            self.uklad = self.uklad.zmien(ident, kolumna=x, wiersz=y)
            self.rozmiesc()

    def _przesun_o_jeden(self, ident: str, after: bool) -> None:
        self.rozpocznij()
        rows = [w for w in self.uklad.widgety if not w.ukryty]
        index = next(i for i, w in enumerate(rows) if w.id == ident)
        target = index + (1 if after else -1)
        if 0 <= target < len(rows):
            self.przesun(ident, rows[target].id, after)

    def _gest_rozmiaru(self, ident: str, dx: int, dy: int) -> None:
        if not self.edycja or abs(dx) + abs(dy) < 15:
            return
        old = next(w for w in self.uklad.widgety if w.id == ident)
        width, height = ROZMIARY[old.rozmiar]
        width = max(1, min(3, width + round(dx / max(100, self.width() / self.kolumny))))
        height = max(1, min(2, height + round(dy / 205)))
        size = f"{width}×{height}"
        if size not in ROZMIARY:
            size = "2×2" if height == 2 else "1×1"
        self.ustaw(ident, rozmiar=size)

    def _zrodlo(self, event: QDragEnterEvent | QDragMoveEvent | QDropEvent) -> str:
        if not self.edycja:
            return ""
        raw = bytes(event.mimeData().data(MIME).data()).decode(errors="replace")
        token, _, ident = raw.partition(":")
        row = next((w for w in self.uklad.widgety if w.id == ident), None)
        return ident if token == self.token and row and not row.przypiety else ""

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if self._zrodlo(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event: QDragMoveEvent) -> None:
        if not self._zrodlo(event):
            event.ignore()
            return
        point = event.position().toPoint()
        visible = [f for f in self.ramki.values() if not f.isHidden()]
        if not visible:
            return
        target = min(visible, key=lambda f: (f.geometry().center() - point).manhattanLength())
        self.cel_drop = (target.ident, point.y() > target.geometry().center().y())
        self.miejsce = target.geometry().adjusted(2, 2, -2, -2)
        event.acceptProposedAction()
        self.podglad.setGeometry(self.miejsce)
        self.podglad.show()
        self.podglad.raise_()
        self.update()
        parent = self.parentWidget()
        while parent is not None and not isinstance(parent, QScrollArea):
            parent = parent.parentWidget()
        if isinstance(parent, QScrollArea):
            y = parent.viewport().mapFromGlobal(self.mapToGlobal(point)).y()
            bar = parent.verticalScrollBar()
            if y < 60:
                bar.setValue(bar.value() - 22)
            elif y > parent.viewport().height() - 60:
                bar.setValue(bar.value() + 22)

    def dragLeaveEvent(self, event: QDragLeaveEvent) -> None:
        self.miejsce, self.cel_drop = None, None
        self.podglad.hide()
        self.update()
        event.accept()

    def dropEvent(self, event: QDropEvent) -> None:
        ident = self._zrodlo(event)
        if ident and self.cel_drop:
            self.przesun(ident, *self.cel_drop)
            event.acceptProposedAction()
        else:
            event.ignore()
        self.miejsce, self.cel_drop = None, None
        self.podglad.hide()
        self.update()

    def paintEvent(self, event: QPaintEvent) -> None:
        super().paintEvent(event)
        if self.edycja and self.miejsce is not None:
            painter = QPainter(self)
            color = self.palette().color(QPalette.ColorRole.Highlight)
            painter.setPen(QPen(color, 3, Qt.PenStyle.DashLine))
            painter.drawRoundedRect(self.miejsce, 8, 8)

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        columns = 3 if event.size().width() >= 1080 else 2 if event.size().width() >= 680 else 1
        if self.ramki and columns != self.kolumny:
            self.rozmiesc()
        self.rozmiar_zmieniony.emit()


class PasekEdycjiDashboardu(QWidget):
    def __init__(self, board: TablicaDashboardu) -> None:
        super().__init__()
        self.board = board
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 4)
        title = QLabel("Dostosowywanie Dashboardu · przeciągnij uchwyt lub otwórz ⋯")
        title.setWordWrap(True)
        layout.addWidget(title, 1)
        self.blad = QLabel()
        self.blad.setObjectName("blad")
        self.blad.setWordWrap(True)
        layout.addWidget(self.blad)
        for text, callback in (
            ("Dodaj widżet", self._biblioteka),
            ("Resetuj układ", board.resetuj),
            ("Anuluj", board.anuluj),
            ("Zapisz układ", self._zapisz),
        ):
            button = QPushButton(text)
            button.clicked.connect(callback)
            if text == "Zapisz układ":
                button.setProperty("primary", True)
            layout.addWidget(button)
        board.zmieniono.connect(self._stan)
        self.hide()

    def _stan(self) -> None:
        self.setVisible(self.board.edycja)
        self.blad.clear()

    def _zapisz(self) -> None:
        try:
            self.board.zapisz()
        except OSError as exc:
            self.blad.setText(str(exc))

    def _biblioteka(self) -> None:
        menu = QMenu(self)
        for w in self.board.uklad.widgety:
            action = menu.addAction(self.board.nazwy[w.id])
            action.setCheckable(True)
            action.setChecked(not w.ukryty)
            action.triggered.connect(partial(self.board.ustaw, w.id, ukryty=not w.ukryty))
        menu.exec(self.mapToGlobal(QPoint(0, self.height())))
