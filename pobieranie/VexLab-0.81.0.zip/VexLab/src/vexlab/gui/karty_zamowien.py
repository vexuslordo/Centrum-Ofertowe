"""Karty o pełnej wysokości; zdjęcie i tekst pozostają w granicach kafelka."""

from PySide6.QtCore import QModelIndex, QPersistentModelIndex, QRect, QSize, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QIcon, QPainter, QPalette
from PySide6.QtWidgets import QStyle, QStyledItemDelegate, QStyleOptionViewItem

from vexlab.gui.premium import font_danych
from vexlab.gui.statusy_zamowien import kolory_odznaki
from vexlab.przypadki_uzycia.zamowienia_allegro import ZamowienieAllegro

Indeks = QModelIndex | QPersistentModelIndex


class KartaZamowienia(QStyledItemDelegate):
    def sizeHint(self, option: QStyleOptionViewItem, index: Indeks) -> QSize:
        return QSize(300, 160)

    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index: Indeks) -> None:
        row = index.data(Qt.ItemDataRole.UserRole)
        if not isinstance(row, ZamowienieAllegro):
            return
        rect = option.rect.adjusted(5, 5, -5, -5)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        dark = option.palette.color(QPalette.ColorRole.Base).lightness() < 128
        background = (
            ("#133652" if dark else "#E7F2FF") if selected else ("#121A2B" if dark else "#F6F9FD")
        )
        border = "#388FD0" if selected else ("#294158" if dark else "#C7D7E8")
        text = option.palette.color(QPalette.ColorRole.Text)
        muted = QColor("#A6B8CD" if dark else "#536985")
        painter.save()
        painter.setClipRect(option.rect)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QColor(border))
        painter.setBrush(QColor(background))
        painter.drawRoundedRect(rect, 8, 8)
        photo = QRect(rect.x() + 12, rect.y() + 12, 48, 48)
        icon = index.sibling(index.row(), 1).data(Qt.ItemDataRole.DecorationRole)
        if isinstance(icon, QIcon):
            icon.paint(painter, photo)
        else:
            painter.drawRoundedRect(photo, 5, 5)
            painter.drawText(photo, Qt.AlignmentFlag.AlignCenter, "—")
        item = row.pozycje[0] if row.pozycje else None
        font = QFont(option.font)
        font.setPixelSize(12)
        font.setWeight(QFont.Weight.DemiBold)
        painter.setFont(font)
        painter.setPen(text)
        title = QRect(rect.x() + 72, rect.y() + 10, rect.width() - 84, 36)
        painter.save()
        painter.setClipRect(title, Qt.ClipOperation.IntersectClip)
        painter.drawText(title, Qt.TextFlag.TextWordWrap, item.nazwa if item else "Brak pozycji")
        painter.restore()
        font = font_danych(font)
        font.setPixelSize(10)
        font.setWeight(QFont.Weight.Normal)
        painter.setFont(font)
        painter.setPen(muted)
        sku = "SKU: " + (item.sku or "—") if item else "—"
        if len(row.pozycje) > 1:
            sku += f" · +{len(row.pozycje) - 1} poz."
        painter.drawText(
            QRect(title.x(), rect.y() + 49, title.width(), 20),
            Qt.AlignmentFlag.AlignVCenter,
            QFontMetrics(font).elidedText(sku, Qt.TextElideMode.ElideRight, title.width()),
        )
        painter.setPen(QColor(border))
        painter.drawLine(rect.left() + 12, rect.top() + 80, rect.right() - 12, rect.top() + 80)
        font = QFont(option.font)
        font.setPixelSize(11)
        painter.setFont(font)
        painter.setPen(muted)
        painter.drawText(
            QRect(rect.x() + 12, rect.y() + 87, rect.width() - 24, 18),
            Qt.AlignmentFlag.AlignVCenter,
            QFontMetrics(font).elidedText(
                "Kupujący: " + row.kupujacy, Qt.TextElideMode.ElideRight, rect.width() - 24
            ),
        )
        status = str(index.sibling(index.row(), 6).data() or "")
        fill, foreground, line = kolory_odznaki(row.realizacja, dark)
        badge = QRect(
            rect.x() + 12,
            rect.y() + 115,
            min(140, QFontMetrics(font).horizontalAdvance(status) + 16),
            22,
        )
        painter.setBrush(QColor(fill))
        painter.setPen(QColor(line))
        painter.drawRoundedRect(badge, 6, 6)
        painter.setPen(QColor(foreground))
        painter.drawText(
            badge,
            Qt.AlignmentFlag.AlignCenter,
            QFontMetrics(font).elidedText(status, Qt.TextElideMode.ElideRight, badge.width() - 12),
        )
        font = font_danych(font)
        font.setPixelSize(12)
        font.setWeight(QFont.Weight.DemiBold)
        painter.setFont(font)
        painter.setPen(text)
        amount = QRect(badge.right() + 10, badge.y(), rect.right() - badge.right() - 22, 22)
        painter.drawText(
            amount,
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
            QFontMetrics(font).elidedText(row.kwota, Qt.TextElideMode.ElideRight, amount.width()),
        )
        painter.restore()
