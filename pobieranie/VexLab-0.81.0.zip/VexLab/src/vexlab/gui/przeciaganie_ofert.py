"""Jawne typy drag & drop: pliki zdjęć, zdjęcie galerii i sekcja tego edytora."""

from pathlib import Path
from typing import cast

from PySide6.QtCore import QEvent, QMimeData, QObject, QPoint, Qt, Signal
from PySide6.QtGui import (
    QDrag,
    QDragEnterEvent,
    QDragLeaveEvent,
    QDragMoveEvent,
    QDropEvent,
    QMouseEvent,
)
from PySide6.QtWidgets import QApplication, QFrame, QToolButton, QWidget

from vexlab.gui.edytor_opisu import MIME_ZDJECIA, TekstWizualny
from vexlab.przypadki_uzycia.nowe_szkice_allegro import adres_zdjecia
from vexlab.przypadki_uzycia.zdjecia_ofert import lokalne_zdjecie

MIME_SEKCJI = "application/x-vexlab-description-section"


def odczytaj_drop(mime: QMimeData) -> tuple[str, object] | None:
    if mime.hasFormat(MIME_ZDJECIA):
        try:
            url = bytes(mime.data(MIME_ZDJECIA).data()).decode("utf-8")
        except UnicodeError:
            return None
        return ("obraz", url) if adres_zdjecia(url) or lokalne_zdjecie(url) else None
    if mime.hasFormat(MIME_SEKCJI):
        raw = bytes(mime.data(MIME_SEKCJI).data())
        return ("sekcja", raw.decode("ascii")) if len(raw) == 36 and raw.isascii() else None
    if mime.hasUrls():
        urls = mime.urls()
        if 1 <= len(urls) <= 16 and all(u.isLocalFile() for u in urls):
            files = tuple(Path(u.toLocalFile()) for u in urls)
            if all(p.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"} for p in files):
                return "pliki", files
    return None


def przyjmij_drop(event: QDropEvent, value: tuple[str, object]) -> bool:
    action = Qt.DropAction.MoveAction if value[0] == "sekcja" else Qt.DropAction.CopyAction
    if not event.possibleActions() & action:
        event.ignore()
        return False
    # Import plików zawsze kopiuje — nie pozwala systemowi przenieść oryginału.
    event.setDropAction(action)
    event.accept()
    return True


class StrefaUpuszczania(QFrame):
    pliki = Signal(object)
    obraz = Signal(str)
    sekcja = Signal(str, bool)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setFrameShape(QFrame.Shape.StyledPanel)

    def _podswietl(self, active: bool) -> None:
        self.setProperty("dropActive", active)
        color = self.palette().highlight().color().name()
        self.setStyleSheet(f'QFrame[dropActive="true"] {{ border: 2px solid {color}; }}')

    def dragLeaveEvent(self, event: QDragLeaveEvent) -> None:
        self._podswietl(False)
        event.accept()

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        value = odczytaj_drop(event.mimeData())
        self._podswietl(value is not None and przyjmij_drop(event, value))
        if value is None:
            event.ignore()

    def dragMoveEvent(self, event: QDragMoveEvent) -> None:
        value = odczytaj_drop(event.mimeData())
        if value is not None:
            przyjmij_drop(event, value)
        else:
            event.ignore()

    def dropEvent(self, event: QDropEvent) -> None:
        self._podswietl(False)
        drop = odczytaj_drop(event.mimeData())
        if drop is None or not przyjmij_drop(event, drop):
            event.ignore()
            return
        typ, value = drop
        if typ == "pliki":
            self.pliki.emit(value)
        elif typ == "obraz":
            self.obraz.emit(str(value))
        else:
            self.sekcja.emit(str(value), event.position().y() > self.height() / 2)


class TekstZPrzeciaganiem(TekstWizualny):
    upuszczono = Signal(object)

    def _obsluz_wejscie(self, event: QDropEvent) -> bool:
        value = odczytaj_drop(event.mimeData())
        if value is not None:
            przyjmij_drop(event, value)
            return True
        if (
            event.mimeData().hasUrls()
            or event.mimeData().hasFormat(MIME_ZDJECIA)
            or event.mimeData().hasFormat(MIME_SEKCJI)
        ):
            event.ignore()
            return True
        return False

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if not self._obsluz_wejscie(event):
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event: QDragMoveEvent) -> None:
        if not self._obsluz_wejscie(event):
            super().dragMoveEvent(event)

    def dropEvent(self, event: QDropEvent) -> None:
        value = odczytaj_drop(event.mimeData())
        if value is not None:
            if przyjmij_drop(event, value):
                self.upuszczono.emit(value)
        elif not self._obsluz_wejscie(event):
            super().dropEvent(event)


class UchwytSekcji(QToolButton):
    def __init__(self, ident: str, parent: QWidget) -> None:
        super().__init__(parent)
        self.ident = ident
        self.poczatek = QPoint()
        self.setText("⠿")
        self.setAccessibleName("Przeciągnij sekcję opisu")
        self.setToolTip("Przeciągnij, aby zmienić kolejność")
        self.setCursor(Qt.CursorShape.OpenHandCursor)

    def mousePressEvent(self, event: QMouseEvent) -> None:
        self.poczatek = event.position().toPoint()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if (
            event.buttons() & Qt.MouseButton.LeftButton
            and (event.position().toPoint() - self.poczatek).manhattanLength()
            >= QApplication.startDragDistance()
        ):
            drag = QDrag(self)
            mime = QMimeData()
            mime.setData(MIME_SEKCJI, self.ident.encode())
            drag.setMimeData(mime)
            drag.exec(Qt.DropAction.MoveAction)
        else:
            super().mouseMoveEvent(event)


class PrzeciaganieZdjecia(QObject):
    def __init__(self, widget: QWidget, url: str) -> None:
        super().__init__(widget)
        self.url, self.poczatek = url, QPoint()
        widget.setCursor(Qt.CursorShape.OpenHandCursor)
        widget.installEventFilter(self)

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if event.type() == QEvent.Type.MouseButtonPress:
            self.poczatek = cast(QMouseEvent, event).position().toPoint()
        elif event.type() == QEvent.Type.MouseMove:
            mouse = cast(QMouseEvent, event)
            if (
                mouse.buttons() & Qt.MouseButton.LeftButton
                and (mouse.position().toPoint() - self.poczatek).manhattanLength()
                >= QApplication.startDragDistance()
            ):
                drag = QDrag(watched)
                mime = QMimeData()
                mime.setData(MIME_ZDJECIA, self.url.encode())
                drag.setMimeData(mime)
                drag.exec(Qt.DropAction.CopyAction)
                return True
        return False
