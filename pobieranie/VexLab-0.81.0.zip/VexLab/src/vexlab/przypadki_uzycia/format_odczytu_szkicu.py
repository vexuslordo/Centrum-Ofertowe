"""Porównanie formatu odczytu, bez pomijania treści opisu i adresów zdjęć."""


def _element(actual: object, expected: object) -> bool:
    if not isinstance(actual, dict) or not isinstance(expected, dict):
        return False
    if actual.get("type") != expected.get("type"):
        return False
    if expected.get("type") == "IMAGE":
        return actual.get("url") == expected.get("url")
    if expected.get("type") != "TEXT":
        return False
    text, wanted = actual.get("content"), expected.get("content")
    return (
        isinstance(text, str)
        and isinstance(wanted, str)
        and text.replace("\r\n", "\n").strip() == wanted.replace("\r\n", "\n").strip()
    )


def _sekcja(actual: object, expected: object) -> bool:
    if not isinstance(actual, dict) or not isinstance(expected, dict):
        return False
    items, wanted = actual.get("items"), expected.get("items")
    return (
        isinstance(items, list)
        and isinstance(wanted, list)
        and len(items) == len(wanted)
        and all(_element(a, e) for a, e in zip(items, wanted, strict=True))
    )


def zgodny_format_opisu(actual: object, expected: object) -> bool:
    if not isinstance(actual, dict) or not isinstance(expected, dict):
        return False
    sections, wanted = actual.get("sections"), expected.get("sections")
    return (
        isinstance(sections, list)
        and isinstance(wanted, list)
        and len(sections) == len(wanted)
        and all(_sekcja(a, e) for a, e in zip(sections, wanted, strict=True))
    )
