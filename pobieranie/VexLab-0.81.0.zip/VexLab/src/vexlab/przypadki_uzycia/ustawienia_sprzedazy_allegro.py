"""Dane użytkownika do przygotowania kompletnego szkicu, bez publikacji."""

import re
import unicodedata
from dataclasses import dataclass
from uuid import UUID

from vexlab.przypadki_uzycia.allegro import BladAllegro

CZASY = ("PT0S", "PT24H", "P2D", "P3D", "P4D", "P5D", "P7D", "P10D", "P14D", "P21D", "P30D", "P60D")
WOJEWODZTWA = (
    "DOLNOSLASKIE",
    "KUJAWSKO_POMORSKIE",
    "LUBELSKIE",
    "LUBUSKIE",
    "LODZKIE",
    "MALOPOLSKIE",
    "MAZOWIECKIE",
    "OPOLSKIE",
    "PODKARPACKIE",
    "PODLASKIE",
    "POMORSKIE",
    "SLASKIE",
    "SWIETOKRZYSKIE",
    "WARMINSKO_MAZURSKIE",
    "WIELKOPOLSKIE",
    "ZACHODNIOPOMORSKIE",
)


@dataclass(frozen=True)
class WyborSprzedazy:
    id: str
    nazwa: str
    opis: str = ""


@dataclass(frozen=True)
class SlownikiSprzedazy:
    producenci: tuple[WyborSprzedazy, ...]
    osoby: tuple[WyborSprzedazy, ...]
    dostawy: tuple[WyborSprzedazy, ...]
    zwroty: tuple[WyborSprzedazy, ...]
    reklamacje: tuple[WyborSprzedazy, ...]
    gwarancje: tuple[WyborSprzedazy, ...]
    bledy: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class UstawieniaSprzedazy:
    producent: str = ""
    osoba: str = ""  # 'nie_dotyczy' to jawny wybór użytkownika
    bezpieczenstwo: str = ""
    dostawa: str = ""
    czas: str = ""
    zwroty: str = ""
    reklamacje: str = ""
    gwarancja: str = ""  # 'brak' = jawny brak dodatkowej gwarancji
    kraj: str = ""
    miasto: str = ""
    kod: str = ""
    wojewodztwo: str = ""
    faktura: str = ""


def wlasna_lokalizacja(u: UstawieniaSprzedazy) -> bool:
    return any((u.kraj, u.miasto, u.kod, u.wojewodztwo))


def sprawdz_ustawienia(u: UstawieniaSprzedazy) -> tuple[str, ...]:
    bledy = []
    for nazwa, ident, pomijane in (
        ("producenta GPSR", u.producent, ""),
        ("osobę odpowiedzialną GPSR lub Nie dotyczy", u.osoba, "nie_dotyczy"),
        ("cennik dostaw", u.dostawa, ""),
        ("warunki zwrotów", u.zwroty, ""),
        ("warunki reklamacji", u.reklamacje, ""),
        ("gwarancję lub Brak dodatkowej gwarancji", u.gwarancja, "brak"),
    ):
        try:
            if not ident or ident != pomijane:
                UUID(ident)
        except (ValueError, AttributeError):
            bledy.append("Wybierz " + nazwa + ".")
    if not u.bezpieczenstwo.strip() or len(u.bezpieczenstwo) > 5000:
        bledy.append("Informacje o bezpieczeństwie: wymagany własny tekst do 5000 znaków.")
    if u.czas not in CZASY:
        bledy.append("Wybierz czas wysyłki.")
    if wlasna_lokalizacja(u):
        if not re.fullmatch(r"[A-Z]{2}", u.kraj):
            bledy.append("Podaj dwuliterowy kod kraju nadania.")
        if not u.miasto.strip() or len(u.miasto) > 50:
            bledy.append("Podaj miejscowość nadania (do 50 znaków).")
        if (
            not u.kod.strip()
            or len(u.kod) > 12
            or (u.kraj == "PL" and not re.fullmatch(r"[0-9]{2}-[0-9]{3}", u.kod))
        ):
            bledy.append("Podaj poprawny kod pocztowy nadania.")
        if u.kraj == "PL" and u.wojewodztwo not in WOJEWODZTWA:
            bledy.append("Wybierz województwo nadania.")
    if u.faktura not in {"VAT", "VAT_MARGIN", "WITHOUT_VAT", "NO_INVOICE"}:
        bledy.append("Wybierz rodzaj faktury.")
    return tuple(bledy)


def sprawdz_slowniki(u: UstawieniaSprzedazy, s: SlownikiSprzedazy) -> None:
    for ident, lista, zwolnienie, pole in (
        (u.producent, s.producenci, "", "producenci"),
        (u.osoba, s.osoby, "nie_dotyczy", "osoby"),
        (u.dostawa, s.dostawy, "", "dostawy"),
        (u.zwroty, s.zwroty, "", "zwroty"),
        (u.reklamacje, s.reklamacje, "", "reklamacje"),
        (u.gwarancja, s.gwarancje, "brak", "gwarancje"),
    ):
        if ident != zwolnienie and ident not in {w.id for w in lista}:
            if pole in dict(s.bledy):
                raise BladAllegro("USTAWIENIA", dict(s.bledy)[pole])
            raise BladAllegro(
                "USTAWIENIA",
                "Wybrane ustawienie nie istnieje na tym koncie. Pobierz listy ponownie.",
            )


def pola_sprzedazy(u: UstawieniaSprzedazy) -> tuple[dict[str, object], dict[str, object]]:
    bledy = sprawdz_ustawienia(u)
    if bledy:
        raise BladAllegro("USTAWIENIA", "; ".join(bledy))
    gpsr: dict[str, object] = {
        "responsibleProducer": {"type": "ID", "id": u.producent},
        "responsiblePerson": {"id": u.osoba} if u.osoba != "nie_dotyczy" else None,
        "safetyInformation": {"type": "TEXT", "description": u.bezpieczenstwo.strip()},
    }
    after: dict[str, object] = {
        "returnPolicy": {"id": u.zwroty},
        "impliedWarranty": {"id": u.reklamacje},
    }
    if u.gwarancja != "brak":
        after["warranty"] = {"id": u.gwarancja}
    fields: dict[str, object] = {
        "delivery": {"handlingTime": u.czas, "shippingRates": {"id": u.dostawa}},
        "payments": {"invoice": u.faktura},
        "afterSalesServices": after,
    }
    if wlasna_lokalizacja(u):
        location = {"city": u.miasto.strip(), "countryCode": u.kraj, "postCode": u.kod.strip()}
        if u.kraj == "PL":
            location["province"] = u.wojewodztwo
        fields["location"] = location
    return fields, gpsr


def _czas_w_sekundach(tekst: str) -> int | None:
    match = re.fullmatch(
        r"P(?:([0-9]{1,6})D)?(?:T(?:([0-9]{1,6})H)?(?:([0-9]{1,6})M)?(?:([0-9]{1,6})S)?)?", tekst
    )
    if (
        match is None
        or not any(v is not None for v in match.groups())
        or ("T" in tekst and not any(v is not None for v in match.groups()[1:]))
    ):
        return None
    return sum(
        int(v or 0) * mnoznik
        for v, mnoznik in zip(match.groups(), (86400, 3600, 60, 1), strict=True)
    )


def _zgodne(actual: object, expected: object, pole: str = "") -> bool:
    if isinstance(expected, dict):
        return isinstance(actual, dict) and all(
            _zgodne(actual.get(k), v, k) for k, v in expected.items()
        )
    if expected is None:
        return actual is None or (
            isinstance(actual, dict) and set(actual) <= {"id"} and actual.get("id") in (None, "")
        )
    if isinstance(actual, str) and isinstance(expected, str):
        if pole == "id":
            try:
                return UUID(actual) == UUID(expected)
            except ValueError:
                return actual == expected
        if pole == "handlingTime":
            sekundy = _czas_w_sekundach(expected)
            return sekundy is not None and _czas_w_sekundach(actual) == sekundy
        if pole == "description":
            return unicodedata.normalize(
                "NFC", actual.replace("\r\n", "\n").strip()
            ) == unicodedata.normalize("NFC", expected.replace("\r\n", "\n").strip())
    return actual == expected


def niepotwierdzone_pola(d: dict[str, object], u: UstawieniaSprzedazy) -> tuple[str, ...]:
    oczekiwane, gpsr = pola_sprzedazy(u)
    wynik = []
    for key, nazwa in (
        ("delivery", "dostawa i czas wysyłki"),
        ("payments", "rodzaj faktury"),
        ("afterSalesServices", "zwroty, reklamacje i gwarancja"),
        ("location", "lokalizacja nadania"),
    ):
        if key in oczekiwane and not _zgodne(d.get(key), oczekiwane[key]):
            wynik.append(nazwa)
    after = d.get("afterSalesServices")
    if (
        u.gwarancja == "brak"
        and isinstance(after, dict)
        and not _zgodne(after.get("warranty"), None)
        and "zwroty, reklamacje i gwarancja" not in wynik
    ):
        wynik.append("zwroty, reklamacje i gwarancja")
    produkty = d.get("productSet")
    first = produkty[0] if isinstance(produkty, list) and len(produkty) == 1 else None
    if not isinstance(first, dict):
        return (*wynik, "dane GPSR produktu")
    for key, nazwa in (
        ("responsibleProducer", "producent GPSR"),
        ("responsiblePerson", "osoba odpowiedzialna w UE"),
        ("safetyInformation", "informacje o bezpieczeństwie"),
    ):
        value = {"id": u.producent} if key == "responsibleProducer" else gpsr[key]
        if not _zgodne(first.get(key), value):
            wynik.append(nazwa)
    return tuple(wynik)


def potwierdz_pola(d: dict[str, object], u: UstawieniaSprzedazy) -> bool:
    return not niepotwierdzone_pola(d, u)
