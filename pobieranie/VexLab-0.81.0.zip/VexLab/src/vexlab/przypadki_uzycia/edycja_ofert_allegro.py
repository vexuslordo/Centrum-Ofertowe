"""Potwierdzana edycja istniejących ofert; brak tworzenia i publikacji."""

import json
from collections.abc import Callable
from dataclasses import dataclass, replace
from hashlib import sha256
from typing import Protocol

from vexlab.domena.produkt import NieprawidlowyProdukt, sprawdz_ean
from vexlab.przypadki_uzycia.allegro import BladAllegro, CzasMonotoniczny, SesjaAllegro
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import (
    ProbaZapisu,
    PrzyjecieZapisu,
    RejestrZapisow,
)


def skrot(value: object) -> str:
    return sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


@dataclass(frozen=True)
class OfertaEdycji:
    ident: str
    tytul: str
    sku: str
    ean: str
    produkt: str
    kategoria: str
    status: str
    wersja: str
    ochrona: str
    konto: str
    ean_mozliwy: bool = True

    def cel(self) -> str:
        return skrot(
            [
                self.ident,
                self.tytul,
                self.sku,
                self.ean,
                self.produkt,
                self.kategoria,
                self.status,
                self.ochrona,
                self.konto,
            ]
        )


@dataclass(frozen=True)
class ZmianaOferty:
    baza: OfertaEdycji
    tytul: str
    sku: str
    ean: str
    produkt: str = ""
    nazwa_produktu: str = ""

    def oczekiwana(self) -> OfertaEdycji:
        return replace(
            self.baza,
            tytul=self.tytul,
            sku=self.sku,
            ean=self.ean,
            produkt=self.produkt or self.baza.produkt,
        )


class APIEdycjiOfert(Protocol):
    def odczytaj_edycje(self, s: SesjaAllegro, ident: str) -> OfertaEdycji: ...
    def produkt_ean(self, s: SesjaAllegro, ean: str, kategoria: str) -> tuple[str, str]: ...
    def zmien_oferte(
        self, s: SesjaAllegro, z: ZmianaOferty, aktualne: Callable[[], bool]
    ) -> PrzyjecieZapisu: ...
    def operacja_szkicu(self, s: SesjaAllegro, ident: str, operacja: str) -> bool: ...


class EdytujOfertyAllegro:
    def __init__(
        self, api: APIEdycjiOfert, rejestr: RejestrZapisow, czas: CzasMonotoniczny
    ) -> None:
        self.api, self.rejestr, self.czas = api, rejestr, czas

    def kontekst(self, s: SesjaAllegro, zapis: bool = False) -> None:
        if self.czas.teraz() >= s.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        if zapis and (s.aplikacja is None or not s.aplikacja.zapis_szkicow):
            raise BladAllegro("UPRAWNIENIA", "Włącz zgodę na zapis ofert i połącz konto ponownie.")

    @staticmethod
    def klucz(s: SesjaAllegro, ident: str) -> str:
        return skrot([s.srodowisko.value, s.konto.id, ident])

    def odczytaj(self, s: SesjaAllegro, ident: str) -> OfertaEdycji:
        self.kontekst(s)
        if not ident.isascii() or not ident.isdigit() or len(ident) > 100:
            raise BladAllegro("ID", "Niepoprawny identyfikator oferty.")
        o = self.api.odczytaj_edycje(s, ident)
        if o.status not in {"ACTIVE", "INACTIVE"}:
            raise BladAllegro("STAN", "Edytuj aktywną ofertę lub wysłany szkic.")
        return o

    def przygotuj(
        self, s: SesjaAllegro, baza: OfertaEdycji, tytul: str, sku: str, ean: str
    ) -> ZmianaOferty:
        self.kontekst(s)
        if baza.konto != skrot([s.srodowisko.value, s.konto.id]):
            raise BladAllegro("KONTO", "Podgląd dotyczy innego konta lub środowiska.")
        tytul, sku, ean = tytul.strip(), sku.strip(), ean.strip()
        if tytul != baza.tytul and (not 12 <= len(tytul) <= 75 or len(tytul.split()) < 3):
            raise BladAllegro("TYTUL", "Tytuł wymaga 12–75 znaków i co najmniej 3 słów.")
        if (sku != baza.sku and not sku) or len(sku) > 100 or any(ord(c) < 32 for c in sku + tytul):
            raise BladAllegro("SKU", "SKU do 100 znaków; bez znaków sterujących.")
        z = ZmianaOferty(baza, tytul, sku, ean)
        if ean != baza.ean:
            if not baza.ean_mozliwy:
                raise BladAllegro(
                    "EAN",
                    "Zmiana EAN tej oferty wymaga edycji w Allegro. Tytuł i SKU są dostępne tutaj.",
                )
            try:
                sprawdz_ean(ean)
            except NieprawidlowyProdukt as exc:
                raise BladAllegro("EAN", str(exc)) from exc
            if not ean:
                raise BladAllegro("EAN", "Zmiana EAN wymaga kodu istniejącego produktu.")
            ident, nazwa = self.api.produkt_ean(s, ean, baza.kategoria)
            z = replace(z, produkt=ident, nazwa_produktu=nazwa)
        return z

    def zapisz(
        self, s: SesjaAllegro, z: ZmianaOferty, aktualne: Callable[[], bool] = lambda: True
    ) -> str:
        self.kontekst(s, True)
        if not aktualne():
            raise BladAllegro("KONTO", "Zmieniono konto. Nie wysłano zmian.")
        # Ponowna walidacja także dla wywołania spoza GUI.
        valid = self.przygotuj(s, z.baza, z.tytul, z.sku, z.ean)
        if valid != z:
            raise BladAllegro("PRODUKT", "Dane produktu zmieniły się. Przygotuj podgląd ponownie.")
        k = self.klucz(s, z.baza.ident)
        if self.rejestr.odczytaj(k):
            raise BladAllegro("NIEZNANY", "Poprzedni zapis wymaga sprawdzenia wyniku.")
        if z.oczekiwana().cel() == z.baza.cel():
            return "Pominięte"
        self.rejestr.rozpocznij(k, ProbaZapisu(z.oczekiwana().cel()))
        try:
            fresh = self.odczytaj(s, z.baza.ident)
            if fresh != z.baza:
                raise BladAllegro("KONFLIKT", "Oferta zmieniła się. Pobierz nowy podgląd.")
            self.kontekst(s, True)
            if not aktualne():
                raise BladAllegro("KONTO", "Zmieniono konto. Nie wysłano zmian.")
        except BladAllegro:
            self.rejestr.zakoncz(k)
            raise
        try:

            def nadal_aktualne() -> bool:
                self.kontekst(s, True)
                return aktualne()

            response = self.api.zmien_oferte(s, z, nadal_aktualne)
        except BladAllegro as exc:
            if exc.kod in {"ODRZUCONO", "KONFLIKT", "POLA", "KONTO", "WYGASLA", "UPRAWNIENIA"}:
                self.rejestr.zakoncz(k)
            raise
        if response.operacja:
            self.rejestr.operacja(k, ProbaZapisu(z.oczekiwana().cel(), response.operacja))
            return "Do sprawdzenia"
        return self.sprawdz(s, z.baza.ident)

    def sprawdz(self, s: SesjaAllegro, ident: str) -> str:
        self.kontekst(s)
        k = self.klucz(s, ident)
        attempt = self.rejestr.odczytaj(k)
        if attempt is None:
            return "Brak oczekującego zapisu"
        try:
            if attempt.operacja and not self.api.operacja_szkicu(s, ident, attempt.operacja):
                return "Do sprawdzenia"
            current = self.odczytaj(s, ident)
        except BladAllegro as exc:
            raise BladAllegro("NIEZNANY", "Nie potwierdzono wyniku. " + str(exc)) from exc
        if current.cel() != attempt.cel:
            raise BladAllegro("NIEZNANY", "Odczyt nie potwierdza zmian. Nie ponawiaj zapisu.")
        self.rejestr.zakoncz(k)
        return "Zapisane"


def kody_z_arkusza(tekst: str, ids: tuple[str, ...]) -> tuple[tuple[str, str, str], ...]:
    """Indywidualne kody z trzech kolumn TSV; brak domyślnej wspólnej wartości."""
    if len(tekst) > 50000:
        raise BladAllegro("KODY", "Wklej maksymalnie 100 wierszy: ID Allegro, SKU, EAN.")
    rows = [line.split("\t") for line in tekst.splitlines() if line.strip()]
    if rows and [v.strip().casefold() for v in rows[0]] == ["id allegro", "sku", "ean"]:
        rows.pop(0)
    if not 1 <= len(rows) <= 100:
        raise BladAllegro("KODY", "Wklej 1–100 wierszy z trzema kolumnami: ID Allegro, SKU, EAN.")
    seen: set[str] = set()
    result = []
    for row in rows:
        if len(row) != 3:
            raise BladAllegro(
                "KODY", "Każdy wiersz wymaga trzech kolumn rozdzielonych tabulatorem."
            )
        ident, sku, ean = (v.strip() for v in row)
        if ident not in ids or ident in seen:
            raise BladAllegro(
                "KODY", "ID spoza zaznaczenia lub powtórzone ID. Nie zmieniono danych."
            )
        seen.add(ident)
        result.append((ident, sku, ean))
    return tuple(result)
