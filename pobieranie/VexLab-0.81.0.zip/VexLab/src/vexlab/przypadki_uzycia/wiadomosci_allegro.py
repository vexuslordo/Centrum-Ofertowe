"""Odczyt centrum wiadomości konta, bez utrwalania i oznaczania przeczytania."""

import re
from dataclasses import dataclass, field
from typing import Protocol

from vexlab.przypadki_uzycia.allegro import BladAllegro, CzasMonotoniczny, SesjaAllegro

ROZMIAR_STRONY = 20
MAKS_OFFSET_WATKOW = 15_000_000
MAKS_OFFSET_WIADOMOSCI = 15_000


def sprawdz_id(ident: str) -> None:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,200}", ident):
        raise BladAllegro("WIADOMOSCI", "Nieprawidłowy identyfikator rozmowy.")


@dataclass(frozen=True)
class WatekAllegro:
    id: str
    login: str = field(repr=False)
    przeczytany: bool
    ostatnia: str


@dataclass(frozen=True)
class WiadomoscAllegro:
    id: str
    watek: str
    autor: str = field(repr=False)
    rozmowca: bool
    kiedy: str
    status: str
    tekst: str = field(repr=False)
    temat: str = field(default="", repr=False)
    zalaczniki: tuple[str, ...] = field(default=(), repr=False)
    dodatkowe_zalaczniki: bool = False


@dataclass(frozen=True)
class StronaWatkow:
    pozycje: tuple[WatekAllegro, ...] = field(repr=False)
    offset: int


@dataclass(frozen=True)
class StronaWiadomosci:
    pozycje: tuple[WiadomoscAllegro, ...] = field(repr=False)
    offset: int


class APIWiadomosci(Protocol):
    def watki(self, s: SesjaAllegro, offset: int) -> StronaWatkow: ...
    def wiadomosci(self, s: SesjaAllegro, ident: str, offset: int) -> StronaWiadomosci: ...


class OdczytajWiadomosciAllegro:
    def __init__(self, api: APIWiadomosci, czas: CzasMonotoniczny) -> None:
        self.api, self.czas = api, czas

    def _sprawdz(self, s: SesjaAllegro, offset: int, maksimum: int) -> None:
        if self.czas.teraz() >= s.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto Allegro ponownie.")
        if s.aplikacja is None or not s.aplikacja.odczyt_wiadomosci:
            raise BladAllegro(
                "UPRAWNIENIA",
                "W Integracje → Allegro włącz Odczyt wiadomości i połącz konto ponownie.",
            )
        if type(offset) is not int or not 0 <= offset <= maksimum or offset % ROZMIAR_STRONY:
            raise BladAllegro("ZAKRES", "Nieprawidłowy zakres strony wiadomości.")

    def watki(self, s: SesjaAllegro, offset: int = 0) -> StronaWatkow:
        self._sprawdz(s, offset, MAKS_OFFSET_WATKOW)
        return self.api.watki(s, offset)

    def wiadomosci(self, s: SesjaAllegro, ident: str, offset: int = 0) -> StronaWiadomosci:
        self._sprawdz(s, offset, MAKS_OFFSET_WIADOMOSCI)
        sprawdz_id(ident)
        return self.api.wiadomosci(s, ident, offset)
