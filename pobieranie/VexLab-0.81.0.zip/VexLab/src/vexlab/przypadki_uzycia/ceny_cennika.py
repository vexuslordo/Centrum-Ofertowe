"""Jawna reguła cenników właściciela: pełne brutto, VAT 23%."""

import re
from decimal import ROUND_HALF_UP, Decimal

from vexlab.domena.cena import CenaSugerowana


def pelne_brutto(tekst: str, waluta: str, rodzaj: str) -> str:
    czysta = tekst.strip().replace(" ", "").replace("\u00a0", "").replace(",", ".")
    if not re.fullmatch(r"\d{1,12}(?:\.\d{1,32})?", czysta):
        raise ValueError("Nieprawidłowa źródłowa kwota cennika.")
    cena = CenaSugerowana(Decimal(czysta), waluta.upper(), rodzaj)
    kwota = cena.kwota * Decimal("1.23") if rodzaj == "netto" else cena.kwota
    return str(kwota.quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def etykieta_cennika(tekst: str, waluta: str, rodzaj: str) -> str:
    try:
        cena = CenaSugerowana.z_tekstu(tekst, waluta, rodzaj)
    except ValueError:
        return f"{tekst} {waluta} {rodzaj}" if tekst else "—"
    brutto = cena.kwota if rodzaj == "brutto" else cena.kwota * Decimal("1.23")
    netto = brutto / Decimal("1.23")
    n = format(netto.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), "f")
    b = format(brutto, "f")
    return f"Brutto: {b} {waluta}\nNetto: {n} {waluta} (VAT 23%)".replace(".", ",")
