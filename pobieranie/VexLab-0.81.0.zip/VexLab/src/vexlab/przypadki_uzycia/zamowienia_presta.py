"""Odczyt zamówień jednego sklepu do Dashboardu; dane tylko w pamięci."""

from collections.abc import Callable
from datetime import datetime, timedelta
from typing import Protocol

from vexlab.przypadki_uzycia.prestashop import BladPresta, KonfiguracjaPresta
from vexlab.przypadki_uzycia.zamowienia_dashboardu import RaportZamowienKanalu


class APIZamowienPresta(Protocol):
    def zamowienia(
        self, k: KonfiguracjaPresta, od: datetime, do: datetime, stop: Callable[[], bool]
    ) -> RaportZamowienKanalu: ...


class OdczytajZamowieniaPresta:
    def __init__(self, api: APIZamowienPresta) -> None:
        self.api = api

    def pobierz(
        self, k: KonfiguracjaPresta, dni: int = 30, stop: Callable[[], bool] | None = None
    ) -> RaportZamowienKanalu:
        k = k.sprawdz()
        if not k.sklep or not k.jezyk:
            raise BladPresta("WYBOR", "Wybierz sklep i język przed odczytem zamówień.")
        if dni not in (7, 30, 90, 365):
            raise BladPresta("ZAKRES", "Wybierz poprawny zakres zamówień.")
        teraz = datetime.now().astimezone().replace(microsecond=0)
        return self.api.zamowienia(k, teraz - timedelta(days=dni), teraz, stop or (lambda: False))
