"""Własne, nazwane wartości użytkownika; bez treści dostarczanych przez program."""

from typing import Protocol


def sprawdz_szablon(rodzaj: str, nazwa: str, wartosc: str) -> None:
    if rodzaj not in {"bezpieczenstwo", "taryfa"}:
        raise ValueError("Nieprawidłowy rodzaj zapisanej wartości.")
    if not nazwa.strip() or len(nazwa) > 100 or any(ord(c) < 32 for c in nazwa):
        raise ValueError("Podaj nazwę do 100 znaków.")
    limit = 5000 if rodzaj == "bezpieczenstwo" else 1000
    if not wartosc.strip() or len(wartosc) > limit:
        raise ValueError(f"Wpisz wartość do {limit} znaków przed zapisaniem.")


class SzablonyOfert(Protocol):
    def lista(self, rodzaj: str) -> tuple[tuple[str, str], ...]: ...
    def zapisz(self, rodzaj: str, nazwa: str, wartosc: str) -> None: ...
    def usun(self, rodzaj: str, nazwa: str) -> None: ...
