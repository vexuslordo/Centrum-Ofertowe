"""Polskie etykiety źródłowych statusów Allegro, bez mapowania między kanałami."""

ZAKUP = {
    "BOUGHT": "Zakup rozpoczęty",
    "FILLED_IN": "Dane uzupełnione",
    "READY_FOR_PROCESSING": "Gotowe do obsługi",
    "CANCELLED": "Anulowane",
}
REALIZACJA = {
    "NEW": "Nowe",
    "PROCESSING": "W realizacji",
    "READY_FOR_SHIPMENT": "Do wysyłki",
    "READY_FOR_PICKUP": "Gotowe do odbioru",
    "SENT": "Wysłane",
    "PICKED_UP": "Odebrane",
    "CANCELLED": "Anulowane",
    "SUSPENDED": "Wstrzymane",
    "RETURNED": "Zwrócone",
}
TYP_PLATNOSCI = {
    "CASH_ON_DELIVERY": "Za pobraniem",
    "WIRE_TRANSFER": "Przelew",
    "ONLINE": "Przez internet",
    "EXTENDED_TERM": "Odroczona płatność",
}
PLATNOSC = {
    "oplacone": "Opłacone",
    "czesciowo": "Częściowo opłacone",
    "pobranie": "Za pobraniem",
    "oczekuje": "Oczekuje na płatność",
    "brak": "Brak potwierdzenia wpłaty",
}


def etykieta(kod: str, slownik: dict[str, str]) -> str:
    return slownik.get(kod, "Nieznany status" if kod else "Brak danych")
