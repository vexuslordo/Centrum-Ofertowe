"""Dobór ścieżki per SKU; tylko jednoznaczne GET, bez zgadywania parametrów."""

from dataclasses import replace

from vexlab.domena.produkt import NieprawidlowyProdukt, sprawdz_ean
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    NoweSzkiceAllegro,
    PlanNowegoSzkicu,
    ProduktSzkicu,
    UstawieniaSzkicu,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad


class AutomatycznyDoborSzkicu:
    def __init__(self, serwis: NoweSzkiceAllegro) -> None:
        self.serwis = serwis

    def _istniejacy(self, s: SesjaAllegro, o: OfertaPodglad) -> ProduktSzkicu | None:
        if not o.ean:
            return None
        try:
            sprawdz_ean(o.ean)
        except NieprawidlowyProdukt:
            raise BladAllegro(
                "DOBOR", "Nieprawidłowy EAN. Popraw go przed automatycznym doborem."
            ) from None
        candidates = {p.id: p for p in self.serwis.api.znajdz_produkty(s, o.ean, True)}
        if len(candidates) > 1:
            raise BladAllegro(
                "DOBOR", "Kilka produktów Allegro dla tego EAN. Wybierz produkt ręcznie."
            )
        return self.serwis.api.produkt_szkicu(s, next(iter(candidates))) if candidates else None

    @staticmethod
    def _ustawienia(u: UstawieniaSzkicu, product: ProduktSzkicu, nowy: bool) -> UstawieniaSzkicu:
        params = {p.id: p for p in product.parametry if nowy or not p.produktowy}
        values = tuple(
            (ident, value)
            for ident, value in u.wartosci
            if ident in params
            and (params[ident].typ != "dictionary" or value.strip() in dict(params[ident].slownik))
        )
        sources = (
            tuple((ident, source) for ident, source in u.zrodla if ident in params) if nowy else ()
        )
        return replace(
            u,
            produkt="" if nowy else product.id,
            nowy=nowy,
            kategoria=product.kategoria if nowy else "",
            wartosci=values,
            zrodla=sources,
            automatyczny=True,
        )

    def przygotuj(self, s: SesjaAllegro, o: OfertaPodglad, u: UstawieniaSzkicu) -> PlanNowegoSzkicu:
        if self.serwis.rejestr.odczytaj(self.serwis.klucz(s, o.sku)) is not None:
            return self.serwis.przygotuj(s, o, replace(u, automatyczny=False))
        try:
            product = self._istniejacy(s, o)
            nowy = product is None
            if product is None:
                categories = {c.id: c for c in self.serwis.api.kategorie(s, o.tytul)}
                if len(categories) != 1:
                    raise BladAllegro(
                        "DOBOR",
                        "Brak jednoznacznej kategorii Allegro. Wybierz kategorię ręcznie; "
                        "pozostałe pozycje mogą zostać przygotowane.",
                    )
                product = self.serwis.api.nowy_produkt(s, next(iter(categories)))
            return self.serwis.przygotuj(s, o, self._ustawienia(u, product, nowy))
        except BladAllegro as exc:
            if exc.kod in {"AUTORYZACJA", "UPRAWNIENIA", "WYGASLA", "LIMIT", "SIEC"}:
                raise
            return PlanNowegoSzkicu(
                o,
                replace(u, automatyczny=True),
                s.konto.id,
                s.srodowisko.value,
                self.serwis.czas.teraz(),
                None,
                (str(exc),),
            )

    def istniejacy_przed_zapisem(self, s: SesjaAllegro, p: PlanNowegoSzkicu) -> PlanNowegoSzkicu:
        if not p.ustawienia.automatyczny or not p.ustawienia.nowy:
            return p
        # Rejestr ma pierwszeństwo: żadnego zmieniania planu niepewnego POST.
        if self.serwis.rejestr.odczytaj(self.serwis.klucz(s, p.oferta.sku)) is not None:
            return p
        product = self._istniejacy(s, p.oferta)
        if product is None:
            return p
        plan = self.serwis.przygotuj(s, p.oferta, self._ustawienia(p.ustawienia, product, False))
        if plan.bledy:
            raise BladAllegro(
                "DOBOR",
                "Dopasowano istniejący produkt, ale wymaga poprawy: " + "; ".join(plan.bledy),
            )
        return plan
