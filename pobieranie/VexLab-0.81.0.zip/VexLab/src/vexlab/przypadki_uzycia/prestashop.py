"""Ustawienia jednego sklepu i odczyt jego kategorii, bez publikacji."""

import re
from dataclasses import dataclass, field
from typing import Protocol
from urllib.parse import urlsplit, urlunsplit

from vexlab.rdzen.kontrakty import BladTechniczny


class BladPresta(BladTechniczny):
    def __init__(self, kod: str, tekst: str) -> None:
        super().__init__(tekst)
        self.kod = kod


@dataclass(frozen=True)
class KonfiguracjaPresta:
    adres: str
    klucz: str = field(repr=False)
    sklep: str = ""
    jezyk: str = ""
    kategoria: str = ""

    def sprawdz(self) -> "KonfiguracjaPresta":
        try:
            u = urlsplit(self.adres.strip())
            if (
                len(self.adres) > 2048
                or u.scheme != "https"
                or not u.hostname
                or u.username
                or u.password
                or u.query
                or u.fragment
                or u.port == 0
                or any(ord(c) < 33 for c in self.adres.strip())
                or "\\" in self.adres
                or "%" in u.path
                or any(x in {".", ".."} or x.lower().startswith("admin") for x in u.path.split("/"))
                or ".php" in u.path.lower()
            ):
                raise ValueError()
        except ValueError:
            raise BladPresta(
                "ADRES", "Podaj adres HTTPS sklepu, bez panelu administratora i tokenów."
            ) from None
        if not re.fullmatch(r"[A-Za-z0-9]{32}", self.klucz):
            raise BladPresta("KLUCZ", "Podaj 32-znakowy klucz Webservice PrestaShop.")
        for ident in (self.sklep, self.jezyk, self.kategoria):
            if ident and not re.fullmatch(r"[1-9][0-9]{0,9}", ident):
                raise BladPresta("WYBOR", "Wybierz sklep, język i kategorię z pobranych list.")
        path = u.path.rstrip("/")
        if path.endswith("/api"):
            path = path[:-4]
        return KonfiguracjaPresta(
            urlunsplit(("https", u.netloc.lower(), path + "/", "", "")),
            self.klucz,
            self.sklep,
            self.jezyk,
            self.kategoria,
        )


@dataclass(frozen=True)
class PozycjaPresta:
    id: str
    nazwa: str
    aktywna: bool = True


@dataclass(frozen=True)
class KategoriaPresta:
    id: str
    rodzic: str
    nazwa: str
    aktywna: bool


@dataclass(frozen=True)
class SlownikiPresta:
    sklepy: tuple[PozycjaPresta, ...]
    jezyki: tuple[PozycjaPresta, ...]


@dataclass(frozen=True)
class OdpowiedzPresta:
    status: int
    dane: bytes = field(repr=False)


class TransportPresta(Protocol):
    def pobierz(
        self, konfiguracja: KonfiguracjaPresta, zasob: str, parametry: dict[str, str]
    ) -> OdpowiedzPresta: ...


class APIPresta(Protocol):
    def slowniki(self, konfiguracja: KonfiguracjaPresta) -> SlownikiPresta: ...
    def kategorie(self, konfiguracja: KonfiguracjaPresta) -> tuple[KategoriaPresta, ...]: ...


class MagazynPresta(Protocol):
    def odczytaj(self) -> KonfiguracjaPresta | None: ...
    def zapisz(self, konfiguracja: KonfiguracjaPresta) -> None: ...
    def usun(self) -> None: ...


class PolaczPresta:
    def __init__(self, api: APIPresta, magazyn: MagazynPresta | None = None) -> None:
        self.api, self.magazyn = api, magazyn

    def sprawdz(self, konfiguracja: KonfiguracjaPresta) -> SlownikiPresta:
        return self.api.slowniki(konfiguracja.sprawdz())

    def kategorie(self, konfiguracja: KonfiguracjaPresta) -> tuple[KategoriaPresta, ...]:
        k = konfiguracja.sprawdz()
        if not k.sklep or not k.jezyk:
            raise BladPresta("WYBOR", "Najpierw wybierz sklep i język.")
        return self.api.kategorie(k)

    def zapamietaj(self, konfiguracja: KonfiguracjaPresta) -> None:
        if self.magazyn is None:
            raise BladPresta("MAGAZYN", "Zapamiętywanie połączenia jest niedostępne.")
        self.magazyn.zapisz(konfiguracja.sprawdz())

    def przywroc(self) -> KonfiguracjaPresta | None:
        return self.magazyn.odczytaj() if self.magazyn else None

    def usun(self) -> None:
        if self.magazyn:
            self.magazyn.usun()
