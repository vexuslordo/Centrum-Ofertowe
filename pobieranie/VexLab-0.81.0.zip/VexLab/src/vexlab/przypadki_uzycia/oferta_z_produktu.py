"""Przygotowanie roboczej oferty z lokalnego Produktu, bez zapisu szkicu/sieci."""

import re
from dataclasses import dataclass
from html import escape
from typing import Protocol
from uuid import UUID

from vexlab.przypadki_uzycia.katalog_uzytkownika import (
    ProduktUzytkownika,
    RepoProduktowUzytkownika,
    blad,
)
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.zdjecia_ofert import PlikiZdjecOfert


class WersjeProduktow(Protocol):
    def wersja_produktu(self, ident: UUID) -> int | None: ...


@dataclass(frozen=True)
class OfertaZProduktu:
    produkt_id: UUID
    wersja_produktu: int
    oferta: OfertaPodglad
    producent: str
    waluta: str
    cena_zrodlowa: str
    uwaga: str = ""


def opis_oferty(tekst: str) -> str:
    if not tekst:
        return ""
    if re.search(r"</?(?:p|h[1-6]|ul|ol|li|b|strong|em|i|br)\b", tekst, re.IGNORECASE):
        return tekst
    return "".join("<p>" + escape(p) + "</p>" for p in tekst.splitlines() if p)


class PrzygotujOferteZProduktu:
    def __init__(
        self, katalog: RepoProduktowUzytkownika, wersje: WersjeProduktow, zdjecia: PlikiZdjecOfert
    ) -> None:
        self.katalog, self.wersje, self.zdjecia = katalog, wersje, zdjecia

    def przygotuj(self, ident: UUID, wersja: int) -> OfertaZProduktu:
        if self.wersje.wersja_produktu(ident) != wersja:
            raise blad("Produkt zmienił się lub został usunięty. Odśwież katalog.")
        produkty = self.katalog.odczytaj_uzytkownika((ident,))
        if self.wersje.wersja_produktu(ident) != wersja or len(produkty) != 1:
            raise blad("Produkt zmienił się podczas odczytu. Odśwież katalog.")
        return self._przygotuj(ident, wersja, produkty[0])

    def _przygotuj(self, ident: UUID, wersja: int, p: ProduktUzytkownika) -> OfertaZProduktu:
        p.sprawdz()
        urls = self.zdjecia.zapisz_kopie(p.zdjecia) if p.zdjecia else ()
        opis = opis_oferty(p.opis)
        sections = []
        if opis:
            sections.append((ElementPodgladu("tekst", opis),))
        sections.extend((ElementPodgladu("obraz", adres=url),) for url in urls)
        price, currency, source_price, note = "", "", "Brak ceny w katalogu", ""
        if p.cena:
            money = p.cena.sprawdz()
            if money:
                source_price = f"{money.kwota} {money.waluta} {money.rodzaj}"
                if money.waluta in {"PLN", "EUR", "CZK", "HUF"}:
                    currency = money.waluta
                    if money.rodzaj == "brutto":
                        price = format(money.kwota, "f")
                    else:
                        note = (
                            "Cena źródłowa jest netto. Wpisz cenę brutto; VAT nie jest zgadywany."
                        )
                else:
                    note = (
                        "Waluta źródłowa nie jest obsługiwana w przygotowaniu Allegro. "
                        "Wpisz właściwą cenę brutto i wybierz walutę w następnym kroku."
                    )
        if len(p.nazwa) > 75:
            note += " Skróć tytuł do 75 znaków przed zapisaniem szkicu."
        o = OfertaPodglad(1, p.sku, p.nazwa, opis, p.ean, price, "", urls, tuple(sections), ())
        return OfertaZProduktu(ident, wersja, o, p.producent, currency, source_price, note.strip())
