"""Porównanie cennika z odczytem Allegro; bez poleceń zmiany cen."""

from collections import Counter
from collections.abc import Callable
from contextlib import closing
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path
from typing import Protocol

from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow, CennikDTO
from vexlab.przypadki_uzycia.ceny_cennika import pelne_brutto
from vexlab.przypadki_uzycia.katalog_allegro import OfertaKatalogu
from vexlab.przypadki_uzycia.statusy_produktow_allegro import APIStatusowProduktow


@dataclass(frozen=True)
class PorownanieCeny:
    sku: str
    nazwa: str
    ident: str
    stan: str
    docelowa: str
    netto: str
    waluta_docelowa: str
    obecna: str
    waluta_obecna: str
    roznica: str
    procent: str
    wynik: str
    powod: str


@dataclass(frozen=True)
class RaportPorownaniaCen:
    konto: str
    login: str
    srodowisko: str
    cennik: CennikDTO
    odczytano: str
    pozycje: tuple[PorownanieCeny, ...]


class ZapisPorownaniaCen(Protocol):
    def zapisz(
        self, cel: Path, raport: RaportPorownaniaCen, pozycje: tuple[PorownanieCeny, ...]
    ) -> int: ...


def kwota_oferty(o: OfertaKatalogu) -> Decimal:
    try:
        v = Decimal(o.cena)
        if (
            not v.is_finite()
            or not 0 < v <= Decimal("999999999")
            or v != v.quantize(Decimal("0.01"))
        ):
            raise ValueError("cena")
        return v
    except (ValueError, InvalidOperation):
        raise ValueError("Brak prawidłowej ceny brutto oferty Allegro.") from None


class PorownajCennikAllegro:
    def __init__(
        self, biblioteka: BibliotekaCennikow, api: APIStatusowProduktow, zapis: ZapisPorownaniaCen
    ) -> None:
        self.biblioteka, self.api, self.zapis = biblioteka, api, zapis

    def lista(self) -> tuple[CennikDTO, ...]:
        return self.biblioteka.lista()

    def _wersja(self, c: CennikDTO) -> None:
        if not any((x.id, x.wersja) == (c.id, c.wersja) for x in self.lista()):
            raise BladAllegro(
                "CENNIK", "Cennik zmienił się lub został usunięty. Wybierz go ponownie."
            )

    def porownaj(
        self,
        s: SesjaAllegro,
        c: CennikDTO,
        stop: Callable[[], bool],
        postep: Callable[[str, int, int], None],
    ) -> RaportPorownaniaCen:
        self._wersja(c)
        with closing(self.biblioteka.magazyn.iteruj_pozycje(c.id, c.wersja)) as iterator:
            rows = []
            for p in iterator:
                if stop():
                    raise BladAllegro("ANULOWANO", "Anulowano porównanie cen.")
                rows.append(p)
        oferty = self.api.lista_statusow(
            s, stop, lambda n, total: postep("Pobieranie cen Allegro", n, total)
        )
        if len({o.ident for o in oferty}) != len(oferty):
            raise BladAllegro("ODCZYT", "Powtórzone ID w odczycie ofert. Nie utworzono raportu.")
        po_sku: dict[str, list[OfertaKatalogu]] = {}
        for oferta in oferty:
            if oferta.sku.strip():
                po_sku.setdefault(oferta.sku.strip().casefold(), []).append(oferta)
        liczby = Counter(p.dane.sku.strip().casefold() for p in rows)
        wynik = []
        for i, p in enumerate(rows):
            if stop():
                raise BladAllegro(
                    "ANULOWANO", "Anulowano porównanie cen. Nie pokazano częściowego raportu."
                )
            postep("Porównywanie cennika", i + 1, len(rows))
            sku = p.dane.sku.strip()
            matches = po_sku.get(sku.casefold(), [])
            problem = p.powod
            target, netto, waluta = "", "", ""
            try:
                if not sku or liczby[sku.casefold()] != 1:
                    raise ValueError("Brak SKU lub powtórzone SKU w cenniku.")
                if p.cena is None:
                    raise ValueError("Brak ceny w cenniku.")
                target = pelne_brutto(p.cena.tekst, p.cena.waluta, p.cena.rodzaj)
                waluta = p.cena.waluta.upper()
                if not 0 < Decimal(target) <= Decimal("999999999"):
                    raise ValueError("Cena docelowa musi być dodatnia i w zakresie Allegro.")
                netto = format(
                    (Decimal(target) / Decimal("1.23")).quantize(
                        Decimal("0.01"), rounding=ROUND_HALF_UP
                    ),
                    "f",
                )
            except (ValueError, InvalidOperation) as exc:
                problem = str(exc)
            for o in matches or (None,):
                obecna, waluta_obecna, diff, procent = "", "", "", ""
                powod = problem
                stan, ident = (o.status, o.ident) if o is not None else ("", "")
                rezultat = "Do sprawdzenia" if problem else "Brak oferty"
                if o is not None:
                    waluta_obecna = o.waluta
                    try:
                        value = kwota_oferty(o)
                        obecna = format(value.quantize(Decimal("0.01")), "f")
                        if not o.waluta or len(o.waluta) != 3:
                            raise ValueError("Brak prawidłowej waluty oferty Allegro.")
                        if not problem:
                            if waluta != o.waluta:
                                rezultat, powod = (
                                    "Inna waluta",
                                    "Waluty są różne. Nie przeliczono kursu.",
                                )
                            elif len(matches) > 1:
                                rezultat, powod = (
                                    "Wiele ofert",
                                    f"Ten sam SKU ma {len(matches)} ofert. "
                                    "Nie wybrano oferty automatycznie.",
                                )
                            elif o.status != "ACTIVE":
                                rezultat, powod = (
                                    "Nieaktywna",
                                    "Oferta nie jest ACTIVE; nie proponujemy aktualizacji.",
                                )
                            else:
                                roznica = Decimal(target) - value
                                diff = format(roznica.quantize(Decimal("0.01")), "f")
                                procent = format(
                                    (roznica / value * 100).quantize(
                                        Decimal("0.01"), rounding=ROUND_HALF_UP
                                    ),
                                    "f",
                                )
                                rezultat = "Różnica" if roznica else "Bez zmian"
                                powod = (
                                    "Cena docelowa względem obecnej ceny Allegro. "
                                    "Sam podgląd nie zmienia cen."
                                )
                    except ValueError as exc:
                        rezultat, powod = "Do sprawdzenia", problem or str(exc)
                elif not problem:
                    powod = "Nie znaleziono oferty z tym pełnym SKU na połączonym koncie."
                wynik.append(
                    PorownanieCeny(
                        sku,
                        p.dane.nazwa,
                        ident,
                        stan,
                        target,
                        netto,
                        waluta,
                        obecna,
                        waluta_obecna,
                        diff,
                        procent,
                        rezultat,
                        powod,
                    )
                )
        if stop():
            raise BladAllegro("ANULOWANO", "Anulowano porównanie cen.")
        self._wersja(c)
        return RaportPorownaniaCen(
            s.konto.id,
            s.konto.login,
            s.srodowisko.value,
            c,
            datetime.now(UTC).isoformat(timespec="seconds"),
            tuple(wynik),
        )

    def eksportuj(
        self, cel: Path, raport: RaportPorownaniaCen, pozycje: tuple[PorownanieCeny, ...]
    ) -> int:
        if not pozycje or not set(pozycje) <= set(raport.pozycje):
            raise BladAllegro("EKSPORT", "Wybierz istniejące pozycje raportu do eksportu.")
        return self.zapis.zapisz(cel, raport, pozycje)
