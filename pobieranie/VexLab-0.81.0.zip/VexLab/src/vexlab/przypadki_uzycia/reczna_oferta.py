"""Przygotowanie treści samodzielnego szkicu bez ZIP-a i bez Produktu."""

from decimal import Decimal, InvalidOperation

from vexlab.domena.produkt import NieprawidlowyProdukt, sprawdz_ean
from vexlab.przypadki_uzycia.nowe_szkice_allegro import adres_zdjecia
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.zdjecia_ofert import lokalne_zdjecie


def przygotuj_reczna(
    sku: str,
    tytul: str,
    ean: str,
    cena: str,
    opis: str,
    zdjecia: tuple[str, ...],
    sekcje: tuple[tuple[ElementPodgladu, ...], ...],
) -> OfertaPodglad:
    sku, tytul, ean, cena = sku.strip(), tytul.strip(), ean.strip(), cena.strip()
    if not sku or len(sku) > 100 or any(ord(c) < 32 for c in sku):
        raise ValueError("Wpisz SKU do 100 znaków.")
    if not tytul or len(tytul) > 75:
        raise ValueError("Wpisz tytuł do 75 znaków.")
    try:
        sprawdz_ean(ean)
    except NieprawidlowyProdukt as exc:
        raise ValueError(str(exc)) from exc
    if cena:
        try:
            value = Decimal(cena.replace(",", "."))
            if (
                not value.is_finite()
                or not 0 < value <= Decimal("999999999.99")
                or value != value.quantize(Decimal("0.01"))
            ):
                raise ValueError("Cena")
            cena = format(value.quantize(Decimal("0.01")), "f")
        except (InvalidOperation, ValueError):
            raise ValueError(
                "Podaj dodatnią cenę z maksymalnie dwoma miejscami po przecinku."
            ) from None
    if len(opis) > 100000 or len(sekcje) > 100:
        raise ValueError("Opis jest zbyt długi (maks. 100 000 znaków i 100 sekcji).")
    urls = tuple(
        dict.fromkeys((*zdjecia, *(e.adres for s in sekcje for e in s if e.typ == "obraz")))
    )
    if len(urls) > 16 or any(not (adres_zdjecia(url) or lokalne_zdjecie(url)) for url in urls):
        raise ValueError("Dodaj maksymalnie 16 zdjęć z dysku lub przez poprawne adresy HTTPS.")
    if any(not 1 <= len(s) <= 2 or any(e.typ not in {"tekst", "obraz"} for e in s) for s in sekcje):
        raise ValueError("Sekcja opisu powinna zawierać 1–2 elementy: tekst lub zdjęcie.")
    return OfertaPodglad(
        1, sku, tytul, opis, ean, cena, "", tuple(dict.fromkeys(zdjecia)), sekcje, ()
    )
