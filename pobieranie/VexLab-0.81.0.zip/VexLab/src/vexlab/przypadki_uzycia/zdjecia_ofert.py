"""Odwołania do własnych kopii zdjęć; bez ujawniania ścieżki pliku."""

import re
from pathlib import Path
from typing import Protocol

from vexlab.przypadki_uzycia.media import ZdjecieDane


def lokalne_zdjecie(adres: str) -> bool:
    return re.fullmatch(r"vexlab-image:[0-9a-f]{64}", adres) is not None


class PlikiZdjecOfert(Protocol):
    def importuj(self, pliki: tuple[Path, ...]) -> tuple[str, ...]: ...
    def pobierz_obraz(self, adres: str) -> ZdjecieDane: ...
    def zapisz_kopie(self, zdjecia: tuple[ZdjecieDane, ...]) -> tuple[str, ...]: ...
