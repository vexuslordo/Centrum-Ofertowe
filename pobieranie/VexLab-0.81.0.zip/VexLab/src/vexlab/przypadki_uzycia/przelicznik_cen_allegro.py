"""Wybór kursowej reguły Allegro; bez lokalnego liczenia kursu i publikacji."""

import re
from dataclasses import dataclass

from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro

RYNKI_KURSOWE = (
    ("allegro-cz", "Czechy", "CZK"),
    ("allegro-sk", "Słowacja", "EUR"),
    ("allegro-hu", "Węgry", "HUF"),
)


@dataclass(frozen=True)
class RegulaKursowa:
    id: str
    nazwa: str


@dataclass(frozen=True)
class PrzelicznikCen:
    regula: str
    rynki: tuple[str, ...]
    konto: str
    srodowisko: str


def sprawdz_przelicznik(
    u: PrzelicznikCen,
    s: SesjaAllegro,
    waluta: str,
    reguly: tuple[RegulaKursowa, ...] | None = None,
) -> None:
    if (u.konto, u.srodowisko) != (s.konto.id, s.srodowisko.value):
        raise BladAllegro("PRZELICZNIK", "Przelicznik cen pochodzi z innego konta lub środowiska.")
    if waluta != "PLN":
        raise BladAllegro("PRZELICZNIK", "Przelicznik wymaga bazowej ceny w PLN na allegro.pl.")
    if (
        not re.fullmatch(r"[A-Za-z0-9-]{1,100}", u.regula)
        or not u.rynki
        or len(set(u.rynki)) != len(u.rynki)
        or not set(u.rynki) <= {r[0] for r in RYNKI_KURSOWE}
    ):
        raise BladAllegro("PRZELICZNIK", "Wybierz regułę kursową i co najmniej jeden rynek.")
    if reguly is not None and u.regula not in {r.id for r in reguly}:
        raise BladAllegro(
            "PRZELICZNIK", "Reguła kursowa nie jest dostępna na tym koncie. Pobierz listę ponownie."
        )


def polecenie_przelicznika(u: PrzelicznikCen, ident: str, komenda: str) -> dict[str, object]:
    return {
        "id": komenda,
        "modification": {
            "set": [{"marketplace": {"id": rynek}, "rule": {"id": u.regula}} for rynek in u.rynki]
        },
        "offerCriteria": [{"type": "CONTAINS_OFFERS", "offers": [{"id": ident}]}],
    }
