"""Jawnie zatwierdzane zmiany cen, trwałe próby i odczyt nieznanego wyniku."""

from collections.abc import Callable
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from decimal import Decimal
from typing import Protocol
from uuid import uuid4

from vexlab.przypadki_uzycia.allegro import BladAllegro, CzasMonotoniczny, SesjaAllegro
from vexlab.przypadki_uzycia.porownanie_cen_allegro import (
    PorownajCennikAllegro,
    PorownanieCeny,
    RaportPorownaniaCen,
)
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import PrzyjecieZapisu


@dataclass(frozen=True)
class CenaOferty:
    ident: str
    sku: str
    stan: str
    kwota: str
    waluta: str
    wersja: str


@dataclass(frozen=True)
class PlanCen:
    raport: RaportPorownaniaCen
    pozycje: tuple[PorownanieCeny, ...]
    bazy: tuple[CenaOferty, ...]
    kiedy: float


@dataclass(frozen=True)
class ProbaCeny:
    id: str
    konto: str
    srodowisko: str
    ident: str
    sku: str
    przed: str
    po: str
    waluta: str
    cennik: str
    wersja_cennika: int
    kiedy: str
    status: str = "Do sprawdzenia"
    powod: str = "Zapis rozpoczęty. Sprawdź wynik; nie wysyłaj ponownie."
    operacja: str = ""


class APICen(Protocol):
    def odczytaj_cene(self, s: SesjaAllegro, ident: str) -> CenaOferty: ...
    def zapisz_cene(
        self, s: SesjaAllegro, baza: CenaOferty, kwota: str, aktualne: Callable[[], bool]
    ) -> PrzyjecieZapisu: ...
    def operacja_szkicu(self, s: SesjaAllegro, ident: str, operacja: str) -> bool: ...


class DziennikCen(Protocol):
    def rozpocznij(self, p: ProbaCeny) -> None: ...
    def zapisz(self, p: ProbaCeny) -> None: ...
    def lista(self, konto: str, srodowisko: str) -> tuple[ProbaCeny, ...]: ...


class AktualizujCenyAllegro:
    def __init__(
        self,
        porownanie: PorownajCennikAllegro,
        api: APICen,
        dziennik: DziennikCen,
        czas: CzasMonotoniczny,
    ) -> None:
        self.porownanie, self.api, self.dziennik, self.czas = porownanie, api, dziennik, czas

    def _kontekst(self, s: SesjaAllegro, zapis: bool = False) -> None:
        if self.czas.teraz() >= s.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        if zapis and (s.aplikacja is None or not s.aplikacja.zapis_szkicow):
            raise BladAllegro("UPRAWNIENIA", "Włącz zgodę na zapis ofert i połącz konto ponownie.")

    def historia(self, s: SesjaAllegro) -> tuple[ProbaCeny, ...]:
        self._kontekst(s)
        return self.dziennik.lista(s.konto.id, s.srodowisko.value)

    def przygotuj(
        self,
        s: SesjaAllegro,
        raport: RaportPorownaniaCen,
        rows: tuple[PorownanieCeny, ...],
        stop: Callable[[], bool],
        postep: Callable[[str, int, int], None],
    ) -> PlanCen:
        self._kontekst(s, True)
        if (raport.konto, raport.srodowisko) != (s.konto.id, s.srodowisko.value):
            raise BladAllegro("KONTO", "Porównanie dotyczy innego konta.")
        if not 1 <= len(rows) <= 500 or len({p.ident for p in rows}) != len(rows):
            raise BladAllegro("WYBOR", "Wybierz od 1 do 500 różnych ofert.")
        if any(p.wynik != "Różnica" or p not in raport.pozycje for p in rows):
            raise BladAllegro(
                "WYBOR", "Zaznacz wyłącznie jednoznaczne aktywne oferty z różnicą ceny."
            )
        fresh = self.porownanie.porownaj(s, raport.cennik, stop, postep)
        if any(p not in fresh.pozycje for p in rows):
            raise BladAllegro("KONFLIKT", "Ceny lub cennik zmieniły się. Porównaj ponownie.")
        pending = {p.ident for p in self.historia(s) if p.status == "Do sprawdzenia"}
        bazy = []
        for i, p in enumerate(rows):
            if stop():
                raise BladAllegro("ANULOWANO", "Anulowano przygotowanie cen.")
            if p.ident in pending:
                raise BladAllegro(
                    "NIEZNANY", f"SKU {p.sku}: sprawdź poprzedni zapis w Historii cen."
                )
            b = self.api.odczytaj_cene(s, p.ident)
            if (
                b.sku.strip().casefold() != p.sku.strip().casefold()
                or b.stan != "ACTIVE"
                or b.waluta != p.waluta_docelowa
                or Decimal(b.kwota) != Decimal(p.obecna)
            ):
                raise BladAllegro(
                    "KONFLIKT", f"SKU {p.sku}: oferta zmieniła się. Porównaj ponownie."
                )
            bazy.append(b)
            postep("Sprawdzanie przed zatwierdzeniem", i + 1, len(rows))
        return PlanCen(raport, rows, tuple(bazy), self.czas.teraz())

    def wykonaj(
        self,
        s: SesjaAllegro,
        plan: PlanCen,
        aktualne: Callable[[], bool],
        postep: Callable[[str, int, int], None],
    ) -> tuple[ProbaCeny, ...]:
        self._kontekst(s, True)
        if (plan.raport.konto, plan.raport.srodowisko) != (s.konto.id, s.srodowisko.value):
            raise BladAllegro("KONTO", "Podgląd dotyczy innego konta.")
        if not 0 <= self.czas.teraz() - plan.kiedy <= 120:
            raise BladAllegro("PODGLAD", "Podgląd cen wygasł. Przygotuj go ponownie.")
        if (
            len(plan.pozycje) != len(plan.bazy)
            or not 1 <= len(plan.pozycje) <= 500
            or len({p.ident for p in plan.pozycje}) != len(plan.pozycje)
            or any(
                p not in plan.raport.pozycje
                or p.wynik != "Różnica"
                or b.ident != p.ident
                or b.sku.strip().casefold() != p.sku.strip().casefold()
                or b.stan != "ACTIVE"
                or b.waluta != p.waluta_docelowa
                or Decimal(b.kwota) != Decimal(p.obecna)
                for p, b in zip(plan.pozycje, plan.bazy, strict=True)
            )
        ):
            raise BladAllegro("PODGLAD", "Niepoprawny podgląd cen.")
        wynik: list[ProbaCeny] = []
        for i, (p, baza) in enumerate(zip(plan.pozycje, plan.bazy, strict=True)):
            proba = ProbaCeny(
                str(uuid4()),
                s.konto.id,
                s.srodowisko.value,
                p.ident,
                p.sku,
                baza.kwota,
                p.docelowa,
                p.waluta_docelowa,
                str(plan.raport.cennik.id),
                plan.raport.cennik.wersja,
                datetime.now(UTC).isoformat(timespec="seconds"),
            )
            if not aktualne():
                wynik.extend(
                    replace(
                        proba,
                        ident=r.ident,
                        sku=r.sku,
                        przed=r.obecna,
                        po=r.docelowa,
                        waluta=r.waluta_docelowa,
                        status="Niewysłane",
                        powod="Zatrzymano serię lub zmieniono konto.",
                    )
                    for r in plan.pozycje[i:]
                )
                break
            try:
                self._kontekst(s, True)
                self.porownanie._wersja(plan.raport.cennik)
                if self.api.odczytaj_cene(s, p.ident) != baza:
                    raise BladAllegro(
                        "KONFLIKT", "Oferta zmieniła się od podglądu. Porównaj ponownie."
                    )
                if not aktualne():
                    raise BladAllegro("ANULOWANO", "Zatrzymano serię przed wysłaniem.")
                self.dziennik.rozpocznij(proba)
            except BladAllegro as exc:
                wynik.append(replace(proba, status="Niewysłane", powod=str(exc)))
                postep("Aktualizacja cen", i + 1, len(plan.pozycje))
                continue
            przyjeto = False
            try:
                self._kontekst(s, True)
                if not aktualne():
                    proba = replace(proba, status="Niewysłane", powod="Zatrzymano przed zapisem.")
                    self.dziennik.zapisz(proba)
                else:

                    def nadal_aktualne() -> bool:
                        self._kontekst(s, True)
                        self.porownanie._wersja(plan.raport.cennik)
                        return aktualne()

                    response = self.api.zapisz_cene(s, baza, p.docelowa, nadal_aktualne)
                    przyjeto = True
                    proba = replace(proba, operacja=response.operacja)
                    self.dziennik.zapisz(proba)
                    proba = self.sprawdz(s, proba.id)
            except BladAllegro as exc:
                proba = replace(
                    proba,
                    status=(
                        "Do sprawdzenia"
                        if przyjeto
                        else "Odrzucone"
                        if exc.kod == "ODRZUCONO"
                        else "Niewysłane"
                        if exc.kod
                        in {"KONFLIKT", "CENA", "KONTO", "CENNIK", "UPRAWNIENIA", "WYGASLA"}
                        else "Do sprawdzenia"
                    ),
                    powod=str(exc),
                )
                self.dziennik.zapisz(proba)
            wynik.append(proba)
            postep("Aktualizacja cen", i + 1, len(plan.pozycje))
        return tuple(wynik)

    def sprawdz(self, s: SesjaAllegro, ident_proby: str) -> ProbaCeny:
        self._kontekst(s)
        p = next((p for p in self.historia(s) if p.id == ident_proby), None)
        if p is None:
            raise BladAllegro("REJESTR", "Nie znaleziono próby dla tego konta.")
        if p.status != "Do sprawdzenia":
            return p
        if p.operacja and not self.api.operacja_szkicu(s, p.ident, p.operacja):
            return p
        b = self.api.odczytaj_cene(s, p.ident)
        if (
            b.sku.strip().casefold() == p.sku.strip().casefold()
            and b.waluta == p.waluta
            and Decimal(b.kwota) == Decimal(p.po)
        ):
            p = replace(p, status="Gotowe", powod="Potwierdzono cenę w aktualnej ofercie Allegro.")
        else:
            p = replace(
                p,
                powod=(
                    "Nie potwierdzono docelowej ceny. Sprawdź ofertę w Allegro; "
                    "nie ponawiaj zapisu."
                ),
            )
        self.dziennik.zapisz(p)
        return p
