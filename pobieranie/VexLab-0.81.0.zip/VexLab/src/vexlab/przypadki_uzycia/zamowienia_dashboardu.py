"""Wspólny podgląd danych kanałów; bez wspólnej encji zamówienia i bez zapisu."""

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation

from vexlab.przypadki_uzycia.opisy_zamowien import REALIZACJA, etykieta
from vexlab.przypadki_uzycia.zamowienia_allegro import RaportZamowien


@dataclass(frozen=True)
class ZamowienieDashboardu:
    numer: str
    zrodlo: str
    klient: str
    kwota: str
    waluta: str
    status: str
    kiedy: str
    do_obrotu: bool = True
    kod_statusu: str = ""


@dataclass(frozen=True)
class RaportZamowienKanalu:
    zrodlo: str
    od: str
    do: str
    odczytano: str
    pozycje: tuple[ZamowienieDashboardu, ...]


def z_allegro(raport: RaportZamowien | None) -> RaportZamowienKanalu | None:
    if raport is None:
        return None
    rows = []
    for r in raport.pozycje:
        kwota, waluta = r.kwota.rsplit(" ", 1) if " " in r.kwota else ("", "")
        rows.append(
            ZamowienieDashboardu(
                r.id,
                "Allegro",
                r.kupujacy,
                kwota,
                waluta,
                etykieta(r.realizacja, REALIZACJA),
                r.kupiono,
                r.status != "CANCELLED" and r.realizacja != "CANCELLED",
                r.realizacja,
            )
        )
    return RaportZamowienKanalu("Allegro", raport.od, raport.do, raport.odczytano, tuple(rows))


@dataclass(frozen=True)
class PodsumowanieZamowien:
    liczba: int | None
    obrot: str
    ostatnie: tuple[ZamowienieDashboardu, ...]
    waluty: tuple[str, ...]
    opis: str


def podsumuj_zamowienia(
    raporty: tuple[RaportZamowienKanalu, ...],
    dni: int,
    waluta: str,
    teraz: datetime,
) -> PodsumowanieZamowien:
    od = teraz - timedelta(days=dni)
    if dni == 1:
        od = teraz.replace(hour=0, minute=0, second=0, microsecond=0)
        if teraz.tzinfo == datetime.now().astimezone().tzinfo:
            od = od.replace(tzinfo=None).astimezone()
    rows = []
    full = bool(raporty)
    for report in raporty:
        try:
            start = datetime.fromisoformat(report.od.replace("Z", "+00:00"))
            # Dopuszczamy kilka minut między odczytem a prezentacją; data od jest granicą pokrycia.
            end = datetime.fromisoformat(report.do.replace("Z", "+00:00"))
            full = full and start <= od and end.astimezone(teraz.tzinfo).date() == teraz.date()
        except (ValueError, TypeError):
            full = False
        for row in report.pozycje:
            try:
                date = datetime.fromisoformat(row.kiedy.replace("Z", "+00:00"))
                if date.tzinfo is None:
                    date = date.astimezone()
                if od <= date <= teraz:
                    rows.append(row)
            except (ValueError, TypeError):
                full = False
    codes = tuple(
        sorted(
            {r.waluta for report in raporty for r in report.pozycje if r.waluta},
            key=lambda c: (c != "PLN", c),
        )
    )
    amount = Decimal(0)
    valid = True
    for row in rows:
        if row.waluta == waluta and row.do_obrotu:
            try:
                value = Decimal(row.kwota)
                if not value.is_finite() or value < 0:
                    raise ValueError("kwota")
                amount += value
            except (ValueError, InvalidOperation):
                valid = False
    text = f"{amount:,.2f}".replace(",", " ").replace(".", ",") + " " + waluta
    opis = " • ".join(
        f"{r.zrodlo}: {r.od[:10]}–{r.do[:10]} (odczyt {r.odczytano[:16]})" for r in raporty
    )
    if not full:
        opis = "Brak pełnego odczytu dla tego okresu. " + opis
    opis += " Obrót w wybranej walucie, bez przeliczeń; przed kosztami i zwrotami."
    if any(r.zrodlo == "PrestaShop" for r in raporty):
        opis += " PrestaShop: zamówienia oznaczone przez sklep jako ważne (valid=1)."
    latest = tuple(
        sorted(
            rows,
            key=lambda r: datetime.fromisoformat(r.kiedy.replace("Z", "+00:00")).timestamp(),
            reverse=True,
        )[:20]
    )
    return PodsumowanieZamowien(
        len(rows) if full else None, text if full and valid else "—", latest, codes, opis
    )
