"""Jawne uruchomienie sprzedaży; trwała komenda przed PUT i odczyt po niepewnym wyniku."""

import hashlib
import re
from collections.abc import Callable
from dataclasses import dataclass, replace
from typing import Protocol
from uuid import uuid4

from vexlab.przypadki_uzycia.allegro import BladAllegro, CzasMonotoniczny, SesjaAllegro


@dataclass(frozen=True)
class SzkicPublikacji:
    ident: str
    tytul: str
    cena: str
    waluta: str
    ilosc: int
    status: str
    odcisk: str
    blad: str = ""


@dataclass(frozen=True)
class PlanPublikacji:
    konto: str
    srodowisko: str
    oferty: tuple[SzkicPublikacji, ...]


@dataclass(frozen=True)
class WynikPublikacji:
    ident: str
    stan: str
    opis: str = ""


class APIPublikacji(Protocol):
    def odczytaj_publikacje(self, s: SesjaAllegro, ident: str) -> SzkicPublikacji: ...
    def zlec_publikacje(self, s: SesjaAllegro, ident: str, komenda: str) -> None: ...
    def raport_publikacji(self, s: SesjaAllegro, ident: str, komenda: str) -> str | None: ...


class RejestrPublikacji(Protocol):
    def odczytaj(self, klucz: str) -> str | None: ...
    def rozpocznij(self, klucz: str, komenda: str) -> None: ...
    def odrzuc(self, klucz: str, komenda: str) -> None: ...


class PublikujSzkiceAllegro:
    def __init__(
        self, api: APIPublikacji, rejestr: RejestrPublikacji, czas: CzasMonotoniczny
    ) -> None:
        self.api, self.rejestr, self.czas = api, rejestr, czas

    @staticmethod
    def klucz(s: SesjaAllegro, ident: str) -> str:
        return hashlib.sha256(f"{s.srodowisko.value}\0{s.konto.id}\0{ident}".encode()).hexdigest()

    def przygotuj(
        self,
        s: SesjaAllegro,
        ids: tuple[str, ...],
        stop: Callable[[], bool],
        postep: Callable[[int, int], None],
    ) -> PlanPublikacji:
        ids = tuple(dict.fromkeys(ids))
        if not 1 <= len(ids) <= 100 or any(re.fullmatch(r"[0-9]{1,100}", i) is None for i in ids):
            raise BladAllegro("WYBOR", "Wybierz od 1 do 100 ofert Allegro.")
        rows = []
        for i, ident in enumerate(ids):
            if stop():
                raise BladAllegro("ANULOWANO", "Zatrzymano sprawdzanie. Nie zlecono publikacji.")
            self._sesja(s)
            try:
                row = self.api.odczytaj_publikacje(s, ident)
                if row.status == "INACTIVE" and (row.ilosc <= 0 or not row.cena or not row.waluta):
                    row = replace(row, blad="Uzupełnij cenę, walutę i ilość większą od zera.")
                if self.rejestr.odczytaj(self.klucz(s, ident)) and row.status != "ACTIVE":
                    row = replace(
                        row, blad="Poprzednia publikacja wymaga odczytu. Kliknij Sprawdź wynik."
                    )
                rows.append(row)
            except BladAllegro as exc:
                rows.append(SzkicPublikacji(ident, "—", "", "", 0, "", "", str(exc)))
            postep(i + 1, len(ids))
        return PlanPublikacji(s.konto.id, s.srodowisko.value, tuple(rows))

    def wykonaj(
        self,
        s: SesjaAllegro,
        plan: PlanPublikacji,
        stop: Callable[[], bool],
        postep: Callable[[int, int], None],
        tylko_odczyt: bool = False,
    ) -> tuple[WynikPublikacji, ...]:
        if (plan.konto, plan.srodowisko) != (s.konto.id, s.srodowisko.value):
            raise BladAllegro("KONTO", "Plan dotyczy innego konta lub środowiska.")
        rows: list[WynikPublikacji] = []
        for i, row in enumerate(plan.oferty):
            if stop():
                rows.extend(
                    WynikPublikacji(p.ident, "Niewysłane", "Zatrzymano serię")
                    for p in plan.oferty[i:]
                )
                break
            rows.append(self._jedna(s, row, stop, tylko_odczyt))
            postep(i + 1, len(plan.oferty))
        return tuple(rows)

    def _sesja(self, s: SesjaAllegro) -> None:
        if not s.token or self.czas.teraz() >= s.wygasa:
            raise BladAllegro("SESJA", "Sesja wygasła. Połącz konto ponownie.")

    def _wynik(self, s: SesjaAllegro, row: SzkicPublikacji, key: str, cmd: str) -> WynikPublikacji:
        current = self.api.odczytaj_publikacje(s, row.ident)
        if current.status == "ACTIVE":
            return WynikPublikacji(row.ident, "Opublikowano")
        fail = self.api.raport_publikacji(s, row.ident, cmd)
        if fail is not None:
            self.rejestr.odrzuc(key, cmd)
            return WynikPublikacji(row.ident, "Błąd", fail)
        return WynikPublikacji(
            row.ident, "Do sprawdzenia", "Allegro przetwarza publikację. Sprawdź wynik."
        )

    def _jedna(
        self, s: SesjaAllegro, row: SzkicPublikacji, stop: Callable[[], bool], tylko_odczyt: bool
    ) -> WynikPublikacji:
        key, cmd, zapisano = self.klucz(s, row.ident), None, False
        try:
            self._sesja(s)
            cmd = self.rejestr.odczytaj(key)
            current = self.api.odczytaj_publikacje(s, row.ident)
            if current.status == "ACTIVE":
                return WynikPublikacji(row.ident, "Opublikowano" if cmd else "Już aktywna")
            if current.status == "ENDED":
                return WynikPublikacji(
                    row.ident, "Pominięto", "Oferta jest zakończona. Nie wznowiono sprzedaży."
                )
            if cmd:
                return self._wynik(s, row, key, cmd)
            if tylko_odczyt:
                return WynikPublikacji(row.ident, "Niewysłane", "Brak komendy publikacji w VexLab.")
            if row.blad or current.status != "INACTIVE":
                return WynikPublikacji(
                    row.ident, "Pominięto", row.blad or "Publikować można tylko szkice INACTIVE."
                )
            if current.odcisk != row.odcisk:
                return WynikPublikacji(
                    row.ident, "Błąd", "Dane zmieniły się. Sprawdź szkice ponownie."
                )
            if s.aplikacja is None or not s.aplikacja.zapis_szkicow:
                raise BladAllegro("UPRAWNIENIA", "Wymagana zgoda na zapis ofert Allegro.")
            if stop():
                return WynikPublikacji(row.ident, "Niewysłane")
            cmd = str(uuid4())
            self.rejestr.rozpocznij(key, cmd)
            zapisano = True
            if stop():
                self.rejestr.odrzuc(key, cmd)
                return WynikPublikacji(row.ident, "Niewysłane")
            self.api.zlec_publikacje(s, row.ident, cmd)
            return self._wynik(s, row, key, cmd)
        except BladAllegro as exc:
            if exc.kod == "ODRZUCONO" and zapisano and cmd:
                self.rejestr.odrzuc(key, cmd)
                return WynikPublikacji(row.ident, "Błąd", str(exc))
            return WynikPublikacji(row.ident, "Do sprawdzenia" if cmd else "Błąd", str(exc))
