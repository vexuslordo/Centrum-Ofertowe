"""Kopie zdjęć ofert w danych użytkownika, niezależne od oryginalnych plików."""

import hashlib
import os
from dataclasses import replace
from pathlib import Path
from tempfile import NamedTemporaryFile

from vexlab.adaptery.obraz import obraz
from vexlab.adaptery.zdjecia_lokalne import LokalneZdjecia
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.podglad_zdjec import ZrodloObrazu
from vexlab.przypadki_uzycia.zdjecia_ofert import lokalne_zdjecie
from vexlab.rdzen.kontrakty import BladTechniczny


class ZdjeciaOfert:
    def __init__(self, katalog: Path, https: ZrodloObrazu) -> None:
        self.katalog, self.https = katalog, https

    def importuj(self, pliki: tuple[Path, ...]) -> tuple[str, ...]:
        if not 1 <= len(pliki) <= 16:
            raise ValueError("Wybierz od 1 do 16 zdjęć.")
        return self._zapisz_kopie(LokalneZdjecia().odczytaj(pliki))

    def zapisz_kopie(self, zdjecia: tuple[ZdjecieDane, ...]) -> tuple[str, ...]:
        if not 1 <= len(zdjecia) <= 16:
            raise ValueError("Wybierz od 1 do 16 zdjęć.")
        return self._zapisz_kopie(tuple(obraz(z.dane, z.zrodlo) for z in zdjecia))

    def _zapisz_kopie(self, przygotowane: tuple[ZdjecieDane, ...]) -> tuple[str, ...]:
        urls = []
        for z in przygotowane:
            ident = hashlib.sha256(z.dane).hexdigest()
            ref = "vexlab-image:" + ident
            plik = self.katalog / (ident + ".jpg")
            tmp: Path | None = None
            try:
                self.katalog.mkdir(parents=True, exist_ok=True)
                if plik.exists():
                    self.pobierz_obraz(ref)
                else:
                    with NamedTemporaryFile(dir=self.katalog, delete=False) as f:
                        tmp = Path(f.name)
                        f.write(z.dane)
                        f.flush()
                        os.fsync(f.fileno())
                    os.replace(tmp, plik)
                urls.append(ref)
            except OSError as exc:
                raise BladTechniczny("Nie zapisano kopii zdjęcia w danych użytkownika.") from exc
            finally:
                if tmp is not None:
                    tmp.unlink(missing_ok=True)
        return tuple(dict.fromkeys(urls))

    def pobierz_obraz(self, adres: str) -> ZdjecieDane:
        if not lokalne_zdjecie(adres):
            return self.https.pobierz_obraz(adres)
        ident = adres.removeprefix("vexlab-image:")
        try:
            plik = self.katalog / (ident + ".jpg")
            if plik.is_symlink():
                raise ValueError("Dowiązanie")
            with plik.open("rb") as f:
                data = f.read(8 * 1024 * 1024 + 1)
            if hashlib.sha256(data).hexdigest() != ident:
                raise ValueError("Suma")
            return replace(obraz(data, adres), dane=data)
        except (OSError, ValueError) as exc:
            raise BladTechniczny(
                "Brakuje kopii zdjęcia oferty lub plik został zmieniony. Dodaj zdjęcie ponownie."
            ) from exc
