"""Raport porównania CSV: atomowość logiczna, BOM i ochrona pól tekstowych."""

import csv
from pathlib import Path

from vexlab.adaptery.eksport_csv import _pole
from vexlab.przypadki_uzycia.porownanie_cen_allegro import PorownanieCeny, RaportPorownaniaCen
from vexlab.rdzen.kontrakty import BladTechniczny


class EksportPorownaniaCenCSV:
    def zapisz(
        self, cel: Path, raport: RaportPorownaniaCen, pozycje: tuple[PorownanieCeny, ...]
    ) -> int:
        utworzono = False
        try:
            with cel.open("x", encoding="utf-8-sig", newline="") as f:
                utworzono = True
                writer = csv.writer(f, delimiter=";", quoting=csv.QUOTE_ALL, lineterminator="\r\n")
                writer.writerow(
                    (
                        "Konto",
                        "Środowisko",
                        "Cennik",
                        "Wersja",
                        "Odczyt UTC",
                        "SKU",
                        "Nazwa",
                        "ID Allegro",
                        "Stan",
                        "Docelowe brutto",
                        "Netto VAT23",
                        "Waluta cennika",
                        "Allegro brutto",
                        "Waluta Allegro",
                        "Różnica",
                        "Różnica %",
                        "Wynik",
                        "Powód",
                    )
                )
                for p in pozycje:
                    writer.writerow(
                        tuple(
                            _pole(v)[0]
                            for v in (
                                raport.login,
                                raport.srodowisko,
                                raport.cennik.nazwa,
                                str(raport.cennik.wersja),
                                raport.odczytano,
                                p.sku,
                                p.nazwa,
                                p.ident,
                                p.stan,
                                p.docelowa,
                                p.netto,
                                p.waluta_docelowa,
                                p.obecna,
                                p.waluta_obecna,
                                p.roznica,
                                p.procent,
                                p.wynik,
                                p.powod,
                            )
                        )
                    )
        except FileExistsError:
            raise BladTechniczny("Plik już istnieje. Wybierz nową nazwę raportu.") from None
        except (OSError, UnicodeError, csv.Error) as exc:
            if utworzono:
                try:
                    cel.unlink(missing_ok=True)
                except OSError as cleanup:
                    raise BladTechniczny(
                        "Pozostał niekompletny plik raportu. Nie używaj go jako eksportu."
                    ) from cleanup
            raise BladTechniczny("Nie zapisano kompletnego raportu porównania cen.") from exc
        return len(pozycje)
