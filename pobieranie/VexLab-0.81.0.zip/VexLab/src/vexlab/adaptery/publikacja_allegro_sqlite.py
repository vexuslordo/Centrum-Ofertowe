"""Techniczny dziennik komend: bez tokenów i treści; atomowe INSERT i warunkowe DELETE."""

import re
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from uuid import UUID

from vexlab.przypadki_uzycia.allegro import BladAllegro


class RejestrPublikacjiSQLite:
    def __init__(self, plik: Path) -> None:
        self.plik = plik

    @contextmanager
    def _polaczenie(self) -> Iterator[sqlite3.Connection]:
        conn = None
        try:
            self.plik.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(self.plik, timeout=5)
            if conn.execute("PRAGMA user_version").fetchone()[0] not in (0, 1):
                raise ValueError("Schemat rejestru")
            conn.execute(
                "CREATE TABLE IF NOT EXISTS proby (klucz TEXT PRIMARY KEY, komenda TEXT NOT NULL)"
            )
            conn.execute("PRAGMA user_version=1")
            yield conn
            conn.commit()
        except (sqlite3.Error, OSError, ValueError):
            raise BladAllegro(
                "REJESTR",
                "Nie można użyć rejestru publikacji. Zachowaj plik; nowa publikacja zablokowana.",
            ) from None
        finally:
            if conn is not None:
                conn.close()

    @staticmethod
    def _sprawdz(klucz: str, komenda: str | None = None) -> None:
        if re.fullmatch(r"[0-9a-f]{64}", klucz) is None:
            raise BladAllegro("REJESTR", "Nieprawidłowy klucz publikacji.")
        if komenda is not None:
            try:
                if str(UUID(komenda)) != komenda:
                    raise ValueError("UUID")
            except ValueError:
                raise BladAllegro("REJESTR", "Nieprawidłowa komenda publikacji.") from None

    def odczytaj(self, klucz: str) -> str | None:
        self._sprawdz(klucz)
        with self._polaczenie() as c:
            row = c.execute("SELECT komenda FROM proby WHERE klucz=?", (klucz,)).fetchone()
        if row is None:
            return None
        if not isinstance(row[0], str):
            raise BladAllegro("REJESTR", "Niepoprawny rejestr publikacji.")
        self._sprawdz(klucz, row[0])
        return str(row[0])

    def rozpocznij(self, klucz: str, komenda: str) -> None:
        self._sprawdz(klucz, komenda)
        with self._polaczenie() as c:
            c.execute("INSERT INTO proby VALUES (?,?)", (klucz, komenda))

    def odrzuc(self, klucz: str, komenda: str) -> None:
        self._sprawdz(klucz, komenda)
        with self._polaczenie() as c:
            c.execute("DELETE FROM proby WHERE klucz=? AND komenda=?", (klucz, komenda))
