"""Jawnie wybrany eksport lokalny, bez nadpisania istniejącego pliku."""

import csv
from pathlib import Path

from vexlab.adaptery.eksport_csv import _pole
from vexlab.przypadki_uzycia.opisy_zamowien import PLATNOSC, REALIZACJA, etykieta
from vexlab.przypadki_uzycia.zamowienia_allegro import (
    RaportZamowien,
    ZamowienieAllegro,
    stan_platnosci,
)
from vexlab.rdzen.kontrakty import BladTechniczny


class EksportZamowienCSV:
    def zapisz(self, cel: Path, raport: RaportZamowien, rows: tuple[ZamowienieAllegro, ...]) -> int:
        created = False
        try:
            with cel.open("x", encoding="utf-8-sig", newline="") as f:
                created = True
                w = csv.writer(f, delimiter=";", quoting=csv.QUOTE_ALL)
                w.writerow(
                    (
                        "Konto",
                        "Środowisko",
                        "Odczyt UTC",
                        "Zamówienie",
                        "Data zakupu",
                        "Produkt",
                        "SKU",
                        "Kupujący",
                        "Kwota",
                        "Dostawa",
                        "Status",
                        "Płatność",
                    )
                )
                for r in rows:
                    w.writerow(
                        tuple(
                            _pole(v)[0]
                            for v in (
                                raport.login,
                                raport.srodowisko,
                                raport.odczytano,
                                r.id,
                                r.kupiono,
                                " | ".join(p.nazwa for p in r.pozycje),
                                " | ".join(p.sku for p in r.pozycje),
                                r.kupujacy,
                                r.kwota,
                                r.dostawa,
                                etykieta(r.realizacja, REALIZACJA),
                                PLATNOSC[stan_platnosci(r)],
                            )
                        )
                    )
        except OSError:
            if created:
                try:
                    cel.unlink(missing_ok=True)
                except OSError:
                    raise BladTechniczny(
                        "Nie ukończono eksportu. Sprawdź częściowy plik."
                    ) from None
            raise BladTechniczny(
                "Nie zapisano eksportu. Wybierz nową nazwę i sprawdź dostęp do folderu."
            ) from None
        return len(rows)
