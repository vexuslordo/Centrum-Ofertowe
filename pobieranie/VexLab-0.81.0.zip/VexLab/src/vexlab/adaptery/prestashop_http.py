"""Ograniczony transport GET do skonfigurowanego sklepu, bez przekierowań."""

from base64 import b64encode
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener

from vexlab.przypadki_uzycia.prestashop import BladPresta, KonfiguracjaPresta, OdpowiedzPresta


class BezPrzekierowan(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
        return None


class HTTPSPresta:
    def pobierz(
        self, konfiguracja: KonfiguracjaPresta, zasob: str, parametry: dict[str, str]
    ) -> OdpowiedzPresta:
        k = konfiguracja.sprawdz()
        if zasob not in {
            "shops",
            "languages",
            "categories",
            "orders",
            "currencies",
            "order_states",
        } or not set(parametry) <= {
            "display",
            "limit",
            "sort",
            "id_shop",
            "language",
            "date",
            "filter[date_add]",
            "filter[id_shop]",
        }:
            raise BladPresta("ZASOB", "Niedozwolony odczyt Webservice.")
        url = k.adres + "api/" + zasob + "?" + urlencode(parametry)
        token = b64encode((k.klucz + ":").encode()).decode("ascii")
        request = Request(
            url,
            headers={
                "Authorization": "Basic " + token,
                "Accept": "application/xml",
                "User-Agent": "VexLab",
            },
            method="GET",
        )
        opener = build_opener(ProxyHandler({}), HTTPSHandler(), BezPrzekierowan())
        try:
            with opener.open(request, timeout=20) as response:
                dane = response.read(4 * 1024 * 1024 + 1)
                if len(dane) > 4 * 1024 * 1024:
                    raise BladPresta("ROZMIAR", "Odpowiedź sklepu przekracza limit rozmiaru.")
                return OdpowiedzPresta(response.status, dane)
        except HTTPError as exc:
            status = exc.code
            exc.close()
            return OdpowiedzPresta(status, b"")
        except (URLError, OSError, ValueError):
            raise BladPresta(
                "SIEC", "Brak odpowiedzi sklepu. Sprawdź adres HTTPS, certyfikat i połączenie."
            ) from None
