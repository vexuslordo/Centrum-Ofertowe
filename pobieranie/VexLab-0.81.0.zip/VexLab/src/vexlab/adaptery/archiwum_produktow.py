"""Przenośne dane katalogu, bez kont i sekretów; ZIP czytany bez rozpakowania."""

import hashlib
import json
import re
from dataclasses import asdict
from pathlib import Path
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile

from vexlab.adaptery.obraz import obraz
from vexlab.przypadki_uzycia.importowanie import CenaImportu
from vexlab.przypadki_uzycia.katalog import DaneDopasowania
from vexlab.przypadki_uzycia.katalog_uzytkownika import LIMIT, ProduktUzytkownika, blad
from vexlab.rdzen.kontrakty import BladTechniczny


class ArchiwumProduktowZIP:
    def zapisz(self, plik: Path, produkty: tuple[ProduktUzytkownika, ...]) -> None:
        if not 1 <= len(produkty) <= 500:
            raise blad("Paczka mieści od 1 do 500 produktów.")
        manifest, images = [], {}
        size = 0
        for p in produkty:
            p.sprawdz()
            row = asdict(p)
            photos = []
            for z in p.zdjecia:
                key = "zdjecia/" + hashlib.sha256(z.dane).hexdigest() + ".jpg"
                if key not in images:
                    size += len(z.dane)
                    if size > LIMIT:
                        raise blad("Eksport przekracza 128 MiB zdjęć.")
                    images[key] = z.dane
                photos.append({"plik": key, "zrodlo": z.zrodlo})
            row["zdjecia"] = photos
            manifest.append(row)
        data = json.dumps(
            {"format": "vexlab-produkty", "wersja": 1, "produkty": manifest}, ensure_ascii=False
        ).encode()
        if len(data) > 16 * 1024 * 1024:
            raise blad("Opisy przekraczają limit paczki. Wybierz mniej produktów.")
        created = False
        try:
            with ZipFile(plik, "x", ZIP_DEFLATED) as archive:
                created = True
                archive.writestr("katalog.json", data)
                for key, value in images.items():
                    archive.writestr(key, value)
        except FileExistsError as exc:
            raise blad("Plik już istnieje. Wybierz nową nazwę paczki.") from exc
        except (OSError, BadZipFile) as exc:
            if created:
                plik.unlink(missing_ok=True)
            raise BladTechniczny("Nie zapisano kompletnego eksportu produktów.") from exc

    def odczytaj(self, plik: Path) -> tuple[ProduktUzytkownika, ...]:
        try:
            if plik.stat().st_size > LIMIT + 16 * 1024 * 1024:
                raise ValueError("rozmiar")
            with ZipFile(plik) as z:
                infos = z.infolist()
                names = [i.filename for i in infos]
                if (
                    not 1 <= len(infos) <= 2501
                    or len(set(names)) != len(names)
                    or "katalog.json" not in names
                    or sum(i.file_size for i in infos) > LIMIT + 16 * 1024 * 1024
                ):
                    raise ValueError("struktura")
                for i in infos:
                    if i.flag_bits & 1 or i.file_size < 0:
                        raise ValueError("szyfrowanie")
                    if i.filename == "katalog.json":
                        if i.file_size > 16 * 1024 * 1024:
                            raise ValueError("manifest")
                    elif (
                        not re.fullmatch(r"zdjecia/[0-9a-f]{64}\.jpg", i.filename)
                        or i.file_size > 8 * 1024 * 1024
                    ):
                        raise ValueError("nazwa zdjęcia")
                document = json.loads(z.read("katalog.json"))
                if (
                    not isinstance(document, dict)
                    or set(document) != {"format", "wersja", "produkty"}
                    or document["format"] != "vexlab-produkty"
                    or document["wersja"] != 1
                ):
                    raise ValueError("format")
                rows = document["produkty"]
                if not isinstance(rows, list) or not 1 <= len(rows) <= 500:
                    raise ValueError("lista")
                output = []
                koszt = 0
                seen: set[str] = set()
                for row in rows:
                    if not isinstance(row, dict) or set(row) != {
                        "nazwa",
                        "sku",
                        "opis",
                        "ean",
                        "producent",
                        "producent_www",
                        "cena",
                        "zdjecia",
                        "dopasowania",
                        "dostepnosc",
                    }:
                        raise ValueError("pola")
                    for k in (
                        "nazwa",
                        "sku",
                        "opis",
                        "ean",
                        "producent",
                        "producent_www",
                        "dostepnosc",
                    ):
                        if not isinstance(row[k], str):
                            raise ValueError("tekst")
                    key = row["sku"].casefold()
                    if key in seen:
                        raise ValueError("SKU")
                    seen.add(key)
                    price = row["cena"]
                    if price is not None and (
                        not isinstance(price, dict)
                        or set(price) != {"tekst", "waluta", "rodzaj"}
                        or any(not isinstance(v, str) for v in price.values())
                    ):
                        raise ValueError("cena")
                    if not isinstance(row["zdjecia"], list) or len(row["zdjecia"]) > 5:
                        raise ValueError("zdjęcia")
                    photos = []
                    for photo in row["zdjecia"]:
                        if (
                            not isinstance(photo, dict)
                            or set(photo) != {"plik", "zrodlo"}
                            or not isinstance(photo["plik"], str)
                            or not isinstance(photo["zrodlo"], str)
                            or not re.fullmatch(r"zdjecia/[0-9a-f]{64}\.jpg", photo["plik"])
                        ):
                            raise ValueError("zdjęcie")
                        body = z.read(photo["plik"])
                        if hashlib.sha256(body).hexdigest() != photo["plik"][8:-4]:
                            raise ValueError("suma zdjęcia")
                        image = obraz(body, photo["zrodlo"])
                        koszt += len(image.dane) + len(image.miniatura)
                        if koszt > LIMIT:
                            raise ValueError("zdjęcia po normalizacji")
                        photos.append(image)
                    if not isinstance(row["dopasowania"], list) or len(row["dopasowania"]) > 500:
                        raise ValueError("dopasowania")
                    fits = []
                    for fit in row["dopasowania"]:
                        if (
                            not isinstance(fit, dict)
                            or set(fit) != {"marka", "model", "rok_od", "rok_do", "wariant"}
                            or any(not isinstance(v, str) for v in fit.values())
                        ):
                            raise ValueError("dopasowanie")
                        fits.append(DaneDopasowania(**fit))
                    product = ProduktUzytkownika(
                        row["nazwa"],
                        row["sku"],
                        row["opis"],
                        row["ean"],
                        row["producent"],
                        row["producent_www"],
                        CenaImportu(**price) if price else None,
                        tuple(photos),
                        tuple(fits),
                        row["dostepnosc"],
                    )
                    product.sprawdz()
                    output.append(product)
                return tuple(output)
        except (
            OSError,
            ValueError,
            KeyError,
            TypeError,
            UnicodeError,
            BadZipFile,
            RuntimeError,
        ) as exc:
            raise blad(
                "Nieprawidłowa lub uszkodzona paczka produktów VexLab. Nie zapisano danych."
            ) from exc
