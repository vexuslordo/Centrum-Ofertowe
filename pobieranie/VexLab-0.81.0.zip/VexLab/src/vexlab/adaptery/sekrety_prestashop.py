"""Osobny atomowy magazyn połączenia PrestaShop, wyłącznie zaszyfrowane bajty."""

import json
import os
import tempfile
from dataclasses import asdict
from pathlib import Path

from vexlab.adaptery.sekrety_allegro import LIMIT, Szyfrator
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.prestashop import BladPresta, KonfiguracjaPresta


class SekretyPresta:
    def __init__(self, plik: Path, szyfrator: Szyfrator) -> None:
        self.plik, self.szyfrator = plik, szyfrator

    def zapisz(self, konfiguracja: KonfiguracjaPresta) -> None:
        k = konfiguracja.sprawdz()
        temp: Path | None = None
        try:
            data = self.szyfrator.zaszyfruj(json.dumps({"wersja": 1, **asdict(k)}).encode())
            if not data or len(data) > LIMIT:
                raise BladPresta("MAGAZYN", "Nieprawidłowy wynik szyfrowania połączenia.")
            self.plik.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            with tempfile.NamedTemporaryFile(dir=self.plik.parent, delete=False) as f:
                temp = Path(f.name)
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp, self.plik)
        except (OSError, BladAllegro):
            raise BladPresta("MAGAZYN", "Nie zapisano bezpiecznie połączenia PrestaShop.") from None
        finally:
            if temp is not None:
                temp.unlink(missing_ok=True)

    def odczytaj(self) -> KonfiguracjaPresta | None:
        try:
            if not self.plik.exists():
                return None
            if not 0 < self.plik.stat().st_size <= LIMIT:
                raise ValueError()
            szyfr = self.plik.read_bytes()
            data = self.szyfrator.odszyfruj(szyfr)
            if len(data) > LIMIT:
                raise ValueError()
            d = json.loads(data)
            if not isinstance(d, dict) or type(d.get("wersja")) is not int or d["wersja"] != 1:
                raise ValueError()
            if set(d) != {"wersja", "adres", "klucz", "sklep", "jezyk", "kategoria"} or not all(
                isinstance(v, str) for key, v in d.items() if key != "wersja"
            ):
                raise ValueError()
            return KonfiguracjaPresta(
                d["adres"], d["klucz"], d["sklep"], d["jezyk"], d["kategoria"]
            ).sprawdz()
        except (OSError, ValueError, TypeError, KeyError, RecursionError, BladAllegro):
            raise BladPresta(
                "MAGAZYN",
                "Nie odczytano zapamiętanego połączenia PrestaShop. Wprowadź dane ponownie.",
            ) from None

    def usun(self) -> None:
        try:
            self.plik.unlink(missing_ok=True)
        except OSError:
            raise BladPresta(
                "MAGAZYN", "Nie usunięto zapamiętanego połączenia PrestaShop."
            ) from None
