"""Dziennik cen użytkownika; atomowa blokada oczekującej próby per konto/oferta."""

import json
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path

from vexlab.przypadki_uzycia.aktualizacja_cen_allegro import ProbaCeny
from vexlab.przypadki_uzycia.allegro import BladAllegro


class DziennikCenSQLite:
    def __init__(self, plik: Path) -> None:
        self.plik = plik

    @contextmanager
    def _db(self) -> Iterator[sqlite3.Connection]:
        db = None
        try:
            self.plik.parent.mkdir(parents=True, exist_ok=True)
            db = sqlite3.connect(self.plik, timeout=10)
            db.execute("PRAGMA synchronous=FULL")
            db.execute(
                "CREATE TABLE IF NOT EXISTS proby (id TEXT PRIMARY KEY, konto "
                "TEXT NOT NULL, srodowisko TEXT NOT NULL, oferta TEXT NOT NULL, "
                "oczekuje INTEGER NOT NULL, dane TEXT NOT NULL)"
            )
            db.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS oczekujaca ON "
                "proby(konto,srodowisko,oferta) WHERE oczekuje=1"
            )
            with db:
                yield db
        except (OSError, sqlite3.Error, ValueError, TypeError):
            raise BladAllegro(
                "REJESTR",
                "Nie można zapisać/odczytać dziennika cen lub oferta ma "
                "oczekującą próbę. Sprawdź Historię cen. Zachowano blokadę zapisu.",
            ) from None
        finally:
            if db is not None:
                db.close()

    def rozpocznij(self, p: ProbaCeny) -> None:
        with self._db() as db:
            db.execute(
                "INSERT INTO proby VALUES (?,?,?,?,?,?)",
                (
                    p.id,
                    p.konto,
                    p.srodowisko,
                    p.ident,
                    1,
                    json.dumps(asdict(p), ensure_ascii=False),
                ),
            )

    def zapisz(self, p: ProbaCeny) -> None:
        with self._db() as db:
            n = db.execute(
                "UPDATE proby SET oczekuje=?, dane=? WHERE id=? AND konto=? AND "
                "srodowisko=? AND oferta=?",
                (
                    int(p.status == "Do sprawdzenia"),
                    json.dumps(asdict(p), ensure_ascii=False),
                    p.id,
                    p.konto,
                    p.srodowisko,
                    p.ident,
                ),
            ).rowcount
            if n != 1:
                raise BladAllegro("REJESTR", "Nie znaleziono próby cen. Zachowaj dziennik.")

    def lista(self, konto: str, srodowisko: str) -> tuple[ProbaCeny, ...]:
        with self._db() as db:
            rows = db.execute(
                "SELECT dane FROM proby WHERE konto=? AND srodowisko=? ORDER BY rowid DESC",
                (konto, srodowisko),
            ).fetchall()
            return tuple(ProbaCeny(**json.loads(r[0])) for r in rows)
