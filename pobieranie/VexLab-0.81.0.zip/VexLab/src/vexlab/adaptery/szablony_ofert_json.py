"""Atomowe pliki nazwanych wartości w katalogu danych użytkownika."""

import hashlib
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile

from vexlab.przypadki_uzycia.szablony_ofert import sprawdz_szablon
from vexlab.rdzen.kontrakty import BladTechniczny


class SzablonyOfertJSON:
    def __init__(self, katalog: Path) -> None:
        self.katalog = katalog

    def _plik(self, rodzaj: str, nazwa: str) -> Path:
        sprawdz_szablon(rodzaj, nazwa, "x")
        ident = hashlib.sha256(nazwa.strip().casefold().encode()).hexdigest()
        return self.katalog / rodzaj / (ident + ".json")

    def lista(self, rodzaj: str) -> tuple[tuple[str, str], ...]:
        sprawdz_szablon(rodzaj, "x", "x")
        try:
            rows = []
            for i, plik in enumerate(sorted((self.katalog / rodzaj).glob("*.json"))):
                if i >= 500 or plik.is_symlink():
                    raise ValueError("Limit lub dowiązanie")
                with plik.open("rb") as f:
                    raw = f.read(32769)
                if len(raw) > 32768:
                    raise ValueError("Rozmiar")
                d = json.loads(raw)
                if not isinstance(d, dict) or d.get("wersja") != 1 or d.get("rodzaj") != rodzaj:
                    raise ValueError("Format")
                nazwa, wartosc = d["nazwa"], d["wartosc"]
                if not isinstance(nazwa, str) or not isinstance(wartosc, str):
                    raise ValueError("Pola")
                sprawdz_szablon(rodzaj, nazwa, wartosc)
                if self._plik(rodzaj, nazwa) != plik:
                    raise ValueError("Identyfikator")
                rows.append((nazwa, wartosc))
            return tuple(sorted(rows, key=lambda row: row[0].casefold()))
        except (OSError, ValueError, TypeError, KeyError, RecursionError) as exc:
            raise BladTechniczny(
                "Nie można odczytać zapisanych wartości. "
                "Pliki zachowano; możesz wpisać dane ręcznie."
            ) from exc

    def zapisz(self, rodzaj: str, nazwa: str, wartosc: str) -> None:
        nazwa = nazwa.strip()
        sprawdz_szablon(rodzaj, nazwa, wartosc)
        rows = self.lista(rodzaj)
        if len(rows) >= 500 and not any(n.casefold() == nazwa.casefold() for n, _ in rows):
            raise ValueError("Zapisano już 500 wartości. Usuń niepotrzebną pozycję.")
        plik = self._plik(rodzaj, nazwa)
        tmp: Path | None = None
        try:
            plik.parent.mkdir(parents=True, exist_ok=True)
            with NamedTemporaryFile(mode="w", encoding="utf-8", dir=plik.parent, delete=False) as f:
                tmp = Path(f.name)
                json.dump(
                    {"wersja": 1, "rodzaj": rodzaj, "nazwa": nazwa, "wartosc": wartosc},
                    f,
                    ensure_ascii=False,
                )
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, plik)
        except OSError as exc:
            raise BladTechniczny(
                "Nie zapisano własnej wartości. Sprawdź dostęp do katalogu danych."
            ) from exc
        finally:
            if tmp is not None:
                tmp.unlink(missing_ok=True)

    def usun(self, rodzaj: str, nazwa: str) -> None:
        try:
            self._plik(rodzaj, nazwa).unlink(missing_ok=True)
        except OSError as exc:
            raise BladTechniczny("Nie usunięto zapisanej wartości.") from exc
