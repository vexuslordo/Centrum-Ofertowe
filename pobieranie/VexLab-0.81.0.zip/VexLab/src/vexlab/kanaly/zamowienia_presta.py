"""PrestaShop 1.6 Webservice: ograniczony odczyt zamówień, walut i etykiet."""

from collections.abc import Callable
from datetime import datetime
from decimal import Decimal, InvalidOperation
from xml.etree.ElementTree import Element, ParseError  # nosec B405

from defusedxml import ElementTree as XML  # type: ignore[import-untyped]
from defusedxml.common import DefusedXmlException  # type: ignore[import-untyped]

from vexlab.kanaly.prestashop import PrestaAPI
from vexlab.przypadki_uzycia.prestashop import BladPresta, KonfiguracjaPresta
from vexlab.przypadki_uzycia.zamowienia_dashboardu import RaportZamowienKanalu, ZamowienieDashboardu


class ZamowieniaPrestaAPI(PrestaAPI):
    def _lista(
        self, k: KonfiguracjaPresta, zasob: str, params: dict[str, str]
    ) -> tuple[Element, ...]:
        reply = self.transport.pobierz(k, zasob, params)
        if reply.status in (401, 403):
            raise BladPresta(
                "UPRAWNIENIA", f"Nadaj kluczowi Webservice uprawnienie GET do {zasob}."
            )
        if reply.status != 200:
            raise BladPresta("HTTP", f"Nie odczytano {zasob} (HTTP {reply.status}).")
        if len(reply.dane) > 4 * 1024 * 1024:
            raise BladPresta("ROZMIAR", "Odpowiedź sklepu jest zbyt duża.")
        try:
            root = XML.fromstring(
                reply.dane, forbid_dtd=True, forbid_entities=True, forbid_external=True
            )
            group = root.find(zasob)
            if root.tag != "prestashop" or group is None:
                raise ValueError("lista")
            return tuple(group)
        except (ParseError, DefusedXmlException, ValueError, RecursionError):
            raise BladPresta("ODPOWIEDZ", "Nieprawidłowa odpowiedź zamówień sklepu.") from None

    @staticmethod
    def _pole(row: Element, name: str, limit: int = 512) -> str:
        value = (row.findtext(name, "") or "").strip()
        if len(value) > limit:
            raise ValueError("pole")
        return value

    def zamowienia(
        self, k: KonfiguracjaPresta, od: datetime, do: datetime, stop: Callable[[], bool]
    ) -> RaportZamowienKanalu:
        if stop():
            raise BladPresta("PRZERWANO", "Przerwano odczyt zamówień sklepu.")
        try:
            currencies = {
                r.findtext("id", ""): self._pole(r, "iso_code", 3)
                for r in self._wiersze(k, "currencies", "[id,iso_code]")
            }
            try:
                states = {
                    r.findtext("id", ""): self._nazwa(r, k.jezyk)
                    for r in self._wiersze(k, "order_states", "[id,name]")
                }
            except BladPresta as e:
                if e.kod != "UPRAWNIENIA":
                    raise
                states = {}
            result, ids = [], set()
            for offset in range(0, 20000, 200):
                if stop():
                    raise BladPresta("PRZERWANO", "Przerwano odczyt zamówień sklepu.")
                page = self._lista(
                    k,
                    "orders",
                    {
                        "display": (
                            "[id,reference,id_customer,id_currency,current_state,"
                            "total_paid_tax_incl,valid,date_add,id_shop]"
                        ),
                        "limit": f"{offset},200",
                        "sort": "[id_DESC]",
                        "date": "1",
                        "filter[date_add]": f"[{od.astimezone():%Y-%m-%d %H:%M:%S},"
                        f"{do.astimezone():%Y-%m-%d %H:%M:%S}]",
                        "filter[id_shop]": k.sklep,
                    },
                )
                if len(page) > 200:
                    raise ValueError("strony")
                for row in page:
                    ident = self._pole(row, "id", 10)
                    if (
                        not ident.isascii()
                        or not ident.isdigit()
                        or int(ident) <= 0
                        or ident in ids
                    ):
                        raise ValueError("id")
                    if self._pole(row, "id_shop", 10) != k.sklep:
                        raise ValueError("sklep")
                    ids.add(ident)
                    value = Decimal(self._pole(row, "total_paid_tax_incl", 24))
                    if not value.is_finite() or not 0 <= value <= 999999999:
                        raise ValueError("kwota")
                    currency = currencies.get(self._pole(row, "id_currency", 10), "")
                    if len(currency) != 3 or not currency.isascii() or not currency.isalpha():
                        raise ValueError("waluta")
                    date = datetime.fromisoformat(self._pole(row, "date_add", 32)).astimezone()
                    if not od <= date <= do:
                        raise ValueError("data")
                    state = self._pole(row, "current_state", 10)
                    valid = self._pole(row, "valid", 1)
                    if valid not in ("0", "1"):
                        raise ValueError("valid")
                    result.append(
                        ZamowienieDashboardu(
                            self._pole(row, "reference", 100) or ident,
                            "PrestaShop",
                            "Klient #" + self._pole(row, "id_customer", 10),
                            str(value),
                            currency,
                            states.get(state, "Status #" + state),
                            date.isoformat(),
                            valid == "1",
                        )
                    )
                if len(page) < 200:
                    return RaportZamowienKanalu(
                        "PrestaShop",
                        od.isoformat(),
                        do.isoformat(),
                        datetime.now().astimezone().isoformat(),
                        tuple(result),
                    )
            raise BladPresta("LIMIT", "Sklep przekroczył 20 000 zamówień. Zmniejsz zakres odczytu.")
        except (ValueError, TypeError, InvalidOperation):
            raise BladPresta(
                "ODPOWIEDZ",
                "Nieprawidłowe dane zamówienia sklepu. Nie przyjęto częściowego odczytu.",
            ) from None
