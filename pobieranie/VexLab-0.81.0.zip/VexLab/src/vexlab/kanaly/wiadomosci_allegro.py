"""Publiczne v1: wyłącznie GET wątków i wiadomości. Treść pozostaje w RAM."""

from datetime import datetime
from typing import Any
from urllib.parse import urlencode

from vexlab.kanaly.allegro import AllegroAPI, tekst
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.wiadomosci_allegro import (
    ROZMIAR_STRONY,
    StronaWatkow,
    StronaWiadomosci,
    WatekAllegro,
    WiadomoscAllegro,
    sprawdz_id,
)


def _bool(d: dict[str, Any], pole: str) -> bool:
    v = d[pole]
    if type(v) is not bool:
        raise ValueError(pole)
    return v


def _data(v: object) -> str:
    if not isinstance(v, str) or len(v) > 50:
        raise ValueError("data")
    parsed = datetime.fromisoformat(v.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("strefa")
    return v


def _tresc(v: object, limit: int) -> str:
    # Wiadomości mogą zawierać nowe linie; nie interpretujemy HTML ani sekwencji sterujących.
    if (
        not isinstance(v, str)
        or len(v) > limit
        or any(ord(c) < 32 and c not in "\n\r\t" for c in v)
    ):
        raise ValueError("tekst")
    return v


def _wiadomosc(d: dict[str, Any], ident: str) -> WiadomoscAllegro:
    mid = tekst(d, "id", 200)
    sprawdz_id(mid)
    if d["thread"]["id"] != ident:
        raise ValueError("watek")
    attachments = d.get("attachments", [])
    if not isinstance(attachments, list) or len(attachments) > 100:
        raise ValueError("zalaczniki")
    return WiadomoscAllegro(
        mid,
        ident,
        tekst(d["author"], "login", 200),
        _bool(d["author"], "isInterlocutor"),
        _data(d["createdAt"]),
        tekst(d, "status", 100),
        _tresc(d["text"], 1_000_000),
        _tresc(d.get("subject") or "", 5000),
        tuple(tekst(a, "fileName", 1000) for a in attachments),
        _bool(d, "hasAdditionalAttachments"),
    )


class WiadomosciAllegroAPI(AllegroAPI):
    def _strona(self, s: SesjaAllegro, path: str, pole: str, offset: int) -> list[dict[str, Any]]:
        try:
            d = self._get(
                s.srodowisko,
                s.token,
                path + "?" + urlencode({"limit": ROZMIAR_STRONY, "offset": offset}),
            )
        except BladAllegro as blad:
            if blad.kod == "UPRAWNIENIA":
                raise BladAllegro(
                    "UPRAWNIENIA",
                    "Allegro odmówiło odczytu wiadomości. "
                    "Włącz allegro:api:messaging i połącz konto ponownie.",
                ) from None
            raise
        rows = d.get(pole)
        if (
            not isinstance(rows, list)
            or len(rows) > ROZMIAR_STRONY
            or any(not isinstance(row, dict) for row in rows)
            or type(d.get("offset")) is not int
            or d["offset"] != offset
            or type(d.get("limit")) is not int
            or d["limit"] != ROZMIAR_STRONY
        ):
            raise ValueError("strona")
        return rows

    def watki(self, s: SesjaAllegro, offset: int) -> StronaWatkow:
        try:
            rows = self._strona(s, "/messaging/threads", "threads", offset)
            wynik = []
            for d in rows:
                ident = tekst(d, "id", 200)
                sprawdz_id(ident)
                interlocutor = d.get("interlocutor")
                login = "" if interlocutor is None else tekst(interlocutor, "login", 200)
                ostatnia = (
                    "" if d.get("lastMessageDateTime") is None else _data(d["lastMessageDateTime"])
                )
                wynik.append(WatekAllegro(ident, login, _bool(d, "read"), ostatnia))
            if len({r.id for r in wynik}) != len(wynik):
                raise ValueError("duplikat")
            return StronaWatkow(tuple(wynik), offset)
        except (ValueError, TypeError, KeyError, AttributeError):
            raise BladAllegro("ODPOWIEDZ", "Nieprawidłowa lista rozmów Allegro.") from None

    def wiadomosci(self, s: SesjaAllegro, ident: str, offset: int) -> StronaWiadomosci:
        sprawdz_id(ident)
        try:
            rows = self._strona(s, "/messaging/threads/" + ident + "/messages", "messages", offset)
            wynik = tuple(_wiadomosc(d, ident) for d in rows)
            if len({r.id for r in wynik}) != len(wynik):
                raise ValueError("duplikat")
            return StronaWiadomosci(wynik, offset)
        except (ValueError, TypeError, KeyError, AttributeError):
            raise BladAllegro("ODPOWIEDZ", "Nieprawidłowa treść rozmowy Allegro.") from None
