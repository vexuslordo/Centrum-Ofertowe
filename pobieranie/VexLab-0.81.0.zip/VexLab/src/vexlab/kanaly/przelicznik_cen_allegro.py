"""Mapowanie odczytu reguł i przypisań, według publicznego OpenAPI Allegro."""

import re
from typing import Any

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.przelicznik_cen_allegro import PrzelicznikCen, RegulaKursowa


def reguly_kursowe(d: dict[str, Any]) -> tuple[RegulaKursowa, ...]:
    try:
        rows = d["rules"]
        if not isinstance(rows, list) or len(rows) > 1000:
            raise ValueError("rules")
        wynik = []
        seen = set()
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError("rule")
            if row.get("type") != "EXCHANGE_RATE" or row.get("default") is not True:
                continue
            ident, nazwa = row["id"], row["name"]
            if (
                not isinstance(ident, str)
                or not re.fullmatch(r"[A-Za-z0-9-]{1,100}", ident)
                or ident in seen
                or not isinstance(nazwa, str)
                or not nazwa.strip()
                or len(nazwa) > 200
                or row.get("configuration") is not None
            ):
                raise ValueError("reguła kursowa")
            seen.add(ident)
            wynik.append(RegulaKursowa(ident, nazwa))
        return tuple(wynik)
    except (ValueError, KeyError, TypeError):
        raise BladAllegro("PRZELICZNIK", "Niepoprawna lista reguł cenowych Allegro.") from None


def potwierdz_przelicznik(d: dict[str, Any], u: PrzelicznikCen) -> bool:
    rows = d.get("rules")
    if not isinstance(rows, list) or len(rows) > 100:
        raise BladAllegro("PRZELICZNIK", "Niepełny odczyt przypisanych reguł cenowych.")
    przypisane = {}
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("marketplace"), dict):
            raise BladAllegro("PRZELICZNIK", "Niepoprawny odczyt przypisanej reguły cenowej.")
        rynek = row["marketplace"].get("id")
        rule = row.get("rule")
        if not isinstance(rynek, str) or rynek in przypisane or not isinstance(rule, dict):
            raise BladAllegro("PRZELICZNIK", "Niejednoznaczne przypisanie reguł cenowych.")
        przypisane[rynek] = rule.get("id")
    return all(przypisane.get(r) == u.regula for r in u.rynki)
