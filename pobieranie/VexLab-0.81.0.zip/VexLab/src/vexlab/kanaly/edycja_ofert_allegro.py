"""Mapowanie edycji pól i jawnej zmiany produktu istniejącej oferty Allegro."""

from collections.abc import Callable
from copy import deepcopy
from typing import Any
from uuid import UUID

from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.kanaly.szkic_allegro import mapuj_oferte
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.edycja_ofert_allegro import OfertaEdycji, ZmianaOferty, skrot
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import PrzyjecieZapisu

GTIN = "225693"
OCHRONA = (
    "sellingMode",
    "stock",
    "delivery",
    "afterSalesServices",
    "payments",
    "location",
    "taxSettings",
    "description",
    "images",
    "additionalMarketplaces",
    "compatibilityList",
    "tecdocSpecification",
    "attachments",
    "parameters",
)


def parametry(d: dict[str, Any]) -> list[dict[str, Any]]:
    rows = d.get("parameters") or []
    if not isinstance(rows, list) or any(not isinstance(p, dict) for p in rows):
        raise BladAllegro("ODPOWIEDZ", "Niepoprawne parametry produktu.")
    return rows


def ean_produktu(d: dict[str, Any]) -> str:
    rows = [p for p in parametry(d) if p.get("id") == GTIN]
    if not rows:
        return ""
    vals = rows[0].get("values") or []
    if not isinstance(vals, list) or not vals or any(not isinstance(v, str) for v in vals):
        raise BladAllegro("EAN", "Produkt ma niejednoznaczny EAN.")
    return " / ".join(vals)


class EdycjaOfertAPI(NoweSzkiceAPI):
    @staticmethod
    def _sprawdz_pola(pola: dict[str, object]) -> None:
        if not pola or not set(pola) <= {"name", "external", "productSet", "description", "images"}:
            raise BladAllegro("POLA", "Niedozwolone pola edycji oferty.")

    def _raw(self, s: SesjaAllegro, ident: str) -> dict[str, Any]:
        return self._get(s.srodowisko, s.token, self._sciezka(ident))

    def _mapuj(self, s: SesjaAllegro, d: dict[str, Any], ident: str) -> OfertaEdycji:
        mapped = mapuj_oferte(d, ident)
        rows = d.get("productSet") or []
        if not isinstance(rows, list) or any(
            not isinstance(r, dict) or not isinstance(r.get("product"), dict) for r in rows
        ):
            raise BladAllegro("ODPOWIEDZ", "Niepoprawne powiązanie produktu.")
        product = rows[0].get("product", {}) if len(rows) == 1 else {}
        pid = product.get("id") or ""
        if pid:
            try:
                UUID(pid)
            except (ValueError, TypeError, AttributeError):
                raise BladAllegro("ODPOWIEDZ", "Niepoprawny identyfikator produktu.") from None
        ean = ean_produktu(product)
        if pid and not ean:
            detail = self._get(s.srodowisko, s.token, "/sale/products/" + pid)
            ean = ean_produktu(detail)
        guard = {k: d.get(k) for k in OCHRONA}
        guard["productSet"] = [
            {
                **{k: v for k, v in row.items() if k != "product"},
                "parameters": [
                    p for p in parametry(row.get("product") or {}) if p.get("id") != GTIN
                ],
            }
            for row in rows
        ]
        return OfertaEdycji(
            ident,
            mapped.tytul,
            mapped.sku,
            ean,
            pid,
            mapped.kategoria,
            mapped.status.value,
            skrot({k: v for k, v in d.items() if k not in {"validation", "updatedAt"}}),
            skrot(guard),
            skrot([s.srodowisko.value, s.konto.id]),
            len(rows) == 1
            and not d.get("compatibilityList")
            and not d.get("tecdocSpecification")
            and not (
                set(rows[0])
                - {
                    "product",
                    "quantity",
                    "responsiblePerson",
                    "responsibleProducer",
                    "safetyInformation",
                    "marketedBeforeGPSRObligation",
                }
            ),
        )

    def odczytaj_edycje(self, s: SesjaAllegro, ident: str) -> OfertaEdycji:
        return self._mapuj(s, self._raw(s, ident), ident)

    def produkt_ean(self, s: SesjaAllegro, ean: str, kategoria: str) -> tuple[str, str]:
        candidates = self.znajdz_produkty(s, ean, True)
        if len(candidates) != 1 or candidates[0].kategoria != kategoria:
            raise BladAllegro("EAN", "EAN wymaga jednego produktu w tej samej kategorii Allegro.")
        product = candidates[0]
        d = self._get(s.srodowisko, s.token, "/sale/products/" + product.id)
        if (
            d.get("id") != product.id
            or (d.get("category") or {}).get("id") != kategoria
            or ean_produktu(d) != ean
        ):
            raise BladAllegro("EAN", "Produkt nie potwierdza wskazanego kodu EAN.")
        return product.id, product.nazwa

    def zmien_oferte(
        self, s: SesjaAllegro, z: ZmianaOferty, aktualne: Callable[[], bool]
    ) -> PrzyjecieZapisu:
        d = self._raw(s, z.baza.ident)
        if self._mapuj(s, d, z.baza.ident) != z.baza:
            raise BladAllegro("KONFLIKT", "Oferta zmieniła się przed wysłaniem. Pobierz podgląd.")
        fields: dict[str, object] = {}
        if z.tytul != z.baza.tytul:
            fields["name"] = z.tytul
        if z.sku != z.baza.sku:
            fields["external"] = {"id": z.sku or None}
        if z.ean != z.baza.ean:
            rows = deepcopy(d.get("productSet") or [])
            allowed = {
                "product",
                "quantity",
                "responsiblePerson",
                "responsibleProducer",
                "safetyInformation",
                "marketedBeforeGPSRObligation",
            }
            if (
                len(rows) != 1
                or set(rows[0]) - allowed
                or d.get("compatibilityList")
                or d.get("tecdocSpecification")
            ):
                raise BladAllegro(
                    "POLA",
                    "Zmianę EAN zestawu/dopasowań wykonaj w Allegro. "
                    "Tytuł/SKU można edytować tutaj.",
                )
            product = rows[0]["product"]
            parameters = [p for p in parametry(product) if p.get("id") != GTIN]
            parameters.append({"id": GTIN, "values": [z.ean]})
            rows[0]["product"] = {"id": z.produkt, "parameters": parameters}
            # Odpowiedź GPSR może zawierać rozwinięte dane zamiast referencji requestu.
            person = rows[0].get("responsiblePerson")
            if isinstance(person, dict):
                rows[0]["responsiblePerson"] = {"id": person["id"]}
            producer = rows[0].get("responsibleProducer")
            if isinstance(producer, dict):
                rows[0]["responsibleProducer"] = {"type": "ID", "id": producer["id"]}
            fields.update(
                productSet=rows,
                name=z.tytul,
                description=d.get("description"),
                images=d.get("images"),
            )
        if not aktualne():
            raise BladAllegro("KONTO", "Zmieniono konto. Nie wysłano zmian.")
        return self.zmien_szkic(s, z.baza.ident, fields)
