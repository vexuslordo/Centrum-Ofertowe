"""Mapowanie Webservice XML PrestaShop 1.6, tylko odczyt."""

from xml.etree.ElementTree import Element, ParseError  # nosec B405

from defusedxml import ElementTree as XML  # type: ignore[import-untyped]
from defusedxml.common import DefusedXmlException  # type: ignore[import-untyped]

from vexlab.przypadki_uzycia.prestashop import (
    BladPresta,
    KategoriaPresta,
    KonfiguracjaPresta,
    PozycjaPresta,
    SlownikiPresta,
    TransportPresta,
)


class PrestaAPI:
    def __init__(self, transport: TransportPresta) -> None:
        self.transport = transport

    def _wiersze(self, k: KonfiguracjaPresta, zasob: str, pola: str) -> tuple[Element, ...]:
        wynik: list[Element] = []
        ids: set[str] = set()
        for offset in range(0, 50000, 200):
            params = {"display": pola, "limit": f"{offset},200", "sort": "[id_ASC]"}
            if zasob == "categories":
                params.update({"id_shop": k.sklep, "language": k.jezyk})
            r = self.transport.pobierz(k, zasob, params)
            if r.status in (401, 403):
                raise BladPresta(
                    "UPRAWNIENIA",
                    f"Brak dostępu do {zasob}. Włącz uprawnienie GET w kluczu Webservice.",
                )
            if r.status == 429:
                raise BladPresta(
                    "LIMIT", "Sklep ograniczył liczbę żądań. Spróbuj ponownie później."
                )
            if r.status != 200:
                raise BladPresta(
                    "HTTP",
                    f"Nie pobrano {zasob} (HTTP {r.status}). "
                    "Sprawdź adres i dostępność Webservice.",
                )
            if len(r.dane) > 4 * 1024 * 1024:
                raise BladPresta("ROZMIAR", "Odpowiedź sklepu jest zbyt duża.")
            try:
                root = XML.fromstring(
                    r.dane, forbid_dtd=True, forbid_entities=True, forbid_external=True
                )
            except (ParseError, DefusedXmlException, ValueError, RecursionError):
                raise BladPresta(
                    "ODPOWIEDZ", "Sklep nie zwrócił prawidłowego XML Webservice."
                ) from None
            grupa = root.find(zasob)
            if root.tag != "prestashop" or grupa is None:
                raise BladPresta("ODPOWIEDZ", f"Brak listy {zasob} w odpowiedzi Webservice.")
            rows = list(grupa)
            if len(rows) > 200:
                raise BladPresta(
                    "STRONY", "Sklep nie respektuje stronicowania. Lista nie została przyjęta."
                )
            for row in rows:
                ident = row.findtext("id", "")
                if (
                    not 1 <= len(ident) <= 10
                    or not ident.isascii()
                    or not ident.isdigit()
                    or int(ident) <= 0
                    or ident in ids
                ):
                    raise BladPresta(
                        "STRONY",
                        "Nieprawidłowe lub powtórzone ID w odpowiedzi sklepu. Odśwież listę.",
                    )
                ids.add(ident)
                wynik.append(row)
            if len(rows) < 200:
                return tuple(wynik)
        raise BladPresta(
            "LIMIT", "Lista przekracza 50 000 pozycji. Nie pokazano niepełnego wyniku."
        )

    @staticmethod
    def _nazwa(row: Element, jezyk: str = "") -> str:
        name = row.find("name")
        if name is None:
            raise BladPresta("ODPOWIEDZ", "Brak nazwy w odpowiedzi sklepu.")
        if list(name):
            wybrany = next((n for n in name if n.get("id") == jezyk), None)
            if wybrany is None:
                raise BladPresta("JEZYK", "Sklep nie zwrócił nazwy w wybranym języku.")
            tekst = wybrany.text or ""
        else:
            tekst = name.text or ""
        if not tekst.strip() or len(tekst) > 512:
            raise BladPresta("ODPOWIEDZ", "Nieprawidłowa nazwa w odpowiedzi sklepu.")
        return tekst.strip()

    @staticmethod
    def _aktywna(row: Element) -> bool:
        wartosc = row.findtext("active", "")
        if wartosc not in ("0", "1"):
            raise BladPresta("ODPOWIEDZ", "Nieprawidłowy status w odpowiedzi sklepu.")
        return wartosc == "1"

    def slowniki(self, konfiguracja: KonfiguracjaPresta) -> SlownikiPresta:
        k = konfiguracja.sprawdz()

        def lista(zasob: str) -> tuple[PozycjaPresta, ...]:
            return tuple(
                PozycjaPresta(r.findtext("id", ""), self._nazwa(r), self._aktywna(r))
                for r in self._wiersze(k, zasob, "[id,name,active]")
            )

        wynik = SlownikiPresta(lista("shops"), lista("languages"))
        if not any(s.aktywna for s in wynik.sklepy) or not any(j.aktywna for j in wynik.jezyki):
            raise BladPresta("PUSTE", "Brak aktywnego sklepu lub języka w odpowiedzi Webservice.")
        return wynik

    def kategorie(self, konfiguracja: KonfiguracjaPresta) -> tuple[KategoriaPresta, ...]:
        k = konfiguracja.sprawdz()
        if not k.sklep or not k.jezyk:
            raise BladPresta("WYBOR", "Wybierz sklep i język.")
        wynik = []
        for row in self._wiersze(k, "categories", "[id,id_parent,name,active]"):
            rodzic = row.findtext("id_parent", "")
            if not 1 <= len(rodzic) <= 10 or not rodzic.isascii() or not rodzic.isdigit():
                raise BladPresta("ODPOWIEDZ", "Nieprawidłowy rodzic kategorii.")
            wynik.append(
                KategoriaPresta(
                    row.findtext("id", ""), rodzic, self._nazwa(row, k.jezyk), self._aktywna(row)
                )
            )
        return tuple(wynik)
