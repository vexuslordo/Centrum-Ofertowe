"""Wyłącznie cena brutto istniejącej oferty; bez publikacji i innych pól."""

import time
from collections.abc import Callable
from decimal import Decimal, InvalidOperation
from threading import Lock

from vexlab.kanaly.zapis_szkicu_allegro import ZapisSzkicuAPI
from vexlab.przypadki_uzycia.aktualizacja_cen_allegro import CenaOferty
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro, TransportAllegro
from vexlab.przypadki_uzycia.edycja_ofert_allegro import skrot
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import PrzyjecieZapisu


class CenyAllegroAPI(ZapisSzkicuAPI):
    def __init__(self, transport: TransportAllegro) -> None:
        super().__init__(transport)
        self._lock = Lock()
        self._kolejna_regula = 0.0

    def _reguly(self, s: SesjaAllegro, ident: str, rynek: str) -> list[dict[str, str]]:
        # Endpoint reguł dopuszcza 5 odczytów/s; bez automatycznych ponowień.
        with self._lock:
            time.sleep(max(0.0, self._kolejna_regula - time.monotonic()))
            try:
                d = self._get(
                    s.srodowisko, s.token, "/sale/price-automation/offers/" + ident + "/rules"
                )
            finally:
                self._kolejna_regula = time.monotonic() + 0.21
        rows = d.get("rules")
        if not isinstance(rows, list) or len(rows) > 100:
            raise BladAllegro("CENA", "Niepełny odczyt automatyzacji ceny. Nie wysłano zmiany.")
        result = []
        seen = set()
        for row in rows:
            try:
                market, rule = row["marketplace"]["id"], row["rule"]["id"]
                if (
                    not isinstance(market, str)
                    or not isinstance(rule, str)
                    or not rule
                    or market in seen
                ):
                    raise ValueError("regula")
            except (KeyError, TypeError, ValueError):
                raise BladAllegro("CENA", "Niepoprawny odczyt automatyzacji ceny.") from None
            if market == rynek:
                raise BladAllegro(
                    "CENA",
                    "Cena rynku głównego ma regułę automatyczną. "
                    "Zmień ją osobno w Allegro; program jej nie odpina.",
                )
            seen.add(market)
            result.append(
                {
                    "marketplace": market,
                    "rule": rule,
                    "configuration": str(row.get("configuration")),
                }
            )
        return sorted(result, key=lambda r: r["marketplace"])

    @staticmethod
    def _sprawdz_pola(pola: dict[str, object]) -> None:
        if set(pola) != {"sellingMode"}:
            raise BladAllegro("POLA", "Dozwolona wyłącznie zmiana ceny.")
        sm = pola["sellingMode"]
        if not isinstance(sm, dict) or set(sm) != {"price"}:
            raise BladAllegro("POLA", "Dozwolona wyłącznie zmiana ceny brutto.")
        price = sm["price"]
        if not isinstance(price, dict) or set(price) != {"amount", "currency"}:
            raise BladAllegro("POLA", "Niepoprawna cena.")

    def odczytaj_cene(self, s: SesjaAllegro, ident: str) -> CenaOferty:
        d = self._get(s.srodowisko, s.token, self._sciezka(ident))
        try:
            sm = d["sellingMode"]
            kwota, waluta = sm["price"]["amount"], sm["price"]["currency"]
            sku, stan = d["external"]["id"], d["publication"]["status"]
            rynek = d["publication"]["marketplaces"]["base"]["id"]
            if (
                d.get("id") != ident
                or sm.get("format") != "BUY_NOW"
                or sm.get("priceAutomation") not in (None, {}, {"rule": None})
                or not all(isinstance(v, str) for v in (kwota, waluta, sku, stan))
                or not isinstance(rynek, str)
                or not rynek
                or not sku.strip()
                or len(waluta) != 3
            ):
                raise ValueError("oferta")
            cena = Decimal(kwota)
            if (
                not cena.is_finite()
                or not 0 < cena <= 999999999
                or cena != cena.quantize(Decimal("0.01"))
            ):
                raise ValueError("kwota")
        except (KeyError, TypeError, ValueError, InvalidOperation):
            raise BladAllegro(
                "CENA",
                "Oferta wymaga stałej ceny Kup teraz, SKU i braku automatycznej "
                "reguły ceny głównej. Sprawdź w Allegro.",
            ) from None
        reguly = self._reguly(s, ident, rynek)
        return CenaOferty(
            ident,
            sku,
            stan,
            kwota,
            waluta,
            skrot([{k: v for k, v in d.items() if k not in {"validation", "updatedAt"}}, reguly]),
        )

    def zapisz_cene(
        self, s: SesjaAllegro, baza: CenaOferty, kwota: str, aktualne: Callable[[], bool]
    ) -> PrzyjecieZapisu:
        try:
            v = Decimal(kwota)
            if not v.is_finite() or not 0 < v <= 999999999 or v != v.to_integral_value():
                raise ValueError("kwota")
        except (InvalidOperation, ValueError):
            raise BladAllegro(
                "CENA", "Cena docelowa wymaga dodatniej pełnej kwoty brutto."
            ) from None
        if self.odczytaj_cene(s, baza.ident) != baza:
            raise BladAllegro(
                "KONFLIKT", "Oferta zmieniła się tuż przed zapisem. Nie wysłano ceny."
            )
        if not aktualne():
            raise BladAllegro("KONTO", "Zatrzymano serię lub zmieniono konto. Nie wysłano ceny.")
        return self.zmien_szkic(
            s,
            baza.ident,
            {"sellingMode": {"price": {"amount": format(v, ".2f"), "currency": baza.waluta}}},
        )
