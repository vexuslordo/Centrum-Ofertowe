"""Istniejący katalog, upload URL/JPEG i tworzenie wyłącznie INACTIVE według Swagger."""

import json
import re
import time
from hashlib import sha256
from typing import Any, cast
from urllib.parse import urlencode, urlsplit
from uuid import UUID

from vexlab.kanaly.allegro import hosty, tekst
from vexlab.kanaly.przelicznik_cen_allegro import potwierdz_przelicznik, reguly_kursowe
from vexlab.kanaly.ustawienia_sprzedazy_allegro import pobierz_slowniki
from vexlab.kanaly.vat_allegro import mapuj_vat
from vexlab.kanaly.zapis_szkicu_allegro import ZapisSzkicuAPI
from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    TransportAllegro,
)
from vexlab.przypadki_uzycia.duplikaty_allegro import IstniejacaOferta
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    KategoriaSzkicu,
    ParametrSzkicu,
    ProbaTworzenia,
    ProduktSzkicu,
    adres_zdjecia,
)
from vexlab.przypadki_uzycia.przelicznik_cen_allegro import (
    PrzelicznikCen,
    RegulaKursowa,
    polecenie_przelicznika,
)
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import SlownikiSprzedazy
from vexlab.przypadki_uzycia.vat_allegro import (
    UstawieniaVAT,
    VATKategorii,
    odczytaj_vat,
    sprawdz_vat,
)
from vexlab.przypadki_uzycia.zdjecia_ofert import PlikiZdjecOfert, lokalne_zdjecie


class NoweSzkiceAPI(ZapisSzkicuAPI):
    def __init__(
        self, transport: TransportAllegro, pliki_zdjec: PlikiZdjecOfert | None = None
    ) -> None:
        super().__init__(transport)
        self.pliki_zdjec = pliki_zdjec
        self._reguly: tuple[tuple[str, str, str], float, tuple[RegulaKursowa, ...]] | None = None
        self._vat: dict[tuple[str, str, str, str], tuple[float, VATKategorii]] = {}
        self._slowniki: tuple[tuple[str, str, str], float, SlownikiSprzedazy] | None = None
        self._kategorie: dict[tuple[str, str, str], tuple[float, ProduktSzkicu]] = {}

    def operacja_w_toku(self, s: SesjaAllegro, ident: str, operacja: str) -> bool:
        if not re.fullmatch(r"[A-Za-z0-9-]{1,100}", operacja):
            raise BladAllegro("ODCZYT", "Nieprawidłowe ID poprzedniej operacji.")
        if time.monotonic() < self.odczekaj.get((s.srodowisko.value, ident), 0):
            raise BladAllegro("PRZETWARZANIE", "Odczekaj zgodnie z Retry-After Allegro.")
        _, host = hosty(s.srodowisko)
        sciezka = self._sciezka(ident)
        r = self.transport_zapisu.wyslij(
            "GET", host + sciezka + "/operations/" + operacja, self._naglowki(s), None
        )
        if r.status == 202:
            self.odczekaj[(s.srodowisko.value, ident)] = time.monotonic() + r.odstep
            return True
        if r.status == 404 or (r.status == 303 and r.lokalizacja == host + sciezka):
            # 404 nie dowodzi odrzucenia; dalszą decyzję podejmuje jawnie operator.
            return False
        raise BladAllegro(
            "ODCZYT",
            f"Nie można sprawdzić poprzedniej operacji (HTTP {r.status}). Zachowano blokadę.",
        )

    def czy_istnieje_oferta(self, s: SesjaAllegro, ident: str) -> bool:
        _, host = hosty(s.srodowisko)
        r = self.transport_zapisu.wyslij(
            "GET", host + self._sciezka(ident), self._naglowki(s), None
        )
        if r.status == 404:
            return False
        if r.status == 200:
            return True
        raise BladAllegro(
            "ODCZYT",
            f"Nie można potwierdzić istnienia oferty (HTTP {r.status}). "
            "Nie odblokowano nowej próby.",
        )

    def reguly_kursowe(self, s: SesjaAllegro, odswiez: bool = False) -> tuple[RegulaKursowa, ...]:
        key = (s.srodowisko.value, s.konto.id, sha256(s.token.encode()).hexdigest())
        cache = self._reguly
        if not odswiez and cache and cache[0] == key and time.monotonic() - cache[1] < 30:
            return cache[2]
        self._reguly = None
        wynik = reguly_kursowe(self._get(s.srodowisko, s.token, "/sale/price-automation/rules"))
        self._reguly = (key, time.monotonic(), wynik)
        return wynik

    def przelicznik_potwierdzony(self, s: SesjaAllegro, ident: str, u: PrzelicznikCen) -> bool:
        self._sciezka(ident)
        return potwierdz_przelicznik(
            self._get(s.srodowisko, s.token, "/sale/price-automation/offers/" + ident + "/rules"), u
        )

    def przypnij_przelicznik(
        self, s: SesjaAllegro, ident: str, u: PrzelicznikCen, komenda: str
    ) -> None:
        self._sciezka(ident)
        UUID(komenda)
        _, host = hosty(s.srodowisko)
        try:
            r = self.transport_zapisu.wyslij(
                "POST",
                host + "/sale/offer-price-automation-commands",
                self._naglowki(s),
                json.dumps(polecenie_przelicznika(u, ident, komenda)).encode(),
            )
        except BladAllegro:
            raise BladAllegro(
                "NIEZNANY",
                "Nieznany wynik przypięcia przelicznika. Sprawdź wynik, nie ponawiaj polecenia.",
            ) from None
        if r.status not in {200, 201, 202}:
            raise BladAllegro(
                "PRZELICZNIK", f"Przelicznik cen: HTTP {r.status}. Sprawdź szczegóły operacji."
            )
        try:
            d = json.loads(r.dane)
            if not isinstance(d, dict) or d.get("id") != komenda:
                raise ValueError("id")
        except (ValueError, TypeError):
            raise BladAllegro(
                "NIEZNANY", "Nie potwierdzono ID operacji przelicznika. Sprawdź wynik."
            ) from None

    def wynik_przelicznika(self, s: SesjaAllegro, ident: str, komenda: str) -> str:
        self._sciezka(ident)
        UUID(komenda)
        d = self._get(
            s.srodowisko,
            s.token,
            "/sale/offer-price-automation-commands/" + komenda + "/tasks?limit=1000",
        )
        rows = d.get("tasks")
        if not isinstance(rows, list) or len(rows) > 1000:
            raise BladAllegro("PRZELICZNIK", "Niepełny wynik operacji przelicznika.")
        errors = []
        for row in rows:
            if not isinstance(row, dict) or not isinstance(row.get("offer"), dict):
                raise BladAllegro("PRZELICZNIK", "Niepoprawny wynik operacji przelicznika.")
            if row["offer"].get("id") != ident:
                raise BladAllegro("PRZELICZNIK", "Wynik operacji dotyczy innej oferty.")
            if row.get("status") == "FAIL":
                errors.append(str(row.get("message") or "Allegro odrzuciło przypięcie reguły."))
                szczegoly = row.get("errors") or []
                if not isinstance(szczegoly, list):
                    raise BladAllegro("PRZELICZNIK", "Niepoprawne szczegóły błędu reguły.")
                for error in szczegoly[:10]:
                    if isinstance(error, dict):
                        errors.append(
                            str(
                                error.get("userMessage")
                                or error.get("message")
                                or error.get("code")
                                or "Błąd reguły"
                            )
                        )
        return (
            "; ".join(errors)[:3000]
            or "Operacja w toku lub brak potwierdzenia przypisania. Sprawdź wynik później."
        )

    def kandydaci_duplikatow(
        self, s: SesjaAllegro, pole: str, fraza: str
    ) -> tuple[IstniejacaOferta, ...]:
        if pole not in {"external.id", "name"} or not fraza or len(fraza) > 100:
            raise BladAllegro("DUPLIKATY", "Niepoprawne dane wyszukiwania.")
        wynik: dict[str, IstniejacaOferta] = {}
        offset = 0
        expected = None
        while True:
            d = self._get(
                s.srodowisko,
                s.token,
                "/sale/offers?" + urlencode({pole: fraza, "offset": offset, "limit": 100}),
            )
            try:
                rows, total = d["offers"], d["totalCount"]
                if (
                    not isinstance(rows, list)
                    or type(total) is not int
                    or not 0 <= total <= 1000
                    or len(rows) > 100
                    or (expected is not None and total != expected)
                ):
                    raise ValueError("lista")
                expected = total
                for row in rows:
                    ident = tekst(row, "id", 100)
                    if not ident.isdigit() or ident in wynik:
                        raise ValueError("id")
                    status = tekst(row["publication"], "status", 32)
                    external = row.get("external") or {}
                    sku = external.get("id") or ""
                    if not isinstance(sku, str) or len(sku) > 100:
                        raise ValueError("sku")
                    wynik[ident] = IstniejacaOferta(ident, tekst(row, "name"), sku, status)
                offset += len(rows)
                if offset == total:
                    return tuple(wynik.values())
                if not rows or offset > total:
                    raise ValueError("niepełna lista")
            except (KeyError, ValueError, TypeError, AttributeError):
                raise BladAllegro(
                    "DUPLIKATY",
                    "Nie udało się sprawdzić pełnych wyników konta. "
                    "Lista jest niepełna, zmieniła się lub przekracza 1000 dopasowań. "
                    "Nie wysłano szkiców.",
                ) from None

    def ean_duplikatu(self, s: SesjaAllegro, ident: str) -> tuple[str, ...]:
        d = cast(dict[str, Any], self.odczytaj_szkic(s, ident))
        try:
            result = set()
            for part in d.get("productSet", []):
                for parameter in part["product"].get("parameters", []):
                    if parameter.get("id") == "225693" or parameter.get("name") in {
                        "EAN",
                        "EAN (GTIN)",
                        "GTIN",
                    }:
                        values = parameter.get("values", [])
                        if not isinstance(values, list) or any(
                            not isinstance(v, str) for v in values
                        ):
                            raise ValueError("ean")
                        result.update(values)
            return tuple(sorted(result))
        except (KeyError, ValueError, TypeError, AttributeError):
            raise BladAllegro(
                "DUPLIKATY", "Nie udało się porównać EAN istniejącej oferty."
            ) from None

    def vat_kategorii(self, s: SesjaAllegro, kategoria: str, odswiez: bool = False) -> VATKategorii:
        if not re.fullmatch(r"[0-9]{1,100}", kategoria):
            raise BladAllegro("VAT", "Najpierw wybierz końcową kategorię Allegro.")
        key = (s.srodowisko.value, s.konto.id, sha256(s.token.encode()).hexdigest(), kategoria)
        cached = self._vat.get(key)
        if not odswiez and cached and time.monotonic() - cached[0] < 30:
            return cached[1]
        self._vat.pop(key, None)
        d = self._get(
            s.srodowisko, s.token, "/sale/tax-settings?" + urlencode({"category.id": kategoria})
        )
        result = mapuj_vat(d, kategoria)
        if len(self._vat) >= 32:
            self._vat.pop(next(iter(self._vat)))
        self._vat[key] = (time.monotonic(), result)
        return result

    def vat_oferty(self, s: SesjaAllegro, ident: str, kategoria: str) -> UstawieniaVAT:
        d = self.odczytaj_szkic(s, ident)
        category = d.get("category")
        if not isinstance(category, dict) or category.get("id") != kategoria:
            raise BladAllegro(
                "VAT", "Oferta źródłowa ma inną kategorię. Wybierz ofertę tej samej kategorii."
            )
        u = odczytaj_vat(d)
        sprawdz_vat(u, self.vat_kategorii(s, kategoria), wymagaj_wyboru=False)
        return u

    def slowniki_sprzedazy(
        self, s: SesjaAllegro, odswiez: bool = False, czesciowe: bool = False
    ) -> SlownikiSprzedazy:
        key = (s.srodowisko.value, s.konto.id, sha256(s.token.encode()).hexdigest())
        cache = self._slowniki
        if not odswiez and cache and cache[0] == key and time.monotonic() - cache[1] < 60:
            return cache[2]
        self._slowniki = None
        result = pobierz_slowniki(self._get, s, czesciowe)
        if not result.bledy:
            self._slowniki = (key, time.monotonic(), result)
        return result

    @staticmethod
    def _parametry_kategorii(meta: dict[str, object]) -> tuple[ParametrSzkicu, ...]:
        reqs = meta["parameters"]
        if not isinstance(reqs, list):
            raise ValueError("parameters")
        wynik = []
        for p in reqs:
            options = p.get("options") or {}
            slownik = p.get("dictionary") or []
            if not isinstance(options, dict) or not isinstance(slownik, list):
                raise ValueError("parametry")
            wynik.append(
                ParametrSzkicu(
                    tekst(p, "id"),
                    tekst(p, "name"),
                    tekst(p, "type"),
                    p.get("required") is True,
                    tuple((tekst(v, "id"), tekst(v, "value")) for v in slownik),
                    options.get("describesProduct") is True,
                    p.get("requiredForProduct") is True,
                )
            )
        return tuple(wynik)

    def kategorie(self, s: SesjaAllegro, fraza: str) -> tuple[KategoriaSzkicu, ...]:
        if not fraza.strip() or len(fraza) > 1024:
            raise BladAllegro("KATEGORIA", "Podaj nazwę produktu lub kategorii.")
        d = self._get(
            s.srodowisko, s.token, "/sale/matching-categories?" + urlencode({"name": fraza})
        )
        try:
            rows = d["matchingCategories"]
            if not isinstance(rows, list) or len(rows) > 1000:
                raise ValueError("categories")
            wynik = []
            for r in rows:
                ident = tekst(r, "id")
                if not re.fullmatch(r"[0-9]{1,100}", ident):
                    raise ValueError("category")
                names = [tekst(r, "name")]
                parent = r.get("parent")
                for _ in range(20):
                    if parent is None:
                        break
                    names.insert(0, tekst(parent, "name"))
                    parent = parent.get("parent")
                wynik.append(KategoriaSzkicu(ident, " / ".join(names)))
            return tuple(wynik)
        except (KeyError, ValueError, TypeError, AttributeError):
            raise BladAllegro("ODPOWIEDZ", "Niepoprawna lista kategorii Allegro.") from None

    def nowy_produkt(self, s: SesjaAllegro, kategoria: str, odswiez: bool = False) -> ProduktSzkicu:
        if not re.fullmatch(r"[0-9]{1,100}", kategoria):
            raise BladAllegro("KATEGORIA", "Wybierz kategorię nowego produktu Allegro.")
        key = (s.srodowisko.value, s.konto.id, kategoria)
        cached = self._kategorie.get(key)
        if not odswiez and cached and time.monotonic() - cached[0] < 30:
            return cached[1]
        d = self._get(s.srodowisko, s.token, "/sale/categories/" + kategoria)
        try:
            if tekst(d, "id") != kategoria or d.get("leaf") is not True:
                raise BladAllegro("KATEGORIA", "Wybierz końcową kategorię produktu.")
            options = d.get("options") or {}
            if not isinstance(options, dict):
                raise ValueError("options")
            if options.get("productCreationEnabled") is False:
                raise BladAllegro(
                    "KATEGORIA", "Allegro nie pozwala tworzyć produktów w tej kategorii."
                )
            meta = self._get(s.srodowisko, s.token, "/sale/categories/" + kategoria + "/parameters")
            result = ProduktSzkicu("", tekst(d, "name"), kategoria, self._parametry_kategorii(meta))
            if len(self._kategorie) >= 32:
                self._kategorie.pop(next(iter(self._kategorie)))
            self._kategorie[key] = (time.monotonic(), result)
            return result
        except (KeyError, ValueError, TypeError, AttributeError):
            raise BladAllegro(
                "ODPOWIEDZ", "Niepoprawne wymagania nowego produktu Allegro."
            ) from None

    def potwierdz_nowy(
        self,
        s: SesjaAllegro,
        ident: str,
        nazwa: str,
        kategoria: str,
        parametry: list[dict[str, object]],
    ) -> bool:
        try:
            ident = str(UUID(ident))
        except ValueError:
            return False
        d = self._get(s.srodowisko, s.token, "/sale/products/" + ident)
        try:
            publication = d.get("publication")
            if (
                tekst(d, "id") != ident
                or tekst(d, "name") != nazwa
                or tekst(d["category"], "id") != kategoria
                or (
                    isinstance(publication, dict)
                    and publication.get("status") in {"NOT_LISTED", "REMOVED"}
                )
            ):
                return False
            rows = d["parameters"]
            if not isinstance(rows, list):
                return False
            for expected in parametry:
                actual = next(
                    (r for r in rows if isinstance(r, dict) and r.get("id") == expected["id"]), None
                )
                field = "valuesIds" if "valuesIds" in expected else "values"
                if actual is None or actual.get(field) != expected[field]:
                    return False
            return True
        except (KeyError, ValueError, TypeError, AttributeError):
            return False

    def znajdz_produkty(
        self, s: SesjaAllegro, fraza: str, gtin: bool = False
    ) -> tuple[ProduktSzkicu, ...]:
        if not fraza.strip() or len(fraza) > 1024:
            raise BladAllegro("PRODUKT", "Podaj EAN lub nazwę szukanego produktu.")
        query = {"phrase": fraza}
        if gtin:
            query["mode"] = "GTIN"
        d = self._get(s.srodowisko, s.token, "/sale/products?" + urlencode(query))
        try:
            rows = d["products"]
            if not isinstance(rows, list) or len(rows) > 1000:
                raise ValueError("products")
            wynik = tuple(
                ProduktSzkicu(
                    str(UUID(tekst(p, "id"))), tekst(p, "name"), tekst(p["category"], "id")
                )
                for p in rows
            )
            if gtin and isinstance(d.get("nextPage"), dict) and d["nextPage"].get("id"):
                raise BladAllegro(
                    "PRODUKT", "Wynik katalogu ma kolejne strony. Wybierz produkt ręcznie."
                )
            return wynik
        except (KeyError, TypeError, ValueError, AttributeError):
            raise BladAllegro("ODPOWIEDZ", "Niepoprawna odpowiedź katalogu Allegro.") from None

    def produkt_szkicu(self, s: SesjaAllegro, ident: str) -> ProduktSzkicu:
        try:
            ident = str(UUID(ident))
        except ValueError:
            raise BladAllegro("PRODUKT", "Niepoprawny UUID produktu Allegro.") from None
        d = self._get(s.srodowisko, s.token, "/sale/products/" + ident)
        try:
            if tekst(d, "id") != ident:
                raise ValueError("id")
            kategoria = tekst(d["category"], "id")
            if not kategoria.isascii() or not kategoria.isdigit():
                raise ValueError("category")
            meta = self._get(s.srodowisko, s.token, "/sale/categories/" + kategoria + "/parameters")
            return ProduktSzkicu(
                ident, tekst(d, "name"), kategoria, self._parametry_kategorii(meta)
            )
        except (KeyError, ValueError, TypeError, AttributeError):
            raise BladAllegro(
                "ODPOWIEDZ", "Niepoprawne dane produktu lub wymagań kategorii."
            ) from None

    def wyslij_zdjecie(self, s: SesjaAllegro, url: str) -> str:
        headers = self._naglowki(s)
        if lokalne_zdjecie(url) and self.pliki_zdjec is not None:
            data = self.pliki_zdjec.pobierz_obraz(url).dane
            headers["Content-Type"] = "image/jpeg"
        elif adres_zdjecia(url):
            data = json.dumps({"url": url}).encode()
        else:
            raise BladAllegro("ZDJECIE", "Brakuje kopii zdjęcia lub poprawnego adresu HTTPS.")
        host = (
            "https://upload.allegro.pl"
            if s.srodowisko == SrodowiskoAllegro.PRODUKCJA
            else "https://upload.allegro.pl.allegrosandbox.pl"
        )
        r = self.transport_zapisu.wyslij("POST", host + "/sale/images", headers, data)
        if r.status != 201:
            raise BladAllegro(
                "ZDJECIE", f"Nie przesłano zdjęcia (HTTP {r.status}). Nie utworzono szkicu."
            )
        try:
            location = json.loads(r.dane)["location"]
            if not isinstance(location, str) or not adres_zdjecia(location):
                raise ValueError("location")
            hostname = urlsplit(location).hostname or ""
            if not any(
                hostname == d or hostname.endswith("." + d)
                for d in ("allegroimg.com", "allegroimg.allegrosandbox.pl")
            ):
                raise ValueError("host")
            return location
        except (KeyError, ValueError, TypeError, UnicodeError):
            raise BladAllegro(
                "ZDJECIE", "Brak prawidłowego adresu przesłanego zdjęcia Allegro."
            ) from None

    def utworz_szkic(self, s: SesjaAllegro, dane: dict[str, object]) -> ProbaTworzenia:
        _, host = hosty(s.srodowisko)
        try:
            r = self.transport_zapisu.wyslij(
                "POST",
                host + "/sale/product-offers",
                self._naglowki(s),
                json.dumps(dane, ensure_ascii=False).encode(),
            )
        except BladAllegro:
            raise BladAllegro(
                "NIEZNANY", "Brak odpowiedzi tworzenia. Sprawdź wynik; nie ponawiaj wysyłki."
            ) from None
        if r.status in {400, 401, 403, 422, 429}:
            opis = "Allegro odrzuciło tworzenie szkicu."
            try:
                bledy = json.loads(r.dane).get("errors", [])
                if isinstance(bledy, list):
                    opis += " " + "; ".join(
                        str(
                            e.get("userMessage")
                            or e.get("message")
                            or e.get("code")
                            or "Błąd danych"
                        )[:500]
                        for e in bledy[:10]
                        if isinstance(e, dict)
                    )
            except (ValueError, UnicodeError, AttributeError):
                pass
            raise BladAllegro("ODRZUCONO", f"HTTP {r.status}. " + opis)
        if r.status not in {201, 202}:
            raise BladAllegro(
                "NIEZNANY", f"Nieznany wynik tworzenia (HTTP {r.status}). Nie ponawiaj."
            )
        try:
            d = json.loads(r.dane)
            ident = str(d.get("id", "")) if isinstance(d, dict) else ""
            operacja = ""
            if r.status == 202:
                u = urlsplit(r.lokalizacja)
                m = re.fullmatch(
                    r"/sale/product-offers/([0-9]{1,100})/operations/([A-Za-z0-9-]{1,100})", u.path
                )
                if (
                    not m
                    or u.scheme != "https"
                    or u.netloc != urlsplit(host).netloc
                    or u.query
                    or u.fragment
                ):
                    raise ValueError("Location")
                if ident and ident != m[1]:
                    raise ValueError("id")
                ident, operacja = m[1], m[2]
                self.odczekaj[(s.srodowisko.value, ident)] = time.monotonic() + r.odstep
            if not re.fullmatch(r"[0-9]{1,100}", ident):
                raise ValueError("id")
            return ProbaTworzenia("", "", r.status, ident, operacja)
        except (ValueError, UnicodeError, TypeError):
            raise BladAllegro(
                "NIEZNANY", "Przyjęto tworzenie, ale nie potwierdzono ID/operacji. Nie ponawiaj."
            ) from None

    def znajdz_szkic(self, s: SesjaAllegro, external: str) -> dict[str, object] | None:
        d = self._get(
            s.srodowisko,
            s.token,
            "/sale/offers?" + urlencode({"external.id": external, "limit": 2}),
        )
        rows = d.get("offers")
        total = d.get("totalCount")
        if (
            not isinstance(rows, list)
            or type(total) is not int
            or total < 0
            or len(rows) > 1
            or total > 1
            or len(rows) != total
        ):
            raise BladAllegro(
                "KONFLIKT", "Niejednoznaczny wynik external.id. Nie tworzono kolejnego szkicu."
            )
        if not rows:
            return None
        try:
            return self.odczytaj_szkic(s, tekst(rows[0], "id"))
        except (ValueError, TypeError):
            raise BladAllegro("ODPOWIEDZ", "Niepoprawny identyfikator wyniku tworzenia.") from None

    def odczytaj_szkic(self, s: SesjaAllegro, ident: str) -> dict[str, object]:
        return self._get(s.srodowisko, s.token, self._sciezka(ident))

    def operacja_tworzenia(self, s: SesjaAllegro, ident: str, operacja: str) -> bool:
        return self.operacja_szkicu(s, ident, operacja)
