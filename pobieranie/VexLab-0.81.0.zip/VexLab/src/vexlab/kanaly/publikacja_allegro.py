"""Komendy ACTIVATE według changePublicationStatusUsingPUT, potwierdzane odczytem."""

import hashlib
import json
import time
from datetime import datetime
from typing import Any
from uuid import UUID

from vexlab.kanaly.allegro import hosty
from vexlab.kanaly.szkic_allegro import mapuj_oferte
from vexlab.kanaly.zapis_szkicu_allegro import ZapisSzkicuAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.publikacja_allegro import SzkicPublikacji


class PublikacjaAllegroAPI(ZapisSzkicuAPI):
    @staticmethod
    def _komenda(cmd: str) -> str:
        try:
            if str(UUID(cmd)) != cmd:
                raise ValueError("UUID")
        except ValueError:
            raise BladAllegro("ADRES", "Nieprawidłowa komenda publikacji.") from None
        return "/sale/offer-publication-commands/" + cmd

    def odczytaj_publikacje(self, s: SesjaAllegro, ident: str) -> SzkicPublikacji:
        d = self._get(s.srodowisko, s.token, self._sciezka(ident))
        o = mapuj_oferte(d, ident)
        fingerprint = hashlib.sha256(
            json.dumps(
                {
                    k: d.get(k)
                    for k in (
                        "name",
                        "sellingMode",
                        "stock",
                        "category",
                        "parameters",
                        "productSet",
                        "images",
                        "description",
                        "delivery",
                        "location",
                        "payments",
                        "afterSalesServices",
                        "taxSettings",
                        "publication",
                    )
                },
                sort_keys=True,
                ensure_ascii=False,
            ).encode()
        ).hexdigest()
        return SzkicPublikacji(
            o.id, o.tytul, o.cena, o.waluta, o.stan or 0, o.status.value, fingerprint
        )

    def zlec_publikacje(self, s: SesjaAllegro, ident: str, komenda: str) -> None:
        self._sciezka(ident)
        path = self._komenda(komenda)
        key = (s.srodowisko.value, s.konto.id)
        if time.monotonic() < self.odczekaj.get(key, 0):
            raise BladAllegro("ODRZUCONO", "Odczekaj po limicie Allegro przed nową próbą.")
        _, host = hosty(s.srodowisko)
        body = {
            "publication": {"action": "ACTIVATE"},
            "offerCriteria": [{"type": "CONTAINS_OFFERS", "offers": [{"id": ident}]}],
        }
        r = self.transport_zapisu.wyslij(
            "PUT", host + path, self._naglowki(s), json.dumps(body).encode()
        )
        if r.status == 429:
            self.odczekaj[key] = time.monotonic() + max(1, min(r.odstep, 3600))
        if r.status in {400, 401, 403, 404, 422, 429}:
            raise BladAllegro(
                "ODRZUCONO",
                f"Allegro odrzuciło publikację (HTTP {r.status}). Sprawdź dane i uprawnienia.",
            )
        if r.status != 201:
            raise BladAllegro(
                "NIEZNANY", f"Brak potwierdzenia publikacji (HTTP {r.status}). Sprawdź wynik."
            )

    def _raport_get(self, s: SesjaAllegro, path: str) -> dict[str, Any]:
        try:
            return self._get(s.srodowisko, s.token, path)
        except BladAllegro as exc:
            if exc.kod == "UPRAWNIENIA":
                raise BladAllegro(
                    "UPRAWNIENIA",
                    "Odczyt komendy publikacji wymaga allegro:api:sale:offers:write. "
                    "Zmień uprawnienia konta i sprawdź wynik ponownie.",
                ) from None
            raise

    def raport_publikacji(self, s: SesjaAllegro, ident: str, komenda: str) -> str | None:
        path = self._komenda(komenda)
        d = self._raport_get(s, path)
        try:
            if d["id"] != komenda:
                raise ValueError("Id")
            counts = d["taskCount"]
            total, success, failed = (counts[k] for k in ("total", "success", "failed"))
            if (
                any(type(v) is not int or not 0 <= v <= 1 for v in (total, success, failed))
                or success + failed > total
            ):
                raise ValueError("Liczniki")
            if d.get("completedAt") is None:
                return None
            if (
                not isinstance(d["completedAt"], str)
                or datetime.fromisoformat(d["completedAt"]).tzinfo is None
            ):
                raise ValueError("Data zakończenia")
            if total != 1 or success + failed != 1:
                raise ValueError("Niepełny wynik")
            if failed == 0:
                return None  # ACTIVE musi osobno potwierdzić GET oferty
            tasks = self._raport_get(s, path + "/tasks?limit=100&offset=0")["tasks"]
            if len(tasks) != 1 or tasks[0]["offer"]["id"] != ident or tasks[0]["status"] != "FAIL":
                raise ValueError("Zadania")
            errors = tasks[0].get("errors") or []
            messages = [
                e.get("userMessage") or e.get("message") or ""
                for e in errors
                if isinstance(e, dict)
            ]
            msg = (
                "; ".join(m for m in messages if isinstance(m, str))
                or tasks[0].get("message")
                or "Allegro odrzuciło publikację. Popraw dane oferty."
            )
            return str(msg)[:2000]
        except (KeyError, TypeError, ValueError, AttributeError):
            raise BladAllegro(
                "ODPOWIEDZ", "Niepełny wynik komendy. Sprawdź ponownie; nie ponowiono publikacji."
            ) from None
