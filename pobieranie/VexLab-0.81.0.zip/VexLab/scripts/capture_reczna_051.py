"""Ręczny formularz na danych tymczasowych; bez wywołań API Allegro."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QBuffer, QIODevice
from PySide6.QtGui import QColor, QImage
from PySide6.QtWidgets import QApplication, QTabWidget

from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.adaptery.zdjecia_ofert import ZdjeciaOfert
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.edytor_opisu import TekstWizualny
from vexlab.gui.reczna_oferta import RecznaOferta
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


class BezSieci:
    def pobierz_obraz(self, url):
        raise ValueError("Dane demonstracyjne nie pobierają zdjęć z sieci.")


def main() -> int:
    app = QApplication(sys.argv)
    out = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    with TemporaryDirectory() as tmp:
        base = Path(tmp)
        image = QImage(800, 600, QImage.Format.Format_RGB32)
        image.fill(QColor("#547B89"))
        buffer = QBuffer()
        buffer.open(QIODevice.OpenModeFlag.WriteOnly)
        image.save(buffer, "PNG")
        source = base / "test.png"
        source.write_bytes(bytes(buffer.data()))
        photos = ZdjeciaOfert(base / "zdjecia", BezSieci())
        service = SzkiceOfert(SzkiceSQLite(base / "k.sqlite3"))
        jobs = []
        d = RecznaOferta(
            None, service, lambda *a: jobs.append(a), PodgladZdjec(photos), pliki_zdjec=photos
        )
        d.sku.setText("SKU-TEST-001")
        d.tytul.setText("Osłona testowa do motocykla")
        d.ean.setText("5901234123457")
        d.cena.setText("289,00")
        d.lokalne = photos.importuj((source,))
        d.lista_plikow.setText("Dodano z dysku: 1")
        d._galeria()
        d.opis.findChild(TekstWizualny).setPlainText("Własny opis przygotowany bez paczki ZIP.")
        for motif, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motif)
            d.show()
            for page, suffix in ((0, "dane"), (1, "opis")):
                tabs = d.findChild(QTabWidget)
                if tabs is not None:
                    tabs.setCurrentIndex(page)
                for _ in range(8):
                    app.processEvents()
                    while jobs:
                        function, success, error = jobs.pop(0)
                        success(function())
                if not d.grab().save(str(out / f"vexlab-reczna-051-{suffix}-{name}.png")):
                    return 1
        d.reject()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
