"""Izolowany podgląd kursowego przelicznika, bez konta i żądań Allegro."""

import sys
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QWidget

from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.gui.przelicznik_cen_allegro import WyborPrzelicznika
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.przelicznik_cen_allegro import RegulaKursowa


def main() -> int:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from tests.conftest import nowe_szkice_fixture

    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    with TemporaryDirectory(prefix="vexlab-przelicznik-") as folder:
        serwis, api, _repo, sesja, oferta, ustawienia = nowe_szkice_fixture.__wrapped__(
            Path(folder)
        )
        api.reguly_kursowe = lambda *a: (RegulaKursowa("exchange-demo", "Przelicznik cen"),)
        api.przelicznik_potwierdzony = lambda *a: False
        parent = QWidget()

        def uruchom(fn, ok, blad):
            ok(fn())

        w = DialogNowychSzkicow(
            parent,
            serwis,
            sesja,
            tuple(replace(oferta, sku=f"SKU-DEMO-{i:03d}") for i in range(1, 36)),
            uruchom,
        )
        w.resize(1280, 820)
        w.kompletny.setChecked(False)
        w.waluta.setCurrentIndex(w.waluta.findData("PLN"))
        for i in range(35):
            w.ustawienia[i] = ustawienia
        w.przygotuj()
        w.tabela.selectRow(0)
        for motyw, nazwa in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motyw)
            w.show()
            app.processEvents()
            assert w.grab().save(str(cel / f"vexlab-przelicznik-panel-062-{nazwa}.png"))
            zapisano = []

            def zapisz(nazwa=nazwa, zapisano=zapisano):
                d = app.activeModalWidget()
                assert isinstance(d, WyborPrzelicznika)
                d.stosuj.setChecked(True)
                d.rynki["allegro-cz"].setChecked(True)
                d.rynki["allegro-sk"].setChecked(True)
                d.rynki["allegro-hu"].setChecked(True)
                app.processEvents()
                zapisano.append(d.grab().save(str(cel / f"vexlab-przelicznik-062-{nazwa}.png")))
                d.reject()

            QTimer.singleShot(100, zapisz)
            w.ustaw_przelicznik()
            assert zapisano == [True]
        w.close()
        parent.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
