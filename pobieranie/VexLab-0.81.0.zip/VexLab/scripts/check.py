"""Powtarzalne kontrole lokalne i CI, bez operacji sieciowych."""

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--osobne-procesy-gui",
        action="store_true",
        help="Uruchom każdy moduł GUI w nowym procesie Qt; żaden test nie jest pomijany.",
    )
    argumenty = parser.parse_args()
    testy = [[sys.executable, "-m", "pytest"]]
    if argumenty.osobne_procesy_gui:
        testy = [[sys.executable, "-m", "pytest", "tests", "--ignore=tests/gui"]]
        testy += [
            [sys.executable, "-m", "pytest", str(plik.relative_to(ROOT))]
            for plik in sorted((ROOT / "tests" / "gui").rglob("*.py"))
            if plik.name.startswith("test_") or plik.name.endswith("_test.py")
        ]
    narzedzia = Path(sys.executable).parent
    linter = narzedzia / ("lint-imports.exe" if os.name == "nt" else "lint-imports")
    polecenia = [
        [sys.executable, "-m", "ruff", "check", "src", "tests", "scripts"],
        [sys.executable, "-m", "ruff", "format", "--check", "src", "tests", "scripts"],
        [sys.executable, "-m", "mypy", "src"],
        [str(linter), "--no-cache"],
        [sys.executable, "-m", "bandit", "-r", "src", "-q"],
        *testy,
        [sys.executable, "-m", "vexlab", "--diagnostyka"],
    ]
    srodowisko = dict(os.environ)
    if sys.platform.startswith("linux"):
        srodowisko.setdefault("QT_QPA_PLATFORM", "offscreen")
    for polecenie in polecenia:
        print("Kontrola:", " ".join(polecenie), flush=True)
        wynik = subprocess.run(polecenie, cwd=ROOT, env=srodowisko, check=False)
        if wynik.returncode:
            return wynik.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
