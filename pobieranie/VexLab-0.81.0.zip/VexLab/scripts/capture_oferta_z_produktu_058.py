"""Oferta z syntetycznego Produktu; izolowana baza i pliki, bez sieci."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from capture_przygotowanie_048 import ObrazTestowy
from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.katalog_uzytkownika_sqlite import KatalogUzytkownikaSQLite
from vexlab.adaptery.obraz import obraz
from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.adaptery.zdjecia_ofert import ZdjeciaOfert
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.reczna_oferta import RecznaOferta
from vexlab.przypadki_uzycia.importowanie import CenaImportu
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.katalog_uzytkownika import ProduktUzytkownika
from vexlab.przypadki_uzycia.oferta_z_produktu import PrzygotujOferteZProduktu
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


class BezSieci:
    def pobierz_obraz(self, *args):
        raise AssertionError("Brak połączeń sieciowych w podglądzie")


def main():
    app = QApplication(sys.argv)
    parent = QWidget()
    out = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    with TemporaryDirectory() as tmp:
        base = Path(tmp)
        repo = KatalogUzytkownikaSQLite(base / "k.sqlite3")
        raw = ObrazTestowy().pobierz_obraz("https://images.example.org/demo.jpg")
        repo.zapisz_uzytkownika(
            (
                ProduktUzytkownika(
                    "Osłona testowa do motocykla",
                    "SKU-TEST-001",
                    "<h2>Osłona testowa</h2><p>Opis z lokalnego Produktu.</p>",
                    "5901234123457",
                    "Producent użytkownika — przykład",
                    cena=CenaImportu("289", "EUR", "brutto"),
                    zdjecia=(obraz(raw.dane, raw.zrodlo),),
                ),
            )
        )
        row = KatalogProduktow(repo, repo).wyszukaj()[0]
        photos = ZdjeciaOfert(base / "zdjecia", BezSieci())
        source = PrzygotujOferteZProduktu(repo, repo, photos).przygotuj(row.id, row.wersja)
        jobs = []
        d = RecznaOferta(
            parent,
            SzkiceOfert(SzkiceSQLite(repo.plik)),
            lambda *a: jobs.append(a),
            PodgladZdjec(photos),
            pliki_zdjec=photos,
            z_produktu=source,
        )
        d.resize(1160, 950)
        for motif, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motif)
            d.show()
            for _ in range(8):
                app.processEvents()
                while jobs:
                    fn, ok, error = jobs.pop(0)
                    ok(fn())
            assert d.grab().save(str(out / f"vexlab-oferta-z-produktu-058-{name}.png"))
        d.reject()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
