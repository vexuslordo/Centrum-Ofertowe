"""Podgląd własnych wpisów na danych syntetycznych w katalogu tymczasowym."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.szablony_ofert_json import SzablonyOfertJSON
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.szablony_ofert import WyborSzablonu
from vexlab.gui.ustawienia_sprzedazy_allegro import DaneSprzedazyAllegro
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import SlownikiSprzedazy


def main() -> int:
    app = QApplication(sys.argv)
    parent = QWidget()
    out = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    with TemporaryDirectory() as tmp:
        repo = SzablonyOfertJSON(Path(tmp))
        repo.zapisz(
            "bezpieczenstwo",
            "Crash pady — przykład",
            "Pełna informacja o bezpieczeństwie wpisana przez użytkownika.\n\n"
            "Dane demonstracyjne — tutaj pojawi się Twój zapisany tekst.",
        )
        d = DaneSprzedazyAllegro(
            parent, SlownikiSprzedazy((), (), (), (), (), ()), None, 197, szablony_ofert=repo
        )
        row = d.findChild(WyborSzablonu)
        row.wybor.setCurrentIndex(1)
        row.wybor.activated.emit(1)
        for motif, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motif)
            d.show()
            app.processEvents()
            if not d.grab().save(str(out / f"vexlab-szablony-050-{name}.png")):
                return 1
        d.reject()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
