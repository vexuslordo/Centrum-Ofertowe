"""Izolowany podgląd PrestaShop z syntetycznym API, bez kontaktu ze sklepem."""

from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QSettings
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.prestashop import (
    KategoriaPresta,
    PolaczPresta,
    PozycjaPresta,
    SlownikiPresta,
)
from vexlab.przypadki_uzycia.producenci import RejestrProducentow


class TestoweAPI:
    def slowniki(self, _k):
        return SlownikiPresta(
            (PozycjaPresta("1", "Sklep demonstracyjny"),), (PozycjaPresta("2", "Polski"),)
        )

    def kategorie(self, _k):
        return tuple(
            KategoriaPresta(str(10 + i), "2", nazwa, i != 4)
            for i, nazwa in enumerate(
                ("Części motocyklowe", "Crash pady", "Lusterka", "Osłony reflektorów", "Archiwum")
            )
        )


def main() -> int:
    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    with TemporaryDirectory(prefix="vexlab-presta-visual-") as folder:
        tmp = Path(folder)
        repo = CennikiSQLite(tmp / "test.sqlite3")
        w = OknoVexLab(
            PowlokaAplikacji(
                PreferencjeQt(QSettings(str(tmp / "prefs.ini"), QSettings.Format.IniFormat)),
                "uzytkownik_testowy",
                "0.61.1.dev0",
            ),
            KatalogProduktow(repo, repo),
            RejestrProducentow(repo),
            EksportujKatalog(EksportCSV()),
            ImportujProdukty(CzytnikTabel(), repo, repo),
            presta=PolaczPresta(TestoweAPI()),
        )
        w.resize(1536, 1024)
        w.show()

        def czekaj() -> None:
            for _ in range(300):
                app.processEvents()
                if not w._zadania and w._katalog_wczytany:
                    return
                QTest.qWait(10)
            raise RuntimeError("Nie zakończono podglądu")

        czekaj()
        w.przejdz("PrestaShop")
        p = w.strona_presta
        assert p is not None
        p.adres.setText("https://sklep.example/")
        p.klucz.setText("TEST" * 8)
        p.polacz.click()
        czekaj()
        p.pobierz.click()
        czekaj()
        p.tabela.setCurrentIndex(p.proxy.index(1, 0))
        for motyw, nazwa in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            w.wybor_motywu.setCurrentIndex(w.wybor_motywu.findData(motyw))
            QTest.qWait(100)
            w.przejdz("PrestaShop")
            QTest.qWait(100)
            assert w.grab().save(str(cel / f"vexlab-presta-0611-{nazwa}.png"))
            p.ustawienia.click()
            QTest.qWait(100)
            assert w.grab().save(str(cel / f"vexlab-presta-integracje-0611-{nazwa}.png"))
        w.close()
        app.processEvents()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
