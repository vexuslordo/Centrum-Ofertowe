"""Syntetyczny odczyt statusów w prawdziwym oknie, bez zewnętrznych żądań."""

from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from PySide6.QtCore import QSettings
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.allegro import KontoAllegro, SesjaAllegro, SrodowiskoAllegro
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.katalog_allegro import OfertaKatalogu
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow


class TestoweAPI:
    def lista_statusow(self, s, stop, postep):
        rows = tuple(
            OfertaKatalogu(
                str(100 + i),
                "Osłona testowa",
                f"SKU-DEMO-{i:02d}",
                ("ACTIVE", "INACTIVE", "ENDED")[(i - 1) % 3],
            )
            for i in range(1, 9)
        )
        postep(len(rows), len(rows))
        return rows


def main() -> int:
    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    with TemporaryDirectory(prefix="vexlab-statusy-") as folder:
        tmp = Path(folder)
        repo = CennikiSQLite(tmp / "k.sqlite3")
        katalog = KatalogProduktow(repo, repo)
        for i in range(1, 11):
            katalog.dodaj(
                DaneProduktu(f"Osłona motocyklowa — produkt testowy {i:02d}", f"SKU-DEMO-{i:02d}")
            )
        import sys

        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from dataclasses import replace

        from tests.integration.test_porownanie_cen_allegro import API, Biblioteka
        from vexlab.adaptery.porownanie_cen_csv import EksportPorownaniaCenCSV
        from vexlab.przypadki_uzycia.porownanie_cen_allegro import PorownajCennikAllegro

        b, api = Biblioteka(), API()
        b.rows = (*b.rows, replace(b.rows[0], dane=replace(b.rows[0].dane, sku="D")))
        api.rows = (*api.rows, replace(api.rows[0], ident="12", sku="D", cena="150"))
        w = OknoVexLab(
            PowlokaAplikacji(
                PreferencjeQt(QSettings(str(tmp / "p.ini"), QSettings.Format.IniFormat)),
                "Test",
                "0.64.1.dev0",
            ),
            katalog,
            RejestrProducentow(repo),
            EksportujKatalog(EksportCSV()),
            ImportujProdukty(CzytnikTabel(), repo, repo),
            porownanie_cen=PorownajCennikAllegro(b, api, EksportPorownaniaCenCSV()),
        )
        w.resize(1536, 1024)
        w.show()

        def czekaj():
            for _ in range(300):
                app.processEvents()
                if not w._zadania and w._katalog_wczytany:
                    return
                QTest.qWait(10)
            raise RuntimeError("Odczyt nie zakończył się")

        czekaj()
        w.strona_allegro = SimpleNamespace(
            sesja=SesjaAllegro(
                KontoAllegro("demo", "konto_testowe"),
                SrodowiskoAllegro.SANDBOX,
                "fixture",
                9999999,
            )
        )
        w.pasek_integracji.ustaw("konto_testowe")
        czekaj()
        w.przejdz("Zmiana cen")
        czekaj()
        w.strona_porownania_cen.porownaj.click()
        czekaj()
        for motyw, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            w.wybor_motywu.setCurrentIndex(w.wybor_motywu.findData(motyw))
            QTest.qWait(50)
            assert w.grab().save(str(cel / f"vexlab-porownanie-cen-0641-{name}.png"))
        w.close()
        app.processEvents()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
