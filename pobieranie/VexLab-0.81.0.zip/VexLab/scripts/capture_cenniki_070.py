"""Izolowany podgląd cenników z syntetycznymi pozycjami i cenami."""

from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import uuid4

from PySide6.QtCore import QSettings
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import CenaImportu, ImportujProdukty, PozycjaImportu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow


def main() -> int:
    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    with TemporaryDirectory(prefix="vexlab-cenniki-visual-") as folder:
        tmp = Path(folder)
        repo = CennikiSQLite(tmp / "test.sqlite3")
        imp = ImportujProdukty(CzytnikTabel(), repo, repo)
        kat = KatalogProduktow(repo, repo)
        producenci = RejestrProducentow(repo)
        pid = producenci.dodaj(DaneProducenta("Producent testowy")).id
        rows = tuple(
            PozycjaImportu(
                uuid4(),
                uuid4(),
                "test.csv",
                "A",
                i + 2,
                DaneProduktu(nazwa, f"TEST-{i}", producent_id=pid),
                cena=CenaImportu(cena, "EUR", "brutto"),
            )
            for i, (nazwa, cena) in enumerate(
                (
                    ("Przykładowy produkt A", "100.00"),
                    ("Przykładowy produkt B", "90.00"),
                    ("Nowy produkt", "75.00"),
                    ("Pozycja do sprawdzenia", "brak"),
                )
            )
        )
        paczka = uuid4()
        bazowe = tuple(replace(p, paczka=paczka) for p in rows[:2])
        imp.zatwierdz(imp.ocen(bazowe), frozenset(p.id for p in bazowe))
        serwis = BibliotekaCennikow(repo, imp)
        serwis.zapisz("Cennik 2025", 2025, "listopad", imp.ocen(rows))
        poprzedni = serwis.lista()[0]
        serwis.oznacz(poprzedni, True, serwis.lista())
        poprzedni = serwis.lista()[0]
        serwis.zapisz(
            "Cennik 2026",
            2026,
            "wydanie 2",
            imp.ocen((replace(rows[0], cena=CenaImportu("125.00", "EUR", "brutto")), *rows[1:])),
            poprzedni=poprzedni,
        )
        okno = OknoVexLab(
            PowlokaAplikacji(
                PreferencjeQt(QSettings(str(tmp / "prefs.ini"), QSettings.Format.IniFormat)),
                "uzytkownik_testowy",
                "0.70.0.dev0",
            ),
            kat,
            producenci,
            EksportujKatalog(EksportCSV()),
            imp,
            cenniki=serwis,
        )
        okno.resize(1920, 1080)
        okno.show()
        s = okno.strona_cennikow
        assert s is not None

        def czekaj() -> None:
            for _ in range(500):
                app.processEvents()
                if not okno._zadania and not s._podglad_trwa and not s._budowanie_pozycji:
                    return
                QTest.qWait(10)
            raise RuntimeError("Nie ukończono odczytu fixture")

        czekaj()
        okno.przejdz("Cenniki")
        czekaj()
        s.tabela.selectRow(0)
        czekaj()
        s.wiersze.selectRow(0)
        for motyw, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(motyw))
            for width, height in ((1366, 768), (1920, 1080), (2560, 1440), (3440, 1440)):
                okno.resize(width, height)
                QTest.qWait(100)
                czekaj()
                assert okno.grab().save(str(cel / f"vexlab-cenniki-070-{width}-{name}.png"))
        okno.close()
        app.processEvents()
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
