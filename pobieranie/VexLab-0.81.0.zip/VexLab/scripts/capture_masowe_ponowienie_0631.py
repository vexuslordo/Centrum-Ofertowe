"""Izolowany podgląd zgody na partię; bez zewnętrznej komunikacji."""

import sys
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtWidgets import QApplication, QWidget

from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.ponowienie_szkicow_allegro import PodgladNowychProb
from vexlab.przypadki_uzycia.ponowienie_szkicu_allegro import PrzygotujNoweProby
from vexlab.przypadki_uzycia.powloka import Motyw


def main() -> int:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from tests.conftest import nowe_szkice_fixture

    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    with TemporaryDirectory(prefix="vexlab-masowe-ponowienie-") as folder:
        serwis, api, repo, sesja, oferta, ustawienia = nowe_szkice_fixture.__wrapped__(Path(folder))
        plany = tuple(
            serwis.przygotuj(sesja, replace(oferta, sku=f"SKU-TEST-{i}"), ustawienia)
            for i in range(1, 4)
        )
        serwis.utworz(sesja, plany[0], lambda: False)
        proba = repo.odczytaj(serwis.klucz(sesja, plany[0].oferta.sku))
        for i, p in enumerate(plany):
            if i:
                repo.rozpocznij(
                    serwis.klucz(sesja, p.oferta.sku), replace(proba, ident=str(1000 + i))
                )
        api.wyniki.clear()
        api.czy_istnieje_oferta = lambda s, ident: ident == "1001"
        api.kandydaci_duplikatow = lambda *a: ()
        api.ean_duplikatu = lambda *a: ()
        wynik = PrzygotujNoweProby(serwis).sprawdz(sesja, plany, lambda: False, lambda *a: None)
        parent = QWidget()
        d = PodgladNowychProb(parent, wynik, "konto_testowe")
        d.resize(1000, 560)
        d.zgoda.setChecked(True)
        d.show()
        for motyw, nazwa in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motyw)
            app.processEvents()
            assert d.grab().save(str(cel / f"vexlab-masowe-ponowienie-0631-{nazwa}.png"))
        d.reject()
        parent.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
