"""Wizualna kontrola edycji: wyłącznie syntetyczne DTO, bez sieci i zapisów Allegro."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.rejestr_zapisow_allegro import RejestrZapisowJSON
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.edycja_ofert_allegro import EdycjaOfertAllegro
from vexlab.przypadki_uzycia.allegro import KontoAllegro, SesjaAllegro, SrodowiskoAllegro
from vexlab.przypadki_uzycia.edycja_ofert_allegro import EdytujOfertyAllegro, OfertaEdycji, skrot
from vexlab.przypadki_uzycia.powloka import Motyw


class Demo:
    def teraz(self):
        return 100

    def odczytaj_edycje(self, s, ident):
        return OfertaEdycji(
            ident,
            "Osłona testowa do motocykla",
            "SKU-" + ident,
            "5901234123457",
            "produkt",
            "123",
            "ACTIVE",
            "wersja",
            "ochrona",
            skrot([s.srodowisko.value, s.konto.id]),
        )

    def produkt_ean(self, *args):
        return "produkt-2", "Druga osłona testowa"

    def zmien_oferte(self, *args):
        raise AssertionError("Zrzuty nie uruchamiają zapisu")

    def operacja_szkicu(self, *args):
        return False


def main():
    app = QApplication(sys.argv)
    parent = QWidget()
    out = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    with TemporaryDirectory() as tmp:
        s = SesjaAllegro(
            KontoAllegro("demo", "Konto demonstracyjne"),
            SrodowiskoAllegro.SANDBOX,
            "syntetyczny",
            1000,
        )
        demo = Demo()
        service = EdytujOfertyAllegro(demo, RejestrZapisowJSON(Path(tmp)), demo)
        for motif, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motif)
            jobs = []
            d = EdycjaOfertAllegro(
                parent,
                service,
                s,
                ("123", "456"),
                lambda *args, queue=jobs: queue.append(args),
                lambda: True,
            )
            d.resize(1536, 800)
            d.show()

            def events(queue=jobs):
                while queue:
                    fn, ok, error = queue.pop(0)
                    ok(fn())
                for _ in range(5):
                    app.processEvents()

            d.odczytaj()
            events()
            d.tabela.item(0, 3).setText("Nowa osłona testowa do motocykla")
            d.tabela.item(0, 5).setText("SKU-NOWE-123")
            d.tabela.item(1, 7).setText("5056711605244")
            d.przygotuj()
            events()
            events()
            assert d.grab().save(str(out / f"vexlab-edycja-056-{name}.png"))
            d.reject()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
