"""Rzeczywiste okno z syntetycznym portem zamówień, bez konta lub klientów."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QSettings
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro


def main() -> int:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from dataclasses import replace

    from PySide6.QtCore import QBuffer, QIODevice
    from PySide6.QtGui import QColor, QImage, QPainter

    from tests.gui.test_allegro import Serwis
    from tests.integration.test_zamowienia_allegro import raw
    from tests.integration.test_zamowienia_presta import Transport
    from vexlab.kanaly.prestashop import PrestaAPI
    from vexlab.kanaly.zamowienia_allegro import mapuj_zamowienie
    from vexlab.kanaly.zamowienia_presta import ZamowieniaPrestaAPI
    from vexlab.przypadki_uzycia.media import ZdjecieDane
    from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
    from vexlab.przypadki_uzycia.prestashop import PolaczPresta
    from vexlab.przypadki_uzycia.zamowienia_allegro import StronaZamowien
    from vexlab.przypadki_uzycia.zamowienia_presta import OdczytajZamowieniaPresta

    image = QImage(64, 64, QImage.Format.Format_RGB32)
    image.fill(QColor("#FFFFFF"))
    painter = QPainter(image)
    painter.setBrush(QColor("#586878"))
    painter.drawRoundedRect(9, 24, 45, 16, 4, 4)
    painter.end()
    buffer = QBuffer()
    buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    image.save(buffer, "PNG")
    png = bytes(buffer.data())

    class Images:
        def pobierz_obraz(self, url):
            return ZdjecieDane(url, png, png)

    class Orders:
        def strona_zamowien(self, session, od, do, offset):
            rows = []
            for i, state in enumerate(
                ("NEW", "READY_FOR_SHIPMENT", "SENT", "CANCELLED", "NEW", "PROCESSING"), 1
            ):
                r = mapuj_zamowienie(raw(i))
                r = replace(
                    r,
                    realizacja=state,
                    kwota="123.00 " + ("PLN", "EUR", "CZK", "HUF", "PLN", "EUR")[i - 1],
                    kupiono="2026-11-18T09:00:00Z",
                    klient="Jan Testowy",
                    email="test@example.org",
                    telefon="123 456 789",
                    kraj=("PL", "CZ", "SK", "HU", "DE", "PL")[i - 1],
                    operator_platnosci="ALLEGRO",
                    status="CANCELLED" if state == "CANCELLED" else r.status,
                    zaplacono="123.00 PLN" if i in (1, 2, 3) else "",
                    platnosc="ONLINE" if i in (1, 2, 3) else r.platnosc,
                    pozycje=(replace(r.pozycje[0], oferta_id=str(100 + i)),),
                )
                rows.append(r)
            return StronaZamowien(tuple(rows), len(rows))

        def zdjecie_oferty(self, session, ident):
            return "https://fixture.example.org/" + ident

    from tests.integration.test_zamowienia_allegro import Czas, sesja

    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    cel.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix="vexlab-zamowienia-fixture-") as folder:
        tmp = Path(folder)
        repo = CennikiSQLite(tmp / "catalog.sqlite3")
        transport = Transport()
        w = OknoVexLab(
            PowlokaAplikacji(
                PreferencjeQt(QSettings(str(tmp / "prefs.ini"), QSettings.Format.IniFormat)),
                "test",
                "0.69.0.dev0",
            ),
            KatalogProduktow(repo, repo),
            RejestrProducentow(repo),
            EksportujKatalog(EksportCSV()),
            ImportujProdukty(CzytnikTabel(), repo, repo),
            allegro=Serwis(),
            presta=PolaczPresta(PrestaAPI(transport)),
            zamowienia_presta=OdczytajZamowieniaPresta(ZamowieniaPrestaAPI(transport)),
            zamowienia=OdczytajZamowieniaAllegro(Orders(), Czas(), PodgladZdjec(Images())),
        )
        w.resize(1536, 1024)
        w.show()

        def czekaj():
            for _ in range(300):
                app.processEvents()
                if not w._zadania and w._katalog_wczytany:
                    return
                QTest.qWait(10)
            raise RuntimeError("Nie ukończono odczytu fixture")

        czekaj()
        w.strona_presta.adres.setText("https://fixture.example/")
        w.strona_presta.klucz.setText("a" * 32)
        w.strona_presta.sprawdz()
        czekaj()
        w.strona_allegro.sesja = sesja()
        w.strona_allegro.obszar.ustaw_konto("test")
        w.dashboard.ustaw_allegro("test")
        w.pasek_integracji.ustaw("test")
        w.przejdz("Zamówienia")
        w.strona_zamowien.pobierz.click()
        czekaj()
        w.strona_zamowien.tabela.selectRow(0)
        for _ in range(5):
            QTest.qWait(100)
            czekaj()
        w.przejdz("Dashboard")
        for motyw, nazwa in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            w.wybor_motywu.setCurrentIndex(w.wybor_motywu.findData(motyw))
            for width, height in ((1366, 768), (1920, 1080), (2560, 1440), (3440, 1440)):
                w.resize(width, height)
                QTest.qWait(100)
                czekaj()
                w.grab().save(str(cel / f"vexlab-dashboard-069-{width}-{nazwa}.png"))
            w.resize(1536, 1024)
            w.dashboard.tablica.rozpocznij()
            QTest.qWait(100)
            w.grab().save(str(cel / f"vexlab-dashboard-069-edycja-{nazwa}.png"))
            w.dashboard.tablica.anuluj()
        w.close()
        app.processEvents()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
