"""Rzeczywiste okno z syntetycznym portem zamówień, bez konta lub klientów."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from PySide6.QtCore import QSettings
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro


def main() -> int:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from tests.integration.test_zamowienia_allegro import API, Czas, sesja

    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    cel.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix="vexlab-zamowienia-fixture-") as folder:
        tmp = Path(folder)
        repo = CennikiSQLite(tmp / "catalog.sqlite3")
        w = OknoVexLab(
            PowlokaAplikacji(
                PreferencjeQt(QSettings(str(tmp / "prefs.ini"), QSettings.Format.IniFormat)),
                "test",
                "0.67.dev0",
            ),
            KatalogProduktow(repo, repo),
            RejestrProducentow(repo),
            EksportujKatalog(EksportCSV()),
            ImportujProdukty(CzytnikTabel(), repo, repo),
            zamowienia=OdczytajZamowieniaAllegro(API(), Czas()),
        )
        w.resize(1536, 1024)
        w.show()

        def czekaj():
            for _ in range(300):
                app.processEvents()
                if not w._zadania and w._katalog_wczytany:
                    return
                QTest.qWait(10)
            raise RuntimeError("Nie ukończono odczytu fixture")

        czekaj()
        w.strona_allegro = SimpleNamespace(sesja=sesja())
        w.pasek_integracji.ustaw("test")
        w.przejdz("Zamówienia")
        w.strona_zamowien.pobierz.click()
        czekaj()
        w.strona_zamowien.tabela.selectRow(0)
        for motyw, nazwa in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            w.wybor_motywu.setCurrentIndex(w.wybor_motywu.findData(motyw))
            QTest.qWait(50)
            assert w.grab().save(str(cel / f"vexlab-zamowienia-067-{nazwa}.png"))
        w.close()
        app.processEvents()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
