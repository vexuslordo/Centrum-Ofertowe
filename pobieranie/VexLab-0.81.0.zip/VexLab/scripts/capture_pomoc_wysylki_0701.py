"""Podgląd procesu ZIP na syntetycznych danych; żadnych żądań API ani publikacji."""

import sys
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.rejestr_tworzenia_allegro import RejestrTworzeniaJSON
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    NoweSzkiceAllegro,
    ParametrSzkicu,
    ProduktSzkicu,
    UstawieniaSzkicu,
    WynikTworzenia,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.powloka import Motyw


class KatalogTestowy:
    def teraz(self):
        return 100

    def znajdz_produkty(self, *args):
        return (
            ProduktSzkicu(
                "c9e39cae-9cb6-11e9-a2a3-2a2ae2dbcce4", "Osłona testowa motocykla", "123"
            ),
        )

    def produkt_szkicu(self, s, ident):
        return ProduktSzkicu(
            ident,
            "Osłona testowa motocykla",
            "123",
            (ParametrSzkicu("11323", "Stan", "dictionary", True, (("11323_1", "Nowy"),)),),
        )


def main() -> int:
    app = QApplication(sys.argv)
    cel = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    cel.mkdir(exist_ok=True)
    parent = QWidget()
    with TemporaryDirectory(prefix="vexlab-zip-visual-") as katalog:
        api = KatalogTestowy()
        serwis = NoweSzkiceAllegro(api, RejestrTworzeniaJSON(Path(katalog)), api)
        sesja = SesjaAllegro(
            KontoAllegro("test", "konto_testowe"),
            SrodowiskoAllegro.SANDBOX,
            "fixture",
            3700,
            aplikacja=AplikacjaAllegro("fixture", "fixture", zapis_szkicow=True),
        )
        oferta = OfertaPodglad(
            1,
            "TEST-001",
            "Osłona testowa do motocykla",
            "<p>Opis testowy</p>",
            "5901234123457",
            "289.00",
            "",
            ("https://images.example.org/test.jpg",),
            (),
            (),
        )
        oferty = (
            oferta,
            replace(oferta, numer=2, sku="TEST-002", cena="319.00"),
            replace(oferta, numer=3, sku="TEST-003", cena="brak"),
        )

        def uruchom(funkcja, sukces, blad):
            # Wyłącznie szybkie fixture'y bez sieci/dysku; produkcja używa Zadanie/Qt pool.
            QTimer.singleShot(0, lambda: sukces(funkcja()))

        d = DialogNowychSzkicow(parent, serwis, sesja, oferty, uruchom)
        d.setWindowTitle("VexLab 0.70.1 • wskazówki na danych testowych")
        d.waluta.setCurrentIndex(d.waluta.findData("PLN"))
        for i in range(3):
            d.ustawienia[i] = UstawieniaSzkicu("PLN", 1, wartosci=(("11323", "11323_1"),))
        zastosuj_motyw(app, Motyw.CIEMNY)
        d.show()
        d.kompletny.setChecked(False)
        d.przygotuj()
        wyniki = []

        def gotowe():
            if d.trwa:
                QTimer.singleShot(20, gotowe)
                return
            for motyw, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
                zastosuj_motyw(app, motyw)
                for row, state in ((0, "gotowa"), (2, "blad")):
                    d.tabela.setCurrentCell(row, 4)
                    app.processEvents()
                    wyniki.append(
                        d.grab().save(str(cel / f"vexlab-pomoc-wysylki-0701-{state}-{name}.png"))
                    )
                d.wyniki = (
                    *d.wyniki[:1],
                    WynikTworzenia(
                        "TEST-002",
                        "Wynik nieznany",
                        "Przerwano połączenie podczas oczekiwania na odpowiedź Allegro.",
                    ),
                    *d.wyniki[2:],
                )
                d._pokaz_wyniki()
                d.tabela.setCurrentCell(1, 4)
                app.processEvents()
                wyniki.append(
                    d.grab().save(str(cel / f"vexlab-pomoc-wysylki-0701-nieznany-{name}.png"))
                )
            d.reject()
            app.quit()

        QTimer.singleShot(100, gotowe)
        r = app.exec()
        return r if r else int(not wyniki or not all(wyniki))


if __name__ == "__main__":
    raise SystemExit(main())
