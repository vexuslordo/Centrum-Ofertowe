"""Podgląd rzeczywistych kart GUI wyłącznie na syntetycznych adresach."""

from pathlib import Path

from PySide6.QtWidgets import QApplication, QVBoxLayout, QWidget

from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.karta_adresu import KartaAdresu
from vexlab.przypadki_uzycia.powloka import Motyw


def main() -> int:
    app = QApplication([])
    folder = Path(__file__).resolve().parents[1] / "docs/screenshots"
    folder.mkdir(exist_ok=True)
    window = QWidget()
    window.setObjectName("zamowieniaAllegro")
    layout = QVBoxLayout(window)
    for title, symbol, address in (
        (
            "Adres dostawy",
            "uzytkownik",
            "Jan Testowy\nUlica Testowa 15 / 15\n929 01 Miasto testowe\nSK",
        ),
        (
            "Punkt odbioru",
            "lokalizacja",
            "Automat testowy\nSK-TEST-2407\nUlica Przykładowa 1\n929 01 Miasto testowe\nSK",
        ),
    ):
        card = KartaAdresu(title, symbol)
        card.ustaw(address)
        layout.addWidget(card)
    window.resize(320, 360)
    window.show()
    for theme, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
        zastosuj_motyw(app, theme)
        app.processEvents()
        assert window.grab().save(str(folder / f"vexlab-adresy-0682-{name}.png"))
    window.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
