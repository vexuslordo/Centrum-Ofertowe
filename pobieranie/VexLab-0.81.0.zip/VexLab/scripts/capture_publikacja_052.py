"""Publikacja i wznowienie na danych syntetycznych, bez mutacji API."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.katalog_allegro_sqlite import KatalogAllegroSQLite
from vexlab.adaptery.publikacja_allegro_sqlite import RejestrPublikacjiSQLite
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.import_katalogu_allegro import ImportKataloguAllegro
from vexlab.gui.publikacja_allegro import PublikacjaAllegro
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.katalog_allegro import KatalogZAllegro
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.publikacja_allegro import PublikujSzkiceAllegro, SzkicPublikacji


class API:
    def teraz(self):
        return 100

    def odczytaj_publikacje(self, s, ident):
        return SzkicPublikacji(
            ident, "Osłona testowa do motocykla", "289.00", "PLN", 50, "INACTIVE", "a" * 64
        )

    def zlec_publikacje(self, *args):
        raise AssertionError("Podgląd nie publikuje")


def main() -> int:
    app = QApplication(sys.argv)
    parent = QWidget()
    out = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    with TemporaryDirectory() as tmp:
        base = Path(tmp)
        api = API()
        s = SesjaAllegro(
            KontoAllegro("test", "konto_testowe"),
            SrodowiskoAllegro.SANDBOX,
            "fixture",
            999999,
            aplikacja=AplikacjaAllegro("fixture", "fixture", zapis_szkicow=True),
        )
        service = PublikujSzkiceAllegro(api, RejestrPublikacjiSQLite(base / "pub.sqlite3"), api)
        jobs = []
        d = PublikacjaAllegro(
            parent, service, s, ("12345678",), lambda *a: jobs.append(a), lambda: True
        )
        d.resize(1100, 700)
        d.show()
        for _ in range(5):
            app.processEvents()
            while jobs:
                function, success, error = jobs.pop(0)
                success(function())
        imports = KatalogZAllegro(api, KatalogAllegroSQLite(base / "k.sqlite3"), None)
        w = ImportKataloguAllegro(parent, imports, s, lambda *a: jobs.append(a), lambda: True)
        w.resize(1100, 760)
        w.show()
        w.lista()
        w.postep.emit(4300, 14292)
        function, success, error = jobs.pop()
        error("SIEC", "Brak odpowiedzi Allegro.")
        for motif, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motif)
            app.processEvents()
            for dialog, label in ((d, "publikacja"), (w, "wznowienie")):
                if not dialog.grab().save(str(out / f"vexlab-{label}-052-{name}.png")):
                    return 1
        d.reject()
        w.reject()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
