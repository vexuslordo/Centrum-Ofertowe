"""Jeden formularz i bezpośrednie karty opisu — wyłącznie dane demonstracyjne."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from capture_przygotowanie_048 import ObrazTestowy
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QDialog

from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.adaptery.zdjecia_ofert import ZdjeciaOfert
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.edytor_opisu import TekstWizualny
from vexlab.gui.reczna_oferta import RecznaOferta
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


class BezSieci:
    def pobierz_obraz(self, url):
        raise ValueError("Podgląd nie korzysta z sieci.")


def main() -> int:
    app = QApplication(sys.argv)
    out = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    with TemporaryDirectory() as tmp:
        base = Path(tmp)
        source = base / "test.jpg"
        source.write_bytes(ObrazTestowy().pobierz_obraz("https://images.example.org/test.jpg").dane)
        photos = ZdjeciaOfert(base / "zdjecia", BezSieci())
        service = SzkiceOfert(SzkiceSQLite(base / "k.sqlite3"))
        jobs = []
        d = RecznaOferta(
            None, service, lambda *a: jobs.append(a), PodgladZdjec(photos), pliki_zdjec=photos
        )
        d.resize(1160, 950)
        d.sku.setText("SKU-TEST-001")
        d.tytul.setText("Osłona testowa do motocykla")
        d.ean.setText("5901234123457")
        d.cena.setText("289,00")
        d.lokalne = photos.importuj((source,))
        d._galeria()
        card = d.opis.karty[0]
        card.findChild(TekstWizualny).setHtml(
            "<h2>Osłona testowa do motocykla</h2>"
            "<p>Przykładowy opis produktu przygotowany bezpośrednio na stronie.</p>"
            "<ul><li>Informacje o produkcie</li><li>Własne dane i zdjęcia</li></ul>"
        )
        card.uklad.setCurrentIndex(2)
        card.zmien_uklad()
        d.opis.wstaw_obraz(card, d.lokalne[0], 1)
        d.opis.dodaj(("tekst",))
        d.opis.karty[1].findChild(TekstWizualny).setPlainText(
            "Dodatkowe informacje o produkcie. Każdą sekcję możesz edytować tutaj "
            "i przeciągnąć w inne miejsce."
        )

        def events():
            for _ in range(8):
                app.processEvents()
                while jobs:
                    fn, ok, error = jobs.pop(0)
                    ok(fn())

        for motif, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motif)
            d.show()
            d.obszar_formularza.verticalScrollBar().setValue(0)
            events()
            if not d.grab().save(str(out / f"vexlab-reczna-053-formularz-{name}.png")):
                return 1
            d.obszar_formularza.verticalScrollBar().setValue(d.opis.y() - 10)
            events()
            if not d.grab().save(str(out / f"vexlab-reczna-053-opis-{name}.png")):
                return 1
            results = []

            def preview(name=name, result=results):
                dialog = next(
                    w
                    for w in d.findChildren(QDialog)
                    if w.windowTitle() == "Podgląd oferty" and w.isVisible()
                )
                events()
                result.append(
                    dialog.grab().save(str(out / f"vexlab-reczna-053-podglad-{name}.png"))
                )
                dialog.accept()

            QTimer.singleShot(50, preview)
            d.pokaz_podglad()
            if not all(results):
                return 1
        d.reject()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
