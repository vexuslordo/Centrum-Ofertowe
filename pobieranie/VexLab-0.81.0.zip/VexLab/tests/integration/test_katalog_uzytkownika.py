import sqlite3
from contextlib import closing
from dataclasses import replace

import pytest

from tests.gui.test_podglad_oferty import png
from vexlab.adaptery.archiwum_produktow import ArchiwumProduktowZIP
from vexlab.adaptery.katalog_uzytkownika_sqlite import KatalogUzytkownikaSQLite
from vexlab.adaptery.obraz import obraz
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.importowanie import CenaImportu
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.katalog_uzytkownika import KatalogUzytkownika, ProduktUzytkownika
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec


class Zdjecia:
    def pobierz_obraz(self, url):
        return obraz(png(), url)


def serwis(tmp_path, nazwa="k.sqlite3"):
    repo = KatalogUzytkownikaSQLite(tmp_path / nazwa)
    return KatalogUzytkownika(repo, ArchiwumProduktowZIP(), PodgladZdjec(Zdjecia())), repo


def produkt():
    return ProduktUzytkownika(
        "Osłona testowa",
        "SKU-1",
        "<p>Opis</p>",
        "5901234123457",
        "Ręczny producent",
        "https://example.org",
        CenaImportu("125,50", "PLN", "brutto"),
        (obraz(png(), "https://example.org/foto.png"),),
    )


def test_produkt_producent_cena_zdjecie_persistencja_i_deduplikacja(tmp_path):
    s, repo = serwis(tmp_path)
    assert not s.producenci() and not KatalogProduktow(repo, repo).wyszukaj()
    w = s.importuj((produkt(),))
    assert w.dodane == 1 and w.istniejace == 0 and w.kopia.exists()
    again, repo2 = serwis(tmp_path)
    assert again.producenci() == ("Ręczny producent",)
    rows = KatalogProduktow(repo2, repo2).wyszukaj()
    assert len(rows) == 1 and rows[0].ean == produkt().ean
    assert rows[0].producent_nazwa == "Ręczny producent" and rows[0].ma_zdjecia
    assert rows[0].cena_sugerowana.kwota == "125.50"
    w = again.importuj((replace(produkt(), sku="sku-1", producent="RĘCZNY PRODUCENT"),))
    assert w.dodane == 0 and w.istniejace == 1
    assert len(KatalogProduktow(repo2, repo2).wyszukaj()) == 1
    assert len(again.producenci()) == 1


def test_atomowy_rollback_konflikt_ean_i_brak_nadpisania(tmp_path):
    s, repo = serwis(tmp_path)
    s.importuj((produkt(),))
    old = KatalogProduktow(repo, repo).wyszukaj()[0]
    s.importuj((replace(produkt(), nazwa="Inny tytuł", opis="Inny opis", producent="Inny"),))
    assert KatalogProduktow(repo, repo).wyszukaj()[0] == old
    assert s.producenci() == ("Ręczny producent",)
    with pytest.raises(BladScenariuszaKatalogu, match="inny EAN"):
        s.importuj(
            (
                replace(produkt(), sku="NOWY", producent="Nowy"),
                replace(produkt(), ean="5056711605244"),
            )
        )
    assert KatalogProduktow(repo, repo).wyszukaj() == [old]
    assert s.producenci() == ("Ręczny producent",)


def test_przenosny_zip_odtwarza_wszystkie_pola_i_zdjecie_bez_sieci(tmp_path):
    s, repo = serwis(tmp_path)
    s.importuj((produkt(),))
    old = KatalogProduktow(repo, repo).wyszukaj()[0]
    plik = tmp_path / "produkty.zip"
    assert s.eksportuj(plik, (old.id,)) == 1
    target, repo2 = serwis(tmp_path, "nowy.sqlite3")
    imported = target.odczytaj(plik)
    assert not KatalogProduktow(repo2, repo2).wyszukaj()
    assert imported[0].sku == old.sku and imported[0].producent == old.producent_nazwa
    assert imported[0].zdjecia[0].miniatura
    target.importuj(imported)
    new = KatalogProduktow(repo2, repo2).wyszukaj()[0]
    assert (
        new.nazwa,
        new.sku,
        new.ean,
        new.opis,
        new.producent_nazwa,
        new.cena_sugerowana.kwota,
    ) == (old.nazwa, old.sku, old.ean, old.opis, old.producent_nazwa, old.cena_sugerowana.kwota)
    assert new.ma_zdjecia
    target.importuj(imported)
    assert len(KatalogProduktow(repo2, repo2).wyszukaj()) == 1


def test_z_paczki_zachowuje_dane_przed_wysylka_i_stop_nic_nie_zapisuje(
    tmp_path, nowe_szkice_fixture
):
    case, _api, _reg, session, o, u = nowe_szkice_fixture
    plan = case.przygotuj(session, o, u)
    local, repo = serwis(tmp_path)
    with pytest.raises(BladScenariuszaKatalogu, match="Zatrzymano"):
        local.z_ofert((plan,), "Nowy producent", lambda: True)
    assert not KatalogProduktow(repo, repo).wyszukaj()
    result = local.z_ofert((plan,), "Nowy producent", lambda: False)
    assert result.dodane == 1
    row = KatalogProduktow(repo, repo).wyszukaj()[0]
    assert row.sku == o.sku and row.ean == o.ean and row.ma_zdjecia
    assert row.cena_sugerowana.kwota == o.cena
    local.powiaz(o.sku, session.konto.id, session.srodowisko.value, "123")
    with closing(sqlite3.connect(repo.plik)) as c:
        assert c.execute("SELECT produkt_id FROM oferty_produktow_allegro").fetchone()[0] == str(
            row.id
        )
    local.powiaz(o.sku, session.konto.id, session.srodowisko.value, "123")


def test_eksport_nie_nadpisuje_istniejacego_pliku(tmp_path):
    s, repo = serwis(tmp_path)
    s.importuj((produkt(),))
    row = KatalogProduktow(repo, repo).wyszukaj()[0]
    plik = tmp_path / "istnieje.zip"
    plik.write_bytes(b"zachowaj")
    with pytest.raises(BladScenariuszaKatalogu):
        s.eksportuj(plik, (row.id,))
    assert plik.read_bytes() == b"zachowaj"


def test_czesciowy_zapis_omija_konflikt_sku_i_robi_jedna_kopie(
    tmp_path, nowe_szkice_fixture, monkeypatch
):
    service, _, _, session, offer, settings = nowe_szkice_fixture
    local, repo = serwis(tmp_path)
    local.importuj((replace(produkt(), sku=offer.sku, ean="4006381333931"),))
    before = KatalogProduktow(repo, repo).wyszukaj()[0]
    copies = []
    original = repo._kopia_spojna

    def backup(*a):
        copies.append(a)
        return original(*a)

    monkeypatch.setattr(repo, "_kopia_spojna", backup)
    plans = tuple(
        service.przygotuj(session, replace(offer, sku=sku), settings)
        for sku in (offer.sku, "DOBRY-2", "DOBRY-3")
    )
    report, errors = local.z_ofert_czesciowo(
        plans, "Testowy producent", lambda: False, lambda *a: None
    )
    assert report.dodane == 2 and len(errors) == 1 and errors[0][0] == offer.sku
    assert "inny EAN" in errors[0][1] and len(copies) == 1
    rows = KatalogProduktow(repo, repo).wyszukaj()
    assert len(rows) == 3 and next(p for p in rows if p.sku == offer.sku) == before


def test_czesciowy_zapis_cofa_caly_wiersz_przy_bledzie_danych(tmp_path, monkeypatch):
    local, repo = serwis(tmp_path)
    original = repo._zapisz_produkt_uzytkownika

    def save(c, p):
        result = original(c, p)
        if p.sku == "BLEDNY":
            raise BladScenariuszaKatalogu("TEST", "Błąd danych po zapisie zdjęcia")
        return result

    monkeypatch.setattr(repo, "_zapisz_produkt_uzytkownika", save)
    report, errors = repo.zapisz_czesciowo_uzytkownika(
        (
            replace(produkt(), sku="BLEDNY", producent="Do wycofania"),
            replace(produkt(), sku="DOBRY", producent="Poprawny producent"),
        )
    )
    assert report.dodane == 1 and errors[0][0] == "BLEDNY"
    assert [p.sku for p in KatalogProduktow(repo, repo).wyszukaj()] == ["DOBRY"]
    assert local.producenci() == ("Poprawny producent",)


def test_techniczna_awaria_czesciowego_zapisu_cofa_cala_transakcje(tmp_path, monkeypatch):
    from vexlab.rdzen.kontrakty import BladTechniczny

    local, repo = serwis(tmp_path)
    original = repo._zapisz_produkt_uzytkownika

    def save(c, p):
        result = original(c, p)
        if p.sku == "AWARIA":
            raise sqlite3.OperationalError("Testowa awaria zapisu")
        return result

    monkeypatch.setattr(repo, "_zapisz_produkt_uzytkownika", save)
    with pytest.raises(BladTechniczny):
        repo.zapisz_czesciowo_uzytkownika((produkt(), replace(produkt(), sku="AWARIA")))
    assert not KatalogProduktow(repo, repo).wyszukaj() and not local.producenci()
