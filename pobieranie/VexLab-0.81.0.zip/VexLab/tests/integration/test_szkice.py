import shutil
import sqlite3
from contextlib import closing
from dataclasses import replace
from pathlib import Path

import pytest

from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.domena.produkt import KonfliktEdycji
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.szkice import SzkiceOfert
from vexlab.rdzen.kontrakty import BladTechniczny


def oferta(**zmiany):
    o = OfertaPodglad(
        1,
        "TEST-1",
        "Gotowa oferta",
        "<p>Pełny opis</p>",
        "123",
        "12,34",
        "Model",
        ("https://example.test/foto.png",),
        (
            (
                ElementPodgladu("tekst", "<p>Tekst sekcji</p>"),
                ElementPodgladu("obraz", adres="https://example.test/banner.png"),
            ),
        ),
        (),
    )
    return replace(o, **zmiany)


@pytest.fixture
def uslugi(tmp_path):
    repo = SzkiceSQLite(tmp_path / "k.sqlite3")
    kat = KatalogProduktow(repo, repo)
    return SzkiceOfert(repo), kat, repo


def test_pelna_tresc_restart_powtorzenie_wiele_szkicow_i_brak_nadpisania(uslugi):
    s, kat, repo = uslugi
    assert s.lista() == () and kat.wyszukaj() == []
    p = kat.dodaj(DaneProduktu("Katalog", "TEST-1", "Katalogowy opis"))
    o = oferta()
    plan = s.zaplanuj((o, replace(o, tytul="Druga prezentacja")), "user.zip")
    assert not plan.bledy
    w = s.zapisz(plan)
    assert w.zapisane == 2
    ponownie = SzkiceOfert(SzkiceSQLite(repo.plik))
    zapisane = ponownie.lista()
    assert len(zapisane) == 2 and zapisane[1].oferta == o
    assert kat.wyszukaj()[0] == p
    assert s.zapisz(s.zaplanuj((o,), "inna-nazwa.zip")).pominiete == 1
    s.edytuj(zapisane[1], "Nowy tytuł", "<p>Nowy opis</p>")
    d = next(x for x in s.lista() if x.id == zapisane[1].id)
    assert d.oferta.tytul == "Nowy tytuł" and d.oferta.sekcje == o.sekcje
    assert d.oferta.zdjecia == o.zdjecia and d.oferta.cena == o.cena
    assert kat.wyszukaj()[0] == p
    with pytest.raises(BladScenariuszaKatalogu):
        s.edytuj(zapisane[1], "Stara wersja", "")
    assert s.zapisz(s.zaplanuj((o,), "user.zip")).pominiete == 1


def test_samodzielne_szkice_atomowo_bledy_i_wiele_prezentacji(uslugi):
    s, kat, _ = uslugi
    o = oferta()
    plan = s.zaplanuj(
        (o, replace(o, numer=2, tytul="Inna"), replace(o, numer=3, sku="", problemy=("Brak SKU",))),
        "user.zip",
    )
    assert len(plan.bledy) == 1
    w = s.zapisz(plan)
    assert w.zapisane == 2
    assert kat.wyszukaj() == []
    assert all(d.produkt_id is None and d.wersja_produktu is None for d in s.lista())


def test_zmiana_produktu_blokada_usuniecia_i_usuniecie_szkicu(uslugi, stare_powiazania):
    s, kat, repo = uslugi
    s.zapisz(s.zaplanuj((oferta(),), "user.zip"))
    stare_powiazania(s, kat, repo)
    p = kat.wyszukaj()[0]
    kat.edytuj(p.id, p.wersja, DaneProduktu("Zmieniony katalog", p.sku))
    d = s.lista()[0]
    assert d.zrodlo_zmienione and d.oferta.tytul == "Gotowa oferta"
    p = kat.wyszukaj()[0]
    with pytest.raises(KonfliktEdycji, match="szkice"):
        repo.usun_produkty(((p.id, p.wersja),))
    kopia = s.usun(d)
    assert kopia.exists() and s.lista() == ()
    assert len(kat.wyszukaj()) == 1
    with closing(sqlite3.connect(kopia)) as c:
        assert c.execute("SELECT COUNT(*) FROM szkice").fetchone()[0] == 1
    with pytest.raises(BladScenariuszaKatalogu):
        s.usun(d)


def test_zmiana_katalogu_nie_blokuje_szkicow_a_awaria_zapisu_cofa_cala_paczke(uslugi, monkeypatch):
    s, kat, repo = uslugi
    plan = s.zaplanuj((oferta(),), "user.zip")
    kat.dodaj(DaneProduktu("Dodany równolegle", "TEST-1"))
    assert s.zapisz(plan).zapisane == 1
    assert len(s.lista()) == 1
    przed = s.lista()
    plan = s.zaplanuj((oferta(sku="TEST-3"), oferta(numer=2, sku="TEST-2")), "user.zip")
    orig = sqlite3.connect

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("INSERT INTO szkice") and '"sku": "TEST-2"' in parameters[5]:
                raise sqlite3.OperationalError("awaria")
            return super().execute(sql, parameters)

    with monkeypatch.context() as m:
        m.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
        with pytest.raises(BladTechniczny):
            s.zapisz(plan)
    assert s.lista() == przed and len(kat.wyszukaj()) == 1


def test_migracja7_kopia_i_odtworzenie(tmp_path):
    plik = tmp_path / "k.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_6.sql"
    with closing(sqlite3.connect(plik)) as c, c:
        c.executescript(fixture.read_text())
    repo = SzkiceSQLite(plik)
    assert repo.lista() == ()
    (kopia,) = (tmp_path / "kopie_migracji").glob("*.sqlite3")
    with closing(sqlite3.connect(kopia)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 6
    with closing(sqlite3.connect(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 12
        assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    odtworzona = tmp_path / "restore.sqlite3"
    shutil.copyfile(kopia, odtworzona)
    assert SzkiceSQLite(odtworzona).lista() == ()


@pytest.mark.parametrize("blad_kopii", [False, True])
def test_przerwanie7_lub_brak_kopii_blokuja_migracje(tmp_path, monkeypatch, blad_kopii):
    plik = tmp_path / "k.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_6.sql"
    with closing(sqlite3.connect(plik)) as c, c:
        c.executescript(fixture.read_text())
    if blad_kopii:
        (tmp_path / "kopie_migracji").write_text("blokada")
    orig = sqlite3.connect

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("INSERT INTO migracje VALUES (7"):
                raise sqlite3.OperationalError("awaria")
            return super().execute(sql, parameters)

    with monkeypatch.context() as m:
        if not blad_kopii:
            m.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
        with pytest.raises(BladTechniczny):
            SzkiceSQLite(plik).lista()
    with closing(orig(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 6
        assert not c.execute("SELECT 1 FROM sqlite_master WHERE name='szkice'").fetchall()


@pytest.mark.parametrize("wersja", [2, 3, 4, 5, 6, 7, 8, 9, 10, 11])
def test_migratory_rozpoznaja_ukonczona_rownolegle_migracje7(uslugi, wersja):
    _, _, repo = uslugi
    assert repo.lista() == ()
    with repo._polaczenie() as conn:
        getattr(repo, f"_migruj_do_{wersja}")(conn, True)
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 12


def test_planowanie_i_zapis_nie_czytaja_katalogu(uslugi, monkeypatch):
    s, kat, repo = uslugi

    def zakazany_odczyt(*args):
        raise AssertionError("Szkice nie mogą czytać katalogu Produktów")

    monkeypatch.setattr(repo, "wyszukaj", zakazany_odczyt)
    assert s.zapisz(s.zaplanuj((oferta(),), "user.zip")).zapisane == 1
    assert s.lista()[0].produkt_id is None


def test_edycja_ukladu_sekcji_restart_i_konflikt_bez_nadpisania(uslugi):
    s, kat, repo = uslugi
    s.zapisz(s.zaplanuj((oferta(),), "user.zip"))
    d = s.lista()[0]
    nowy = (
        (ElementPodgladu("obraz", adres="https://example.test/inny.png"),),
        (ElementPodgladu("tekst", "<p><b>Nowy</b></p>"),),
    )
    s.edytuj(d, "Po zmianie", "<p>Nowy pełny opis</p>", nowy)
    restart = SzkiceOfert(SzkiceSQLite(repo.plik))
    wynik = restart.lista()[0]
    assert wynik.oferta.sekcje == nowy and wynik.oferta.opis == "<p>Nowy pełny opis</p>"
    assert wynik.oferta.zdjecia == d.oferta.zdjecia
    assert kat.wyszukaj() == []
    with pytest.raises(BladScenariuszaKatalogu):
        s.edytuj(d, "Stara wersja", "", ())
    assert s.lista()[0] == wynik
    assert s.zapisz(s.zaplanuj((oferta(),), "user.zip")).pominiete == 1


@pytest.mark.parametrize(
    "url", ["", "file:///tmp/obraz", "https://", "https://login:haslo@example.test/a"]
)
def test_bledny_adres_zdjecia_nie_zmienia_szkicu(uslugi, url):
    s, _, _ = uslugi
    s.zapisz(s.zaplanuj((oferta(),), "user.zip"))
    d = s.lista()[0]
    with pytest.raises(BladScenariuszaKatalogu, match="HTTPS"):
        s.edytuj(d, "Nowy", "", ((ElementPodgladu("obraz", adres=url),),))
    assert s.lista()[0] == d


def test_usuwanie_wielu_szkicow_kopia_konflikt_i_produkty_bez_zmian(uslugi):
    s, kat, repo = uslugi
    s.zapisz(s.zaplanuj(tuple(oferta(numer=i, sku=f"SKU-{i}") for i in range(3)), "user.zip"))
    przed = s.lista()
    produkty = kat.wyszukaj()
    s.edytuj(przed[-1], "Zmieniony równolegle", przed[-1].oferta.opis)
    with pytest.raises(BladScenariuszaKatalogu):
        s.usun_wiele(przed)
    assert len(s.lista()) == 3
    aktualne = s.lista()
    kopia = s.usun_wiele(aktualne[:2])
    assert len(s.lista()) == 1 and kat.wyszukaj() == produkty
    with closing(sqlite3.connect(kopia)) as c:
        assert c.execute("SELECT COUNT(*) FROM szkice").fetchone()[0] == 3
        assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    s.usun_wiele(s.lista())
    assert SzkiceSQLite(repo.plik).lista() == () and kat.wyszukaj() == produkty


def test_awaria_kopii_nie_usuwaja_zadnego_szkicu(uslugi, monkeypatch):
    s, _, repo = uslugi
    s.zapisz(s.zaplanuj((oferta(), oferta(numer=2, sku="INNY")), "user.zip"))
    przed = s.lista()

    def awaria(*args):
        raise OSError("brak miejsca")

    monkeypatch.setattr(repo, "_kopia_spojna", awaria)
    with pytest.raises(BladTechniczny):
        s.usun_wiele(przed)
    assert s.lista() == przed


def test_awaria_usuwania_w_srodku_paczki_wycofuje_cala_transakcje(uslugi):
    s, _, repo = uslugi
    s.zapisz(s.zaplanuj((oferta(), oferta(numer=2, sku="INNY")), "user.zip"))
    przed = s.lista()
    with repo._polaczenie() as conn:
        conn.execute(
            f"CREATE TRIGGER awaria_usuwania BEFORE DELETE ON szkice WHEN old.id='{przed[1].id}' "
            "BEGIN SELECT RAISE(ABORT, 'test'); END"
        )
    with pytest.raises(BladTechniczny):
        s.usun_wiele(przed)
    assert s.lista() == przed


def test_usuwanie_produktu_i_szkicow_wymaga_jawnego_zakresu_i_ma_kopie(
    uslugi, tmp_path, stare_powiazania
):
    s, kat, repo = uslugi
    s.zapisz(
        s.zaplanuj(
            (
                oferta(),
                replace(oferta(), tytul="Drugi szkic"),
                oferta(sku="INNY", tytul="Inny produkt"),
            ),
            "test.zip",
        )
    )
    stare_powiazania(s, kat, repo)
    p = next(p for p in kat.wyszukaj() if p.sku == "TEST-1")
    zakres = (p,)
    with pytest.raises(BladScenariuszaKatalogu) as exc:
        kat.usun(zakres)
    assert exc.value.kod == "SZKICE_PRODUKTOW"
    szkice = kat.szkice_do_usuniecia(zakres)
    assert len(szkice) == 2
    kopia = kat.usun(zakres, szkice=szkice)
    assert [p.sku for p in kat.wyszukaj()] == ["INNY"]
    assert len(s.lista()) == 1 and s.lista()[0].oferta.sku == "INNY"
    restored = tmp_path / "restore-products.sqlite3"
    shutil.copyfile(kopia, restored)
    r = SzkiceSQLite(restored)
    assert len(r.lista()) == 3 and len(r.wyszukaj("")) == 2


def test_wspolne_usuwanie_odrzuca_zmienione_i_nowe_szkice(uslugi, stare_powiazania):
    s, kat, repo = uslugi
    s.zapisz(s.zaplanuj((oferta(),), "test.zip"))
    stare_powiazania(s, kat, repo)
    produkty = tuple(kat.wyszukaj())
    plan = kat.szkice_do_usuniecia(produkty)
    s.edytuj(s.lista()[0], "Po zmianie", "<p>Opis</p>")
    with pytest.raises(BladScenariuszaKatalogu, match="szkice zmieniły"):
        kat.usun(produkty, szkice=plan)
    plan = kat.szkice_do_usuniecia(produkty)
    s.zapisz(s.zaplanuj((oferta(tytul="Nowy szkic"),), "nowy.zip"))
    stare_powiazania(s, kat, repo)
    with pytest.raises(BladScenariuszaKatalogu, match="szkice zmieniły"):
        kat.usun(produkty, szkice=plan)
    assert len(s.lista()) == 2 and len(kat.wyszukaj()) == 1


def test_awaria_usuwania_produktow_cofa_usuniecie_szkicow(uslugi, stare_powiazania):
    s, kat, repo = uslugi
    s.zapisz(s.zaplanuj((oferta(),), "test.zip"))
    stare_powiazania(s, kat, repo)
    produkty = tuple(kat.wyszukaj())
    plan = kat.szkice_do_usuniecia(produkty)
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute(
            "CREATE TRIGGER stop_delete BEFORE DELETE ON produkty "
            "BEGIN SELECT RAISE(ABORT,'stop'); END"
        )
    with pytest.raises(BladTechniczny):
        kat.usun(produkty, szkice=plan)
    assert len(s.lista()) == 1 and tuple(kat.wyszukaj()) == produkty
