from dataclasses import replace
from datetime import UTC, datetime, timedelta

from vexlab.przypadki_uzycia.zamowienia_dashboardu import (
    RaportZamowienKanalu,
    ZamowienieDashboardu,
    podsumuj_zamowienia,
)


def raport(zrodlo="Allegro", code="PLN", kwota="100.00", dni=30):
    now = datetime.now(UTC)
    row = ZamowienieDashboardu(
        "TEST-1", zrodlo, "Klient testowy", kwota, code, "Nowe", now.isoformat()
    )
    return RaportZamowienKanalu(
        zrodlo, (now - timedelta(days=dni)).isoformat(), now.isoformat(), now.isoformat(), (row,)
    )


def test_dashboard_liczy_dwa_kanaly_i_waluty_osobno():
    a, p = raport(), raport("PrestaShop", "EUR", "50.00")
    now = datetime.now(UTC)
    result = podsumuj_zamowienia((a, p), 30, "PLN", now)
    assert result.liczba == 2 and result.obrot == "100,00 PLN"
    assert set(r.zrodlo for r in result.ostatnie) == {"Allegro", "PrestaShop"}
    assert podsumuj_zamowienia((a, p), 30, "EUR", now).obrot == "50,00 EUR"
    assert podsumuj_zamowienia((a, p), 365, "PLN", now).liczba is None
    cancelled = replace(a, pozycje=(replace(a.pozycje[0], do_obrotu=False),))
    assert podsumuj_zamowienia((cancelled,), 30, "PLN", now).obrot == "0,00 PLN"


def test_dashboard_porownuje_chwile_a_nie_napisy_stref_czasowych():
    now = datetime(2026, 11, 18, 23, 0, tzinfo=UTC)
    report = raport()
    earlier = replace(report.pozycje[0], numer="wczesniej", kiedy="2026-11-18T23:00:00+01:00")
    later = replace(earlier, numer="pozniej", kiedy="2026-11-18T22:30:00Z")
    report = replace(
        report, od="2026-11-01T00:00:00Z", do=now.isoformat(), pozycje=(earlier, later)
    )
    assert podsumuj_zamowienia((report,), 7, "PLN", now).ostatnie[0].numer == "pozniej"
