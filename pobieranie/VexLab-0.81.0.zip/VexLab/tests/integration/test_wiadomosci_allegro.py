import json
from dataclasses import replace
from urllib.parse import parse_qs, urlsplit

import pytest

from tests.integration.test_zamowienia_allegro import Czas
from tests.integration.test_zamowienia_allegro import sesja as sesja_zamowien
from vexlab.kanaly.wiadomosci_allegro import WiadomosciAllegroAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, OdpowiedzAllegro
from vexlab.przypadki_uzycia.wiadomosci_allegro import OdczytajWiadomosciAllegro


def sesja():
    s = sesja_zamowien()
    return replace(s, aplikacja=replace(s.aplikacja, odczyt_wiadomosci=True))


def watek(ident="thread-1", login="rozmowca_testowy"):
    return {
        "id": ident,
        "read": False,
        "lastMessageDateTime": "2026-11-23T10:00:00Z",
        "interlocutor": {"login": login, "avatarUrl": "https://example.invalid/avatar"},
    }


def wiadomosc(ident="message-1", thread="thread-1"):
    return {
        "id": ident,
        "status": "DELIVERED",
        "type": "MESSAGE_CENTER",
        "createdAt": "2026-11-23T10:00:00Z",
        "thread": {"id": thread},
        "author": {"login": "rozmowca_testowy", "isInterlocutor": True},
        "text": "Treść syntetyczna\n<b>bez HTML</b>",
        "subject": "Temat testowy",
        "relatesTo": {},
        "hasAdditionalAttachments": False,
        "attachments": [{"fileName": "test.txt", "url": "https://example.invalid/file"}],
    }


class Transport:
    def __init__(self, payload, status=200):
        self.payload, self.status, self.calls = payload, status, []

    def wyslij(self, *args):
        self.calls.append(args)
        return OdpowiedzAllegro(self.status, json.dumps(self.payload).encode())


def test_get_public_stronicowanie_i_brak_operacji_oznaczania_przeczytania():
    t = Transport({"threads": [watek()], "offset": 20, "limit": 20})
    uc = OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(t), Czas())
    page = uc.watki(sesja(), 20)
    assert page.offset == 20 and page.pozycje[0].login == "rozmowca_testowy"
    t.payload = {"messages": [wiadomosc()], "offset": 0, "limit": 20}
    page = uc.wiadomosci(sesja(), "thread-1")
    row = page.pozycje[0]
    assert row.tekst.endswith("<b>bez HTML</b>") and row.zalaczniki == ("test.txt",)
    assert all(call[0] == "GET" and call[3] is None for call in t.calls)
    assert all(call[2]["Accept"] == "application/vnd.allegro.public.v1+json" for call in t.calls)
    assert urlsplit(t.calls[1][1]).path == "/messaging/threads/thread-1/messages"
    assert parse_qs(urlsplit(t.calls[0][1]).query) == {"offset": ["20"], "limit": ["20"]}
    assert "rozmowca_testowy" not in repr(row) and "Treść syntetyczna" not in repr(row)
    assert "rozmowca_testowy" not in repr(page)


@pytest.mark.parametrize("offset", [-1, 1, True, 15_000_020])
def test_nieprawidlowy_offset_nie_wychodzi_do_sieci(offset):
    t = Transport({})
    with pytest.raises(BladAllegro, match="zakres"):
        OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(t), Czas()).watki(sesja(), offset)
    assert not t.calls


def test_brak_zgody_wygasniecie_i_limit_wiadomosci_bez_http():
    t = Transport({})
    uc = OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(t), Czas())
    for s in (sesja_zamowien(), replace(sesja(), aplikacja=None), replace(sesja(), wygasa=0)):
        with pytest.raises(BladAllegro):
            uc.watki(s)
    with pytest.raises(BladAllegro):
        uc.wiadomosci(sesja(), "thread-1", 15_020)
    for ident in ("../x", "x?read=true", "x/y", "", "a" * 201):
        with pytest.raises(BladAllegro):
            uc.wiadomosci(sesja(), ident)
    assert not t.calls


@pytest.mark.parametrize(
    "mutation",
    [
        lambda d: d.update(offset=1),
        lambda d: d.update(limit=True),
        lambda d: d.update(threads=[watek()] * 21),
        lambda d: d.update(threads=[watek(), watek()]),
        lambda d: d["threads"][0].update(read="false"),
        lambda d: d["threads"][0].update(lastMessageDateTime="2026-11-23"),
        lambda d: d["threads"][0].update(interlocutor=[]),
    ],
)
def test_nieprawidlowe_watki_bez_tresci_w_bledzie(mutation):
    payload = {"threads": [watek()], "offset": 0, "limit": 20}
    mutation(payload)
    t = Transport(payload)
    with pytest.raises(BladAllegro) as exc:
        OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(t), Czas()).watki(sesja())
    assert "rozmowca_testowy" not in str(exc.value)


@pytest.mark.parametrize(
    "mutation",
    [
        lambda d: d.update(thread={"id": "inne-konto"}),
        lambda d: d.update(text=17),
        lambda d: d.update(text="\x00"),
        lambda d: d.update(author={"login": "x", "isInterlocutor": 1}),
        lambda d: d.update(attachments=[{}]),
    ],
)
def test_wiadomosc_z_innego_watku_lub_bledna_jest_odrzucona(mutation):
    row = wiadomosc()
    mutation(row)
    t = Transport({"messages": [row], "offset": 0, "limit": 20})
    with pytest.raises(BladAllegro, match="treść rozmowy"):
        OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(t), Czas()).wiadomosci(sesja(), "thread-1")


@pytest.mark.parametrize(
    "status,kod", [(401, "AUTORYZACJA"), (403, "UPRAWNIENIA"), (429, "LIMIT"), (500, "HTTP")]
)
def test_odmowa_i_limit_bez_retry_lub_ujawnienia_odpowiedzi(status, kod):
    t = Transport({"private": "tresc-klienta"}, status)
    with pytest.raises(BladAllegro) as exc:
        OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(t), Czas()).watki(sesja())
    assert exc.value.kod == kod and "tresc-klienta" not in str(exc.value)
    assert len(t.calls) == 1
    if status == 403:
        assert "allegro:api:messaging" in str(exc.value)


def test_puste_listy_nullable_i_nowy_status_sa_obslugiwane():
    t = Transport({"threads": [], "offset": 0, "limit": 20})
    uc = OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(t), Czas())
    assert uc.watki(sesja()).pozycje == ()
    t.payload["threads"] = [dict(watek(), interlocutor=None, lastMessageDateTime=None)]
    assert uc.watki(sesja()).pozycje[0].login == ""
    t.payload = {"messages": [dict(wiadomosc(), status="NEW_STATUS")], "offset": 0, "limit": 20}
    assert uc.wiadomosci(sesja(), "thread-1").pozycje[0].status == "NEW_STATUS"


def test_oauth_messaging_jest_wylacznie_opcjonalny():
    t = Transport(
        {
            "device_code": "fixture",
            "user_code": "TEST",
            "verification_uri_complete": "https://allegro.pl.allegrosandbox.pl/auth",
            "expires_in": 600,
            "interval": 5,
        }
    )
    api = WiadomosciAllegroAPI(t)
    api.rozpocznij(sesja_zamowien().aplikacja)
    assert "allegro:api:messaging" not in parse_qs(t.calls[-1][3].decode())["scope"][0]
    api.rozpocznij(sesja().aplikacja)
    assert "allegro:api:messaging" in parse_qs(t.calls[-1][3].decode())["scope"][0].split()
