from dataclasses import replace

import pytest

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.ceny_cennika import etykieta_cennika, pelne_brutto
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty, Mapowanie, MapowanieCeny
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.strony_cennika import PrzegladCennika


@pytest.mark.parametrize(
    "tekst,rodzaj,wynik",
    [
        ("1340.2345", "brutto", "1340"),
        ("1340.2345000000002", "brutto", "1340"),
        ("1340.5", "brutto", "1341"),
        ("100", "netto", "123"),
        ("100.41", "netto", "124"),
        ("0", "brutto", "0"),
    ],
)
def test_pelna_kwota_bez_float(tekst, rodzaj, wynik):
    assert pelne_brutto(tekst, "PLN", rodzaj) == wynik


@pytest.mark.parametrize("tekst", ["-1", "NaN", "1e3", "abc"])
def test_bledne_kwoty_nie_sa_zgadywane(tekst):
    with pytest.raises(ValueError):
        pelne_brutto(tekst, "PLN", "brutto")


def test_import_zapis_odczyt_i_dodanie_maja_te_sama_pelna_kwote(tmp_path):
    plik = tmp_path / "cennik.csv"
    plik.write_text("Nazwa;SKU;Cena\nProdukt;ABC;1340.2345\n", encoding="utf-8-sig")
    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    importer = ImportujProdukty(CzytnikTabel(), repo, repo)
    dane = importer.odczytaj(plik)
    mapa = Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "PLN", "brutto", False, True))
    oceny = importer.zaplanuj(dane, 0, mapa, None)
    assert not oceny[0].problem
    assert oceny[0].pozycja.cena.tekst == "1340"
    assert etykieta_cennika("1340", "PLN", "brutto") == (
        "Brutto: 1340 PLN\nNetto: 1089,43 PLN (VAT 23%)"
    )
    b = BibliotekaCennikow(repo, importer)
    b.zapisz("Mój cennik", 2026, "listopad", oceny)
    c = b.lista()[0]
    restart = BibliotekaCennikow(CennikiSQLite(repo.plik), importer)
    przeglad = PrzegladCennika(restart)
    strona = przeglad.strona(c, przeglad.przygotuj(c))
    assert strona.pozycje[0].pozycja.cena.tekst == "1340"
    wynik = restart.dodaj(c, frozenset({0}))
    assert wynik.dodane == 1
    produkt = KatalogProduktow(repo, repo).wyszukaj()[0]
    assert produkt.cena_sugerowana.kwota == "1340"
    assert produkt.cena_sugerowana.rodzaj == "brutto"
    # Wyłączenie reguły zachowuje źródłową precyzję.
    oryginal = importer.zaplanuj(
        dane, 0, replace(mapa, cena=replace(mapa.cena, pelne_brutto_vat23=False)), None
    )
    assert oryginal[0].pozycja.cena.tekst == "1340.2345"
