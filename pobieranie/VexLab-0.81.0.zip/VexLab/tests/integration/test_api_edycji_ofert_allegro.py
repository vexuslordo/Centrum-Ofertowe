import json
from copy import deepcopy

import pytest

from tests.integration.test_zapis_szkicu_allegro import Czas
from vexlab.adaptery.allegro_http import _edycja_oferty
from vexlab.adaptery.rejestr_zapisow_allegro import RejestrZapisowJSON
from vexlab.kanaly.edycja_ofert_allegro import EdycjaOfertAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, OdpowiedzAllegro
from vexlab.przypadki_uzycia.edycja_ofert_allegro import EdytujOfertyAllegro

P1 = "c9e39cae-9cb6-11e9-a2a3-2a2ae2dbcce4"
P2 = "04bd97d0-396f-429d-a24f-fbfa086406af"
EAN1, EAN2 = "5901234123457", "5056711605244"


def raw():
    return {
        "id": "123",
        "name": "Testowa oferta motocykla",
        "external": {"id": "SKU-1"},
        "publication": {"status": "ACTIVE"},
        "category": {"id": "123"},
        "sellingMode": {"price": {"amount": "100.00", "currency": "PLN"}},
        "stock": {"available": 50},
        "delivery": {"shippingRates": {"id": "rates"}},
        "description": {"sections": [{"items": [{"type": "TEXT", "content": "<p>Opis</p>"}]}]},
        "images": ["https://images.example.org/photo.jpg"],
        "productSet": [
            {
                "product": {
                    "id": P1,
                    "parameters": [
                        {"id": "225693", "values": [EAN1]},
                        {"id": "inne", "values": ["wartość"]},
                    ],
                },
                "quantity": {"value": 1},
                "responsibleProducer": {"type": "ID", "id": P1},
                "responsiblePerson": {"id": P2},
                "safetyInformation": {"type": "TEXT", "description": "Ostrzeżenia użytkownika"},
            }
        ],
    }


class Transport:
    def __init__(self):
        self.offer, self.calls = raw(), []
        self.status = 200

    def wyslij(self, method, url, headers, body):
        self.calls.append((method, url, body))
        if method == "PATCH":
            data = json.loads(body)
            assert _edycja_oferty(data)
            if self.status == 200:
                self.offer.update(deepcopy(data))
            return OdpowiedzAllegro(self.status, b"{}")
        if "/sale/products?" in url:
            data = {
                "products": [
                    {"id": P2, "name": "Nowy produkt motocykla", "category": {"id": "123"}}
                ]
            }
        elif "/sale/products/" in url:
            data = {
                "id": P2,
                "category": {"id": "123"},
                "parameters": [{"id": "225693", "values": [EAN2]}],
            }
        else:
            data = self.offer
        return OdpowiedzAllegro(200, json.dumps(data).encode())


def test_tylko_tytul_i_sku_bez_produktu_i_innych_pol(tmp_path, nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    t = Transport()
    api = EdycjaOfertAPI(t)
    service = EdytujOfertyAllegro(api, RejestrZapisowJSON(tmp_path), Czas())
    base = service.odczytaj(s, "123")
    z = service.przygotuj(s, base, "Zmieniony tytul motocykla", "SKU-2", base.ean)
    assert service.zapisz(s, z) == "Zapisane"
    patches = [json.loads(c[2]) for c in t.calls if c[0] == "PATCH"]
    assert patches == [{"name": z.tytul, "external": {"id": z.sku}}]
    assert not any(c[0] in {"POST", "PUT"} for c in t.calls)
    assert t.offer["productSet"] == raw()["productSet"]


def test_ean_zmienia_istniejacy_produkt_zachowujac_gpsr_tresc_i_cene(tmp_path, nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    t = Transport()
    service = EdytujOfertyAllegro(EdycjaOfertAPI(t), RejestrZapisowJSON(tmp_path), Czas())
    base = service.odczytaj(s, "123")
    z = service.przygotuj(s, base, base.tytul, base.sku, EAN2)
    assert z.produkt == P2 and z.nazwa_produktu == "Nowy produkt motocykla"
    assert service.zapisz(s, z) == "Zapisane"
    patch = next(json.loads(c[2]) for c in t.calls if c[0] == "PATCH")
    assert set(patch) == {"productSet", "name", "description", "images"}
    assert patch["productSet"][0]["product"]["id"] == P2
    assert t.offer["sellingMode"] == raw()["sellingMode"]
    assert t.offer["publication"] == raw()["publication"]
    assert t.offer["description"] == raw()["description"]
    for field in ("responsibleProducer", "responsiblePerson", "safetyInformation", "quantity"):
        assert patch["productSet"][0][field] == raw()["productSet"][0][field]


@pytest.mark.parametrize("status", [400, 401, 403, 404, 409, 422, 429, 500])
def test_bledy_zapisu_bez_powtorzen(tmp_path, nowe_szkice_fixture, status):
    t = Transport()
    t.status = status
    s = nowe_szkice_fixture[3]
    service = EdytujOfertyAllegro(EdycjaOfertAPI(t), RejestrZapisowJSON(tmp_path), Czas())
    base = service.odczytaj(s, "123")
    z = service.przygotuj(s, base, "Zmieniony tytul motocykla", base.sku, base.ean)
    with pytest.raises(BladAllegro):
        service.zapisz(s, z)
    assert sum(c[0] == "PATCH" for c in t.calls) == 1


@pytest.mark.parametrize("field", ["publication", "sellingMode", "stock", "unknown"])
def test_guard_nie_dopuszcza_obcych_pol(field):
    assert not _edycja_oferty({"name": "Tytuł", field: {}})
    assert not _edycja_oferty({"productSet": [{"product": {"name": "nowy produkt"}}]})


def test_zestaw_i_dopasowania_blokuja_tylko_ean(tmp_path, nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    t = Transport()
    t.offer["compatibilityList"] = {"type": "PRODUCT"}
    service = EdytujOfertyAllegro(EdycjaOfertAPI(t), RejestrZapisowJSON(tmp_path), Czas())
    base = service.odczytaj(s, "123")
    assert not base.ean_mozliwy
    with pytest.raises(BladAllegro, match="w Allegro"):
        service.przygotuj(s, base, base.tytul, base.sku, EAN2)
    z = service.przygotuj(s, base, "Zmieniony tytul motocykla", base.sku, base.ean)
    assert service.zapisz(s, z) == "Zapisane"


def test_zmiana_konta_podczas_ostatniego_get_nie_wysyla_patch(tmp_path, nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    t = Transport()
    api = EdycjaOfertAPI(t)
    service = EdytujOfertyAllegro(api, RejestrZapisowJSON(tmp_path), Czas())
    base = service.odczytaj(s, "123")
    z = service.przygotuj(s, base, "Zmieniony tytul motocykla", base.sku, base.ean)
    with pytest.raises(BladAllegro, match="konto"):
        api.zmien_oferte(s, z, lambda: False)
    assert not any(c[0] == "PATCH" for c in t.calls)


def test_wiele_gtin_nie_blokuje_edycji_tytulu(tmp_path, nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    t = Transport()
    t.offer["productSet"][0]["product"]["parameters"][0]["values"] = [EAN1, EAN2]
    service = EdytujOfertyAllegro(EdycjaOfertAPI(t), RejestrZapisowJSON(tmp_path), Czas())
    base = service.odczytaj(s, "123")
    assert EAN1 in base.ean and EAN2 in base.ean
    z = service.przygotuj(s, base, "Zmieniony tytul motocykla", base.sku, base.ean)
    assert service.zapisz(s, z) == "Zapisane"
    patch = next(json.loads(c[2]) for c in t.calls if c[0] == "PATCH")
    assert set(patch) == {"name"}


def test_zmiana_kategorii_produktu_miedzy_wyszukiwaniem_a_szczegolami_blokuje_ean(
    nowe_szkice_fixture, monkeypatch
):
    from vexlab.przypadki_uzycia.nowe_szkice_allegro import ProduktSzkicu

    s = nowe_szkice_fixture[3]
    api = EdycjaOfertAPI(None)
    monkeypatch.setattr(api, "znajdz_produkty", lambda *a: (ProduktSzkicu(P2, "Produkt", "123"),))
    monkeypatch.setattr(
        api,
        "_get",
        lambda *a: {
            "id": P2,
            "category": {"id": "inna"},
            "parameters": [{"id": "225693", "values": [EAN2]}],
        },
    )
    with pytest.raises(BladAllegro, match="nie potwierdza"):
        api.produkt_ean(s, EAN2, "123")
