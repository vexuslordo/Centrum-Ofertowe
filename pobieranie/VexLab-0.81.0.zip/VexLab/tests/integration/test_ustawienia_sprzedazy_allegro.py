from copy import deepcopy
from dataclasses import replace
from uuid import UUID

import pytest

from tests.integration.test_nowe_szkice_allegro import Transport, odpowiedz
from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import pola_sprzedazy, sprawdz_ustawienia


def test_zapis_kompletnego_szkicu_i_sygnatura_sku(sprzedaz_fixture):
    service, api, _, s, o, u, _ = sprzedaz_fixture
    original = api.utworz_szkic

    def post(s, dane):
        r = original(s, dane)
        d = next(iter(api.wyniki.values()))
        # Publiczny GET ma id producenta bez type; dodatkowe pola nie blokują weryfikacji.
        d["productSet"][0]["responsibleProducer"].pop("type")
        d["validation"] = {"errors": [], "warnings": [], "validatedAt": "2026-11-13T10:00:00Z"}
        return r

    api.utworz_szkic = post
    p = service.przygotuj(s, o, u)
    assert not p.bledy
    assert service.utworz(s, p, lambda: False).stan == "Szkic kompletny"
    d = api.przeslane
    fields, gpsr = pola_sprzedazy(u.sprzedaz)
    assert all(d[k] == v for k, v in fields.items())
    assert all(d["productSet"][0][k] == v for k, v in gpsr.items())
    assert d["external"] == {"id": o.sku}
    assert d["publication"] == {"status": "INACTIVE", "republish": False}
    assert service.utworz(s, p, lambda: False).stan == "Szkic kompletny"
    assert api.calls.count("POST") == 1


@pytest.mark.parametrize(
    "pole,wartosc",
    [
        ("producent", ""),
        ("osoba", ""),
        ("bezpieczenstwo", ""),
        ("bezpieczenstwo", "x" * 5001),
        ("dostawa", "bad"),
        ("czas", "PT2H"),
        ("zwroty", ""),
        ("reklamacje", ""),
        ("gwarancja", ""),
        ("kraj", ""),
        ("kod", "12345"),
        ("wojewodztwo", ""),
        ("faktura", ""),
    ],
)
def test_braki_nie_pozwalaja_wyslac(sprzedaz_fixture, pole, wartosc):
    service, api, _, s, o, u, _ = sprzedaz_fixture
    bad = replace(u.sprzedaz, **{pole: wartosc})
    assert sprawdz_ustawienia(bad)
    p = service.przygotuj(s, o, replace(u, sprzedaz=bad))
    assert p.bledy
    with pytest.raises(BladAllegro):
        service.utworz(s, p, lambda: False)
    assert "POST" not in api.calls and "zdjecie" not in api.calls


def test_usuniety_lub_obcy_id_blokuje_preflight(sprzedaz_fixture):
    service, api, _, s, o, u, refs = sprzedaz_fixture
    api.slowniki_sprzedazy = lambda *a, **kw: replace(refs, producenci=())
    p = service.przygotuj(s, o, u)
    with pytest.raises(BladAllegro, match="nie istnieje"):
        service.utworz(s, p, lambda: False)
    assert "POST" not in api.calls


@pytest.mark.parametrize(
    "pole",
    [
        "delivery",
        "location",
        "payments",
        "afterSalesServices",
        "safetyInformation",
        "responsibleProducer",
        "responsiblePerson",
    ],
)
def test_niezapisane_pole_nie_jest_sukcesem_i_nie_ponawia_post(sprzedaz_fixture, pole):
    service, api, _, s, o, u, _ = sprzedaz_fixture
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    d = next(iter(api.wyniki.values()))
    if pole in d:
        d[pole] = None
    else:
        d["productSet"][0][pole] = None
    wynik = service.utworz(s, p, lambda: False)
    assert wynik.stan == "Utworzono — sprawdź ustawienia"
    assert wynik.ident and "Oferta została utworzona" in wynik.komunikat
    assert wynik.stan != "Szkic kompletny"
    assert api.calls.count("POST") == 1


def test_slowniki_calego_konta_strony_cache_i_brak_domyslnych_danych(sprzedaz_fixture):
    _, _, _, s, _, _, refs = sprzedaz_fixture
    groups = [
        refs.producenci,
        refs.osoby,
        refs.dostawy,
        refs.zwroty,
        refs.reklamacje,
        refs.gwarancje,
    ]
    keys = [
        "responsibleProducers",
        "responsiblePersons",
        "shippingRates",
        "returnPolicies",
        "impliedWarranties",
        "warranties",
    ]
    replies = [
        odpowiedz(
            200,
            {
                key: [{"id": r.id, "name": r.nazwa} for r in rows],
                **({"totalCount": len(rows)} if i < 2 else {}),
            },
        )
        for i, (key, rows) in enumerate(zip(keys, groups, strict=True))
    ]
    t = Transport(*replies)
    api = NoweSzkiceAPI(t)
    assert api.slowniki_sprzedazy(s) == refs
    assert api.slowniki_sprzedazy(s) == refs and len(t.calls) == 6
    assert all(m == "GET" for m, *_ in t.calls)
    assert "limit=100" in t.calls[0][1] and "/return-policies?limit=60" in t.calls[3][1]


def test_paginacja_gpsr_nie_ucina_listy(sprzedaz_fixture):
    _, _, _, s, _, _, _ = sprzedaz_fixture
    first = {"id": str(UUID(int=101)), "name": "Pierwszy"}
    second = {"id": str(UUID(int=102)), "name": "Drugi"}
    replies = [
        odpowiedz(200, {"responsibleProducers": [first], "totalCount": 2}),
        odpowiedz(200, {"responsibleProducers": [second], "totalCount": 2}),
        odpowiedz(200, {"responsiblePersons": [], "totalCount": 0}),
    ]
    replies += [
        odpowiedz(200, {key: []})
        for key in ["shippingRates", "returnPolicies", "impliedWarranties", "warranties"]
    ]
    api = NoweSzkiceAPI(Transport(*replies))
    assert len(api.slowniki_sprzedazy(s).producenci) == 2


def test_brak_scope_wskazuje_sposob_nadania(sprzedaz_fixture):
    s = sprzedaz_fixture[3]
    with pytest.raises(BladAllegro, match="settings:read"):
        NoweSzkiceAPI(Transport(odpowiedz(403, {}))).slowniki_sprzedazy(s)


def test_transport_dopuszcza_komplet_i_blokuje_obce_pola(sprzedaz_fixture, monkeypatch):
    import json

    from vexlab.adaptery import allegro_http

    service, api, _, s, o, u, _ = sprzedaz_fixture
    service.utworz(s, service.przygotuj(s, o, u), lambda: False)
    calls = []

    def opener(*a):
        calls.append(True)
        raise BladAllegro("TEST", "Dopuszczono transport")

    monkeypatch.setattr(allegro_http, "build_opener", opener)
    d = api.przeslane
    with pytest.raises(BladAllegro):
        allegro_http.HTTPSAllegro().wyslij(
            "POST", "https://api.allegro.pl/sale/product-offers", {}, json.dumps(d).encode()
        )
    assert calls
    calls.clear()
    bad = deepcopy(d)
    bad["publication"]["status"] = "ACTIVE"
    with pytest.raises(BladAllegro):
        allegro_http.HTTPSAllegro().wyslij(
            "POST", "https://api.allegro.pl/sale/product-offers", {}, json.dumps(bad).encode()
        )
    assert not calls


def test_czesciowy_odczyt_nie_blokuje_innych_list_i_nie_jest_pelnym_cache(sprzedaz_fixture):
    _, _, _, s, _, _, refs = sprzedaz_fixture
    replies = [
        odpowiedz(
            200,
            {
                "responsibleProducers": [{"id": refs.producenci[0].id, "name": "Producent"}],
                "totalCount": 1,
            },
        ),
        odpowiedz(200, {"responsiblePersons": [], "totalCount": 0}),
        odpowiedz(200, {"shippingRates": [{"id": refs.dostawy[0].id, "name": "Cennik"}]}),
        odpowiedz(200, {"returnPolicies": []}),
        odpowiedz(200, {"impliedWarranties": []}),
        odpowiedz(500, {}),
    ]
    t = Transport(*replies, odpowiedz(403, {}))
    api = NoweSzkiceAPI(t)
    result = api.slowniki_sprzedazy(s, True, True)
    assert len(result.producenci) == len(result.dostawy) == 1
    assert dict(result.bledy)["gwarancje"] and api._slowniki is None
    with pytest.raises(BladAllegro):
        api.slowniki_sprzedazy(s)
    assert len(t.calls) == 7


def test_blad_nieuzywanej_gwarancji_nie_blokuje_ale_blad_wybranego_producenta_blokuje(
    sprzedaz_fixture,
):
    from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import sprawdz_slowniki

    u = sprzedaz_fixture[5].sprzedaz
    refs = sprzedaz_fixture[-1]
    partial = replace(refs, gwarancje=(), bledy=(("gwarancje", "Błąd gwarancji"),))
    sprawdz_slowniki(u, partial)
    with pytest.raises(BladAllegro, match="Błąd producenta"):
        sprawdz_slowniki(
            u, replace(partial, producenci=(), bledy=(("producenci", "Błąd producenta"),))
        )


def test_brak_wlasnej_lokalizacji_korzysta_z_konta_i_nie_wysyla_location(sprzedaz_fixture):
    service, api, _, s, o, u, _ = sprzedaz_fixture
    config = replace(u.sprzedaz, kraj="", miasto="", kod="", wojewodztwo="")
    assert not sprawdz_ustawienia(config)
    original = api.utworz_szkic

    def post(session, dane):
        assert "location" not in dane
        result = original(session, dane)
        response = next(iter(api.wyniki.values()))
        response["location"] = {
            "countryCode": "PL",
            "city": "Z konta",
            "postCode": "00-002",
            "province": "MAZOWIECKIE",
        }
        response["validation"] = {"errors": [], "validatedAt": "2026-11-13T12:00:00Z"}
        return result

    api.utworz_szkic = post
    p = service.przygotuj(s, o, replace(u, sprzedaz=config))
    assert not p.bledy
    assert service.utworz(s, p, lambda: False).stan == "Szkic kompletny"
    assert "location" not in api.przeslane
    assert config.miasto == ""


def test_transport_dopuszcza_ustawienia_bez_nadpisywania_adresu(sprzedaz_fixture, monkeypatch):
    import json

    from vexlab.adaptery import allegro_http

    service, api, _, s, o, u, _ = sprzedaz_fixture
    service.utworz(s, service.przygotuj(s, o, u), lambda: False)
    dane = deepcopy(api.przeslane)
    dane.pop("location")
    calls = []

    def opener(*args):
        calls.append(True)
        raise BladAllegro("TEST", "Transport dopuszczony")

    monkeypatch.setattr(allegro_http, "build_opener", opener)
    with pytest.raises(BladAllegro):
        allegro_http.HTTPSAllegro().wyslij(
            "POST", "https://api.allegro.pl/sale/product-offers", {}, json.dumps(dane).encode()
        )
    assert calls


def test_rownolegle_reprezentacje_nie_powoduja_falszywego_bledu(sprzedaz_fixture):
    from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import niepotwierdzone_pola

    u = replace(
        sprzedaz_fixture[5].sprzedaz,
        producent="abcdefab-1234-5678-abcd-abcdef123456",
        osoba="nie_dotyczy",
        bezpieczenstwo="Uwaga!\nSprawdź montaż.",
    )
    fields, gpsr = pola_sprzedazy(u)
    d = {**deepcopy(fields), "productSet": [deepcopy(gpsr)]}
    d["delivery"]["handlingTime"] = "PT72H"
    d["productSet"][0]["responsibleProducer"] = {"id": u.producent.upper()}
    d["productSet"][0]["responsiblePerson"] = {"id": None}
    d["afterSalesServices"]["warranty"] = {"id": None}
    d["productSet"][0]["safetyInformation"]["description"] = "Uwaga!\r\nSprawdź montaż."
    assert niepotwierdzone_pola(d, u) == ()
    d["delivery"]["handlingTime"] = "P2D"
    assert niepotwierdzone_pola(d, u) == ("dostawa i czas wysyłki",)
    d["productSet"][0]["safetyInformation"]["description"] = "Inna instrukcja."
    assert "informacje o bezpieczeństwie" in niepotwierdzone_pola(d, u)


def test_utworzenie_z_uwaga_restart_i_pozniejsze_potwierdzenie_bez_post(sprzedaz_fixture):
    from vexlab.adaptery.rejestr_tworzenia_allegro import RejestrTworzeniaJSON
    from vexlab.przypadki_uzycia.nowe_szkice_allegro import NoweSzkiceAllegro

    service, api, repo, s, o, u, _ = sprzedaz_fixture
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    d = next(iter(api.wyniki.values()))
    zapisane = d["productSet"][0].pop("safetyInformation")
    restart = NoweSzkiceAllegro(api, RejestrTworzeniaJSON(repo.katalog), api)
    wynik = restart.utworz(s, p, lambda: False)
    assert wynik.stan == "Utworzono — sprawdź ustawienia" and wynik.ident == d["id"]
    assert "informacje o bezpieczeństwie" in wynik.komunikat
    assert u.sprzedaz.bezpieczenstwo not in wynik.komunikat
    assert api.calls.count("POST") == 1
    d["productSet"][0]["safetyInformation"] = zapisane
    d["validation"] = {"errors": [], "validatedAt": "2026-11-17T10:00:00Z"}
    assert restart.sprawdz(s, p).stan == "Szkic kompletny"
    assert api.calls.count("POST") == 1


def test_zmienione_id_lub_core_nie_udaja_utworzenia(sprzedaz_fixture):
    service, api, _, s, o, u, _ = sprzedaz_fixture
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    d = next(iter(api.wyniki.values()))
    d["productSet"][0].pop("safetyInformation")
    original = api.odczytaj_szkic
    api.odczytaj_szkic = lambda *a: {**original(*a), "id": "99999"}
    with pytest.raises(BladAllegro, match="inne ID"):
        service.sprawdz(s, p)
    api.odczytaj_szkic = original
    d["sellingMode"]["price"]["amount"] = "1.00"
    with pytest.raises(BladAllegro, match="nie odpowiada"):
        service.sprawdz(s, p)
    assert api.calls.count("POST") == 1
