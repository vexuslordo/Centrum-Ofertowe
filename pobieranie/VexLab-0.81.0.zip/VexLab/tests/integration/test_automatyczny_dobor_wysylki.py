from dataclasses import replace

import pytest

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.seria_szkicow_allegro import (
    ObserwatorSeriiSzkicow,
    WyslijSerieSzkicow,
    ZlecenieSeriiSzkicow,
)


def przygotuj(fixture):
    service, api, registry, session, offer, settings = fixture
    plan = service.przygotuj(session, offer, replace(settings, automatyczny=True))
    changed = []
    observer = ObserwatorSeriiSzkicow(
        lambda: False,
        lambda: False,
        lambda *a: None,
        lambda *a: None,
        lambda: None,
        plan_zmieniony=lambda i, p: changed.append((i, p)),
    )
    request = ZlecenieSeriiSzkicow(session, (plan,), (0,), (), frozenset({0}), "", False)
    return service, api, registry, session, plan, observer, request, changed


def test_produkt_pojawil_sie_przed_post_wybiera_katalog_bez_odrzucenia(nowe_produkty_fixture):
    service, api, _, session, plan, observer, request, changed = przygotuj(nowe_produkty_fixture)
    result = WyslijSerieSzkicow(service, None, None).wykonaj(request, observer)
    assert result[0].stan == "Utworzono szkic" and api.calls.count("POST") == 1
    assert len(changed) == 1 and not changed[0][1].ustawienia.nowy
    assert service.sprawdz(session, changed[0][1]).stan == "Utworzono szkic"


def test_po_pewnym_422_jedna_zmiana_na_katalog_i_sprawdzenie_bez_ponownego_post(
    nowe_produkty_fixture,
):
    service, api, _, session, _, observer, request, changed = przygotuj(nowe_produkty_fixture)
    original = api.utworz_szkic
    available = [False]
    api.znajdz_produkty = lambda *a: (api.produkt,) if available[0] else ()

    def utworz(s, data):
        if "id" not in data["productSet"][0]["product"]:
            available[0] = True
            api.calls.append("POST")
            raise BladAllegro("ODRZUCONO", "HTTP 422. Product already exists in Catalog")
        return original(s, data)

    api.utworz_szkic = utworz
    series = WyslijSerieSzkicow(service, None, None)
    result = series.wykonaj(request, observer)
    assert result[0].stan == "Utworzono szkic" and api.calls.count("POST") == 2
    new_plan = changed[0][1]
    result2 = series.wykonaj(
        replace(request, plany=(new_plan,), poprzednie=result, sprawdzenie=True), observer
    )
    assert result2[0].stan == "Utworzono szkic" and api.calls.count("POST") == 2


@pytest.mark.parametrize(
    "kod,opis", [("NIEZNANY", "Timeout"), ("ODRZUCONO", "HTTP 401"), ("ODRZUCONO", "HTTP 429")]
)
def test_niepewny_lub_globalny_blad_nie_uruchamia_drugiego_post(nowe_produkty_fixture, kod, opis):
    service, api, _, _, _, observer, request, changed = przygotuj(nowe_produkty_fixture)
    available = [False]
    api.znajdz_produkty = lambda *a: (api.produkt,) if available[0] else ()

    def awaria(*a):
        api.calls.append("POST")
        available[0] = True
        raise BladAllegro(kod, opis)

    api.utworz_szkic = awaria
    result = WyslijSerieSzkicow(service, None, None).wykonaj(request, observer)
    assert result[0].stan in {"Wymaga sprawdzenia", "Odrzucono"}
    assert api.calls.count("POST") == 1 and not changed


def test_manualny_nowy_produkt_nie_zmienia_sciezki_samoczynnie(nowe_produkty_fixture):
    service, api, _, _, plan, observer, request, changed = przygotuj(nowe_produkty_fixture)
    plan = replace(plan, ustawienia=replace(plan.ustawienia, automatyczny=False))
    result = WyslijSerieSzkicow(service, None, None).wykonaj(
        replace(request, plany=(plan,)), observer
    )
    assert result[0].stan == "Utworzono szkic" and not changed
    assert api.katalog is not None and api.calls.count("POST") == 1


def test_problem_doboru_jednej_pozycji_nie_zatrzymuje_nastepnej(nowe_produkty_fixture):
    service, api, _, _, plan, observer, request, _ = przygotuj(nowe_produkty_fixture)
    bad = replace(
        plan, oferta=replace(plan.oferta, sku="BRAK"), produkt=None, bledy=("Wybierz kategorię",)
    )
    good = replace(plan, ustawienia=replace(plan.ustawienia, automatyczny=False))
    result = WyslijSerieSzkicow(service, None, None).wykonaj(
        replace(request, plany=(bad, good), indeksy=(0, 1), do_utworzenia=frozenset({1})), observer
    )
    assert [r.stan for r in result] == ["Do poprawy", "Utworzono szkic"]
    assert api.calls.count("POST") == 1
