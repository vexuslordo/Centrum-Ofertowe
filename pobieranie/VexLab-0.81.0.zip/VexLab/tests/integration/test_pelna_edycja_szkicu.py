from dataclasses import replace

import pytest

from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.reczna_oferta import przygotuj_reczna
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


def utworz(tmp_path):
    repo = SzkiceSQLite(tmp_path / "k.sqlite3")
    service = SzkiceOfert(repo)
    o = replace(
        przygotuj_reczna("SKU", "Tytuł", "", "10", "<p>Opis</p>", (), ()),
        numer=12,
        dopasowanie_tekst="Źródłowy model",
    )
    service.zapisz(service.zaplanuj((o,), "paczka.zip"))
    return repo, service, service.lista()[0]


def test_ten_sam_szkic_restart_i_kopia_bez_zmiany_produktu(tmp_path):
    repo, service, old = utworz(tmp_path)
    catalog = KatalogProduktow(repo, repo)
    product = catalog.dodaj(DaneProduktu("Produkt", "SKU"))
    new = replace(old.oferta, sku="INNE-SKU", ean="5901234123457", cena="35,50")
    before = set((repo.plik.parent / "kopie_szkicow").glob("*.sqlite3"))
    service.edytuj_pelny(old, new)
    rows = SzkiceOfert(SzkiceSQLite(repo.plik)).lista()
    assert len(rows) == 1
    row = rows[0]
    assert row.id == old.id and row.wersja == old.wersja + 1
    assert row.zrodlo == old.zrodlo
    assert row.oferta == replace(new, cena="35.50")
    assert catalog.wyszukaj() == [product]
    backups = set((repo.plik.parent / "kopie_szkicow").glob("*.sqlite3")) - before
    assert len(backups) == 1
    assert SzkiceOfert(SzkiceSQLite(backups.pop())).lista()[0] == old
    assert service.zapisz(service.zaplanuj((old.oferta,), "paczka.zip")).pominiete == 1


def test_konflikt_nie_nadpisuje_pierwszego_zapisu(tmp_path):
    _repo, service, old = utworz(tmp_path)
    service.edytuj_pelny(old, replace(old.oferta, tytul="Pierwszy zapis"))
    with pytest.raises(BladScenariuszaKatalogu, match="zmienił"):
        service.edytuj_pelny(old, replace(old.oferta, tytul="Nieaktualny zapis"))
    assert service.lista()[0].oferta.tytul == "Pierwszy zapis"


@pytest.mark.parametrize("changes", [{"ean": "123"}, {"sku": ""}, {"cena": "-1"}])
def test_nieprawidlowe_dane_bez_czesciowego_zapisu(tmp_path, changes):
    _repo, service, old = utworz(tmp_path)
    with pytest.raises(BladScenariuszaKatalogu):
        service.edytuj_pelny(old, replace(old.oferta, tytul="Zmieniony", **changes))
    assert service.lista() == (old,)
