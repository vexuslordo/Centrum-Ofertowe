from dataclasses import replace

import pytest

from tests.gui.test_podglad_oferty import png
from tests.integration.test_nowe_szkice_allegro import Transport
from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.adaptery.zdjecia_ofert import ZdjeciaOfert
from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.przypadki_uzycia.allegro import OdpowiedzAllegro
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu
from vexlab.przypadki_uzycia.reczna_oferta import przygotuj_reczna
from vexlab.przypadki_uzycia.szkice import SzkiceOfert
from vexlab.rdzen.kontrakty import BladTechniczny


class BezSieci:
    def pobierz_obraz(self, url):
        raise AssertionError("Brak sieci")


def oferta(**changes):
    values = dict(
        sku="SKU-1",
        tytul="Osłona testowa do motocykla",
        ean="5901234123457",
        cena="12,50",
        opis="<p>Opis</p>",
        zdjecia=(),
        sekcje=((ElementPodgladu("tekst", "<p>Opis</p>"),),),
    )
    return przygotuj_reczna(**(values | changes))


@pytest.mark.parametrize(
    "zmiana",
    [
        {"sku": ""},
        {"tytul": ""},
        {"ean": "5901234123458"},
        {"cena": "NaN"},
        {"cena": "1e999"},
        {"cena": "-1"},
        {"cena": "12.345"},
        {"zdjecia": ("file:///etc/passwd",)},
        {"zdjecia": tuple(f"https://images.example.org/{i}.jpg" for i in range(17))},
    ],
)
def test_bledny_reczny_formularz_nie_daje_oferty(zmiana):
    with pytest.raises(ValueError):
        oferta(**zmiana)


def test_szkic_bez_produktu_i_duplikatu_odczyt_po_restarcie(tmp_path):
    path = tmp_path / "k.sqlite3"
    service = SzkiceOfert(SzkiceSQLite(path))
    o = oferta()
    assert o.cena == "12.50"
    plan = service.zaplanuj((o,), "Utworzono ręcznie")
    assert service.zapisz(plan).zapisane == 1
    assert service.zapisz(plan).pominiete == 1
    row = SzkiceOfert(SzkiceSQLite(path)).lista()[0]
    assert row.oferta == o and row.produkt_id is None and row.zrodlo == "Utworzono ręcznie"
    assert not KatalogSQLite(path).wyszukaj("")


def test_plik_ma_wlasna_kopie_po_usunieciu_oryginalu_i_jest_przeslany_binarnie(
    tmp_path, nowe_szkice_fixture
):
    source = tmp_path / "oryginal.png"
    source.write_bytes(png())
    media = ZdjeciaOfert(tmp_path / "dane", BezSieci())
    ref = media.importuj((source,))[0]
    assert media.importuj((source,)) == (ref,)
    source.unlink()
    media = ZdjeciaOfert(tmp_path / "dane", BezSieci())
    data = media.pobierz_obraz(ref).dane
    assert data.startswith(b"\xff\xd8")
    t = Transport(OdpowiedzAllegro(201, b'{"location":"https://a.allegroimg.com/photo.jpg"}'))
    api = NoweSzkiceAPI(t, media)
    assert api.wyslij_zdjecie(nowe_szkice_fixture[3], ref) == "https://a.allegroimg.com/photo.jpg"
    assert t.calls[-1][2]["Content-Type"] == "image/jpeg" and t.calls[-1][3] == data
    assert ref.encode() not in t.calls[-1][3]
    stored = next((tmp_path / "dane").glob("*.jpg"))
    stored.write_bytes(b"uszkodzone")
    with pytest.raises(BladTechniczny):
        media.pobierz_obraz(ref)


def test_lokalne_zdjecie_w_galerii_i_opisie_zamienione_na_url_allegro(nowe_szkice_fixture):
    service, api, _, s, o, u = nowe_szkice_fixture
    ref = "vexlab-image:" + "a" * 64
    original = api.wyslij_zdjecie
    uploaded = []

    def upload(session, url):
        uploaded.append(url)
        return original(session, "https://images.example.org/test.jpg")

    api.wyslij_zdjecie = upload
    o = replace(
        o,
        zdjecia=(ref,),
        sekcje=((ElementPodgladu("tekst", "<p>Opis</p>"), ElementPodgladu("obraz", adres=ref)),),
    )
    plan = service.przygotuj(s, o, u)
    assert not plan.bledy
    assert service.utworz(s, plan, lambda: False).ident
    assert uploaded == [ref]
    payload = next(iter(api.wyniki.values()))
    assert payload["images"][0].startswith("https://")
    assert payload["description"]["sections"][0]["items"][1]["url"] == payload["images"][0]
