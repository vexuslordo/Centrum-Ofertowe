from dataclasses import replace

import pytest

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.ponowienie_szkicu_allegro import PrzygotujNowaProbe


@pytest.fixture
def blokada(nowe_szkice_fixture):
    service, api, repo, s, o, u = nowe_szkice_fixture
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    old = repo.odczytaj(service.klucz(s, o.sku))
    api.czy_istnieje_oferta = lambda *a: False
    api.kandydaci_duplikatow = lambda *a: ()
    api.ean_duplikatu = lambda *a: ()
    api.wyniki.clear()
    return service, api, repo, s, p, old


def test_nowa_proba_tylko_po_potwierdzeniu_i_z_archiwum(blokada):
    service, api, repo, s, p, old = blokada
    uc = PrzygotujNowaProbe(service)
    kontrola = uc.sprawdz(s, p)
    assert repo.odczytaj(service.klucz(s, p.oferta.sku)) == old
    with pytest.raises(BladAllegro):
        uc.potwierdz(s, p, kontrola)
    uc.potwierdz(s, p, kontrola, True)
    assert repo.odczytaj(service.klucz(s, p.oferta.sku)) is None
    assert len(list(repo.katalog.glob("*.json"))) == 1
    assert api.calls.count("POST") == 1
    service.utworz(s, p, lambda: False)
    assert api.calls.count("POST") == 2


@pytest.mark.parametrize("zmiana", ["istnieje", "wygaslo", "plan", "miedzy_odczytami", "blad_api"])
def test_odmowa_gdy_istnieje_lub_kontrola_nieaktualna(blokada, zmiana):
    service, api, repo, s, p, old = blokada
    uc = PrzygotujNowaProbe(service)
    kontrola = uc.sprawdz(s, p)
    if zmiana in {"istnieje", "miedzy_odczytami"}:
        api.czy_istnieje_oferta = lambda *a: True
    elif zmiana == "wygaslo":
        api.czas += 121
    elif zmiana == "plan":
        p = replace(p, oferta=replace(p.oferta, cena="999"))
    else:
        api.czy_istnieje_oferta = lambda *a: (_ for _ in ()).throw(
            BladAllegro("SIEC", "Brak odpowiedzi")
        )
    with pytest.raises(BladAllegro):
        uc.potwierdz(s, p, kontrola, True)
    assert repo.odczytaj(service.klucz(s, p.oferta.sku)) == old
    assert api.calls.count("POST") == 1


def test_awaria_archiwum_nie_usuwa_rezerwacji(blokada, monkeypatch):
    service, api, repo, s, p, old = blokada
    uc = PrzygotujNowaProbe(service)
    kontrola = uc.sprawdz(s, p)
    monkeypatch.setattr(
        repo,
        "rozpocznij",
        lambda *a: (_ for _ in ()).throw(BladAllegro("REJESTR", "Błąd archiwum")),
    )
    with pytest.raises(BladAllegro):
        uc.potwierdz(s, p, kontrola, True)
    assert repo.odczytaj(service.klucz(s, p.oferta.sku)) == old


@pytest.mark.parametrize("status", [200, 404, 401, 403, 500])
def test_transport_tylko_404_jest_brakiem(status, nowe_szkice_fixture):
    from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
    from vexlab.przypadki_uzycia.allegro import OdpowiedzAllegro

    class Transport:
        def wyslij(self, *args):
            return OdpowiedzAllegro(status, b"{}")

    api = NoweSzkiceAPI(Transport())
    s = nowe_szkice_fixture[3]
    if status in {200, 404}:
        assert api.czy_istnieje_oferta(s, "12345678") is (status == 200)
    else:
        with pytest.raises(BladAllegro):
            api.czy_istnieje_oferta(s, "12345678")


def test_202_w_toku_blokuje_a_wygasla_operacja_wymaga_jawnej_zgody(blokada):
    service, api, repo, s, p, old = blokada
    old = replace(old, status=202, operacja="op-stara")
    repo.zapisz(service.klucz(s, p.oferta.sku), old)
    api.operacja_w_toku = lambda *a: True
    uc = PrzygotujNowaProbe(service)
    with pytest.raises(BladAllegro, match="przetwarza"):
        uc.sprawdz(s, p)
    api.operacja_w_toku = lambda *a: False
    kontrola = uc.sprawdz(s, p)
    with pytest.raises(BladAllegro):
        uc.potwierdz(s, p, kontrola)
    uc.potwierdz(s, p, kontrola, True)
    assert repo.odczytaj(service.klucz(s, p.oferta.sku)) is None
    assert api.calls.count("POST") == 1


@pytest.mark.parametrize("status", [202, 303, 404, 401, 503, 302])
def test_odczyt_operacji_respektuje_przetwarzanie_i_bledy(status, nowe_szkice_fixture):
    from vexlab.kanaly.allegro import hosty
    from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
    from vexlab.przypadki_uzycia.allegro import OdpowiedzAllegro

    s = nowe_szkice_fixture[3]
    host = hosty(s.srodowisko)[1]

    class Transport:
        def wyslij(self, metoda, url, naglowki, dane):
            assert metoda == "GET" and url.endswith("/12345678/operations/op")
            return OdpowiedzAllegro(status, b"{}", host + "/sale/product-offers/12345678")

    api = NoweSzkiceAPI(Transport())
    if status in {202, 303, 404}:
        assert api.operacja_w_toku(s, "12345678", "op") is (status == 202)
    else:
        with pytest.raises(BladAllegro):
            api.operacja_w_toku(s, "12345678", "op")
