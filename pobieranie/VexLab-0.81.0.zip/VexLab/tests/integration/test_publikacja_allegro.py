from dataclasses import replace
from uuid import uuid4

import pytest

from vexlab.adaptery.publikacja_allegro_sqlite import RejestrPublikacjiSQLite
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.publikacja_allegro import PublikujSzkiceAllegro, SzkicPublikacji


class API:
    def __init__(self):
        self.rows = {
            "123": SzkicPublikacji(
                "123", "Oferta testowa motocykla", "100.00", "PLN", 10, "INACTIVE", "a" * 64
            )
        }
        self.calls = []
        self.unknown = self.reject = False
        self.fail = None

    def teraz(self):
        return 100

    def odczytaj_publikacje(self, s, ident):
        self.calls.append(("GET", ident))
        return self.rows[ident]

    def zlec_publikacje(self, s, ident, cmd):
        self.calls.append(("PUT", ident, cmd))
        if self.reject:
            raise BladAllegro("ODRZUCONO", "Brak wymaganych danych")
        if self.unknown:
            raise BladAllegro("SIEC", "Timeout")
        self.rows[ident] = replace(self.rows[ident], status="ACTIVE")

    def raport_publikacji(self, s, ident, cmd):
        self.calls.append(("raport", cmd))
        return self.fail


@pytest.fixture
def pub(tmp_path, nowe_szkice_fixture):
    api = API()
    repo = RejestrPublikacjiSQLite(tmp_path / "pub.sqlite3")
    service = PublikujSzkiceAllegro(api, repo, api)
    s = nowe_szkice_fixture[3]
    plan = service.przygotuj(s, ("123",), lambda: False, lambda *a: None)
    return service, api, repo, s, plan


def run(pub, tylko=False, stop=lambda: False):
    service, _, _, s, plan = pub
    return service.wykonaj(s, plan, stop, lambda *a: None, tylko)[0]


def test_active_potwierdza_sukces_i_restart_nie_ponawia_put(pub):
    service, api, repo, s, plan = pub
    assert run(pub).stan == "Opublikowano"
    restored = PublikujSzkiceAllegro(api, RejestrPublikacjiSQLite(repo.plik), api)
    assert restored.wykonaj(s, plan, lambda: False, lambda *a: None)[0].stan == "Opublikowano"
    assert len([c for c in api.calls if c[0] == "PUT"]) == 1
    assert s.token.encode() not in repo.plik.read_bytes()


def test_timeout_blokuje_put_po_restarcie_i_pozwala_czytac_bez_zgody_zapisu(pub):
    service, api, repo, s, plan = pub
    api.unknown = True
    assert run(pub).stan == "Do sprawdzenia"
    assert run(pub).stan == "Do sprawdzenia"
    api.rows["123"] = replace(api.rows["123"], status="ACTIVE")
    readonly = replace(s, aplikacja=replace(s.aplikacja, zapis_szkicow=False))
    assert (
        service.wykonaj(readonly, plan, lambda: False, lambda *a: None, True)[0].stan
        == "Opublikowano"
    )
    assert len([c for c in api.calls if c[0] == "PUT"]) == 1
    assert repo.odczytaj(service.klucz(s, "123"))


def test_odmowa_pozwala_na_nowa_jawna_probe_z_nowym_uuid(pub):
    service, api, repo, s, _ = pub
    api.reject = True
    assert run(pub).stan == "Błąd" and repo.odczytaj(service.klucz(s, "123")) is None
    api.reject = False
    assert run(pub).stan == "Opublikowano"
    puts = [c for c in api.calls if c[0] == "PUT"]
    assert len(puts) == 2 and puts[0][2] != puts[1][2]


def test_koncowy_fail_wyniku_czytany_bez_powtorzenia_put(pub):
    service, api, repo, s, _ = pub
    api.unknown = True
    run(pub)
    api.fail = "Uzupełnij cennik dostaw"
    result = run(pub, True)
    assert result.stan == "Błąd" and result.opis == api.fail
    assert repo.odczytaj(service.klucz(s, "123")) is None
    assert len([c for c in api.calls if c[0] == "PUT"]) == 1


@pytest.mark.parametrize(
    "status,zmiana",
    [("ENDED", False), ("ACTIVATING", False), ("ACTIVE", False), ("INACTIVE", True)],
)
def test_nieszkic_lub_zmienione_dane_nie_publikuje(pub, status, zmiana):
    _, api, *_ = pub
    api.rows["123"] = replace(
        api.rows["123"], status=status, odcisk="b" * 64 if zmiana else "a" * 64
    )
    run(pub)
    assert not any(c[0] == "PUT" for c in api.calls)


def test_zmiana_konta_i_zatrzymanie_blokuja_zapis(pub):
    service, api, _, s, plan = pub
    other = replace(s, konto=replace(s.konto, id="inne"))
    with pytest.raises(BladAllegro, match="innego konta"):
        service.wykonaj(other, plan, lambda: False, lambda *a: None)
    assert run(pub, stop=lambda: True).stan == "Niewysłane"
    assert not any(c[0] == "PUT" for c in api.calls)


def test_atomowy_rejestr_i_warunkowe_usuniecie_nie_gubia_nowszej_proby(pub):
    service, _, repo, s, _ = pub
    key = service.klucz(s, "123")
    old, new = str(uuid4()), str(uuid4())
    repo.rozpocznij(key, old)
    with pytest.raises(BladAllegro):
        RejestrPublikacjiSQLite(repo.plik).rozpocznij(key, new)
    repo.odrzuc(key, old)
    repo.rozpocznij(key, new)
    repo.odrzuc(key, old)
    assert repo.odczytaj(key) == new


def test_uszkodzony_rejestr_blokuje_put_i_zachowuje_plik(pub):
    _, api, repo, *_ = pub
    repo.plik.write_bytes(b"uszkodzony rejestr")
    assert run(pub).stan == "Błąd"
    assert not any(c[0] == "PUT" for c in api.calls)
    assert repo.plik.read_bytes() == b"uszkodzony rejestr"


def test_plan_po_timeout_kieruje_do_odczytu_zamiast_nowego_publikowania(pub):
    service, api, _, s, _ = pub
    api.unknown = True
    run(pub)
    plan = service.przygotuj(s, ("123",), lambda: False, lambda *a: None)
    assert "Sprawdź wynik" in plan.oferty[0].blad
    service.wykonaj(s, plan, lambda: False, lambda *a: None, True)
    assert len([c for c in api.calls if c[0] == "PUT"]) == 1
