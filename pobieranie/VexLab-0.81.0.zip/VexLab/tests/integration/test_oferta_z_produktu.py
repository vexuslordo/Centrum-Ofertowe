from dataclasses import replace

import pytest

from tests.integration.test_katalog_uzytkownika import produkt, serwis
from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.adaptery.zdjecia_ofert import ZdjeciaOfert
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.importowanie import CenaImportu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.oferta_z_produktu import PrzygotujOferteZProduktu
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


class BezSieci:
    def pobierz_obraz(self, *args):
        raise AssertionError("Przygotowanie z Produktu nie pobiera zdjęć z sieci")


def setup(tmp_path, data=None):
    local, repo = serwis(tmp_path)
    local.importuj((data or produkt(),))
    row = KatalogProduktow(repo, repo).wyszukaj()[0]
    photos = ZdjeciaOfert(tmp_path / "zdjecia_ofert", BezSieci())
    source = PrzygotujOferteZProduktu(repo, repo, photos)
    return source, repo, row, photos


def test_kody_cena_opis_zdjecia_producent_bez_zmiany_produktu(tmp_path):
    source, repo, row, photos = setup(tmp_path)
    result = source.przygotuj(row.id, row.wersja)
    assert result.oferta.sku == row.sku and result.oferta.ean == row.ean
    assert result.oferta.cena == "125.50" and result.waluta == "PLN"
    assert result.producent == row.producent_nazwa
    assert result.oferta.opis == row.opis
    assert photos.pobierz_obraz(result.oferta.zdjecia[0]).dane
    assert KatalogProduktow(repo, repo).wyszukaj() == [row]
    assert SzkiceOfert(SzkiceSQLite(repo.plik)).lista() == ()


@pytest.mark.parametrize("kind,currency", [("netto", "PLN"), ("brutto", "USD")])
def test_netto_lub_inna_waluta_nie_staje_sie_cena_brutto(tmp_path, kind, currency):
    data = replace(produkt(), cena=CenaImportu("100", currency, kind))
    source, _repo, row, _photos = setup(tmp_path, data)
    result = source.przygotuj(row.id, row.wersja)
    assert result.oferta.cena == "" and "100" in result.cena_zrodlowa
    assert kind in result.cena_zrodlowa and currency in result.cena_zrodlowa
    assert result.uwaga and result.waluta == ("PLN" if currency == "PLN" else "")


def test_konflikt_wersji_blokuje_otwarcie_i_zapis_szkicu(tmp_path):
    source, repo, row, _photos = setup(tmp_path)
    result = source.przygotuj(row.id, row.wersja)
    service = SzkiceOfert(SzkiceSQLite(repo.plik))
    plan = replace(
        service.zaplanuj((result.oferta,), "Produkt"),
        produkt_id=row.id,
        wersja_produktu=row.wersja,
        producent_zrodlowy=result.producent,
        waluta_zrodlowa=result.waluta,
    )
    KatalogProduktow(repo, repo).edytuj(
        row.id, row.wersja, DaneProduktu("Zmieniona nazwa", row.sku)
    )
    with pytest.raises(BladScenariuszaKatalogu, match="zmienił"):
        source.przygotuj(row.id, row.wersja)
    with pytest.raises(BladScenariuszaKatalogu, match="zmienił"):
        service.zapisz(plan)
    assert service.lista() == ()


def test_zapis_fk_restart_metadane_edycja_i_deduplikacja(tmp_path):
    source, repo, row, photos = setup(tmp_path)
    result = source.przygotuj(row.id, row.wersja)
    service = SzkiceOfert(SzkiceSQLite(repo.plik))
    plan = replace(
        service.zaplanuj((result.oferta,), "Produkt: SKU-1"),
        produkt_id=row.id,
        wersja_produktu=row.wersja,
        producent_zrodlowy=result.producent,
        waluta_zrodlowa=result.waluta,
    )
    assert service.zapisz(plan).zapisane == 1
    assert service.zapisz(plan).pominiete == 1
    stored = SzkiceOfert(SzkiceSQLite(repo.plik)).lista()[0]
    assert stored.produkt_id == row.id and stored.wersja_produktu == row.wersja
    assert stored.producent_zrodlowy == row.producent_nazwa and stored.waluta_zrodlowa == "PLN"
    service.edytuj_pelny(stored, replace(stored.oferta, tytul="Nowa nazwa dla oferty"))
    stored = service.lista()[0]
    assert stored.waluta_zrodlowa == "PLN" and stored.producent_zrodlowy == row.producent_nazwa
    assert KatalogProduktow(repo, repo).wyszukaj() == [row]
    with repo._polaczenie() as conn:
        conn.execute("DELETE FROM zdjecia WHERE produkt_id=?", (str(row.id),))
    assert photos.pobierz_obraz(stored.oferta.zdjecia[0]).dane


def test_tekst_z_nawiasami_i_dluga_nazwa_nie_sa_gubione(tmp_path):
    data = replace(
        produkt(),
        nazwa=("Bardzo długa nazwa produktu " * 5).strip(),
        opis="Dane <moto> & opis\nDruga linia",
    )
    source, _repo, row, _photos = setup(tmp_path, data)
    result = source.przygotuj(row.id, row.wersja)
    assert result.oferta.tytul == row.nazwa and len(result.oferta.tytul) > 75
    assert "&lt;moto&gt;" in result.oferta.opis and "&amp;" in result.oferta.opis
    assert "75" in result.uwaga
