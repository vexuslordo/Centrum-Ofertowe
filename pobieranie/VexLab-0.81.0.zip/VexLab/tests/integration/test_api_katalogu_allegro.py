from urllib.parse import parse_qs, urlsplit

import pytest

from vexlab.kanaly.katalog_allegro import KatalogAllegroAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, OdpowiedzAllegro
from vexlab.przypadki_uzycia.katalog_allegro import OfertaKatalogu
from vexlab.przypadki_uzycia.nowe_szkice_allegro import ParametrSzkicu, ProduktSzkicu


def test_producent_slownikowy_z_kategorii_nie_gpsr(nowe_szkice_fixture, monkeypatch):
    s = nowe_szkice_fixture[3]
    api = KatalogAllegroAPI(None)
    d = {
        "name": "Nazwa oferty",
        "category": {"id": "123"},
        "publication": {"status": "ACTIVE"},
        "productSet": [
            {
                "product": {
                    "parameters": [
                        {"id": "maker", "valuesIds": ["mk1"]},
                        {"id": "225693", "values": ["5901234123457"]},
                    ]
                },
                "responsibleProducer": {"name": "TO NIE PRODUCENT KATALOGOWY"},
            }
        ],
        "description": {"sections": [{"items": [{"type": "TEXT", "content": "<p>Opis</p>"}]}]},
        "images": [{"url": "https://images.example.org/a.jpg"}],
    }
    monkeypatch.setattr(api, "_get", lambda *args: d)
    monkeypatch.setattr(
        api,
        "nowy_produkt",
        lambda *args: ProduktSzkicu(
            "",
            "",
            "123",
            (
                ParametrSzkicu(
                    "maker", "Producent", "dictionary", True, (("mk1", "Evotech performance"),)
                ),
                ParametrSzkicu("225693", "EAN (GTIN)", "string", False),
            ),
        ),
    )
    o = api.szczegoly_katalogu(s, OfertaKatalogu("1", "", "SKU", "ACTIVE"))
    assert o.producent == "Evotech performance" and o.ean == "5901234123457"
    assert o.opis == "<p>Opis</p>" and len(o.zdjecia) == 1
    d["productSet"][0]["product"]["parameters"][0]["valuesIds"] = ["nieznany"]
    with pytest.raises(BladAllegro, match="rozpoznać"):
        api.szczegoly_katalogu(s, OfertaKatalogu("1", "", "SKU", "ACTIVE"))


def test_pobranie_wszystkich_stron_ponad_limit_starego_widoku(nowe_szkice_fixture, monkeypatch):
    api = KatalogAllegroAPI(None)
    calls = []

    def get(env, token, url):
        q = parse_qs(urlsplit(url).query)
        offset = int(q["offset"][0])
        calls.append(offset)
        return {
            "offers": [
                {
                    "id": str(i + 1),
                    "name": "Produkt",
                    "external": {"id": "SKU" + str(i)},
                    "publication": {"status": "ACTIVE"},
                }
                for i in range(offset, min(offset + int(q["limit"][0]), 13182))
            ],
            "totalCount": 13182,
        }

    monkeypatch.setattr(api, "_get", get)
    result = api.lista_katalogu(nowe_szkice_fixture[3], lambda: False)
    assert len(result) == 13182 and len(calls) == 132 and calls[-1] == 13100


def test_zmieniona_lista_nie_oddaje_czesciowych_wynikow(nowe_szkice_fixture, monkeypatch):
    api = KatalogAllegroAPI(None)

    def get(env, token, url):
        offset = int(parse_qs(urlsplit(url).query)["offset"][0])
        return {
            "offers": [
                {
                    "id": str(offset + 1),
                    "name": "P",
                    "external": None,
                    "publication": {"status": "ACTIVE"},
                }
            ],
            "totalCount": 2 if offset == 0 else 3,
        }

    monkeypatch.setattr(api, "_get", get)
    with pytest.raises(BladAllegro):
        api.lista_katalogu(nowe_szkice_fixture[3], lambda: False)


def test_api_zakonczenia_wysyla_wylacznie_ended(nowe_szkice_fixture):
    calls = []

    class Transport:
        def wyslij(self, metoda, url, headers, data):
            calls.append((metoda, url, data))
            return OdpowiedzAllegro(202, b"{}")

    api = KatalogAllegroAPI(Transport())
    api.zakoncz_oferte(nowe_szkice_fixture[3], "123")
    assert calls[0][0] == "PATCH" and calls[0][2] == b'{"publication": {"status": "ENDED"}}'


def test_anulowanie_odczytu_nie_zwraca_paczki(nowe_szkice_fixture):
    with pytest.raises(BladAllegro, match="Zatrzymano"):
        KatalogAllegroAPI(None).lista_katalogu(nowe_szkice_fixture[3], lambda: True)


def test_duza_odpowiedz_zmniejsza_strone_bez_pominiecia_ofert(nowe_szkice_fixture, monkeypatch):
    api = KatalogAllegroAPI(None)
    calls = []

    def get(env, token, url):
        q = parse_qs(urlsplit(url).query)
        offset, limit = int(q["offset"][0]), int(q["limit"][0])
        calls.append((offset, limit))
        if limit > 25:
            raise BladAllegro("ROZMIAR", "Odpowiedź za duża")
        return {
            "offers": [
                {
                    "id": str(i + 1),
                    "name": "Produkt",
                    "external": {"id": str(i)},
                    "publication": {"status": "ACTIVE"},
                }
                for i in range(offset, min(offset + limit, 63))
            ],
            "totalCount": 63,
        }

    monkeypatch.setattr(api, "_get", get)
    progress = []
    rows = api.lista_katalogu(
        nowe_szkice_fixture[3], lambda: False, lambda i, n: progress.append((i, n))
    )
    assert progress == [(25, 63), (50, 63), (63, 63)]
    assert [r.ident for r in rows] == [str(i) for i in range(1, 64)]
    assert calls == [(0, 100), (0, 50), (0, 25), (25, 25), (50, 25)]


def strona_testowa(offset, total=450, start=0):
    return {
        "offers": [
            {
                "id": str(i + start + 1),
                "name": "Produkt",
                "external": {"id": str(i)},
                "publication": {"status": "ACTIVE"},
            }
            for i in range(offset, min(offset + 100, total))
        ],
        "totalCount": total,
    }


def test_siec_ponawia_tylko_biezaca_strone_a_po_bledzie_wznawia_od_200(
    nowe_szkice_fixture, monkeypatch
):
    api = KatalogAllegroAPI(None)
    calls, progress = [], []
    offline = True
    monkeypatch.setattr("vexlab.kanaly.katalog_allegro.time.sleep", lambda _: None)

    def get(env, token, url):
        offset = int(parse_qs(urlsplit(url).query)["offset"][0])
        calls.append(offset)
        if offline and offset == 200:
            raise BladAllegro("SIEC", "Brak odpowiedzi")
        return strona_testowa(offset)

    monkeypatch.setattr(api, "_get", get)
    with pytest.raises(BladAllegro, match="Brak odpowiedzi"):
        api.lista_katalogu(
            nowe_szkice_fixture[3], lambda: False, lambda i, n: progress.append((i, n))
        )
    assert calls == [0, 100, 200, 200, 200]
    assert progress[-1] == (200, 450)
    offline = False
    calls.clear()
    rows = api.lista_katalogu(nowe_szkice_fixture[3], lambda: False)
    assert calls == [0, 200, 300, 400]  # kontrola początku, potem brakująca strona
    assert [o.ident for o in rows] == [str(i) for i in range(1, 451)]
    calls.clear()
    api.lista_katalogu(nowe_szkice_fixture[3], lambda: False)
    assert calls == [0, 100, 200, 300, 400]  # ukończone odświeżenie nie używa checkpointu


def test_chwilowy_blad_jest_naprawiany_bez_przerwania_pobierania(nowe_szkice_fixture, monkeypatch):
    api = KatalogAllegroAPI(None)
    calls = []
    monkeypatch.setattr("vexlab.kanaly.katalog_allegro.time.sleep", lambda _: None)

    def get(env, token, url):
        offset = int(parse_qs(urlsplit(url).query)["offset"][0])
        calls.append(offset)
        if calls == [0, 100]:
            raise BladAllegro("SIEC", "Przerwa")
        return strona_testowa(offset, 250)

    monkeypatch.setattr(api, "_get", get)
    assert len(api.lista_katalogu(nowe_szkice_fixture[3], lambda: False)) == 250
    assert calls == [0, 100, 100, 200]


@pytest.mark.parametrize("inne_konto,zmieniona_lista", [(True, False), (False, True)])
def test_wznowienie_nie_miesza_kont_ani_zmienionej_listy(
    nowe_szkice_fixture, monkeypatch, inne_konto, zmieniona_lista
):
    from dataclasses import replace

    api = KatalogAllegroAPI(None)
    s = nowe_szkice_fixture[3]
    stop = False
    calls = []
    start = 0

    def get(env, token, url):
        offset = int(parse_qs(urlsplit(url).query)["offset"][0])
        calls.append(offset)
        return strona_testowa(offset, 250, start)

    def progress(i, n):
        nonlocal stop
        stop = i == 100

    monkeypatch.setattr(api, "_get", get)
    with pytest.raises(BladAllegro, match="Zatrzymano"):
        api.lista_katalogu(s, lambda: stop, progress)
    assert calls == [0]
    calls.clear()
    stop = False
    if inne_konto:
        s = replace(s, konto=replace(s.konto, id="drugie"))
    if zmieniona_lista:
        start = 1000
    rows = api.lista_katalogu(s, lambda: False)
    assert [o.ident for o in rows] == [str(i + start) for i in range(1, 251)]
    assert calls[-2:] == [100, 200]


def test_uprawnienia_nie_sa_ponawiane_jak_blad_sieci(nowe_szkice_fixture, monkeypatch):
    api = KatalogAllegroAPI(None)
    calls = []

    def get(*args):
        calls.append(1)
        raise BladAllegro("UPRAWNIENIA", "Brak zgody")

    monkeypatch.setattr(api, "_get", get)
    with pytest.raises(BladAllegro, match="Brak zgody"):
        api.lista_katalogu(nowe_szkice_fixture[3], lambda: False)
    assert calls == [1]
