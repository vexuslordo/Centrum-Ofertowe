from dataclasses import replace
from uuid import uuid4

import pytest

from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.katalog import ProduktDTO
from vexlab.przypadki_uzycia.katalog_allegro import OfertaKatalogu
from vexlab.przypadki_uzycia.statusy_produktow_allegro import (
    OdczytajStatusyProduktow,
    oznacz_statusy,
)


def sesja():
    return SesjaAllegro(
        KontoAllegro("konto", "Test"), SrodowiskoAllegro.SANDBOX, "fixture", 9999999
    )


def produkty():
    return tuple(
        ProduktDTO(uuid4(), n, n, "", 1, dostepnosc="dostepny") for n in ("SKU-1", "SKU-2", "SKU-3")
    )


class API:
    def __init__(self):
        self.rows = (
            OfertaKatalogu("10", "Test", " sku-1 ", "ACTIVE"),
            OfertaKatalogu("11", "Test", "SKU-2", "INACTIVE"),
            OfertaKatalogu("12", "Test", "SKU-1", "ENDED"),
        )

    def lista_statusow(self, s, stop, postep):
        postep(len(self.rows), len(self.rows))
        return self.rows


def test_zielona_tylko_active_po_pelnym_sku_bez_zmian_dostepnosci():
    s, p, api = sesja(), produkty(), API()
    snapshot = OdczytajStatusyProduktow(api).odczytaj(s, lambda: False, lambda *a: None)
    wynik = oznacz_statusy(p, snapshot, s)
    assert [x.allegro_aktywne for x in wynik] == [True, False, False]
    assert "ID 10" in wynik[0].allegro_opis and "ID 12" in wynik[0].allegro_opis
    assert "INACTIVE" in wynik[1].allegro_opis and "Nie znaleziono" in wynik[2].allegro_opis
    assert [x.dostepnosc for x in wynik] == ["dostepny"] * 3
    assert not any(x.allegro_aktywne for x in p)
    assert not any(x.allegro_aktywne for x in oznacz_statusy(p, None, s))
    assert not any(x.allegro_aktywne for x in oznacz_statusy(p, snapshot, None))
    assert not any(
        x.allegro_aktywne
        for x in oznacz_statusy(p, snapshot, replace(s, konto=KontoAllegro("inne", "Inne")))
    )


def test_niepublikowane_techniczne_i_podobne_sku_nie_sa_zielone():
    api = API()
    api.rows = (
        OfertaKatalogu("1", "Test", "SKU-10", "ACTIVE"),
        OfertaKatalogu("2", "Test", "", "ACTIVE"),
    )
    s, p = sesja(), produkty()
    snap = OdczytajStatusyProduktow(api).odczytaj(s, lambda: False, lambda *a: None)
    assert not any(x.allegro_aktywne for x in oznacz_statusy(p, snap, s))


def test_anulowanie_i_duplikat_id_nie_daja_czesciowej_zieleni():
    api, s = API(), sesja()
    with pytest.raises(BladAllegro):
        OdczytajStatusyProduktow(api).odczytaj(s, lambda: True, lambda *a: None)
    api.rows = api.rows + (api.rows[0],)
    with pytest.raises(BladAllegro):
        OdczytajStatusyProduktow(api).odczytaj(s, lambda: False, lambda *a: None)
