from datetime import datetime, timedelta

import pytest

from vexlab.kanaly.zamowienia_presta import ZamowieniaPrestaAPI
from vexlab.przypadki_uzycia.prestashop import BladPresta, KonfiguracjaPresta, OdpowiedzPresta


def konfiguracja():
    return KonfiguracjaPresta("https://fixture.example/", "a" * 32, "1", "1")


class Transport:
    def __init__(self):
        self.calls = []
        self.blad = False
        self.powtorz = False
        self.sklep = "1"

    def pobierz(self, k, zasob, params):
        self.calls.append((zasob, params))
        data = {
            "shops": "<shop><id>1</id><name>Sklep testowy</name><active>1</active></shop>",
            "languages": "<language><id>1</id><name>Polski</name><active>1</active></language>",
            "currencies": "<currency><id>1</id><iso_code>PLN</iso_code></currency>",
            "order_states": (
                "<order_state><id>2</id><name>"
                "<language id='1'>Opłacone</language></name></order_state>"
            ),
        }
        if zasob == "orders":
            if self.blad:
                return OdpowiedzPresta(403)
            date = (datetime.now().astimezone() - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
            row = f"""<order><id>1</id><reference>TEST-1</reference><id_customer>7</id_customer>
              <id_shop>{self.sklep}</id_shop><id_currency>1</id_currency><current_state>2</current_state>
              <total_paid_tax_incl>123.00</total_paid_tax_incl><valid>1</valid><date_add>{date}</date_add></order>"""
            data[zasob] = row + (row if self.powtorz else "")
        return OdpowiedzPresta(
            200, f"<prestashop><{zasob}>{data[zasob]}</{zasob}></prestashop>".encode()
        )


def test_presta_wybrany_sklep_waluta_i_status_bez_persistencji():
    transport = Transport()
    now = datetime.now().astimezone()
    report = ZamowieniaPrestaAPI(transport).zamowienia(
        konfiguracja(), now - timedelta(days=30), now, lambda: False
    )
    assert report.zrodlo == "PrestaShop" and len(report.pozycje) == 1
    row = report.pozycje[0]
    assert (row.numer, row.kwota, row.waluta, row.status) == ("TEST-1", "123.00", "PLN", "Opłacone")
    assert row.klient == "Klient #7" and row.do_obrotu
    params = next(p for resource, p in transport.calls if resource == "orders")
    assert params["filter[id_shop]"] == "1" and "filter[date_add]" in params


@pytest.mark.parametrize("mode", ["blad", "powtorz", "obcy_sklep"])
def test_presta_blad_lub_zmieniony_kontekst_nie_daje_czesciowego_raportu(mode):
    transport = Transport()
    if mode == "obcy_sklep":
        transport.sklep = "2"
    else:
        setattr(transport, mode, True)
    now = datetime.now().astimezone()
    with pytest.raises(BladPresta) as error:
        ZamowieniaPrestaAPI(transport).zamowienia(
            konfiguracja(), now - timedelta(days=30), now, lambda: False
        )
    assert "TEST-1" not in str(error.value)


def test_presta_anulowanie_nie_wysyla_zadania():
    transport = Transport()
    now = datetime.now().astimezone()
    with pytest.raises(BladPresta):
        ZamowieniaPrestaAPI(transport).zamowienia(
            konfiguracja(), now - timedelta(days=30), now, lambda: True
        )
    assert not transport.calls
