from dataclasses import replace

import pytest

from tests.integration.test_zamowienia_allegro import raw
from vexlab.kanaly.zamowienia_allegro import mapuj_zamowienie
from vexlab.przypadki_uzycia.zamowienia_allegro import stan_platnosci


@pytest.mark.parametrize(
    "paid,typ,status,expected",
    [
        ("123.00 PLN", "ONLINE", "READY_FOR_PROCESSING", "oplacone"),
        ("12.00 PLN", "ONLINE", "READY_FOR_PROCESSING", "czesciowo"),
        ("", "CASH_ON_DELIVERY", "READY_FOR_PROCESSING", "pobranie"),
        ("", "ONLINE", "FILLED_IN", "oczekuje"),
        ("", "ONLINE", "READY_FOR_PROCESSING", "brak"),
        ("123.00 EUR", "ONLINE", "READY_FOR_PROCESSING", "brak"),
        ("NaN PLN", "ONLINE", "READY_FOR_PROCESSING", "brak"),
    ],
)
def test_platnosc_nie_jest_utozsamiana_z_gotowoscia_ani_pobraniem(paid, typ, status, expected):
    order = replace(mapuj_zamowienie(raw()), zaplacono=paid, platnosc=typ, status=status)
    assert stan_platnosci(order) == expected
