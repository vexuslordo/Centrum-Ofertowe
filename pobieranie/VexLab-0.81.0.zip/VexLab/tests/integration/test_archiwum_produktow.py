import json
from zipfile import ZIP_DEFLATED, ZipFile

import pytest

from tests.integration.test_katalog_uzytkownika import produkt, serwis
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import KatalogProduktow


@pytest.mark.parametrize(
    "mutation", ["traversal", "hash", "duplikat", "ean", "wersja", "brak_zdjecia"]
)
def test_uszkodzone_archiwum_nie_zmienia_bazy(tmp_path, mutation):
    s, repo = serwis(tmp_path)
    s.importuj((produkt(),))
    row = KatalogProduktow(repo, repo).wyszukaj()[0]
    good = tmp_path / "good.zip"
    s.eksportuj(good, (row.id,))
    with ZipFile(good) as z:
        data = {n: z.read(n) for n in z.namelist()}
    doc = json.loads(data["katalog.json"])
    if mutation == "traversal":
        data["../outside.jpg"] = "nie wolno rozpakować".encode()
    elif mutation == "hash":
        image = next(n for n in data if n != "katalog.json")
        data[image] = b"uszkodzony obraz"
    elif mutation == "duplikat":
        doc["produkty"].append(doc["produkty"][0])
    elif mutation == "ean":
        doc["produkty"][0]["ean"] = "123"
    elif mutation == "wersja":
        doc["wersja"] = 100
    else:
        data.pop(next(n for n in data if n != "katalog.json"))
    data["katalog.json"] = json.dumps(doc).encode()
    bad = tmp_path / "bad.zip"
    with ZipFile(bad, "w", ZIP_DEFLATED) as z:
        for name, body in data.items():
            z.writestr(name, body)
    with pytest.raises(BladScenariuszaKatalogu):
        s.odczytaj(bad)
    assert KatalogProduktow(repo, repo).wyszukaj() == [row]
    assert not (tmp_path.parent / "outside.jpg").exists()


def test_archiwum_nie_zawiera_kont_sekretow_i_powiazan_allegro(tmp_path):
    s, repo = serwis(tmp_path)
    s.importuj((produkt(),))
    row = KatalogProduktow(repo, repo).wyszukaj()[0]
    s.powiaz(row.sku, "prywatne-konto", "Allegro", "123")
    plik = tmp_path / "dane.zip"
    s.eksportuj(plik, (row.id,))
    with ZipFile(plik) as z:
        manifest = z.read("katalog.json").decode()
        assert "prywatne-konto" not in manifest and "token" not in manifest
        assert set(json.loads(manifest)) == {"format", "wersja", "produkty"}
        assert all(n == "katalog.json" or n.startswith("zdjecia/") for n in z.namelist())
