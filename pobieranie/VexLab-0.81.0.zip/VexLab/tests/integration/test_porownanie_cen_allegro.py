from dataclasses import replace
from uuid import uuid4

import pytest

from vexlab.adaptery.porownanie_cen_csv import EksportPorownaniaCenCSV
from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.cenniki import CennikDTO
from vexlab.przypadki_uzycia.importowanie import CenaImportu, PozycjaImportu
from vexlab.przypadki_uzycia.katalog import DaneProduktu
from vexlab.przypadki_uzycia.katalog_allegro import OfertaKatalogu
from vexlab.przypadki_uzycia.porownanie_cen_allegro import PorownajCennikAllegro
from vexlab.rdzen.kontrakty import BladTechniczny


class Biblioteka:
    def __init__(self):
        self.c = CennikDTO(
            uuid4(), "Cennik testowy", 2026, "", "", "test.csv", "A", 3, "2026-11-18", 1
        )
        self.magazyn = self
        self.rows = tuple(
            PozycjaImportu(
                uuid4(),
                uuid4(),
                "test.csv",
                "A",
                i + 2,
                DaneProduktu("Produkt", sku),
                cena=CenaImportu(cena, "PLN", rodzaj),
            )
            for i, (sku, cena, rodzaj) in enumerate(
                (("A", "100", "netto"), ("B", "200", "brutto"), ("C", "350", "brutto"))
            )
        )
        self.zmieniony = False

    def lista(self):
        return () if self.zmieniony else (self.c,)

    def iteruj_pozycje(self, *a):
        yield from self.rows


class API:
    def __init__(self):
        self.calls = 0
        self.rows = (
            OfertaKatalogu("10", "Pierwsza", " a ", "ACTIVE", cena="100.00", waluta="PLN"),
            OfertaKatalogu("11", "Druga", "B", "ACTIVE", cena="200", waluta="PLN"),
        )

    def lista_statusow(self, s, stop, postep):
        self.calls += 1
        postep(len(self.rows), len(self.rows))
        return self.rows


@pytest.fixture
def porownanie():
    b, api = Biblioteka(), API()
    s = SesjaAllegro(KontoAllegro("konto", "Test"), SrodowiskoAllegro.SANDBOX, "fixture", 9999999)
    return PorownajCennikAllegro(b, api, EksportPorownaniaCenCSV()), b, api, s


def raport(f):
    uc, b, api, s = f
    return uc.porownaj(s, b.c, lambda: False, lambda *a: None)


def test_roznice_pelne_brutto_netto_i_brak_oferty_bez_zapisu(porownanie):
    uc, b, api, s = porownanie
    r = raport(porownanie)
    assert [p.wynik for p in r.pozycje] == ["Różnica", "Bez zmian", "Brak oferty"]
    assert (
        r.pozycje[0].docelowa,
        r.pozycje[0].netto,
        r.pozycje[0].roznica,
        r.pozycje[0].procent,
    ) == ("123", "100.00", "23.00", "23.00")
    assert api.calls == 1 and b.rows[0].cena.rodzaj == "netto"
    assert r.konto == s.konto.id and r.srodowisko == s.srodowisko.value


@pytest.mark.parametrize(
    "tryb", ["waluta", "nieaktywna", "wiele", "brak_ceny", "duplikat_sku", "zero"]
)
def test_nie_sugeruje_zmiany_dla_niejednoznacznych_danych(porownanie, tryb):
    uc, b, api, s = porownanie
    if tryb == "waluta":
        api.rows = (replace(api.rows[0], waluta="EUR"),)
    elif tryb == "nieaktywna":
        api.rows = (replace(api.rows[0], status="INACTIVE"),)
    elif tryb == "wiele":
        api.rows = (api.rows[0], replace(api.rows[0], ident="12"))
    elif tryb == "brak_ceny":
        api.rows = (replace(api.rows[0], cena="NaN"),)
    elif tryb == "duplikat_sku":
        b.rows = (b.rows[0], b.rows[0])
    elif tryb == "zero":
        b.rows = (replace(b.rows[0], cena=CenaImportu("0", "PLN", "brutto")),)
    r = raport(porownanie)
    assert r.pozycje[0].wynik not in {"Różnica", "Bez zmian"}
    assert r.pozycje[0].roznica == "" and r.pozycje[0].powod


def test_anulowanie_i_zmiana_cennika_nie_pokazuja_czesciowego_raportu(porownanie):
    uc, b, api, s = porownanie
    with pytest.raises(BladAllegro):
        uc.porownaj(s, b.c, lambda: True, lambda *a: None)
    assert api.calls == 0
    original = api.lista_statusow

    def zmien(*a):
        b.zmieniony = True
        return original(*a)

    api.lista_statusow = zmien
    with pytest.raises(BladAllegro, match="zmienił"):
        raport(porownanie)


def test_eksport_ma_kontekst_ochrone_csv_i_nie_nadpisuje(porownanie, tmp_path):
    uc, b, api, s = porownanie
    b.rows = (replace(b.rows[0], dane=DaneProduktu("=FORMULA", "00123")),)
    api.rows = (replace(api.rows[0], sku="00123"),)
    r = raport(porownanie)
    cel = tmp_path / "raport.csv"
    assert uc.eksportuj(cel, r, r.pozycje) == 1
    data = cel.read_text(encoding="utf-8-sig")
    assert "' =FORMULA" not in data and "'=FORMULA" in data
    assert '"00123"' in data and '"Test"' in data and "Allegro Sandbox" in data
    with pytest.raises(BladTechniczny):
        uc.eksportuj(cel, r, r.pozycje)
    assert cel.read_text(encoding="utf-8-sig") == data


def test_parser_odczytuje_cene_bez_zmiany_statusow_i_sku():
    from vexlab.kanaly.katalog_allegro import KatalogAllegroAPI

    rows, total = KatalogAllegroAPI._odczytaj_strone(
        {
            "offers": [
                {
                    "id": "10",
                    "name": "Test",
                    "external": {"id": "00123"},
                    "publication": {"status": "ACTIVE"},
                    "sellingMode": {"price": {"amount": "349.99", "currency": "PLN"}},
                }
            ],
            "totalCount": 1,
        },
        100,
    )
    assert (total, rows[0].sku, rows[0].cena, rows[0].waluta) == (1, "00123", "349.99", "PLN")
