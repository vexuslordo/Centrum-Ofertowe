from dataclasses import replace

import pytest

from tests.integration.test_zapis_szkicu_allegro import Czas
from vexlab.adaptery.rejestr_zapisow_allegro import RejestrZapisowJSON
from vexlab.przypadki_uzycia.allegro import BladAllegro, KontoAllegro
from vexlab.przypadki_uzycia.edycja_ofert_allegro import EdytujOfertyAllegro, OfertaEdycji, skrot
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import PrzyjecieZapisu


@pytest.fixture
def edycja(tmp_path, nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    base = OfertaEdycji(
        "123",
        "Bazowy tytul motocykla",
        "SKU-1",
        "5901234123457",
        "prod-1",
        "123",
        "ACTIVE",
        "wersja",
        "chronione",
        skrot([s.srodowisko.value, s.konto.id]),
    )

    class API:
        current = base
        patches = 0
        error = None
        async_mode = False
        fail_get = False
        after_get = None

        def odczytaj_edycje(self, session, ident):
            if self.fail_get:
                raise BladAllegro("SIEC", "Brak połączenia")
            if self.after_get:
                self.after_get()
            return self.current

        def produkt_ean(self, session, ean, category):
            return "prod-2", "Drugi produkt katalogu"

        def zmien_oferte(self, session, z, aktualne):
            assert aktualne()
            self.patches += 1
            self.current = z.oczekiwana()
            if self.error:
                raise self.error
            return PrzyjecieZapisu("operacja" if self.async_mode else "")

        def operacja_szkicu(self, *args):
            return not self.async_mode

    api = API()
    registry = RejestrZapisowJSON(tmp_path / "zapisy")
    return EdytujOfertyAllegro(api, registry, Czas()), api, registry, s, base


def test_zapis_active_ten_sam_id_i_weryfikacja_get(edycja):
    service, api, registry, s, base = edycja
    z = service.przygotuj(s, base, "Nowy tytul motocykla", "SKU-2", base.ean)
    assert service.zapisz(s, z) == "Zapisane"
    assert api.current.ident == base.ident and api.current.status == "ACTIVE"
    assert api.current.ochrona == base.ochrona and api.patches == 1
    assert registry.odczytaj(service.klucz(s, base.ident)) is None


def test_ean_pokazuje_konkretny_produkt(edycja):
    service, api, _registry, s, base = edycja
    z = service.przygotuj(s, base, base.tytul, base.sku, "5056711605244")
    assert z.produkt == "prod-2" and z.nazwa_produktu == "Drugi produkt katalogu"
    assert service.zapisz(s, z) == "Zapisane"
    assert api.current.produkt == "prod-2" and api.current.ean == z.ean


@pytest.mark.parametrize("field,value", [("tytul", "Krótki"), ("sku", ""), ("ean", "123")])
def test_walidacja_nie_wysyla_patch(edycja, field, value):
    service, api, _registry, s, base = edycja
    values = {"tytul": base.tytul, "sku": base.sku, "ean": base.ean}
    values[field] = value
    with pytest.raises(BladAllegro):
        service.przygotuj(s, base, **values)
    assert api.patches == 0


@pytest.mark.parametrize("change", ["konto", "stan", "wersja", "zgoda", "sesja"])
def test_kontekst_konflikt_i_uprawnienia_blokuja_zapis(edycja, change):
    service, api, registry, s, base = edycja
    z = service.przygotuj(s, base, "Nowy tytul motocykla", base.sku, base.ean)
    if change == "konto":
        s = replace(s, konto=KontoAllegro("inne", "inne"))
    elif change == "stan":
        api.current = replace(base, status="ENDED")
    elif change == "wersja":
        api.current = replace(base, wersja="zmieniona")
    elif change == "zgoda":
        s = replace(s, aplikacja=replace(s.aplikacja, zapis_szkicow=False))
    else:
        s = replace(s, wygasa=1)
    with pytest.raises(BladAllegro):
        service.zapisz(s, z)
    assert api.patches == 0 and registry.odczytaj(service.klucz(s, base.ident)) is None


def test_zmiana_konta_w_trakcie_preflight_bez_patch(edycja):
    service, api, _registry, s, base = edycja
    z = service.przygotuj(s, base, "Nowy tytul motocykla", base.sku, base.ean)
    current = [True]
    api.after_get = lambda: current.__setitem__(0, False)
    with pytest.raises(BladAllegro, match="konto"):
        service.zapisz(s, z, lambda: current[0])
    assert not api.patches


@pytest.mark.parametrize("async_mode", [True, False])
def test_nieznany_wynik_restart_i_get_bez_ponawiania_patch(edycja, async_mode):
    service, api, registry, s, base = edycja
    api.async_mode = async_mode
    z = service.przygotuj(s, base, "Nowy tytul motocykla", base.sku, base.ean)
    if async_mode:
        assert service.zapisz(s, z) == "Do sprawdzenia"
    else:
        api.error = BladAllegro("NIEZNANY", "Timeout po zapisie")
        with pytest.raises(BladAllegro):
            service.zapisz(s, z)
    restarted = EdytujOfertyAllegro(api, RejestrZapisowJSON(registry.katalog), Czas())
    with pytest.raises(BladAllegro):
        restarted.zapisz(s, z)
    assert api.patches == 1
    api.async_mode = False
    assert restarted.sprawdz(s, base.ident) == "Zapisane"
    assert api.patches == 1


def test_niepelne_potwierdzenie_zachowuje_blokade(edycja):
    service, api, registry, s, base = edycja
    api.async_mode = True
    z = service.przygotuj(s, base, "Nowy tytul motocykla", base.sku, base.ean)
    service.zapisz(s, z)
    api.async_mode = False
    api.current = replace(api.current, ochrona="inna cena")
    with pytest.raises(BladAllegro, match="nie potwierdza"):
        service.sprawdz(s, base.ident)
    assert registry.odczytaj(service.klucz(s, base.ident)) is not None


def test_odrzucenie_zwalnia_rezerwacje(edycja):
    service, api, registry, s, base = edycja
    api.error = BladAllegro("ODRZUCONO", "Błąd 422")
    z = service.przygotuj(s, base, "Nowy tytul motocykla", base.sku, base.ean)
    with pytest.raises(BladAllegro):
        service.zapisz(s, z)
    assert registry.odczytaj(service.klucz(s, base.ident)) is None
