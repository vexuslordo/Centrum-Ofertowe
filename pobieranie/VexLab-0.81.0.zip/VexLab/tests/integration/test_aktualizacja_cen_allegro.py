"""Izolowane próby: rejestr przetrwa restart, żaden test nie dotyka konta."""

import json
from copy import deepcopy
from dataclasses import replace

import pytest

from tests.integration import test_porownanie_cen_allegro as porownania
from tests.integration.test_zapis_szkicu_allegro import Czas
from vexlab.adaptery.allegro_http import _edycja_oferty
from vexlab.adaptery.dziennik_cen_allegro import DziennikCenSQLite
from vexlab.kanaly.aktualizacja_cen_allegro import CenyAllegroAPI
from vexlab.przypadki_uzycia.aktualizacja_cen_allegro import AktualizujCenyAllegro, CenaOferty
from vexlab.przypadki_uzycia.allegro import AplikacjaAllegro, BladAllegro, OdpowiedzAllegro
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import PrzyjecieZapisu

porownanie = porownania.porownanie


class API:
    def __init__(self):
        self.baza = CenaOferty("10", "A", "ACTIVE", "100.00", "PLN", "v1")
        self.patches = 0
        self.error = None
        self.operacja = False
        self.fail_get = False

    def odczytaj_cene(self, s, ident):
        if self.fail_get:
            raise BladAllegro("CENA", "Nie można odczytać ceny")
        return self.baza

    def zapisz_cene(self, s, baza, kwota, aktualne):
        assert aktualne()
        self.patches += 1
        self.baza = replace(baza, kwota=kwota, wersja="v2")
        if self.error:
            raise self.error
        return PrzyjecieZapisu("op" if self.operacja else "")

    def operacja_szkicu(self, *args):
        return not self.operacja


@pytest.fixture
def ceny(tmp_path, porownanie):
    por, b, _, s = porownanie
    s = replace(s, aplikacja=AplikacjaAllegro("id", "fixture", s.srodowisko, True))
    api, czas = API(), Czas()
    db = DziennikCenSQLite(tmp_path / "ceny.sqlite3")
    uc = AktualizujCenyAllegro(por, api, db, czas)
    raport = por.porownaj(s, b.c, lambda: False, lambda *a: None)
    plan = uc.przygotuj(s, raport, (raport.pozycje[0],), lambda: False, lambda *a: None)
    return uc, api, s, plan, b


def wykonaj(f):
    uc, api, s, plan, _ = f
    return uc.wykonaj(s, plan, lambda: True, lambda *a: None)


def test_cena_potwierdzona_i_dziennik_po_restarcie(ceny):
    uc, api, s, plan, _ = ceny
    rows = wykonaj(ceny)
    assert rows[0].status == "Gotowe" and api.patches == 1
    db2 = DziennikCenSQLite(uc.dziennik.plik)
    assert db2.lista(s.konto.id, s.srodowisko.value) == rows
    assert not db2.lista("inne", s.srodowisko.value)
    assert (rows[0].przed, rows[0].po) == ("100.00", "123")


@pytest.mark.parametrize("zmiana", ["cena", "sku", "konto", "cennik", "czas", "uprawnienia"])
def test_nie_wysyla_po_zmianie_podgladu(ceny, zmiana):
    uc, api, s, plan, b = ceny
    if zmiana == "cena":
        api.baza = replace(api.baza, kwota="101")
    elif zmiana == "sku":
        api.baza = replace(api.baza, sku="inne")
    elif zmiana == "konto":
        s = replace(s, konto=replace(s.konto, id="inne"))
    elif zmiana == "cennik":
        b.zmieniony = True
    elif zmiana == "czas":
        plan = replace(plan, kiedy=-1000)
    else:
        s = replace(s, aplikacja=None)
    try:
        r = uc.wykonaj(s, plan, lambda: True, lambda *a: None)
        assert r[0].status == "Niewysłane"
    except BladAllegro:
        pass
    assert api.patches == 0


def test_unknown_po_restarcie_tylko_get_i_blokada_drugiej_proby(ceny):
    uc, api, s, plan, b = ceny
    api.error = BladAllegro("NIEZNANY", "Zerwane połączenie po wysłaniu")
    rows = wykonaj(ceny)
    assert rows[0].status == "Do sprawdzenia"
    uc.dziennik = DziennikCenSQLite(uc.dziennik.plik)
    assert wykonaj(ceny)[0].status == "Niewysłane"
    assert uc.sprawdz(s, rows[0].id).status == "Gotowe"
    assert api.patches == 1


def test_async_i_stop_nie_powtarza_zapisu(ceny):
    uc, api, s, plan, b = ceny
    api.operacja = True
    r = wykonaj(ceny)[0]
    assert r.status == "Do sprawdzenia" and r.operacja == "op"
    assert uc.sprawdz(s, r.id).status == "Do sprawdzenia"
    api.operacja = False
    assert uc.sprawdz(s, r.id).status == "Gotowe" and api.patches == 1
    assert uc.wykonaj(s, plan, lambda: False, lambda *a: None)[0].status == "Niewysłane"
    assert api.patches == 1


def test_atomowa_rezerwacja_nie_pozwala_na_drugi_zapis(ceny):
    uc, api, s, plan, _ = ceny
    api.operacja = True
    r = wykonaj(ceny)[0]
    with pytest.raises(BladAllegro):
        DziennikCenSQLite(uc.dziennik.plik).rozpocznij(replace(r, id="druga"))


def test_odrzucenie_ma_powod_i_terminalny_wynik(ceny):
    uc, api, s, plan, _ = ceny
    api.error = BladAllegro("ODRZUCONO", "Allegro odrzuciło zmianę 422")
    r = wykonaj(ceny)[0]
    assert r.status == "Odrzucone" and "422" in r.powod
    assert uc.historia(s)[0].status == "Odrzucone"


class Transport:
    def __init__(self):
        self.raw = {
            "id": "10",
            "external": {"id": "A"},
            "publication": {"status": "ACTIVE", "marketplaces": {"base": {"id": "allegro-pl"}}},
            "sellingMode": {"format": "BUY_NOW", "price": {"amount": "100.00", "currency": "PLN"}},
            "stock": {"available": 7},
            "description": {"sections": []},
            "name": "Testowa oferta",
        }
        self.calls = []
        self.code = 200
        self.rules = []

    def wyslij(self, method, url, headers, body):
        self.calls.append((method, url, body))
        if url.endswith("/rules"):
            return OdpowiedzAllegro(200, json.dumps({"rules": self.rules}).encode())
        if method == "PATCH":
            payload = json.loads(body)
            assert _edycja_oferty(payload)
            assert payload == {"sellingMode": {"price": {"amount": "123.00", "currency": "PLN"}}}
            if self.code == 200:
                self.raw["sellingMode"]["price"] = payload["sellingMode"]["price"]
            return OdpowiedzAllegro(self.code, b"{}")
        return OdpowiedzAllegro(200, json.dumps(self.raw).encode())


def test_kanal_i_allowlista_wysylaja_wylacznie_cene(ceny):
    _, _, s, _, _ = ceny
    t = Transport()
    before = deepcopy(t.raw)
    api = CenyAllegroAPI(t)
    base = api.odczytaj_cene(s, "10")
    api.zapisz_cene(s, base, "123", lambda: True)
    assert [c[0] for c in t.calls] == ["GET", "GET", "GET", "GET", "PATCH"]
    assert t.raw["stock"] == before["stock"] and t.raw["description"] == before["description"]
    for bad in (
        {"sellingMode": {"format": "AUCTION"}},
        {"sellingMode": {"price": {"amount": "NaN", "currency": "PLN"}}},
        {"sellingMode": {"price": {"amount": "123.50", "currency": "PLN"}}},
        {
            "sellingMode": {"price": {"amount": "123", "currency": "PLN"}},
            "publication": {"status": "ACTIVE"},
        },
    ):
        assert not _edycja_oferty(bad)


def test_kanal_wykrywa_automatyzacje_konflikt_i_zatrzymanie(ceny):
    _, _, s, _, _ = ceny
    t = Transport()
    api = CenyAllegroAPI(t)
    base = api.odczytaj_cene(s, "10")
    with pytest.raises(BladAllegro):
        api.zapisz_cene(s, base, "123", lambda: False)
    t.raw["sellingMode"]["priceAutomation"] = {"rule": {"id": "rule"}}
    with pytest.raises(BladAllegro):
        api.odczytaj_cene(s, "10")
    assert not any(m == "PATCH" for m, _, _ in t.calls)


def test_blad_odczytu_po_przyjeciu_nie_zwalnia_blokady(ceny, monkeypatch):
    uc, api, s, plan, _ = ceny
    original = api.zapisz_cene

    def zapisz(*args):
        result = original(*args)
        api.fail_get = True
        return result

    monkeypatch.setattr(api, "zapisz_cene", zapisz)
    r = wykonaj(ceny)[0]
    assert r.status == "Do sprawdzenia" and api.patches == 1
    assert uc.historia(s)[0].status == "Do sprawdzenia"


@pytest.mark.parametrize("rynek", ["allegro-pl", "allegro-cz", "niepoprawny"])
def test_reguly_rynku_glownego_sprawdzane_osobnym_endpointem(ceny, rynek):
    _, _, s, _, _ = ceny
    t = Transport()
    t.rules = [{"marketplace": {"id": rynek}, "rule": {"id": "rule"}}]
    if rynek == "niepoprawny":
        t.rules = [{}]
    api = CenyAllegroAPI(t)
    if rynek == "allegro-cz":
        assert api.odczytaj_cene(s, "10").kwota == "100.00"
    else:
        with pytest.raises(BladAllegro):
            api.odczytaj_cene(s, "10")
    assert not any(m == "PATCH" for m, _, _ in t.calls)
