"""Własne konto syntetyczne; nigdy prawdziwe oferty ani zewnętrzne żądania."""

import json
from dataclasses import replace
from uuid import UUID

import pytest

from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.kanaly.przelicznik_cen_allegro import potwierdz_przelicznik, reguly_kursowe
from vexlab.przypadki_uzycia.allegro import BladAllegro, OdpowiedzAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import USTAWIENIA_DO_SPRAWDZENIA, NoweSzkiceAllegro
from vexlab.przypadki_uzycia.przelicznik_cen_allegro import PrzelicznikCen, RegulaKursowa


@pytest.fixture
def kurs(nowe_szkice_fixture):
    service, api, repo, s, o, u = nowe_szkice_fixture
    state = {"przypiete": False, "post": [], "timeout": False, "blad": ""}
    rule = PrzelicznikCen(
        "rule-exchange", ("allegro-cz", "allegro-hu"), s.konto.id, s.srodowisko.value
    )
    api.reguly_kursowe = lambda *a: (RegulaKursowa(rule.regula, "Przelicznik cen"),)
    api.przelicznik_potwierdzony = lambda *a: state["przypiete"]
    api.wynik_przelicznika = lambda *a: state["blad"] or "Operacja w toku."
    original = api.utworz_szkic

    def post(s, data):
        result = original(s, data)
        api.wyniki[o.sku]["publication"]["marketplaces"] = {"base": {"id": "allegro-pl"}}
        return result

    def przypnij(s, ident, ustawienia, komenda):
        state["post"].append((s.konto.id, ident, ustawienia, komenda))
        UUID(komenda)
        if state["timeout"]:
            raise BladAllegro("NIEZNANY", "Timeout przelicznika.")
        if not state["blad"]:
            state["przypiete"] = True

    api.utworz_szkic, api.przypnij_przelicznik = post, przypnij
    u = replace(u, przelicznik=rule)
    return service, api, repo, s, o, u, state


def test_przypiecie_po_utworzeniu_i_sprawdzanie_tylko_get(kurs):
    service, api, repo, s, o, u, state = kurs
    p = service.przygotuj(s, o, u)
    assert not p.bledy
    result = service.utworz(s, p, lambda: False)
    assert result.ident and result.stan == USTAWIENIA_DO_SPRAWDZENIA
    assert state["post"] == []
    assert service.sprawdz(s, p).stan == USTAWIENIA_DO_SPRAWDZENIA
    assert state["post"] == []
    result = service.dokoncz_przelicznik(s, p, lambda: False)
    assert result.stan == "Utworzono szkic" and "potwierdzony" in result.komunikat
    assert len(state["post"]) == api.calls.count("POST") == 1
    assert state["post"][0][2].rynki == ("allegro-cz", "allegro-hu")
    restarted = NoweSzkiceAllegro(api, repo, api)
    restarted.dokoncz_przelicznik(s, p, lambda: False)
    restarted.utworz(s, p, lambda: False)
    assert len(state["post"]) == api.calls.count("POST") == 1


@pytest.mark.parametrize("tryb", ["timeout", "odrzucenie"])
def test_nieznany_lub_odrzucony_przelicznik_nie_powtarza_post_po_restarcie(kurs, tryb):
    service, api, repo, s, o, u, state = kurs
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    state["timeout"] = tryb == "timeout"
    state["blad"] = "Próba modyfikacji jest przestarzała."
    result = service.dokoncz_przelicznik(s, p, lambda: False)
    assert result.ident and result.stan == USTAWIENIA_DO_SPRAWDZENIA
    restarted = NoweSzkiceAllegro(api, repo, api)
    result = restarted.dokoncz_przelicznik(s, p, lambda: False)
    assert "przestarzała" in result.komunikat
    assert len(state["post"]) == api.calls.count("POST") == 1
    state["przypiete"] = True
    assert restarted.sprawdz(s, p).stan == "Utworzono szkic"
    assert len(state["post"]) == 1


@pytest.mark.parametrize("tryb", ["anuluj", "baza", "uprawnienia", "regula", "cena"])
def test_brak_zapisu_reguly_gdy_anulowano_lub_brak_potwierdzenia(kurs, tryb):
    service, api, repo, s, o, u, state = kurs
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    if tryb == "baza":
        api.wyniki[o.sku]["publication"]["marketplaces"]["base"]["id"] = "allegro-hu"
    elif tryb == "cena":
        api.wyniki[o.sku]["sellingMode"]["price"]["amount"] = "9999"
    elif tryb == "uprawnienia":
        s = replace(s, aplikacja=replace(s.aplikacja, zapis_szkicow=False))
    elif tryb == "regula":
        api.reguly_kursowe = lambda *a: ()
    try:
        service.dokoncz_przelicznik(s, p, lambda: tryb == "anuluj")
    except BladAllegro:
        assert tryb == "cena"
    assert state["post"] == [] and api.calls.count("POST") == 1


@pytest.mark.parametrize("zmiana", ["waluta", "rynek", "konto", "regula"])
def test_niepoprawny_przelicznik_blokuje_plan(kurs, zmiana):
    service, api, repo, s, o, u, state = kurs
    if zmiana == "waluta":
        u = replace(u, waluta="EUR")
    else:
        fields = {
            "rynek": {"rynki": ("allegro-pl",)},
            "konto": {"konto": "inne"},
            "regula": {"regula": "brak"},
        }
        u = replace(u, przelicznik=replace(u.przelicznik, **fields[zmiana]))
    assert service.przygotuj(s, o, u).bledy
    assert not state["post"] and "POST" not in api.calls


def test_nieprzetworzone_202_nie_przypina_reguly(kurs):
    service, api, repo, s, o, u, state = kurs
    api.async_mode = True
    api.zakonczona = False
    p = service.przygotuj(s, o, u)
    assert service.utworz(s, p, lambda: False).stan == "Przetwarzanie"
    assert service.dokoncz_przelicznik(s, p, lambda: False).stan == "Przetwarzanie"
    assert not state["post"]
    api.zakonczona = True
    assert service.dokoncz_przelicznik(s, p, lambda: False).stan == "Utworzono szkic"
    assert len(state["post"]) == api.calls.count("POST") == 1


def test_mapper_tylko_domyslny_kurs_nie_najnizsza_cena():
    d = {
        "rules": [
            {"id": "course", "name": "Kurs", "type": "EXCHANGE_RATE", "default": True},
            {
                "id": "low",
                "name": "Najniższa",
                "type": "FOLLOW_BY_ALLEGRO_MIN_PRICE",
                "default": True,
            },
            {"id": "custom", "name": "Modyfikowana", "type": "EXCHANGE_RATE", "default": False},
        ]
    }
    assert reguly_kursowe(d) == (RegulaKursowa("course", "Kurs"),)
    with pytest.raises(BladAllegro):
        reguly_kursowe({"rules": [d["rules"][0], d["rules"][0]]})


def test_mapper_potwierdza_kazdy_wybrany_rynek(kurs):
    u = kurs[5].przelicznik
    rows = [{"marketplace": {"id": r}, "rule": {"id": u.regula}} for r in u.rynki]
    assert potwierdz_przelicznik({"rules": rows}, u)
    assert not potwierdz_przelicznik({"rules": rows[:1]}, u)
    with pytest.raises(BladAllegro):
        potwierdz_przelicznik({"rules": rows + rows}, u)


def test_transport_komenda_bez_kursu_ceny_lub_publikacji(kurs):
    s, u = kurs[3], kurs[5].przelicznik
    calls = []
    command = "312b11b0-691c-41d4-8d00-545c4f95b395"

    class Transport:
        def wyslij(self, metoda, url, naglowki, dane):
            calls.append((metoda, url, json.loads(dane)))
            return OdpowiedzAllegro(201, json.dumps({"id": command}).encode())

    api = NoweSzkiceAPI(Transport())
    api.przypnij_przelicznik(s, "12345678", u, command)
    method, url, data = calls[0]
    assert method == "POST" and url.endswith("/sale/offer-price-automation-commands")
    assert set(data) == {"id", "modification", "offerCriteria"}
    assert data["modification"] == {
        "set": [{"marketplace": {"id": r}, "rule": {"id": u.regula}} for r in u.rynki]
    }
    assert data["offerCriteria"][0]["offers"] == [{"id": "12345678"}]


def test_blad_reguly_zachowuje_bledy_walidacji_szkicu(kurs):
    service, api, repo, s, o, u, state = kurs
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    api.wyniki[o.sku]["validation"] = {"errors": [{"message": "Uzupełnij dostawę"}]}
    state["blad"] = "Nie przypięto reguły."
    result = service.dokoncz_przelicznik(s, p, lambda: False)
    assert result.stan == "Szkic do poprawy"
    assert "Uzupełnij dostawę" in result.komunikat and "Nie przypięto reguły" in result.komunikat


def test_transport_odczyt_regul_cache_i_zmiana_konta(kurs):
    s = kurs[3]
    calls = []

    class Transport:
        def wyslij(self, metoda, url, naglowki, dane):
            calls.append((metoda, url, naglowki["Authorization"]))
            return OdpowiedzAllegro(
                200,
                json.dumps(
                    {
                        "rules": [
                            {
                                "id": "exchange",
                                "name": "Kurs",
                                "type": "EXCHANGE_RATE",
                                "default": True,
                            },
                        ]
                    }
                ).encode(),
            )

    api = NoweSzkiceAPI(Transport())
    assert api.reguly_kursowe(s)[0].id == "exchange"
    api.reguly_kursowe(s)
    assert len(calls) == 1
    api.reguly_kursowe(replace(s, konto=replace(s.konto, id="inne-konto")))
    api.reguly_kursowe(replace(s, token="inny-token"))
    api.reguly_kursowe(s, True)
    assert len(calls) == 4
    assert all(c[0] == "GET" and c[1].endswith("/sale/price-automation/rules") for c in calls)


def test_transport_pelny_blad_przetwarzania_zamiast_sukcesu(kurs):
    s = kurs[3]

    class Transport:
        def wyslij(self, metoda, url, naglowki, dane):
            assert metoda == "GET" and "/tasks?limit=1000" in url
            return OdpowiedzAllegro(
                200,
                json.dumps(
                    {
                        "tasks": [
                            {
                                "offer": {"id": "12345678"},
                                "status": "FAIL",
                                "message": "Próba modyfikacji jest przestarzała.",
                                "errors": [{"code": "STALE", "userMessage": "Odśwież ofertę."}],
                            },
                        ]
                    }
                ).encode(),
            )

    api = NoweSzkiceAPI(Transport())
    result = api.wynik_przelicznika(s, "12345678", "312b11b0-691c-41d4-8d00-545c4f95b395")
    assert "przestarzała" in result and "Odśwież ofertę" in result
