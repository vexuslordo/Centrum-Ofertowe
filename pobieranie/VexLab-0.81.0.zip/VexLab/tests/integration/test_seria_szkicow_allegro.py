"""Seria z prawdziwą bazą i dekoderem zdjęć, zainicjalizowanym po QApplication."""

from dataclasses import replace

from vexlab.przypadki_uzycia.seria_szkicow_allegro import WyslijSerieSzkicow


def test_uszkodzone_zdjecie_lokalne_pomijamy_a_poprawne_oferty_sa_zapisywane(
    seria_szkicow_fixture, tmp_path, monkeypatch, qapp
):
    from tests.integration.test_katalog_uzytkownika import serwis as lokalny_serwis
    from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
    from vexlab.przypadki_uzycia.katalog import KatalogProduktow

    service, api, _, request, observer = seria_szkicow_fixture
    local, repo = lokalny_serwis(tmp_path)
    original = local.zdjecia.pobierz

    def photo(url):
        if url.endswith("bad.jpg"):
            raise BladScenariuszaKatalogu("ZDJECIE", "Uszkodzone zdjęcie jednej oferty")
        return original(url)

    monkeypatch.setattr(local.zdjecia, "pobierz", photo)
    first = replace(
        request.plany[0],
        oferta=replace(
            request.plany[0].oferta, zdjecia=("https://images.example.org/bad.jpg",), sekcje=()
        ),
    )
    request = replace(request, plany=(first, *request.plany[1:]))
    copies = []
    backup = repo._kopia_spojna

    def kopia(*a):
        copies.append(a)
        return backup(*a)

    monkeypatch.setattr(repo, "_kopia_spojna", kopia)
    results = WyslijSerieSzkicow(service, local, None).wykonaj(request, observer)
    assert [w.stan for w in results] == ["Do poprawy", "Utworzono szkic", "Utworzono szkic"]
    assert {p.sku for p in KatalogProduktow(repo, repo).wyszukaj()} == {"DRUGI", "TRZECI"}
    assert api.calls.count("POST") == 2 and len(copies) == 1


def test_awaria_bazy_lokalnej_wstrzymuje_post(seria_szkicow_fixture, tmp_path, monkeypatch, qapp):
    import sqlite3

    from tests.integration.test_katalog_uzytkownika import serwis as lokalny_serwis
    from vexlab.przypadki_uzycia.katalog import KatalogProduktow

    service, api, _, request, observer = seria_szkicow_fixture
    local, repo = lokalny_serwis(tmp_path)

    def fail(*a):
        raise sqlite3.OperationalError("Testowa awaria dysku")

    monkeypatch.setattr(repo, "_zapisz_produkt_uzytkownika", fail)
    results = WyslijSerieSzkicow(service, local, None).wykonaj(request, observer)
    assert all(w.stan == "Wstrzymano" for w in results)
    assert not KatalogProduktow(repo, repo).wyszukaj() and "POST" not in api.calls
