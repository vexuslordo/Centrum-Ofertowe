import pytest

from vexlab.adaptery.szablony_ofert_json import SzablonyOfertJSON
from vexlab.rdzen.kontrakty import BladTechniczny


def test_puste_potem_trwale_oddzielne_zbiory_i_polskie_znaki(tmp_path):
    repo = SzablonyOfertJSON(tmp_path / "dane")
    assert repo.lista("bezpieczenstwo") == () and not repo.katalog.exists()
    text = "Crash pady — ostrzeżenia\n" + "Ł" * 4900
    repo.zapisz("bezpieczenstwo", "Crash pady", text)
    repo.zapisz("taryfa", "Crash pady", "87141090")
    repo = SzablonyOfertJSON(tmp_path / "dane")
    assert repo.lista("bezpieczenstwo") == (("Crash pady", text),)
    assert repo.lista("taryfa") == (("Crash pady", "87141090"),)
    repo.zapisz("taryfa", "CRASH PADY", "12345678")
    assert repo.lista("taryfa") == (("CRASH PADY", "12345678"),)
    repo.usun("taryfa", "Crash pady")
    assert repo.lista("taryfa") == () and repo.lista("bezpieczenstwo")


def test_nieudana_podmiana_zachowuje_poprzedni_zapis(tmp_path, monkeypatch):
    repo = SzablonyOfertJSON(tmp_path)
    repo.zapisz("taryfa", "Test", "123")

    def fail(*args):
        raise OSError("Brak dostępu")

    monkeypatch.setattr("vexlab.adaptery.szablony_ofert_json.os.replace", fail)
    with pytest.raises(BladTechniczny):
        repo.zapisz("taryfa", "Test", "456")
    assert repo.lista("taryfa") == (("Test", "123"),)
    assert len(list((tmp_path / "taryfa").iterdir())) == 1


@pytest.mark.parametrize("nazwa,wartosc", [("", "123"), ("x", ""), ("x", "z" * 5001)])
def test_niepoprawny_wpis_nie_zapisuje(tmp_path, nazwa, wartosc):
    repo = SzablonyOfertJSON(tmp_path)
    with pytest.raises(ValueError):
        repo.zapisz("bezpieczenstwo", nazwa, wartosc)
    assert repo.lista("bezpieczenstwo") == ()


def test_uszkodzony_plik_zachowany_i_nie_nadpisany(tmp_path):
    repo = SzablonyOfertJSON(tmp_path)
    repo.zapisz("taryfa", "x", "123")
    plik = next((tmp_path / "taryfa").glob("*.json"))
    plik.write_text("uszkodzone")
    with pytest.raises(BladTechniczny):
        repo.zapisz("taryfa", "y", "456")
    assert plik.read_text() == "uszkodzone"
