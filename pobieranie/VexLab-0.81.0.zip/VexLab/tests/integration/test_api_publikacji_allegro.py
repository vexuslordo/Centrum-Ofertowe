import json
from uuid import uuid4

import pytest

from tests.integration.test_nowe_szkice_allegro import Transport, odpowiedz
from vexlab.adaptery import allegro_http as http
from vexlab.kanaly.publikacja_allegro import PublikacjaAllegroAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro


def test_put_tylko_activate_wskazanej_oferty_i_201_nie_oznacza_active(nowe_szkice_fixture):
    t = Transport(odpowiedz(201, {}))
    api = PublikacjaAllegroAPI(t)
    command = str(uuid4())
    api.zlec_publikacje(nowe_szkice_fixture[3], "123", command)
    method, url, headers, body = t.calls[0]
    assert method == "PUT" and url.endswith("/sale/offer-publication-commands/" + command)
    assert json.loads(body) == {
        "publication": {"action": "ACTIVATE"},
        "offerCriteria": [{"type": "CONTAINS_OFFERS", "offers": [{"id": "123"}]}],
    }


def test_raport_fail_oddaje_konkretny_powod_i_weryfikuje_id(nowe_szkice_fixture):
    command = str(uuid4())
    report = {
        "id": command,
        "completedAt": "2026-11-15T10:00:00Z",
        "taskCount": {"total": 1, "success": 0, "failed": 1},
    }
    tasks = {
        "tasks": [
            {
                "offer": {"id": "123"},
                "status": "FAIL",
                "errors": [{"userMessage": "Uzupełnij GPSR"}],
            }
        ]
    }
    api = PublikacjaAllegroAPI(Transport(odpowiedz(200, report), odpowiedz(200, tasks)))
    assert api.raport_publikacji(nowe_szkice_fixture[3], "123", command) == "Uzupełnij GPSR"
    tasks["tasks"][0]["offer"]["id"] = "inne"
    api = PublikacjaAllegroAPI(Transport(odpowiedz(200, report), odpowiedz(200, tasks)))
    with pytest.raises(BladAllegro, match="Niepełny"):
        api.raport_publikacji(nowe_szkice_fixture[3], "123", command)


def test_429_odczekuje_a_409_pozostaje_nieznany(nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]
    t = Transport(odpowiedz(429, {}, retry=120))
    api = PublikacjaAllegroAPI(t)
    for _ in range(2):
        with pytest.raises(BladAllegro) as err:
            api.zlec_publikacje(s, "123", str(uuid4()))
        assert err.value.kod == "ODRZUCONO"
    assert len(t.calls) == 1
    api = PublikacjaAllegroAPI(Transport(odpowiedz(409, {})))
    with pytest.raises(BladAllegro) as err:
        api.zlec_publikacje(s, "123", str(uuid4()))
    assert err.value.kod == "NIEZNANY"


def test_odcisk_obejmuje_cene_i_tresc_ale_nie_czas_walidacji(nowe_szkice_fixture, monkeypatch):
    d = {
        "id": "123",
        "name": "Oferta testowa motocykla",
        "publication": {"status": "INACTIVE"},
        "sellingMode": {"price": {"amount": "100.00", "currency": "PLN"}},
        "stock": {"available": 1},
        "validation": {"validatedAt": "x"},
    }
    api = PublikacjaAllegroAPI(None)
    monkeypatch.setattr(api, "_get", lambda *a: d)
    first = api.odczytaj_publikacje(nowe_szkice_fixture[3], "123")
    d["validation"]["validatedAt"] = "y"
    assert api.odczytaj_publikacje(nowe_szkice_fixture[3], "123").odcisk == first.odcisk
    d["sellingMode"]["price"]["amount"] = "200.00"
    assert api.odczytaj_publikacje(nowe_szkice_fixture[3], "123").odcisk != first.odcisk


def test_guard_put_odrzuca_obce_pola_i_kryteria(monkeypatch):
    monkeypatch.setattr(http, "build_opener", lambda *a: pytest.fail("Nie wolno wykonać sieci"))
    command = str(uuid4())
    url = "https://api.allegro.pl/sale/offer-publication-commands/" + command
    good = {
        "publication": {"action": "ACTIVATE"},
        "offerCriteria": [{"type": "CONTAINS_OFFERS", "offers": [{"id": "123"}]}],
    }
    for bad in (
        good | {"name": "zmiana"},
        good | {"publication": {"action": "END"}},
        good | {"publication": {"action": "ACTIVATE", "scheduledFor": "jutro"}},
        good | {"offerCriteria": []},
    ):
        with pytest.raises(BladAllegro):
            http.HTTPSAllegro().wyslij("PUT", url, {}, json.dumps(bad).encode())


def test_guard_dopuszcza_dokladna_komende_na_wlasciwym_hoscie(monkeypatch):
    calls = []

    class Response:
        code = 201
        headers = {}

        def __enter__(self):
            return self

        def __exit__(self, *a):
            pass

        def read(self, n):
            return b"{}"

    class Opener:
        def open(self, req, timeout):
            calls.append(req)
            return Response()

    monkeypatch.setattr(http, "build_opener", lambda *a: Opener())
    command = str(uuid4())
    body = {
        "publication": {"action": "ACTIVATE"},
        "offerCriteria": [{"type": "CONTAINS_OFFERS", "offers": [{"id": "123"}]}],
    }
    r = http.HTTPSAllegro().wyslij(
        "PUT",
        "https://api.allegro.pl/sale/offer-publication-commands/" + command,
        {},
        json.dumps(body).encode(),
    )
    assert r.status == 201 and calls[0].method == "PUT"


def test_odmowa_odczytu_komendy_wskazuje_wlasciwy_zakres_write(nowe_szkice_fixture):
    api = PublikacjaAllegroAPI(Transport(odpowiedz(403, {})))
    with pytest.raises(BladAllegro, match="allegro:api:sale:offers:write"):
        api.raport_publikacji(nowe_szkice_fixture[3], "123", str(uuid4()))
