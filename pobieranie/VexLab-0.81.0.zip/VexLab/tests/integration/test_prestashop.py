from dataclasses import replace

import pytest

from vexlab.adaptery.sekrety_prestashop import SekretyPresta
from vexlab.kanaly.prestashop import PrestaAPI
from vexlab.przypadki_uzycia.prestashop import (
    BladPresta,
    KonfiguracjaPresta,
    OdpowiedzPresta,
    PolaczPresta,
)

KLUCZ = "K" * 32  # Wyłącznie syntetyczny klucz fixture.


def config():
    return KonfiguracjaPresta("https://sklep.example/katalog/", KLUCZ, "1", "2")


def xml(zasob, rows):
    singular = {"shops": "shop", "languages": "language", "categories": "category"}[zasob]
    values = "".join(f"<{singular}>{r}</{singular}>" for r in rows)
    return f'<prestashop xmlns:xlink="http://www.w3.org/1999/xlink"><{zasob}>{values}</{zasob}></prestashop>'.encode()


def row(i, nazwa="Przykład", *, category=False):
    name = f'<language id="2"><![CDATA[{nazwa}]]></language>' if category else nazwa
    return f"<id>{i}</id><name>{name}</name><active>1</active>" + (
        "<id_parent>0</id_parent>" if category else ""
    )


class Transport:
    def __init__(self):
        self.calls = []
        self.status = 200
        self.page = None

    def pobierz(self, k, zasob, params):
        self.calls.append((k, zasob, params))
        data = (
            self.page
            if self.page is not None
            else xml(zasob, [row(1, category=zasob == "categories")])
        )
        return OdpowiedzPresta(self.status, data)


@pytest.mark.parametrize(
    "adres",
    [
        "http://sklep.example/",
        "https://sklep.example/admin123/index.php?token=fixture",
        "https://user:haslo@sklep.example/",
        "https://sklep.example/?key=fixture",
        "https://sklep.example/../",
        "https://sklep.example/%2e%2e/",
        "https://sklep.example/#token",
    ],
)
def test_adres_panelu_token_lub_niebezpieczny_adres_odrzucony(adres):
    with pytest.raises(BladPresta, match="adres HTTPS"):
        KonfiguracjaPresta(adres, KLUCZ).sprawdz()


def test_konfiguracja_normalizacja_podkatalog_i_repr_bez_klucza():
    k = KonfiguracjaPresta(" https://SKLEP.example/sklep/api/ ", KLUCZ).sprawdz()
    assert k.adres == "https://sklep.example/sklep/" and KLUCZ not in repr(k)
    with pytest.raises(BladPresta):
        replace(k, klucz="zly").sprawdz()


def test_api_xml16_i_kontekst_sklepu_jezyka():
    t = Transport()
    s = PolaczPresta(PrestaAPI(t))
    meta = s.sprawdz(config())
    assert meta.sklepy[0].id == "1" and meta.jezyki[0].nazwa == "Przykład"
    cats = s.kategorie(config())
    assert cats[0].nazwa == "Przykład" and cats[0].rodzic == "0"
    assert t.calls[-1][2]["id_shop"] == "1" and t.calls[-1][2]["language"] == "2"
    assert t.calls[-1][2]["display"] == "[id,id_parent,name,active]"
    with pytest.raises(BladPresta, match="wybierz sklep"):
        s.kategorie(replace(config(), sklep=""))


@pytest.mark.parametrize(
    "status,kod",
    [(401, "UPRAWNIENIA"), (403, "UPRAWNIENIA"), (429, "LIMIT"), (302, "HTTP"), (500, "HTTP")],
)
def test_odmowa_i_przekierowania_nie_sa_sukcesem(status, kod):
    t = Transport()
    t.status = status
    with pytest.raises(BladPresta) as exc:
        PrestaAPI(t).slowniki(config())
    assert exc.value.kod == kod and KLUCZ not in str(exc.value)


@pytest.mark.parametrize(
    "data",
    [
        b"<html>blad</html>",
        b"<prestashop><shops>",
        b'<!DOCTYPE p [<!ENTITY e SYSTEM "file:///etc/passwd">]><prestashop><shops>&e;</shops></prestashop>',
    ],
)
def test_html_uszkodzony_xml_i_encje_odrzucone(data):
    t = Transport()
    t.page = data
    with pytest.raises(BladPresta):
        PrestaAPI(t).slowniki(config())


def test_pelne_strony_oraz_duplikaty_nie_sa_ucinane():
    class Pages(Transport):
        def pobierz(self, k, zasob, params):
            start = int(params["limit"].split(",")[0])
            rows = [row(i, category=True) for i in range(start + 1, min(start + 201, 352))]
            return OdpowiedzPresta(200, xml(zasob, rows))

    assert len(PrestaAPI(Pages()).kategorie(config())) == 351
    t = Transport()
    t.page = xml("categories", [row(i, category=True) for i in range(1, 201)])
    with pytest.raises(BladPresta, match="powtórzone ID"):
        PrestaAPI(t).kategorie(config())


def test_brak_jezyka_nie_bierze_pierwszego_innego():
    t = Transport()
    t.page = xml("categories", [row(1, category=True).replace('id="2"', 'id="3"')])
    with pytest.raises(BladPresta, match="wybranym języku"):
        PrestaAPI(t).kategorie(config())


class SzyfratorTestowy:
    def zaszyfruj(self, data):
        return bytes(x ^ 0xAA for x in data)

    def odszyfruj(self, data):
        return bytes(x ^ 0xAA for x in data)


def test_zapamietanie_tylko_szyfr_restart_i_usuniecie(tmp_path):
    p = tmp_path / "prestashop.dpapi"
    m = SekretyPresta(p, SzyfratorTestowy())
    assert m.odczytaj() is None
    k = replace(config(), kategoria="12")
    m.zapisz(k)
    assert KLUCZ.encode() not in p.read_bytes() and b"sklep.example" not in p.read_bytes()
    assert SekretyPresta(p, SzyfratorTestowy()).odczytaj() == k
    allegro = tmp_path / "allegro.dpapi"
    allegro.write_bytes(b"fixture")
    m.usun()
    assert not p.exists() and allegro.read_bytes() == b"fixture"


def test_awaria_zapisu_nie_niszczy_poprzedniego(tmp_path, monkeypatch):
    import vexlab.adaptery.sekrety_prestashop as module

    m = SekretyPresta(tmp_path / "prestashop.dpapi", SzyfratorTestowy())
    m.zapisz(config())
    przed = m.plik.read_bytes()

    def odmowa(*args):
        raise PermissionError("prywatna tresc")

    monkeypatch.setattr(module.os, "replace", odmowa)
    with pytest.raises(BladPresta) as exc:
        m.zapisz(replace(config(), kategoria="2"))
    assert m.plik.read_bytes() == przed
    assert "prywatna" not in str(exc.value)
    assert list(tmp_path.iterdir()) == [m.plik]


def test_http_tylko_get_basic_bez_klucza_w_url_i_ograniczony_odczyt(monkeypatch):
    import vexlab.adaptery.prestashop_http as module

    class Response:
        status = 200

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def read(self, limit):
            assert limit == 4 * 1024 * 1024 + 1
            return b"<prestashop/>"

    class Opener:
        def open(self, request, timeout):
            assert request.get_method() == "GET" and timeout == 20
            assert KLUCZ not in request.full_url
            assert request.get_header("Authorization").startswith("Basic ")
            assert request.full_url.startswith("https://sklep.example/katalog/api/categories?")
            return Response()

    handlers = []

    def build(*args):
        handlers.extend(args)
        return Opener()

    monkeypatch.setattr(module, "build_opener", build)
    assert module.HTTPSPresta().pobierz(config(), "categories", {"language": "2"}).status == 200
    redirect = next(h for h in handlers if isinstance(h, module.BezPrzekierowan))
    assert redirect.redirect_request(None, None, 302, "", {}, "https://inne.example") is None
    assert any(isinstance(h, module.ProxyHandler) and not h.proxies for h in handlers)
    with pytest.raises(BladPresta):
        module.HTTPSPresta().pobierz(config(), "products", {})
