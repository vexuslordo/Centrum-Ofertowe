import json
from dataclasses import asdict, replace

import pytest

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.format_cennika import _pozycja
from vexlab.adaptery.profile_cennikow_json import ProfileCennikowJSON
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.importowanie import (
    Arkusz,
    ImportujProdukty,
    Komorka,
    Mapowanie,
    MapowaniePolaCennika,
    PlikImportu,
)
from vexlab.przypadki_uzycia.profile_cennikow import ProfileCennikow


def dane():
    return PlikImportu(
        "uzytkownika.csv",
        (
            Arkusz(
                "A",
                (
                    (1, tuple(Komorka(x) for x in ("Nazwa", "SKU", "Seria", "Pojazd"))),
                    (
                        2,
                        tuple(
                            Komorka(x) for x in ("Osobna nazwa", "00123", "Model X", "Motocykl Y")
                        ),
                    ),
                ),
            ),
        ),
    )


def mapa():
    return Mapowanie(
        1,
        0,
        1,
        pola_cennika=(
            MapowaniePolaCennika("Model wydechu", 2),
            MapowaniePolaCennika("Motocykl", 3),
        ),
    )


def test_wlasny_profil_i_pola_cennika_przetrwaja_restart(tmp_path):
    repo = CennikiSQLite(tmp_path / "db.sqlite3")
    importer = ImportujProdukty(CzytnikTabel(), repo, repo)
    profile = ProfileCennikow(ProfileCennikowJSON(tmp_path / "profile"))
    assert profile.magazyn.lista() == ()
    profile.zapisz(dane(), 0, mapa(), None, "Wydechy")
    profil = ProfileCennikow(ProfileCennikowJSON(tmp_path / "profile")).rozpoznaj(dane()).zgodne[0]
    assert profil.mapa.pola_cennika == mapa().pola_cennika
    rows = importer.zaplanuj(dane(), 0, profil.mapa, None)
    assert rows[0].pozycja.dane.nazwa == "Osobna nazwa"
    assert [(p.nazwa, p.wartosc) for p in rows[0].pozycja.pola_cennika] == [
        ("Model wydechu", "Model X"),
        ("Motocykl", "Motocykl Y"),
    ]
    b = BibliotekaCennikow(repo, importer)
    b.zapisz("Mój cennik", 2026, "", rows)
    c = b.lista()[0]
    restart = CennikiSQLite(repo.plik)
    assert restart.pozycje(c.id, c.wersja)[0].pola_cennika == rows[0].pozycja.pola_cennika
    assert (
        tuple(restart.iteruj_pozycje(c.id, c.wersja))[0].pola_cennika
        == rows[0].pozycja.pola_cennika
    )
    old = json.loads(json.dumps(asdict(rows[0].pozycja), default=str))
    del old["pola_cennika"]
    assert _pozycja(old).pola_cennika == ()


@pytest.mark.parametrize(
    "pola",
    [
        (MapowaniePolaCennika("", 2),),
        (MapowaniePolaCennika("A", -1),),
        (MapowaniePolaCennika("Model", 2), MapowaniePolaCennika("model", 3)),
    ],
)
def test_niepoprawne_wlasne_pola_blokuja_profil(tmp_path, pola):
    repo = ProfileCennikow(ProfileCennikowJSON(tmp_path / "profile"))
    with pytest.raises(BladScenariuszaKatalogu):
        repo.zapisz(dane(), 0, replace(mapa(), pola_cennika=pola), None, "Użytkownika")
    assert repo.magazyn.lista() == ()
