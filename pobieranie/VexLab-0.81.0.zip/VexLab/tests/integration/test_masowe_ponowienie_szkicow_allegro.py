from dataclasses import replace

import pytest

from tests.integration import test_ponowienie_szkicu_allegro as pojedyncze
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.ponowienie_szkicu_allegro import PrzygotujNoweProby

blokada = pojedyncze.blokada


@pytest.fixture
def partia(blokada):
    service, api, repo, s, p, old = blokada
    plany = []
    for i in range(3):
        nowy = service.przygotuj(s, replace(p.oferta, sku=f"MASOWO-{i}"), p.ustawienia)
        repo.rozpocznij(
            service.klucz(s, nowy.oferta.sku),
            replace(old, zrodlo=service._zrodlo(nowy), ident=str(1000 + i)),
        )
        plany.append(nowy)
    return service, api, repo, s, tuple(plany)


def test_podglad_mieszany_potwierdza_tylko_uprawnione_i_czyta_ponownie(partia):
    service, api, repo, s, plany = partia
    uc = PrzygotujNoweProby(service)
    api.czy_istnieje_oferta = lambda s, ident: ident == "1001"
    preview = uc.sprawdz(s, plany, lambda: False, lambda *a: None)
    assert [p.kontrola is not None for p in preview.pozycje] == [True, False, True]
    assert all(repo.odczytaj(service.klucz(s, p.oferta.sku)) for p in plany)
    with pytest.raises(BladAllegro):
        uc.potwierdz(s, preview, False, lambda: False, lambda *a: None)
    api.czy_istnieje_oferta = lambda s, ident: ident in {"1001", "1002"}
    wynik = uc.potwierdz(s, preview, True, lambda: False, lambda *a: None)
    assert [w.odblokowano for w in wynik] == [True, False, False]
    assert repo.odczytaj(service.klucz(s, plany[0].oferta.sku)) is None
    assert all(repo.odczytaj(service.klucz(s, p.oferta.sku)) for p in plany[1:])
    assert "istnieje" in wynik[1].komunikat and "istnieje" in wynik[2].komunikat
    assert api.calls.count("POST") == 1


def test_dluga_kontrola_nie_uniewaznia_pierwszych_wierszy(partia):
    service, api, repo, s, plany = partia
    uc = PrzygotujNoweProby(service)

    def odczyt(*a):
        api.czas += 65
        return False

    api.czy_istnieje_oferta = odczyt
    preview = uc.sprawdz(s, plany, lambda: False, lambda *a: None)
    assert preview.czas - preview.pozycje[0].kontrola.czas > 120
    wynik = uc.potwierdz(s, preview, True, lambda: False, lambda *a: None)
    assert all(w.odblokowano for w in wynik)
    assert api.calls.count("POST") == 1


def test_wygasla_zgoda_nie_odblokowuje_zadnego_wiersza(partia):
    service, api, repo, s, plany = partia
    uc = PrzygotujNoweProby(service)
    preview = uc.sprawdz(s, plany, lambda: False, lambda *a: None)
    api.czas += 121
    with pytest.raises(BladAllegro):
        uc.potwierdz(s, preview, True, lambda: False, lambda *a: None)
    assert all(repo.odczytaj(service.klucz(s, p.oferta.sku)) for p in plany)


def test_anulowanie_pozostawia_raport_dla_kazdego_wiersza(partia):
    service, api, repo, s, plany = partia
    uc = PrzygotujNoweProby(service)
    preview = uc.sprawdz(s, plany, lambda: False, lambda *a: None)
    stop = [False]

    def postep(n, total):
        stop[0] = n >= 2

    wynik = uc.potwierdz(s, preview, True, lambda: stop[0], postep)
    assert [w.odblokowano for w in wynik] == [True, False, False]
    assert "zatrzymano" in wynik[1].komunikat
    assert all(repo.odczytaj(service.klucz(s, p.oferta.sku)) for p in plany[1:])


def test_blad_odczytu_nie_daje_czesciowej_zgody_dla_pozostalych(partia):
    service, api, repo, s, plany = partia
    uc = PrzygotujNoweProby(service)
    api.czy_istnieje_oferta = lambda *a: (_ for _ in ()).throw(
        BladAllegro("SIEC", "Brak połączenia")
    )
    preview = uc.sprawdz(s, plany, lambda: False, lambda *a: None)
    assert all(p.kontrola is None for p in preview.pozycje)
    assert all("Brak połączenia" in p.komunikat for p in preview.pozycje)
    assert all(repo.odczytaj(service.klucz(s, p.oferta.sku)) for p in plany)
