from PySide6.QtWidgets import QMessageBox

from tests.gui.test_nowe_szkice_allegro import panel, wykonaj


def test_nowa_proba_ma_odmowe_domyslna_i_nie_wysyla_post(qtbot, nowe_szkice_fixture, monkeypatch):
    service, api, repo, s, o, u = nowe_szkice_fixture
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    w.wyslij(False)
    wykonaj(jobs)
    api.wyniki.clear()
    api.czy_istnieje_oferta = lambda *a: False
    api.kandydaci_duplikatow = lambda *a: ()
    api.ean_duplikatu = lambda *a: ()
    w.tabela.selectRow(0)
    pytania = []

    def nie(*a):
        pytania.append(a)
        return QMessageBox.StandardButton.No

    monkeypatch.setattr(QMessageBox, "question", nie)
    w.sprawdz_blokade()
    wykonaj(jobs)
    assert pytania[0][-1] == QMessageBox.StandardButton.No
    assert "duplikat" in pytania[0][2]
    assert repo.odczytaj(service.klucz(s, o.sku)) is not None
    assert api.calls.count("POST") == 1
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    w.sprawdz_blokade()
    wykonaj(jobs)
    qtbot.waitUntil(lambda: w.trwa)
    wykonaj(jobs)
    assert not w.trwa and not w.plany
    w.przygotuj()
    wykonaj(jobs)
    assert repo.odczytaj(service.klucz(s, o.sku)) is None
    assert w.wyniki[0].stan == "Gotowa do utworzenia" and w._mozna_wyslac(0)
    assert api.calls.count("POST") == 1
