from dataclasses import replace

from PySide6.QtCore import QItemSelectionModel
from PySide6.QtWidgets import QMessageBox, QWidget

from tests.gui.test_nowe_szkice_allegro import wykonaj
from tests.gui.test_podglad_oferty import png
from vexlab.adaptery.katalog_allegro_sqlite import KatalogAllegroSQLite
from vexlab.gui.import_katalogu_allegro import ImportKataloguAllegro, OfertyProduktowAllegro
from vexlab.przypadki_uzycia.katalog import KatalogProduktow, ZapytanieKatalogu
from vexlab.przypadki_uzycia.katalog_allegro import KatalogZAllegro, OfertaKatalogu
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec


def wybierz(tabela):
    tabela.selectionModel().select(
        tabela.model().index(0, 0),
        QItemSelectionModel.SelectionFlag.ClearAndSelect | QItemSelectionModel.SelectionFlag.Rows,
    )
    assert tabela.selectionModel().selectedRows()


def setup(qtbot, tmp_path, nowe_szkice_fixture):
    repo = KatalogAllegroSQLite(tmp_path / "k.sqlite3")
    s = nowe_szkice_fixture[3]
    o = OfertaKatalogu(
        "123",
        "Produkt testowy",
        "SKU-1",
        "ACTIVE",
        "5901234123457",
        "Producent testowy",
        "Opis",
        ("https://images.example.org/a.jpg",),
    )

    class API:
        patches = 0
        status = "ACTIVE"

        def lista_katalogu(self, s, stop, postep=None):
            return (replace(o, producent=""),)

        def szczegoly_katalogu(self, s, offer):
            return replace(o, sku=offer.sku)

        def status_katalogu(self, s, ident):
            return self.status

        def zakoncz_oferte(self, s, ident):
            self.status = "ENDED"
            self.patches += 1

    class Source:
        def pobierz_obraz(self, url):
            return ZdjecieDane(url, png(), png())

    api = API()
    service = KatalogZAllegro(api, repo, PodgladZdjec(Source()))
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = ImportKataloguAllegro(parent, service, s, lambda *a: jobs.append(a), lambda: True)
    d.show()
    return d, jobs, repo, s, api, service, parent


def test_podglad_producenta_przed_jawnym_zapisem(qtbot, tmp_path, nowe_szkice_fixture):
    d, jobs, repo, *_ = setup(qtbot, tmp_path, nowe_szkice_fixture)
    d.pobierz.click()
    wykonaj(jobs)
    assert not repo.wyszukaj("")
    wybierz(d.tabela)
    d.sprawdz.click()
    wykonaj(jobs)
    assert d.tabela.item(0, 4).text() == "Producent testowy"
    assert d.zapisz.isEnabled() and not repo.lista_producentow()
    d.zapisz.click()
    wykonaj(jobs)
    p = KatalogProduktow(repo, repo).strona(ZapytanieKatalogu()).produkty[0]
    assert p.producent_nazwa == "Producent testowy" and p.ma_zdjecia
    assert d.zapisano and not d.zapisz.isEnabled()
    d.zaznacz()
    assert not d.tabela.selectionModel().selectedRows()
    d.reject()


def test_zmiana_sku_uniewaznia_plan_i_anulowanie_nic_nie_zapisuje(
    qtbot, tmp_path, nowe_szkice_fixture
):
    d, jobs, repo, *_ = setup(qtbot, tmp_path, nowe_szkice_fixture)
    d.lista()
    wykonaj(jobs)
    wybierz(d.tabela)
    d.przygotuj()
    wykonaj(jobs)
    d.tabela.item(0, 2).setText("INNY-SKU")
    assert d.plan is None and not d.zapisz.isEnabled()
    d.reject()
    assert not repo.wyszukaj("")


def test_zakonczenie_ma_domyslna_odmowe_i_odrebne_potwierdzenie(
    qtbot, tmp_path, nowe_szkice_fixture, monkeypatch
):
    d, jobs, repo, s, api, service, parent = setup(qtbot, tmp_path, nowe_szkice_fixture)
    o = api.szczegoly_katalogu(s, api.lista_katalogu(s, lambda: False)[0])
    plan = repo.plan_katalogu_allegro(s, (o,))
    repo.zapisz_katalog_allegro(plan, {})
    d.reject()
    offers = service.powiazania(s, (plan.pozycje[0].produkt,))
    window = OfertyProduktowAllegro(
        parent, service, s, offers, lambda *a: jobs.append(a), lambda: True
    )
    window.show()
    wybierz(window.tabela)
    defaults = []

    def no(*args):
        defaults.append(args[-1])
        return QMessageBox.StandardButton.No

    monkeypatch.setattr(QMessageBox, "question", no)
    window.wyslij()
    assert api.patches == 0 and defaults == [QMessageBox.StandardButton.No]
    monkeypatch.setattr(QMessageBox, "question", lambda *args: QMessageBox.StandardButton.Yes)
    window.wyslij()
    wykonaj(jobs)
    assert api.patches == 1 and window.tabela.item(0, 3).text() == "Zakończona"
    window.reject()


def test_postep_listy_podgladu_i_zapisu(qtbot, tmp_path, nowe_szkice_fixture, monkeypatch):
    d, jobs, _, _, api, *_ = setup(qtbot, tmp_path, nowe_szkice_fixture)
    original = api.lista_katalogu

    def lista(s, stop, postep=None):
        postep(100, 250)
        assert d.pasek.maximum() == 250 and d.pasek.value() == 100
        assert "Pobrano ofert: 100 z 250" in d.info.text()
        return original(s, stop)

    monkeypatch.setattr(api, "lista_katalogu", lista)
    d.lista()
    assert d.pasek.isVisible() and d.pasek.maximum() == 0
    assert "Pobrano ofert" in d.info.text()
    wykonaj(jobs)
    assert d.pasek.value() == 100 and d.pasek.maximum() == 100
    assert "Pobrano 1 ofert" in d.info.text()
    wybierz(d.tabela)
    d.przygotuj()
    wykonaj(jobs)
    assert "Do zapisania: 1" in d.info.text()
    d.zapis()
    wykonaj(jobs)
    assert "Zapisano: 1 ofert" in d.info.text()
    assert "Łącznie z tej listy: 1" in d.info.text()
    assert d.pasek.value() == d.pasek.maximum() == 100
    d.postep.emit(1, 99)
    assert d.pasek.value() == 100
    d.reject()


def test_blad_pobierania_zachowuje_licznik_bez_udawania_zakonczenia(
    qtbot, tmp_path, nowe_szkice_fixture
):
    d, jobs, *_ = setup(qtbot, tmp_path, nowe_szkice_fixture)
    d.lista()
    d.postep.emit(100, 250)
    function, success, error = jobs.pop()
    error("HTTP", "Brak połączenia")
    assert d.pasek.value() == 100 and d.pasek.maximum() == 250
    assert d.pasek.format() == "Przerwano"
    assert "100 z 250" in d.info.text() and "Brak połączenia" in d.info.text()
    assert not d.trwa and d.tabela.rowCount() == 0
    d.reject()


def test_blad_sieci_pokazuje_wznowienie_i_nie_gubi_licznika(qtbot, tmp_path, nowe_szkice_fixture):
    d, jobs, *_ = setup(qtbot, tmp_path, nowe_szkice_fixture)
    d.lista()
    d.postep.emit(4300, 14292)
    function, success, error = jobs.pop()
    error("SIEC", "Brak odpowiedzi Allegro")
    assert d.pobierz.text() == "Wznów pobieranie"
    assert "4300 z 14292" in d.info.text()
    assert "zachowano odebrane strony" in d.info.text()
    assert d.pasek.value() == 4300 and d.pasek.maximum() == 14292
    d.lista()
    wykonaj(jobs)
    assert d.pobierz.text() == "Pobierz / odśwież listę konta"
    d.reject()
