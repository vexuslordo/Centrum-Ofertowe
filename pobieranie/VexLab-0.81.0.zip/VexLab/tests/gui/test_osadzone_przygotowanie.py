"""Jeden widok przygotowania: rzeczywiste widgety, zakres i cykl życia bez POST."""

from dataclasses import replace

import pytest
from PySide6.QtWidgets import QVBoxLayout, QWidget

from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.gui.paczki_ofert import StronaPaczek


@pytest.fixture
def osadzone(qtbot, nowe_szkice_fixture):
    service, api, _, session, offer, settings = nowe_szkice_fixture
    root = QWidget()
    qtbot.addWidget(root)
    box = QVBoxLayout(root)
    page = StronaPaczek(None, lambda *a: None, root, allegro_dostepne=True)
    box.addWidget(page)
    root.resize(1366, 768)
    root.show()
    offers = (offer, replace(offer, sku="DRUGI", ean="bad"))
    page._pokaz(offers)
    jobs = []
    dialog = DialogNowychSzkicow(root, service, session, offers, lambda *a: jobs.append(a))
    dialog.automatyczny_dobor.setChecked(False)
    dialog.kompletny.setChecked(False)
    dialog.waluta.setCurrentIndex(dialog.waluta.findData("PLN"))
    for i in range(2):
        dialog.ustawienia[i] = settings
    page.centrum.czytaj_kontekst = lambda: (dialog, session)
    page.centrum.osadzenie.osadz(dialog)

    def finish(_):
        page.centrum.czytaj_kontekst = lambda: (None, session)
        page.centrum.osadzenie.zakoncz(dialog)

    dialog.finished.connect(finish)
    yield page, dialog, api, jobs, offers
    dialog.reject()


def sprawdz(dialog, jobs):
    dialog.sprawdz_przycisk.click()
    function, success, _ = jobs[-1]
    success(function())


def test_jedna_tabela_i_te_same_ustawienia_bez_osobnego_okna(osadzone):
    page, dialog, api, jobs, _ = osadzone
    assert not dialog.isWindow() and dialog.parentWidget() is page.centrum.uklad.tresc
    assert page.centrum.uklad.tresc.currentWidget() is dialog
    assert dialog.tabela.isVisible() and not page.tabela.isVisible()
    assert page.centrum.tabela_widoku is dialog.tabela
    page.centrum.osadzenie.ustawienia.setChecked(True)
    assert dialog.waluta.isVisible() and not dialog.karty_ustawien.isVisible()
    sprawdz(dialog, jobs)
    page.centrum.odswiez(wymus=True)
    assert page.centrum.kpi["gotowe"].liczba.text() == "1"
    assert page.centrum.kpi["bledy"].liczba.text() == "1"
    assert "POST" not in api.calls


def test_filtr_nie_znika_po_aktualizacji_wynikow_i_ogranicza_zakres(osadzone):
    page, dialog, api, jobs, _ = osadzone
    sprawdz(dialog, jobs)
    page.centrum.odswiez(wymus=True)
    page.centrum._filtr("ean")
    assert dialog.tabela.isRowHidden(0) and not dialog.tabela.isRowHidden(1)
    dialog.wszystkie.click()
    assert dialog.zakres_wysylki() == (1,)
    # Bez timera KPI: każda przebudowa stosuje ten sam filtr synchronicznie.
    dialog._pokaz_wyniki()
    assert dialog.zakres_wysylki() == (1,) and dialog.tabela.isRowHidden(0)
    page.centrum._filtr("wszystkie")
    page.centrum.szukaj.setText("DRUGI")
    dialog._pokaz_plan()
    assert dialog.tabela.isRowHidden(0) and not dialog.tabela.isRowHidden(1)
    assert "POST" not in api.calls


def test_poprawione_dane_w_kpi_i_panelu_bez_nadpisania_zrodla_zip(osadzone):
    page, dialog, api, jobs, original = osadzone
    dialog.oferty = (
        replace(original[0], cena="999", tytul="Poprawiony tytuł produktu"),
        original[1],
    )
    sprawdz(dialog, jobs)
    page.centrum.odswiez(wymus=True)
    dialog.tabela.setCurrentCell(0, 1)
    assert page.centrum.stany[0].gotowa
    assert page.centrum.panel.nazwa.text() == "Poprawiony tytuł produktu"
    assert "999" in page.centrum.panel.pola["Cena"].text()
    assert page.oferty is original and page.oferty[0].cena != "999"
    assert "POST" not in api.calls


def test_zakonczenie_przywraca_podglad_i_zwalnia_polaczenie_filtra(osadzone):
    page, dialog, _, _, original = osadzone
    dialog.reject()
    assert page.centrum.osadzenie.dialog is None
    assert page.centrum.uklad.tresc.currentWidget() is page.tabela
    assert page.tabela.isVisible() and not dialog.isVisible()
    assert dialog.filtr_prezentacji is None
    assert page.wczytaj_paczke.isEnabled() and page.oferty is original


def test_checkboxy_i_klawiatura_korzystaja_z_oryginalnego_wyboru(osadzone, qtbot):
    from PySide6.QtCore import Qt

    page, dialog, api, jobs, _ = osadzone
    sprawdz(dialog, jobs)
    selection = page.centrum.osadzenie.wybor
    table = dialog.tabela
    rect = table.visualRect(table.model().index(0, selection.kolumna))
    qtbot.mouseClick(table.viewport(), Qt.MouseButton.LeftButton, pos=rect.center())
    assert dialog.wybrane() == (0,)
    table.setFocus()
    qtbot.keyClick(table, Qt.Key.Key_Space)
    assert not dialog.wybrane()
    selection._wszystkie(selection.kolumna)
    assert dialog.wybrane() == (0, 1)
    page.centrum._filtr("ean")
    assert dialog.wybrane() == (1,) and dialog.zakres_wysylki() == (1,)
    assert "POST" not in api.calls


def test_przeniesione_ustawienia_sa_blokowane_podczas_operacji(osadzone):
    page, dialog, api, jobs, _ = osadzone
    dialog.sprawdz_przycisk.click()
    assert dialog.trwa
    assert not dialog.waluta.isEnabled() and not dialog.ilosc.isEnabled()
    assert not page.wczytaj_paczke.isEnabled()
    function, success, _ = jobs[-1]
    success(function())
    assert dialog.waluta.isEnabled() and page.wczytaj_paczke.isEnabled()
    assert "POST" not in api.calls


def test_nowy_produkt_dostepny_bezposrednio_w_ustawieniach(osadzone, monkeypatch):
    from PySide6.QtWidgets import QDialog

    page, dialog, api, jobs, _ = osadzone
    button = dialog.nowy_przycisk
    assert button.isVisible() and button.isEnabled()
    assert "Nowy produkt w Allegro" in button.text()
    assert button in page.centrum.osadzenie.przeniesione
    opened = []
    monkeypatch.setattr(
        QDialog, "exec", lambda d: opened.append(d.windowTitle()) or QDialog.DialogCode.Rejected
    )
    dialog.tabela.selectRow(0)
    button.click()
    assert opened == ["Nowy produkt • wybierz kategorię Allegro"]
    assert not jobs and "POST" not in api.calls


def test_postep_operacji_jest_liczbowy_i_odrozniony_od_gotowosci(osadzone):
    from PySide6.QtWidgets import QProgressBar

    page, dialog, _, jobs, _ = osadzone
    dialog.przygotuj()
    assert dialog.pasek.maximum() > 0 and dialog.pasek.value() == 0
    assert not dialog.pasek.isVisible() and page.centrum.postep.isVisible()
    assert len(page.centrum.uklad.stopka.findChildren(QProgressBar)) == 1
    dialog.postep_etapu.emit("Katalog lokalny", 1, 2)
    assert dialog.pasek.maximum() == 2 and dialog.pasek.value() == 1
    assert page.centrum.uklad.procent.text() == "50%"
    assert page.centrum.uklad.licznik.text() == "1 / 2 przetworzonych"
    page.centrum.odswiez(wymus=True)
    assert page.centrum.uklad.procent.text() == "50%"
    assert page.centrum.postep.value() == 1 and page.centrum.postep.maximum() == 2
    assert not dialog.pasek.isVisible() and page.centrum.postep.isVisible()
    dialog.postep_etapu.emit("Wysyłka szkiców Allegro", 0, 2)
    assert page.centrum.uklad.postep_tytul.text() == "Wysyłka szkiców Allegro"
    assert dialog.pasek.value() == 0
    function, success, _ = jobs[-1]
    success(function())
    assert not dialog.trwa and dialog.pasek.value() == 2
    assert not dialog.pasek.isVisible() and page.centrum.postep.isVisible()
    assert len(page.centrum.uklad.stopka.findChildren(QProgressBar)) == 1
