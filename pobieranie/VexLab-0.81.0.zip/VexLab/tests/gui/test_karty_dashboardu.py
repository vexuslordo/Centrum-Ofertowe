from dataclasses import replace

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon

from tests.integration.test_dashboard_zamowienia import raport
from tests.integration.test_zamowienia_allegro import raw
from vexlab.gui.dashboard import DashboardView
from vexlab.kanaly.zamowienia_allegro import mapuj_zamowienie
from vexlab.przypadki_uzycia.powloka import PreferencjePowloki
from vexlab.przypadki_uzycia.zamowienia_allegro import RaportZamowien


def test_karta_zachowuje_pola_tozsamosc_kanalu_i_klawiature(qtbot):
    v = DashboardView(PreferencjePowloki())
    qtbot.addWidget(v)
    a, p = raport(), raport("PrestaShop")
    row = replace(mapuj_zamowienie(raw(1)), id="TEST-1", kraj="CZ")
    full = RaportZamowien("konto", "login", "test", a.od, a.do, a.odczytano, (row,))
    v.lista_zamowien.dane.kontekst(full, {row.pozycje[0].oferta_id: QIcon()})
    v.ustaw_zamowienia("Allegro", a)
    v.ustaw_zamowienia("PrestaShop", p)
    model = v.lista_zamowien.dane
    assert model.rowCount() == 2
    idx = next(model.index(i) for i, r in enumerate(model.rows) if r.zrodlo == "Allegro")
    assert row.pozycje[0].nazwa in idx.data()
    assert row.dostawa in idx.data()
    other = next(model.index(i) for i, r in enumerate(model.rows) if r.zrodlo == "PrestaShop")
    assert row.pozycje[0].nazwa not in other.data()
    v.resize(1400, 900)
    v.show()
    v.lista_zamowien.setCurrentIndex(idx)
    v.lista_zamowien.setFocus()
    with qtbot.waitSignal(v.otworz_zamowienie) as result:
        qtbot.keyClick(v.lista_zamowien, Qt.Key.Key_Return)
    assert result.args == ["Allegro", "TEST-1"]
    v.lista_zamowien.dane.kontekst(None, {})
    v.ustaw_zamowienia("Allegro", None)
    assert not model.szczegoly and not model.ikony
    assert model.rowCount() == 1 and model.rows[0].zrodlo == "PrestaShop"


def test_warianty_kart_i_skroty_podlegaja_anulowaniu(qtbot):
    v = DashboardView(PreferencjePowloki())
    qtbot.addWidget(v)
    board = v.tablica
    board.ustaw("zamowienia", widok="Karty")
    assert v.lista_zamowien.karta.karty
    board.ustaw("akcje", skroty=("Zamówienia", "Produkty"))
    assert sum(not b.isHidden() for b in v.przyciski_akcji) == 2
    board.anuluj()
    assert not v.lista_zamowien.karta.karty
    assert all(not b.isHidden() for b in v.przyciski_akcji)
    assert v.szybkie_kpi["koszyk"].text() == "—"


def test_przyciski_skrotow_nigdy_nie_sa_osobnymi_oknami(qtbot):
    v = DashboardView(PreferencjePowloki())
    qtbot.addWidget(v)
    v.show()
    qtbot.waitUntil(lambda: all(b.parentWidget() is not None for b in v.przyciski_akcji))
    assert all(not b.isWindow() for b in v.przyciski_akcji)
    v.tablica.ustaw("akcje", skroty=())
    v.tablica.anuluj()
    assert all(not b.isWindow() for b in v.przyciski_akcji)
