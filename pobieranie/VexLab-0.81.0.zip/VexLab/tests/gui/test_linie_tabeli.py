import pytest
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QAbstractItemView, QTableWidget, QTableWidgetItem

from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.linie_tabeli import LinieTabeli, kolor_separatora
from vexlab.przypadki_uzycia.powloka import Motyw


@pytest.mark.parametrize("theme", [Motyw.CIEMNY, Motyw.JASNY])
def test_linie_podazaja_za_kolumnami_i_nie_blokuja_wyboru(qtbot, qapp, theme):
    zastosuj_motyw(qapp, theme)
    table = QTableWidget(20, 3)
    qtbot.addWidget(table)
    table.setHorizontalHeaderLabels(["Produkt", "SKU", "Cena"])
    table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    for column in range(3):
        table.setColumnWidth(column, 100)
        table.setItem(0, column, QTableWidgetItem(str(column)))
    table.resize(230, 180)
    table.show()
    qtbot.waitExposed(table)
    overlay = table.findChild(LinieTabeli)
    assert overlay is not None and overlay.testAttribute(
        Qt.WidgetAttribute.WA_TransparentForMouseEvents
    )
    header = table.horizontalHeader()
    header.moveSection(0, 1)
    table.setColumnHidden(2, True)
    table.setColumnWidth(0, 150)
    table.horizontalScrollBar().setValue(20)
    table.verticalScrollBar().setValue(17)
    qapp.processEvents()
    visible = header.logicalIndex(0)
    x = header.sectionViewportPosition(visible) + header.sectionSize(visible) - 1
    image = table.viewport().grab().toImage()
    assert image.pixelColor(x, 50) == QColor(kolor_separatora(theme == Motyw.CIEMNY))
    rect = table.visualRect(table.model().index(table.rowAt(30), visible))
    qtbot.mouseClick(table.viewport(), Qt.MouseButton.LeftButton, pos=rect.center())
    assert table.currentColumn() == visible
    assert len(table.findChildren(LinieTabeli)) == 1
