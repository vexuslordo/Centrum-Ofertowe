from tests.gui.test_nowe_szkice_allegro import panel, wykonaj


def test_domyslny_automat_jest_dostepny_bez_odczytow_przy_zmianie_pola(
    qtbot, nowe_produkty_fixture
):
    w, jobs = panel(qtbot, nowe_produkty_fixture)
    w.automatyczny_dobor.setChecked(True)
    assert not jobs and not w.plany
    w.przygotuj()
    wykonaj(jobs)
    assert not w.plany[0].bledy and not w.plany[0].ustawienia.nowy
    assert w.plany[0].ustawienia.automatyczny
    assert w.ustawienia[0].produkt == nowe_produkty_fixture[1].produkt.id
    from vexlab.gui.walidacja_paczki_ui import oznacz_oferte

    state = oznacz_oferte(w.oferty[0], w.plany[0])
    assert ("EAN", "Sprawdzono przy dopasowaniu", "zielony") in state.kontrole
    assert "POST" not in nowe_produkty_fixture[1].calls


def test_reczna_kategoria_ma_pierwszenstwo_i_mozna_przywrocic_automat(qtbot, nowe_produkty_fixture):
    w, jobs = panel(qtbot, nowe_produkty_fixture)
    w.automatyczny_dobor.setChecked(True)
    w.tabela.selectRow(0)
    w._zastosuj_kategorie(0, "123", False)
    assert not w._ustawienia(0).automatyczny and not jobs
    w.przygotuj()
    wykonaj(jobs)
    assert w.plany[0].ustawienia.nowy
    before = len(jobs)
    w.tabela.selectRow(0)
    w._przywroc_dobor()
    assert w._ustawienia(0).automatyczny and len(jobs) == before and not w.plany
    w.przygotuj()
    wykonaj(jobs)
    assert not w.plany[0].ustawienia.nowy


def test_zmiana_planu_podczas_wysylki_zachowuje_sprawdzanie_wyniku(qtbot, nowe_produkty_fixture):
    w, jobs = panel(qtbot, nowe_produkty_fixture)
    w.automatyczny_dobor.setChecked(False)
    w.przygotuj()
    wykonaj(jobs)
    from dataclasses import replace

    w.plany = (replace(w.plany[0], ustawienia=replace(w.plany[0].ustawienia, automatyczny=True)),)
    w.wyslij(False)
    wykonaj(jobs)
    assert not w.plany[0].ustawienia.nowy and w.wyniki[0].stan == "Utworzono szkic"
    count = nowe_produkty_fixture[1].calls.count("POST")
    w.wyslij(True)
    wykonaj(jobs)
    assert (
        w.wyniki[0].stan == "Utworzono szkic"
        and nowe_produkty_fixture[1].calls.count("POST") == count
    )


def test_domyslny_tryb_nie_wykonuje_get_przy_otwarciu(qtbot, nowe_produkty_fixture):
    from PySide6.QtWidgets import QWidget

    from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow

    service, api, _, session, offer, _ = nowe_produkty_fixture
    root = QWidget()
    qtbot.addWidget(root)
    jobs = []
    dialog = DialogNowychSzkicow(root, service, session, (offer,), lambda *a: jobs.append(a))
    assert dialog.automatyczny_dobor.isChecked() and not jobs and "POST" not in api.calls


def test_mieszana_paczka_przygotowuje_reszte_przy_niejednoznacznej_kategorii(
    qtbot, nowe_produkty_fixture
):
    from dataclasses import replace

    from vexlab.przypadki_uzycia.nowe_szkice_allegro import KategoriaSzkicu

    offer = nowe_produkty_fixture[4]
    api = nowe_produkty_fixture[1]
    api.kategorie = lambda s, name: (
        (KategoriaSzkicu("456", "Silnik"),)
        if "silnik" in name
        else (KategoriaSzkicu("123", "Pierwsza"), KategoriaSzkicu("789", "Druga"))
    )
    offers = (
        offer,
        replace(offer, sku="NOWY", ean="", tytul="Osłona na silnik motocykla"),
        replace(offer, sku="WYBOR", ean="", tytul="Osłona do wyboru kategorii"),
    )
    w, jobs = panel(qtbot, nowe_produkty_fixture, offers)
    w.automatyczny_dobor.setChecked(True)
    w.przygotuj()
    wykonaj(jobs)
    assert [r.stan for r in w.wyniki] == [
        "Gotowa do utworzenia",
        "Gotowa do utworzenia",
        "Do poprawy",
    ]
    assert not w.plany[0].ustawienia.nowy and w.plany[1].ustawienia.kategoria == "456"
    assert "jednoznacznej kategorii" in w.wyniki[2].komunikat
    assert "POST" not in api.calls
