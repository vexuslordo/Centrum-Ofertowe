from dataclasses import replace

import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFileDialog

from tests.integration import test_porownanie_cen_allegro as porownania
from vexlab.gui.porownanie_cen_allegro import StronaPorownaniaCen

porownanie = porownania.porownanie


@pytest.fixture
def strona(qtbot, porownanie):
    uc, b, api, s = porownanie
    jobs, sesja = [], [s]
    w = StronaPorownaniaCen(uc, lambda *a: jobs.append(a), lambda: sesja[0])
    qtbot.addWidget(w)
    w.resize(1400, 850)
    w.show()
    w.odswiez_cenniki()
    fn, ok, error = jobs.pop(0)
    ok(fn())
    return w, jobs, sesja, porownanie


def wykonaj(jobs):
    fn, ok, error = jobs.pop(0)
    ok(fn())


def test_podglad_filtry_sortowanie_i_eksport_widocznych(strona, qtbot, tmp_path, monkeypatch):
    w, jobs, sesja, (uc, b, api, s) = strona
    w.porownaj.click()
    wykonaj(jobs)
    assert [x.text() for x in w.liczniki] == ["1", "1", "1"]
    assert w.model.rowCount() == 3 and w.eksport.isEnabled()
    w.filtr.setCurrentIndex(w.filtr.findData("Różnica"))
    assert w.proxy.rowCount() == 1
    assert w.proxy.index(0, 0).data() == "A"
    cel = tmp_path / "widoczne.csv"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a: (str(cel), "CSV"))
    w.eksport.click()
    wykonaj(jobs)
    assert '"A"' in cel.read_text(encoding="utf-8-sig") and '"B"' not in cel.read_text(
        encoding="utf-8-sig"
    )
    assert api.calls == 1
    w.filtr.setCurrentIndex(0)
    w.tabela.sortByColumn(7, Qt.SortOrder.AscendingOrder)
    assert w.proxy.index(0, 0).data() == "B"


def test_zmiana_sesji_nie_przyjmuje_spoznionego_raportu(strona):
    w, jobs, sesja, _ = strona
    w.porownaj_ceny()
    fn, ok, error = jobs.pop(0)
    result = fn()
    sesja[0] = replace(sesja[0], token="inne")
    w.polaczenie()
    ok(result)
    assert w.raport is None and w.model.rowCount() == 0 and not w.eksport.isEnabled()


def test_pusty_cennik_nie_wywoluje_api_i_brak_konta_daje_wskazowke(strona):
    w, jobs, sesja, (uc, b, api, s) = strona
    sesja[0] = None
    w.porownaj_ceny()
    assert not jobs and "Najpierw połącz" in w.info.text()
    b.zmieniony = True
    w.odswiez_cenniki()
    wykonaj(jobs)
    assert w.cennik.count() == 0 and not w.porownaj.isEnabled()
    assert api.calls == 0


def test_przycisk_zatrzymaj_dotyczy_biezacego_odczytu(strona):
    from vexlab.przypadki_uzycia.allegro import BladAllegro

    w, jobs, sesja, (uc, b, api, s) = strona
    w.porownaj_ceny()
    assert w.stop.isVisible()
    w.stop.click()
    fn, ok, error = jobs.pop(0)
    with pytest.raises(BladAllegro) as exc:
        fn()
    error(exc.value.kod, str(exc.value))
    assert w.model.rowCount() == 0 and w.raport is None and api.calls == 0
    assert "Anulowano" in w.info.text()


def test_wejscie_z_menu_otwiera_rzeczywista_strone(qtbot, tmp_path, porownanie):
    from types import SimpleNamespace

    from PySide6.QtCore import QSettings

    from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
    from vexlab.adaptery.czytnik_importu import CzytnikTabel
    from vexlab.adaptery.eksport_csv import EksportCSV
    from vexlab.adaptery.preferencje import PreferencjeQt
    from vexlab.gui.okno import OknoVexLab
    from vexlab.przypadki_uzycia.eksport import EksportujKatalog
    from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
    from vexlab.przypadki_uzycia.katalog import KatalogProduktow
    from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
    from vexlab.przypadki_uzycia.producenci import RejestrProducentow

    uc, b, api, s = porownanie
    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)),
            "Test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
        porownanie_cen=uc,
    )
    qtbot.addWidget(w, before_close_func=lambda _: qtbot.waitUntil(lambda: not w._zadania))
    w.show()
    qtbot.waitUntil(lambda: not w._zadania and w._katalog_wczytany)
    w.strona_allegro = SimpleNamespace(sesja=s)
    w.przejdz("Zmiana cen")
    qtbot.waitUntil(lambda: not w._zadania)
    p = w.strona_porownania_cen
    assert w.stos.currentWidget() is p and p.cennik.count() == 1
    p.porownaj.click()
    qtbot.waitUntil(lambda: not w._zadania)
    assert p.model.rowCount() == 3
    w.close()


def test_kolory_i_nazwy_odrozniaja_kierunek_roznicy(strona):
    from PySide6.QtGui import QColor

    from vexlab.gui.porownanie_cen_allegro import ModelPorownaniaCen

    w, jobs, sesja, _ = strona
    w.porownaj_ceny()
    wykonaj(jobs)
    rows = w.model.pozycje
    model = ModelPorownaniaCen()
    model.ustaw((*rows, replace(rows[0], roznica="-10", procent="-5")))
    assert [model.index(i, 8).data() for i in range(4)] == [
        "Za niska cena",
        "Cena zgodna",
        "Brak oferty",
        "Cena wyższa",
    ]
    colors = [model.index(i, 8).data(Qt.ItemDataRole.ForegroundRole) for i in range(4)]
    assert all(isinstance(c, QColor) and c.isValid() for c in colors)
    assert len({c.name() for c in colors}) == 4
    assert model.index(0, 6).data(Qt.ItemDataRole.ForegroundRole) == colors[0]
    assert "Za niska cena" in model.index(0, 8).data(Qt.ItemDataRole.AccessibleTextRole)
