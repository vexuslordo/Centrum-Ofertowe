import json
from dataclasses import replace

import pytest
from PySide6.QtCore import QMimeData, QPoint, QPointF, QSettings, Qt
from PySide6.QtGui import QDragEnterEvent, QDragMoveEvent, QDropEvent
from PySide6.QtWidgets import QLabel

from vexlab.gui.tablica_dashboardu import MIME, TablicaDashboardu
from vexlab.gui.uklad_dashboardu import (
    PamiecDashboardu,
    UkladDashboardu,
    UstawienieWidgetu,
    rozmieszczenie,
)


def initial():
    return UkladDashboardu(
        (UstawienieWidgetu("a", "2×1"), UstawienieWidgetu("b"), UstawienieWidgetu("c", "1×2"))
    )


def board(qtbot, tmp_path):
    settings = QSettings(str(tmp_path / "dashboard.ini"), QSettings.Format.IniFormat)
    b = TablicaDashboardu(initial(), PamiecDashboardu(settings))
    for key in ("a", "b", "c"):
        b.dodaj(key, key, "produkt", QLabel(key), "Produkty")
    qtbot.addWidget(b)
    b.resize(1200, 800)
    b.show()
    b.rozmiesc()
    return b


def test_zapis_anulowanie_i_reset_nie_gubia_ukladu(qtbot, tmp_path):
    b = board(qtbot, tmp_path)
    b.rozpocznij()
    b.ustaw("a", rozmiar="3×2")
    b.ustaw("c", ukryty=True)
    b.przesun("b", "a")
    changed = b.uklad
    assert changed != initial()
    b.zapisz()
    assert b.pamiec.odczytaj(initial()) == changed
    b.rozpocznij()
    b.resetuj()
    assert b.uklad == initial()
    b.anuluj()
    assert b.uklad == changed
    assert b.pamiec.odczytaj(initial()) == changed
    b.rozpocznij()
    b.resetuj()
    b.zapisz()
    assert b.pamiec.odczytaj(initial()) == initial()


@pytest.mark.parametrize("columns", [1, 2, 3])
def test_pakowanie_bez_kolizji_z_przypieciem_i_ukryciem(columns):
    layout = UkladDashboardu(
        tuple(
            UstawienieWidgetu(str(i), size, przypiety=i == 2, kolumna=2, wiersz=1)
            for i, size in enumerate(("1×1", "2×1", "2×2", "3×1", "3×2", "Pełna szerokość"))
        )
    )
    cells = set()
    for x, y, width, height in rozmieszczenie(layout, columns).values():
        assert 0 <= x < columns and x + width <= columns
        occupied = {(a, b) for a in range(x, x + width) for b in range(y, y + height)}
        assert not occupied & cells
        cells |= occupied
    assert rozmieszczenie(layout, columns) == rozmieszczenie(layout, columns)


def test_przypiety_nie_przesuwa_sie_przy_zmianie_sasiadow(qtbot, tmp_path):
    b = board(qtbot, tmp_path)
    b.rozpocznij()
    b._przypnij("b", True)
    before = b.pozycje["b"]
    b.przesun("b", "a")
    b.ustaw("b", rozmiar="3×2")
    assert b.pozycje["b"] == before
    b.przesun("c", "a")
    assert b.pozycje["b"] == before
    saved = b.uklad
    b.resize(500, 800)
    qtbot.waitUntil(lambda: b.kolumny == 1)
    b.resize(1200, 800)
    qtbot.waitUntil(lambda: b.kolumny == 3)
    assert b.uklad == saved and b.pozycje["b"] == before


@pytest.mark.parametrize(
    "raw",
    [
        "{",
        "[]",
        '{"wersja":99}',
        json.dumps({"wersja": 1, "widgety": [{"id": "a", "rozmiar": "99×99"}]}),
        json.dumps(
            {
                "wersja": 1,
                "widgety": [
                    {
                        "id": "a",
                        "rozmiar": "1×1",
                        "ukryty": False,
                        "przypiety": True,
                        "widok": "Lista",
                        "kolumna": 0,
                        "wiersz": -100,
                    }
                ],
            }
        ),
        "x" * 65000,
    ],
)
def test_uszkodzone_preferencje_nie_blokuja_startu(tmp_path, raw):
    s = QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)
    s.setValue(PamiecDashboardu.KLUCZ, raw)
    assert PamiecDashboardu(s).odczytaj(initial()) == initial()


def test_nowy_widget_dodany_do_zapisanego_ukladu(tmp_path):
    s = QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)
    memory = PamiecDashboardu(s)
    memory.zapisz(UkladDashboardu((replace(initial().widgety[1], ukryty=True),)))
    loaded = memory.odczytaj(initial())
    assert tuple(w.id for w in loaded.widgety) == ("b", "a", "c")
    assert loaded.widgety[0].ukryty


def test_rzeczywiste_zdarzenia_drop_tylko_z_wlasnej_tablicy_w_edycji(qtbot, tmp_path):
    b = board(qtbot, tmp_path)
    mime = QMimeData()
    mime.setData(MIME, (b.token + ":c").encode())
    point = b.ramki["a"].geometry().topLeft() + QPoint(10, 10)

    def enter():
        return QDragEnterEvent(
            QPointF(point),
            Qt.DropAction.MoveAction,
            mime,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
        )

    e = enter()
    b.dragEnterEvent(e)
    assert not e.isAccepted()
    b.rozpocznij()
    e = enter()
    b.dragEnterEvent(e)
    assert e.isAccepted()
    move = QDragMoveEvent(
        QPointF(point),
        Qt.DropAction.MoveAction,
        mime,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    b.dragMoveEvent(move)
    assert move.isAccepted() and not b.podglad.isHidden()
    drop = QDropEvent(
        QPointF(point),
        Qt.DropAction.MoveAction,
        mime,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    b.dropEvent(drop)
    assert drop.isAccepted() and b.uklad.widgety[0].id == "c"
    assert b.podglad.isHidden()
    mime.setData(MIME, b"foreign:c")
    e = enter()
    b.dragEnterEvent(e)
    assert not e.isAccepted()


def test_blad_zapisu_pozostawia_edycje_i_poprzedni_dokument(qtbot, tmp_path, monkeypatch):
    b = board(qtbot, tmp_path)
    b.rozpocznij()
    b.ustaw("a", ukryty=True)

    def odmowa(_):
        raise OSError("Brak dostępu")

    monkeypatch.setattr(b.pamiec, "zapisz", odmowa)
    with pytest.raises(OSError, match="Brak dostępu"):
        b.zapisz()
    assert b.edycja and b.zapisany == initial()
    assert b.uklad != initial()
    b.anuluj()
    assert b.uklad == initial()


def test_zapis_skrotow_wariantow_i_rozmiaru_po_ponownym_otwarciu(qtbot, tmp_path):
    b = board(qtbot, tmp_path)
    b.ustaw("a", skroty=("Zamówienia", "Produkty"), widok="Karty", rozmiar="3×2")
    b.zapisz()
    loaded = board(qtbot, tmp_path)
    assert loaded.uklad == b.uklad
    assert loaded.uklad.widgety[0].skroty == ("Zamówienia", "Produkty")


def test_menu_opcji_uruchamia_edytowalny_podglad(qtbot, tmp_path):
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QApplication, QMenu

    b = board(qtbot, tmp_path)
    chosen = []

    def wybierz():
        menu = QApplication.activePopupWidget()
        if isinstance(menu, QMenu):
            try:
                action = next(a for a in menu.actions() if a.text() == "Ukryj")
                action.trigger()
                chosen.append(True)
            finally:
                menu.close()

    QTimer.singleShot(10, wybierz)
    b._menu("a")
    assert chosen and b.edycja and b.ramki["a"].isHidden()
    b.anuluj()
    assert not b.ramki["a"].isHidden()
