from dataclasses import replace

from PySide6.QtCore import Qt

from tests.integration.test_zamowienia_allegro import API, Czas, raw, sesja
from vexlab.gui.zamowienia_allegro import StronaZamowien
from vexlab.kanaly.zamowienia_allegro import mapuj_zamowienie
from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro


def test_lista_filtry_szczegoly_i_wyczyszczenie_po_zmianie_konta(qtbot):
    uc, jobs, s = OdczytajZamowieniaAllegro(API(), Czas()), [], [sesja()]
    w = StronaZamowien(uc, lambda *args: jobs.append(args), lambda: s[0])
    qtbot.addWidget(w)
    w.show()
    w.pobierz.click()
    fn, ok, error = jobs.pop(0)
    ok(fn())
    assert w.model.rowCount() == 2 and "Widoczne: 2" in w.liczniki.text()
    w.tabela.selectRow(0)
    assert "Część testowa" in w.detale.toPlainText()
    assert "Za pobraniem" in w.detale.toPlainText()
    w.panel.zamknij_button.click()
    assert not w.detale.toPlainText()
    w.tabela.selectRow(0)
    assert "Część testowa" in w.detale.toPlainText()
    w.szukaj.setText("00123")
    assert w.model.rowCount() == 2
    w.szukaj.setText("brak")
    assert w.model.rowCount() == 0 and not w.detale.toPlainText()
    s[0] = replace(s[0], konto=replace(s[0].konto, id="inne"))
    w.polaczenie()
    assert w.raport is None and w.model.rowCount() == 0


def test_spozniony_wynik_nie_odslania_danych_po_wylogowaniu(qtbot):
    jobs, s = [], [sesja()]
    w = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()), lambda *a: jobs.append(a), lambda: s[0]
    )
    qtbot.addWidget(w)
    w.pobierz_liste()
    fn, ok, error = jobs.pop(0)
    result = fn()
    s[0] = None
    w.polaczenie()
    ok(result)
    assert w.raport is None and w.model.rowCount() == 0 and not w.detale.toPlainText()


def test_stop_odczytu_nie_pokazuje_czesciowej_listy(qtbot):
    import pytest

    from vexlab.przypadki_uzycia.allegro import BladAllegro

    jobs = []
    s = sesja()
    w = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()), lambda *a: jobs.append(a), lambda: s
    )
    qtbot.addWidget(w)
    w.pobierz_liste()
    w.stop.click()
    fn, ok, error = jobs.pop(0)
    with pytest.raises(BladAllegro) as e:
        fn()
    error(e.value.kod, str(e.value))
    assert not w.model.rowCount() and "Anulowano" in w.info.text()


def test_polskie_etykiety_kolory_kafelki_i_filtry(qtbot):
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QColor

    from vexlab.przypadki_uzycia.zamowienia_allegro import RaportZamowien

    s, jobs = sesja(), []
    w = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()), lambda *a: jobs.append(a), lambda: s
    )
    qtbot.addWidget(w)
    paid = replace(mapuj_zamowienie(raw()), zaplacono="123.00 PLN", platnosc="ONLINE")
    cancelled = replace(paid, id="inne", status="CANCELLED", realizacja="CANCELLED", zaplacono="")
    w.raport = RaportZamowien(
        s.konto.id, "test", s.srodowisko.value, "od", "do", "czas", (paid, cancelled)
    )
    w.filtruj()
    assert w.kafelki["Nowe"].text() == "1"
    assert set(w.kafelki) == {"Nowe", "Do wysyłki", "Wysłane", "Obrót (30 dni)"}
    assert w.model.index(0, 6).data() == "Nowe"
    assert w.model.index(1, 6).data() == "Anulowane"
    assert isinstance(w.model.index(0, 6).data(Qt.ItemDataRole.ForegroundRole), QColor)
    w.platnosc.setCurrentIndex(w.platnosc.findData("oplacone"))
    assert w.model.rowCount() == 1
    w.tabela.selectRow(0)
    assert (
        "READY_FOR_PROCESSING" not in w.detale.toPlainText()
        and "Opłacone" in w.detale.toPlainText()
    )


def test_stronicowanie_zaznaczanie_karty_i_czyszczenie_sesji(qtbot):
    from PySide6.QtCore import Qt

    from vexlab.przypadki_uzycia.zamowienia_allegro import RaportZamowien

    current = [sesja()]
    w = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()), lambda *a: None, lambda: current[0]
    )
    qtbot.addWidget(w)
    rows = tuple(replace(mapuj_zamowienie(raw()), id=str(i)) for i in range(103))
    w.raport = RaportZamowien("konto", "test", "sandbox", "od", "do", "czas", rows)
    w.filtruj()
    assert w.model.rowCount() == 50
    w._zaznacz_wszystkie(0)
    assert len(w.model.zaznaczone) == 103
    w._zmien_strone(1)
    assert w.model.index(0, 0).data(Qt.ItemDataRole.CheckStateRole) == Qt.CheckState.Checked
    w._widok(1)
    assert w.widoki.currentWidget() is w.karty
    w._zmien_strone(1)
    assert w.model.rowCount() == 3
    current[0] = None
    w.polaczenie()
    w._zmien_strone(-1)
    assert not w._wynik and not w.model.zaznaczone and w.model.rowCount() == 0
    assert not w.detale.toPlainText() and w.panel.klient.pola["Kupujący"].text() == "—"


def test_karty_maja_pelna_wysokosc_i_wybor_otwiera_wlasciwe_szczegoly(qtbot):
    from PySide6.QtCore import Qt

    s, jobs = sesja(), []
    page = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()), lambda *args: jobs.append(args), lambda: s
    )
    qtbot.addWidget(page)
    page.resize(1300, 850)
    page.show()
    page.pobierz_liste()
    fn, ok, error = jobs.pop()
    ok(fn())
    page._widok(1)
    qtbot.waitUntil(lambda: page.karty.visualRect(page.model.index(0, 2)).height() >= 150)
    first = page.karty.visualRect(page.model.index(0, 2))
    second = page.karty.visualRect(page.model.index(1, 2))
    assert not first.intersects(second)
    qtbot.mouseClick(page.karty.viewport(), Qt.MouseButton.LeftButton, pos=second.center())
    assert page.model.rows[1].id in page.panel.numer.text()
    assert "Część testowa" in page.panel.produkt.text()


def test_otworz_allegro_uzywa_oficjalnej_listy_zamowien(qtbot, monkeypatch):
    from PySide6.QtGui import QDesktopServices

    urls, jobs, session = [], [], sesja()
    monkeypatch.setattr(
        QDesktopServices, "openUrl", lambda url: urls.append(url.toString()) or True
    )
    page = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()), lambda *args: jobs.append(args), lambda: session
    )
    qtbot.addWidget(page)
    page.pobierz_liste()
    fn, ok, error = jobs.pop()
    ok(fn())
    page.tabela.selectRow(0)
    page.panel.otworz_button.click()
    assert urls == ["https://salescenter.allegro.com/orders"]
    page.panel.napisz.click()
    assert len(urls) == 1


def test_nawigacja_z_dashboardu_wybiera_wlasciwe_zamowienie_po_filtrze(qtbot):
    jobs = []
    s = sesja()
    page = StronaZamowien(
        OdczytajZamowieniaAllegro(API(), Czas()), lambda *args: jobs.append(args), lambda: s
    )
    qtbot.addWidget(page)
    page.pobierz.click()
    fn, ok, _ = jobs.pop(0)
    ok(fn())
    ident = page.raport.pozycje[-1].id
    page.szukaj.setText("brak takiego produktu")
    assert not page.model.rows
    page.pokaz_zamowienie(ident)
    assert page.tabela.currentIndex().data(Qt.ItemDataRole.UserRole).id == ident
    assert page.model.rows[0].id == ident
