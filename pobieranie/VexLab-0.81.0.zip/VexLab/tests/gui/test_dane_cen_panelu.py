"""Podgląd netto nie dopowiada stawki VAT ani nie modyfikuje oferty."""

from dataclasses import replace

from vexlab.gui.panel_walidacji_oferty import dane_cen
from vexlab.gui.walidacja_paczki_ui import oznacz_oferte
from vexlab.przypadki_uzycia.nowe_szkice_allegro import PlanNowegoSzkicu
from vexlab.przypadki_uzycia.vat_allegro import StawkaVAT, UstawieniaVAT


def test_netto_tylko_z_jawnej_stawki_pl(nowe_szkice_fixture):
    offer, settings = nowe_szkice_fixture[4:]
    settings = replace(
        settings,
        cena="123",
        waluta="PLN",
        vat=UstawieniaVAT((StawkaVAT("PL", "23.00"),), "GOODS"),
    )
    plan = PlanNowegoSzkicu(offer, settings, "test", "test", 1, None, ())
    assert dane_cen(offer, oznacz_oferte(offer, plan)) == (
        "123 PLN",
        "100.00 PLN",
        "23.00% (PL)",
    )
    assert offer == nowe_szkice_fixture[4]


def test_brak_pl_nie_uzywa_stawki_z_innego_kraju(nowe_szkice_fixture):
    offer, settings = nowe_szkice_fixture[4:]
    for vat in (None, UstawieniaVAT((StawkaVAT("CZ", "21.00"),), "GOODS")):
        plan = PlanNowegoSzkicu(offer, replace(settings, vat=vat), "test", "test", 1, None, ())
        assert dane_cen(offer, oznacz_oferte(offer, plan))[1:] == ("—", "—")
    assert dane_cen(offer, oznacz_oferte(offer))[1:] == ("—", "—")


def test_strona_producenta_tylko_z_jednoznacznego_aktywnego_wpisu(qtbot, nowe_szkice_fixture):
    from uuid import uuid4

    from PySide6.QtWidgets import QWidget

    from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
    from vexlab.gui.paczki_ofert import StronaPaczek
    from vexlab.przypadki_uzycia.producenci import ProducentDTO

    service, api, _, session, offer, _ = nowe_szkice_fixture
    parent = QWidget()
    qtbot.addWidget(parent)
    page = StronaPaczek(None, lambda *a: None, parent, allegro_dostepne=True)
    dialog = DialogNowychSzkicow(parent, service, session, (offer,), lambda *a: None)
    page.centrum.osadzenie.dialog = dialog
    dialog.producent_lokalny.setEditable(True)
    dialog.producent_lokalny.setEditText("Test")
    producer = ProducentDTO(uuid4(), "Test", True, 1, "https://example.com/")
    page.centrum.czytaj_producentow = lambda: (producer,)
    before = list(api.calls)
    assert page.centrum.adres_producenta() == "https://example.com/"
    for url in ("file:///tmp/test", "javascript:alert(1)", "https://user:secret@example.com/", ""):
        producer = replace(producer, strona_www=url)
        assert page.centrum.adres_producenta() == ""
    producer = replace(producer, strona_www="https://example.com/", aktywny=False)
    assert page.centrum.adres_producenta() == ""
    producer = replace(producer, aktywny=True)
    page.centrum.czytaj_producentow = lambda: (producer, replace(producer, id=uuid4()))
    assert page.centrum.adres_producenta() == ""
    assert api.calls == before
    page.centrum.osadzenie.dialog = None
    dialog.reject()
