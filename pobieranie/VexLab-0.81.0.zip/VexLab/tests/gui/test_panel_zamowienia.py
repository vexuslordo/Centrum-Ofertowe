from dataclasses import replace

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from tests.integration.test_zamowienia_allegro import raw
from vexlab.gui.panel_zamowienia import PanelZamowienia
from vexlab.kanaly.zamowienia_allegro import mapuj_zamowienie


def test_panel_pokazuje_kraj_rozdziela_adresy_kopiuje_i_czysci_dane(qtbot):
    data = raw()
    data["buyer"].update(email="test@example.org", address={"countryCode": "PL"})
    data["delivery"]["pickupPoint"] = {
        "name": "Automat testowy",
        "id": "123",
        "address": {"street": "Testowa 1"},
    }
    order = mapuj_zamowienie(data)
    panel = PanelZamowienia()
    qtbot.addWidget(panel)
    panel.show()
    panel.ustaw(order)
    assert panel.klient.pola["Kraj"].text() == "Polska"
    flag = panel.klient.ikony["Kraj"].pixmap().toImage()
    assert flag.pixelColor(5, 1).name() == "#ffffff"
    assert flag.pixelColor(5, 8).red() > 180 and flag.pixelColor(5, 8).green() < 80
    qtbot.mouseClick(panel.klient.kopiuj["E-mail"], Qt.MouseButton.LeftButton)
    assert QApplication.clipboard().text() == "test@example.org"
    assert "Automat testowy" not in panel.adres_dostawy.text()
    assert "Automat testowy" in panel.punkt_odbioru.text()
    assert panel.adresy.isHidden()
    panel.adresy_button.click()
    assert not panel.adresy.isHidden()
    qtbot.mouseClick(panel.punkt_odbioru.kopiuj, Qt.MouseButton.LeftButton)
    assert QApplication.clipboard().text() == order.punkt_odbioru
    assert panel.pozycje.count() == len(order.pozycje)
    assert panel.napisz.text() == "Wiadomość" and not panel.napisz.isEnabled()
    panel.ustaw(replace(order, kraj="CZ", email="<b>tekst</b>"))
    assert panel.klient.pola["Kraj"].text() == "Czechy"
    assert panel.klient.pola["E-mail"].textFormat() == Qt.TextFormat.PlainText
    panel.wyczysc()
    assert panel.klient.pola["E-mail"].text() == "—"
    assert not panel.klient.kopiuj["E-mail"].isEnabled()
    assert not panel.kopiuj_id.isEnabled() and panel.pozycje.count() == 0
    assert not panel.adres_dostawy.text() and not panel.punkt_odbioru.text()
    assert not panel.adres_dostawy.kopiuj.isEnabled() and not panel.punkt_odbioru.kopiuj.isEnabled()


def test_flagi_rynkow_i_operator_platnosci_bez_zgadywania_karty(qtbot):
    panel = PanelZamowienia()
    qtbot.addWidget(panel)
    raw_order = raw()
    raw_order["payment"].update(
        type="ONLINE", provider="PAYU", paidAmount={"amount": "123.00", "currency": "PLN"}
    )
    order = mapuj_zamowienie(raw_order)
    fingerprints = set()
    for code, name in (("PL", "Polska"), ("CZ", "Czechy"), ("HU", "Węgry"), ("SK", "Słowacja")):
        panel.ustaw(replace(order, kraj=code))
        assert panel.klient.pola["Kraj"].text() == name
        image = panel.klient.ikony["Kraj"].pixmap().toImage()
        assert not image.isNull()
        fingerprints.add(bytes(image.constBits()))
    assert len(fingerprints) == 4
    assert panel.dane.pola["Sposób zapłaty"].text() == "Przez internet · PayU"
    assert "Opłacone" in panel.dane.pola["Płatność"].text()
    assert "BLIK" not in panel.dane.pola["Sposób zapłaty"].text()
    panel.ustaw(replace(order, operator_platnosci="P24"))
    assert "Przelewy24" in panel.dane.pola["Sposób zapłaty"].text()
    panel.ustaw(replace(order, operator_platnosci="ALLEGRO"))
    assert "Allegro" in panel.dane.pola["Sposób zapłaty"].text()
    panel.ustaw(replace(order, operator_platnosci="Operator testowy"))
    assert "Operator testowy" in panel.dane.pola["Sposób zapłaty"].text()
    assert "Nieznany operator" not in panel.dane.pola["Sposób zapłaty"].text()
