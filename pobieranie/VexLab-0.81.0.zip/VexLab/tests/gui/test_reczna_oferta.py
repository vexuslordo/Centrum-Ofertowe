from PySide6.QtCore import QItemSelectionModel
from PySide6.QtWidgets import QFileDialog, QWidget

from tests.gui.test_edytor_opisu import TekstWizualny
from tests.gui.test_nowe_szkice_allegro import wykonaj
from tests.gui.test_podglad_oferty import png
from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.adaptery.zdjecia_ofert import ZdjeciaOfert
from vexlab.gui.podglad_oferty import ObrazPodgladu
from vexlab.gui.reczna_oferta import RecznaOferta
from vexlab.gui.szkice import StronaSzkicow
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


class BezSieci:
    def pobierz_obraz(self, url):
        raise AssertionError("Brak sieci")


def setup(qtbot, tmp_path):
    parent = QWidget()
    qtbot.addWidget(parent)
    service = SzkiceOfert(SzkiceSQLite(tmp_path / "k.sqlite3"))
    photos = ZdjeciaOfert(tmp_path / "zdjecia", BezSieci())
    jobs = []
    d = RecznaOferta(
        parent, service, lambda *a: jobs.append(a), PodgladZdjec(photos), pliki_zdjec=photos
    )
    d._parent_test = parent
    d.show()
    return d, jobs, service, photos


def wypelnij(d):
    d.sku.setText("SKU-RECZNE")
    d.tytul.setText("Osłona testowa do motocykla")
    d.ean.setText("5901234123457")
    d.cena.setText("120,50")
    d.opis.findChild(TekstWizualny).setPlainText("Pełny opis testowy")


def test_otwarcie_anulowanie_i_blad_walidacji_bez_zapisu(qtbot, tmp_path):
    d, jobs, service, _photos = setup(qtbot, tmp_path)
    assert d.width() <= d.screen().availableGeometry().width()
    assert d.height() <= d.screen().availableGeometry().height()
    d.zapisz(False)
    assert "SKU" in d.info.text() and not jobs and not service.lista()
    wypelnij(d)
    d.ean.setText("5901234123458")
    d.zapisz(False)
    assert "EAN" in d.info.text() and not jobs
    d.reject()
    assert not service.lista()


def test_zdjecie_dyskowe_zapis_odczyt_i_przekazanie_do_allegro(qtbot, tmp_path, monkeypatch):
    d, jobs, service, photos = setup(qtbot, tmp_path)
    wypelnij(d)
    source = tmp_path / "test.png"
    source.write_bytes(png())
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a: ([str(source)], ""))
    d.dodaj_pliki()
    assert d.trwa and not service.lista()
    wykonaj(jobs)
    assert len(d.lokalne) == 1 and "1" in d.lista_plikow.text()
    mini = d.miniatury_layout.itemAt(0).widget().findChild(ObrazPodgladu)
    assert mini.width() == mini.height() == 64
    source.unlink()
    sent = []
    d.wysylka_zadana.connect(sent.append)
    d.zapisz(True)
    wykonaj(jobs)
    assert not d.isVisible() and len(sent) == 1
    row = service.lista()[0]
    assert row.oferta == sent[0][0] and row.oferta.zdjecia == d.lokalne
    assert "Pełny opis" in row.oferta.opis
    assert row.oferta.cena == "120.50"
    assert photos.pobierz_obraz(row.oferta.zdjecia[0]).dane
    parent = d._parent_test
    drafts = StronaSzkicow(service, lambda *a: jobs.append(a), parent)
    drafts._wczytano(service.lista())
    drafts.tabela.selectionModel().select(
        drafts.tabela.model().index(0, 0),
        QItemSelectionModel.SelectionFlag.ClearAndSelect | QItemSelectionModel.SelectionFlag.Rows,
    )
    resumed = []
    drafts.wysylka_zadana.connect(resumed.append)
    drafts.wyslij()
    assert resumed == sent


def test_anulowany_wybor_pliku_i_blad_zapisu_zachowuje_formularz(qtbot, tmp_path, monkeypatch):
    d, jobs, _service, _photos = setup(qtbot, tmp_path)
    wypelnij(d)
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a: ([], ""))
    d.dodaj_pliki()
    assert not jobs and not d.lokalne
    d.zapisz(False)
    function, success, error = jobs[-1]
    error("IO", "Nie można zapisać")
    assert not d.trwa and d.isEnabled() and d.tytul.text() == "Osłona testowa do motocykla"
    assert "Nie można zapisać" in d.info.text()
    d.reject()


def test_powrot_do_szkicu_zdjecia_i_zapis_bez_duplikatu(qtbot, tmp_path):
    d, jobs, service, photos = setup(qtbot, tmp_path)
    wypelnij(d)
    source = tmp_path / "test.png"
    source.write_bytes(png())
    d._importuj_pliki((source,))
    wykonaj(jobs)
    d.zapisz(False)
    wykonaj(jobs)
    old = service.lista()[0]
    page = StronaSzkicow(
        service, lambda *a: jobs.append(a), d._parent_test, PodgladZdjec(photos), photos
    )
    page._wczytano(service.lista())
    page.tabela.selectRow(0)
    page.edytuj()
    edit = page.dialog
    assert edit.szkic.id == old.id
    assert edit.sku.text() == old.oferta.sku and edit.lokalne == old.oferta.zdjecia
    assert edit.opis.opis() == old.oferta.opis
    edit.tytul.setText("Zmieniona oferta")
    edit.cena.setText("150")
    emitted = []
    page.wysylka_zadana.connect(emitted.append)
    edit.zapisz(True)
    wykonaj(jobs)
    rows = service.lista()
    assert len(rows) == 1 and rows[0].id == old.id
    assert rows[0].oferta.cena == "150.00"
    assert rows[0].oferta.zdjecia == old.oferta.zdjecia
    assert emitted == [(rows[0].oferta,)]
    page.tabela.selectRow(0)
    page.edytuj()
    page.dialog.sku.setText("ANULOWANE")
    page.dialog.reject()
    assert service.lista() == rows


def test_konflikt_edycji_zachowuje_formularz_i_nie_przekazuje_do_kanalu(qtbot, tmp_path):
    from dataclasses import replace

    from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu

    d, jobs, service, photos = setup(qtbot, tmp_path)
    wypelnij(d)
    d.zapisz(False)
    wykonaj(jobs)
    old = service.lista()[0]
    edit = RecznaOferta(
        d._parent_test, service, lambda *a: jobs.append(a), pliki_zdjec=photos, szkic=old
    )
    edit.show()
    emitted = []
    edit.wysylka_zadana.connect(emitted.append)
    service.edytuj_pelny(old, replace(old.oferta, tytul="Zapis z innego okna"))
    edit.tytul.setText("Moja niezapisana zmiana")
    edit.zapisz(True)
    function, _success, error = jobs[-1]
    try:
        function()
    except BladScenariuszaKatalogu as exc:
        error(exc.kod, str(exc))
    else:
        raise AssertionError("Brak wykrycia konfliktu")
    assert edit.isVisible() and edit.isEnabled() and not edit.trwa
    assert edit.tytul.text() == "Moja niezapisana zmiana"
    assert "zmienił" in edit.info.text() and not emitted
    assert service.lista()[0].oferta.tytul == "Zapis z innego okna"
    edit.reject()


def test_szkice_o_roznych_walutach_nie_dostaja_wspolnej_waluty(qtbot, tmp_path):
    from dataclasses import replace
    from uuid import uuid4

    from vexlab.przypadki_uzycia.reczna_oferta import przygotuj_reczna
    from vexlab.przypadki_uzycia.szkice import SzkicDTO

    d, jobs, service, _photos = setup(qtbot, tmp_path)
    page = StronaSzkicow(service, lambda *a: jobs.append(a), d._parent_test)
    offer = przygotuj_reczna("SKU", "Nazwa oferty testowej", "", "100", "", (), ())
    first = SzkicDTO(
        uuid4(),
        uuid4(),
        1,
        1,
        offer,
        "Produkt",
        False,
        producent_zrodlowy="Producent",
        waluta_zrodlowa="PLN",
    )
    second = replace(first, id=uuid4(), oferta=replace(offer, sku="INNE"), waluta_zrodlowa="EUR")
    page._wczytano((first, second))
    page.tabela.selectAll()
    data = []
    page.przygotowanie_zadane.connect(lambda *args: data.append(args))
    page.wyslij()
    assert not data and "różne waluty" in page.info.text()
    d.reject()
