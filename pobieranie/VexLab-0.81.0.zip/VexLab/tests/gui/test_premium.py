"""Nowy renderer nie zmienia treści, edycji ani zachowania akcji."""

from PySide6.QtCore import QPoint, Qt
from PySide6.QtGui import QFont, QFontDatabase, QRawFont
from PySide6.QtWidgets import (
    QLineEdit,
    QPushButton,
    QStyleOptionViewItem,
    QTableWidget,
    QTableWidgetItem,
)

from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.premium import FONT, MONO, DelegatDanych, PoswiataPrzycisku
from vexlab.przypadki_uzycia.powloka import Motyw


def test_lokalne_fonty_maja_cztery_wagi_i_znaki_rynkow(qapp):
    zastosuj_motyw(qapp, Motyw.CIEMNY)
    for family in (FONT, MONO):
        assert {"Regular", "Medium", "SemiBold", "Bold"} <= set(QFontDatabase.styles(family))
        raw = QRawFont.fromFont(QFont(family))
        assert all(raw.supportsCharacter(ord(c)) for c in "ąćęłńóśźżčřěľťőű0123456789")


def test_font_techniczny_nie_zmienia_modelu_edytora_i_wyboru(qtbot, qapp):
    zastosuj_motyw(qapp, Motyw.CIEMNY)
    table = QTableWidget(1, 2)
    qtbot.addWidget(table)
    table.setHorizontalHeaderLabels(["Produkt", "SKU"])
    table.setItem(0, 0, QTableWidgetItem("Nazwa produktu"))
    table.setItem(0, 1, QTableWidgetItem("KOD-001"))
    table.show()
    qtbot.waitExposed(table)
    delegate = table.itemDelegate()
    assert isinstance(delegate, DelegatDanych)
    product, technical = QStyleOptionViewItem(), QStyleOptionViewItem()
    delegate.initStyleOption(product, table.model().index(0, 0))
    delegate.initStyleOption(technical, table.model().index(0, 1))
    assert technical.font.family() == MONO
    assert product.font.family() != MONO
    table.setCurrentCell(0, 1)
    editor = delegate.createEditor(table, technical, table.currentIndex())
    assert isinstance(editor, QLineEdit)
    delegate.setEditorData(editor, table.currentIndex())
    assert editor.text() == "KOD-001"
    editor.setText("KOD-002")
    delegate.setModelData(editor, table.model(), table.currentIndex())
    assert table.item(0, 1).text() == "KOD-002"
    assert table.currentColumn() == 1 and table.item(0, 0).text() == "Nazwa produktu"


def test_poswiata_nie_przechwytuje_klikniecia_i_nie_uruchamia_nieaktywnych_akcji(qtbot, qapp):
    zastosuj_motyw(qapp, Motyw.CIEMNY)
    button = QPushButton("Akcja")
    qtbot.addWidget(button)
    calls = []
    button.clicked.connect(lambda: calls.append(True))
    button.show()
    qtbot.waitExposed(button)
    qtbot.mouseMove(button, QPoint(8, 8))
    qtbot.mouseClick(button, Qt.MouseButton.LeftButton)
    assert calls == [True]
    effect = button.findChild(PoswiataPrzycisku)
    assert effect is not None
    assert effect.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
    button.setEnabled(False)
    qtbot.mouseClick(button, Qt.MouseButton.LeftButton)
    assert calls == [True]


def test_ograniczenie_animacji_nie_blokuje_akcji(qtbot, qapp):
    zastosuj_motyw(qapp, Motyw.CIEMNY)
    previous = qapp.property("ograniczAnimacje")
    qapp.setProperty("ograniczAnimacje", True)
    try:
        button = QPushButton("Akcja bez animacji")
        qtbot.addWidget(button)
        calls = []
        button.clicked.connect(lambda: calls.append(True))
        button.show()
        qtbot.waitExposed(button)
        qtbot.mouseMove(button, QPoint(8, 8))
        qtbot.mouseClick(button, Qt.MouseButton.LeftButton)
        assert calls == [True] and button.findChild(PoswiataPrzycisku) is None
    finally:
        qapp.setProperty("ograniczAnimacje", previous)


def test_zaokraglenie_zdjecia_obsluguje_dpi_i_nie_zmienia_zrodla(qapp):
    from PySide6.QtGui import QPixmap

    from vexlab.gui.premium import obraz_inspektora

    original = QPixmap(80, 80)
    original.setDevicePixelRatio(2)
    original.fill(Qt.GlobalColor.white)
    before = original.toImage()
    shown = obraz_inspektora(original, 80, 80)
    assert original.toImage() == before
    assert shown.devicePixelRatio() == 2
    image = shown.toImage()
    assert image.pixelColor(0, 0).alpha() == 0
    assert image.pixelColor(79, 0).alpha() == 0
    assert image.pixelColor(40, 40).alpha() == 255


def test_panele_modulow_maja_jedna_powierzchnie_w_obu_motywach(qtbot, qapp):
    from PySide6.QtWidgets import QFrame

    for theme in (Motyw.CIEMNY, Motyw.JASNY):
        zastosuj_motyw(qapp, theme)
        samples = []
        for name in (
            "karta",
            "panelCennika",
            "szczegolyCennika",
            "szczegolyAllegro",
            "panelZamowienia",
            "panelWalidacjiPaczki",
            "lewyPanelPrzygotowania",
        ):
            frame = QFrame()
            qtbot.addWidget(frame)
            frame.setObjectName(name)
            frame.resize(220, 300)
            frame.show()
            qapp.processEvents()
            image = frame.grab().toImage()
            samples.append(
                tuple(image.pixelColor(x, y).name() for x, y in ((20, 20), (110, 150), (200, 280)))
            )
            frame.hide()
        assert len(set(samples)) == 1
        assert samples[0][0] != samples[0][-1]  # Subtelna głębia jak w Dashboardzie.


def test_ikony_menu_zachowuja_kolory_modulow_w_obu_motywach(qapp):
    from PySide6.QtGui import QColor

    from vexlab.gui.design_system import IKONY_MENU, ikona_menu

    for dark in (True, False):
        for name, (_, light, strong) in IKONY_MENU.items():
            image = ikona_menu(name, dark).pixmap(24, 24).toImage()
            colors = [
                image.pixelColor(x, y) for x in range(image.width()) for y in range(image.height())
            ]
            pixel = max(colors, key=lambda color: color.alpha())
            expected = QColor(light if dark else strong)
            assert pixel.alpha() > 200
            assert abs(pixel.red() - expected.red()) <= 2
            assert abs(pixel.green() - expected.green()) <= 2
            assert abs(pixel.blue() - expected.blue()) <= 2


def test_menu_bez_belek_zachowuje_znacznik_aktywnosci_i_klikniecia(qtbot, qapp):
    from PySide6.QtWidgets import QFrame, QToolButton

    for theme in (Motyw.CIEMNY, Motyw.JASNY):
        zastosuj_motyw(qapp, theme)
        root = QFrame()
        root.setObjectName("nawigacja")
        qtbot.addWidget(root)
        root.resize(230, 100)
        button = QToolButton(root)
        button.setObjectName("nav")
        button.setAutoRaise(True)
        button.setCheckable(True)
        button.setText("Produkty")
        button.setGeometry(5, 10, 210, 32)
        root.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        root.show()
        root.setFocus()
        qtbot.mouseMove(root, QPoint(225, 90))
        qapp.processEvents()
        normal = root.grab().toImage()
        qtbot.mouseClick(button, Qt.MouseButton.LeftButton)
        qapp.processEvents()
        active = root.grab().toImage()
        assert button.isChecked()
        assert active.pixelColor(190, 25) == normal.pixelColor(190, 25)
        assert active.pixelColor(5, 25) != normal.pixelColor(5, 25)
        assert button.findChild(PoswiataPrzycisku) is None
        root.hide()
