from dataclasses import replace
from uuid import uuid4

import pytest
from PySide6.QtCore import QSettings, Qt
from PySide6.QtGui import QImage

from tests.gui.test_strony_cennika import czekaj
from tests.gui.test_strony_cennika import okno as okno
from vexlab.gui.branding_cennikow import BrandingCennikow
from vexlab.przypadki_uzycia.cenniki import CennikDTO


def test_kolumny_zrodlowe_zachowuja_pelne_dane_i_zaznaczenie(qtbot, okno):
    s = okno.strona_cennikow
    before = s.wiersze.item(0, 2).text()
    assert not s.wiersze.isColumnHidden(2) and s.wiersze.isColumnHidden(7)
    s.wiersze.selectAll()
    assert len(s._indeksy_wyboru()) == 350
    s.widok.kolumny_akcja.setChecked(True)
    assert not s.wiersze.isColumnHidden(2) and not s.wiersze.isColumnHidden(7)
    assert s.wiersze.horizontalHeaderItem(0).text() == "Wiersz"
    assert s.wiersze.item(0, 2).text() == before
    s.widok.kolumny_akcja.setChecked(False)
    assert len(s._indeksy_wyboru()) == 350
    s.widok._naglowek(0)
    assert not s._indeksy_wyboru()
    s.widok._naglowek(0)
    assert len(s._indeksy_wyboru()) == 350


def test_karty_wyboru_i_panel_korzystaja_z_tego_samego_zrodla(qtbot, okno):
    s = okno.strona_cennikow
    assert s.tabela.columnSpan(0, 0) == 4
    assert s.widok.kpi["produkty"].liczba.text() == "350"
    s.wiersze.setCurrentCell(1, 1)
    s.wiersze.selectRow(1)
    assert s.widok.panel.pola["SKU"].text() == s.pozycje[1].pozycja.dane.sku
    assert "Pełny opis 1" in s.widok.panel.pola["Dane dodatkowe"].text()
    s._pusty_podglad("Wybierz cennik")
    assert s.widok.kpi["produkty"].liczba.text() == "—"
    assert s.widok.panel.pola["SKU"].text() == "—"
    assert s.widok.panel.producent.text() == "Wybierz cennik"


def test_chipy_filtruja_caly_dokument_a_nie_widoczna_strone(qtbot, okno):
    s = okno.strona_cennikow
    expected = len(s.indeks.pasujace("", "Do poprawy"))
    s.widok.chipy["Do poprawy"].click()
    czekaj(qtbot, okno)
    assert s.status_pozycji.currentText() == "Do poprawy"
    assert len(s.pozycje) == expected
    s.wiersze.selectAll()
    assert len(s._indeksy_wyboru()) == expected
    s.widok.chipy["Wszystkie pozycje"].click()
    czekaj(qtbot, okno)
    assert len(s.pozycje) == 100


def test_checkbox_i_spacja_zmieniaja_wybor_bez_gubienia_innych(qtbot, okno):
    s = okno.strona_cennikow
    s.wiersze.selectRow(1)
    rect = s.wiersze.visualRect(s.wiersze.model().index(2, 0))
    qtbot.mouseClick(s.wiersze.viewport(), Qt.MouseButton.LeftButton, pos=rect.center())
    assert s._indeksy_wyboru() == frozenset({1, 2})
    qtbot.keyClick(s.wiersze, Qt.Key.Key_Space)
    assert s._indeksy_wyboru() == frozenset({1})


def test_logo_jest_ustawieniem_uzytkownika_i_wspoldzielone_po_id(qapp, tmp_path):
    settings = QSettings(str(tmp_path / "ui.ini"), QSettings.Format.IniFormat)
    branding = BrandingCennikow(settings)
    c = CennikDTO(
        uuid4(),
        "Cennik",
        2026,
        "",
        "Własna marka",
        "test.csv",
        "A",
        1,
        "2026-11-20",
        1,
        producent_id=uuid4(),
    )
    assert branding.logo(c).isNull()
    path = tmp_path / "logo.png"
    image = QImage(64, 64, QImage.Format.Format_RGB32)
    image.fill(0x112233)
    assert image.save(str(path))
    branding.ustaw(c, str(path))
    reloaded = BrandingCennikow(settings)
    assert not reloaded.logo(replace(c, id=uuid4())).isNull()
    assert reloaded.logo(replace(c, producent_id=uuid4())).isNull()
    branding.usun(c)
    assert BrandingCennikow(settings).logo(c).isNull()
    with pytest.raises(ValueError):
        branding.ustaw(c, str(tmp_path / "brak.png"))


def test_male_okno_zostawia_miejsce_na_produkty_i_otwiera_szczegoly(qtbot, okno):
    s = okno.strona_cennikow
    okno.resize(1366, 768)
    qtbot.waitUntil(lambda: not s.widok.panel.isHidden())
    qtbot.waitUntil(lambda: s.wiersze.viewport().height() >= 120)
    s.widok.detale_przycisk.click()
    assert s.widok.panel.isHidden()
    s.widok.detale_przycisk.click()
    assert not s.widok.panel.isHidden()
    okno.resize(1920, 1080)
    qtbot.waitUntil(lambda: s.widok._tryb == "pelny")
    assert not s.widok.panel.isHidden()
