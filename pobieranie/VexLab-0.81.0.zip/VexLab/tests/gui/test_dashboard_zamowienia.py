from tests.integration.test_dashboard_zamowienia import raport
from vexlab.gui.dashboard import DashboardView
from vexlab.przypadki_uzycia.powloka import PreferencjePowloki


def test_dashboard_wspolna_lista_waluta_i_wyczyszczenie_zrodla(qtbot):
    view = DashboardView(PreferencjePowloki())
    qtbot.addWidget(view)
    view.ustaw_zamowienia("Allegro", raport())
    view.ustaw_zamowienia("PrestaShop", raport("PrestaShop", "EUR", "50.00"))
    assert view.karty["zamowienia"].liczba.text() == "2"
    assert view.karty["obrot"].liczba.text() == "100,00 PLN"
    assert view.lista_zamowien.dane.rowCount() == 2
    view.waluta_zamowien.setCurrentIndex(view.waluta_zamowien.findData("EUR"))
    assert view.karty["obrot"].liczba.text() == "50,00 EUR"
    assert view.karty["marza"].liczba.text() == "—"
    view.ustaw_zamowienia("PrestaShop", None)
    assert view.lista_zamowien.dane.rowCount() == 1
    view.ustaw_zamowienia("Allegro", None)
    assert view.lista_zamowien.dane.rowCount() == 0
    assert view.karty["zamowienia"].liczba.text() == "—"
