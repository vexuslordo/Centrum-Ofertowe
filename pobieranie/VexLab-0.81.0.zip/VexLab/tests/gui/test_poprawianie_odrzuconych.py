from dataclasses import replace

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
)

from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from vexlab.gui.nowe_szkice_allegro import wskazowka_wyniku
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import WynikTworzenia

BLAD = (
    "HTTP 422. Product is already in the Catalog. The value of parameter 'Numer katalogowy części' "
    "in the offer is 'RETRY' and differs from our Catalog 'CAT-1'. "
    "To list the offer, change the value to 'CAT-1'."
)


def test_filtry_wynikow_i_wybor_wylacznie_widocznych(qtbot, nowe_szkice_fixture):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(qtbot, nowe_szkice_fixture, tuple(replace(o, sku=str(i)) for i in range(8)))
    w.przygotuj()
    wykonaj(jobs)
    states = (
        ("Odrzucono", ""),
        ("Do poprawy", ""),
        ("Utworzono szkic", "123"),
        ("Wymaga sprawdzenia", ""),
        ("Szkic do poprawy", "124"),
        ("Utworzono — sprawdź ustawienia", "125"),
        ("Gotowa do utworzenia", ""),
        ("Wstrzymano", ""),
    )
    w.wyniki = tuple(
        WynikTworzenia(str(i), stan, "Powód testowy", ident)
        for i, (stan, ident) in enumerate(states)
    )
    w._pokaz_wyniki()
    for nazwa, expected in (
        ("Odrzucone", (0,)),
        ("Do poprawy", (1,)),
        ("Do sprawdzenia", (3,)),
        ("Utworzone — do uzupełnienia", (4, 5)),
        ("Utworzone", (2, 4, 5)),
    ):
        w.filtr.setCurrentIndex(w.filtr.findText(nazwa))
        w.zaznacz_widoczne()
        assert w.wybrane() == expected
        assert tuple(i for i in range(8) if not w.tabela.isRowHidden(i)) == expected
    assert not w._mozna_wyslac(0) and not w._mozna_wyslac(1)
    assert not w._mozna_wyslac(2) and not w._mozna_wyslac(3)
    assert w._mozna_wyslac(6)


def test_poprawka_parametru_wysyla_tylko_odrzucony_wiersz_i_zachowuje_reszte(
    qtbot, nowe_produkty_fixture, monkeypatch
):
    service, api, repo, s, o, u = nowe_produkty_fixture
    oferty = (replace(o, sku="RETRY"), replace(o, sku="SENT"), replace(o, sku="UNKNOWN"))
    w, jobs = panel(qtbot, nowe_produkty_fixture, oferty)
    original = api.utworz_szkic

    def post(s, dane):
        sku = dane["external"]["id"]
        param = dane["productSet"][0]["product"]["parameters"]
        kod = next(p["values"][0] for p in param if p["id"] == "kod")
        if sku == "RETRY" and kod != "CAT-1":
            api.calls.append("POST")
            raise BladAllegro("ODRZUCONO", BLAD)
        result = original(s, dane)
        d = api.wyniki[sku]
        d["id"] = str(12345670 + len(api.wyniki))
        if sku == "UNKNOWN":
            raise BladAllegro("NIEZNANY", "Timeout po przyjęciu żądania.")
        return replace(result, ident=d["id"])

    api.utworz_szkic = post
    w.przygotuj()
    wykonaj(jobs)
    w.wyslij(False)
    wykonaj(jobs)
    assert [r.stan for r in w.wyniki] == ["Odrzucono", "Utworzono szkic", "Wymaga sprawdzenia"]
    assert api.calls.count("POST") == 3
    zachowane = w.wyniki[1:]
    stare_plany = w.plany[1:]
    # Samo sprawdzanie nie kasuje odrzucenia i nie odblokowuje wysyłki bez poprawy.
    w.przygotuj()
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Odrzucono" and not w._mozna_wyslac(0)
    w.tabela.selectRow(0)
    w.wyslij(True)
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Odrzucono" and w.wyniki[0].komunikat == BLAD
    assert api.calls.count("POST") == 3
    w.filtr.setCurrentIndex(w.filtr.findText("Odrzucone"))
    w.zaznacz_widoczne()
    assert w.wybrane() == (0,)

    def edit(d):
        if d.windowTitle().startswith("Popraw wybrane"):
            text = d.findChild(QPlainTextEdit).toPlainText()
            assert "CAT-1" in text and "SKU" in text
            next(
                b for b in d.findChildren(QPushButton) if b.text().startswith("Parametry produktu")
            ).click()
        else:
            assert "CAT-1" in d.findChild(QPlainTextEdit).toPlainText()
            source = next(
                c
                for c in d.findChildren(QComboBox)
                if c.accessibleName() == "Źródło parametru Kod producenta"
            )
            source.setCurrentIndex(source.findData(""))
            source.activated.emit(source.currentIndex())
            field = next(
                c for c in d.findChildren(QLineEdit) if c.accessibleName() == "Kod producenta"
            )
            field.setText("CAT-1")
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", edit)
    w.popraw_przycisk.click()
    assert not w.trwa and not w.plany
    w.przygotuj()
    wykonaj(jobs)
    assert w.wybrane() == (0,) and w.filtr.currentIndex() == 0
    assert w.wyniki[0].stan == "Gotowa do utworzenia"
    assert w.wyniki[1:] == zachowane and w.plany[1:] == stare_plany
    assert w.oferty[0].sku == "RETRY" and w.oferty[0].ean == o.ean
    assert dict(w.plany[0].ustawienia.wartosci)["kod"] == "CAT-1"
    assert "Wyślij poprawione" in w.utworz_przycisk.text()
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: QMessageBox.StandardButton.Yes)
    w.tworz()
    wykonaj(jobs)
    assert w.wyniki[0].stan == "Utworzono szkic"
    assert w.wyniki[1:] == zachowane
    assert api.calls.count("POST") == 4  # Nigdy drugi POST dla SENT lub UNKNOWN.


def test_ochrona_utworzonej_oferty_przed_edycja_paczki(qtbot, nowe_szkice_fixture):
    w, jobs = panel(qtbot, nowe_szkice_fixture)
    w.przygotuj()
    wykonaj(jobs)
    w.wyslij(False)
    wykonaj(jobs)
    przed = w.wyniki
    w.tabela.selectRow(0)
    liczba = len(jobs)
    w.edytuj_masowo()
    w.uzupelnij()
    assert len(jobs) == liczba and "już utworzoną" in w.info.text()
    w.ilosc.setValue(50)
    w.przygotuj()
    wykonaj(jobs)
    assert w.plany[0].ustawienia.ilosc == 1 and w.wyniki == przed
    assert not w.utworz_przycisk.isEnabled()
    assert nowe_szkice_fixture[1].calls.count("POST") == 1


def test_pelna_wskazowka_konfliktu_numeru_katalogowego_bez_zmiany_sku():
    text = wskazowka_wyniku("Odrzucono", BLAD)
    assert "CAT-1" in text and "ręczne" in text and "SKU pozostaje" in text
