"""Regresje zakresu akcji i uczciwości statusów w istniejącym widoku ZIP."""

from dataclasses import replace

from PySide6.QtWidgets import QWidget

from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.gui.paczki_ofert import StronaPaczek
from vexlab.gui.walidacja_paczki_ui import oznacz_oferte
from vexlab.przypadki_uzycia.nowe_szkice_allegro import PlanNowegoSzkicu


def test_niesprawdzony_zip_nie_jest_gotowy_i_nie_wymysla_walidacji_ean(nowe_szkice_fixture):
    offer = replace(nowe_szkice_fixture[4], ean="niepoprawny")
    state = oznacz_oferte(offer)
    assert not state.gotowa and not state.grupy
    assert all(text == "Nie sprawdzono" for _, text, _ in state.kontrole)
    plan = PlanNowegoSzkicu(offer, nowe_szkice_fixture[5], "test", "test", 1, None, ("Błędny EAN",))
    checked = oznacz_oferte(offer, plan, mozna_utworzyc=True)
    assert not checked.gotowa and "ean" in checked.grupy


def test_filtry_nie_zmieniaja_paczki_ani_zakresu_oryginalnej_akcji(qtbot, nowe_szkice_fixture):
    parent = QWidget()
    qtbot.addWidget(parent)
    page = StronaPaczek(None, lambda *args: None, parent, allegro_dostepne=True)
    offers = (nowe_szkice_fixture[4], replace(nowe_szkice_fixture[4], sku="DRUGI"))
    page._pokaz(offers)
    page.centrum._filtr("gotowe")
    assert all(page.tabela.isRowHidden(i) for i in range(2))
    received = []
    page.wysylka_zadana.connect(received.append)
    page.przygotuj_allegro.click()
    assert received == [offers] and page.oferty is offers
    page.centrum._filtr("wszystkie")
    page.centrum.szukaj.setText("DRUGI")
    assert page.tabela.isRowHidden(0) and not page.tabela.isRowHidden(1)
    assert page.tabela.item(1, 1).text() == "DRUGI"
    assert page.tabela.item(1, 2).text() == offers[1].tytul


def test_statusy_czytaja_plan_i_traca_waznosc_po_zmianie_sesji_lub_danych(
    qtbot, nowe_szkice_fixture
):
    service, api, _, session, offer, settings = nowe_szkice_fixture
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    dialog = DialogNowychSzkicow(parent, service, session, (offer,), lambda *a: jobs.append(a))
    dialog.kompletny.setChecked(False)
    dialog.waluta.setCurrentIndex(dialog.waluta.findData("PLN"))
    dialog.ustawienia[0] = settings
    dialog.przygotuj()
    function, success, _ = jobs[-1]
    success(function())
    page = StronaPaczek(None, lambda *args: None, parent, allegro_dostepne=True)
    page._pokaz((offer,))
    page.centrum.czytaj_kontekst = lambda: (dialog, session)
    before = list(api.calls)
    page.centrum.odswiez(wymus=True)
    assert page.centrum.stany[0].gotowa
    assert api.calls == before  # Odczyt UI nie uruchamia walidacji ani API.
    page.tabela.setCurrentCell(0, 2)
    assert page.centrum.panel.pola["Ilość"].text() == str(settings.ilosc)
    page.centrum.czytaj_kontekst = lambda: (dialog, replace(session))
    page.centrum.odswiez(wymus=True)
    assert not page.centrum.stany[0].gotowa
    page.centrum.czytaj_kontekst = lambda: (dialog, session)
    page._pokaz((replace(offer, cena="999"),))
    assert not page.centrum.stany[0].gotowa
    page.centrum.czytaj_kontekst = lambda: (None, session)
    page.centrum.odswiez(wymus=True)
    assert not page.centrum.stany[0].gotowa
    dialog.reject()


def test_zapisane_i_niepewne_wyniki_nie_sa_gotowe_do_nowego_szkicu(nowe_szkice_fixture):
    from vexlab.przypadki_uzycia.nowe_szkice_allegro import WynikTworzenia

    offer, settings = nowe_szkice_fixture[4:]
    plan = PlanNowegoSzkicu(offer, settings, "test", "test", 1, None, ())
    for state, ident in (("Utworzono szkic", "123"), ("Wynik nieznany", "")):
        shown = oznacz_oferte(
            offer,
            plan,
            WynikTworzenia(offer.sku, state, "Sprawdź wynik wysyłki.", ident),
            mozna_utworzyc=True,
        )
        assert not shown.gotowa and "gotowe" not in shown.grupy
    missing = oznacz_oferte(offer, plan, mozna_utworzyc=True, producent_wymagany=True)
    assert not missing.gotowa and "producent" in missing.grupy
