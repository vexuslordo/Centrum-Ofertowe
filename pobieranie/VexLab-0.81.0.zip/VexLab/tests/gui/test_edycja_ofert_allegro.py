import pytest
from PySide6.QtWidgets import QApplication, QMessageBox, QWidget

from tests.integration.test_zapis_szkicu_allegro import Czas
from vexlab.adaptery.rejestr_zapisow_allegro import RejestrZapisowJSON
from vexlab.gui.edycja_ofert_allegro import EdycjaOfertAllegro
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.edycja_ofert_allegro import EdytujOfertyAllegro, OfertaEdycji, skrot
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import PrzyjecieZapisu


@pytest.fixture
def panel(qtbot, tmp_path, nowe_szkice_fixture):
    s = nowe_szkice_fixture[3]

    class API:
        def __init__(self):
            self.patches = []
            self.rows = {
                ident: OfertaEdycji(
                    ident,
                    "Oferta testowa motocykla",
                    "SKU-" + ident,
                    "5901234123457",
                    "produkt",
                    "123",
                    "ACTIVE",
                    "wersja",
                    "ochrona",
                    skrot([s.srodowisko.value, s.konto.id]),
                )
                for ident in ("123", "456")
            }
            self.error = False

        def odczytaj_edycje(self, session, ident):
            return self.rows[ident]

        def produkt_ean(self, *args):
            return "produkt-2", "Produkt wybrany przez EAN"

        def zmien_oferte(self, session, z, aktualne):
            assert aktualne()
            self.patches.append(z)
            if self.error and z.baza.ident == "456":
                raise BladAllegro("NIEZNANY", "Nie potwierdzono zapisu")
            self.rows[z.baza.ident] = z.oczekiwana()
            return PrzyjecieZapisu()

        def operacja_szkicu(self, *args):
            return True

    parent = QWidget()
    qtbot.addWidget(parent)
    api = API()
    service = EdytujOfertyAllegro(api, RejestrZapisowJSON(tmp_path), Czas())
    jobs, current = [], [True]
    d = EdycjaOfertAllegro(
        parent, service, s, ("123", "456"), lambda *a: jobs.append(a), lambda: current[0]
    )
    d._test_parent = parent
    d.show()
    return d, jobs, api, current


def run(jobs):
    while jobs:
        fn, ok, error = jobs.pop(0)
        try:
            result = fn()
        except BladAllegro as exc:
            error(exc.kod, str(exc))
        else:
            ok(result)


def test_pobranie_indywidualne_sku_ean_i_podglad_bez_zapisu(panel, monkeypatch):
    d, jobs, api, _current = panel
    d.odczytaj()
    run(jobs)
    assert d.tekst(0, 5) == "SKU-123" and d.tekst(1, 5) == "SKU-456"
    d.tabela.item(0, 5).setText("NOWE-SKU")
    d.tabela.item(1, 7).setText("5056711605244")
    d.przygotuj()
    run(jobs)
    assert d.tekst(1, 8) == "Produkt wybrany przez EAN"
    assert d.plany[0].sku == "NOWE-SKU" and d.plany[1].sku == "SKU-456"
    assert d.zapis.isEnabled() and not api.patches
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    d.zapisz()
    assert not jobs and not api.patches
    d.reject()


def test_masowe_tytuly_i_raport_wyniku_czesciowego(panel, monkeypatch):
    d, jobs, api, _current = panel
    d.odczytaj()
    run(jobs)
    d.szukaj.setText("testowa")
    d.zamien.setText("zmieniona")
    d.tytuly()
    d.przygotuj()
    run(jobs)
    api.error = True
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    d.zapisz()
    run(jobs)
    assert len(api.patches) == 2
    assert d.tekst(0, 9) == "Zapisane" and "Do sprawdzenia" in d.tekst(1, 9)
    assert "Zapisane: 1" in d.info.text() and "Do sprawdzenia: 1" in d.info.text()
    d.kopiuj_raport()
    report = QApplication.clipboard().text()
    assert "SKU-123" in report and "Do sprawdzenia" in report and "456" in report
    d.reject()


def test_zmiana_podgladu_blokuje_stary_plan_i_zmiana_konta_nie_wysyla(panel):
    d, jobs, api, current = panel
    d.odczytaj()
    run(jobs)
    d.przygotuj()
    run(jobs)
    d.tabela.item(0, 5).setText("POPRAWIONE")
    assert not d.plany and not d.zapis.isEnabled()
    d.przygotuj()
    run(jobs)
    current[0] = False
    d.zapisz()
    assert not api.patches and not jobs
    d.reject()


def test_zatrzymanie_po_biezacej_ofercie(panel):
    d, jobs, api, _current = panel
    d.odczytaj()
    assert d.trwa and jobs
    d.reject()
    assert d.isVisible()
    run(jobs)
    assert not d.trwa and len(d.bazy) == 1 and not api.patches
    assert "Zatrzymano" in d.info.text()
    d.reject()


def test_kody_z_arkusza_sa_mapowane_po_id_i_nie_zastepuja_pustych_pol(panel, monkeypatch):
    from PySide6.QtWidgets import QInputDialog

    d, jobs, api, _current = panel
    d.odczytaj()
    run(jobs)
    monkeypatch.setattr(
        QInputDialog,
        "getMultiLineText",
        lambda *a: ("ID Allegro\tSKU\tEAN\n456\tNOWE-456\t5056711605244\n123\tNOWE-123\t", True),
    )
    d.wklej()
    assert d.tekst(0, 5) == "NOWE-123" and d.tekst(1, 5) == "NOWE-456"
    assert d.tekst(0, 7) == "5901234123457" and d.tekst(1, 7) == "5056711605244"
    assert not api.patches
    monkeypatch.setattr(QInputDialog, "getMultiLineText", lambda *a: ("999\tINNE\t", True))
    d.wklej()
    assert "spoza" in d.info.text() and d.tekst(0, 5) == "NOWE-123"
    d.reject()
