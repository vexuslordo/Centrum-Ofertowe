import pytest
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QLineEdit

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.gui.prestashop import StronaPresta
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.prestashop import (
    BladPresta,
    KategoriaPresta,
    PolaczPresta,
    PozycjaPresta,
    SlownikiPresta,
)
from vexlab.przypadki_uzycia.producenci import RejestrProducentow


class API:
    def __init__(self):
        self.calls = []
        self.awaria = False

    def slowniki(self, k):
        self.calls.append(("meta", k))
        if self.awaria:
            raise BladPresta("UPRAWNIENIA", "Brak uprawnienia GET languages.")
        return SlownikiPresta(
            (PozycjaPresta("1", "Sklep testowy"), PozycjaPresta("3", "Drugi sklep")),
            (PozycjaPresta("2", "Polski"),),
        )

    def kategorie(self, k):
        self.calls.append(("categories", k))
        return (
            KategoriaPresta("10", "0", "Motocykle", True),
            KategoriaPresta("12", "10", "Crash pady", True),
            KategoriaPresta("13", "0", "Archiwum", False),
        )


class Magazyn:
    def __init__(self):
        self.value = None

    def zapisz(self, k):
        self.value = k

    def odczytaj(self):
        return self.value

    def usun(self):
        self.value = None


def wykonaj(jobs):
    fn, ok, error = jobs.pop(0)
    try:
        value = fn()
    except BladPresta as e:
        error(e.kod, str(e))
    else:
        ok(value)


@pytest.fixture
def panel(qtbot):
    api, magazyn, jobs = API(), Magazyn(), []
    w = StronaPresta(PolaczPresta(api, magazyn), lambda *args: jobs.append(args))
    qtbot.addWidget(w)
    w.resize(1150, 780)
    w.show()
    return w, api, magazyn, jobs


def polacz(panel):
    w, api, magazyn, jobs = panel
    w.adres.setText("https://sklep.example/")
    w.klucz.setText("K" * 32)
    w.polacz.click()
    assert w._trwa and not w.adres.isEnabled()
    assert not api.calls
    wykonaj(jobs)
    assert not w._trwa and "Połączono" in w.status.text()
    assert w.sklep.currentData() == "" and w.jezyk.currentData() == "2"
    w.sklep.setCurrentIndex(w.sklep.findData("1"))


def test_wybor_kategorii_pamiec_restart_bez_sieci_i_zmiana_kontekstu(panel):
    w, api, magazyn, jobs = panel
    polacz(panel)
    assert w.klucz.echoMode() == QLineEdit.EchoMode.Password
    w.pobierz.click()
    wykonaj(jobs)
    assert w.model.rowCount() == 3 and "Pobrano kategorii: 3" in w.status.text()
    w.tabela.setCurrentIndex(w.proxy.mapFromSource(w.model.index(1, 0)))
    assert w._kategoria() == "12" and "Crash pady" in w.wybrana.text()
    w.zapisz.click()
    wykonaj(jobs)
    assert magazyn.value.kategoria == "12" and len(api.calls) == 2
    w.sklep.setCurrentIndex(w.sklep.findData("3"))
    assert w.model.rowCount() == 0 and not w._kategoria()
    w.przywroc()
    wykonaj(jobs)
    assert len(api.calls) == 2  # Przywrócenie pliku nigdy nie łączy z API.
    w.polacz.click()
    wykonaj(jobs)
    assert w.sklep.currentData() == "1"
    w.pobierz.click()
    wykonaj(jobs)
    assert w._kategoria() == "12"
    w.adres.setText("https://inny.example/")
    assert not w._sprawdzone and not w.zapisz.isEnabled() and w.model.rowCount() == 0
    w.polacz.click()
    wykonaj(jobs)
    assert w.sklep.currentData() == ""  # Nie przenosi wyboru do innego sklepu.


def test_filtr_nieaktywnosc_i_brak_dostepu_nie_daja_falszywego_sukcesu(panel):
    w, api, magazyn, jobs = panel
    polacz(panel)
    w.pobierz.click()
    wykonaj(jobs)
    w.filtr.setText("archiwum")
    assert w.proxy.rowCount() == 1
    w.tabela.setCurrentIndex(w.proxy.index(0, 0))
    assert not w._kategoria() and "nieaktywna" in w.wybrana.text()
    w.filtr.setText("nieistniejaca")
    assert w.proxy.rowCount() == 0 and not w._kategoria()
    api.awaria = True
    w.polacz.click()
    wykonaj(jobs)
    assert "Brak uprawnienia" in w.status.text()
    assert not w.zapisz.isEnabled() and not w.model.pozycje


def test_usuniecie_nie_zmienia_sklepu_i_nie_zapisuje_automatycznie(panel):
    w, api, magazyn, jobs = panel
    polacz(panel)
    assert magazyn.value is None
    w.usun.click()
    wykonaj(jobs)
    assert w.adres.text() == w.klucz.text() == ""
    assert len(api.calls) == 1


def test_nieprawidlowy_adres_panelu_nie_jest_wysylany(panel):
    w, api, magazyn, jobs = panel
    w.adres.setText("https://sklep.example/admin/index.php?token=fixture")
    w.klucz.setText("K" * 32)
    w.polacz.click()
    assert not jobs and not api.calls and "bez panelu" in w.status.text()


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_wejscie_z_ustawien_i_nawigacji_do_rzeczywistego_modulu(qtbot, tmp_path, motyw):
    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    api, magazyn = API(), Magazyn()
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "p.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
        presta=PolaczPresta(api, magazyn),
    )
    qtbot.addWidget(w, before_close_func=lambda _: qtbot.waitUntil(lambda: not w._zadania))
    w.show()
    qtbot.waitUntil(lambda: not w._zadania and w._katalog_wczytany)
    w.wybor_motywu.setCurrentIndex(w.wybor_motywu.findData(motyw))
    w.przejdz("PrestaShop")
    assert w.stos.currentWidget() is w.strona_presta
    assert not api.calls and w.strona_presta.adres.text() == ""
    assert w.integracje.nazwy.count("PrestaShop") == 1
    p = w.strona_presta
    assert not p.isAncestorOf(p.adres)
    assert p.panel_polaczenia.isAncestorOf(p.adres)
    assert not p.adres.isVisible()
    p.ustawienia.click()
    assert w.integracje.currentWidget() is p.panel_polaczenia
    assert p.adres.isVisible()
    assert w.ustawienia_zakladki.currentIndex() == 1
    w.przejdz("PrestaShop")
    assert not p.adres.isVisible()
    w.strona_presta.adres.setText("https://sklep.example/")
    w.strona_presta.klucz.setText("K" * 32)
    w.strona_presta.polacz.click()
    qtbot.waitUntil(lambda: not w._zadania and not w.strona_presta._trwa)
    i = w.integracje.nazwy.index("PrestaShop")
    assert "Połączono" in w.integracje.lista.item(i).text()
    assert "PrestaShop" in w.pasek_integracji.status.text()
    assert w.dashboard.panel_integracji.presta.wartosci[0].text() == "https://sklep.example/"
    w.pasek_integracji.ustaw("konto Allegro")
    assert "konto Allegro" in w.pasek_integracji.status.text()
    w.pasek_integracji.ustaw(None)
    assert "PrestaShop" in w.pasek_integracji.status.text()
    w.strona_presta.adres.setText("https://inny.example/")
    assert "Niepołączono" in w.pasek_integracji.status.text()
    assert w.dashboard.panel_integracji.presta.wartosci[0].text() == "—"
    w.close()


def test_metryki_rozrozniaja_brak_odczytu_i_pusta_liste(panel):
    w, api, magazyn, jobs = panel
    assert [v.text() for v in w.liczniki[:3]] == ["—"] * 3
    polacz(panel)
    w.sklep.setCurrentIndex(1)
    w.pobierz.click()
    wykonaj(jobs)
    assert [v.text() for v in w.liczniki[:3]] == ["3", "2", "1"]
    w.sklep.setCurrentIndex(2)
    assert [v.text() for v in w.liczniki[:3]] == ["—"] * 3
    api.kategorie = lambda _: ()
    w.pobierz.click()
    wykonaj(jobs)
    assert [v.text() for v in w.liczniki[:3]] == ["0"] * 3
