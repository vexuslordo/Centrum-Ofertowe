import pytest

from tests.integration import test_aktualizacja_cen_allegro as integracja
from tests.integration import test_porownanie_cen_allegro as porownania
from vexlab.gui.porownanie_cen_allegro import StronaPorownaniaCen

porownanie = porownania.porownanie
ceny = integracja.ceny


def wykonaj(jobs):
    fn, ok, error = jobs.pop(0)
    ok(fn())


@pytest.fixture
def strona(qtbot, ceny):
    uc, api, s, plan, _ = ceny
    jobs, sesja = [], [s]
    w = StronaPorownaniaCen(uc.porownanie, lambda *a: jobs.append(a), lambda: sesja[0], uc)
    qtbot.addWidget(w)
    w.show()
    w.odswiez_cenniki()
    wykonaj(jobs)
    w.porownaj.click()
    wykonaj(jobs)
    w.wybierz_roznice.click()
    assert len(w.tabela.selectionModel().selectedRows()) == 1
    return w, jobs, sesja, ceny


def test_anulowanie_podgladu_nie_wysyla(strona, monkeypatch):
    w, jobs, sesja, (uc, api, *_) = strona
    w.wybierz_wszystkie.click()
    assert len(w.tabela.selectionModel().selectedRows()) == 3
    assert w.zaznaczenie.text() == "Zaznaczono: 3 z 3"
    monkeypatch.setattr("vexlab.gui.porownanie_cen_allegro.potwierdz_ceny", lambda *a: False)
    w.zmien_ceny.click()
    wykonaj(jobs)
    assert not jobs and api.patches == 0 and "Anulowano" in w.info.text()


def test_zapis_po_zgodzie_pokazuje_wynik_i_czysci_stare_porownanie(strona, monkeypatch):
    w, jobs, sesja, (uc, api, *_) = strona
    monkeypatch.setattr("vexlab.gui.porownanie_cen_allegro.potwierdz_ceny", lambda *a: True)
    w.zmien_ceny.click()
    wykonaj(jobs)
    assert api.patches == 0 and w.stop.isVisible()
    wykonaj(jobs)
    assert api.patches == 1 and w.raport is None and w.model.rowCount() == 0
    assert w.historia.rows[0].status == "Gotowe" and "Gotowe: 1" in w.info.text()
    w.historia.close()


def test_zmiana_konta_podczas_potwierdzania_blokuje_zapis(strona, monkeypatch):
    w, jobs, sesja, (uc, api, *_) = strona

    def zgoda(*a):
        sesja[0] = None
        w.polaczenie()
        return True

    monkeypatch.setattr("vexlab.gui.porownanie_cen_allegro.potwierdz_ceny", zgoda)
    w.zmien_ceny.click()
    wykonaj(jobs)
    assert not jobs and api.patches == 0 and w.raport is None
