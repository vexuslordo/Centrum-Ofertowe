from PySide6.QtWidgets import QMessageBox, QWidget

from tests.gui.test_nowe_szkice_allegro import wykonaj
from tests.integration.test_publikacja_allegro import API
from vexlab.adaptery.publikacja_allegro_sqlite import RejestrPublikacjiSQLite
from vexlab.gui.publikacja_allegro import PublikacjaAllegro
from vexlab.przypadki_uzycia.publikacja_allegro import PublikujSzkiceAllegro


def setup(qtbot, tmp_path, nowe_szkice_fixture):
    parent = QWidget()
    qtbot.addWidget(parent)
    api = API()
    service = PublikujSzkiceAllegro(api, RejestrPublikacjiSQLite(tmp_path / "pub.sqlite3"), api)
    jobs = []
    active = [True]
    d = PublikacjaAllegro(
        parent,
        service,
        nowe_szkice_fixture[3],
        ("123",),
        lambda *a: jobs.append(a),
        lambda: active[0],
    )
    d._parent_test = parent
    d.show()
    qtbot.waitUntil(lambda: len(jobs) == 1)
    wykonaj(jobs)
    return d, jobs, api, active


def test_odczyt_i_domyslne_nie_nie_publikuja(qtbot, tmp_path, nowe_szkice_fixture, monkeypatch):
    d, jobs, api, _active = setup(qtbot, tmp_path, nowe_szkice_fixture)
    assert "Do publikacji: 1" in d.info.text() and d.publikuj.isEnabled()
    defaults = []

    def no(*args):
        defaults.append(args[-1])
        return QMessageBox.StandardButton.No

    monkeypatch.setattr(QMessageBox, "question", no)
    d.potwierdz()
    assert defaults == [QMessageBox.StandardButton.No] and len(jobs) == 1
    assert not any(c[0] == "PUT" for c in api.calls)
    d.reject()


def test_potwierdzenie_publikuje_a_sprawdzenie_wyniku_nie_ponawia(
    qtbot, tmp_path, nowe_szkice_fixture, monkeypatch
):
    d, jobs, api, _active = setup(qtbot, tmp_path, nowe_szkice_fixture)
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    d.potwierdz()
    wykonaj(jobs)
    assert "Opublikowano: 1" in d.info.text() and not d.publikuj.isEnabled()
    assert d.tabela.item(0, 4).text() == "Opublikowano"
    d.wynik.click()
    wykonaj(jobs)
    assert len([c for c in api.calls if c[0] == "PUT"]) == 1
    d.reject()


def test_zmiana_konta_po_potwierdzeniu_nie_wysyla_put(
    qtbot, tmp_path, nowe_szkice_fixture, monkeypatch
):
    d, jobs, api, active = setup(qtbot, tmp_path, nowe_szkice_fixture)

    def yes(*args):
        active[0] = False
        return QMessageBox.StandardButton.Yes

    monkeypatch.setattr(QMessageBox, "question", yes)
    d.potwierdz()
    assert not any(c[0] == "PUT" for c in api.calls) and len(jobs) == 1
    d.reject()
