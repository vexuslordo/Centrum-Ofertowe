from PySide6.QtCore import QSettings

from tests.gui.test_allegro import Serwis
from tests.integration.test_wiadomosci_allegro import Transport, watek
from tests.integration.test_wiadomosci_allegro import sesja as sesja_wiadomosci
from tests.integration.test_zamowienia_allegro import API, Czas, sesja
from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.kanaly.wiadomosci_allegro import WiadomosciAllegroAPI
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.przypadki_uzycia.wiadomosci_allegro import OdczytajWiadomosciAllegro
from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro


def test_zamowienia_w_allegro_bez_osobnej_pozycji_i_zachowane_filtry(qtbot, tmp_path):
    repo = CennikiSQLite(tmp_path / "db.sqlite3")
    transport = Transport({"threads": [watek()], "offset": 0, "limit": 20})
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "p.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
        allegro=Serwis(),
        wiadomosci=OdczytajWiadomosciAllegro(WiadomosciAllegroAPI(transport), Czas()),
        zamowienia=OdczytajZamowieniaAllegro(API(), Czas()),
    )
    qtbot.addWidget(w, before_close_func=lambda _: qtbot.waitUntil(lambda: not w._zadania))
    w.show()
    qtbot.waitUntil(lambda: not w._zadania and w._katalog_wczytany)
    w.strona_allegro.sesja = sesja()
    assert "Zamówienia" not in w.przyciski_menu and "Zamówienia" not in w.strony
    tabs = w.allegro_podmenu
    assert [tabs.tabText(i) for i in range(tabs.count())] == ["Oferty", "Zamówienia", "Wiadomości"]
    w.przejdz("Zamówienia")
    assert w.stos.currentWidget() is tabs and tabs.currentWidget() is w.strona_zamowien
    assert w.przyciski_menu["Allegro"].isChecked()
    w.strona_zamowien.pobierz.click()
    qtbot.waitUntil(lambda: not w._zadania)
    assert w.strona_zamowien.model.rowCount() == 2
    w.strona_zamowien.szukaj.setText("00123")
    report = w.strona_zamowien.raport
    tabs.setCurrentIndex(0)
    tabs.setCurrentIndex(1)
    assert w.strona_zamowien.raport is report and w.strona_zamowien.szukaj.text() == "00123"
    assert not w._zadania
    w.przejdz("Allegro")
    assert tabs.currentIndex() == 0
    choice = w.wybor_odswiezania_zamowien
    choice.setCurrentIndex(choice.findData(30))
    assert w.powloka.preferencje.odswiezanie_zamowien_minuty == 30
    assert w.strona_zamowien.auto.interval() == 1_800_000
    choice.setCurrentIndex(choice.findData(0))
    assert not w.strona_zamowien.auto.isActive()
    choice.setCurrentIndex(choice.findData(5))
    assert w.strona_zamowien.auto.interval() == 300_000
    assert w.strona_zamowien.auto.isActive()
    assert not transport.calls
    tabs.setCurrentIndex(2)
    assert not transport.calls
    assert "Odczyt wiadomości" in w.strona_wiadomosci.stan.text()
    w.strona_allegro.sesja = sesja_wiadomosci()
    tabs.setCurrentIndex(0)
    tabs.setCurrentIndex(2)
    qtbot.waitUntil(lambda: not w._zadania)
    assert len(transport.calls) == 1 and w.strona_wiadomosci.lista.count() == 1
    tabs.setCurrentIndex(1)
    tabs.setCurrentIndex(2)
    assert len(transport.calls) == 1
    w.strona_allegro.sesja = None
    w.strona_wiadomosci.polaczenie()
    assert w.strona_wiadomosci.lista.count() == 0
    assert not w.strona_wiadomosci.odswiez.isEnabled()
    w.close()
