import pytest
from PySide6.QtCore import QEvent, QMimeData, QPointF, Qt, QUrl
from PySide6.QtGui import QDrag, QDragEnterEvent, QDropEvent, QMouseEvent
from PySide6.QtWidgets import QApplication, QMessageBox, QTabWidget

from tests.gui.test_edytor_opisu import dane
from tests.gui.test_nowe_szkice_allegro import wykonaj
from tests.gui.test_podglad_oferty import png
from tests.gui.test_reczna_oferta import setup, wypelnij
from vexlab.gui.edytor_opisu import MIME_ZDJECIA, TekstWizualny
from vexlab.gui.opis_na_stronie import OpisNaStronie
from vexlab.gui.podglad_oferty import ObrazPodgladu
from vexlab.gui.przeciaganie_ofert import (
    MIME_SEKCJI,
    StrefaUpuszczania,
    UchwytSekcji,
    odczytaj_drop,
)


def drop(target, mime, y=10, action=Qt.DropAction.CopyAction):
    enter = QDragEnterEvent(
        QPointF(10, y), action, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier
    )
    QApplication.sendEvent(target, enter)
    assert enter.isAccepted()
    event = QDropEvent(
        QPointF(10, y), action, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier
    )
    QApplication.sendEvent(target, event)
    assert event.isAccepted()


def test_formularz_bez_zakladek_i_brak_przepisywania_przy_otwarciu(qtbot, tmp_path):
    d, jobs, service, _ = setup(qtbot, tmp_path)
    assert d.findChild(QTabWidget) is None
    original = dane()
    editor = OpisNaStronie(original, d, None, lambda *a: jobs.append(a))
    assert editor.opis() == original.opis and editor.wynik_sekcji() == original.sekcje
    assert not editor.zmieniony and not service.lista()
    d.reject()


def test_drag_sekcji_zmienia_kolejnosc_bez_gubienia_tekstu_i_zapisuje(qtbot, tmp_path, monkeypatch):
    d, jobs, service, _ = setup(qtbot, tmp_path)
    wypelnij(d)
    editor = d.opis
    editor.dodaj(("tekst",))
    editor.karty[1].findChild(TekstWizualny).setPlainText("Drugi opis")
    source, target = editor.karty
    captured = []

    def drag_exec(drag, *args):
        captured.append(bytes(drag.mimeData().data(MIME_SEKCJI).data()))
        return Qt.DropAction.MoveAction

    monkeypatch.setattr(QDrag, "exec", drag_exec)
    handle = source.findChild(UchwytSekcji)
    QApplication.sendEvent(
        handle,
        QMouseEvent(
            QEvent.Type.MouseButtonPress,
            QPointF(1, 1),
            QPointF(1, 1),
            Qt.MouseButton.LeftButton,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
        ),
    )
    QApplication.sendEvent(
        handle,
        QMouseEvent(
            QEvent.Type.MouseMove,
            QPointF(30, 30),
            QPointF(30, 30),
            Qt.MouseButton.NoButton,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
        ),
    )
    assert captured == [source.ident.encode()]
    mime = QMimeData()
    mime.setData(MIME_SEKCJI, captured[0])
    drop(target, mime, y=target.height() - 2, action=Qt.DropAction.MoveAction)
    assert editor.karty == [target, source]
    d.zapisz(False)
    wykonaj(jobs)
    row = service.lista()[0]
    assert "Drugi opis" in row.oferta.sekcje[0][0].tekst
    assert "Pełny opis" in row.oferta.sekcje[1][0].tekst


def test_drop_pliku_do_galerii_i_zdjecia_z_galerii_do_opisu(qtbot, tmp_path, monkeypatch):
    d, jobs, service, _ = setup(qtbot, tmp_path)
    wypelnij(d)
    source = tmp_path / "obraz.png"
    source.write_bytes(png())
    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(source))])
    gallery = next(
        w
        for w in d.findChildren(StrefaUpuszczania)
        if w.accessibleName() == "Przeciągnij zdjęcia z dysku do oferty"
    )
    drop(gallery, mime)
    assert d.trwa
    wykonaj(jobs)
    assert len(d.lokalne) == 1
    mini = d.pola_miniatur.findChild(ObrazPodgladu)
    assert mini.size().width() == mini.size().height() == 64
    captured = []

    def drag_exec(drag, *args):
        captured.append(bytes(drag.mimeData().data(MIME_ZDJECIA).data()))
        return Qt.DropAction.CopyAction

    monkeypatch.setattr(QDrag, "exec", drag_exec)
    QApplication.sendEvent(
        mini,
        QMouseEvent(
            QEvent.Type.MouseButtonPress,
            QPointF(1, 1),
            QPointF(1, 1),
            Qt.MouseButton.LeftButton,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
        ),
    )
    QApplication.sendEvent(
        mini,
        QMouseEvent(
            QEvent.Type.MouseMove,
            QPointF(30, 30),
            QPointF(30, 30),
            Qt.MouseButton.NoButton,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
        ),
    )
    assert captured == [d.lokalne[0].encode()]
    picture = QMimeData()
    picture.setData(MIME_ZDJECIA, captured[0])
    drop(d.opis.karty[0], picture)
    assert d.opis.sekcje()[1][0].adres == d.lokalne[0]
    assert "Pełny opis" in d.opis.sekcje()[0][0].tekst
    d.zapisz(False)
    wykonaj(jobs)
    assert service.lista()[0].oferta.sekcje[1][0].adres == d.lokalne[0]


def test_drop_pliku_bezposrednio_w_opis_i_anulowanie_nie_zapisuje_szkicu(qtbot, tmp_path):
    d, jobs, service, _ = setup(qtbot, tmp_path)
    source = tmp_path / "test.png"
    source.write_bytes(png())
    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(source))])
    drop(d.opis.karty[0], mime)
    wykonaj(jobs)
    assert len(d.opis.sekcje()) == 1 and d.opis.sekcje()[0][0].typ == "obraz"
    d.reject()
    assert not service.lista() and source.exists()


def test_zmiana_ukladu_wymaga_zgody_na_usuniecie_tekstu(qtbot, tmp_path, monkeypatch):
    d, jobs, _, _ = setup(qtbot, tmp_path)
    wypelnij(d)
    card = d.opis.karty[0]
    previous = card.elementy
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    card.uklad.setCurrentIndex(1)
    card.zmien_uklad()
    assert card.elementy == previous
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    card.uklad.setCurrentIndex(1)
    card.zmien_uklad()
    assert tuple(e.typ for e in card.elementy) == ("obraz",)
    d.reject()


def test_glowne_zdjecie_i_usuwanie_nie_kasuja_sekcji(qtbot, tmp_path):
    d, _, _, _ = setup(qtbot, tmp_path)
    first, second = "https://images.example.org/1.jpg", "https://images.example.org/2.jpg"
    d.galeria.setPlainText(first + "\n" + second)
    d.opis.dodaj_zdjecie(first)
    d.glowne_zdjecie(second)
    assert d._adresy() == (second, first)
    d.usun_zdjecie(first)
    assert d._adresy() == (second,)
    assert d.opis.sekcje()[-1][0].adres == first
    d.reject()


@pytest.mark.parametrize("url", ["https://example.org/test.png", "file:///tmp/test.txt"])
def test_obce_drop_nie_sa_zdjeciami_z_dysku(url):
    mime = QMimeData()
    mime.setUrls([QUrl(url)])
    assert odczytaj_drop(mime) is None


def test_dwa_pliki_wypelniaja_uklad_dwoch_zdjec_we_wlasciwej_kolejnosci(qtbot, tmp_path):
    from PySide6.QtGui import QImage

    d, jobs, service, _ = setup(qtbot, tmp_path)
    wypelnij(d)
    a, b = tmp_path / "a.png", tmp_path / "b.png"
    a.write_bytes(png())
    image = QImage.fromData(png())
    image.fill(Qt.GlobalColor.red)
    assert image.save(str(b))
    d.opis.dodaj(("obraz", "obraz"))
    card = d.opis.karty[-1]
    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(a)), QUrl.fromLocalFile(str(b))])
    drop(card, mime)
    wykonaj(jobs)
    assert len(d.opis.karty) == 2
    assert tuple(e.adres for e in card.elementy) == d.lokalne
    d.zapisz(False)
    wykonaj(jobs)
    assert tuple(e.adres for e in service.lista()[0].oferta.sekcje[1]) == d.lokalne


def test_formatowanie_i_uklad_tekst_zdjecie_zachowuje_tresc(qtbot, tmp_path):
    from PySide6.QtWidgets import QToolButton

    d, _, _, _ = setup(qtbot, tmp_path)
    wypelnij(d)
    card = d.opis.karty[0]
    text = card.findChild(TekstWizualny)
    text.selectAll()
    next(b for b in card.findChildren(QToolButton) if b.accessibleName() == "Pogrubienie").click()
    assert "<b>" in card.elementy[0].tekst
    card.uklad.setCurrentIndex(2)
    card.zmien_uklad()
    assert "<b>" in card.elementy[0].tekst
    url = "https://images.example.org/test.jpg"
    d.galeria.setPlainText(url)
    mime = QMimeData()
    mime.setData(MIME_ZDJECIA, url.encode())
    drop(card, mime)
    assert len(d.opis.karty) == 1
    assert card.elementy[1].adres == url
    assert "<b>" in d.opis.opis()
    d.reject()


def test_drop_pliku_zadany_jako_move_nie_pozwala_przeniesc_oryginalu(qtbot, tmp_path):
    d, jobs, _, _ = setup(qtbot, tmp_path)
    source = tmp_path / "oryginal.png"
    source.write_bytes(png())
    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(source))])
    target = d.opis.karty[0]
    actions = Qt.DropAction.MoveAction | Qt.DropAction.CopyAction
    enter = QDragEnterEvent(
        QPointF(10, 10), actions, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.ShiftModifier
    )
    QApplication.sendEvent(target, enter)
    event = QDropEvent(
        QPointF(10, 10), actions, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.ShiftModifier
    )
    event.setDropAction(Qt.DropAction.MoveAction)
    QApplication.sendEvent(target, event)
    assert event.isAccepted() and event.dropAction() == Qt.DropAction.CopyAction
    wykonaj(jobs)
    assert source.exists()
    d.reject()
