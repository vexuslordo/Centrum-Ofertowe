from tests.gui import test_profile_cennikow as profile
from tests.gui.test_profile_cennikow import czekaj, wczytaj
from vexlab.przypadki_uzycia.importowanie import Mapowanie, MapowaniePolaCennika
from vexlab.przypadki_uzycia.profile_cennikow import DopasowanieCennika

okno = profile.okno


def test_wlasne_pola_w_podgladzie_i_zapisanym_cenniku(qtbot, okno, tmp_path, monkeypatch):
    wczytaj(
        qtbot,
        okno,
        tmp_path,
        monkeypatch,
        tekst="Nazwa;SKU;Seria;Pojazd\nOsobna nazwa;A;Model X;Motocykl Y\n",
    )
    p = okno.strona_importu
    pola = (MapowaniePolaCennika("Model wydechu", 2), MapowaniePolaCennika("Motocykl", 3))
    p.zastosuj_mape(DopasowanieCennika(0, Mapowanie(1, 0, 1, pola_cennika=pola)))
    assert p.pola_cennika.isVisible() and p.mapowanie().pola_cennika == pola
    p.zaplanuj()
    czekaj(qtbot, okno)
    assert p.wyniki.horizontalHeaderItem(9).text() == "Model wydechu"
    assert p.wyniki.item(0, 9).text() == "Model X"
    assert p.wyniki.item(0, 10).text() == "Motocykl Y"
    b = okno.cenniki
    b.zapisz("Wydechy użytkownika", 2026, "", p.oceny)
    c = b.lista()[0]
    okno.strona_cennikow.cennik = c
    # Actual cennik rendering uses stored metadata as dynamic columns.
    przeglad = okno.strona_cennikow.przeglad
    page = przeglad.strona(c, przeglad.przygotuj(c), "", "", 0, 100)
    okno.strona_cennikow.pozycje = page.pozycje
    okno.strona_cennikow._renderuj(page)
    qtbot.waitUntil(lambda: okno.strona_cennikow.wiersze.isEnabled())
    assert okno.strona_cennikow.wiersze.horizontalHeaderItem(8).text() == "Model wydechu"
    assert okno.strona_cennikow.wiersze.item(0, 9).text() == "Motocykl Y"
