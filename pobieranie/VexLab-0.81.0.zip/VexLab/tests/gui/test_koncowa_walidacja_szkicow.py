"""Edycja robocza nie sprawdza paczki; metadane nie uprawniają do POST."""

from dataclasses import replace

from PySide6.QtWidgets import QDialog, QLineEdit

from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from vexlab.przypadki_uzycia.nowe_szkice_allegro import WynikTworzenia


def test_zmiany_robocze_nie_wyzwalaja_sprawdzania_i_blokuja_wysylke(
    qtbot, nowe_produkty_fixture, monkeypatch
):
    service, api, _, _, offer, _ = nowe_produkty_fixture
    calls = []
    original = service.przygotuj

    def prepare(*args):
        calls.append(args[1].sku)
        return original(*args)

    monkeypatch.setattr(service, "przygotuj", prepare)
    w, jobs = panel(qtbot, nowe_produkty_fixture, (offer, replace(offer, sku="DRUGI")))
    assert not jobs and not w.wyniki
    w.przygotuj()
    wykonaj(jobs)
    assert calls == [offer.sku, "DRUGI"] and w.utworz_przycisk.isEnabled()
    before = len(jobs)
    w.ilosc.setValue(20)
    w.waluta.setCurrentIndex(w.waluta.findData("EUR"))
    w.kompletny.setChecked(True)
    w._zastosuj_kategorie(0, "123", False)
    assert len(jobs) == before and calls == [offer.sku, "DRUGI"]
    assert not w.plany and not w.utworz_przycisk.isEnabled()
    assert all(r.stan == "Nie sprawdzono" for r in w.wyniki)
    w.tworz()
    assert len(jobs) == before and "POST" not in api.calls
    w.przygotuj()
    wykonaj(jobs)
    assert calls == [offer.sku, "DRUGI", offer.sku, "DRUGI"]


def test_parametry_nowego_produktu_przed_pierwsza_walidacja_tylko_metadane(
    qtbot, nowe_produkty_fixture, monkeypatch
):
    service, api, _, _, offer, _ = nowe_produkty_fixture
    w, jobs = panel(qtbot, nowe_produkty_fixture, (offer, replace(offer, sku="DRUGI")))
    opened = []

    def no_validation(*args):
        raise AssertionError("Edycja nie może sprawdzać paczki")

    monkeypatch.setattr(service, "przygotuj", no_validation)

    def edit(d):
        opened.append(d.windowTitle())
        d.findChild(QLineEdit, "cena_szkicu").setText("123.45")
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", edit)
    w.tabela.selectRow(0)
    w.uzupelnij()
    assert w.trwa and not opened
    wykonaj(jobs)
    assert len(opened) == 1 and api.calls.count("nowy") == 1
    assert w._ustawienia(0).cena == "123.45" and not w.plany
    assert not w.utworz_przycisk.isEnabled() and "POST" not in api.calls
    w.uzupelnij()
    assert len(opened) == 2 and len(jobs) == 1  # Cache kategorii, nie kolejna walidacja.
    w._zastosuj_kategorie(0, "456", False)
    w.uzupelnij()
    wykonaj(jobs)
    assert api.calls.count("nowy") == 2 and not w.plany


def test_metadane_nie_otwieraja_formularza_dla_innego_wiersza(
    qtbot, nowe_produkty_fixture, monkeypatch
):
    offer = nowe_produkty_fixture[4]
    w, jobs = panel(qtbot, nowe_produkty_fixture, (offer, replace(offer, sku="DRUGI")))
    opened = []
    monkeypatch.setattr(QDialog, "exec", lambda d: opened.append(d) or QDialog.DialogCode.Rejected)
    w.tabela.selectRow(0)
    w.uzupelnij()
    w.tabela.selectRow(1)
    wykonaj(jobs)
    assert not opened and not w.plany and "Wybierz ponownie" in w.info.text()


def test_zmiana_konta_odrzuca_wynik_pobierania_metadanych(qtbot, nowe_produkty_fixture):
    w, jobs = panel(qtbot, nowe_produkty_fixture)
    w.tabela.selectRow(0)
    w.uzupelnij()
    work, success, _ = jobs[-1]
    result = work()
    w.zmiana_sesji()
    success(result)
    assert not w.metadane_edycji.produkty and not w.plany
    assert not w.utworz_przycisk.isEnabled()


def test_edycja_innego_wiersza_zachowuje_odrzucenie_i_niepewny_wynik(qtbot, nowe_szkice_fixture):
    offer = nowe_szkice_fixture[4]
    w, jobs = panel(qtbot, nowe_szkice_fixture, tuple(replace(offer, sku=str(i)) for i in range(3)))
    w.przygotuj()
    wykonaj(jobs)
    rejected = WynikTworzenia("0", "Odrzucono", "Popraw parametr")
    unknown = WynikTworzenia("1", "Wynik nieznany", "Sprawdź wynik", "123")
    w.wyniki = (rejected, unknown, w.wyniki[2])
    w._uniewaznij_wiersze((2,))
    assert w.wyniki[:2] == (rejected, unknown)
    w.przygotuj()
    wykonaj(jobs)
    assert w.wyniki[:2] == (rejected, unknown)
    assert not w._mozna_wyslac(0) and not w._mozna_wyslac(1)


def test_vat_nowej_kategorii_dostepny_bez_sprawdzania_paczki(
    qtbot, nowe_produkty_fixture, monkeypatch
):
    from vexlab.gui import nowe_szkice_allegro as gui

    w, jobs = panel(qtbot, nowe_produkty_fixture)
    categories = []

    class VAT:
        wynik = ()

        def __init__(self, parent, category, *args, **kwargs):
            categories.append(category)

        def exec(self):
            return QDialog.DialogCode.Accepted

    monkeypatch.setattr(gui, "VATAllegro", VAT)
    w.ustaw_vat()
    assert categories == ["123"] and not jobs and not w.plany
