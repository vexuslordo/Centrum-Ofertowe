from dataclasses import replace

from PySide6.QtCore import QBuffer, QIODevice
from PySide6.QtGui import QImage

from tests.integration.test_zamowienia_allegro import API, Czas, raw, sesja
from vexlab.gui.zamowienia_allegro import StronaZamowien
from vexlab.kanaly.zamowienia_allegro import mapuj_zamowienie
from vexlab.przypadki_uzycia.zamowienia_allegro import OdczytajZamowieniaAllegro, RaportZamowien


def test_miniatury_tylko_widoczne_z_cache_i_po_zmianie_konta_czyszczone(qtbot):
    jobs, s, calls = [], [sesja()], []
    uc = OdczytajZamowieniaAllegro(API(), Czas())
    uc.obrazy = object()  # fixture: loader only uses the presence; method below returns bytes
    image = QImage(12, 12, QImage.Format.Format_RGB32)
    image.fill(0x336699)
    buffer = QBuffer()
    buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    image.save(buffer, "PNG")

    def miniatura(session, ident):
        calls.append(ident)
        return bytes(buffer.data())

    uc.miniatura = miniatura
    w = StronaZamowien(uc, lambda *a: jobs.append(a), lambda: s[0])
    qtbot.addWidget(w)
    w.resize(1400, 700)
    w.show()
    r = mapuj_zamowienie(raw())
    r = replace(r, pozycje=(replace(r.pozycje[0], oferta_id="123"),))
    w.raport = RaportZamowien("konto", "test", "test", "od", "do", "czas", (r,))
    w.filtruj()
    w.miniatury.pobierz()
    fn, ok, error = jobs.pop(0)
    ok(fn())
    assert calls == ["123"] and w.miniatury.cache["123"] is not None
    w.miniatury.pobierz()
    assert not jobs
    s[0] = None
    w.polaczenie()
    assert not w.miniatury.cache
