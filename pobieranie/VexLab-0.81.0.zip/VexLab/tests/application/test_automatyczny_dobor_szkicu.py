from dataclasses import replace
from uuid import uuid4

import pytest

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.automatyczny_dobor_szkicu import AutomatycznyDoborSzkicu
from vexlab.przypadki_uzycia.nowe_szkice_allegro import KategoriaSzkicu


def test_istniejacy_ean_wybiera_wlasna_kategorie_i_nie_wysyla_definicji(nowe_produkty_fixture):
    service, api, _, session, offer, settings = nowe_produkty_fixture
    api.produkt = replace(api.produkt, kategoria="789")
    plan = AutomatycznyDoborSzkicu(service).przygotuj(session, offer, settings)
    assert not plan.bledy and not plan.ustawienia.nowy
    assert plan.produkt.kategoria == "789" and plan.ustawienia.produkt == api.produkt.id
    assert plan.ustawienia.automatyczny and not plan.ustawienia.zrodla
    assert "kod" not in dict(plan.ustawienia.wartosci)
    assert "POST" not in api.calls


def test_brak_produktu_przygotowuje_nowe_rozne_kategorie_per_sku(nowe_produkty_fixture):
    service, api, _, session, offer, settings = nowe_produkty_fixture
    api.znajdz_produkty = lambda *a: ()
    api.kategorie = lambda s, title: (
        KategoriaSzkicu("123" if "ekran" in title else "456", "Części"),
    )
    resolver = AutomatycznyDoborSzkicu(service)
    first = resolver.przygotuj(session, replace(offer, tytul="Uchwyt na ekran motocykla"), settings)
    second = resolver.przygotuj(
        session, replace(offer, sku="DRUGI", tytul="Osłona silnika motocykla", cena="999"), settings
    )
    assert not first.bledy and not second.bledy
    assert first.ustawienia.kategoria == "123" and second.ustawienia.kategoria == "456"
    assert first.ustawienia.nowy and second.ustawienia.nowy
    assert dict(second.ustawienia.wartosci)["kod"] == "DRUGI"
    assert second.oferta.cena == "999" and "POST" not in api.calls


@pytest.mark.parametrize("wariant", ["produkty", "kategorie", "brak_kategorii"])
def test_niejednoznacznosc_pozostawia_wiersz_do_wyboru(nowe_produkty_fixture, wariant):
    service, api, _, session, offer, settings = nowe_produkty_fixture
    api.znajdz_produkty = lambda *a: (
        (api.produkt, replace(api.produkt, id=str(uuid4()))) if wariant == "produkty" else ()
    )
    api.kategorie = lambda *a: (
        ()
        if wariant == "brak_kategorii"
        else (KategoriaSzkicu("123", "Pierwsza"), KategoriaSzkicu("456", "Druga"))
    )
    plan = AutomatycznyDoborSzkicu(service).przygotuj(session, offer, settings)
    assert plan.bledy and plan.produkt is None and "ręcznie" in plan.bledy[0]
    assert "POST" not in api.calls


def test_inna_kategoria_nie_przenosi_obcych_parametrow(nowe_produkty_fixture):
    service, api, _, session, offer, settings = nowe_produkty_fixture
    settings = replace(settings, wartosci=(("nieznany", "zła wartość"), ("11323", "nieznany-stan")))
    plan = AutomatycznyDoborSzkicu(service).przygotuj(session, offer, settings)
    assert plan.bledy
    assert "nieznany" not in dict(plan.ustawienia.wartosci)
    assert "11323" not in dict(plan.ustawienia.wartosci)
    assert "POST" not in api.calls


def test_blad_globalnego_polaczenia_nie_jest_zgadywanym_brakiem_produktu(nowe_produkty_fixture):
    service, api, _, session, offer, settings = nowe_produkty_fixture

    def blad(*a):
        raise BladAllegro("SIEC", "Przerwane połączenie")

    api.znajdz_produkty = blad
    with pytest.raises(BladAllegro, match="Przerwane"):
        AutomatycznyDoborSzkicu(service).przygotuj(session, offer, settings)
    assert "POST" not in api.calls


def test_zapisana_proba_nie_zmienia_doboru_nawet_gdy_produkt_juz_jest_w_katalogu(
    nowe_produkty_fixture,
):
    service, api, _, session, offer, settings = nowe_produkty_fixture
    plan = service.przygotuj(session, offer, settings)
    service.utworz(session, plan, lambda: False)

    def bez_doboru(*a):
        raise AssertionError("Zapisanej próby nie wolno automatycznie przekierować")

    api.znajdz_produkty = bez_doboru
    refreshed = AutomatycznyDoborSzkicu(service).przygotuj(
        session, offer, replace(settings, automatyczny=True)
    )
    assert refreshed.ustawienia.nowy and api.calls.count("POST") == 1
