"""Kolejność, odrzucenia i blokady testujemy bez Qt i prawdziwych żądań API."""

from dataclasses import replace

import pytest

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.duplikaty_allegro import SprawdzDuplikatyAllegro
from vexlab.przypadki_uzycia.seria_szkicow_allegro import (
    WyslijSerieSzkicow,
)


def test_odrzucenie_jednej_oferty_nie_zatrzymuje_nastepnych(seria_szkicow_fixture):
    service, api, _, request, observer = seria_szkicow_fixture
    original = api.utworz_szkic

    def reject(s, data):
        if data["external"]["id"] == "DRUGI":
            api.calls.append("POST")
            raise BladAllegro("ODRZUCONO", "HTTP 422. Brak parametru wybranej oferty.")
        return original(s, data)

    api.utworz_szkic = reject
    results = WyslijSerieSzkicow(service, None, None).wykonaj(request, observer)
    assert [w.stan for w in results] == ["Utworzono szkic", "Odrzucono", "Utworzono szkic"]
    assert api.calls.count("POST") == 3
    assert service.rejestr.odczytaj(service.klucz(request.sesja, "DRUGI")) is None


def test_niepotwierdzony_odczyt_jednego_sku_pozostaje_zablokowany_a_reszta_idzie_dalej(
    seria_szkicow_fixture,
):
    service, api, registry, request, observer = seria_szkicow_fixture
    api.awaria = "timeout"
    with pytest.raises(BladAllegro):
        service.utworz(request.sesja, request.plany[0], observer.stop)
    saved = registry.odczytaj(service.klucz(request.sesja, "PIERWSZY"))
    api.awaria = ""
    api.wyniki.clear()
    before = api.calls.count("POST")
    uc = WyslijSerieSzkicow(service, None, None)
    results = uc.wykonaj(request, observer)
    assert results[0].stan == "Wynik nieznany"
    assert all(w.stan == "Utworzono szkic" for w in results[1:])
    assert api.calls.count("POST") == before + 2
    assert registry.odczytaj(service.klucz(request.sesja, "PIERWSZY")) == saved
    uc.wykonaj(replace(request, poprzednie=results, sprawdzenie=True), observer)
    assert api.calls.count("POST") == before + 2


def test_blad_zdjecia_jednej_oferty_nie_blokuje_innych(seria_szkicow_fixture):
    service, api, _, request, observer = seria_szkicow_fixture
    first = replace(
        request.plany[0],
        oferta=replace(
            request.plany[0].oferta, zdjecia=("https://images.example.org/bad.jpg",), sekcje=()
        ),
    )
    request = replace(request, plany=(first, *request.plany[1:]))
    original = api.wyslij_zdjecie

    def upload(s, url):
        if url.endswith("bad.jpg"):
            raise BladAllegro("ZDJECIE", "Nieprawidłowe zdjęcie tej oferty.")
        return original(s, url)

    api.wyslij_zdjecie = upload
    results = WyslijSerieSzkicow(service, None, None).wykonaj(request, observer)
    assert [w.stan for w in results] == ["Do poprawy", "Utworzono szkic", "Utworzono szkic"]
    assert api.calls.count("POST") == 2


@pytest.mark.parametrize(
    "code,message",
    [
        ("AUTORYZACJA", "Brak autoryzacji"),
        ("SIEC", "Przerwane połączenie"),
        ("NIEZNANY", "Brak odpowiedzi POST"),
        ("REJESTR", "Brak trwałego dziennika"),
        ("ODRZUCONO", "HTTP 429. Limit konta"),
        ("ODCZYT", "HTTP 503. Awaria Allegro"),
    ],
)
def test_wspolny_problem_wstrzymuje_dalsze_post(seria_szkicow_fixture, code, message):
    service, api, _, request, observer = seria_szkicow_fixture

    def fail(*a):
        raise BladAllegro(code, message)

    api.wyslij_zdjecie = fail
    results = WyslijSerieSzkicow(service, None, None).wykonaj(request, observer)
    assert [w.stan for w in results[1:]] == ["Wstrzymano", "Wstrzymano"]
    assert all(message in w.komunikat for w in results)
    assert "POST" not in api.calls


def test_problem_kontroli_duplikatu_dotyczy_tylko_tego_sku(seria_szkicow_fixture):
    service, api, _, request, observer = seria_szkicow_fixture

    class Candidates:
        def kandydaci_duplikatow(self, s, field, value):
            if value == "PIERWSZY":
                raise BladAllegro("ODCZYT", "HTTP 404. Nie udało się odczytać kandydata.")
            return ()

    uc = WyslijSerieSzkicow(service, None, SprawdzDuplikatyAllegro(Candidates()))
    results = uc.wykonaj(request, observer)
    assert results[0].stan == "Wymaga sprawdzenia"
    assert all(w.stan == "Utworzono szkic" for w in results[1:])
    assert api.calls.count("POST") == 2


def test_postep_wysylki_liczy_zakonczone_pozycje_i_zachowuje_wyniki(seria_szkicow_fixture):
    service, api, _, request, observer = seria_szkicow_fixture
    progress = []
    observer = replace(observer, postep_etapu=lambda *args: progress.append(args))
    result = WyslijSerieSzkicow(service, None, None).wykonaj(request, observer)
    assert progress == [("Wysyłka szkiców Allegro", i, 3) for i in range(4)]
    assert len(result) == 3 and api.calls.count("POST") == 3


def test_postep_katalogu_liczy_tylko_wybrane_plany(seria_szkicow_fixture):
    service, _, _, request, observer = seria_szkicow_fixture
    progress = []
    observer = replace(observer, postep_etapu=lambda *args: progress.append(args))

    class Katalog:
        def z_ofert_czesciowo(self, plany, producent, stop, postep):
            for i, plan in enumerate(plany):
                postep(i + 1, plan.oferta.sku)
            return None, ()

    uc = WyslijSerieSzkicow(service, Katalog(), None)
    uc._katalog(replace(request, do_utworzenia=frozenset({0, 2})), observer)
    assert progress == [("Katalog lokalny", i, 2) for i in range(3)]


def test_seria_pokazuje_istniejacy_szkic_bez_oznaczania_zgodnosci_danych(seria_szkicow_fixture):
    service, api, _, request, observer = seria_szkicow_fixture
    original = api.utworz_szkic

    def zmieniony_odczyt(session, dane):
        result = original(session, dane)
        api.wyniki[dane["external"]["id"]]["name"] = "Inny tytuł"
        return result

    api.utworz_szkic = zmieniony_odczyt
    results = WyslijSerieSzkicow(service, None, None).wykonaj(request, observer)
    assert all(w.stan == "Wymaga sprawdzenia" and w.odczytany_szkic and w.ident for w in results)
    assert all("tytuł" in w.komunikat for w in results)
    WyslijSerieSzkicow(service, None, None).wykonaj(request, observer)
    assert api.calls.count("POST") == 3
