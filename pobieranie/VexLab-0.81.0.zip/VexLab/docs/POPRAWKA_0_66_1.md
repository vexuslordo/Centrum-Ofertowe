# VexLab 0.66.1 — mniejsza paczka bez zrzutów ekranu

Na polecenie właściciela domyślny ZIP nie zawiera docs/screenshots.
Obraz referencyjny assets/UI_REFERENCE.png pozostaje, tak samo logo, ikony,
kod, testy, tekstowa dokumentacja i funkcje programu. Dane użytkownika
nie są zmieniane. Archiwalne zrzuty zachowano w roboczych źródłach.

Pełną paczkę dokumentacyjną można zbudować przez:

    python scripts/package_source.py --output VexLab-pelny.zip --include-screenshots

Odnośniki do obrazków dokumentacyjnych w lekkiej paczce nie mają załączników;
te obrazki nie są wymagane do uruchomienia programu.
