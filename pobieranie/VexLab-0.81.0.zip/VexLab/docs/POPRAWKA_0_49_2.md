# VexLab 0.49.2 — postęp importu produktów Allegro

Pod tabelą jest pasek postępu i bieżący licznik pobranych ofert, np. **Pobrano ofert: 1200 z 13579 · 8%**.
Przed pierwszą odpowiedzią pasek jest animowany. Po każdej stronie listy aktualizuje liczbę i procent.
Podgląd pokazuje liczbę sprawdzonych ofert, a przygotowanie zdjęć — liczbę pozycji przygotowanych do zapisu.
Po ukończeniu pasek pokazuje 100%, a komunikat podaje pobrane oferty lub liczbę zapisanych powiązań, nowo dodanych produktów i łączną liczbę zapisanych ofert z tej listy.

Zatrzymanie lub błąd zachowuje ostatni odebrany licznik. Nie oznacza zakończenia sukcesem i nie zapisuje częściowo pobranej listy.
Bez zmian schematu bazy, danych użytkownika, wielkości partii i zasad publikacji.
