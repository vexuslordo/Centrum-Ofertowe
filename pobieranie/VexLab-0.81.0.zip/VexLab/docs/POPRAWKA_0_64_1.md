# VexLab 0.64.1 — czytelne porównanie cen

Cena Allegro poniżej ceny z cennika: czerwone kwoty i wynik „Za niska cena”.
Równa cena: zielone kwoty i „Cena zgodna”. Wyższa cena: pomarańczowe kwoty
oraz „Cena wyższa”. Pozostałe wyniki mają spokojny kolor i zachowują konkretny
powód. Kolory działają w jasnym i ciemnym motywie, a tekst pozwala rozróżnić
wyniki bez rozpoznawania kolorów. Legenda znajduje się nad tabelą.

Różnica nadal oznacza cenę z cennika minus cenę Allegro. Filtry i eksport
zachowują wyniki źródłowego porównania. Widok nie zmienia cen w Allegro.
