# VexLab 0.57.1 — rozszerzenie przygotowania Allegro na ekran

Okno Przygotuj oferty Allegro ma natywny przycisk maksymalizacji obok
zamknięcia. Można też dwukrotnie kliknąć pasek tytułu Windows. Ponowne
kliknięcie przywraca poprzedni rozmiar. Tabela korzysta z dodatkowej przestrzeni.

Dodano WindowMaximizeButtonHint, zachowując typ Dialog, modalność i istniejące
zasady zamykania podczas pracy. Brak własnej imitacji paska Windows.
Zaznaczenie, producent, parametry i przebieg wysyłki pozostają w tym samym
formularzu. Brak zmian danych, migracji, tworzenia ofert lub publikacji.

Sprawdzenie: flaga natywna, maksymalizacja/przywrócenie oraz zachowanie
zaznaczenia i planu w Qt; pełne kontrole projektu. Odbiór wyglądu natywnego
przycisku Windows wymaga uruchomienia na Windows, testy wykonywane w Linux Qt.
