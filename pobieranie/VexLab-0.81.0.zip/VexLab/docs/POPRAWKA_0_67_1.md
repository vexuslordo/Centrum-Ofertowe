# VexLab 0.67.1 — poprawne uprawnienie odczytu zamówień

Poprawiono błędne scope order:read na allegro:api:orders:read (liczba mnoga),
zgodne z kontraktem GET /order/checkout-forms oraz panelem aplikacji Allegro.
Poprawka obejmuje żądanie OAuth, opcję połączenia, komunikaty i instrukcje.

W Allegro zaznacz allegro:api:orders:read i zapisz ustawienia aplikacji.
W VexLab: Ustawienia → Integracje → Allegro → Odczyt zamówień → Zmień uprawnienia.
Ponownie zatwierdź zgodę. Potem Sprzedaż → Zamówienia → Pobierz.
Dane użytkownika, zapisane cenniki, profile i dotychczasowe funkcje bez zmian.
