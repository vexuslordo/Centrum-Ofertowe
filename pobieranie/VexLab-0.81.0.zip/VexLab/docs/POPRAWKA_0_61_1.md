# Poprawka 0.61.1 — PrestaShop w Integracjach

Na polecenie właściciela formularz adresu, maskowanego klucza Webservice,
sprawdzania, zapamiętywania i usuwania połączenia znajduje się bezpośrednio
w Ustawienia → Integracje → PrestaShop. Główna zakładka ma przycisk prowadzący
od razu do tego formularza, tak jak Allegro.

Główny widok korzysta ze wspólnego wyglądu Allegro: logo, nagłówek, stan
połączenia, czas odczytu, kolorowe kafelki oraz tabela i panel szczegółów.
Kafelki pokazują rzeczywiste dane odczytu kategorii, sklepu i języka.
Przed odczytem wyświetlają —, po odczycie pustej listy 0.

Zachowano wybór sklepu, języka i kategorii, wyszukiwanie, pracę w tle oraz
szyfrowane ustawienia użytkownika Windows. Bez zmian schematu danych,
modelu domenowego, obsługi Webservice i zakresu uprawnień. Ten etap nadal
odczytuje kategorie; publikacja produktów jest kolejnym etapem roadmapy.

Sprawdzenie: testy GUI obu motywów, nawigacji i rzeczywistego osadzenia
formularza, liczniki po odczycie i zmianie kontekstu; pełne kontrole projektu.
Zrzuty powstają z izolowanego API syntetycznego, bez kontaktu ze sklepem.
Natywny Windows i rzeczywisty sklep nie były dostępne w tym środowisku.
