# Kopiowanie danych cennika — 0.59.2

Prawy przycisk myszy w tabeli pozycji: „Kopiuj wartość komórki”,
„Kopiuj SKU”, „Kopiuj EAN”. Kopiowana pełna wartość z klikniętego wiersza,
nie ucięty wizualnie tekst. Zera początkowe zachowane. Puste dane/brak EAN
oraz kliknięcie poza wierszami wyłączają kopiowanie. Menu otwierane
klawiaturą korzysta z bieżącej komórki. Dotychczasowy wybór wielu wierszy,
dodawanie do katalogu i zaznaczanie wszystkich zachowane. Bez zapisu
w bazie, zmian cennika, importu lub żądań API. Schemat 12 bez zmian.
