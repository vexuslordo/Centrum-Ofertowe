# Mniejsze panele przygotowania Allegro — 0.59.3

Na polecenie właściciela zmniejszono marginesy i odstępy obu paneli
przygotowania ofert oraz głównego okna. Producent lokalny z etykietą
w jednym wierszu, krótsza informacja o zapisie katalogu. Opisy objaśniające
przeniesione do podpowiedzi nagłówków. Zawartość prawego panelu wyrównana
do góry, zamiast rozciąganych odstępów. Tabela przejmuje odzyskaną przestrzeń.
Wszystkie pola i przyciski, miniatury 64×64, maksymalizacja i działanie
w tle pozostają. Bez stałej wysokości paneli: większe czcionki i komunikaty
mogą zwiększyć ich wysokość. Bez zmian danych, API lub schematu 12.
