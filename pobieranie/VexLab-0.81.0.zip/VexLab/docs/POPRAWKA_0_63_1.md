# VexLab 0.63.1 — masowo Sprawdź blokadę i ponów

Zaznacz kilka ofert w głównej tabeli (Ctrl/Shift lub Zaznacz widoczne) i wybierz
Więcej działań → Sprawdź blokadę i ponów. Możesz też otworzyć Szczegóły wysyłki,
ustawić filtr, zaznaczyć wiele wierszy lub kliknąć Zaznacz widoczne i uruchomić
tę samą akcję. Dotyczy wyłącznie jawnie zaznaczonych pozycji.

Program sprawdzi każdą ofertę w tle i pokaże jeden podgląd: ile pozycji można
odblokować i dlaczego pozostałe nie przechodzą kontroli. Po sprawdzeniu panelu
Allegro zaznacz zgodę i potwierdź całą sprawdzoną grupę. Pozycje z odmową
pozostaną bez zmian. Brak oferty w odczycie nie usuwa ryzyka opóźnienia API
po nieznanym wyniku — podgląd przypomina o możliwości duplikatu.

Przed odblokowaniem nastąpi ponowna kontrola każdego wiersza i archiwizacja
jego starej próby. Zobaczysz licznik odblokowanych oraz powód dla pozostałych
w Szczegółach wysyłki. Odblokowane wrócą do walidacji. Wysyłkę nowych szkiców
zatwierdzasz później osobno; samo odblokowanie niczego nie wysyła do Allegro.
Przycisk zatrzymania działa pomiędzy pozycjami, zachowując wyniki wykonanych.

Pojedyncza akcja 0.63 nadal działa tak samo. Bez migracji i zmian katalogu,
cen, dostępności oraz ofert na kanałach. PrestaShop pozostaje odłożony.
[Decyzja](adr/ADR-089-masowe-odblokowanie-nowych-prob.md).

Testy izolowane, bez operacji na rzeczywistym koncie. Windows nie był dostępny
w środowisku sprawdzania.
