# Potwierdzone utworzenie oferty i sprawdzanie ustawień

Po potwierdzeniu przyjęcia żądania i zgodnego odczytu ID oraz treści INACTIVE
niezgodność odczytu GPSR, dostawy, warunków lub VAT nie jest już błędem
utworzenia całej oferty. Status: „Utworzono — sprawdź ustawienia”.
ID pozostaje widoczne. Szczegóły wskazują nazwy pól do sprawdzenia,
bez kopiowania danych adresowych i instrukcji bezpieczeństwa do komunikatu.

Podsumowanie Gotowe liczy potwierdzone zapisane szkice. Dodatkowy licznik
Ustawienia do sprawdzenia obejmuje utworzone szkice z taką uwagą. Wynik
nie wstrzymuje reszty serii, ale nie potwierdza kompletności do sprzedaży.
Rzeczywiste błędy walidacji Allegro nadal pokazują Szkic do poprawy.
Przycisk tworzenia nie wysyła ponownie wskazanej utworzonej pozycji;
Sprawdź wyniki wysyłki wykonuje odczyt i może usunąć uwagę po potwierdzeniu.
Trwały rejestr chroni przed ponownym POST również po restarcie.

Porównanie toleruje równoważne dni/godziny ISO, wielkość liter UUID,
CRLF/LF i NFC w informacjach bezpieczeństwa, puste opcjonalne odnośniki
zamiast null. Inne ID, inna treść i brak wymaganego pola nadal wymagają
sprawdzenia. Brak akceptacji POST lub niezgodność ID/core pozostają
nieznanym wynikiem/konfliktem. Brak migracji; schemat 12 i dane zachowane.
Nie wykonano rzeczywistych zapisów API ani odbioru natywnego Windows.
