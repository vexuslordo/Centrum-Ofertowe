# VexLab 0.64.2 — osobne kolumny cen

Porównanie cen Allegro pokazuje osobno Cennik netto i Cennik brutto, z walutą. Obie kolumny sortują się liczbowo. VAT pozostaje 23%, brutto w pełnych kwotach. Cena Allegro, różnica i kolorowa ocena pozostają obok. Obliczenia, eksport i dane użytkownika pozostają bez zmian.
