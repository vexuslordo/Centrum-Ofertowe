# VexLab 0.65.1 — zaznaczanie wszystkich ofert

W porównaniu cen przycisk Zaznacz wszystkie obejmuje cały wynik aktualnego filtra, również wiersze poza ekranem. Działa też Ctrl+A. Licznik pokazuje wielkość zaznaczenia. Przygotowanie zmiany pomija zaznaczone pozycje bez różnicy ceny; zachowany limit 500 zmian na serię z jawnym komunikatem przy przekroczeniu. Nie wysyła niczego automatycznie.
