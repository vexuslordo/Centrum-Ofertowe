# VexLab 0.49.1

Wynik wysyłki to jeden wiersz: **Gotowe: X · Do sprawdzenia: Y · Błędy: Z · Niewysłane: N · Pominięte: P**.
Gotowe oznacza potwierdzony zapis szkicu z ID Allegro (szczegóły ewentualnych poprawek w tabeli).
Do sprawdzenia oznacza brak potwierdzenia — przycisk „Sprawdź wyniki wysyłki” odczytuje wynik bez ponownego tworzenia.
Sprawdzanie paczki pokazuje „Do wysłania”, aby nie mylić przygotowanych danych z zapisanymi szkicami.

Import produktów pobiera listę Allegro po 100 ofert. Zbyt duża odpowiedź zmniejsza stronę i ponawia odczyt od tego samego miejsca. Całe konto jest nadal pobierane; limit HTTP nie jest zwiększany.

Bez zmiany bazy, danych użytkownika i zasad publikacji. Testy na syntetycznych danych, bez zapisu na koncie użytkownika.
