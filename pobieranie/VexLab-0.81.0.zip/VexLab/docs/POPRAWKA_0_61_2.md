# Poprawka 0.61.2 — niższy komunikat w edycji parametrów

Na polecenie właściciela górne pole powodu odrzucenia w oknie „Uzupełnij dane
szkicu” otrzymało stałą, kompaktową wysokość dwóch–trzech wierszy zależnie
od liczby akapitów i metryki czcionki. Przy powiększaniu okna miejsce zyskuje
formularz parametrów. Długi komunikat pozostaje dostępny przez przewijanie
i kopiowanie, bez obcinania danych. Dotyczy edycji pojedynczej i masowej.

Bez zmian danych, walidacji, powodów odrzucenia i żądań Allegro.
Sprawdzenie: istniejące testy poprawiania odrzuconych i formularza, pełne
kontrole projektu. Natywny Windows nie był dostępny do odbioru wizualnego.
