# Powody statusów ofert — 0.59.1

Na polecenie właściciela przycisk „Szczegóły wysyłki” na dole okna otwiera
osobne zestawienie. Główna tabela bez dodatkowych kolumn i paneli.
Domyślnie lista ofert wymagających uwagi, opcjonalnie wszystkie oferty;
SKU, status, konkretny powód i pełny kopiowalny opis ze wskazówką po wyborze.
Okno można rozszerzać i maksymalizować. Podgląd nie zmienia zaznaczenia
paczki i nie wysyła żadnych żądań. Dostępny po zakończeniu zadania.

Zatrzymane pozycje wskazują ofertę i błąd, który zatrzymał serię; osobne
wyjaśnienia dla anulowania i zmiany sesji. Brak zarejestrowanej próby jest
odróżniony od odrzucenia przez Allegro. Odrzucenia/walidacja korzystają
również z message, jeśli API nie zwraca userMessage, zamiast samego kodu.
Nieznany wynik nadal wymaga odczytu, bez ponownej wysyłki. Szkic do poprawy
jest już zapisany w Allegro i nie należy tworzyć go ponownie.
Schemat 12, dane użytkownika i reguły zapisu bez zmian.
