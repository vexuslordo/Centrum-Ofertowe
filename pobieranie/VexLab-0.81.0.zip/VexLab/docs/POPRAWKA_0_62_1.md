# Poprawka 0.62.1 — zwarty układ PrestaShop jak Allegro

Na polecenie właściciela: tytuł i podtytuł w jednym wierszu, stan i czas
odczytu w drugim, identyczna organizacja jak w Allegro. Mniejsze marginesy,
odstępy i pionowe wypełnienie kafelków. Sklep, język, wyszukiwanie oraz
pobieranie w jednym pasku nad tabelą. Szczegóły po prawej obejmują wysokość
całego obszaru roboczego, także paska narzędzi, jak w Allegro.

Informacja o wybranej kategorii jest w panelu szczegółów. Na dole jeden
komunikat zamiast trzech osobnych wierszy. Informacja o samym odczycie
w podpowiedzi komunikatu. Konfiguracja nadal w Integracjach.
Zachowane wszystkie funkcje, dane, API, odczyty w tle i oba motywy.
Bez migracji oraz zmian publikacji Allegro lub PrestaShop.

Sprawdzenie: istniejące testy GUI i integracji PrestaShop, pełne kontrole
projektu oraz syntetyczne podglądy obu motywów. Bez odbioru na Windows
lub operacji na rzeczywistym sklepie.
