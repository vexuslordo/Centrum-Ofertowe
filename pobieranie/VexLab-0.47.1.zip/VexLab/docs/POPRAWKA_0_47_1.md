# VexLab 0.47.1 — widoczny wybór na rozwijanych listach

Zgłoszenie właściciela: na liście producentów trudno zobaczyć wskazywaną
pozycję. Dotychczasowy tryb menu QComboBox rysował własne, bardzo słabe
podświetlenie i pomijał część stylów pozycji.

Rozwijane listy używają teraz widoku listy (`combobox-popup: 0`) ze wspólnym
stylem: wybrany wiersz ma niebieskie tło #1767B6, biały tekst i jasny lewy
akcent. Najechanie ma osobny akcent, wiersze mają większe odstępy.
Dotyczy producentów oraz pozostałych QComboBox w programie, w obu motywach.
Nie zmieniono wartości, źródeł parametrów, opcji, walidacji ani danych.
Lista nadal obsługuje klawiaturę i przewijanie, a pola edytowalne VAT
zachowują ręczne wpisywanie.

Test regresji sprawdza renderowany kolor wybranego wiersza (stary tryb menu
nie przechodzi testu), odróżnienie od pozostałych wierszy oraz zatwierdzenie
strzałką/Enter w obu motywach. Podglądy z danych syntetycznych:
[ciemny](screenshots/vexlab-wybor-0471-dark.png),
[jasny](screenshots/vexlab-wybor-0471-light.png).
Bez zmian bazy, logo, funkcji Allegro i plików użytkownika.
