# Poprawka 0.36.1 — większe, jednakowe miniatury Allegro

Polecenie właściciela 2026-11-09: większy kwadrat zdjęcia i jednakowy rozmiar.

Miniatury tabeli mają białe pola 64×64 px, kolumnę 80 px i wiersze 76 px.
Obraz jest wyśrodkowany, mieści się w polu 56×56 px i zachowuje proporcje,
bez rozciągania oraz obcinania produktu. Puste zdjęcie ma takie samo pole.
Usunięto tekstowy myślnik komórki, który był widoczny obok małej miniatury.
Wymiary pól pozostają jednakowe także po przewijaniu i zmianie strony.

Zmiana wyłącznie prezentacji: oryginalne obrazy, dane ofert, odczyt na żądanie,
cache miniatur oraz osobny pełny podgląd pozostają zachowane. Brak migracji,
nowych zależności i zapisów w Allegro.

Kontrola: 28 testów miniatur/podglądu i Allegro zaliczonych, także przy
skalowaniu 150%. Testy obejmują obraz poziomy/pionowy, proporcje, jednakowe
pola, brak zdjęcia, brak myślnika oraz używanie miniatur zamiast pełnych plików.
Mypy Windows: 94 moduły bez błędów. Ruff i formatowanie poprawne.
Paczka ZIP weryfikowana przez CRC, SHA256 i zgodność źródeł.
