# VexLab 0.6 — ceny, zaznaczanie, czyszczenie i zdjęcia

## Uzupełnij ceny już zaimportowanych produktów

Nie musisz usuwać obecnego katalogu.

1. Otwórz Cenniki i wczytaj ten sam plik źródłowy.
2. Wybierz arkusz/nagłówki, nazwę i SKU, a także kolumnę Cena sugerowana.
3. Wskaż walutę źródłową (np. GBP, EUR lub PLN) i netto/brutto.
4. Sprawdź podgląd. Istniejące SKU mają komunikat konfliktu dla zwykłego
   dodawania — nie zaznaczaj ich do ponownego dodania.
5. Kliknij Podgląd uzupełniania brakujących cen po SKU.
6. Zobacz proponowane ceny i listę pominięć. Zatwierdź wyłącznie pokazane ceny.

Program uzupełnia tylko brakujące sugerowane ceny istniejących Produktów.
Nie zmienia nazw, opisów, producentów ani wcześniej zapisanych cen.
Niejednoznaczne SKU i błędy są pomijane jawnie w podglądzie. Przed zapisem
powstaje kopia całej bazy w kopie_cen. To nie aktualizacja cen ofert Allegro/PrestaShop.

Dla przykładu Evotech możesz wybrać GBP netto + GBP + netto. Aby użyć
PLN netto/brutto z formuł, najpierw sprawdź wartości w Excelu i zaznacz
Użyj zapisanych wyników formuł ceny. VexLab nie przelicza formuł — zapisany
wynik może być starszy niż zmiana danych w arkuszu. Dla cennika EUR wybierasz
jego kolumnę i walutę EUR; program nie zmienia kwoty przez zmianę waluty.

Nowy import zapisuje tę samą opcjonalną cenę razem z nowym Produktem.
Pusta cena to brak; zero jest ceną zerową. Wartości nie są automatycznie
przeliczane na PLN, z netto na brutto ani na cenę naszej Oferty.
Tabela i szczegóły pokazują kwotę, walutę i netto/brutto jako cenę sugerowaną.
CSV z ekranu Produkty nadal ma cztery pola katalogowe, bez cen i zdjęć;
pełna kopia z Ustawień obejmuje całą bazę.

## Zaznaczanie i masowa edycja

W Produktach użyj Zaznacz wszystkie wyniki lub Ctrl+A na tabeli.
Obejmuje to cały bieżący wynik wyszukiwania/filtra, nie ukryte produkty.
Ctrl i Shift umożliwiają wybór części wierszy; Odznacz usuwa wybór.
Licznik pokazuje zakres. Odświeżenie zachowuje wybór po ID w nadal widocznych wynikach.

Zmień dane zaznaczonych otwiera formularz dla tej migawki. Możesz:

- ustawić aktywnego producenta lub usunąć przypisanie;
- zastąpić, dopisać albo wyczyścić opis;
- dołączyć nazwę każdego produktu do jego opisu, np. aby zachować zawarty w niej model i roczniki;
- pozostawić wybrane pole bez zmian.

Przed zapisem powstaje kopia w kopie_edycji_masowej. Wszystkie zmiany są
jedną transakcją; konflikt wersji blokuje całość. Nazwy, SKU, ceny i zdjęcia
pozostają bez zmian. To pierwszy zakres masowej edycji, bez masowego tłumaczenia
nazw, zmiany cen, pobierania zdjęć i publikacji.

## Usuwanie i czyszczenie

Usuń zaznaczone Produkty działa na wyborze, a Usuń wszystkie bieżące wyniki
na całym aktualnym wyniku filtra. Okno potwierdzenia podaje liczbę.
Domyślnie wybrane jest Nie. Po potwierdzeniu program blokuje zapisy,
sprawdza wersje i robi kopię całej bazy w kopie_usuwania; błąd kopii blokuje usunięcie.
Potem usuwa lokalne Produkty z ich cenami, zdjęciami i technicznymi powiązaniami importu.

Producenci oraz lista Do poprawy pozostają. Nic nie jest usuwane z Allegro
lub PrestaShop. Nowe Produkty dodane poza migawką również pozostają.
Nie jest to reset ani skasowanie całego pliku bazy. Zwolnione SKU można
ponownie zaimportować. Przywrócenie z kopii: DANE_I_KOPIE.md; nie ma selektywnego Undo.

## Zdjęcia ze strony producenta — pojedynczy produkt

1. W Producenci → Edytuj wpisz własny adres HTTPS witryny i zapisz.
   Pole jest opcjonalne i w nowej instalacji puste.
2. Dodaj lub edytuj pojedynczy Produkt. Wybierz producenta i wpisz SKU.
3. Adres źródła jest podpowiadany z producenta; możesz zmienić go dla tej próby.
4. Kliknij Pobierz kandydatów zdjęć po SKU.
5. Sprawdź tytuł, adres karty i wariant. Zaznacz właściwe zdjęcia i zapisz Produkt.

Pierwszy adapter obsługuje publiczny katalog sklepów Shopify, bez zaszytej
domeny i bez domyślnego producenta. Nie obsługuje każdej dowolnej witryny.
Wymagane jest jednoznaczne SKU wariantu, nie samo podobieństwo nazwy.
Brak obsługi, limit HTTP lub niejednoznaczność dają błąd, bez fikcyjnego sukcesu.
Zdjęcia produktu nadrzędnego mogą obejmować inne warianty, dlatego wybór
jest jawny. Maksymalnie pięć kandydatów na pobranie. 

Pobranie nie zapisuje nic w katalogu. Nowy zaznaczony zestaw zastąpi obecne
zdjęcia przy zapisie; brak zaznaczonych nowych zdjęć zachowuje poprzednie.
Dla zmiany istniejącego zestawu powstaje kopia w kopie_zdjec. Zmiana SKU
lub adresu po pobraniu unieważnia kandydatów, aby nie pomylić zdjęć.
W bazie są zdjęcia JPEG do 1600 px, miniatury i adresy pochodzenia;
nie jest to archiwum oryginalnych plików w pełnej rozdzielczości.
Tabela i szczegóły pokazują pierwszą miniaturę. Kopia bazy obejmuje zdjęcia.

Nie wykonano w chmurze próby rzeczywistej witryny właściciela; mechanizm
sprawdzono na syntetycznych odpowiedziach i obrazach. Potrzebny odbiór
online na Windows. Zgodność konkretnej witryny nie jest potwierdzona samym
zapisem adresu. W tym przyroście nie ma masowego pobierania zdjęć w imporcie.

## Tłumaczenia

Nie podłączono płatnego OpenAI API i nie wykonano płatnych wywołań.
Abonament ChatGPT nie obejmuje rozliczeń API. Limit 5 USD był propozycją,
nie przyjętym budżetem. Automatyczne tłumaczenie pozostaje wstrzymane.
Opis możesz złożyć z pól pliku i pełnego Title; nie jest to tłumaczenie ani
potwierdzone strukturalne dopasowanie marka/model/rocznik.
