# VexLab 0.43.1 — GPSR/dostawa otwiera się przed odczytem API

Zgłoszenie właściciela: kliknięcie „GPSR, dostawa i warunki…” nie otwierało
formularza. W 0.43 dialog tworzono dopiero po udanym pobraniu sześciu list
z Allegro. Błąd sieci, zgody lub dowolnego słownika kończył operację przed
utworzeniem okna, a komunikat trafiał tylko do dolnego paska planu.
Nie posiadamy odpowiedzi API z konta właściciela, więc nie przypisujemy mu
konkretnego błędu uprawnień.

## Zmiana

Formularz otwiera się natychmiast. Odczyt list w tle uruchamia się po jego
pokazaniu, a status widoczny jest u góry. Zakładki i własny tekst pozostają
dostępne podczas oczekiwania, przycisk zastosowania jest wtedy zablokowany.
Odmowa/wygaśnięcie/brak sieci mają widoczną przyczynę i przycisk **Pobierz
listy ponownie**. Własny tekst, dane nadania i nadal dostępne wybory zostają
zachowane po ponowieniu. Zamknięte okno ignoruje spóźnione wyniki.
Zmiana sesji blokuje zastosowanie danych poprzedniego konta.

Błąd jednej listy nie ukrywa innych danych. Formularz pokazuje listy pobrane
prawidłowo, wskazując po nazwie listy, których nie udało się pobrać. Brak
pozycji na koncie różni się od błędu odczytu. Częściowy wynik nie trafia do
cache pełnego odczytu i nie jest deklaracją potwierdzenia wszystkich danych.
Błędy wspólne kilku listom są grupowane, bez powtarzania całej instrukcji.

Przed zastosowaniem i wysyłką nadal trzeba potwierdzić wybrane identyfikatory.
Brak dostępu do wybranego producenta/cennika/warunków blokuje wysyłkę przed
uploadem zdjęć. Niedostępna lista dodatkowych gwarancji nie blokuje profilu,
który jawnie wybrał **Brak dodatkowej gwarancji**. Nie podstawiamy fałszywych
wpisów ani nie zmieniamy zgód automatycznie. Dla odmowy settings:read okno
podaje instrukcję odnowienia zgody; wygasła sesja zachowuje właściwy komunikat.

## Zachowanie danych i kontrola

Bez migracji schematu 11, zmian źródłowego ZIP-a, Produktów, logo, miniatur,
sygnatur, zasad potwierdzania i blokad ponowień. Pozostały zakres 0.43
zachowany. Testy używają kontrolowanych odpowiedzi, nie konta właściciela.

Regresje: prawdziwe modalne okno po kliknięciu przy odmowie API, oczekiwanie,
ponowienie po błędzie, zachowanie tekstu, odczyt częściowy, brak cache dla
częściowego wyniku, zamknięcie podczas pobierania i kontrola wybranych
wymaganych danych. Pełne narzędzia kontrolne oraz oba motywy/DPI sprawdzane
przed utworzeniem i publikacją paczki.

Wyniki: scripts/check.py — 922 testy zaliczone, 1 pominięty (DPAPI wymaga
Windows); ruff/format, mypy 110 modułów, 7 kontraktów importów, bandit
i diagnostyka poprawne. Audyt runtime i dev: brak znanych podatności.
48 testów GUI przy QT_SCALE_FACTOR=2 zaliczonych. Obejrzano okno z odmową
odczytu w obu motywach; błąd i ponowienie widoczne u góry, formularz otwarty.
