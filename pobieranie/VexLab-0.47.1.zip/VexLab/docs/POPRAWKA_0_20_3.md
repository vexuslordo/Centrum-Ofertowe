# VexLab 0.20.3 — dopracowanie bocznej nawigacji

2026-11-06, akceptacja właściciela „dopracuj” po ocenie wyglądu 0.20.2.
Wersja developerska 0.20.3.dev0. Schemat bazy 11 bez zmian.

Zwinięte belki mają delikatniejsze tła i półprzezroczyste obramowania.
Rozwinięcie wzmacnia akcent, z zachowaniem turkusu, fioletu, złota,
niebieskiego i lawendy. Większy odstęp po ostatniej zakładce oddziela
rozwiniętą grupę od następnej belki. Zaokrąglenie pozostaje 13 px.

Dashboard i belki mają wspólne boczne marginesy. Minimalne szerokości
zakładek nie wymuszają poszerzenia zawartości poza viewport menu; poziome
przewijanie nawigacji wyłączone. Nazwy i podpowiedzi zachowane. Przewijanie
pionowe nadal działa, a globalny tryb ikon zachowuje zwarty układ.
Nie zmieniono działania zakładek ani zapisu rozwiniętych grup.

Nowy test sprawdza oba motywy, wszystkie rozwinięte grupy i fokus długiej
nazwy: belki i zakładki pozostają wewnątrz szerokości widocznego obszaru,
bez przesunięcia poziomego. Dotychczasowe testy interakcji zachowane.
Przejrzano zrzuty z rozwiniętymi Produktami i Narzędziami, aktywnymi
Ustawieniami, w obu motywach i wąskim oknie. Dodatkowe przebiegi okna
przy skalach 125% i 150% zakończyły się powodzeniem (po 20 testów).

Minimalny obliczony kontrast tekst/tło belek we wszystkich deklarowanych
stanach wynosi 7,65:1 w ciemnym i 6,08:1 w jasnym motywie. To sprawdzenie
konkretnych tokenów, nie pełny audyt dostępności. Odbiór na natywnym Windows
pozostaje do wykonania. Profile, szkice, podgląd zdjęć i integracje bez zmian.

## Wyniki końcowe

`scripts/check.py`: 486 testów zaliczonych, ruff i format bez uwag,
mypy poprawne (66 modułów), siedem kontraktów importów, Bandit i diagnostyka
bez błędów. Audyt pełnych zależności przechodnich runtime/dev: brak znanych
podatności w sprawdzonych wersjach. Wheel/sdist zbudowane offline.
Porównanie z 0.20.2 potwierdziło niezmienione pliki bazy, preferencji,
szkiców i podglądu obrazów. Zmiany pozostają ograniczone do nawigacji.
