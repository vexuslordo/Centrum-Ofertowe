# VexLab 0.30 — widoki katalogu

Pasek producentów powstaje wyłącznie z rejestru użytkownika: pierwszych pięciu
producentów jako przyciski, kolejni w menu Więcej. Brak stałych marek i seedów.
Zmiany nazw oraz usunięcie producenta odświeżają pasek.

Dashboard i Produkty: lokalne wyszukiwanie po nazwie, SKU i EAN, filtry obecności
zdjęcia i ceny, przełączanie listy i kafelków, akcje edycji i menu wiersza.
Wybór produktów oraz stronicowanie zachowane. Stany kanałów pozostają nieznane,
bez demonstracyjnych zielonych wskaźników. Schemat 11 bez zmian.

Pakiet źródłowy wymaga Pythona 3.13 oraz uv jak poprzednie wydania.
