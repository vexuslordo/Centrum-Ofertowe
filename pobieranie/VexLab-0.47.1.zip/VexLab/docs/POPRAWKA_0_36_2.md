# Poprawka 0.36.2 — kolory Allegro jak na Dashboardzie

Właściciel doprecyzował 2026-11-09: „Allegro jak Dashboard”. Zmiana dotyczy
wyłącznie kolorów pięciu KPI w obszarze Allegro. Pełne zielone/niebieskie/
czerwone/fioletowe/złote wypełnienia zastępuje ciemna baza #0D1B28,
delikatna kolorowa poświata i ramka #203B51, zgodnie z kompaktowymi KPI
Dashboardu. Kolorowe pola ikon pozostają. Jasny motyw ma odpowiednik
na #F6F9FE i czytelne ciemne etykiety. Dashboard bez zmian.

Liczby, statusy połączenia, pobieranie ofert, kwadratowe miniatury 64×64
oraz wszystkie działania pozostają zachowane. Bez zmian danych,
schematu, zależności lub operacji API.

Weryfikacja: istniejące testy Allegro, Dashboardu i KPI w obu motywach,
również skalowanie 150%; mypy Windows, ruff i formatowanie. Zrzuty
vexlab-allegro-0362-* używają izolowanego fixture, bez danych konta użytkownika.
