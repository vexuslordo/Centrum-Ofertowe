# VexLab 0.17 — wygodniejsza praca z cennikami

2026-11-06. Właściciel zaakceptował propozycję usprawnień: lista i podgląd
obok siebie, statusy pozycji, porównanie cen, aktualne/archiwalne wydania
producenta i krótszy pasek. Zakres zatwierdzony w ADR-043.

## Obsługa

Cenniki mają trzy główne akcje: Dodaj cennik, Dodaj do katalogu i Więcej.
Kliknięcie cennika pokazuje jego produkty obok listy. Podział można
przesuwać; na węższym oknie panele ustawiają się pionowo. Nazwa,
producent, rok i status są w tabeli, wydanie, liczba pozycji, plik i czas
wczytania w podglądzie oraz dymku. Zapisane wcześniej źródła pozostają.

Pozycje mają stany Nowy / W katalogu / Inna cena / Do poprawy, także filtr
według stanu. Tekst statusu jest zawsze obecny; barwa wspomaga odczyt.
Cena cennika, obecna zapisana cena bazowa i różnica kwotowa/procentowa
są widoczne obok siebie. Różnica to cena cennika minus cena bazowa,
procent liczony względem bazowej. Waluta i netto/brutto muszą być zgodne.
Nie ma przeliczania kursów lub VAT. Brak porównania pokazuje kreskę i
wyjaśnienie w dymku. Dla zerowej bazowej procent jest nieokreślony;
różnica kwotowa pozostaje dostępna. Błędy danych mają pierwszeństwo
przed stanem W katalogu, bez nadpisywania istniejących SKU.

Więcej i prawy przycisk na cenniku: Ustaw jako aktualny / Archiwizuj.
Wybór jest daną użytkownika, osobną dla każdego producenta. Maksymalnie
jeden aktualny cennik na producenta; może nie być żadnego. Dokumenty nowe
oraz z wcześniejszych wersji startują jako archiwalne. Bez przypisanego
producenta nie można oznaczyć aktualności. Rok nie wybiera aktualnego
wydania. Archiwizacja i usunięcie nie wybierają zastępczego dokumentu.

Oznaczenie aktualności porządkuje źródła; nie zmienia zapisanych cen
Produktów. Aktualizacja tych cen pozostaje osobnym jawnym procesem;
istniejące Uzupełnij brakujące ceny nadal dostępne w Więcej. Nie dodano
masowego zastępowania istniejących cen ani odczytów cen Allegro/PrestaShop.

Dodanie zaznaczonych pozycji do katalogu: przycisk lub PPM; Ctrl/Shift i
Ctrl+A zachowane. Znane SKU pomijane, nowe poprawne tworzone, wybrane
błędne do Do poprawy. Usuwanie zaznaczonych cenników jest w Więcej i PPM,
z potwierdzeniem, kopią i bez usuwania Produktów. Do poprawy, import
bezpośredni i odświeżenie są w menu. Shift+F10 / Menu obsługują PPM.

## Spójność i odtworzenie

Schemat 9: flaga aktualności i częściowy indeks unikalności per producent.
Migracja 8→9 tworzy spójną kopię w kopie_migracji. Niezmienione definicje
schematu 1 i migracji 2–8 porównano z ZIP-em 0.16. Nowa instalacja nadal
pusta, bez producentów, cenników lub wyborów zaszytych w programie.

Zmiana aktualności sprawdza wersje cenników danego producenta sprzed
potwierdzenia. W jednej transakcji archiwizuje poprzedni, oznacza wybrany
i zwiększa wersje zmienianych dokumentów. Konflikt lub błąd zapisu cofa
całość. Przed operacją kopia w kopie_cennikow. Kopia chroni także usuwanie.
Do powrotu do 0.16 potrzebna kopia sprzed migracji 9: zamknij aplikację,
zachowaj obecną bazę i przywróć zgodną kopię. Późniejsze zmiany nie są
w niej obecne. Starsza aplikacja nie otwiera schematu 9.

Odczyt i zapis pozostają w tle, GUI bez SQL. Podgląd ignoruje spóźniony
wynik dla poprzedniego wyboru, kolejkuje wyłącznie ostatni wybór; tabela
wypełniana partiami. Kwoty porównywane w Decimal za warstwą przypadków
użycia, bez logiki cenowej w GUI i bez nowej encji głównej.

## Sprawdzenia

Kontrola lokalna scripts/check.py: lint, format, mypy strict, siedem
kontraktów warstw, Bandit, pytest bez ekranu i diagnostyka. Testy obejmują
poprawne i nieporównywalne ceny, zero, duplikaty, błędne istniejące SKU,
aktualność per producent, restart, konflikty, rollback, kopię, odtworzenie,
przerwanie migracji i brak kopii; GUI oba motywy, filtry, klawiaturę,
3000 pozycji, anulowanie, spóźniony wynik i mniejsze okna. Dodatkowy przebieg
GUI ze skalowaniem 150%. Audyt runtime/dev z uv.lock: brak znanych
podatności w dniu sprawdzenia. Końcowy wynik liczbowy w raporcie przekazania.

Izolowane zrzuty w docs/screenshots/vexlab-cenniki-*.png używają wyłącznie
danych syntetycznych, generowanych przez scripts/capture_cenniki.py.
Budowanie wheel/sdist i kontrola źródłowego ZIP-a. Odbiór na Windows oraz
zaplanowany audyt techniczny i UX kandydata 1.0 pozostają osobnymi zadaniami.
