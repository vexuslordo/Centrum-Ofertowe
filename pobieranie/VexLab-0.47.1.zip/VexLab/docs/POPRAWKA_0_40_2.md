# VexLab 0.40.2 — pełny podgląd oferty przed zapisaniem

2026-11-13. Zgłoszenie właściciela: potrzebny cały podgląd oferty;
zdjęcia pojawiały się dopiero po zapisaniu lokalnego szkicu.

Przyczyna: główne okno nie przekazywało portu PodgladZdjec do strony paczek.
Zapisany szkic korzystał z poprawnego połączenia zależności. Naprawiono
podłączenie; odczyt zdjęć z ZIP jest teraz wykonywany tym samym mechanizmem
HTTPS w tle, bez konieczności zapisu do bazy.

Domyślna zakładka Cała oferta pokazuje tytuł, metadane ceny/EAN, galerię
z wyborem zdjęcia i wszystkie sekcje w kolejności źródłowej. Dla braku sekcji
pokazywany jest cały bezpieczny tekst HTML i galeria. Pozostały podgląd danych,
opisu, źródła i sekcji pozostaje dostępny w dotychczasowych zakładkach.
Okno można maksymalizować; rozmiar startowy uwzględnia dostępny ekran.
Strona jest przewijana, długie nagłówki i opisy nie są ściskane ani ucinane,
a elementy obrazu/tekstu są wyrównane do góry.

Renderer jest przybliżeniem oferty, nie oficjalną stroną Allegro. HTML nadal
nie ładuje zasobów, skryptów i plików; obrazy odczytywane przez ograniczony
port z limitami/cache i ignorowaniem spóźnionych wyników po zamknięciu.
Zachowano limity galerii podglądu i kolejki, proporcje zdjęć i miniatury tabel.
Podgląd nie zmienia źródła, Produktów, szkiców lub konta. Schemat 11 bez zmian.

Testy obejmują pełny widok, obrazy w tle z głównego okna bez lokalnego zapisu,
długi tytuł/opis w obu motywach, klawiaturę, zmianę rozmiaru, brak sekcji,
błąd zdjęcia i zamknięcie podczas odczytu. Rzeczywiste zdjęcia z przesłanej
paczki odczytano przez istniejący transport HTTPS; brak zapisów na Allegro.

Osobne zgłoszenie właściciela: produkty nie istnieją w Katalogu Allegro.
Wersja 0.40.2 poprawia podgląd; nowa ścieżka zgłoszenia produktu wymaga
kolejnego przyrostu z kategorią/parametrami i jawnym potwierdzeniem tego skutku.
Nie wolno dobierać innego istniejącego produktu dla obejścia tej potrzeby.

Kontrola wydania: check.py — 833 passed / 1 skipped (DPAPI Windows),
ruff/format, mypy 104 moduły, 7 kontraktów importów, bandit i diagnostyka OK.
Podgląd i import przy 150% — 24 passed. Audyt runtime/dev bez znanych
podatności. Pełne GUI odczytało trzy unikalne zdjęcia oferty z rzeczywistej
paczki przez HTTPS, pokazało cały układ bez tworzenia lokalnego szkicu.
