# VexLab 0.45 — prostsze przygotowanie ofert Allegro

Okno nowych szkiców ma układ zgodny z kolorami i typografią Dashboardu.

1. **Dane produktów**: wybierz walutę, domyślną ilość oraz produkt Allegro
   lub przygotowanie nowego produktu. SKU, EAN i ceny pozostają indywidualne.
2. **Ustawienia Allegro**: GPSR, dostawa, warunki i VAT są w jednej sekcji.
3. Nad tabelą zaznacz produkty i użyj **Edytuj dane…** lub
   **Parametry produktów…** do zmian masowych.
4. Kliknij **Sprawdź paczkę**. Wybierz wiersz, żeby przeczytać braki.
   Następnie **Utwórz zaznaczone szkice…** — po potwierdzeniu.

Menu **Więcej działań** zawiera dane pojedynczej oferty, odznaczenie,
sprawdzenie wyników wysyłki, eksport raportu i poprawę starych sygnatur.
**Zatrzymaj serię** pojawia się podczas pracy. Zachowano wszystkie funkcje,
trwałą ochronę przed ponownym POST i obowiązkowe potwierdzenia.
Utworzenie szkiców nie uruchamia sprzedaży.

W tej samej paczce poprawiono pustą listę VAT: placeholdery Allegro
`value: null` i specjalna opcja `OUT_OF_SCOPE_OF_VAT` są poprawnie odczytywane.
Szczegóły i źródła: [poprawka VAT](POPRAWKA_0_44_1.md). Numer 0.44.1 nie był
osobno opublikowany — po rozszerzeniu zakresu poprawka trafiła do 0.45.

Podgląd jednego ekranu do oceny: [ciemny](screenshots/vexlab-przygotowanie-045-dark.png)
i [jasny](screenshots/vexlab-przygotowanie-045-light.png). Dane syntetyczne;
reprodukcja: `python scripts/capture_przygotowanie_045.py`.
Bez zmian logo, równych miniatur w pozostałych widokach, schematu bazy
lub plików użytkownika. Odczyty i zapisy konta testowane transportem kontrolowanym,
bez logowania do prywatnego konta użytkownika i bez publikacji ofert.
