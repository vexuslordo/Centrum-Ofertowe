# VexLab 0.15.1 — krótsze etykiety menu Produktów

Data: 2026-11-05. Polecenie właściciela: skrócić nazwy w menu,
aby były bardziej naturalne i czytelne.

Etykiety wspólnego menu rozwijanego i kontekstowego:

- Szczegóły
- Edytuj…
- Galeria…
- Masowa edycja…
- Zaznacz wszystkie
- Odznacz
- Dodaj (menu kontekstowe)
- Importuj… (menu kontekstowe)
- Do poprawy
- Eksportuj CSV…
- Odśwież (menu kontekstowe)
- Usuń zaznaczone…
- Usuń wszystkie wyniki…

Zakres dwóch operacji usuwania pozostaje odróżniony. Dymki objaśniają
usunięcie zaznaczonych i wszystkich wyników bieżących filtrów oraz eksport
całych wyników do CSV. Zachowano połączenia sygnałów, skróty, warunki
wyboru, potwierdzenia i kopie. Baza nadal schemat 7, bez migracji.
Żadna operacja domeny, zapisu, importu lub integracji nie została zmieniona.
Nowe etykiety nie są nowymi funkcjami ani seedami danych użytkownika.

Weryfikacja: Ruff, strict mypy oraz cztery istniejące testy menu,
zaznaczania, rzeczywistego zdarzenia kontekstowego Qt i klawiatury.
Zrzuty obu motywów pokazują skrócone etykiety. Poprawka wyłącznie tekstowa;
pełna regresja 324 testów była wykonana dla poprzedniego wydania 0.15.
Audyt kandydata 1.0 i odbiór Windows/DPI pozostają osobnymi sprawdzeniami.
