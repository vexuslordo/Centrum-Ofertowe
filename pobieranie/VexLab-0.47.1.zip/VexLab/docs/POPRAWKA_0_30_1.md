# VexLab 0.30.1 — wyrównanie ikon wyszukiwania

Ikony lupy i czyszczenia w polach tekstowych nie dziedziczą już wymiarów,
obramowania i odstępów przycisków akcji. Pozostają wyśrodkowane i mieszczą się
w polu. Sprawdzono oba motywy, pusty i wypełniony tekst oraz podgląd Dashboardu.
Schemat 11, dane użytkownika i działanie wyszukiwania bez zmian.
