# VexLab 0.41 — produkty nieobecne w Katalogu Allegro

Polecenie właściciela z 2026-11-13: oferty z paczki dotyczą także nowych
produktów. Dotychczasowy wymóg istniejącego UUID nie wystarczał. Nowa ścieżka
jest opcjonalna i nie podstawia podobnej, cudzej kartoteki.

## Jak używać

1. Otwórz ZIP, przejdź do „Przygotuj szkice w Allegro”, wybierz walutę cen.
2. Zaznacz pozycję i kliknij **Nowy produkt w Allegro…**.
3. Wyszukaj i wybierz końcową kategorię Allegro. Opcjonalnie zaznacz
   zastosowanie kategorii do wszystkich pozycji bez dopasowanego produktu.
4. Kliknij **Uzupełnij wybraną…**. Wpisz parametry produktu i oferty pobrane
   z API. Wymagane mają gwiazdkę. Słowniki zawierają rzeczywiste wartości API.
   Parametr tekstowy/liczbowy może pochodzić ze wspólnej wartości albo z SKU
   lub EAN każdej pozycji — wybór źródła jest jawny, nie automatyczny.
5. Opcjonalnie zastosuj parametry i źródła do pozostałych nowych produktów
   tej samej kategorii. Cena edytowana w formularzu dotyczy tylko bieżącego
   wiersza, pozostałe zachowują własne ceny. Braki i błędny EAN pozostają
   błędami poszczególnych pozycji.
6. Sprawdź plan i potwierdź **Utwórz szkice w Allegro…**. Okno potwierdzenia
   podaje konto, środowisko, liczbę szkiców oraz liczbę definicji nowych
   produktów wysyłanych do Katalogu Allegro. Domyślna odpowiedź: Nie.
7. Zachowaj raport. Dla 202 użyj „Sprawdź wyniki wysyłki”. Nieznany wynik
   zachowuje blokadę powtórnego utworzenia także po ponownym otwarciu programu.

## Kontrakt i granice

Pełna definicja produktu (nazwa, kategoria, parametry produktowe, zdjęcia)
trafia do productSet w jednym POST /sale/product-offers. Nie wykonujemy
osobnego zgłoszenia product-proposals. Allegro może utworzyć produkt,
dopasować istniejący albo odrzucić dane; nie gwarantujemy nowego UUID.
Powstała oferta zawsze INACTIVE, republish=false. Zgłoszenie katalogowe
jest rzeczywistym skutkiem, mimo że sprzedaż nie zostaje uruchomiona.

Przed POST ponowny odczyt wymagań kategorii i upload zdjęć HTTPS. Rejestr
konto/środowisko/SKU oraz odciski blokują nieznane i konfliktowe próby.
Po przyjęciu wymagane odczyty oferty i produktu: nazwa, kategoria,
parametry, treść, zdjęcia i INACTIVE. NOT_LISTED, brak UUID lub rozbieżności
nie są komunikatem sukcesu. Stare odciski prób 0.40 pozostają zgodne.

Kategorie pochodzą z matching-categories; wybór użytkownika, bez zgadywania
marki lub kategorii z nazwy paczki. Metadane wspólnej kategorii mają ograniczony
cache w pamięci (32 wpisy, 30 s), oddzielony według konta i środowiska.

Pierwszy zakres nadal obsługuje pojedynczą wartość parametru, zdjęcia HTTPS,
walidację podstawową i dodatkową walidację Allegro. Ograniczenia warunkowe,
reguły kategorii, dostawa i GPSR mogą wymagać dalszych danych; błędy API
zostają w raporcie. Nie zgadujemy obowiązkowych wartości i nie generujemy EAN.
Formularz ręcznej nowej oferty bez ZIP-a, zamówienia i zwroty prowizji są
kolejnymi wymaganiami; nie zostały zastąpione tym importerem.

Pełny podgląd 0.40.2, logo, miniatury i dotychczasowe funkcje zachowane.
Schemat SQLite 11 bez migracji; brak zmian danych i plików użytkownika.

## Weryfikacja

Testy kontrolowanych odpowiedzi obejmują nowy produkt bez UUID, wymagania,
źródła parametrów, zachowanie cen, kategorię liściową, cache, POST/GET,
202/timeout i deduplikację po restarcie, niezgodny produkt i NOT_LISTED,
blokadę publikacji w transporcie, potwierdzenie z domyślnym Nie oraz oba
motywy. Pełny zestaw i audyt zależności opisane w raporcie wydania.
Nie wykonano mutacji rzeczywistego konta Allegro. Pierwszy odbiór użytkownika:
jedna poprawnie uzupełniona pozycja i odczyt raportu odpowiedzi Allegro.

Wyniki przed pakowaniem: scripts/check.py — 859 testów zaliczonych,
1 pominięty (natywne DPAPI Windows), ruff/format, mypy 104 modułów,
7 kontraktów importów, bandit i diagnostyka poprawne. Dodany następnie test
pełnego przebiegu przez mapper HTTP wraz z pozostałymi testami nowych
produktów: 24/24. GUI procesu i podglądu przy QT_SCALE_FACTOR=2: 20/20.
Audyt runtime i dev: brak znanych podatności. Syntetyczne podglądy obu motywów:
[screenshot ciemny](screenshots/vexlab-nowe-produkty-041-dark.png),
[screenshot jasny](screenshots/vexlab-nowe-produkty-041-light.png).

Rzeczywisty ZIP użytkownika: 200 ofert i 800 sekcji bez problemów odczytu,
automatyczne otwarcie na pustej instalacji, zachowany hash źródła. Pełny
podgląd pobrał i zdekodował wszystkie 3 unikalne zdjęcia wybranej oferty,
bez lokalnego zapisu i wywołań API konta. Dane z ZIP-a i obrazy użytkownika
nie są dołączane do dystrybucji programu.
