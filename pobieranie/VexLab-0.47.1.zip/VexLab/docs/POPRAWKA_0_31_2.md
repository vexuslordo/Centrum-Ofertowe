# VexLab 0.31.2 — uprawnienia połączenia Allegro

Device Flow jawnie żąda dwóch uprawnień odczytu: allegro:api:profile:read
oraz allegro:api:sale:offers:read. Nie żąda uprawnień zapisu ani publikacji.
HTTP 403 wskazuje teraz odmowę odczytu profilu (/me) albo ofert (/sale/),
z nazwą uprawnienia i instrukcją ponownej autoryzacji. invalid_scope ma
osobny komunikat konfiguracji aplikacji. Nie pokazujemy treści odpowiedzi API.

Sama zgoda w przeglądarce nie potwierdza konta; sukces nadal wymaga /me.
Brak dostępu do ofert zachowuje sesję, jeśli konto potwierdzono wcześniej.
Nie zmieniamy uprawnień aplikacji na Allegro z poziomu VexLab.

Gdy Allegro odmawia dostępu: w konfiguracji własnej aplikacji na
https://apps.developer.allegro.pl/ sprawdzić oba zakresy odczytu. Po ich
włączeniu uruchomić nowe połączenie i ponownie zatwierdzić zgodę.
Jeżeli 403 pozostaje, należy sprawdzić powód odmowy po stronie Allegro;
403 nie jest sam w sobie jednoznacznym dowodem brakującego scope.

Schemat, DPAPI i zależności bez zmian. Testy symulują uprawnienia API;
bez dostępu do konta właściciela nie potwierdzono logowania na produkcji.
