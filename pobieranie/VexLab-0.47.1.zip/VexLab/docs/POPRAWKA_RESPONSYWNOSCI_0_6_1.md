# VexLab 0.6.1 — poprawka responsywności edycji masowej

Data: 2026-11-03. Zgłoszenie właściciela: zmiana Producenta dla wszystkich
Produktów kończyła się komunikatem Windows „Brak odpowiedzi”.

## Przyczyna i zmiana

Zapis był wykonywany w tle, ale GUI po odczycie katalogu odtwarzało
zaznaczenie osobno dla każdego wiersza. Każdy krok emitował selectionChanged,
którego odbiorca ponownie pobierał i mapował cały wybór na DTO. Koszt rósł
w przybliżeniu kwadratowo z liczbą zaznaczonych Produktów.

Nowa obsługa buduje jeden QItemSelection ze scalonymi sąsiednimi zakresami
i wykonuje jedno ustawienie wyboru na tabelę. Licznik liczy wybrane wiersze
bez mapowania ich na DTO. Selekcja nadal odtwarzana po ID, w bieżącym filtrze
i sortowaniu. Formularz masowy pokazuje indeterminate progress i tekst
Zapisywanie; nie przedstawia nieznanego procentu jako zmierzonego postępu.

W lokalnym porównaniu samej obsługi odczytu i selekcji 500 wierszy: wydane
0.6 około 2,408 s, poprawka około 0,129 s. To pomiar Linux/offscreen,
nie czas całej operacji z bazą ani pomiar na Windows właściciela.

## Dane i zakres

Bez zmiany reguł biznesowych, kontraktów portów, adaptera SQLite, zależności
i schematu 4. Blokada paczek ma nową wersję własnego projektu 0.6.1.dev0;
cały graf zależności zewnętrznych porównano z ZIP 0.6 — identyczny.
Kopie przed edycją masową i atomowy zapis pozostają. Nie resetowano danych,
nie dodano seedów, nie publikowano konfiguracji środowiska ani repozytorium.

Zamknij starszy program po zakończeniu jego operacji, rozpakuj ZIP osobno
i kliknij Uruchom VexLab.cmd. Program użyje dotychczasowego katalogu danych.
Nie ma nowej migracji względem 0.6.

## Weryfikacja

Test regresyjny rzeczywistej bazy i GUI: 2375 Produktów, zaznaczenie całości,
wybór Producenta i zapis przez formularz. Sprawdza finalnego producenta
każdego rekordu, zachowanie selekcji, najwyżej trzy sygnały zmiany wyboru,
wykonywanie zapisu poza wątkiem GUI, działanie timera GUI i kopię bazy.
Drugi test chroni nieprzyległą selekcję przy sortowaniu malejącym.

Oba testy przeszły przed przerwaniem dostępu do poprzedniego środowiska.
Po przywróceniu dostępu potwierdzono zachowanie plików poprawki; dokończono
synchronizację wersji i weryfikację wydania. Końcowe wyniki poniżej.

Pozostaje odbiór poprawki na komputerze Windows właściciela. Testy Linux
nie stanowią gwarancji responsywności każdej operacji na dowolnym sprzęcie.

## Wynik końcowy

Po odzyskaniu środowiska wykonano pełne scripts/check.py: ruff check/format,
mypy strict (35 plików), 7 kontraktów importów, bandit, 197 testów i diagnostyka
zakończyły się sukcesem. Runtime: Python 3.13.18, PySide6/Qt 6.12.0, uv 0.13.6.
uv lock --check potwierdził zgodność. Zależności zewnętrzne i adapter bazy
porównano z wydanym 0.6, bez zmian; nie powtarzano audytu tego samego grafu.
2026-11-03 właściciel po otrzymaniu 0.6.1 potwierdził „działa”.
To potwierdzenie poprawki, bez deklaracji pełnego odbioru wszystkich funkcji/DPI.

## Weryfikacja ZIP

Źródła rozpakowano do osobnego katalogu. Z ustawionym PYTHONPATH na jego
src potwierdzono ścieżkę importu oraz wykonano z paczki oba testy regresyjne
(2375 rekordów i nieprzyległa selekcja): 2 przeszły. Diagnostyka również
zakończona poprawnie. Użyto istniejących przypiętych zależności, bez deklaracji
testu świeżego Windows lub nowej instalacji zależności z sieci.
ZIP ma poprawne CRC, bez baz, danych źródłowych użytkownika, środowiska i cache.
