# VexLab 0.9.1 — osobna strona Masowej edycji

Zgłoszenie właściciela, 2026-11-03: menu Masowa edycja pokazywało Produkty,
z dodawaniem i importem. Usunięto przekierowanie i automatyczne otwieranie
formularza. Strona ma tytuł Masowa edycja, wyjaśnienie zakresu, filtr
producenta, czyszczenie filtrów, odświeżenie, zaznaczenie wszystkich wyników,
odznaczenie, licznik oraz „Ustaw zmianę zaznaczonych…”.

Wybór produktów odbywa się we własnej tabeli. Wyszukiwanie pozostaje
na tej stronie. Enter otwiera wspólny formularz zmiany producenta/opisu.
Dodawanie, import i usuwanie produktów pozostają w przeznaczonych obszarach.
Podgląd tabeli zawiera miniaturę, nazwę, SKU i producenta; nie sugeruje
wprowadzenia edycji cen/stanów lub Ofert.

Zaznaczenia Produkty/Masowa edycja są niezależne, dane i filtry współdzielone.
Formularz zapisuje migawkę wyboru z właściwej strony, poza wątkiem GUI,
z kopią i kontrolą wersji. Po zapisie odświeża katalog i odtwarza wybór
zbiorczo po ID. Skrót w Produkty nadal otwiera ten sam formularz.
Pusta baza i brak wyników mają osobne komunikaty; akcja bez wyboru jest
nieaktywna. Błąd odczytu blokuje zmianę na podstawie nieaktualnego katalogu.

Bez zmian domeny, schematu 6 i zewnętrznych zależności. Brak migracji.
Nowe oferty/Szkice nie są częścią tej poprawki — ADR-035 nadal propozycją.
Wymagany audyt techniczny i użytkowy 1.0 pozostaje zaplanowany.

Test regresji: oddzielne strony i aktywna pozycja menu, brak przycisków
Dodaj/Importuj/Usuń, właściwe źródło zaznaczenia, zmiana tylko wybranego
produktu, zachowanie wyboru po zapisie, wyszukiwanie bez opuszczania strony,
zaznaczenie tylko wyników i odznaczenie. Regresja 2375 produktów sprawdza
teraz oba wejścia, wątek zapisu i zbiorcze odtwarzanie selekcji.
Odbiór poprawki na Windows/DPI/Narrator pozostaje do wykonania.

Wynik scripts/check.py: 244 testy przeszły, ruff check/format, mypy
(40 plików), 7 kontraktów importów, bandit i diagnostyka poprawne.
uv sync --frozen --offline i uv lock --check potwierdziły zgodność wersji.
Porównanie z wydanym 0.9 potwierdziło brak zmian w schemacie/adapterze
SQLite i regułach zmiany danych. Zależności zewnętrzne bez zmian;
nie powtarzano audytu tego samego grafu.

Obejrzano zrzuty nowej strony w obu motywach przy 1536×1024 (Qt offscreen).
ZIP rozpakowano osobno, potwierdzono import z jego src i uruchomiono
z paczki oba nowe testy regresji — przeszły. CRC poprawne; bez baz,
źródłowych XLSX, środowiska i cache. Użyto istniejących przypiętych
zależności; nie był to odbiór nowej wersji na świeżym Windows.
