# VexLab 0.32 — karta Integracje i górny pasek

Dashboard ma dwie osobne karty z logotypami Allegro i PrestaShop, stanem,
kontem/sklepem oraz miejscem na liczbę ofert/produktów i limit/wersję.
Przycisk Zarządzaj otwiera Ustawienia → Integracje.
Górny pasek: stan Allegro, znaki i nazwy kanałów, separator, ikona Ustawień,
avatar użytkownika systemu i rzeczywista wersja programu.
Przyciski kanałów prowadzą do odpowiednich obszarów pracy.

Login i zielony stan Allegro pochodzą z potwierdzonej sesji /me. Rozłączenie
czyści login i status w obu miejscach. PrestaShop pozostaje niepołączony,
ze wskazaniem przygotowania integracji. Nie skopiowano przykładowych kont,
domen, liczb, 2 req/s ani wersji sklepu z referencji. Nieodczytane pola są
pokazane jako —. Liczba szkiców INACTIVE nie jest liczbą wszystkich ofert.
Pełny znak Allegro pochodzi z już używanego zasobu Simple Icons (zmiana viewBox).
Pozostałe znaki marek i licencje bez zmian.

To zmiana GUI, bez nowych żądań API, domeny, uprawnień i migracji schematu 11.
