# VexLab 0.10 — podgląd paczek ZIP, profile i logo

2026-11-03. Pierwszy działający etap docelowego importu i wysyłania gotowych
ofert na Allegro. Obejmuje odczyt ZIP oraz konfigurowalny podgląd; nie
zapisuje Ofert do bazy i nie publikuje. Schemat 6 bez zmian.

## Jak sprawdzić paczkę

1. Nowe oferty → Wybierz ZIP.
2. Wczytaj własny profil JSON lub wybierz plik listy rekordów JSON wewnątrz
   archiwum i wskaż pola. SKU/tytuł wymagane do przygotowania podglądu;
   brak w konkretnym rekordzie jest oznaczany, bez tworzenia Produktu.
3. Jeśli mapujesz sekcje, ustaw również ich klucze oraz wartości typów
   tekst/obraz. Można zachować inny układ dla każdego producenta/oferty.
4. Sprawdź i pokaż oferty → tabela. Dwuklik lub Pokaż wybraną ofertę otwiera
   dane, opis, jego źródło i układ sekcji. Zdjęcia pokazane jako adresy,
   bez pobierania. Nie jest to jeszcze podgląd graficzny obrazów Allegro.
5. Zapisz profil jako… zachowuje konfigurację w osobnym pliku użytkownika.
   Wczytaj go przy następnej paczce. Wybierz nową nazwę zamiast nadpisywania.

W programie nie ma wbudowanego producenta, nazwy pliku paczki, banerów ani
ustawień konta. Przygotowany profil Evotech jest osobnym plikiem użytkownika,
poza ZIP-em programu. Nie zawiera kluczy API i nie ustawia konta Allegro.
Pierwszy obsługiwany format danych to lista obiektów JSON w ZIP; CSV,
załączniki i inne pliki są teraz wykazywane w inwentarzu, nie importowane
jako kolejne oferty. Wybór właściwego pliku jest jawny — nie sumujemy
kopii tych samych 200 ofert z JSON i CSV.

Paczka przykładowa została sprawdzona przez rzeczywisty czytnik i profil:
8 plików, 200 ofert, 800 sekcji, 335 adresów fotografii produktu, bez błędów
w mapowanym zakresie. Nie jest to potwierdzenie dostępności URL-i, poprawności
EAN/cen ani spełnienia wymagań Allegro. 51 pozycji w pomocniczym CSV widocznych
jako plik w paczce; nie dodano ich do działającej listy Do poprawy katalogu.

HTML jest filtrowany i wyświetlany bez zasobów sieciowych/lokalnych,
skryptów lub aktywnych linków. Źródłowy HTML można obejrzeć jako tekst.
Archiwum nie jest rozpakowywane na dysk. Limity i odrzucane struktury
opisuje ADR-037. Nie pobieramy adresów lub instrukcji z ZIP-a jako poleceń.
Błąd odczytu nowej paczki usuwa poprzedni podgląd, nie myli źródeł.

## Docelowy proces Allegro — wymaganie właściciela

ZIP → profil odczytu i gotowa treść → powiązanie Produkt/Oferta → wybrane
konto → wymagania i dostępne ustawienia z API → dobór według profilu
użytkownika → walidacja kompletności → zatwierdzenie zakresu → wysyłka
oraz wynik/obsługa ponowień. Te etapy po podglądzie nie są jeszcze wdrożone.
Sama obecność pól w ZIP-ie nie potwierdza, że dane ustawienie istnieje
na danym koncie. Nie wprowadzono fikcyjnych kont lub statusu „połączono”.

## Identyfikacja wizualna

Logo dostarczone przez właściciela przygotowano jako PNG z przezroczystością,
włączono do nagłówka i ikony okna. Zmiana palety na granat, turkus, fiolet
i złote akcenty; zachowano układ ekranów i oba motywy. Źródło nowej grafiki:
edytowane narzędziem obrazowym logo użytkownika. Transparentny plik również
przekazany osobno do pobrania. Nazwa aplikacji/katalog danych VexLab bez zmian.

## Kontrole

Testy odczytu dwóch różnych profili i nazw pól, kolejności sekcji/galerii,
nieprawidłowych rekordów, ścieżek, dowiązań, duplikatów nazw, limitów,
uszkodzonego ZIP/JSON oraz zapisu/odczytu profilu bez nadpisania.
Qt: profil przed ZIP-em, podgląd, szczegóły, filtracja HTML, unieważnianie
wyniku, błąd nowego pliku, brak zmiany katalogu, logo z kanałem alfa,
oba motywy i małe okno. Dane automatycznych testów wyłącznie syntetyczne.

Nowe ustawienia Allegro, pełny model zapisu oraz rzeczywiste API pozostają
do wdrożenia. Odbiór na Windows, DPI/Narrator i pełny audyt użytkowy 1.0
pozostają otwarte. Nie deklarujemy ich na podstawie zrzutów Qt offscreen.

Wynik scripts/check.py: 263 testy przeszły, ruff check/format, mypy
(43 pliki), 7 kontraktów importów, bandit i diagnostyka poprawne.
Po zwinięciu zaawansowanego mapowania i korektach wyglądu tabeli ponownie
sprawdzono 3 testy GUI nowego przepływu, lint/format i typowanie.
uv sync --frozen --offline i uv lock --check potwierdziły zgodność.
Budowanie wheel/sdist offline zakończone poprawnie; PNG obecny w wheel.
Zewnętrzne zależności bez zmian, bez ponownego audytu tego samego grafu.

Obejrzano zrzuty w obu motywach i rzeczywisty podgląd paczki użytkownika
(200 ofert) w Qt offscreen. Katalog po tym scenariuszu pozostał pusty.
Zrzuty zawierające treść paczki pozostawiono poza paczką źródeł programu;
w repozytorium są tylko puste widoki i syntetyczne dane testów.
Sprawdzony kontrast tekstu głównej akcji: 8,07:1 w obu motywach;
nie zastępuje to pełnego audytu kontrastu/dostępności. Logo ma kanał alfa
z przezroczystymi narożnikami. Adapter SQLite identyczny z wydanym 0.9.1.

ZIP źródeł rozpakowano do osobnego katalogu, potwierdzono ścieżkę importu
z jego src i uruchomiono 19 testów nowego czytnika/profili/GUI — wszystkie
przeszły. CRC poprawne, PNG logo obecny. Brak baz, danych źródłowych paczki,
profili producenta, cache i środowiska. Profil użytkownika i logo do pobrania
przekazano jako osobne artefakty. Nie był to test świeżego Windows.
