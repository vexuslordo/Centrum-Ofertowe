# VexLab 0.4 — raport przyrostu

Data: 2026-11-02. Wersja developerska 0.4.0.dev0.

## Co działa

Filtrowanie po producencie (także nieaktywnym lub brak), łączone z nazwą/SKU,
na Dashboard i Produktach. Odświeżenie zachowuje filtr, sortowanie i wybór
Produktu po ID, o ile pozostaje w wynikach. Szczegóły pokazują pełny opis
(przycisk/Enter); dwuklik nadal edytuje.

Eksport CSV zapisuje migawkę widocznych, posortowanych wyników w tle. Format:
UTF-8 z BOM, średnik, cytowane pola; nazwa, SKU, opis, producent. Formułopodobne
pola są poprzedzane apostrofem, liczba zabezpieczeń jest raportowana.
Nie nadpisuje istniejących plików. Anulowanie nie zapisuje; błędy nie udają
sukcesu. Jeśli sprzątnięcie niepełnego pliku się nie powiedzie, komunikat
wskazuje niekompletny plik. CSV nie jest kopią bazy ani formatem importu.

## Architektura i dane

Port eksportu w przypadkach użycia, adapter CSV, składanie w bootstrap,
I/O poza GUI. Siedem kontraktów importów zachowanych. Bez nowych zależności.
Schemat 2 pozostaje bez zmian względem 0.3; adapter SQLite i domena Produktu
porównane bajtowo z dostarczoną paczką 0.3. Wzorzec UI również bez zmian.
Domyślne miejsce danych i preferencji pozostaje to samo. Nowa baza bez seedów.
Przejście z 0.2 nadal korzysta z istniejącej migracji 1→2 z kopią.

## Sprawdzenia

Linux, CPython 3.13.18, PySide6/Qt 6.12.0, uv 0.13.6.
Pełne scripts/check.py: ruff check/format, mypy strict (27 plików),
import-linter (7 kontraktów), bandit, 115 testów i diagnostyka — sukces.
Testy obejmują łączenie filtrów, podgląd z klawiatury, zachowanie wyboru,
migawkę eksportu przy zmianie filtrów, Unicode, cytowanie, formuły,
anulowanie, brak nadpisania i awarie częściowego zapisu/sprzątania.
Wygenerowano zrzuty pustej bazy obu motywów i ekranów Produkty/Producenci.
Zależności nie zmieniły się; nie powtarzano audytu poprzedniego grafu.

## Pozostaje

Rzeczywisty odbiór 0.4 na Windows, DPI i Narrator. Testy Linux/offscreen
nie potwierdzają tych elementów ani wykonania CI. Cały katalog jest
wczytywany do pamięci; duże zbiory wymagają pomiarów i ewentualnej paginacji.
Importy Allegro/PrestaShop, transfer z profilem, kurierzy, oferty, ceny,
magazyn, media, AI, kolejka i analityka pozostają niewdrożone.
ADR-023 zapisuje kierunek przyszłych integracji, ADR-024 decyzje tego przyrostu.
Nie wykonywano push ani publikacji.

## Weryfikacja paczki źródłowej

ZIP rozpakowano do osobnego katalogu /tmp/vexlab04-source/VexLab.
uv sync --frozen --offline utworzył nowe środowisko z lokalnego cache.
Pełne scripts/check.py ponownie zakończyło się sukcesem: 115 testów.
Sprawdzono, że importowany kod i metadane 0.4.0.dev0 pochodzą z rozpakowanej
paczki. To potwierdza odtwarzanie z cache na Linux, nie pobieranie na czystym Windows.
