# VexLab 0.27 — przyciski według dostarczonego wzoru

2026-11-08. Właściciel wskazał wygląd przycisków na screenie „CENTRUM OFERTOWE
5.0”. Wymaganie obejmuje przyciski, nie podmianę logo/nazwy, demonstracyjnych
liczb czy udawanie integracji. Zachowano VexLab i rozwijane grupy menu.

Główne akcje mają niebieski gradient i biały tekst, pomocnicze ciemny panel,
cienki obrys i zaokrąglenie 10–11 px. Wspólne stany hover, pressed, focus
i disabled; jasny motyw zachowuje czytelny kontrast. Etykiety i funkcje
formularzy nie zostały zamienione. Złota barwa logo i grupy nawigacji pozostają;
nowy niebieski akcent zastępuje złote wypełnienie głównych przycisków.

Pasek Dashboard ma ikony i wysokość 50 px. Utwórz nowe oferty ma menu
prowadzące do istniejącej strony wczytania ZIP lub szkiców. Jest dostępny
wyłącznie przy złożonym serwisie paczek. Pobierz z Allegro otwiera istniejący
obszar Allegro i żąda odczytu szkiców bieżącej sesji; bez niej potrzebne jest
połączenie w Ustawieniach. Nie publikuje ofert. Pozostałe niewdrożone akcje
nadal wyłączone; masowa edycja zachowuje warunki dostępności.

Szybkie akcje są kartami z ikoną, tytułem i mniejszym opisem. Ich wybór,
kolejność, dostępność i cele pozostają danymi istniejących preferencji.
Karta nadal jest QPushButton: obsługuje Space, mysz, focus i disabled;
wewnętrzne etykiety nie przechwytują kliknięć. W wąskim widoku tekst się
zawija, wysokość zależy od szerokości. Ikony adaptują się do palety.

Układ danych, schemat 11, zależności, połączenie Allegro i wspólne Ustawienia
→ Integracje (Allegro/Subiekt GT) z 0.26.1 pozostają. Nie dodano nowych danych
biznesowych ani zewnętrznych efektów publikacji.

## Weryfikacja

`scripts/check.py`: 613 testów zaliczonych, jeden natywny test DPAPI pominięty
na Linux. Ruff/format, mypy 84 moduły, siedem kontraktów importów, Bandit
oraz diagnostyka poprawne. Mypy win32 również poprawne. Po dopracowaniu
wysokości i nagłówka kart ponownie zaliczono sześć testów GUI przycisków,
menu paczek i pustego katalogu. Po cztery testy nowych przycisków przy
skalowaniu 125% oraz 150% zaliczone. Testy sprawdzają klawiaturę, mysz,
disabled i zawijanie tekstu, a także nawigację menu bez importu danych.

Obejrzano Dashboard i Produkty 1536×1024 w obu motywach oraz małe okno
900×700. Zrzuty `docs/screenshots/vexlab-buttons-027-*.png` korzystają z pustej
tymczasowej bazy i nie pokazują fikcyjnych wyników sprzedaży. Audyt zależności
runtime/dev bez znanych podatności w chwili sprawdzenia; wheel/sdist zbudowane
offline. Natywny odbiór Windows i audyt UX 1.0 nadal osobno.
