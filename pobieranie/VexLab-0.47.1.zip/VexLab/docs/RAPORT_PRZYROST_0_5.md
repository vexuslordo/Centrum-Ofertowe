# VexLab 0.5 — raport przyrostu

Data: 2026-11-02. Wersja developerska 0.5.0.dev0.

## Co działa

Import XLSX i CSV UTF-8: wybór arkusza, wiersza nagłówków, kolumn nazwy/SKU
i opcjonalnego opisu oraz producenta paczki. Podgląd całości, numery
wierszy, powody problemów i lista pomijanych kolumn. Wybór checkboxami,
ponowna walidacja i atomowy zapis Produktów oraz odłożonych wierszy.
Wstępnie zaznaczone wyłącznie pozycje bez konfliktów. Można świadomie
wybrać jeden rekord z grupy duplikatów albo odłożyć całą paczkę.

Trwała lista Do poprawy: korekta z zapisem na później, dodanie poprawionego
Produktu, jawne przypisanie do istniejącego Produktu o zgodnym SKU bez
nadpisania danych. Kontrola wersji bufora i zapis powiązania zapobiegają
ponownemu rozstrzygnięciu tej samej pozycji. Dane po zatwierdzeniu paczki
pozostają po restarcie. Sam odczyt/podgląd nie zapisuje planu.
Wejścia: Cenniki, przyciski na Produktach i w formularzu dodawania oraz
Import z cennika na Dashboard. Komunikaty podają rzeczywisty wynik.

## Dane, architektura i bezpieczeństwo

Schemat 3 dodaje techniczne tabele procesu importu. Stare SCHEMAT 1
i MIGRACJA_2 wraz z sumami porównano z wydanym ZIP 0.4 — bez zmian.
Dotychczasowe dane są zachowane; kopia przed migracją. Testy przerwania
migracji 2→3 i braku kopii potwierdzają brak częściowego schematu.
Wersje 0.2–0.4 nie obsługują schematu 3; powrót wymaga starej kopii
w oddzielnym katalogu. Procedura: DANE_I_KOPIE.md.

Sześć warstw zachowane, porty w przypadkach użycia, parser i SQL w adapterach,
bootstrap składa zależności. I/O i walidacja planu poza GUI. Nie zmieniono
reguł Produktu/Producenta ani 16 głównych pojęć. Nowa baza bez seedów.
Oryginalny obraz referencyjny pozostaje bez zmian.

XLSX odczytywany bez wykonywania formuł/makr i bez pobierania zewnętrznych
arkuszy. Defusedxml 0.7.1 przypięto do runtime; DTD i encje zakazane.
Limity pliku/ZIP/arkuszy/wierszy/komórek; opis ograniczeń w ADR-027.
Nie odtwarzamy formatowania liczbowego: wybrane pola numeryczne i formuły
odkładamy do świadomej korekty. Bufor zachowuje mapowane dane i pochodzenie,
nie pełny plik ani pominięte kolumny.

## Sprawdzenia

Linux, Python 3.13.18, PySide6/Qt 6.12.0, uv 0.13.6.
Pełne scripts/check.py: ruff check/format, mypy strict (31 plików),
import-linter (7 kontraktów), bandit, 144 testy i diagnostyka — sukces.
Testy obejmują atomowość paczki i korekty, równoległy konflikt SKU,
deaktywację producenta, trwałość, wersjonowanie, brak nadpisania przy
powiązaniu, mapowanie innych kolumn, tekstowe zera, formuły, DTD/encje,
uszkodzony plik, anulowanie, błędy, klawiaturę i pracę poza wątkiem GUI.
Sprawdzono oba motywy i okno 800×620 (z przewijaniem kreatora),
wygenerowano zrzuty pustej bazy dla importu, Dashboard, Produktów i Producentów.
To nie odbiór Windows/DPI/Narratora ani pełny odbiór UI-REF-01.
Audyt pełnych przypiętych grafów runtime i dev przez scripts/audit.py:
nie znaleziono znanych podatności. uv lock --check --offline potwierdza blokadę.

Przesłany XLSX Evotech sprawdzono rzeczywistym nowym czytnikiem i przypadkiem
użycia na tymczasowej bazie: 2396 wierszy, 2373 dodane, 23 Do poprawy
(przy domyślnym wykluczeniu obu wierszy każdej grupy duplikatów). Liczba
Produktów i odłożonych pozycji po zapisie zgodna. Pliku właściciela nie
umieszczono w źródłowej paczce ani fixture'ach; nie testowano na jego bazie.

## Pozostaje

Odbiór 0.5 na Windows, DPI i Narrator. Dalszy zakres: ceny/Cenniki jako
model, EAN, dopasowania do motocykli, kategorie PrestaShop i publikacja
na Allegro/PrestaShop, kurierzy i dokumenty Subiekta. API katalogów
dostawców i producentów zapisano w ADR-028 jako przyszły zakres — właściciel
nie wybrał jeszcze partnera. Nie utworzono pustych konektorów.
Import nie aktualizuje automatycznie istniejących produktów. Powiązania
różnych kodów/aliasów wymagają osobnej reguły. Nie obsługuje XLS/PDF/ODS/XLSM
ani dowolnej wizualnej struktury Excela. Wszystko w pamięci, z limitami.
Nie wykonano push, publikacji aplikacji ani CI.

## Weryfikacja ZIP

Paczkę rozpakowano do /tmp/vexlab05-source/VexLab. Nowe środowisko
utworzono przez uv sync --frozen --offline z lokalnego cache.
Pełne scripts/check.py ponownie zakończyło się sukcesem: 144 testy
i wszystkie kontrole. Sprawdzono, że importowany kod i metadane 0.5.0.dev0
pochodzą z rozpakowanego katalogu. ZIP bez baz użytkownika i źródłowego XLSX.
To odtworzenie na Linux z cache, nie test pobierania na czystym Windows.
