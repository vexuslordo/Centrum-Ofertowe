# VexLab 0.33 — ekran Allegro według nowej referencji

Nagłówek z logotypem i kontem, ostatni odczyt, pięć kafelków podsumowań,
zakładki stanów, wyszukiwanie, filtry, pasek akcji, tabela, wybór checkboxami,
stronicowanie oraz prawy panel szczegółów. Panel pobiera aktualny szkic po
zaznaczeniu; pełny opis dostępny przyciskiem lub aktywacją wiersza.
Zmiana wyboru i sesji odrzuca spóźnione odpowiedzi. Zdjęcia tylko widocznych
wierszy, przez istniejący ograniczony podgląd obrazów. Przy wąskim oknie
ukrywane są dodatkowe statystyki/filtry i panel boczny; podgląd dialogowy zostaje.

Działające API: odczyt INACTIVE, ich liczba, SKU, źródłowa cena, dostępność
oraz miniatura z odpowiedzi listy; pełny podgląd szczegółów i opisu. Nie ma
wygenerowanych rekordów w instalacji ani demonstracyjnych metryk.
Wyszukiwanie jest lokalnym filtrem pobranej strony. Zaznacz wszystko obejmuje
tylko szkice tej strony. Kategoria i producent są na razie niedostępne.

Zakładki innych stanów, sprzedaż/obrót, kafelki/kanban i operacje zapisu
pozostają zablokowane do wdrożenia odpowiadających procesów Allegro API.
Nie jest to pełne wdrożenie funkcji biznesowych widocznych w referencji.
Nowa oferta/Importuj otwierają lokalne przygotowanie ZIP, bez tworzenia
Produktów w katalogu lub Subiekcie. Ustawienia połączenia są nadal w Integracjach.
Zawiera również zmiany kart integracji i nagłówka z 0.32.

[ADR-056](adr/ADR-056-przestrzen-allegro.md). Schemat 11 i zależności bez zmian.
Testy i zrzuty mają dane syntetyczne; nie potwierdzono odbioru produkcyjnego
konta właściciela ani natywnego wyglądu Windows z tego środowiska.

## Weryfikacja

Pełny scripts/check.py: 662 testy zaliczone, 1 pominięty (natywne DPAPI
wymaga Windows), ruff/format, mypy 92 moduły, 7 kontraktów, Bandit i diagnostyka
bez błędów. Po doprecyzowaniu miniatur i czyszczenia wyboru: ponownie 64 testy
obszaru Allegro/API/obrazów; nowy test potwierdza przechowywanie miniatury zamiast
pełnego zdjęcia w tabeli. 17 testów GUI przy 150% skalowania i mypy win32 poprawne.
Podgląd obejrzano w obu motywach i przy 900×700; dane zrzutów są syntetyczne.
Bez nowych zależności i bez poleceń zapisu na produkcyjnym koncie Allegro.
