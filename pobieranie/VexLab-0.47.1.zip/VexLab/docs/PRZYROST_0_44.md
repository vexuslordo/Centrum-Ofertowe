# VexLab 0.44 — VAT według krajów

W oknie nowych szkiców zaznacz oferty z tej samej kategorii i wybierz
**VAT według krajów…**. Produkty i kategorie muszą być wcześniej przygotowane.

1. Pobierz stawki z Allegro. Program odczytuje dopuszczalne kraje, stawki,
   przedmiot opodatkowania i podstawy zwolnienia dla kategorii.
2. Zaznacz obsługiwane kraje. Dla każdego wybierz stawkę lub wpisz ją ręcznie
   (np. `23,00`). Program sprawdzi wartość z metadanymi Allegro.
3. Możesz podać ID własnej oferty z tej samej kategorii i użyć
   **Pobierz VAT z oferty**. Kopiowane są wyłącznie dane VAT.
4. Uzupełnij wymagany przedmiot opodatkowania i ewentualną podstawę zwolnienia.
   Zastosuj ustawienia, następnie ponownie **Sprawdź paczkę**.
5. Utwórz zaznaczone szkice. Program przesyła `taxSettings` i potwierdza zapis
   odczytem szkicu. Publikacja do sprzedaży pozostaje osobną akcją.

Kraje wskazuje użytkownik: lista API nie oznacza aktywnych rynków konta.
Ustawienie VAT nie aktywuje rynków, nie przelicza cen brutto i nie wybiera
stawki podatkowej za użytkownika. Bez zaznaczenia stosowania VAT pole nie
jest wysyłane. Ustawienia dotyczą wskazanych nowych szkiców; nie zmieniają
istniejących ofert. SKU, EAN i ceny pozostają indywidualne.

Odczyty działają w tle z ponowieniem i kontrolą bieżącego konta. Błąd
potwierdzenia VAT zachowuje rejestr wysyłki i nie powoduje drugiego POST.
Bez migracji bazy i nowych zgód OAuth. Zachowano logo i miniatury.

Testy obejmują różne stawki krajowe, ręczne wartości, zwolnienia, kopiowanie,
błędy API, zmianę sesji, trwałe potwierdzanie i ochronę przed powtórnym POST.
Podglądy na danych syntetycznych (nie zalecenie podatkowe):
[ciemny](screenshots/vexlab-vat-044-dark.png),
[jasny](screenshots/vexlab-vat-044-light.png).
