# VexLab 0.30.9 — mocniejsze przyciemnienie

Gradienty sekcji menu i kafelków KPI są dodatkowo przyciemnione o 25%
względem 0.30.8. Odcienie i biały tekst zachowane; bez zmian danych i schematu.
