# VexLab 0.7 — lokalna galeria produktu

2026-11-03. Kontynuacja roadmapy mediów, ADR-032. Dodawanie zdjęć z dysku,
duży podgląd, kolejność, usuwanie i czyszczenie galerii, pierwsze zdjęcie
jako miniatura. Do 5 zdjęć; JPG/PNG/WebP, do 8 MiB i 16 mln pikseli na wejściu.
Pliki normalizowane do JPEG do 1600 px, miniatury do 96 px.

W Produkty zaznacz dokładnie jeden wiersz i wybierz „Galeria zaznaczonego
produktu…”. Menu „Zdjęcia i media” prowadzi do tego samego katalogu.
Dodaj pliki, uporządkuj, zapisz. Zmiany robocze można anulować. Usunięcie
wszystkich zdjęć i odrzucenie niezapisanych zmian wymagają potwierdzenia.
Podczas odczytu/zapisu okno pokazuje stan i blokuje zamknięcie.

Zapis transakcyjny pod kontrolą wersji Produktu. Kopia SQLite w kopie_zdjec
powstaje przed zmianami. Konflikt wymaga ponownego otwarcia galerii po
odświeżeniu katalogu. Błąd nie kasuje wcześniejszych zdjęć. Nazwa, SKU, opis,
producent i cena pozostają zachowane. Schemat 4 i zależności bez zmian.
Przed ewentualnym przywróceniem kopii zamknij aplikację, zachowaj bieżącą
bazę osobno i przywróć kopię jako katalog.sqlite3 w tym samym katalogu danych.

Weryfikacja: testy na rzeczywistej tymczasowej SQLite sprawdzają kolejność,
miniaturę, czyszczenie, integralność kopii, konflikt i wycofanie niepełnego
zapisu. Testy plików odrzucają HTML, przekroczenie limitu i brak dostępu.
Testy Qt sprawdzają roboczą kolejność, potwierdzenia i blokadę zamknięcia;
dodatkowy scenariusz przechodzi przez okno główne, wybór pliku, zadania w tle,
zapis oraz odświeżenie miniatury. Wszystkie dane są syntetyczne.

Odbiór 0.7 na Windows, przy różnych DPI i z czytnikiem ekranu pozostaje
otwarty. Nie wykonywano pobierania rzeczywistej witryny producenta ani
płatnych wywołań. Masowe pobieranie zdjęć i integracje nadal przyszłe.

Wynik kontroli: scripts/check.py zakończony poprawnie — 203 testy,
ruff check/format, mypy (39 plików źródłowych), 7 kontraktów importów,
bandit i diagnostyka. Następnie dodatkowy test pełnego przepływu galerii
przez okno główne również przeszedł (łącznie 204 sprawdzone testy).
uv sync --frozen --offline oraz uv lock --check --offline zakończone poprawnie.
Zależności zewnętrzne bez zmian, bez ponownego audytu tego samego grafu.
Obejrzano zrzuty galerii z syntetycznym obrazem w obu motywach w Qt offscreen;
nie zastępuje to odbioru na Windows.

Paczka źródłowa została rozpakowana osobno. Potwierdzono ścieżkę importu
z jej src i uruchomiono z niej 7 testów galerii (SQLite, Qt i pełny przepływ)
— wszystkie przeszły. Sprawdzono CRC i brak baz, XLSX, cache oraz środowiska
w ZIP. Testy używały istniejących przypiętych zależności; nie był to test
nowej instalacji na Windows.
