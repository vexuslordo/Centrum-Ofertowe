# VexLab 0.33.1 — kolorowe kafelki Allegro

Całe kafelki podsumowań mają gradienty odpowiadające ikonom: aktywne — zielony,
szkice — niebieski, błędy — czerwony, sprzedano — fioletowy, obrót — złoty.
Białe nagłówki/liczniki i jasne podpisy zachowują czytelność w obu motywach.
Zmiana dotyczy wyłącznie wyglądu; dane, uprawnienia i działania API bez zmian.
