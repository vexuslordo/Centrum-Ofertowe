# VexLab 0.9 — import dopasowań z cennika

2026-11-03. Kontynuacja po potwierdzeniu przez właściciela działania 0.8.
Zakres: jawne mapowanie kolumn istniejącego modelu dopasowań (ADR-033/034).

## Użycie

Cenniki → Wybierz plik → wskaż arkusz i nagłówki → nazwa oraz SKU.
Zaznacz „Importuj dopasowanie do motocykla (opcjonalne)”. Wskaż kolumny
marki/modelu, a jeśli są w pliku — roczników od/do oraz wariantu.
„Sprawdź i pokaż podgląd” pokazuje również dopasowania. Dwuklik otwiera
pełny podgląd wiersza. Zatwierdzenie zapisuje zaznaczone wiersze;
pozostałe trafiają do Do poprawy z surowymi wartościami do korekty.

Mapowanie jest domyślnie wyłączone. Nie trzeba go włączać dla uniwersalnego
lub pozostałego asortymentu. Jeśli wszystkie wskazane pola w wierszu są
puste, Produkt nie dostaje dopasowania. Częściowe dane oraz błędne roczniki
są wykluczane z domyślnego wyboru. Dane z tytułu nie są odgadywane.

Jedno dopasowanie na wiersz pliku; powtarzające się SKU nie są scalane.
Wiele motocykli przy Produkcie można dopisać w edytorze dopasowań,
także w formularzu Do poprawy. Jeśli plik ma wyłącznie markę motocykla,
a model/roczniki są w tytule, ten przyrost nie rozbija automatycznie tytułu.
Można zachować go w opisie i później ręcznie uzupełnić dopasowania.

W Do poprawy otwórz wiersz → Pasuje do motocykli… → popraw dane →
Zapisz poprawki na później lub Dodaj poprawiony Produkt do katalogu.
Szkic może pozostać niekompletny; dodanie do katalogu wymaga walidacji.
Powiązanie z istniejącym SKU nie nadpisuje Produktu ani jego dopasowań;
komunikat w edytorze wyjaśnia różnicę przed operacją.

## Zapis i aktualizacja

Zapis nowego Produktu, dopasowań, ceny i powiązania importu jest atomowy.
Niepoprawne roczniki i puste pola są przechowywane jako dane robocze,
aby nie zgubić ich po zamknięciu programu. Nie są dopasowaniami katalogowymi
przed potwierdzonym dodaniem Produktu.

Schemat 6 dodaje jedną kolumnę w import_robocze; migracje 1–5 bez zmian.
Kopia w kopie_migracji powstaje przed aktualizacją istniejącej bazy.
Produkty i ich wcześniejsze dopasowania pozostają zachowane. Błąd migracji
lub brak możliwości wykonania kopii blokuje aktualizację, bez resetowania.

Powrót do 0.8: zamknij aplikację, zachowaj aktualny katalog.sqlite3 osobno,
przywróć kopię schematu 5 w katalogu danych jako katalog.sqlite3. Kopia nie
zawiera zmian dokonanych po aktualizacji do 0.9. Starsza aplikacja odrzuca
schemat 6, dlatego sam powrót do starszych plików programu nie wystarczy.

## Weryfikacja i ograniczenia

Testy: poprawny i niepełny wiersz, brak dopasowań, złe mapowanie, rocznik
liczbowy i formuła XLSX, restart bufora, korekta do wielu dopasowań,
powiązanie bez nadpisania, rollback paczki i uszkodzony JSON bufora.
Migracja: fixture schematu 5 z wydanego ZIP 0.8, zachowanie wcześniejszych
dopasowań i pozycji roboczych, kopia i jej odtworzenie, przerwanie DDL,
brak kopii i niezgodny checksum. Test Qt przechodzi przez mapowanie,
podgląd, zapis, korektę szkicu i dodanie poprawionego Produktu.

Nie wykonywano publikacji do Allegro lub PrestaShop, automatycznej analizy
tytułów ani płatnych wywołań. Zależności zewnętrzne bez zmian. Odbiór nowego
przepływu na Windows, DPI i z Narratorem pozostaje do wykonania.

Wynik scripts/check.py: 241 testów przeszło, ruff check/format,
mypy (40 plików), 7 kontraktów importów, bandit i diagnostyka poprawne.
uv sync --frozen --offline i uv lock --check potwierdziły zgodność.
Porównanie stałych migracji 1–5 z wydanym ZIP 0.8 potwierdziło ich identyczność.
Nie powtarzano audytu niezmienionego grafu zależności zewnętrznych.

Po zwinięciu opcjonalnych pól motocykla przy wyłączonym mapowaniu ponownie
uruchomiono 10 testów GUI importu — wszystkie przeszły. Obejrzano widok
w obu motywach (Qt offscreen); kontrolki pozostają dostępne przez przewijanie.
ZIP rozpakowano osobno, potwierdzono import z jego src oraz uruchomiono
16 nowych testów importu dopasowań, migracji i GUI — wszystkie przeszły.
CRC poprawne; paczka bez baz, źródłowych XLSX, środowiska i cache.
Użyto istniejących przypiętych zależności, bez deklaracji świeżej instalacji Windows.
