# VexLab 0.43.2 — lokalizacja konta i czytelny wybór numeru katalogowego

## Lokalizacja nadania

Polecenie właściciela: nie wymagać adresu, który Allegro pobiera z konta.
Domyślnie w Dostawie są cennik, czas wysyłki i informacja o korzystaniu
z lokalizacji konta. Cztery pola adresu są ukryte pod **Podaj inną lokalizację
(opcjonalnie)**. Bez nadpisania POST nie zawiera `location` — nie wysyła
pustego obiektu, null ani domyślnego/zgadywanego adresu. Allegro stosuje dane
konta; nie kopiujemy adresów z innych ofert ani nie pobieramy zbędnych danych.

Kontrakt sprawdzono w oficjalnym poradniku Allegro: „Jeżeli wysyłasz
przedmioty z innego adresu, niż przypisany do twojego konta” — wówczas należy
przekazać location. [Źródło](https://developer.allegro.pl/tutorials/jak-jednym-requestem-wystawic-oferte-powiazana-z-produktem-D7Kj9gw4xFA#jak-ustawic-wlasny-adres-z-ktorego-wysylany-jest-przedmiot).

Własna lokalizacja nadal wymaga poprawnego, pełnego adresu. Dawne wypełnione
ustawienia otwierają tę opcję jako zaznaczoną, bez utraty danych. Odznaczenie
nie usuwa wpisanego tekstu w otwartym formularzu, ale przy zastosowaniu
wybiera lokalizację konta. GET może zawierać adres wypełniony przez Allegro;
nie porównujemy go do pustych pól klienta. Gotowość nadal wymaga walidacji
Allegro — brak prawidłowych danych konta może wymagać uzupełnienia w Allegro.

Bez nowych pól DTO i zmian repr dawnych ustawień. Odciski wcześniejszych
prób, rejestry i schemat 11 zachowane. Nie nadpisuje istniejących szkiców.

## Numer katalogowy części

Polecenie właściciela: jawny wybór ręczny lub z paczki, także dla masowej
wysyłki. Przy numerze katalogowym/kodzie producenta pojawia się widoczny
wybór **Z paczki — SKU każdego produktu** albo **Wpisz ręcznie**. Nie trzeba
otwierać opcji zaawansowanych. W edycji masowej ręczny tryb jest opisany
jako wspólna wartość dla zaznaczonych pozycji; indywidualna edycja pozostaje
dostępna. Wybranie trybu albo wpisanie tekstu zaznacza pole do zmiany,
a wyłączenie checkboxa nadal pozwala pominąć ten parametr w grupie.

Tryb z paczki pobiera SKU każdego wiersza, nie numer pierwszego produktu.
Nie kopiuje EAN ani innych parametrów. Dawne świadomie wybrane źródło EAN
dla kodu pozostaje widoczne jako wcześniejsze ustawienie. Inne źródła
parametrów nadal dostępne w Zaawansowane. Rozpoznawanie semantyczne nazw
bez zaszywania identyfikatora kategorii, marki lub danych paczki.

## Kontrola

Regresje obejmują pustą lokalizację i brak location w żądaniu, uzupełniony
adres w odpowiedzi, akceptację transportu bez nadpisania adresu, zachowanie
ręcznych i częściowych adresów, domyślnie ukryte pola oraz oba tryby numeru
katalogowego na grupie o różnych SKU. Oryginalny ZIP, lokalne Produkty,
logo, miniatury i publikacja osobno bez zmian. Testy na kontrolowanych
odpowiedziach; brak zapisów na rzeczywistym koncie właściciela.

Wyniki wydania: scripts/check.py — 927 testów zaliczonych, 1 pominięty
(natywne DPAPI Windows); ruff/format, mypy 110 modułów, 7 kontraktów
importów, bandit i diagnostyka poprawne. Audyt runtime i dev: brak znanych
podatności. 54 testy GUI przy QT_SCALE_FACTOR=2 zaliczone, oba motywy
sprawdzone na danych syntetycznych. Naprawiono także wejście do parametrów
masowych, gdy zaznaczone są wiersze, ale brak aktywnej komórki (np. po
„Zaznacz widoczne”). Przygotowanie i sygnatury nie wykonują publikacji.
