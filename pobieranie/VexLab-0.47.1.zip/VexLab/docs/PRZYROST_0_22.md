# VexLab 0.22 — strony katalogu

2026-11-07. Kontynuacja roadmapy na polecenie właściciela. Wersja 0.22.dev0,
schemat 11 bez migracji i nowych zależności. ADR-050.

## Obsługa

Pod tabelami katalogu pojawia się pasek Poprzednia / licznik zakresu /
liczba rekordów / Następna. Domyślnie 100, do wyboru 250 lub 500 na stronę.
Dashboard, Produkty, Zdjęcia i media oraz Masowa edycja dzielą filtr i stronę.
Wyszukiwanie i sortowanie obejmują cały katalog, również niewczytane rekordy.
KPI i liczniki pokazują cały zakres, a pasek stron — bieżący fragment.

Przejście na inną stronę zachowuje wybór. Ctrl/Shift rozszerza go; zwykłe
kliknięcie rozpoczyna nowy. Widoki mają osobne zaznaczenia. Licznik obejmuje
też inne strony. Odznacz/Escape czyści cały wybór widoku. Nowy filtr czyści
wybór i wraca na początek. PPM w grupie zachowuje grupę; poza nią wybiera
tylko kliknięty Produkt. Podczas odczytu zakresu akcje zmiany są blokowane.

Zaznacz wszystkie / Ctrl+A nadal obejmuje wszystkie wyniki filtra.
Eksport i Usuń wszystkie wyniki także działają na wszystkich stronach,
z pełnym zestawem odczytanym przed zatwierdzeniem/zapisem. Usuwanie z kopią,
kontrola wersji i atomowe zapisy pozostają. Błąd pełnego odczytu nie wybiera
ani nie zapisuje części zestawu. Po usunięciu ostatniej strony program
koryguje numer do ostatniej dostępnej.

## Odczyt i ograniczenia

SQLite wybiera posortowane klucze z LIMIT/OFFSET w jednej migawce odczytu.
Pełne opisy/dopasowania pobierane są dla bieżącej strony i jawnie wybranych
rekordów, a nie całego katalogu przy starcie. Miniatury pozostają na żądanie
według 0.21. Pełny zestaw pobierany dopiero dla jawnej operacji obejmującej
wszystkie wyniki. Taki wybór nadal potrzebuje odpowiednio większej pamięci.

Nie jest to konektor Subiekta GT, Allegro lub PrestaShop. Stronicowanie
Cenników i przygotowanie rzeczywistego dostępu GT pozostają osobnymi etapami.
Nie zmniejsza istniejącej bazy i nie usuwa zdjęć/kopii. Odbiór natywnego
Windows oraz audyt UX 1.0 nadal są odrębnymi pracami.

## Weryfikacja

Testy porównują strony z pełnym zbiorem, globalny filtr/sortowanie,
literalne znaki i Unicode, ograniczenie liczby DTO, wybrane wersje spoza
strony, błędy i numer po usunięciu. Testy GUI obejmują wybór między stronami,
PPM, eksport całego wyniku i usuwanie wszystkich stron. Regresja edycji
masowej nadal sprawdza 2375 Produktów, kontrolę wątku, kopię i odtworzenie
zaznaczeń bez emisji sygnału dla każdego rekordu.

Dotychczasowe testy formularzy/filtrów czekają na odczyt w tle. Fixture Qt
odczekuje zakończenie zadań przed automatycznym zamknięciem okna, także
przy niepowodzeniu asercji. Nie wyciszamy wyjątków po usunięciu obiektów.

## Pomiar syntetyczny i wyniki końcowe

Baza tymczasowa: 2000 produktów, każdy z opisem 16 384 znaków. Pełny odczyt
zawierał 2000 DTO / 32 768 000 znaków opisów; strona zawierała 100 DTO /
1 638 400 znaków. Szczyt alokacji Python (`tracemalloc`) wyniósł około
34,2 MB dla pełnego odczytu i 1,74 MB dla strony. To jeden syntetyczny
scenariusz, nie RAM całego Qt ani test miliona kartotek/instalacji GT.

`scripts/check.py`: **510 testów zaliczonych**, ruff i format bez uwag,
mypy poprawne (70 modułów), siedem kontraktów importów, Bandit i diagnostyka
bez błędów. Przy skalowaniu 125% i 150% zaliczono po 26 testów okna/stron.
Audyt pełnych zależności runtime i dev: brak znanych podatności w chwili
sprawdzenia. Wheel/sdist zbudowane offline. Schemat i opublikowane migracje
porównane AST z 0.21 — identyczne.

Obejrzano zrzuty 1536×1024 w ciemnym/jasnym motywie i małe okno 900×700.
Pasek stron mieści się w obszarze pracy. Dane i kolorowe obrazy TEST
pochodzą wyłącznie z tymczasowej bazy wizualnej, nie seedów aplikacji.
Zrzuty: `docs/screenshots/vexlab-strony-katalogu-022-*.png`.
Testy wykonane na Linux/Qt offscreen; natywny odbiór Windows nadal osobno.
ZIP weryfikowany przez CRC, wykluczenie baz/środowiska/sekretów i testy
po rozpakowaniu.
