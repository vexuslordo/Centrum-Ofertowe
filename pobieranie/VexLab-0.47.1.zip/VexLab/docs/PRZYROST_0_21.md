# VexLab 0.21 — miniatury katalogu na żądanie

2026-11-07. Kontynuacja roadmapy po potwierdzeniu działania 0.20.4 przez
właściciela. Wersja 0.21.dev0. Schemat 11 bez migracji i zmian zależności.

## Co się zmieniło

Dashboard, Produkty, Zdjęcia i media oraz Masowa edycja nie wczytują już
wszystkich miniatur katalogu przy odświeżeniu. Pobierane są metadane zdjęć,
a same miniatury tylko dla widocznych wierszy. Jeden odczyt w tle, do 32
ID/wersji naraz. Przewijanie i zmiana sortowania dobierają aktualne wiersze.
Odczyt miniatury nie pobiera pełnego zdjęcia z galerii i nie korzysta z sieci.

Osobny cache w pamięci jest ograniczony do 128 wpisów / 8 MiB szacowanego
kosztu obrazów i czyszczony przy odświeżeniu katalogu. Nie jest limitem RAM
całej aplikacji. Zamknięcie zatrzymuje planowanie nowych partii. Błąd lub
uszkodzone zdjęcie ma wyjaśnienie w podpowiedzi, bez pętli ciągłych odczytów.
Odśwież ponawia próbę. Szczegóły wyświetlają tekst od razu, a zdjęcie w tle.

Zaznaczanie wszystkich wyników i operacje masowe pozostają niezależne od
wczytania obrazów. Seria pobierania ze strony producenta nadal pomija Produkty
mające zdjęcia; nie wymaga załadowania ich miniatur do tabeli. Galerie,
cenniki, szkice, eksport i preferencje zachowane. Szczegóły: ADR-049.

## Ograniczenia i następne kroki

Samych tekstowych rekordów katalogu nie stronicujemy jeszcze. Przyrost
realizuje część planu zdjęć na żądanie i ograniczonego cache, przygotowując
przeglądanie dużego katalogu GT. Nie jest połączeniem z Subiektem, Allegro
lub PrestaShop. Nie zmniejsza zapisanej bazy i nie usuwa kopii/zdjęć.
Retencja kopii nadal wymaga ustalenia. Audyt UX kandydata 1.0 pozostaje osobno.

## Weryfikacja

Nowe testy używają prawdziwej tymczasowej bazy oraz tabeli z 1000 syntetycznych
produktów ze zdjęciami. Sprawdzają ograniczoną partię, brak BLOB w odczycie
listy i brak I/O w `data()`, selekcję wszystkich, przewijanie, sortowanie
w trakcie odczytu, spóźniony wynik po odświeżeniu/zamknięciu, błędy bez pętli,
limity cache, wersję galerii i rzeczywisty odczyt poza wątkiem Qt.

## Pomiar syntetyczny

Na tymczasowej bazie 2000 produktów, każdy z miniaturą JPEG 128×128
(9323 bajty), pełny odczyt zawierał 18 646 000 bajtów miniatur. Odczyt
listy GUI zawierał 0 bajtów obrazów; późniejsza partia 20 widocznych produktów
pobrała 186 460 bajtów. `tracemalloc` pokazał szczyt alokacji Python około
20,6 MB dla pełnego odczytu i 1,88 MB dla listy bez BLOB. To pomiar jednego
syntetycznego scenariusza, nie RAM całego procesu, test Subiekta ani milionów
kartotek. Definicje opublikowanego schematu i migracji porównane AST z 0.20.4:
identyczne.

## Wyniki końcowe

`scripts/check.py`: **497 testów zaliczonych**, ruff i format bez uwag,
mypy poprawne (68 modułów), siedem kontraktów importów, Bandit oraz
izolowana diagnostyka bez błędów. Przy skalowaniu 125% i 150% zaliczono
po 25 testów okna/miniatur/odświeżenia galerii. Audyt pełnych zależności
runtime i dev: brak znanych podatności w chwili sprawdzenia. Wheel/sdist
zbudowane offline. Schemat i opublikowane migracje identyczne z 0.20.4.

Testy przeprowadzono na Linux/Qt offscreen z danymi syntetycznymi.
Nie są odbiorem integracji GT ani pomiarem na komputerze użytkownika.
ZIP sprawdzany przez CRC, wykluczenie baz/środowiska/sekretów i testy
po rozpakowaniu. Audyt UX wersji 1.0 nadal pozostaje zaplanowany.
