# VexLab 0.30.4 — producenci bez poziomego przewijania

Usunięto obszar przewijania producentów. Szerokość rzeczywistych przycisków
wyznacza liczbę widocznych producentów; pozostałe nazwy są w menu Więcej.
Przycisk Więcej pozostaje w całości widoczny, także po zmianie rozmiaru okna.
Testy w obu motywach: 1300/760/500/420 px i powrót do szerokiego panelu;
każdy producent jest dostępny na pasku albo w menu, bez duplikatów.
Wyszukiwarka pozostaje po prawej. Schemat i zależności bez zmian.
