# Import produktów — VexLab 0.6

1. Jeśli producent nie istnieje, dodaj go w menu Producenci.
2. Otwórz Produkty → Importuj produkty z pliku albo menu Cenniki.
3. Wybierz plik XLSX lub CSV UTF-8.
4. Wybierz arkusz i numer wiersza z nagłówkami, potem kolumny nazwy i SKU
   oraz opcjonalnie opisu. Wybierz producenta dla paczki albo Brak producenta.
5. Sprawdź listę pomijanych kolumn. Opcjonalną cenę sugerowaną wybierz
   osobno z walutą i netto/brutto; EAN i strukturalne dopasowania nie są importowane. Podgląd próbki obejmuje tylko 10 wierszy;
   właściwy podgląd importu sprawdza wszystkie wiersze poniżej nagłówków.
6. Kliknij Sprawdź i pokaż podgląd. Zaznaczone pozycje zostaną dodane
   do katalogu, niezaznaczone zachowane na osobnej liście Do poprawy.
7. Sprawdź wybór, następnie kliknij Zapisz wybrane, pozostałe odłóż do poprawy.
   Samo wybranie pliku lub podgląd niczego nie zapisuje.

## Dla przesłanego przykładu Evotech

Arkusz EVOTECH, nagłówki w wierszu 1, nazwa = kolumna 2 (Title),
SKU = kolumna 5 (KOD), opis = pomiń, producent = Evotech (dodany przez Ciebie).
Nagłówek MARKA oznacza markę motocykla, nie producenta części.
Pozostaje pominięty wraz z cenami; nie przypisuj go jako opisu lub producenta.
Na pustej bazie próbka daje 2373 gotowe pozycje i 23 do poprawy.
Twoja baza może mieć dodatkowe konflikty istniejących SKU.

## Poprawianie i przypisanie

Otwórz zakładkę Do poprawy, odśwież, zaznacz wiersz i kliknij
Popraw / przypisz zaznaczony. Widzisz nazwę pliku, arkusz, numer i powód.

- Zapisz poprawki na później: zachowuje robocze dane, nie dodaje Produktu.
- Dodaj poprawiony Produkt do katalogu: sprawdza nazwę, unikalne SKU
  i aktywność producenta, potem dodaje Produkt i usuwa pozycję z oczekujących.
- Powiąż z wybranym Produktem: wybierz istniejący Produkt z listy.
  W tej wersji wymagane jest zgodne SKU (ignorując wielkość liter).
  Powiązanie nie nadpisuje nazwy, opisu ani producenta istniejącego Produktu.

Powtórzone kody nie są automatycznie scalane. Możesz świadomie wybrać jeden
wiersz z grupy do dodania; pozostałe odłożyć, a później jawnie przypisać.
Nie wymyślaj nowego SKU tylko po to, by ominąć konflikt tego samego produktu.
Brak kodu wymaga uzupełnienia poprawnym symbolem. Liczbowe komórki i formuły
w wybranych kolumnach trafiają do korekty — program nie odgaduje zer ani
nie wykonuje obliczeń. Po poprawce zatwierdzasz tekst świadomie.

## Dane i ograniczenia

Lista Do poprawy przetrwa restart, o ile zatwierdzisz zapis paczki. Zamknięcie
samego podglądu nie zachowuje niezatwierdzonego planu. Bufor zachowuje tylko
mapowane pola i pochodzenie, nie cały cennik ani pominięte kolumny.
Kopia katalogu z Ustawień obejmuje także listę Do poprawy i powiązania importu.

Nie obsługujemy XLS/PDF/ODS/XLSM ani dowolnego układu dokumentu Excel.
XLSX: maksymalnie 20 MB pliku, 40 MB po rozpakowaniu, 100 arkuszy,
20000 wierszy łącznie, 256 kolumn i 250000 komórek. CSV: UTF-8, separator
średnik/przecinek/tabulator, wykrywany automatycznie; sprawdź próbkę.
Nieczytelny separator popraw w pliku lub wyeksportuj CSV ze średnikiem.
Interfejs nie wysyła danych do Allegro/PrestaShop ani nie zmienia cen.

## Pełniejszy opis — 0.5.2

Możesz wskazać Opis źródłowy i Dodatkowe dane do opisu oraz zaznaczyć
Dołącz pełną nazwę z pliku do opisu. Podgląd zawiera wynikowy opis;
dwuklik na jego wierszu otwiera cały tekst przed zapisem. Puste fragmenty
są pomijane, identyczne niepowtarzane. Nie jest to tłumaczenie ani
potwierdzenie strukturalnego dopasowania do motocykla.

Dla Evotech: nazwa = Title, SKU = KOD, zaznacz dołączenie pełnej nazwy
do opisu; opcjonalnie jako dodatkową kolumnę wskaż MARKA. Model i roczniki
pozostaną w opisie w takim brzmieniu, jakie mają w Title. Sama MARKA daje
np. Honda, bez modelu. Produkty uniwersalne nie wymagają danych motocykla.

Wcześniejsze Produkty nie są automatycznie zmieniane. Popraw je przez
Edytuj produkt; ponowny import nie nadpisze istniejącego SKU.
Nagłówki cen GBP/EUR/PLN pochodzą z pliku, nie ze stałej konfiguracji programu.
Ceny sugerowane, uzupełnianie ich braków po SKU, wybór i czyszczenie
opisuje aktualna instrukcja [0.6](PRACA_Z_KATALOGIEM_0_6.md).
Automatyczne tłumaczenie nie jest wdrożone.
