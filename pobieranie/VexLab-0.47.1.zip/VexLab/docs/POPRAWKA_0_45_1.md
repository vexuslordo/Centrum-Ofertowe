# VexLab 0.45.1 — czytelny rozmiar okna GPSR

Zgłoszenie właściciela: GPSR/dostawa/warunki otwiera się jako bardzo wąskie
okno, z uciętymi zakładkami i polami. Ręczne powiększenie pomagało.

Formularz otrzymuje teraz minimalny rozmiar 720 × 560 jednostek logicznych
oraz początkowy rozmiar 850 × 730 po zbudowaniu całego układu. Wymiary są
ograniczone dostępną przestrzenią ekranu, z marginesem na ramkę i pasek
zadań. Samo początkowe resize nie zapewniało ochrony przed ściśnięciem.
Nie ustawiamy stałego rozmiaru: okno nadal można powiększać. Mniejszy ekran
zachowuje dostęp do przewijanych formularzy. Zakładki i pobieranie list,
wybory użytkownika, walidacja oraz zapis pozostają bez zmian.

Test regresji próbuje wymusić rozmiar ze zgłoszenia przed i po odczycie API,
sprawdza minimalne wymiary i widoczność wszystkich trzech zakładek w obu
motywach. Uruchomiono także przy skali 200%. Pozostałe okna i dane bez zmian.
Podglądy na danych syntetycznych:
[ciemny](screenshots/vexlab-gpsr-0451-dark.png),
[jasny](screenshots/vexlab-gpsr-0451-light.png).
Nie wykonano odbioru na Windows; testy Qt uruchomiono na Linuksie.
