# VexLab 0.37 — propozycje edycji zdalnych szkiców

**Zakres: przygotowanie zmian i lokalny plik roboczy. Ta wersja nie zapisuje
zmian w Allegro i nie publikuje ofert.** Dokończenie zapisu wymaga dostępu
do bieżącej dokumentacji i potwierdzenia kontraktu obsługi konfliktów.

## Co działa

W Allegro wybierz szkic INACTIVE i „Przygotuj edycję szkicu” w panelu,
menu wiersza lub ikonę ołówka. Program ponownie odczytuje szkic, następnie
otwiera formularz roboczy tytułu i sekcji opisu ze wspólnym edytorem:
formatowanie, układ tekst/zdjęcie, kolejność i podgląd całej treści.
Dla aktywnych ofert przygotowanie jest niedostępne. Lokalne szkice z ZIP
i ich dotychczasowy zapis SQLite pozostają osobnym procesem.

„Zapisz propozycję do pliku…” zapisuje nowy JSON bez nadpisania starego.
„Wczytaj propozycję…” przywraca pracę wyłącznie dla tego samego konta,
środowiska, szkicu i bazowej treści. Plik ma tytuł/sekcje bazowe i robocze
oraz identyfikatory kontekstu. Nie zawiera tokenów ani sekretów aplikacji.
Nie jest gotowym żądaniem API ani pakietem do automatycznej publikacji.

„Sprawdź aktualność w Allegro” wykonuje wyłącznie GET z bieżącą sesją.
Zmiana tytułu/opisu lub utrata stanu INACTIVE daje komunikat konfliktu;
wpisana propozycja pozostaje. Błąd pliku i rozłączenie konta również nie
usuwają pracy. Zamknięcie niezapisanej edycji wymaga odrzucenia, domyślnie Nie.
Po zapisaniu pliku komunikat wyraźnie mówi, że Allegro pozostało bez zmian.

Walidacja formularza/pliku jest robocza: do 1000 znaków tytułu (granica
odczytywanego DTO), do 100 sekcji i dwóch elementów w sekcji, adresy HTTPS,
plik do 2 MiB. **Nie deklaruje to zgodności ze wszystkimi limitami aktualnego
API zapisu**, które nadal trzeba potwierdzić. Otwarcie bez edycji nie
przepisuje HTML źródłowego. Transport API nadal dopuszcza tylko GET i POST
związane z autoryzacją; brak PATCH/PUT i rozszerzenia OAuth do zapisu.

## Blokada dalszej integracji

Wymuszona polityka sieci środowiska nie dopuszcza developer.allegro.pl.
Oficjalne repozytorium Allegro odsyła do tej dokumentacji; nie udało się
potwierdzić bieżących zasad zapisu i atomowej kontroli aktualności.
Zapisano projekt dostępu do tej jednej domeny. Wymaga przeglądu/zapisania
w ustawieniach oraz publikacji środowiska. Sam zapis projektu nie stosuje
zmiany. „Zapisz w Allegro” pozostaje wyłączony — pomyślny odczyt aktualności
nie jest atomową ochroną przed kolejną zmianą zewnętrzną.

Nie testowano produkcyjnego zapisu i nie wykonywano modyfikacji na koncie.
Pozostała część celu roadmapy (jawny zapis zmian, warunki konfliktu,
nieznany wynik, ewentualne nowe uprawnienia) pozostaje do wdrożenia.

## Architektura i sprawdzenia

ADR-059 opisuje DTO, port i adapter JSON. Bez migracji, nowych zależności
lub zapisów Produktów. I/O poza GUI. Testy obejmują zachowanie oryginalnego
HTML, zapis/odczyt, odmowę nadpisania, błędne/duże pliki, kontekst konta,
konflikty, rozłączenie i niezapisane zamknięcie. Testy UI używają izolowanych
fixture i nie korzystają z tokenów ani danych użytkownika.
Zrzuty vexlab-propozycja-037-* pokazują wyłącznie syntetyczny szkic.
Pełna regresja: 714 zaliczonych, 1 pominięty (natywne DPAPI wymaga Windows).
Końcowe testy edytora, plików i wspólnego komponentu: 24 zaliczone; testy
Allegro/edytora przy skalowaniu 150%: 26 zaliczonych. Mypy Windows: 97 modułów
bez błędów. Ruff, formatowanie, Bandit, 7 kontraktów importów i diagnostyka
poprawne. Sprawdzenie paczki obejmuje CRC, SHA256, zgodność źródeł i testy
uruchomione z rozpakowanego ZIP-a. Zdalny zapis nie był testowany ani włączony.
