# VexLab 0.14.1 — kolorowe ikony menu

Data: 2026-11-05. Polecenie właściciela: kolorowe ikony w menu bocznym
oraz osobne znaki Allegro i PrestaShop.

Każda funkcja ma kolor i czytelny symbol: cennik, producent, zdjęcia,
AI, szkic, aktywna oferta, masowa edycja, układ, kolejka i analityka.
Kolor dobierany do jasnego/ciemnego motywu. Ikony mają 20 px, w rozwiniętym
oraz zwiniętym menu. Nazwy, kolejność, skróty i działanie menu zachowane.

Allegro oznacza pomarańczowy monogram „a”, PrestaShop różowy znak marki.
Wektory oparte na Simple Icons (CC0), źródła i adaptacje opisano w
src/vexlab/gui/zasoby/IKONY_MAREK.md, licencja dołączona do zasobów.
Wszystkie ikony są lokalne, nie wymagają internetu w aplikacji.
Znaki kanałów nie oznaczają działającej integracji API.

Zmiany obejmują wyłącznie prezentację menu, zasoby i pakowanie.
Pozostały kod, logo programu, modele, baza, importy, ceny i dane pozostają
bez zmian. Schemat 7 bez migracji. Nie dodano zależności ani seedów.
Audyt kandydata 1.0 pozostaje zaplanowany; testy offscreen nie zastępują
odbioru Windows/DPI i czytnika ekranu.

## Weryfikacja

Obejrzano zrzuty obu motywów. Wszystkie 21 ikon menu renderuje się
poprawnie, w tym oba wektory marek. Wheel i ZIP zawierają SVG oraz tekst
licencji i źródła. Zbudowano wheel/sdist offline; CRC ZIP poprawne,
brak baz użytkownika w dystrybucji.
Z wypakowanej paczki przeszły cztery testy motywu/zwijania i rozmiarów
800/1100/1536. Potwierdzono import z wypakowanych źródeł.

Pełna kontrola wydania: **321 testów przeszło** (238,02 s). Ruff,
formatowanie, strict mypy (50 plików), siedem kontraktów importów,
Bandit i diagnostyka techniczna zakończyły się poprawnie.
