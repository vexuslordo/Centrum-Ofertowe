# VexLab 0.2 — lokalny katalog i pierwsze okno

Data: 2026-11-02 (Europe/Warsaw). Autor wykonania: Codex.
Zakres: pierwszy kompletny lokalny scenariusz i powłoka, bez integracji.

## Co działa

Uruchomienie bez `--diagnostyka` otwiera natywne GUI. Użytkownik może dodać
Produkt, zmienić jego nazwę/SKU/opis, wyszukać nazwę lub SKU przez Ctrl+K,
posortować listę i wrócić do danych po restarcie. Zapis jest rzeczywisty,
w SQLite poza repozytorium, a nie w demonstracyjnej pamięci widżetu.

Właściciel potwierdził w rozmowie dwie decyzje: SKU obowiązkowe i unikalne;
wielkość liter nie odróżnia symboli. Kontrola działa dla dodania, edycji,
równoczesnych zapisów i polskich liter. Pisownię zachowujemy do wyświetlenia.
Konflikt wersji nie nadpisuje nowszych danych, a błąd nie czyści formularza.
Nie utworzono relacji ani pól ceny/magazynu na podstawie zrzutu.

Działa kopia katalogu przez SQLite backup API z kontrolą integralności.
Kopia nie nadpisuje pliku ani aktywnej bazy; odtworzenie sprawdzono na osobnej
tymczasowej bazie. [Procedura danych i kopii](DANE_I_KOPIE.md).
Pierwszy schemat powstaje transakcyjnie, ma wersję, rejestr i sumę skryptu.
Przerwana inicjalizacja jest wycofywana. Cudzy/uszkodzony schemat pozostaje
nietknięty. Nowa instalacja ma 0 Produktów, bez seedów biznesowych.

Powłoka zachowuje grupy i kolejność menu. Działa zmiana motywu,
zwijanie nawigacji, zapis preferencji oraz nazwa użytkownika systemu.
I/O katalogu i kopii jest wykonywane poza głównym wątkiem; test potwierdza,
że GUI obsługuje zdarzenia podczas oczekiwania na zadanie. Wyniki wracają
do wątku GUI. Zamknięcie w czasie zadania nie przerywa zapisu.

## Weryfikacja

| Kontrola | Wynik |
|---|---|
| Python | rzeczywista instalacja CPython 3.13.18 |
| PySide6 / Qt | 6.12.0, rzeczywiste importy i pętla zdarzeń |
| uv / SQLite Linux | 0.13.6 / 3.53.1 |
| pytest | 69 zaliczonych, 0 niezaliczonych, 0 pominiętych |
| ruff check / format | poprawne |
| mypy strict | brak błędów w 21 plikach źródłowych |
| import-linter | 7 zachowanych kontraktów, 0 naruszeń |
| bandit | brak zgłoszeń w źródłach |
| pip-audit runtime / dev | brak znanych podatności w pełnych eksportach blokady |
| Druga czysta instalacja 3.13.18 | identyczne 53 dystrybucje i wersje; komplet testów przeszedł |
| Rzeczywisty start przez bootstrap | otwarcie GUI, pętla Qt i powstanie pustego schematu w izolowanym katalogu |
| Kopia i odczyt odtworzonego katalogu | dane zachowane; oryginał i istniejący plik kopii bez nadpisania |
| Windows / CI | konfiguracja przygotowana, niewykonane w tej sesji |

Kod i testy dotyczą bieżącego stanu 3.13.18. Raport etapów 1–2 opisuje
wcześniejsze 3.12.14. Pin, zakres wersji, lock, ruff/mypy, CI i instrukcje
są teraz spójne. Potwierdzono dostępność dystrybucji 3.13.18 dla Windows x64;
nie utożsamiamy tego z testem programu na Windows.

Testy korzystają wyłącznie z tymczasowych danych. Nie łączono Allegro,
PrestaShop ani AI, nie wykonywano publikacji i nie używano bazy użytkownika.
Audyt PyPI dotyczy znanych podatności pakietów; nie jest pełnym audytem
natywnych bibliotek Qt ani potwierdzeniem prawa do dystrybucji.

## Widok i różnice względem UI-REF-01

Zrzuty 1536×1024, Linux/Qt offscreen, pusta baza i syntetyczna nazwa
`uzytkownik_testowy`. To izolowany materiał testowy, nie profil instalacji:

- [Ciemny dashboard](screenshots/vexlab-dashboard-dark.png).
- [Jasny dashboard](screenshots/vexlab-dashboard-light.png).

Odtworzenie: `QT_QPA_PLATFORM=offscreen uv run --frozen python scripts/capture_ui.py`.
Oryginalny `assets/UI_REFERENCE.png` nie został zmieniony.

Zachowano granatową powłokę, menu, cztery karty, pięć akcji, tabelę,
operacje i trzy dolne panele. Nazwę marki zastępuje VexLab. Nie kopiujemy
danych z obrazu. Kolorowe karty inne niż Produkty mają „— / W przygotowaniu”.
Niewdrożone akcje są nieaktywne i opisane. Integracje nie pokazują „Połączono”.

To nie jest pełny odbiór referencji: brak gradientów/dopracowania geometrii,
oryginalnych zasobów marki i platform, miniatur, filtrów producenta,
kafelkowego widoku, wyboru masowego i menu akcji wiersza. Dashboard pokazuje
bieżący lokalny katalog, bez chronologii ostatnich modyfikacji. Nie ma
historii, kolejki, wykresu, cen, stanów i rzeczywistych połączeń. Wyszukiwanie
obejmuje obecnie nazwę/SKU, nie Oferty/EAN.

Sprawdzono interakcje i układ przy szerokościach 800, 1100 i 1536 oraz
motywy jasny/ciemny. Wysoki kontrast, Narrator, DPI 100–200%, wiele monitorów
i zgodność na Windows wymagają rzeczywistego odbioru w kolejnym środowisku.

## Granice i dalszy krok

Wykonano pionowy fragment etapów 3–7; nie zamykamy całych tych etapów.
[ADR-020](adr/ADR-020-lokalny-katalog-i-sqlite.md) opisuje model/trwałość,
[ADR-021](adr/ADR-021-powloka-vexlab.md) — GUI. Pozostałe 15 pojęć oraz
nieuzgodnione części Produktu pozostają propozycjami, bez zastępczych tabel.

Następny przyrost wymaga wyboru konkretnego scenariusza, np. producentów
i ich relacji z Produktem. Przed wdrożeniem trzeba rozstrzygnąć liczność
i obowiązkowość tej relacji; nie wynika ona z kolumny na ekranie.
Tak samo ceny, dostępność, układy, AI, retencja i dystrybucja pozostają
do uzgodnienia przed zależnym kodem. Nie zrealizowano integracji.

Zmiany są lokalne, bez push/PR i uruchomienia GitHub Actions. Instrukcje
chmurowe są zapisywane jako szkic konfiguracji; zapis nie oznacza publikacji
snapshotu ani sprawdzenia odtworzenia w nowym zadaniu chmurowym.
