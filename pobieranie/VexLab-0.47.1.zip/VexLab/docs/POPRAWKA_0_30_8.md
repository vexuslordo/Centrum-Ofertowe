# VexLab 0.30.8 — spokojniejsze kolory

Przyciemniono gradienty kafelków KPI i nagłówków sekcji menu o około 17%,
zachowując wspólną paletę, biały tekst i kolory ikon. Układ i działanie bez zmian.
Schemat i zależności bez zmian.
