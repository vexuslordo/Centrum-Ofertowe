# Audyt techniczny VexLab 0.18

Data: 2026-11-06. Audyt kodu bieżącej wersji developerskiej, wykonany po
poprawkach na polecenie właściciela. Nie zastępuje odbioru Windows, audytu
użytkowego 1.0 ani przyszłych testów kontraktowych rzeczywistych integracji.

## Zakres i metoda

Inwentaryzacja całego src: 62 moduły Python, około 11,8 tys. linii.
Kontrole statyczne obejmują cały src, testy i skrypty; typowanie cały src.
Przegląd ręczny oparty na ryzyku obejmował granice warstw i składanie usług,
modele Produktu/EAN, import XLSX/CSV/ZIP, źródła cen i historię cenników,
zapisy i usuwanie SQLite, migracje/kopie, preferencje, pracę zadań Qt,
pobieranie/dekodowanie obrazów oraz przygotowanie paczki źródeł.
Nie jest to deklaracja ręcznego przejrzenia każdej linii ani dowód braku
wszystkich błędów. Testy uruchamiane na tymczasowych danych, bez bazy użytkownika.

## Ustalenia i poprawki

| ID | Waga | Ustalenie i wynik |
|---|---|---|
| A18-01 | wysoka | Aktualizacja cennika mogła opierać producenta/aktywność na DTO interfejsu. Odczyt przeniesiono do transakcji pod blokadą, z kontrolą wersji. Archiwizacja i zapis nowego dokumentu wycofują się razem przy awarii. |
| A18-02 | średnia | Nieaktywny nowy dokument wyglądał jak archiwalny. Dodano jawną archiwizację i trzy stany; brak danych historycznych nie jest zgadywany. |
| A18-03 | średnia | Porównanie mogło zgubić poprzednią cenę po zmianie bazowego. Aktualizacja zachowuje odniesienie historyczne. Usunięcie poprzednika ma ostrzeżenie i neutralny brak porównania. |
| A18-04 | średnia | Surowy zapis liczby XLSX nie odpowiadał zaokrągleniu formatu. Dodano ograniczony odczyt precyzji z styles.xml i Decimal. Nieobsługiwane formaty są jawnie zgłaszane. Formuły nie są wykonywane. |
| A18-05 | średnia | Seryjne zdjęcia wymagają kontroli dysku i częściowego sukcesu. Dodano limit nowych danych, jedną kopię na serię, transakcję na produkt, ochronę wersji/istniejącej galerii i anulowanie; test awarii kopii blokuje zapis. |
| A18-06 | niska | Nieczytelne Do poprawy i pozostający plik w kreatorze. Przyczyny dostępne po kliknięciu, kreator czyszczony po sukcesie; plik źródłowy pozostaje. |
| A18-07 | niska | Preferencje akcji powinny przetrwać restart i odrzucać nieznane/zdublowane identyfikatory. Dodano walidację, test odczytu po restarcie i braku zmiany aktywnego stanu przy awarii zapisu. |

## Architektura i bezpieczeństwo danych

Domena nie zależy od Qt, SQL ani HTTP. GUI nie wykonuje SQL; bootstrap
składa porty i adaptery. Import-linter sprawdza siedem kontraktów; testy
mutacyjne dowodzą odrzucania naruszeń. Sam urllib.parse w przypadkach użycia
jest czystą analizą tekstu (ADR-046); kontrola AST i test izolowanego importu
nadal blokują klientów HTTP. Globalnego połączenia SQLite nie ma.

Sprawdzono odczyt wersji i BEGIN IMMEDIATE dla krytycznych zapisów, kopie przed
zmianami i wycofanie przy awarii. Porównanie AST opublikowanego źródła 0.17.1
potwierdza niezmienione definicje migracji 2–9; nowe pola wyłącznie w migracji
10. Testy obejmują starsze schematy, konflikt wersji, brak częściowego zapisu,
odtworzenie kopii i start pustej instalacji bez danych demonstracyjnych.

XLSX: limity rozmiarów/komórek, defusedxml bez DTD i encji. ZIP: limity
wpisów, sumy rozpakowanych danych i kompresji; bez wykonywania załączonych
instrukcji i kodu. Podgląd HTML nie uruchamia dowolnych zasobów sieciowych.
Zdjęcia: HTTPS/TLS, odrzucanie prywatnych adresów i kontrola przekierowań,
8 MiB odpowiedzi obrazu, 16 mln pikseli, JPEG/PNG/WebP normalizowane przed
zapisem. Timeout pojedynczego żądania wynosi 20 s; zatrzymanie serii czeka
na zakończenie bieżącego odczytu. Nie logujemy treści odpowiedzi ani sekretów.

## Pozostały dług i ograniczenia

- **Średni, skala:** lista katalogu i tabela cennika nadal ładują cały ograniczony
  zbiór; potrzebne stronicowanie przed dużym katalogiem Subiekta. Test 2375
  pozycji chroni dotychczasową masową edycję, nie dowodzi wydajności milionów.
- **Średni, dysk:** retencja kopii nieustalona. Jedna kopia na serię ogranicza
  ich liczbę w operacji, ale nie całkowite zużycie dysku. Bez samowolnego
  usuwania kopii. Limit nowych zdjęć nie jest limitem bazy i transferu.
- **Średni, sieć:** kontrola DNS poprzedza połączenie; ponowne rozwiązanie hosta
  przez transport pozostawia ryzyko DNS rebinding. Przed szerszym zastosowaniem
  serwerowym potrzebny transport z przypięciem zweryfikowanego celu i polityką
  wyjścia. Nie przedstawiać obecnej kontroli jako pełnej izolacji sieciowej.
- **Średni, utrzymanie:** okno.py (~1660 linii), katalog_sqlite.py (~1040),
  importowanie GUI (~840), paczki GUI (~780) i cenniki GUI (~765) są duże.
  Kolejny kontrolowany refaktoring powinien wydzielić kontrolery stron i
  migrator SQLite, zachowując testy regresji. Nowe dialogi i seryjne zdjęcia
  są osobnymi modułami; nie wykonano ryzykownej przebudowy całej aplikacji.
- **Odbiór:** brak rzeczywistego testu Evotech przez ograniczenia sieci tego
  środowiska. Publiczny katalog Shopify konkretnej witryny wymaga sprawdzenia.
  Brak dostępu do kont Allegro/PrestaShop/Subiekta i brak ich integracji.
  Windows, czytnik ekranu i pełny audyt intuicyjności pozostają do odbioru.

## Dowody weryfikacji

Wyniki końcowe kontroli lokalnych, pakowania i testów zapisano w raporcie
wydania po ich zakończeniu. Audyt pip-audit pełnego zestawu zależności
przechodnich runtime i dev z uv.lock: brak znanych podatności w chwili
sprawdzenia. Początkowy brak sieci sandboxa rozwiązano uruchomieniem audytu
przez zatwierdzony mechanizm dostępu; TLS i proxy pozostały włączone.
Nie zastępuje to przeglądu logiki ani gwarancji przyszłego bezpieczeństwa.

Końcowy `scripts/check.py`: **432 passed**, ruff i format bez uwag,
mypy bez błędów w 62 modułach, siedem kontraktów zachowanych, Bandit bez
zgłoszeń, diagnostyka poprawna. Po poprawce kolejności kolumn: ponowny
przebieg 11 testów Cenników i 13 testów GUI przy 150% (w tym dodatkowy test
kolejności). Wheel/sdist zbudowane offline. Zrzuty jasne/ciemne i wąski
widok obejrzane. Brak krytycznych ustaleń w wykonanym przeglądzie; wymieniony
wyżej dług pozostaje otwarty i nie oznacza ukończenia audytu UX 1.0.
