# Osobny widok Zdjęcia i media — 0.7.1

Zgłoszenie właściciela, 2026-11-03: Zdjęcia i media oraz Produkty otwierały
tę samą stronę. Usunięto alias, dodano odrębną stronę z miniaturą,
nazwą, SKU i producentem. Narzędzia: otwarcie galerii jednego produktu,
odświeżenie, filtr producenta i czyszczenie filtrów. Enter i dwuklik otwierają
galerię zamiast edytora Produktu. Globalne wyszukiwanie nazw/SKU pozostaje
na stronie mediów. Brak wyników ma osobny komunikat.

Oba widoki korzystają ze wspólnego katalogu i filtra, bez powielenia danych.
Galeria w Produkty pozostaje skrótem. Zapis galerii i jej kopie bez zmian;
nie zmieniono schematu 4, modelu ani zewnętrznych zależności.

Test regresji sprawdza oddzielne widgety i aktywną pozycję menu,
pozostawanie wyszukiwania w mediach, otwieranie galerii produktu wybranego
w tabeli mediów oraz komunikat braku wyników. Dane syntetyczne.
Odbiór nowego widoku na Windows/DPI pozostaje do wykonania.

Wynik: scripts/check.py — 205 testów przeszło, ruff, formatowanie,
mypy (39 plików), 7 kontraktów importów, bandit i diagnostyka poprawne.
Zgodność uv.lock sprawdzona offline, zainstalowano lokalny pakiet 0.7.1.
Obejrzano zrzuty pustego widoku mediów w obu motywach przy 1536×1024
(Qt offscreen); zrzuty w docs/screenshots/vexlab-media-dark.png i light.png.

ZIP rozpakowano osobno i uruchomiono z niego nowy test regresji nawigacji
— przeszedł. CRC poprawne, bez baz, XLSX, środowiska i cache. Zależności
zewnętrzne bez zmian, bez ponownego audytu tego samego grafu.

2026-11-03 właściciel po wyjaśnieniu zakresu potwierdził „Rozumiem. Działa.”
Potwierdza działanie poprawki 0.7.1 u właściciela; nie zastępuje pełnej macierzy DPI/Narrator.
