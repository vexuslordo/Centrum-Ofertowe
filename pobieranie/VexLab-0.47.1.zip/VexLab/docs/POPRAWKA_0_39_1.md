# VexLab 0.39.1 — kolory Dashboardu i statusów Allegro

Polecenia właściciela z 2026-11-10 zastępują płaskie tła KPI Allegro z 0.39.
Kafelki mają bazę Dashboardu #0D1B28 (jasny #F6F9FE), jego obrys
#203B51 / #CDDBEE i delikatną kolorową poświatę o tej samej sile 45/25.
Akcent Allegro jest pomarańczowy, szkiców niebieski, błędów czerwony,
sprzedaży zielony i obrotu złoty — z palety Dashboardu. Bez nowych ikon,
przebudowy układu ani zmiany Dashboardu.

Niezależnie od akcentów KPI statusy w tabeli i szczegółach mają znaczenie:
Aktywna — zielony, Zakończona — czerwony, Szkic — żółty; Aktywowanie — niebieski.
Odcienie zależą od jasnego/ciemnego motywu. Kolor tekstu i kropki pozostaje
widoczny także po zaznaczeniu wiersza i po zmianie motywu podczas pracy.
Nazwa statusu jest nadal wyświetlana, więc znaczenie nie zależy od samego koloru.

Scenariusz: przegląd listy i odczyt statusu oferty. Właściciel statusu to
Allegro API; zmieniamy wyłącznie prezentację istniejącego DTO. Brak nowych
bytów, zapisu danych, żądań API, migracji i zależności. Dane użytkownika,
uprawnienia, logo i jednakowe miniatury pozostają zachowane. Zmiana dotyczy
warstwy gui i wspólnego Design Systemu, nie procesu zapisu/publikacji.

Podglądy: docs/screenshots/vexlab-allegro-0391-dark.png i odpowiednik light.
Wygenerowane skryptem capture_allegro.py na syntetycznych ofertach i koncie
Sandbox, w tym przykładach każdego z trzech statusów. Bez danych konta właściciela.

Sprawdzenia obejmują oba motywy, zmianę motywu w trakcie pracy, zaznaczenie
każdego statusu i kontrolę rzeczywiście narysowanego koloru komórki, a także
regresję Allegro/Dashboardu, miniatur i skalowanie 150%. Linux/offscreen
nie zastępuje odbioru natywnego Windows. Szczegółowy wynik kontroli poniżej.

Wynik kontroli wydania, 2026-11-10: check.py zakończony kodem 0 — ruff,
format, mypy (100 modułów), 7 kontraktów importów, bandit, diagnostyka oraz
**759 passed, 1 skipped** (natywne DPAPI Windows). Testy Allegro przy 150%:
**30 passed**. Audyt pełnych zależności runtime i dev: brak znanych podatności.
Sprawdzono podglądy jasny/ciemny, węższe okno i stan niepołączony.
