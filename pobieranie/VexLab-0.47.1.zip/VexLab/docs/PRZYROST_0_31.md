# VexLab 0.31 — podgląd szkiców Allegro

Allegro → Pobierz szkice → zaznacz jeden wiersz → Podgląd szkicu (lub dwuklik).
Program odczytuje szczegóły wybranego identyfikatora i pokazuje konto,
środowisko, ID, tytuł, SKU, źródłową cenę/walutę, dostępność, kategorię,
galerię zdjęć i układ opisu. Braki danych są pokazane jawnie.

Podgląd jest odczytem. Nie zapisuje danych do katalogu, nie edytuje zdalnego
szkicu i nie publikuje oferty. Edycja i zapis będą następnym etapem.
Opis przechodzi przez istniejący filtr HTML; obrazy pobierane przez port
PodgladZdjec z ograniczoną kolejką/pamięcią, bez tokenów Allegro w żądaniach
zdjęć. Sesja, zgodność ID i status INACTIVE są sprawdzane. Rozłączenie zamyka
podgląd; spóźniona odpowiedź poprzedniej sesji jest ignorowana.

Technicznie: GET /sale/product-offers/{id}, istniejący transport HTTPS,
limit odpowiedzi 2 MiB i timeout 20 s. Schemat 11 i zależności bez zmian.
[ADR-055](adr/ADR-055-podglad-szkicu-allegro.md).

Oficjalne odnośniki: https://github.com/allegro/allegro-api oraz
https://developer.allegro.pl/documentation/#operation/getProductOffer.
Repozytorium oficjalne odczytano; pełny portal dokumentacji pozostaje poza
listą dostępnych hostów tego środowiska. Testy używają symulowanych odpowiedzi;
nie wykonano odczytu na rzeczywistym koncie ani natywnego odbioru Windows.

## Weryfikacja

Pełny scripts/check.py: 647 testów zaliczonych, 1 pominięty (natywne DPAPI
wymaga Windows), ruff/format, mypy 90 modułów, 7 kontraktów warstw, Bandit
i diagnostyka poprawne. Po doprecyzowaniu obsługi null ponownie zaliczono
49 testów API/GUI; dodatkowy scenariusz nieuzupełnionego szkicu przechodzi.
14 testów Allegro GUI przy skalowaniu 150%; mypy win32 poprawne.
Audyt runtime/dev: brak znanych podatności w chwili sprawdzenia.
Podgląd obejrzano w obu motywach z danymi syntetycznymi i lokalnym obrazem
fixture (docs/screenshots/vexlab-allegro-031-*.png). Bez dostępu do konta
właściciela testy nie potwierdzają działania na produkcyjnym API Allegro.
