# VexLab 0.13 — opis z formatowaniem i przeciąganie sekcji

Data: 2026-11-05. Wymaganie właściciela i zasady: ADR-040.

## Jak używać

Szkice → zaznacz ofertę → Edytuj tytuł i opis…

- Po lewej wybierz sekcję, po prawej zmieniaj tekst z formatowaniem.
- Przeciągnij sekcję, żeby zmienić kolejność, lub użyj przycisków ↑ / ↓.
- Dodawaj tekst, zdjęcie, tekst ze zdjęciem lub dwa zdjęcia.
- Przeciągnij zdjęcie z listy zdjęć paczki na listę sekcji. Dwukrotne
  wybranie zdjęcia dodaje taką samą sekcję bez przeciągania.
- Dla zdjęć wprowadź lub zmień adres HTTPS. Wyświetlane są adresy;
  edytor nie pobiera zdjęć z internetu i nie pokazuje ich miniatur.
- Zakładka Podgląd pełnego opisu pokazuje opis z formatowaniem.
- Zapisz utrwala strukturę i opis razem; Anuluj pozostawia zapisany szkic.

Podstawowe formatowanie: pogrubienie, kursywa, podkreślenie, lista i nagłówek.
Tekst jest pokazywany jako tekst sformatowany, bez ręcznej edycji kodu HTML.
Samo otwarcie starego szkicu nie przepisuje jego treści lub układu.
Dopiero zmiana sekcji tworzy pełny opis odpowiadający zmienionemu układowi.

## Dane i zgodność

Treści/ustawienia producentów pozostają danymi użytkownika. Brak seedów.
Zmiany dotyczą tylko wybranego szkicu. Produkt, inne szkice, metadane ceny,
EAN i źródłowa galeria nie są nadpisywane. Edytowane adresy zdjęć są
częścią sekcji. Konflikt wersji blokuje nadpisanie i zachowuje otwarte okno
z edycją. Błąd walidacji lub zapisu pozwala poprawić dane w tym samym oknie.

Schemat bazy nadal 7. Zapis tworzy kopię w kopie_szkicow. Nie ma migracji
lub nowych zależności. HTML wklejany i renderowany jest ograniczony do
bezpiecznych znaczników, bez wykonywania skryptów i pobierania zasobów.
To wizualny edytor lokalnego szkicu, nie wdrożenie publikacji Allegro.

Wymagany audyt techniczny i użyteczności kandydata 1.0 nadal zaplanowany.
Odbiór Windows, rzeczywistego przeciągania myszą i DPI pozostaje osobny;
testy Qt offscreen sprawdzają model przenoszenia i zdarzenia upuszczenia.

## Weryfikacja

Testy Qt sprawdzają wyświetlanie tekstu bez kodu, pogrubienie, zmianę
kolejności modelu wykorzystywanego przez przeciąganie, zdarzenie upuszczenia
zdjęcia z galerii, wklejanie bez aktywnej treści i otwarcie bez przepisywania
źródła. Test GUI sprawdza anulowanie, poprawienie błędu w otwartym oknie
oraz zapis opisu i sekcji. SQLite: restart, konflikt wersji, zachowanie
metadanych i brak nadpisania przez ponowny import.

Z wypakowanej paczki przeszło 26 testów edytora, szkiców i pełnego przepływu
edycji. Potwierdzono import z wypakowanych źródeł. CRC ZIP poprawne,
brak baz/paczek użytkownika w dystrybucji. Kod schematu i migracji identyczny
z 0.12. Wheel/sdist zbudowane offline z przypiętymi zależnościami.

Obejrzano zrzuty obu motywów z syntetycznym opisem (scripts/capture_editor.py),
bez danych biznesowych w źródłach i bez zewnętrznych żądań.

Końcowa pełna regresja: **316 testów przeszło** (228,24 s). Ruff,
formatowanie, strict mypy (50 plików), siedem kontraktów importów,
Bandit i diagnostyka techniczna zakończyły się poprawnie.

Po dodatkowym sprawdzeniu rzeczywistej paczki dopracowano wybór pierwszej
sekcji tekstowej, gdy początek oferty zawiera baner. Kolejność danych nie
jest zmieniana. Wszystkie osiem testów GUI edytora i zapisu przeszło
ponownie; Ruff i mypy również. Próba na izolowanej bazie z 200 ofertami
potwierdziła renderowanie tekstu, brak przepisania źródła przed edycją,
poprawny zapis zmienionego układu oraz zachowanie galerii i innych szkiców.
