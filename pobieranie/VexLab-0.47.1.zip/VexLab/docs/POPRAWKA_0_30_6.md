# VexLab 0.30.6 — kwadratowe przyciski ikon

Filtr, kafelki i lista mają rzeczywisty rozmiar 36 × 36 px i promień rogów 8 px.
Styl nie zeruje już minimalnej szerokości, przez co układ nie spłaszcza
przycisków. Ikony 18 px są wyśrodkowane; usunięto dodatkową strzałkę filtra.
Test regresji w obu motywach obejmuje zmianę szerokości i fokus każdego przycisku.
Dane, schemat i zależności bez zmian.
