# VexLab 0.30.5 — przycisk Więcej

Przycisk Więcej otrzymał rozmiar tekstu, zaokrąglenie i wysokość zgodne
z przyciskami producentów. Wysokość wyznacza przycisk Wszystkie, z zachowaniem
miejsca na strzałkę menu. Fokus nie zwiększa rozmiarów przycisków.
Schemat i dane bez zmian.
