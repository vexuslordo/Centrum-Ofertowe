# VexLab 0.8 — opcjonalne dopasowania do motocykli

2026-11-03. Właściciel zaakceptował ADR-033 odpowiedzią „tak”. Produkt ma
opcjonalną listę zero–wiele dopasowań, z marką/modelem, opcjonalnymi
rocznikami od/do i wariantem. Brak listy nie oznacza uniwersalności.
Marka motocykla pozostaje niezależna od producenta części. Nowa instalacja
nie zawiera marek, modeli ani produktów demonstracyjnych.

## Obsługa

Dodaj/edytuj Produkt → Pasuje do motocykli… → Dodaj motocykl.
„Zastosuj w formularzu” zatwierdza listę roboczą. „Zapisz lokalnie” zapisuje
Produkt wraz z całą listą. Anulowanie edytora zostawia listę w formularzu
bez zmian; anulowanie formularza nie zapisuje zmian w bazie.
Szczegóły Produktu pokazują wszystkie dopasowania.

Marka i model są wymagane wyłącznie w dodanym dopasowaniu. Pusty wiersz
pomijany, niepełny zgłasza błąd. Roczniki całkowite 1000–9999; „do” wymaga
„od” i nie może go poprzedzać. Dokładny duplikat po trim/casefold odrzucany,
warianty pozostają odrębne. Puste roczniki oznaczają brak danych, sam rok od
— niepodany koniec. Nie sugeruje to gwarancji dla przyszłych roczników.
Nie odgadujemy dopasowań z nazwy lub opisu.

## Dane i aktualizacja

Typ wartości należy do agregatu Produktu; nie dodano głównej encji.
Wspólne strukturalne DTO dostępne dla przyszłych mapowań kanałów.
Domena i przypadki użycia bez Qt/SQL, GUI bez adaptera bazy.
Zapis całego Produktu i listy jest jedną transakcją i chroniony jego wersją.
Niepełny zapis wycofuje także zmianę nazwy oraz wersji.
Edycja masowa producenta/opisu i operacje galerii zachowują dopasowania.
Import XLSX/CSV nie dodaje dopasowań automatycznie.

Schemat 5, nowa podrzędna tabela dopasowania. Migracje 1–4 zachowane.
Przed aktualizacją istniejącej bazy powstaje spójna kopia w kopie_migracji.
Migracja 4→5 zachowuje dotychczasowe tabele oraz ich dane; istniejące Produkty
zaczynają z pustą listą. Starsze schematy nadal aktualizowane z kopią.
Błąd lub brak możliwości wykonania kopii blokuje migrację; bez resetu bazy.

Powrót do 0.7.1: zamknij aplikację, zachowaj bieżący katalog.sqlite3 osobno,
przywróć kopię schematu 4 pod nazwą katalog.sqlite3 w tym samym katalogu
danych. Kopia nie obejmuje zmian wprowadzonych po aktualizacji do 0.8.
Nie otwieraj bazy schematu 5 starszą aplikacją; jej mechanizm zgodności
odrzuci nowszy schemat.

## Weryfikacja i ograniczenia

Testy domeny obejmują puste wymagane pola, granice roczników, błędne zakresy,
duplikaty i różne warianty. Testy rzeczywistej SQLite: dodanie, edycja,
restart, wyczyszczenie, konflikt, awaria w trakcie listy, masowa edycja,
zapis zdjęć i usunięcie Produktu z odtwarzalną kopią.
Migracja używa fixture schematu 4 wygenerowanej z wydanego ZIP 0.7.1;
sprawdza zachowanie Produktów, Producentów, cen, zdjęć i pozycji Do poprawy,
integralność i odtworzenie kopii, przerwanie DDL, brak kopii i checksum.

Test Qt przechodzi przez formularz Produktu: robocza lista, błąd walidacji,
poprawienie bez utraty danych, zapis w tle, szczegóły i anulowanie edycji.
Zrzuty edytora w obu motywach zawierają wyłącznie syntetyczne dane.
Pełny odbiór 0.8 na Windows, DPI i Narrator pozostaje do wykonania.
Nie sprawdzano mapowań API Allegro/PrestaShop, nie wykonywano publikacji
ani płatnych wywołań. Zewnętrzne zależności nie zmieniły się.

Wynik scripts/check.py: 225 testów przeszło, ruff check/format, mypy
(40 plików), wszystkie 7 kontraktów importów, bandit i diagnostyka poprawne.
Po drobnej korekcie wyglądu nagłówka tabeli edytora ponownie sprawdzono jego
test Qt oraz lint/format. uv sync --frozen --offline i uv lock --check
potwierdziły zgodność. Porównanie opublikowanych stałych migracji 1–4
z wydanym ZIP 0.7.1 potwierdziło identyczną treść. Nie powtarzano audytu
niezmienionego grafu zależności zewnętrznych.

ZIP rozpakowano osobno. Potwierdzono import z jego src i uruchomiono
z niego 20 nowych testów dopasowań, migracji i GUI — wszystkie przeszły.
CRC poprawne; bez baz, XLSX, środowiska i cache. Użyto istniejących
przypiętych zależności, bez deklaracji testu świeżego Windows.

2026-11-03 właściciel po otrzymaniu 0.8 potwierdził „działa”. To potwierdzenie
działania u właściciela, bez deklaracji kompletnego odbioru DPI/Narrator.
