# VexLab 0.3 — Producenci

Data: 2026-11-02 (Europe/Warsaw). Autor wykonania: Codex.
Zakres: lokalny rejestr producentów, opcjonalne przypisanie do Produktu
i aktualizacja dotychczasowego katalogu bez utraty danych.

## Decyzja i działający przyrost

Właściciel wybrał **zero lub jednego producenta na Produkt** w odpowiedzi
na konkretną propozycję [ADR-022](adr/ADR-022-producenci-propozycja.md).
Nie zmieniono znaczenia Dostawcy ani PodmiotuGPSR i nie zatwierdzono
pozostałych nieustalonych relacji modelu.

Ekran Producenci pozwala dodać rekord, zmienić nazwę i aktywność, wyszukać
nazwę oraz pokazać/ukryć nieaktywnych. Dwie takie same nazwy nie są scalane;
lista i wybór odróżniają ID. Producent ma własną wersję edycji. Konflikt
zachowuje formularz i nie nadpisuje nowszego zapisu.

Formularz Produktu ma opcjonalny wybór producenta. Nazwa jest rzeczywiście
odczytywana w tabeli, także po zmianie nazwy rejestru. Dezaktywacja zachowuje
wcześniejsze przypisania, pozwala edytować pozostałe dane takiego Produktu
i blokuje nowe przypisania. Ostateczna kontrola jest atomowa w adapterze
SQLite, a nie tylko w liście rozwijanej. Nie dodano usuwania ani scalania.

I/O jest wykonywane poza wątkiem GUI; warstwy zachowują kierunek importów.
Nie dodano nowych bibliotek ani reguł platform sprzedażowych. Nadal brak
cen, magazynu, Ofert, AI, importów i działających konektorów.

## Migracja danych 0.2

Opublikowany schemat 1 zachowano dokładnie, łącznie z sumą skryptu.
Fixture testowa SQL pochodzi z rzeczywiście przekazanego ZIP VexLab 0.2.
Schemat 2 dodaje rejestr producentów i nullable FK w Produktach.
Istniejące ID, nazwy, SKU, opisy i wersje nie są przepisywane ani zerowane;
producent pozostaje nieprzypisany. Czysta instalacja nie zawiera seedów.

Przed zmianą istniejącego schematu 1 powstaje spójna kopia przez SQLite
backup API w `kopie_migracji`, obok bazy. Kopia ma unikalną nazwę i kontrolę
integralności. Niepowodzenie kopii blokuje migrację. Zmiana tabel, rejestru
i wersji jest transakcyjna. Symulowane przerwanie przed ALTER TABLE
pozostawia poprzednie dane i schemat 1. Nie usuwa się bazy po błędzie.

Aktualizacja używa tej samej lokalizacji danych użytkownika co 0.2;
nie wymaga ręcznego kopiowania aktywnej bazy. Szczegóły odtworzenia i
ewentualnego powrotu do kopii: [DANE_I_KOPIE](DANE_I_KOPIE.md).
Wersja 0.2 nie obsłuży już zmigrowanego schematu 2.

## Sprawdzenia

| Kontrola | Wynik |
|---|---|
| pytest | 93 zaliczone, 0 niezaliczonych, 0 pominiętych |
| mypy strict | brak błędów w 25 plikach źródłowych |
| ruff check / format | poprawne |
| import-linter | 7 kontraktów zachowanych, 0 naruszeń |
| bandit | brak zgłoszeń w źródłach |
| Środowisko | Python 3.13.18, PySide6/Qt 6.12.0, uv 0.13.6 |
| Zależności zewnętrzne | wersje bez zmian względem 0.2; ponowny audyt sieciowy nie był potrzebny |
| Schemat 1→2 | dane zachowane, kopia odczytywalna i odtwarzalna w nowym katalogu |
| Awaria migracji / brak możliwości kopii | brak częściowej zmiany i brak utraty danych |
| GUI | rzeczywisty rejestr, przypisanie, zmiana nazwy, dezaktywacja, konflikt i błędy formularzy |
| ZIP po rozpakowaniu | czysta instalacja i pełny zestaw 93 testów oraz kontrole przeszły także z rozpakowanego archiwum |

Pytest używa import-mode=importlib, aby moduły testów GUI i integracji
o tej samej nazwie nie kolidowały podczas pełnej kolekcji. Nie usuwano
testów ani nie wyciszano ostrzeżeń w celu uzyskania wyniku.
Testy nie korzystają z danych właściciela i nie wykonują operacji w sieci.

## Uruchomienie i przekazanie

ZIP zawiera `Uruchom VexLab.cmd`, który przechodzi do swojego katalogu
i uruchamia program przez `py -3.13 -m uv run --frozen python -m vexlab`.
W razie błędu zachowuje okno z komunikatem. Nie jest to instalator Windows;
wymaga Pythona/uv, tak jak działająca instalacja 0.2 właściciela.
Krótkie kroki są w `JAK_URUCHOMIC.txt`.

Zamknąć 0.2, rozpakować 0.3 do nowego folderu i uruchomić plik CMD.
Nie nadpisywać starego folderu lub jedynej kopii danych. Nowy folder ma
własne środowisko pakietów; lokalny katalog biznesowy pozostaje wspólny.

Zrzuty z pustych, izolowanych danych Linux/offscreen:
[Producenci](screenshots/vexlab-producenci-dark.png),
[dashboard](screenshots/vexlab-dashboard-dark.png).
Oryginalny PNG referencyjny nie jest zmieniany.

Właściciel pokazał działający start, dodanie i odczyt po restarcie 0.2 na
Windows. To nie zastępuje testu aktualizacji 0.3 na jego komputerze ani
odbioru Narratora, DPI, wielu monitorów lub pełnej zgodności UI-REF-01.
Plik CMD jest przygotowany, ale nie był uruchamiany w bieżącym Linuksie.
Zmiany pozostają lokalne, bez push i wykonania GitHub Actions.

Zaktualizowano i potwierdzono zapis `start_skill` środowiska chmurowego
dla wersji 0.3, schematu 2 i nowego zestawu testów. Instalacja i wersje
narzędzi pozostały bez zmian. Zapis szkicu nie jest publikacją snapshotu.
