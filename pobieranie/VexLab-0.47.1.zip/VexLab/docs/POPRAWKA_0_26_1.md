# VexLab 0.26.1 — wspólna konfiguracja integracji

2026-11-08. Właściciel zlecił umieszczenie Subiekta w Integracjach oraz
wyznaczył to miejsce dla wszystkich przyszłych integracji.

Ustawienia → Integracje zawiera zakładki Allegro i Subiekt GT. W Allegro
zachowano konfigurację, DPAPI i wznawianie połączenia. W Subiekt GT zachowano
ręczne sprawdzenie środowiska i kopiowanie raportu. Konektor GT pozostaje
odłożony; zmiana nie łączy z serwerem. Przyszłe integracje otrzymają kolejne
zakładki dopiero wraz z implementacją ich konfiguracji.

Skrót Ustawienia połączenia z obszaru Allegro wybiera właściwą zakładkę,
także po wcześniejszym przejściu do Subiekta. Sekcja Integracje dostępna
również w konfiguracji bez serwisu Allegro. Dane, schema 11, zależności,
mechanizm zapamiętywania i obszary codziennej pracy bez zmian.

Weryfikacja: pełna kontrola 608 testów zaliczonych, jeden test natywnego DPAPI
pominięty na Linux. Ruff, format, mypy (83 moduły), siedem kontraktów importów,
Bandit i diagnostyka poprawne. Po dopracowaniu układu dodatkowo pięć testów
przeniesienia konfiguracji, wyboru zakładki i diagnostyki zaliczonych.
Przy skali 150% zaliczono 13 testów GUI Allegro/Subiekt. Obejrzano oba motywy
i małe okno; zrzuty docs/screenshots/vexlab-integracje-0261-*.png pokazują
puste dane wizualne. Audyt runtime/dev bez znanych podatności w chwili
sprawdzenia; wheel/sdist zbudowane offline. Natywny odbiór Windows pozostaje.
