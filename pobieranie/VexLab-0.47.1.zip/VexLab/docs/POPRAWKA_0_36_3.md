# Poprawka 0.36.3 — przywrócone pionowe karty integracji

Polecenie właściciela 2026-11-09: widżet integracji ma wyglądać jak wcześniej,
z logo i pionowym układem. Dashboard ponownie używa istniejącego PanelIntegracji:
dwie karty Allegro/PrestaShop, logo u góry, status i informacje poniżej oraz
„Zarządzaj” w nagłówku. Zastępuje tabelę pięciu statusów w tej sekcji.
Konfigurator zachowuje dotychczasowy identyfikator i zapisany układ sekcji.

Karta Allegro pokazuje potwierdzone konto i licznik ACTIVE z istniejącego
odczytu 0.36. Pole opisano „Aktywne:”, ponieważ ta liczba nie jest łączną
liczbą wszystkich stanów. Limit API pozostaje —, bez kopiowania „2 req/s”
z demonstracji. PrestaShop nadal niepołączone/w przygotowaniu; sklep,
produkty i wersja bez fikcyjnych danych. Rozłączenie lub zmiana konta usuwa
poprzednie wartości. „Zarządzaj” otwiera Ustawienia → Integracje.

Ponowne użycie komponentu z 0.32, bez równoległego widżetu. Brak zmian
schematu, zależności, API lub logowania. Testy dotyczą nawigacji, właściwego
pola/licznika, braku fikcyjnych stanów, resetu po rozłączeniu, obu motywów,
responsywności i DPI 150%. Mypy Windows: 94 moduły bez błędów.
Zrzuty vexlab-allegro-0363-* są syntetycznym fixture wizualnym.
