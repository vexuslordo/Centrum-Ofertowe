# VexLab 0.29 — kafelki KPI według referencji

2026-11-08. Właściciel wymaga ikon i kolorów czterech kafelków jak na
przesłanym screenie. Zmiana dotyczy prezentacji, nie danych i metryk.

Niebieskie Produkty, zielone Aktywne oferty, pomarańczowe Szkice ofert,
fioletowe Błędy. Jaśniejsze gradienty z subtelną poświatą, obrys i promień
12 px. Kafelek ma 120 px wysokości, ikonę 56×56 px z białym pełnym symbolem,
odstęp do tekstu 22 px, typografię 14/28/12 px. Ta sama paleta w obu motywach.
QPainter/SVG zachowują skalowanie, bez zewnętrznych bibliotek UI i pobierania
ikon podczas pracy. Dotychczasowy responsywny układ czterech lub dwóch kolumn.

Pudełko 3D i wykrzyknik w okręgu są własnymi kształtami SVG według wzoru.
Metka i dokument: Font Awesome Free tag/file-lines (CC BY 4.0).
Atrybucja i licencja w assets/KPI_ICONS_ATTRIBUTION.md
i FONT_AWESOME_FREE_LICENSE.txt. Symbole zmieniono
na białe i umieszczono na własnych gradientowych tłach; pozostałe ikony menu
nie są zastępowane. Nie zmieniano pliku assets/UI_REFERENCE.png.

Produktów jest tyle, ile wynika z katalogu. Pozostałe niezaimplementowane
odczyty nadal pokazują — i W przygotowaniu. Nie wstawiono demonstracyjnych
liczb ani procentowych wzrostów z grafiki. Brak nowych połączeń, zmian
schematu 11, zależności, danych, sekretów i procesów użytkownika.

## Weryfikacja

Pełne `scripts/check.py`: 619 testów zaliczonych, jeden natywny test DPAPI
pominięty na Linux. Ruff/format, mypy 86 modułów, siedem kontraktów importów,
Bandit i diagnostyka poprawne. Następnie dodano i zaliczono cztery testy
renderowania białych symboli: wykrywają m.in. dokument SVG, którego Qt nie
renderuje w całości mimo poprawnej składni. W testowanych zasobach nie ma
zagnieżdżonych svg, użyte są obsługiwane grupy/ścieżki. Przy skali 150%
zaliczono te cztery testy oraz test pustego Dashboardu. Mypy win32 poprawne.

Obejrzano pasek kafelków oraz Dashboard w obu motywach 1536×1024 i małym
oknie 900×700. Zrzuty docs/screenshots/vexlab-kpi-029-*.png pokazują zero
produktów i brak nieodczytanych metryk, bez danych demonstracyjnych.
Audyt runtime/dev nie wykazał znanych podatności w chwili sprawdzenia.
Wheel/sdist zbudowane offline. Natywny odbiór Windows i faktyczne odczyty
metryk kanałów pozostają osobno.
