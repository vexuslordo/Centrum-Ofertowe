# VexLab 0.31.1 — spokojniejsza nawigacja

Nagłówki grup mają wspólne ciemnogranatowe tło, bez kolorowych obramowań.
Akcent grupy pozostaje wyłącznie na małej strzałce. Aktywna zakładka wyróżnia
się niebieskim tłem i niebieskim znacznikiem. Mniejsze odstępy między grupami,
zaokrąglenia oraz zwijanie zachowane. Jasny motyw ma odpowiednią jasną paletę.
Kafelki KPI i dane bez zmian. Schemat 11 i zależności bez zmian.
