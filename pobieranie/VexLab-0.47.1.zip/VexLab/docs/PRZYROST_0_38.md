# VexLab 0.38 — zapis zmian szkicu Allegro

2026-11-09. Wdrożenie na podstawie przesłanego swagger.yaml (ADR-060).

## Użycie

1. W konfiguracji aplikacji Allegro włącz `allegro:api:sale:offers:write`
   obok dotychczasowych scope profilu i odczytu ofert.
2. VexLab → Ustawienia → Integracje → Allegro → Dane aplikacji:
   zaznacz „Zezwól na zapis tytułu i opisu szkiców” i połącz konto ponownie.
   Samo wznowienie starej zgody nie dodaje uprawnienia. Sekret wpisujesz
   w programie, nie w rozmowie.
3. W Allegro wybierz szkic INACTIVE → Przygotuj edycję szkicu.
   Zmień tytuł/opis, opcjonalnie zachowaj propozycję JSON.
4. „Zapisz w Allegro” pokazuje konto, środowisko, ID i zmieniane pola.
   Domyślnie Nie. Nie edytuj ani nie publikuj tej oferty równolegle:
   API nie definiuje tu zapisu warunkowego.
5. Zapis obejmuje tylko tytuł/opis. Nie wysyła publikacji, ceny, stanu,
   galerii ani innych pól. Sukces oznacza potwierdzenie zmian kolejnym GET.
6. Przy 202 lub niepewnym wyniku użyj „Sprawdź wynik zapisu”. Nie ma
   automatycznych ponowień PATCH. Rejestr blokuje powtórzenie także po
   restarcie. Po restarcie ponownie otwórz właściwy szkic i sprawdź wynik.

## Ograniczenia

Ponowny GET blokuje wykryte konflikty, ale nie wyklucza równoległej zmiany
między sprawdzeniem i zapisem. Allegro może odrzucić HTML lub inne warunki
oferty odpowiedzią 422; treść w edytorze pozostaje. Przy wyniku niezgodnym
z oczekiwanym zachowaj plik propozycji i rejestr `zapisy_allegro` oraz
wyjaśnij stan w Allegro. Nie usuwaj blokady w celu ponowienia niepewnej
operacji. Nie ma automatycznego scalania, nadpisania konfliktu ani publikacji.

Dotychczasowe odczyty bez uprawnienia zapisu działają. Dane lokalnych
Produktów, szkiców ZIP, motywy, logo, Dashboard i miniatury pozostają.
SQLite: schemat 11, bez migracji i nowych zależności.

## Weryfikacja

Testy portów i GUI obejmują: payload tylko zmienionych pól, granice tytułu
oraz rozmiaru UTF-8 opisu, konflikty i kontekst konta, brak wywołania PATCH
przy błędzie wstępnym, odmowy HTTP, timeout/nieznany wynik, odzyskiwanie po
restarcie, blokadę uszkodzonego rejestru, 202/303, obce Location, Retry-After,
zgodę użytkownika, zachowanie treści i aktualizację bazy po sukcesie.
Wyniki kontroli i weryfikacji paczki podawane przy publikacji.
Nie wykonano testu rzeczywistego zapisu na koncie użytkownika ani natywnego
odbioru Windows/DPAPI w Linux. Nie jest to deklaracja gotowości produkcyjnej.

Dowody lokalne z 2026-11-09: scripts/check.py — 747 zaliczonych, 1 pominięty
DPAPI; po ostatnich uzupełnieniach 135 zaliczonych i ten sam 1 pominięty
w zakresie Allegro/autoryzacji/transportu/edytora. Ostateczny zbiór liczy
753 przypadki; pięć później dodanych uwzględnia powyższy test zakresowy.
Test równoległych instancji potwierdza brak dwóch PATCH. mypy Linux i win32:
100 modułów bez błędów; Ruff, Bandit i 7 kontraktów importów zaliczone.
DPI150%: 28 testów GUI. Z rozpakowanego ZIP: 73 zaliczone, 1 DPAPI pominięty.
Zrzuty syntetyczne obu motywów i małego okna: docs/screenshots/vexlab-zapis-038-*.png.
