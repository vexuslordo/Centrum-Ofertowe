# VexLab 0.12 — trwałe szkice ofert z paczek

Data: 2026-11-05. Zakres zatwierdzony przez właściciela: ADR-035,
rozszerzenie ZIP z 2026-11-04 oraz decyzja z 2026-11-05.

## Obsługa

1. Nowe oferty → wybierz gotowy ZIP. Profile i rozpoznawanie układów
   działają jak w 0.11; mapowania pozostają danymi użytkownika.
2. Oferty z paczki → opcjonalnie wybierz producenta nowych Produktów.
3. „Zapisz oferty jako lokalne szkice…” → sprawdź podsumowanie i zatwierdź.
4. Otwórz „Szkice”. Oferty pozostają na liście po zamknięciu programu.

Podsumowanie wskazuje liczbę ofert, nowych Produktów i błędnych wierszy.
Przed zatwierdzeniem nie ma zapisu. Błędne wiersze nie tworzą szkiców;
powody są pokazane w podsumowaniu, źródłowy ZIP nie jest zmieniany.
Zmodyfikowane prezentacje dla tego samego SKU tworzą osobne szkice,
co komunikat wyraźnie zapowiada przed potwierdzeniem.

## Zachowanie danych

Każdy szkic wskazuje jeden Produkt, Produkt może mieć wiele szkiców.
Nowe Produkty powstają w tej samej transakcji, istniejące nie są nadpisywane.
Zachowane pola oferty: SKU, tytuł, pełny HTML, EAN i cena źródłowa jako
tekst bez zgadywania waluty/VAT, tekst dopasowania, uporządkowane sekcje
tekst/obraz, linki galerii, numer wiersza i pochodzenie.

Identyczna znormalizowana treść nie tworzy duplikatu, także po zmianie
nazwy ZIP. Numer wiersza nie jest tożsamością oferty. Edycja zapisanego
szkicu nie powoduje, że ponowny import nadpisze tę edycję. Usunięty szkic
można ponownie utworzyć z oryginalnej paczki.

Osobna strona Szkice: wyszukiwanie po tytule/SKU, bezpieczny podgląd,
edycja tytułu i pełnego HTML, usuwanie z potwierdzeniem i kopią. Sekcje
są zachowane oddzielnie: edycja pełnego HTML nie przebudowuje sekcji.
Nie ma jeszcze edytora układu sekcji. Wszystkie treści to dane użytkownika;
HTML/JS nie jest wykonywany, podgląd nie pobiera zdjęć lub innych zasobów.

Zapis, lista i edycja wykonują I/O poza wątkiem GUI. Wersje chronią przed
równoczesną edycją; zmiana Produktu daje oznaczenie „Produkt zmieniony”,
bez automatycznego nadpisywania treści. Produkt ze szkicami nie może być
usunięty; usunięcie szkicu pozostawia Produkt i inne prezentacje.

## Baza i odtworzenie

Schemat 7: tabela szkice z referencją do Produktu, wersją Produktu i edycji,
treścią oraz unikalnym odciskiem importu. Migracja 6→7 z kopią spójnej
bazy w kopie_migracji. Migracje 1–6 i ich sumy pozostają niezmienione.
Migratory obsługują także przypadek zakończenia aktualizacji do 7 przez
równoległy proces. Nie ma usuwania ani przebudowy wcześniejszych danych.

Zapisy/edycja/usuwanie szkiców tworzą kopie w kopie_szkicow. Awaria zapisu
wycofuje całą transakcję, łącznie z dopiero tworzonymi Produktami.

Powrót do 0.11 wymaga zamknięcia aplikacji i odtworzenia katalog.sqlite3
z kopii sprzed migracji. Najpierw zachowaj bieżącą bazę osobno. Dane
dodane po wykonaniu kopii nie znajdą się w odtworzonej starszej bazie.
Nie otwieraj bazy 7 w 0.11. Nowa instalacja jest pusta, bez producentów,
profili, ofert, cen i ustawień kont dostarczanych jako seedy.

## Granice wydania i dalszy kierunek

Zgodnie z decyzją właściciela późniejsza integracja ma wysyłać oferty do
Allegro jako **szkice**, bez uruchamiania sprzedaży. Publikacja będzie
osobną akcją. W 0.12 nie ma wywołań Allegro ani fikcyjnych kont/statusów.
Wymagania kategorii, ustawienia konta, ceny kanałów i API pozostają do
wdrożenia. Ręczny kreator szkicu z Produktu jest późniejszym rozszerzeniem.

Audyt techniczny i użyteczności kandydata 1.0 pozostaje zaplanowany.
Testy offscreen nie zastępują odbioru Windows, DPI i czytnika ekranu.

## Weryfikacja

- 49 testów integracyjnych szkiców, SQLite i migracji przeszło po poprawce
  współbieżności. Testy obejmują rollback, konflikty, kopie i odtworzenie.
- Testy GUI pokrywają anulowanie zapisu, listę, wyszukiwanie, edycję,
  podgląd oraz usunięcie bez usuwania Produktu.
- Rzeczywista paczka użytkownika na izolowanej bazie: 200 szkiców i 200
  nowych Produktów, zgodność pełnej treści po restarcie; ponowienie pomija
  200 ofert. Żaden producent/profil z tej paczki nie został seedem programu.
- Zbudowano wheel/sdist i paczkę źródłową 0.12. Sprawdzono CRC ZIP-a,
  kompletność nowego modułu i logo w wheel oraz brak baz/paczek użytkownika
  i domyślnych profili w dystrybucji. Z wypakowanego ZIP-a przeszło 17
  testów szkiców, migracji, domeny i przepływu GUI; potwierdzono ścieżkę
  importu z wypakowanych źródeł, a nie katalogu roboczego.
- Porównanie definicji SQL migracji 1–6 z wydaniem 0.11 wykazało zgodność.
- Końcowy pełny zestaw: **303 testy przeszły** (240,64 s); Ruff,
  formatowanie, strict mypy (49 plików), siedem kontraktów importów,
  Bandit i diagnostyka techniczna zakończyły się poprawnie.
- Po końcowym przeglądzie dodano mapowanie błędu brakującego producenta
  na czytelny błąd scenariusza. Wszystkie 14 testów integracyjnych szkiców
  przeszło ponownie, w tym dodatkowy test braku częściowego zapisu.
  Ruff i strict mypy przeszły ponownie. Nie zmieniano zależności aplikacji.
