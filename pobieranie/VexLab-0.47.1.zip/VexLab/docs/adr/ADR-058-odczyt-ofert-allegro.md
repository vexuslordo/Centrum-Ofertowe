# ADR-058 — stany ofert Allegro i liczniki całego konta

Status: wdrożone w 0.36; kontynuacja roadmapy zlecona przez właściciela
2026-11-09. Subiekt GT pozostaje odłożony. Zakres: odczyty Allegro i zasilenie
istniejących KPI, bez operacji zapisu lub publikacji.

## Scenariusz i właściciel danych

Użytkownik przełącza w Allegro listę Wszystkie / Aktywne / Szkice /
Aktywowanie / Zakończone, przegląda stronę i podgląd oferty. Stany pochodzą
z publication.status kanału, nie z lokalnych Produktów. Wszystkie widoki
korzystają z tej samej sesji potwierdzonej przez /me. Produkt, Oferta,
Producent, konto i kanał nie otrzymują nowych lokalnych relacji lub pól.
To zewnętrzne DTO odczytu; nie powstaje konkurencyjny katalog.

## Port i implementacja

APISesjiAllegro rozszerzono o oferty/oferta. StatusOfertyAllegro mapuje
INACTIVE, ACTIVE, ACTIVATING, ENDED. Brak filtra oznacza wszystkie stany.
Adapter kanału stosuje GET /sale/offers z publication.status, offset i limit,
a dla podglądu GET /sale/product-offers/{id}. Wspólny mapper odrzuca obcy lub
brakujący status; odczyt wyspecjalizowany szkicu zachowuje wymaganie INACTIVE.
Historyczne nazwy DTO SzkicAllegro/StronaSzkicowAllegro/SzczegolySzkicuAllegro
pozostają dla kompatybilności i otrzymują rzeczywisty status. Nie ma drugiego
modelu tych samych danych ani migracji SQLite.

GUI korzysta z dotychczasowej puli zadań i limitowanego odczytu zdjęć.
Pełnych kolekcji ofert, opisów i zdjęć nie ładuje się na start. Rozmiar strony
50 i dotychczasowy limit pierwszych 10 000 wyników pozostają. Jest to limit
tej wersji aplikacji, nie deklaracja limitu Allegro API. Licznik totalCount
może być większy i jest pokazywany jako liczba całego wyniku z API.

## Liczniki i spójność

LicznikiAllegro zawiera liczby ACTIVE/INACTIVE z dwóch zapytań limit=1.
Cache ma jedną parę wyników, TTL 30 sekund i własną blokadę, bez globalnego
stanu i plików. Klucz: środowisko, ID konta i SHA256 tokenu, wyłącznie w RAM;
cache nie przechowuje tokenu ani SesjaAllegro. Nie logować kluczy ani danych
odpowiedzi. Oba odczyty muszą się powieść; błąd nie zapisuje częściowego
snapshotu. Sprawdzenie ważności także po oczekiwaniu na blokadę i po odczycie.

Dashboard pobiera liczniki po potwierdzeniu sesji, po odczycie listy oraz
co minutę przy działającym oknie. Nie uruchamia równoległych serii odczytu
liczników dla tej samej aktywnej sesji. Odpowiedź przyjmowana wyłącznie dla
tego samego obiektu sesji. Rozłączenie/wznawianie usuwa widoczne liczniki;
spóźnione wyniki nie przywracają starego konta. Odczyt bieżącej strony ma
pierwszeństwo dla licznika swojego stanu względem starszego cache.
403/429/błąd sieci oznacza brak odczytu, nie zero ani utratę potwierdzonej
sesji. 401/wygaśnięcie przechodzi dotychczasowym procesem wznowienia.

Podgląd pokazuje stan zwrócony przez szczegóły; zmianę względem listy
sygnalizuje informacją o potrzebie odświeżenia. Zlecenia podglądu mają osobny
numer operacji, aby stara odpowiedź po zmianie zakładki nie kończyła nowego
odczytu ani nie wstawiała starych pól.

## Granice

Nie ma zapisu szkicu, publikacji, zmiany ceny/stanu, usuwania ani nowych
uprawnień OAuth. Zamówienia, sprzedaż i obrót pozostają osobnymi etapami.
Ukryte/Błędy nie są zgadywanymi stanami API i pozostają niedostępne.
Wyszukiwarka listy nadal filtruje bieżącą stronę i jest tak opisana.

Próba pobrania bieżącej publicznej specyfikacji swagger.yaml zakończyła się
HTTP 403. Nie deklarujemy zweryfikowania jej najnowszej wersji. Rozszerzono
istniejący kontrakt GET i przetestowano go izolowanym transportem; działanie
na rzeczywistym koncie wymaga sprawdzenia po stronie użytkownika.
