# ADR-060 — częściowy zapis tytułu i opisu szkicu Allegro

Data: 2026-11-09. Zakres: kontynuacja roadmapy zlecona przez właściciela,
rozszerzenie ADR-059 po dostarczeniu specyfikacji. Bez nowego modelu domenowego.

## Dowód kontraktu

Dostarczony przez właściciela `swagger.yaml`, SHA256:
`dc7c98cb7de47e5eba0a0783cecf5ce4f18cd3755ee9542966a9124e40c71ca6`.
Plik traktujemy jako dokumentację, nie instrukcje wykonawcze. Nie dołączamy
pełnego dokumentu do dystrybucji. Dostęp sieciowy do dokumentacji nie jest
już warunkiem tego przyrostu; data aktualności przesłanej specyfikacji nie
jest niezależnie potwierdzona.

`PATCH /sale/product-offers/{offerId}` edytuje pola niezależnie, przyjmuje
`application/vnd.allegro.public.v1+json`. Wysyłamy wyłącznie zmienione `name`
i/lub `description.sections[].items[]`. TEXT ma `content`, IMAGE ma `url`.
Nazwa: 12–75 znaków, przynajmniej trzy słowa. Opis: maksymalnie 40 000 bajtów;
sprawdzamy rozmiar serializacji JSON UTF-8 (konserwatywnie). Dopuszczalność
HTML ostatecznie sprawdza Allegro; nie przepisujemy nieedytowanych sekcji.

200 nie wystarcza do komunikatu sukcesu: wymagany kolejny GET i zgodność
pełnego tytułu/sekcji. 202 oznacza przyjęcie, nie zakończenie. Zapisujemy
identyfikator operacji wyłącznie z Location na tym samym hoście API i ścieżce
tej oferty. Ręczne „Sprawdź wynik zapisu” odpytuje GET operacji: 202 nadal
oczekuje, 303 prowadzi do odczytu znanej oferty. Nie śledzimy przekierowań.
Odstęp Retry-After ogranicza kolejne sprawdzenia w bieżącym procesie. Po
restarcie sprawdzenie jest ręczne, bez automatycznego odpytywania lub zapisu.

## Granice gwarancji i zgoda

Specyfikacja tej operacji nie definiuje If-Match/ETag ani odpowiedzi 412.
Świeży GET porównuje konto/środowisko/ID, INACTIVE i bazowy tytuł/sekcje;
konflikt blokuje zapis. Nie jest to atomowe zabezpieczenie. Potwierdzenie
z domyślnym Nie pokazuje konto, środowisko, ID i pola oraz ostrzega przed
równoległą edycją/publikacją. Nie obiecujemy, że inny klient nie aktywuje
oferty pomiędzy GET i PATCH. Żądanie nigdy nie zawiera publication, ceny,
stanu, productSet ani galerii; nie wysyłamy polecenia publikacji.

Opcjonalna zgoda „Zezwól na zapis tytułu i opisu szkiców” dodaje do Device
Flow `allegro:api:sale:offers:write`; domyślnie odczyt pozostaje bez zmian.
Nowa zgoda wymaga ponownego połączenia. Zapamiętywana konfiguracja DPAPI
ma kompatybilne opcjonalne pole bool; stary zapis oznacza False. Sam wybór
opcji nie dowodzi przyznania scope: 403 podaje instrukcję ponownej autoryzacji.

## Nieznany wynik i odtworzenie

Port RejestrZapisow, adapter plikowy w `zapisy_allegro`: wyłączny zapis i fsync
przed ponownym GET, a następnie PATCH. Błąd preflight zwalnia własną
rezerwację bez wysyłania zmian. Klucz to skrót środowiska/konta/oferty; zawartość to skrót
oczekiwanego tytułu/sekcji i opcjonalny identyfikator operacji. Bez tokenów,
sekretów, pełnego opisu i pełnych odpowiedzi. Wyłączność blokuje również
konkurencyjne procesy. Uszkodzony plik blokuje, nie znika automatycznie.
Nie zmieniamy schematu SQLite ani Produktu.

400/401/403/404/409/422/429 oznaczają odrzucenie i zwalniają własną blokadę.
Timeout, 5xx, brak prawidłowego Location, niezgodny odczyt i awaria procesu
zachowują blokadę. Nie ma automatycznego ponawiania PATCH. Ponowne otwarcie
edytora i „Sprawdź wynik zapisu” może potwierdzić wynik także po restarcie.
Gdy utracono identyfikator operacji, sprawdzenie porównuje oczekiwaną treść
z GET, bez domniemania, że operacja zakończyła się na podstawie samego HTTP.
Jeżeli treść nie jest zgodna albo oferta nie jest już INACTIVE, wymagane jest
ręczne wyjaśnienie w Allegro i diagnostyka; nie ma „wymuś zapis” ani automatycznego
usuwania blokady. Zachowaj propozycję JSON oraz pliki rejestru. Nie usuwaj
rejestru, dopóki wynik wcześniejszego zapisu nie zostanie wyjaśniony.

Blokada zapewnia ochronę przed ponowieniem po awarii procesu, nie gwarancję
Exactly Once po fizycznej utracie dysku. Poziom trwałości zależy od systemu
plików. Nie wykonano rzeczywistych zapisów użytkownika w testach.
