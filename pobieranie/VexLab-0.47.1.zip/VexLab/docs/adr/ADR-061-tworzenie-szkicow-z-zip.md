# ADR-061 — ZIP → nowe szkice Allegro

2026-11-12, polecenie właściciela „działa. Zaczynamy dalej”, po potwierdzeniu
0.39.1; realizacja wskazanego wcześniej kolejnego etapu. API: aktualny
https://developer.allegro.pl/swagger.yaml pobrany 2026-11-12. Źródła bazowe:
potwierdzona paczka 0.39.1, nie main.

OfertaPodglad z istniejącego czytnika ZIP pozostaje źródłem treści użytkownika.
Katalog Produktów VexLab/Subiekta bez zmian; katalog Allegro tylko do odczytu.
POST product-offers wskazuje wyłącznie UUID istniejącego produktu Allegro,
nigdy jego pełną definicję. Dopasowanie po GTIN wymaga jednego pełnego wyniku
lub jawnego wyboru użytkownika. Waluta, ilość i parametry są jawne w planie;
nie zgadujemy ustawień po nazwie producenta. W pierwszej wersji obsługujemy
zdjęcia HTTPS wskazane przez rozpoznany profil ZIP (bez lokalnych plików mediów).

Port API: GET katalogu produktu/kategorii, POST upload.allegro.pl/sale/images
z URL-em zdjęcia, POST api.allegro.pl/sale/product-offers. Osobny transportowy
bezpiecznik dopuszcza wyłącznie publication.status INACTIVE, bez harmonogramu
i z republish=false. Żadnych poleceń publikacji, zmian stanów istniejących ofert
lub zapisu kartotek. INACTIVE nie dowodzi gotowości do uruchomienia sprzedaży.
Walidacja lokalna i metadane API nie zastępują ostatecznej walidacji Allegro;
raport pokazuje błędy/ostrzeżenia, bez fikcyjnego sukcesu.

Przed POST: kontrola konta/środowiska/ważności sesji i planu, wymagane dane,
zdjęcia i rezerwacja w trwałym rejestrze. Konto/środowisko/SKU określa klucz
zapobiegający powtórzeniu w tym procesie; to konserwatywne ograniczenie, nie
nowy niezmiennik modelu Oferty. Nie tworzymy kolejnej oferty tego SKU nawet
po edycji paczki bez osobnego przyszłego procesu jawnych duplikatów.
Rejestr nie znika po sukcesie. Zapis zawiera skróty treści, ID i stan operacji,
bez sekretów i pełnych odpowiedzi API; zapis atomowy, fsync i wyłączność tworzenia.
Po timeout/5xx/awarii lub 202 nie ponawiamy POST. Ręczne sprawdzenie uzgadnia
operację i GET szkicu po deterministycznym external.id. Brak wyniku nie dowodzi
braku skutku. Uszkodzony rejestr blokuje wysyłkę; nie usuwać go automatycznie.

Transakcje SQLite i migracje niepotrzebne. I/O w tle, anulowanie między
żądaniami/pozycjami; żądania już wysłanego nie cofamy. Raport per pozycja,
bezpieczny eksport CSV bez nadpisania. Zmiana sesji zatrzymuje dalsze wysyłki.
Testy na fixture'ach transportu i tymczasowych rejestrach, nigdy na koncie
użytkownika. Odbiór rzeczywistego tworzenia pozostaje po stronie właściciela.
