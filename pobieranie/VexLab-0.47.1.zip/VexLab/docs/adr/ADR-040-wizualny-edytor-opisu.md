# ADR-040 — wizualny edytor opisu i sekcji szkicu

Data: 2026-11-05. Status: WYMAGANIE właściciela: opis widoczny z formatowaniem,
a nie jako kod HTML; edycja podobna do Allegro, z przeciąganiem sekcji.
To polecenie rozszerza poprzednią edycję tytułu/pełnego HTML z ADR-035.

## Wykonanie w 0.13

Zamiast pola z kodem w oknie szkicu jest wizualny edytor. Lista sekcji
po lewej umożliwia przeciąganie i alternatywę klawiaturową przez przyciski
w górę/w dół. Po prawej edycja tekstu z formatowaniem lub adresów zdjęć.
Dodawanie tekstu, zdjęcia, tekstu ze zdjęciem i dwóch zdjęć; usuwanie sekcji.
Galeria źródłowych adresów umożliwia przeciągnięcie zdjęcia na listę,
co tworzy nową sekcję. Można także dwukrotnie wybrać zdjęcie.

Tekst renderowany z bezpiecznego HTML, z pogrubieniem, kursywą,
podkreśleniem, listą i nagłówkiem. Kod HTML nie jest pokazywany jako pole
edycji. Osobna zakładka pokazuje pełny opis. Żądania sieciowe i odczyty
plików przez dokument HTML są zablokowane. Ten edytor nie pobiera zdjęć:
bloki zdjęciowe i galeria pokazują adresy HTTPS; nie udają miniatur.

## Własność i zapis

Treść, adresy, kolejność i układ są danymi użytkownika przypisanymi do
konkretnego szkicu. Żadne ustawienia producenta lub treści nie są seedami.
Otwarcie lub anulowanie zachowuje oryginalny pełny HTML i sekcje. Dla
szkicu bez sekcji pełny opis jest pokazany jako roboczy blok tekstowy,
bez trwałej konwersji do chwili faktycznej edycji.

Po pierwszej zmianie układu lub elementu sekcje stają się podstawą pełnego
opisu: teksty i obrazy są składane w kolejności sekcji. Zapis aktualizuje
pełny opis i strukturę razem. Źródłowa galeria pozostaje pulą adresów z
paczki; nowe adresy elementów są zapisane w sekcjach. Pozostałe metadane,
SKU, EAN, cena, pochodzenie i Produkt nie są nadpisywane przez edytor.

Zapis jest atomowy w istniejącym schemacie 7, z kopią bazy i kontrolą
wersji. Zachowany pierwotny odcisk importu zapobiega nadpisaniu edycji lub
duplikatowi po ponownym imporcie oryginalnej paczki. Błąd nie zamyka okna
ani nie czyści wprowadzonych zmian. Podczas zapisu zamknięcie jest blokowane.

Nie ma nowej encji ani migracji, zmienia się istniejąca prezentacja Oferty.
Walidacja formatu adresu jest lokalna, bez testowania dostępności serwera.
Publikacja i wysyłka do szkiców Allegro nadal wymagają przyszłej integracji.
Nie traktować edytora jako potwierdzenia zgodności parametrów z Allegro API.
