# ADR-001 — granice sześciu warstw i składanie

Data: 2026-11-02. Status: wdrożona decyzja techniczna etapu 2, odwracalna.
Autor: Codex w ramach delegacji rutynowych decyzji przez właściciela projektu.
Źródło: bieżące polecenie „Zacznij od etapu 1 […] Następnie przejdź do fundamentu
architektonicznego” oraz konstytucja, sekcja 3. Nie oznacza akceptacji modelu domeny.

Przyjmujemy graf z konstytucji. Punkt składania `vexlab.bootstrap` znajduje się
poza sześcioma warstwami i jako jedyny konstruuje implementacje portów.
`vexlab.__main__` jest wyłącznie wejściem do bootstrapu. Pakiet główny nie ma
efektów ubocznych. Żadna warstwa nie importuje bootstrapu ani `__main__`.

| Warstwa | Dozwolone bezpośrednie zależności wewnętrzne |
|---|---|
| rdzen | brak |
| domena | rdzen |
| przypadki_uzycia | domena, rdzen |
| adaptery | przypadki_uzycia, domena, rdzen |
| kanaly | przypadki_uzycia, domena, rdzen |
| gui | przypadki_uzycia, rdzen |

Graf dozwolonych zależności (strzałka oznacza import, nie przepływ danych):

```mermaid
flowchart TD
    GUI[gui] --> U[przypadki_uzycia]
    GUI --> R[rdzen]
    A[adaptery] --> U
    A --> D[domena]
    A --> R
    K[kanaly] --> U
    K --> D
    K --> R
    U --> D
    U --> R
    D --> R
    B[bootstrap: składanie poza warstwami] -.-> A
    B -.-> K
    B -.-> GUI
    B -.-> U
```

Bootstrap obecnego przykładu składa tylko diagnostykę; nie tworzy GUI ani kanałów.

Alternatywa: umieszczenie składania w GUI lub adapterach powodowałoby zależności
między równorzędnymi warstwami. Rekomendowane zewnętrzne składanie rozstrzyga K-01
bez tworzenia siódmej warstwy biznesowej i bez narzucania kontenera DI.

Kontrakty `.importlinter` sprawdzają bezpośrednie krawędzie każdego węzła grafu.
`allow_indirect_imports=True` jest celowe: GUI może wywołać przypadek użycia,
który korzysta z domeny, ale nie może importować domeny bezpośrednio. Każda
nielegalna krawędź pośredniej ścieżki nadal narusza kontrakt swojej warstwy.
Kontrola AST dodatkowo obejmuje SQL, HTTP i Qt w centrum, SQL w GUI/kanałach
oraz dynamiczne obejścia. Nie jest to sandbox wykonania dowolnego kodu;
dynamiczne zależności nadal wymagają przeglądu.

Dowody: testy mutacyjne kopii projektu odrzucają zabronione importy;
import centrum działa przy zablokowanych Qt/SQL/HTTP; przepływ diagnostyczny
używa wymiennego zegara i czytnika metadanych. Nie powstały encje, migracje,
repozytoria biznesowe, konta ani konektory.

Konsekwencje: dodanie nowej zależności wymaga zachowania grafu. Polskie nazwy
modułów bez znaków diakrytycznych to odwracalna konwencja techniczna.
Techniczny `IdKorelacji` opakowuje UUID wyłącznie dla diagnostyki; nie ustala
formatu ID któregokolwiek z 16 bytów (P-08 pozostaje otwarte).

Zmiany granic wymagają aktualizacji ADR, konfiguracji i dowodów negatywnych.

