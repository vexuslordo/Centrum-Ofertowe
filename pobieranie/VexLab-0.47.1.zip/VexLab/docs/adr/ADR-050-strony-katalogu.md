# ADR-050 — stronicowany odczyt katalogu

2026-11-07. Decyzja techniczna realizująca polecenie właściciela „działaj”
po przyroście 0.21 i wskazaniu stronicowania jako następnego kroku roadmapy.
Nie zmienia modelu domenowego, schematu 11 ani zasad zapisów/usuwania.

## Scenariusz i własność danych

Przeglądanie dużego lokalnego katalogu nie wymaga wczytania do Qt opisów
i dopasowań wszystkich Produktów. Dane nadal należą do lokalnego katalogu;
nie wprowadzamy jeszcze transportu GT. Pojęcia Produkt/Producent i źródłowe
ceny pozostają bez zmian. Zapytanie i strona są modelami odczytu, nie bytami.

## Decyzja techniczna

`ZapytanieKatalogu` zawiera frazę, filtr producenta, numer/rozmiar strony
i kolumnę/kierunek sortowania. Walidacja przed I/O. Port zwraca DTO strony,
globalne liczniki, listę producentów i bieżące wersje jawnie wybranych kartotek.
GUI wywołuje go w tle. Stary pełny odczyt pozostaje zgodny dla innych klientów.

SQLite w jednej transakcji odczytu ustala licznik, koryguje stronę poza
końcem, wybiera posortowane klucze z LIMIT/OFFSET i dopiero dla nich odczytuje
opisy/dopasowania. Materializowana strona zawiera klucze, nie pełne opisy
sortowanego katalogu. Obrazy nie trafiają do tej odpowiedzi; mechanizm 0.21
pozostaje. Dodatkowo odświeżane są rekordy jawnie zaznaczone poza stroną.

Wyszukiwanie używa casefold i literalnego podciągu, również dla znaków
`%`, `_` i apostrofu. Filtr producenta obejmuje brak i nieaktywnego producenta.
Sortowanie działa na całym wyniku; przy remisie stabilny klucz ID. Cena nadal
porządkowana po etykiecie, jak dotychczasowa tabela; nie zmieniamy reguł cen.
Wszystkie wartości są parametrami, SQL jest stały. Bez tworzenia tabel
tymczasowych i zmian opublikowanych migracji.

## Wybór i operacje na wielu stronach

Pasek stron udostępnia 100/250/500 rekordów. Cztery widoki katalogu dzielą
zapytanie, ale mają oddzielne wybory ID/wersji. Ctrl/Shift rozszerza wybór,
zwykłe kliknięcie zaczyna nowy. Przejście strony zachowuje wybór; nowy filtr
czyści go i wraca na początek. Odznacz/Escape usuwa także wybór poza stroną.
PPM w grupie zachowuje grupę, poza nią wybiera tylko kliknięty Produkt.

Zaznacz wszystkie pobiera pełny wynik filtra w tle dopiero na żądanie.
Eksport i usuwanie wszystkich wyników również pobierają pełną migawkę,
zamiast przypadkiem ograniczać się do strony. Błąd odczytu nie powoduje
częściowego wyboru ani zapisu. Zmiana zapytania unieważnia spóźniony wynik
odczytu wszystkich. Zapis/usunięcie nadal kontroluje wersje atomowo i tworzy
kopię według dotychczasowych przypadków użycia.

## Granice i odbiór

Odczyty i zapisy poza wątkiem GUI; Qt otrzymuje najwyżej bieżącą stronę,
poza jawnie utrzymywanym wyborem. Wybranie całego dużego katalogu nadal
wymaga pamięci na pełny zestaw operacji. Nie deklarujemy obsługi miliona
kartotek bez dalszych pomiarów, optymalizacji indeksów i osobnego odbioru GT.
Stronicowanie samych Cenników oraz transport/sekrety GT pozostają osobno.

Wymagane dowody: globalne sortowanie i filtry, brak podwójnych/pominiętych
rekordów, pusty zakres, ostatnia strona po usunięciu, wybór między stronami,
pełny zakres eksportu/usuwania, błąd bez częściowego wyboru, regresja 2375
Produktów w edycji masowej, oba motywy i DPI. Dane tylko w tymczasowych bazach.
