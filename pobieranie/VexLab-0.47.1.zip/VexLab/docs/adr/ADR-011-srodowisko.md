# ADR-011 — odtwarzalne środowisko developerskie

Data: 2026-11-02. Status: konfiguracja lokalna wdrożona i zweryfikowana;
wybrano i przetestowano Python 3.13.18; odbiór na czystym Windows pozostaje otwarty.
Autor: Codex na podstawie delegacji rutynowych, odwracalnych decyzji
w bieżącym poleceniu właściciela projektu. Nie zatwierdza polityki dystrybucji.

| Składnik | Wersja / decyzja |
|---|---|
| CPython | 3.13.18, zakres projektu >=3.13,<3.14 |
| PySide6 / Qt | 6.12.0 |
| SQLite | standardowy moduł `sqlite3` dostarczony z interpreterem |
| uv | 0.13.6 do reprodukcji i CI, przypięty także w dev |
| Backend pakietu Python | hatchling 1.33.0 |
| pytest / pytest-qt | 9.2.0 / 4.5.0 |
| ruff / mypy | 0.17.3 / 2.4.1 |
| import-linter | 2.15 |
| bandit / pip-audit | 1.9.4 / 2.10.1 |

Wersje sprawdzono w PyPI; metadane PySide6 dopuszczają Python >=3.10,<3.16.
Interpreter 3.12.14 był dostępnym interpreterem wybranym dla pierwszej
lokalnej walidacji. Nie jest rekomendacją aktualnej poprawki bezpieczeństwa
ani ostatecznym wyborem dla produktu. Numery z obrazu nie wybierają stosu.

## Rozbieżność raportów i korekta rekomendacji

Właściciel przekazał raport innego stanu: Python 3.13 (lokalnie 3.13.5),
PySide6 6.12.0 i uv 0.10.x. Tego stanu nie należy utożsamiać z checkoutem
niniejszej sesji. Poprzedni odczyt `.python-version`, `pyproject.toml` i `.venv`
potwierdził wtedy 3.12.14 oraz uv 0.12.23. `uv python list --only-installed`
wykazał również `/usr/bin/python3.13` w wersji 3.13.5, nie był to jednak
interpreter ówczesnego środowiska projektu. Dostarczony raport nie jest
dowodem zmiany plików ani wykonania instalacji w tej sesji.

Sprawdzono istnienie oficjalnych tagów CPython `v3.12.16` i `v3.13.5`.
Nie zweryfikowano w tej kontroli daty wydania 3.12.16 ani pełnej listy jego
poprawek. Wcześniejszego pinu 3.12.14 nie należy przedstawiać jako najnowszej
wersji szeregu 3.12. Rekomendacja właściciela dla dalszego przyrostu to
**szereg 3.13**; dokładne aktualne wydanie poprawkowe wybierzemy i sprawdzimy
przed zamknięciem ADR-011. Samo istnienie 3.13.5 nie czyni go docelowym pinem.

PyPI dla PySide6 6.12.0 podaje `Requires-Python: >=3.10,<3.16` i klasyfikatory
3.12 oraz 3.13. Zgodność metadanych nie dowodzi poprawnego importu, działania
GUI ani praw do dystrybucji. Tutaj powtórzono rzeczywisty test Qt offscreen
na Pythonie 3.12.14: renderowanie kontrolki i obsługa zdarzenia przeszły.
Wtedy nie wykonano analogicznego testu Qt na 3.13 ani na czystym Windows;
aktualizację po rzeczywistej migracji opisano poniżej.

Nie zmieniamy działającego interpretera lub blokady wyłącznie na podstawie
tekstu raportu z innej maszyny. Przy przejściu na wybrane wydanie 3.13
trzeba spójnie zmienić pin, requires-python, konfigurację analizatorów, lock,
CI i instrukcje chmury, a następnie wykonać czystą instalację i pełne kontrole.
uv 0.10.x nie jest sprawdzoną wersją tego checkoutu i nie obniżamy do niego
narzędzia bez weryfikacji obsługi bieżącego formatu blokady.

Źródła kontroli: [tagi CPython](https://github.com/python/cpython/tags),
[metadane PySide6 6.12.0](https://pypi.org/pypi/PySide6/6.12.0/json).

`pyproject.toml` przypina zależności bezpośrednie, `uv.lock` — pełny graf,
markery platform i sumy artefaktów. Instalacja: `uv sync --frozen`;
weryfikacja spójności: `uv lock --check`. SQLite nie otrzymuje osobnej,
fikcyjnej zależności pip. Wersję SQLite odczytujemy w każdym środowisku;
obecny Linux dostarcza 3.53.1. Wersja w Pythonie Windows może być inna.
Minimalną wersję SQLite dla produkcji ustalimy przed migracjami w etapie 4.

Alternatywy: pip z osobnymi requirements i ręczną synchronizacją albo Poetry.
uv zapewnia jeden lock dla Linuksa i Windows oraz instalację bez ręcznej aktywacji.
Zmiana narzędzia jest możliwa bez zmiany modelu domenowego. Nie wybrano ORM,
narzędzia migracji ani instalatora Windows. Wheel Python nie jest instalatorem.

Środowisko bieżące: Linux x86_64. Weryfikujemy tu testy, Qt offscreen, build
i narzędzia jakości. CI ma macierz ubuntu-24.04 i windows-2025 (x64).
Windows Server w CI nie zastępuje odbioru na Windows 11, Narratora i różnych DPI.
Rekomendacja stanowiska developerskiego: Windows 11 x64; ostateczna macierz
systemów użytkownika i sprzęt referencyjny wymagają decyzji przed dystrybucją.

PySide6 instaluje także komponenty Addons/WebEngine/PDF; nie używamy ich w kodzie.
Audyt obejmuje cały zainstalowany graf, nie tylko moduły importowane przez przykład.
QFluentWidgets nie został dodany ani zakupiony. Warunki dystrybucji PySide6,
zasobów i aplikacji wymagają przeglądu przed wydaniem.

Do etapu 5 rekomendujemy testowe zrzuty Qt (`QWidget.grab`) i porównanie `QImage`
przy ustalonej skali, z raportem różnic i przeglądem człowieka. Wykres: wstępnie
własny komponent QPainter, bez nowej biblioteki i bez domyślnej adopcji QtCharts.
Nie jest to implementacja ani pomiar zgodności UI. Ikony: własne zasoby SVG;
logotypy platform dopiero po sprawdzeniu ich warunków. Font systemowy bez
kopiowania plików Segoe do dystrybucji. To odwracalne rekomendacje techniczne.

Dowody i ograniczenia: [raport przyrostu](../RAPORT_ETAPY_1_2.md).


## Aktualizacja po wykonaniu przyrostu 0.2

Na podstawie polecenia kontynuowania tworzenia programu wykonano migrację
z walidacją, zamiast zmiany wyłącznie na podstawie tekstowego raportu.
Wybrano CPython **3.13.18** i **uv 0.13.6**. Zweryfikowano oficjalny tag
CPython i zainstalowano dystrybucję przez uv z zachowaniem TLS i weryfikacji
artefaktu. Potwierdzono dostępność tego interpretera dla Windows x64.
PySide6 pozostaje **6.12.0**. Zmieniono pin, zakres Pythona, konfigurację
ruff/mypy, uniwersalny lock, CI i instrukcje środowiska.

Przeprowadzono rzeczywiste testy Qt i aplikacji na 3.13.18, pełne kontrole
oraz drugą czystą instalację. Wyniki są w raporcie przyrostu 0.2.
Wcześniejsze 3.12.14 i uv 0.12.23 są historią pierwszego raportu, nie bieżącym
stanem projektu. CI używa Pythona 3.13 jako bootstrapu do instalacji uv,
a uv odtwarza dokładne **3.13.18** zapisane w `.python-version`.
Windows i docelowa dystrybucja nadal wymagają rzeczywistego odbioru.
