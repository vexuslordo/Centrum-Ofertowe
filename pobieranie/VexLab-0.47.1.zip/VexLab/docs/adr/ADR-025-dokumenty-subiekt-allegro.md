# ADR-025 — przyszły łącznik dokumentów Subiekt → Allegro

Data: 2026-11-02. Status: wymaganie właściciela zapisane do przyszłej
realizacji; integracja niewdrożona. Źródło: bieżące polecenie właściciela.

## Scenariusz i zakres

Po wydrukowaniu faktury lub paragonu w Subiekcie VexLab ma automatycznie
przekazać dokument do konkretnego zamówienia Allegro. Subiekt pozostaje
źródłem dokumentu. VexLab jest łącznikiem, bez własnego archiwum dokumentów
i bez trwałego przechowywania ich treści ani danych nabywcy w tym module.
Nie wystawia dokumentów i nie zastępuje systemu księgowego.

Wymaganie „nie przechowywać żadnych danych” zapisujemy w kontekście tego
łącznika. Nie jest poleceniem usunięcia zatwierdzonego lokalnego katalogu
Produktów, Producentów ani istniejących danych użytkownika.

## Do rozstrzygnięcia przed implementacją

- Wersja Subiekta, dostępny mechanizm integracji, wymagane licencje/koszty
  oraz sposób wykrycia faktycznego wydruku. Samo wystawienie dokumentu
  lub pojawienie się pliku nie jest potwierdzonym odpowiednikiem wydruku.
- Obsługa faktur i paragonów przez aktualne API Allegro, formaty i limity
  załączników, uprawnienia konta i sposób uzyskania dokumentu z Subiekta.
  Nie zakładamy, że oba rodzaje dokumentów mają identyczną obsługę.
- Jednoznaczne powiązanie dokumentu z identyfikatorem zamówienia i właściwym
  kontem Allegro. Brak lub niejednoznaczność powiązania blokuje wysłanie;
  nie dopasowujemy wyłącznie po nazwisku lub kwocie.
- Ponowny wydruk, duplikaty, korekty, brak sieci, restart i nieznany wynik
  wysyłki. Uzgodnić, czy wolno zachować minimalne metadane techniczne
  (identyfikatory/status), czy stan odtwarzać wyłącznie z systemów źródłowych.
  Ten ADR nie udziela zgody na trwałą kolejkę ani logowanie danych dokumentu.
- Jeżeli wymagany będzie plik tymczasowy: uzgodnić jego dopuszczalność,
  lokalizację, czas życia i sprzątanie także po awarii. Nie tworzyć trwałego
  cache pod nazwą pliku tymczasowego. Sekrety poza dokumentami i logami.

Rekomendacja do oceny przy wdrożeniu: pobierać treść na żądanie z Subiekta,
przekazywać ją bez archiwizacji, a możliwość bezpiecznego ponowienia oprzeć
na uzgadnianiu stanu z systemami zewnętrznymi. Przy całkowitym braku lokalnego
stanu gwarancja dostarczenia po restarcie zależy od możliwości tych systemów;
nie obiecujemy jej bez weryfikacji.

## Granice i odbiór przyszłego przyrostu

Adapter Subiekta → port/przypadek użycia przekazania dokumentu → adapter
Allegro. Konektory nie importują się wzajemnie, GUI nie wykonuje I/O.
Nie zmieniamy obecnie 16 bytów, schematu SQLite ani istniejących kontraktów.

Odbiór obejmie właściwe zamówienie i konto, oba wspierane rodzaje dokumentów,
ponowny wydruk bez niezamierzonego duplikatu, odmowę autoryzacji, brak sieci,
timeout po wysłaniu, restart oraz brak treści dokumentów i danych nabywcy
w bazie, logach, kopiach i pozostawionych plikach. Testy zewnętrzne wyłącznie
w odpowiednim środowisku testowym; sukces dopiero po potwierdzeniu Allegro.
