# ADR-029 — pełniejszy opis, waluty i tłumaczenie nazw

Data: 2026-11-02. Źródło: wymagania właściciela po próbie importu 0.5.
Status mieszany: poprawka opisu wdrożona w 0.5.2; ceny i AI wymagają
kolejnego przyrostu. Nie zmieniono 16 głównych bytów ani schematu 3.

## Opis z pliku — wdrożone

Właściciel potrzebuje w opisie także nazwy/modelu motocykla, jeśli dane
źródłowe zawierają takie dopasowanie. W przesłanym Evotech MARKA zawiera
samą markę pojazdu, a nazwa, model i roczniki znajdują się w Title.
Nie wyprowadzać ich jako potwierdzonych strukturalnych dopasowań wyłącznie
z tytułu; dopuszczamy jawne skopiowanie tekstu źródłowego do opisu.

Mapowanie pozwala wybrać opis i dodatkową kolumnę opisu oraz opcjonalnie
włączyć dołączenie pełnej nazwy źródłowej. Puste fragmenty pomijane,
identyczne niepowtarzane, rozdzielane pustą linią. Kolumna nazwy może też
być kolumną opisu; nazwa i SKU nadal muszą być różnymi kolumnami.
Formuły w dodatkowych polach nadal wymagają korekty, bez ich wykonywania.
Zmiana mapowania unieważnia plan. Podgląd zawiera opis, dwuklik otwiera
pełny tekst przed zapisem. Nie ma wymogu wskazania pojazdu dla produktu
uniwersalnego lub niezwiązanego z motocyklami. Nie uzupełniamy braków z domysłów.

Dotyczy nowych planów importu; nie nadpisuje wcześniejszych Produktów.
Dla istniejących danych pozostaje jawna edycja Produktu. Automatyczne
aktualizacje lub masowe zmiany wymagają odrębnego podglądu zakresu i różnic.

## Ceny — potwierdzone znaczenie i propozycja następnego zakresu

Właściciel potwierdził: omawiane kwoty to sugerowane ceny sprzedaży,
nie ceny zakupu. Różne cenniki mogą być w GBP albo EUR (także PLN).
Widoczne nagłówki GBP/PLN są oryginalnymi nagłówkami przykładowego XLSX,
nie stałymi walutami importera. Wersja 0.5.2 nadal nie zapisuje cen.

Propozycja konkretnego kolejnego przyrostu: dla każdej wybranej kolumny ceny
użytkownik wskazuje walutę źródłową i rodzaj netto/brutto. Wiersz ceny
sugerowanej zawiera referencję Produktu, kwotę dziesiętną (bez float),
walutę, netto/brutto i pochodzenie z pliku/arkusza/wiersza. Pozostaje danymi
źródłowymi cennika, odrębnymi od aktywnej ceny Oferty. Brak kwoty nie oznacza
zera. Nie zmieniamy waluty przez zmianę etykiety. Waluty nie sumują się.

Nie przeliczać automatycznie walut, nie wyprowadzać brutto bez uzgodnionej
stawki VAT ani nie stosować marży. Kurs, jego data, źródło, zasady VAT,
zaokrąglenia i aktualizacja starszej ceny wymagają ustalenia przed wdrożeniem.
Pierwszy przyrost powinien zachować oryginalną kwotę/walutę bez zmiany cen
publikowanych. Dokładny model cennika/snapshotu i migrację opisać przed zapisem.

## Tłumaczenie — wybór dostawcy, bez zgody na płatne wywołania

Właściciel wybrał OpenAI API spośród zaproponowanych dostawców. Następnie
zapytał, czy usługa jest bezpłatna. Wyjaśniono, że API jest płatne i odrębnie
rozliczane od abonamentu ChatGPT. Budżet nie został ustalony; rekomendowane
5 USD nie jest przyjętym limitem. Wstrzymano podłączanie płatnego API.
Nie zaimplementowano konektora i nie wykonano płatnych wywołań.

Proponowany proces: oryginalna nazwa i wybrane fakty → tłumaczenie na polski
→ porównanie oryginału z propozycją → jawna akceptacja. Zachować markę,
model, roczniki, SKU i parametry, bez tworzenia nowych faktów lub dopasowań.
AI nie publikuje i nie nadpisuje całego katalogu automatycznie. Dane z pliku
traktować jako dane, a nie polecenia dla modelu. Nie wysyłać sekretów, cen
lub danych klientów, jeśli nie są potrzebne do tłumaczenia nazwy.

Przed realizacją ustalić koszt/limit, model, zakres przekazywanych treści,
sposób bezpiecznej konfiguracji klucza i obsługę awarii, limitów, błędnego
wyniku oraz nieznanego kosztu po timeout. Klucza nie podawać w rozmowie,
nie przechowywać w SQLite ani logach. Dostawca za portem przypadków użycia,
HTTP w adapterze, I/O poza GUI. Nie deklarować działania przed próbą API.

Alternatywa do rozważenia: lokalny tłumacz bez opłat za wywołania API,
z osobnym pobraniem modelu, oceną licencji, wymagań sprzętowych i jakości.
Nie jest wdrożony ani wybrany automatycznie w miejsce OpenAI.

## Stan po przyroście 0.6

Poprawka opisu z etapu roboczego 0.5.2 została wydana łącznie z 0.6.
Minimalny zapis sugerowanej ceny z walutą i netto/brutto oraz uzupełnianie
brakujących cen istniejących Produktów wdrożono według ADR-030.
Przeliczanie walut i aktywne ceny Ofert pozostają otwarte. OpenAI API
nie podłączono — pytanie właściciela o bezpłatność nie akceptuje budżetu.
