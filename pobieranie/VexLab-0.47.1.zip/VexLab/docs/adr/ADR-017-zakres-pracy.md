# ADR-017 — przejście od dokumentacji do etapów 1–2

Data: 2026-11-02. Status: wymaganie właściciela projektu z bieżącej rozmowy.
Zakres: środowisko i fundament architektoniczny bez funkcjonalności biznesowych.
Źródło: „Rozpoczynamy pracę nad aplikacją Windows […] Zacznij od etapu 1
roadmapy […] Następnie przejdź do fundamentu architektonicznego”.

Zastępuje historyczne ograniczenie „wyłącznie dokumentacja” w AGENTS/README
i W-09. Bieżące polecenie zezwala na kod techniczny, konfigurację, testy i CI
oraz rutynowe odwracalne decyzje. Nie zatwierdza propozycji pól, agregatów,
liczności, źródeł cen, AI, retencji, uprawnień ani schematu bazy.

K-01 rozstrzygnięto technicznie w ADR-001. Wersje P-11 opisuje ADR-011.
K-02 (etapy 6/7) rekomendujemy rozwiązać wspólnymi pionowymi scenariuszami,
bez logiki w GUI; nie blokuje to pustego fundamentu. P-02/P-03/P-04/P-08
oraz ADR-013–016 pozostają do rozpatrzenia przed zależnymi funkcjami.
K-07 (Cennik/media/szablony względem 16 bytów) wymaga decyzji modelowej;
na tym etapie nie dodajemy klas zastępczych ani tabel dla tych pojęć.

Repozytorium istnieje w `/workspace/Centrum-Ofertowe`, więc Q-01 jest spełnione
przez bieżące środowisko. W tej wiadomości nie udostępniono dostępnego ZIP;
bazą jest komplet 7 dokumentów i PNG z commitu `08b2b04`.
Nie deklarujemy porównania treści z niedostępnym archiwum.

Nie jest potrzebna blokująca decyzja biznesowa dla tego przyrostu. Przed
implementacją modelu przedstawimy konkretne scenariusze, rekomendacje,
alternatywy i konsekwencje, zamiast zatwierdzać cały dokument domyślnie.

