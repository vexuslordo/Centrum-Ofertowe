# ADR-048 — paczki szkiców niezależne od zakładania Produktów

2026-11-06, kontynuacja „działaj dalej” po 0.19. Realizacja kierunku właściciela:
ZIP gotowych ofert nie tworzy Produktów ani w katalogu lokalnym, ani w Subiekcie.
Przyszły katalog Subiekt jest tylko do odczytu. Ten etap nie wdraża konektora
Subiekta lub kanałów i nie wykonuje zdalnych zapisów.

## Scenariusz i model przed implementacją

ZIP → sprawdzenie ofert → jawny zapis lokalnych szkiców → edycja/podgląd/usuwanie.
Nie ma kroku tworzenia kartotek. SKU/tytuł/HTML/sekcje/galeria/cena/EAN pozostają
prezentacją użytkownika w szkicu; szkic nie jest konkurencyjną kartoteką Produktu.
Przyszłe dopasowanie do zewnętrznego Produktu będzie osobnym odczytem, bez
wymuszania fikcyjnego lokalnego ID. Nie tworzymy nowego głównego bytu.

Zastępuje wymaganie ADR-035/0.12, że każdy lokalny szkic musi mieć Produkt.
Nowe szkice z ZIP mają brak lokalnego powiązania i wersji Produktu. Para pól
musi być albo kompletna (ID i dodatnia wersja), albo obydwa puste. Dane szkicu
mają własną wersję. Dawne powiązania zostają zachowane; starych kartotek nie
usuwamy. Nadal działa ich kontrola aktualności i ochrona przed usunięciem
Produktu z powiązanymi szkicami. Nie dopasowujemy nowych szkiców automatycznie
po podobieństwie lub do przypadkowego lokalnego Produktu o tym samym SKU.

Alternatywy odrzucone: zakładanie pustych/fikcyjnych Produktów (łamie kierunek
właściciela), automatyczne kasowanie starych kartotek (ryzyko utraty danych),
łączenie ze strukturą konkretnego Subiekta przed poznaniem jego wersji.

## Porty i transakcje

SzkiceOfert zależy tylko od magazynu szkiców. Planowanie nie czyta katalogu,
a zapis nie zna importera Produktów. Z interfejsu ZIP usuwamy osobny przycisk
zakładania Produktów, wybór ich producenta i sprawdzanie katalogu. Zapis szkiców
pozostaje jawny, atomowy, z kopią i pomijaniem identycznych ofert po odcisku.
Nie wykonuje HTTP i nie publikuje. Edycja/anulowanie nadal nie zmienia źródła.

## Migracja i przywracanie

Schemat 11 przebudowuje wyłącznie tabelę szkice: opcjonalne produkt_id i
wersja_produktu z ograniczeniem kompletności. Kopiuje wszystkie wartości,
ID, odciski i kolejność rowid, odtwarza indeks. Jedna transakcja z blokadą
zapisu i kopią przed zmianą. Migracje 1–10 i ich sumy pozostają niezmienione.
Niestandardowe indeksy/wyzwalacze na przebudowywanej tabeli blokują migrację,
aby nie usuwać ich niejawnie. Błąd w dowolnym kroku wycofuje przebudowę.

Powrót do 0.19: zabezpieczyć bieżącą bazę i przywrócić kopię schematu 10.
Nie próbować uruchamiać starej wersji na schemacie 11; nowe szkice z późniejszej
bazy nie znajdą się w kopii. Bez automatycznego usuwania danych i kopii.

## Kryteria odbioru

- Nowy i istniejący SKU z ZIP nie tworzą ani nie modyfikują Produktów.
- Planowanie nie wymaga katalogu, zapis nie wykonuje INSERT/UPDATE Produktów.
- Powtórzenie pomija identyczne oferty; edycja i restart zachowują pełną treść.
- Migracja zachowuje dawne szkice/powiązania/wersje/rowid i kontrolę konfliktu.
- Awaria migracji/kopii/zapisu nie zostawia częściowego wyniku.
- Usuwanie samodzielnego szkicu nie zmienia katalogu; stare zabezpieczenia
  usuwania powiązanego Produktu nadal mają testy na danych sprzed migracji.
