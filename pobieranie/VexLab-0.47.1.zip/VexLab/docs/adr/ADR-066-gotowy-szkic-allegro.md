# ADR-066 — kompletne ustawienia szkicu i sygnatura SKU

Polecenia właściciela 2026-11-13: przygotować szkic z GPSR, dostawą i warunkami
sprzedaży, tak by pozostała odrębna publikacja; external.id ma być SKU.
Uprościć formularz parametrów: wymagane/dodatkowe, automatyczne SKU/EAN,
źródła w opcji zaawansowanej, bez poziomego przewijania.

Odczyt słowników rzeczywistego konta: producenci/osoby GPSR, cenniki dostaw,
zwroty, reklamacje, gwarancje. Wymaga sale:settings:read; ponowne nadanie
uprawnień istniejącym procesem bez rozłączania. Brak nowych zapisów do
rejestrów producentów lub generowania treści bezpieczeństwa. Wybór osoby
odpowiedzialnej albo jawne Nie dotyczy. Dane lokalizacji, czasu wysyłki,
faktury i informacji o bezpieczeństwie podaje użytkownik. Profile są DTO
w bieżącym przygotowaniu, nie nowym lokalnym Produktem lub PodmiotemGPSR.

POST INACTIVE zawiera delivery/location/payments/afterSalesServices oraz
GPSR w elemencie productSet (nie w product). Preflight kontroluje wybrane
odwołania na koncie. GET potwierdza zapis wszystkich pól; błędy walidacji
Allegro nie są gotowością do publikacji. Brak błędów nie daje gwarancji
późniejszej publikacji wobec zmiennych reguł API.

Sygnatura nowego szkicu to dokładne SKU do 100 znaków. Hash nadal jest
wyłącznie kluczem wewnętrznego rejestru. Sprawdzenie wcześniejszych prób
uwzględnia stare external.id vexlab-hash i zachowuje blokadę ponowień.
Nie usuwać starych rejestrów ani ich odcisków. Rozszerzenia DTO bez repr
nie zmieniają dawnych odcisków, nowa konfiguracja jest haszowana osobno.
Bez migracji SQLite i automatycznych publikacji/testowych zapisów na koncie.


Poprawka 0.43.1: okno musi powstać przed pobieraniem słowników, nie dopiero
po sukcesie sześciu GET. Opcjonalny odczyt częściowy z opisami błędów per
słownik; bez cache dla niepełnego wyniku. Wybrane identyfikatory wymagają
potwierdzenia swojego słownika, niewybrana dodatkowa gwarancja nie blokuje
pozostałych danych. UI pokazuje odmowę/brak scope, ponawia w tle, zachowuje
tekst, ignoruje wyniki zamkniętego okna i innej sesji.


0.43.2 — właściciel potwierdził korzystanie z lokalizacji konta Allegro.
Pusty komplet czterech pól oznacza brak własnego nadpisania: bez location
w POST (nie null ani pusty obiekt). Formularz domyślnie ukrywa adres pod
opcjonalnym checkboxem. Zachować dotychczasowe własne adresy i ich repr,
walidować częściowy ręczny adres. GET może zwrócić lokalizację uzupełnioną
przez Allegro, nie porównywać jej do pustych pól klienta. Walidacja Allegro
nadal warunkiem deklaracji kompletności. Potwierdzenie kontraktu:
https://developer.allegro.pl/tutorials/jak-jednym-requestem-wystawic-oferte-powiazana-z-produktem-D7Kj9gw4xFA#jak-ustawic-wlasny-adres-z-ktorego-wysylany-jest-przedmiot
