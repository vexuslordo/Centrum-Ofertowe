# ADR-037 — pierwszy podgląd ZIP, profile użytkownika i identyfikacja wizualna

Data: 2026-11-03. Status: wdrożony przyrost techniczny 0.10 w autoryzowanym
zakresie odczytu gotowych ofert i ustawień użytkownika (ADR-036).
Docelowy proces obejmuje publikację na Allegro zgodnie z doprecyzowaniem
właściciela; ten przyrost nie wdraża publikacji ani trwałego modelu Oferty.
Nie uznano go za zatwierdzenie pozostałych propozycji ADR-035.

## Dlaczego etap odczytu

Właściciel dostarczył paczkę i wymaga niezależnych układów producentów jako
danych użytkownika. Można zweryfikować ZIP, mapowanie i podgląd sekcji bez
zapisu nieuzgodnionej relacji Produkt/Oferta, ceny, EAN czy konta.
Daje to działający pierwszy fragment przyszłego procesu publikacji,
bez deklarowania integracji na podstawie lokalnego odczytu.

Pierwszy format: wybrany plik JSON zawierający listę obiektów. Pozostałe
pliki są wykazywane w inwentarzu; nie są wykonywane. Nie obiecuje to obsługi
każdego eksportu ZIP. Kolejne formaty można dodać za portem czytnika.

## Konfiguracja jest danymi użytkownika

Profil określa nazwę pliku wewnątrz ZIP oraz pola SKU, tytułu, opisu,
sekcji, galerii i opcjonalnych danych źródłowych. Definicja struktury
sekcji również konfigurowalna: klucze elementów/typu/tekstu/adresu i wartości
rozróżniające tekst/obraz. Brak nazw producentów, domen, banerów i treści
w kodzie lub seedach. Domyślna instalacja ma puste mapowanie.

Profil JSON wersji 1 można zapisać pod nową nazwą i wczytać później.
Nie nadpisuje się istniejącego pliku. Profil nie przechowuje sekretów,
nie jest wykonywalnym skryptem i nie stanowi konfiguracji konta Allegro.
Przygotowany na podstawie załącznika profil użytkownika Evotech przekazano
jako osobny plik poza katalogiem źródeł i paczką programu.

## Podgląd

Nowe oferty ma osobną stronę z inwentarzem, mapowaniem i tabelą rekordów.
Dane pozostają w pamięci. Szczegóły pokazują tytuł, surową cenę/EAN/tekst
pojazdu, galerię adresów, opis i kolejność sekcji. Galeria Produktu i banery
w sekcjach nie są automatycznie scalane. Obrazy są adresami/slotami,
nie są pobierane i nie potwierdzono ich dostępności.

HTML wyświetlany statycznie po filtracji do ograniczonych znaczników;
brak atrybutów, skryptów, zewnętrznych stylów, obrazów i aktywnych linków.
Dodatkowo zablokowano pobieranie zasobów QTextBrowser. Oryginalny opis można
obejrzeć jako tekst źródłowy, bez wykonywania. Nie jest to jeszcze wierny
renderer Allegro ani test zgodności jego walidatora.

Błędy pól i nieobsługiwanych elementów widoczne per rekord. Powtórzone SKU
nie są scalane ani odrzucane z podglądu: oznaczane do późniejszego uzgodnienia.
Cena pozostaje surowym polem z paczki; bez domyślnej waluty/VAT, obliczeń
lub zapisu do ceny sugerowanej Produktu. fit pozostaje tekstem źródłowym,
nie potwierdzonym dopasowaniem. Nie odczytuje się instrukcji jako poleceń.

## Ograniczenia i granice

ZIP nie jest rozpakowywany na dysk. Limity: archiwum 32 MiB, suma 128 MiB,
plik wewnętrzny 32 MiB, 2000 wpisów, kompresja do 200:1, zbiór do 20000
rekordów i 200 pól. Są to techniczne limity pierwszej implementacji,
nie zatwierdzony wolumen docelowy. Przekroczenie daje jawny błąd.
Odrzucane ścieżki absolutne, wyjścia przez .., ścieżki Windows/ADS,
dowiązania, zduplikowane nazwy i zaszyfrowane wpisy. CRC sprawdzane przy
ograniczonym odczycie każdego pliku. Nie ma rekurencyjnego odczytu ZIP-ów.

Odczyt/parsowanie/profil i walidacja poza wątkiem GUI. Tabela uzupełniana
partiami z oddawaniem sterowania; zmiana mapowania unieważnia stary wynik.
Porty i neutralne DTO w przypadkach użycia; ZIP/JSON plików w adapterach;
GUI nie zna SQLite ani czytnika archiwum; jawny bootstrap. Brak migracji
schematu 6, zewnętrznych zależności i biznesowych seedów.

## Logo i motywy — odrębne jawne polecenie właściciela

Właściciel dostarczył logo VexLabs i wymaga usunięcia białego tła oraz
kolorystyki zgodnej z nim. Przygotowano transparentny PNG narzędziem edycji
obrazu; oryginału nie zmieniono. Kanał alfa i przezroczyste narożniki
sprawdzone. Logo w nagłówku i ikonie okna jest zasobem aplikacji.

Paleta granat/turkus/fiolet ze złotym akcentem zastępuje poprzedni niebieski
akcent; układ UI-REF-01 i opcje zachowane. Motyw jasny używa neutralnego
tła i tej samej palety akcentów. Nazwa aplikacji i katalog danych pozostają
VexLab; grafika zawiera dostarczony napis VexLabs. Nie zmieniono tożsamości
katalogu danych ani nazwy użytkownika w nagłówku.

## Nadal wymagane dla pełnego procesu Allegro

Trwały model Oferty i ponownego importu, powiązanie z Produktem, cena,
EAN/parametry oraz model układu; konfiguracja realnego konta i sekretów;
sprawdzone kontrakty API, wymagania kategorii, cenniki dostaw, warunki
sprzedaży i podmioty wymagane w danej kategorii. Profil publikacji użytkownika
wybierze ustawienia spośród rzeczywiście dostępnych w API. Braki wymagają
rozstrzygnięcia, bez zgadywania danych. Następnie walidacja, podgląd zakresu,
wysyłka, wynik per oferta i uzgodnienie nieznanego wyniku/ponowienia.
Żadnych publikacji lub zmian konta nie wykonano w tym przyroście.
