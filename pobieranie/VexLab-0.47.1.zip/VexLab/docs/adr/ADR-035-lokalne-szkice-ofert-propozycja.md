# ADR-035 — pierwszy lokalny szkic Oferty

Data propozycji: 2026-11-03. Status: ZATWIERDZONE przez właściciela
2026-11-05 odpowiedzią „tak” i poleceniem „działamy”, dla zakresu 0.12
z opisanego niżej rozszerzenia ZIP.
Wynika z następnego obszaru B roadmapy: Nowe oferty i Szkice.
Nie wdrożono modelu ani migracji; zakres poniżej nie oznacza publikacji.

## Proponowany pierwszy scenariusz

Użytkownik wybiera istniejący Produkt, przygotowuje tytuł i opis Oferty,
zapisuje szkic, odnajduje go po restarcie oraz poprawia. Produkt pozostaje
wspólnym źródłem danych katalogowych; Oferta jest jego prezentacją.

Rekomendacja do zatwierdzenia jako jeden mały przyrost:

- Jeden szkic wskazuje dokładnie jeden istniejący Produkt. Jeden Produkt
  może mieć kilka szkiców; nie tworzymy drugiego Produktu przy zmianie tytułu.
- Początkowy tytuł i opis kopiowane z wybranego Produktu do edytowalnej
  prezentacji szkicu. Zapis szkicu nie zmienia nazwy/opisu katalogowego.
- Zmiana Produktu nie nadpisuje później tytułu/opisu zapisanej Oferty.
  Zapamiętana wersja źródłowego Produktu pozwala pokazać informację, że
  dane katalogowe się zmieniły. Aktualizacja treści pozostaje świadoma.
- Szkic lokalny może istnieć bez konta i kanału sprzedażowego. Nie tworzymy
  fikcyjnych kont Allegro/PrestaShop. Wybór prawdziwego konta i wymagania
  konkretnego kanału nastąpią w przyroście integracyjnym, przed publikacją.
- Jedyny stan pierwszego przyrostu to „Szkic lokalny”. Nie oznacza gotowości
  ani aktywnej oferty. Brak statusów „opublikowano” lub „połączono”.
- Tytuł wymagany, opis opcjonalny. Limity publikacji nie są zgadywane
  z API jednej platformy. Cena docelowa, ilość, kategorie, GPSR, warianty,
  zestawy i układy nie otrzymują teraz nowych reguł własności pól.
- Edycja chroniona wersją szkicu; usuwanie szkicu po potwierdzeniu.
  Usunięcie szkicu nie usuwa Produktu. Usunięcie Produktu mającego szkice
  jest blokowane z czytelną informacją, bez kaskadowego kasowania szkiców.

Przykład syntetyczny: Produkt TEST-1 „Część katalogowa” → szkic A
„Część do Modelu X” oraz szkic B „Część — inna prezentacja”. Oba wskazują
TEST-1. Edycja A nie zmienia B ani nazwy Produktu. Produkt TEST-2 może
nie mieć żadnego szkicu. Dane przykładów nie są seedami.

## Dane, odpowiedzialność i architektura

Oferta jest jednym z istniejących 16 pojęć, proponowanym samodzielnym
agregatem kontekstu Sprzedaż. ID szkicu, ID Produktu, tytuł, opis,
wersja Produktu użyta do przygotowania i wersja edycji szkicu. Nie zapisujemy
zewnętrznych identyfikatorów i stanów zmyślonej integracji.

Domena odpowiada za tytuł i reguły edycji, przypadki użycia za utworzenie/
odczyt/edycję/usunięcie i porty, SQLite za transakcje oraz referencję,
GUI za formularz i osobną listę Szkice. Bootstrap składa porty.
Nowe oferty otwiera formularz, Szkice listę; nie są aliasem strony Produkty.

Produkt do utworzenia szkicu musi istnieć i odpowiadać wersji pokazanej
w podglądzie, żeby użytkownik nie zatwierdził innej treści. Zapis szkicu
nie blokuje późniejszej edycji Produktu. Odczyt i zapis poza wątkiem GUI.
Podgląd nie kopiuje obrazów ani dopasowań do konkurencyjnego katalogu;
pozostają danymi wskazanego Produktu, z oznaczeniem aktualności źródła.

Po zatwierdzeniu proponowana migracja 6→7 z kopią, osobna tabela lokalnych
szkiców, referencja do Produktu i kontrola wersji. Migracje 1–6 zachowane.
Dotychczasowe Produkty, importy, zdjęcia, ceny i dopasowania bez zmian.
Kopia i przywrócenie muszą być sprawdzone przed wydaniem.

## Alternatywy i zakres późniejszy

Wymaganie konta od pierwszego szkicu uzależniłoby pracę lokalną od
niewdrożonej konfiguracji kont. Jedna Oferta na Produkt uniemożliwiłaby
później różne prezentacje i wiele kont. Wieloproduktowe zestawy wymagają
osobnego modelu — nie są dodawane do pierwszego przyrostu.

Cena Oferty nie jest automatycznie ceną sugerowaną z cennika; reguły ceny,
waluty, podatków i źródeł pozostają do konkretnego następnego scenariusza.
Właściwe konto/kanał, kategorie i wymagane parametry muszą zostać wskazane
przed jakąkolwiek publikacją. Ten szkic nie gwarantuje późniejszego przyjęcia
przez Allegro lub PrestaShop.

## Kryteria akceptacji po decyzji

Utworzenie dwóch szkiców jednego Produktu, edycja bez zmiany Produktu,
restart, znalezienie i podgląd, konflikt wersji, zmiana źródłowego Produktu
bez nadpisania prezentacji, blokada usunięcia Produktu ze szkicami,
potwierdzone usunięcie szkicu, rollback oraz aktualizacja/odtworzenie bazy.
Osobne strony Nowe oferty/Szkice, pusta instalacja, oba motywy i klawiatura.
Brak publikacji i sztucznych kont. Audyt całego zakresu 1.0 pozostaje
odrębnym [wymaganym punktem kontrolnym](../AUDYT_1_0_PLAN.md).

Uzupełnienie 2026-11-03: właściciel wymaga także importu gotowych ofert
w ZIP (ADR-036). Propozycję zakresu należy uzupełnić po analizie paczki.
W imporcie gotowa treść źródłowa nie może być zastąpiona kopią z Produktu.
Nie uznano tego wymagania za zatwierdzenie pozostałych relacji niniejszej propozycji.

## Konkretna propozycja kolejnego przyrostu 0.12 — 2026-11-04

Status nadal PROPOZYCJA; polecenie kontynuacji roadmapy nie rozstrzyga
poniższych nowych reguł trwałego modelu. Rozszerzenie uwzględnia działające
paczki ZIP i zapamiętane profile z 0.11. Nie zastępuje tego przepływu
formularzem tworzenia oferty od zera.

### Przebieg dla gotowej paczki

1. Wczytanie i rozpoznanie ZIP jak obecnie, z zachowaniem pełnej treści
   ofert i ustawień użytkownika. Sam podgląd niczego nie zapisuje.
2. Dodatkowa akcja „Zapisz jako szkice” pokazuje podsumowanie: nowe
   Produkty, istniejące Produkty dopasowane po SKU, szkice i błędne wiersze.
3. Po zatwierdzeniu prawidłowe oferty tworzą lokalne szkice. Brakujący
   Produkt jest tworzony według istniejących zasad importu z ZIP; istniejący
   Produkt nie jest nadpisywany. Zapis Produktów i szkiców jest atomowy.
   Wiersze niepoprawne nie tworzą szkiców, a podsumowanie wskazuje powód.
4. Po restarcie osobna zakładka „Szkice” pokazuje zapisane oferty,
   pozwala je odnaleźć, podejrzeć i usunąć po potwierdzeniu.
5. Ponowny zapis identycznej oferty z tej samej paczki nie tworzy duplikatu.
   Zmieniona treść dla tego samego SKU nie nadpisuje starego szkicu:
   użytkownik wybiera utworzenie kolejnej prezentacji. Nie ma globalnego
   ograniczenia „jeden szkic na SKU”.

### Co jest zapisywane

Powiązanie z jednym Produktem i jego wersją źródłową, własny tytuł,
pełny źródłowy opis HTML, uporządkowane sekcje tekst/obraz, galeria URL,
źródłowe wartości EAN/ceny/tekstu dopasowania oraz pochodzenie paczki.
Zachowane źródłowe wartości nie są automatycznie poprawnymi parametrami
publikacji. Brak waluty, podstawy VAT lub innych danych pozostaje brakiem;
nie zgadujemy ich z producenta, SKU ani instrukcji w archiwum.

Treści źródłowe pozostają danymi. Nie wykonujemy HTML/JS, instrukcji ani
linków z ZIP. Adresy obrazów są zapisywane bez pobierania plików podczas
importu. Układ i treść nie są zastępowane tekstowym opisem Produktu.
Profil odczytu nadal pozostaje ustawieniem użytkownika, poza modelem Oferty.

Szkic nie otrzymuje fikcyjnego konta, kategorii, statusu publikacji lub
ustawień producenta. Późniejszy etap Allegro sprawdzi wymagania konta,
kategorii, ceny i parametrów przez API przed wysyłką. Zapamiętany szkic
nie jest dowodem gotowości do publikacji.

### Transakcje, interfejs i odbiór

Przy zapisie kontrola wersji istniejących Produktów oraz kopia bazy.
Proponowany schemat 7: lokalne szkice i ich treści z kluczem obcym do
Produktu oraz znacznikiem idempotencji źródła. Bez zapisu pełnego modelu
Allegro jako domeny. Usunięcie Produktu powiązanego ze szkicem jest
blokowane, usunięcie szkicu nie usuwa Produktu. Brak kaskadowego kasowania.

Warstwy: domena Oferta i reguły edycji; przypadki użycia + port zapisu
paczki; adapter SQLite + migracja; odrębny widok Szkice; bootstrap składa
zależności. Import i migracja poza wątkiem GUI. Nowa instalacja pozostaje
pusta. Migracje 1–6 są zachowane bez edycji.

Odbiór: trwałość sekcji/kolejności/URL i pełnego opisu po restarcie;
ponowienie bez duplikatu; wiele prezentacji Produktu; brak nadpisania
katalogu; rollback całego zatwierdzonego zapisu przy awarii; konflikt wersji;
blokada usunięcia powiązanego Produktu; migracja 6→7 z kopią i odtworzeniem;
klawiatura, oba motywy, pusta lista. Bez rzeczywistej publikacji w testach.

Alternatywa: pozostawić wyłącznie nietrwały podgląd ZIP. Nie wymaga
modelu szkicu, ale nie pozwala kontynuować przygotowania oferty po
zamknięciu programu. Rekomendowany jest opisany wyżej trwały szkic.


## Decyzja właściciela i wykonanie — 2026-11-05

Właściciel zatwierdził relację jeden Produkt na szkic i wiele szkiców na
Produkt oraz utrwalanie ofert z paczek. Doprecyzował cel integracyjny:
wysyłka do Allegro jako **szkice**, bez uruchamiania sprzedaży. Publikacja
będzie osobną akcją. Konfiguracja, treści i układy mają być danymi
użytkownika, nie kodem; nowa instalacja nie zawiera ich przykładów.

W 0.12 wdrożono zapis z ZIP, osobną listę, bezpieczny podgląd, edycję
tytułu i pełnego opisu HTML, usunięcie z kopią, kontrolę wersji i migrację 7.
Sekcje i galeria pozostają zachowane; edycja opisu HTML nie przebudowuje
sekcji. Idempotencja wynika ze znormalizowanej treści (bez numeru wiersza
lub nazwy ZIP); zmiana nazwy archiwum nie duplikuje identycznej oferty.
Ponowienie po edycji nie nadpisuje zapisanej prezentacji.

Pierwszy przyrost dotyczy gotowych paczek; ręczny kreator szkicu
z Produktu pozostaje późniejszą pracą. Nie wdrożono kont, API ani wysyłki.
