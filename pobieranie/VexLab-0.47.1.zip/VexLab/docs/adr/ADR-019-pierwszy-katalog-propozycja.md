# ADR-019 — pierwszy scenariusz katalogu (propozycja)

Data: 2026-11-02. Status: rozpatrzona w zakresie pierwszego katalogu; wdrożenie w ADR-020.
Źródło: polecenie kontynuowania tworzenia programu; DOMAIN_MODEL, karta Produktu.
Nie jest to zatwierdzenie całego modelu ani polecenie utworzenia schematu bazy.

Scenariusz: użytkownik otwiera Produkty, dodaje lokalny szkic Produktu,
odnajduje go na liście i zmienia nazwę/opis bez zmiany tożsamości.
Sukces: po restarcie widzi własne dane; nowe środowisko pozostaje puste.
Nie ma publikacji, importu platform, cen, magazynu ani danych GPSR.

Proponowany zakres danych: wewnętrzne techniczne ID, nazwa robocza,
opcjonalny symbol SKU, opcjonalny opis katalogowy i wersja edycji.
Żadna relacja do Producenta, Dostawcy, GPSR, Oferty lub konta nie powstaje
automatycznie. Produkt należy do lokalnego Katalogu; integracje nie są
źródłem danych tego scenariusza. Katalog nie wymaga połączenia z Internetem.

Proponowane niezmienniki: nazwa po usunięciu skrajnych odstępów nie jest
pusta; zmiana danych zachowuje ID; opis może być pusty; zapis sprawdza
odczytaną wersję i zgłasza konflikt zamiast nadpisywać nowszą edycję.
Format ID i długości pól będą odwracalnymi szczegółami technicznymi
udokumentowanymi przed wdrożeniem, bez reguł platformowych.

Decyzja modelowa wymagająca odpowiedzi: znaczenie i unikalność SKU.

| Wariant | Konsekwencje |
|---|---|
| Opcjonalne, unikalne gdy podane (rekomendacja) | Można tworzyć szkice bez symbolu; jednoznaczne ręczne wyszukiwanie po SKU; trzeba obsłużyć konflikt symbolu |
| Opcjonalne, duplikaty dozwolone | Mniej ograniczeń importu; wyszukiwanie może zwracać wiele Produktów z tym samym symbolem; późniejsze mapowanie wymaga innych kluczy |
| Obowiązkowe i unikalne | Ułatwia identyfikację, ale blokuje szkic bez symbolu; narzuca mocniejszą regułę na katalog |

Nie zakładamy globalnej unikalności EAN ani tego, że SKU jest ID Produktu.
Przykłady syntetyczne do testów: „Produkt testowy A”, symbol „TEST-A”; drugi
szkic bez symbolu; edycja dwóch otwartych formularzy tej samej wersji.
Dane występują wyłącznie w fixture'ach, nigdy w starcie aplikacji.

Kryteria odbioru po decyzji: dodanie, edycja, wyszukiwanie, trwałość po
restarcie, jawny błąd konfliktu wersji i symbolu według wybranego wariantu,
brak częściowego zapisu po awarii. Domena bez Qt/SQL; porty w przypadkach
użycia; SQLite w adapterach; GUI obsługuje DTO i komunikaty.
Migracje i kopia/odtworzenie wymagają osobnego opisu przed pierwszą bazą.

Niezależna praca przed decyzją: powłoka GUI, nawigacja, motywy i skróty.
Nie utrwalamy nieuzgodnionego SKU lub relacji w schemacie ani API.

## Decyzje właściciela i wdrożenie

W bieżącej rozmowie właściciel wybrał wariant **obowiązkowe i unikalne**,
a następnie potwierdził, że wielkość liter nie odróżnia SKU. Wariant
rekomendowany pierwotnie jako opcjonalny nie został przyjęty.
Propozycję ograniczonego scenariusza wdrożono w
[ADR-020](ADR-020-lokalny-katalog-i-sqlite.md). Nie jest to akceptacja całej domeny.
