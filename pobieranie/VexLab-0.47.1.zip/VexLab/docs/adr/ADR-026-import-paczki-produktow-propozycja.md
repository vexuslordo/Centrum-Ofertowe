# ADR-026 — import paczki Produktów z pliku producenta

Data: 2026-11-02. Status: wymaganie importu i wyboru producenta pochodzi
od właściciela; poniższy zakres pierwszego przyrostu jest propozycją.
Wdrożenie minimalnego importu w 0.5 opisuje ADR-027; pozostałe propozycje
i model dopasowań zachowują status otwarty.

## Scenariusz i wejście w interfejsie

Obok „Dodaj produkt” na stronie Produkty dostępna ma być akcja
„Importuj produkty z pliku”. Formularz ręcznego dodawania ze wskazanego
zrzutu otrzyma przejście do tego samego procesu. Istniejący skrót
„Import z cennika” powinien prowadzić do tego procesu dopiero po jego
wdrożeniu; nie może wcześniej udawać działającej funkcji.

Przepływ: wybór pliku → wybór arkusza, jeśli dotyczy → wskazanie kolumn
→ wybór producenta dla paczki → walidacja i podgląd → zatwierdzenie zapisu
→ rzeczywisty raport wyniku. Nazwa i SKU wymagane, opis opcjonalny.
Wybór dotyczy istniejącego aktywnego Producenta; nie tworzymy producentów
automatycznie z nazw znalezionych w pliku. Obecna opcjonalność relacji
Produkt–Producent nie zostaje zmieniona.

Właściciel dostarczył przykładowy XLSX Evotech, podkreślając, że inne cenniki
mogą wyglądać inaczej. [Analiza pliku](../ANALIZA_IMPORTU_EVOTECH.md)
potwierdza potrzebę wyboru arkusza, wiersza nagłówków i mapowania kolumn
zamiast sztywnego szablonu Evotech. W przykładzie `Title` to nazwa,
`KOD` jest kandydatem na SKU, a `MARKA` nie oznacza Producenta.
Są też powtarzające się kody z różnymi nazwami i jeden brak kodu;
właściciel zaakceptował ich jawne wykluczanie w podglądzie przed zapisem.
Pozostałe formaty, kodowania i układy wymagają osobnego sprawdzenia.
Nie deklarujemy obsługi dowolnych PDF/XLS/XLSX/CSV.
Symbole należy odczytywać jako tekst i zachowywać zera wiodące; jeżeli
źródło już je utraciło, nie wolno ich odgadywać. Formuły i makra nie są
wykonywane.

## Zakres modelu i rekomendacja

Pierwszy przyrost rekomendowany: import istniejących pól Produktu
(nazwa, SKU, opis) i opcjonalnego przypisania Producenta. Bez nowych bytów,
kolumn cen, VAT, walut, marż, magazynu, EAN ani publikacji. Ceny z pliku
nie mogą być po cichu uznane za zaimportowane: podgląd musi wskazać,
które kolumny pominięto. Pełny import Cennika wymaga osobnego ustalenia
właściciela cen i ich znaczenia zgodnie z DOMAIN_MODEL, sekcja 9.

SKU zachowuje zatwierdzoną globalną unikalność ignorującą wielkość liter.
Kod producenta w pliku nie staje się automatycznie wewnętrznym SKU;
użytkownik jawnie wybiera kolumnę. Kolizji kodów różnych producentów
nie rozwiązujemy przez zmianę dotychczasowego niezmiennika.

Decyzja właściciela z 2026-11-02: konflikty pokazywać w podglądzie
z numerami wierszy i umożliwić ich jawne wykluczenie przed importem.
Nie scalać automatycznie, nie generować SKU i nie nadpisywać istniejących
Produktów. Nierozstrzygnięte błędy wybranych wierszy blokują zapis;
wykluczone pozycje muszą być widoczne w podsumowaniu. Walidacja po zmianie
wyboru jest ponawiana, by wybrana paczka spełniała obowiązkowe i unikalne SKU.
Wszystkie zaakceptowane nowe rekordy zapisywane w jednej transakcji;
konflikt wykryty dopiero przy zapisie również wycofuje wybraną paczkę.
Nie jest to zgoda na ciche pomijanie rekordów ani automatyczne aktualizacje.

### Pozycje „Do poprawy” — wymaganie właściciela

Właściciel doprecyzował 2026-11-02: wykluczone wiersze mają trafiać na osobną
listę „Do poprawy”, aby można było do nich wrócić, poprawić dane i przypisać.
To stan przygotowania importu, nie kategoria asortymentowa, nowy główny byt
ani gotowe Produkty z pominięciem walidacji SKU. Pozycje pozostają dostępne
także po zamknięciu programu; nie wymagają ponownego wczytania całego cennika.

Przechowywać dla odłożonego wiersza dane potrzebne do korekty, wskazany
Producent, identyfikację paczki i numer wiersza oraz powód wykluczenia.
Nie wymaga to archiwizacji całego XLSX. Dokładny schemat techniczny i migracja
z kopią zostaną przygotowane przy implementacji; ten wpis nie zmienia bazy.
Wymaganie braku przechowywania dokumentów z ADR-025 dotyczy innego modułu.

Użytkownik otwiera pozycję, poprawia nazwę/SKU lub wybór Producenta,
a następnie ponawia walidację i świadomie zatwierdza dodanie do katalogu.
Przy konflikcie może wskazać istniejący Produkt jako powiązanie wiersza
źródłowego, bez nadpisywania danych Produktu i bez tworzenia duplikatu.
Nie przypisywać automatycznie po samej nazwie. Lista nie wymaga wskazania
motocykla; model dopasowań do pojazdów pozostaje osobnym zagadnieniem.

Po zatwierdzeniu pozycja przestaje być oczekująca. Zapis Produktu/powiązania
i zmiana stanu pozycji muszą być atomowe, aby ponowienie po awarii nie
tworzyło duplikatu. Przed zatwierdzeniem sprawdzić aktualne SKU i aktywność
Producenta. Raport oddziela dodane Produkty, przypisane istniejące Produkty
i pozycje nadal „Do poprawy”. Samo odłożenie wiersza nie jest udanym importem.

Odbiór obejmie ponowny start z zachowaniem odłożonych danych, czytelne powody
błędów, korektę i dodanie, jawne powiązanie z istniejącym Produktem bez
nadpisania oraz awarię/ponowienie bez utraty pozycji i bez duplikatów.

Przykład syntetyczny, wyłącznie do testów: nazwa „Produkt testowy A”,
SKU „001-TEST”, opis „Przykład”; drugi wiersz „001-test” jest konfliktem,
a nie drugim Produktem. Wybór Producenta przypisuje tę samą referencję
do zaakceptowanych nowych rekordów.

## Architektura, dane i odbiór

Parser pliku w adapterze za portem odczytu, walidacja i plan importu
w przypadkach użycia z użyciem zatwierdzonych reguł domeny. Zapis paczki
przez port transakcyjny, implementacja SQLite; składanie w bootstrap.
GUI obsługuje DTO i stan procesu, bez SQL i parsowania w wątku GUI.
Nie przechowujemy kopii źródłowego cennika ani nowych metadanych biznesowych
bez ustalenia zakresu. Nie ma skutków w Allegro/PrestaShop.

Odbiór: mapowanie kolumn i wybór producenta, tekstowe SKU, polskie znaki,
puste pola, duplikaty w pliku i bazie, anulowanie bez zapisu, awaria bez
częściowych danych, dezaktywacja producenta między podglądem a zapisem,
konflikt równoległego zapisu i poprawny raport rzeczywiście zapisanych pozycji.
Potwierdzić na przykładowym pliku właściciela; testy na bazach tymczasowych.

Pierwotnie zapisano propozycję bez zmian kodu. Realizacja zatwierdzonego
minimalnego zakresu: [ADR-027](ADR-027-import-xlsx-i-bufor-korekt.md).

## Zakres asortymentu — wymaganie właściciela

Właściciel potwierdził 2026-11-02, że katalog obejmuje produkty dopasowane
do motocykli, produkty uniwersalne oraz produkty niezwiązane z motocyklami.
Produkt nie wymaga marki, modelu ani rocznika motocykla. Nie uzależniać
dodawania, importu i publikacji całego asortymentu od dopasowania do pojazdu.

W tym źródle nagłówek `MARKA` prezentować w mapowaniu jako „Marka motocykla”,
nie jako Producent produktu. „Motocykl” może być nazwą szerszej sekcji
dopasowań w przyszłości; sama marka nie opisuje konkretnego modelu/rocznika.
Nie zmieniamy oryginalnego XLSX. Nie dopisujemy obecnie pola dopasowania
do bazy ani opisu produktu automatycznie. Podgląd ma wskazać pominięcie
tej kolumny w pierwszym zakresie. Model wielu dopasowań pozostaje osobnym
zagadnieniem; brak dopasowania nie ustanawia samoczynnie etykiety „uniwersalny”.

## Przenośność dopasowań

Właściciel wymaga możliwości przekazania lokalnego wyboru motocykla do
PrestaShop i Allegro. Przy projektowaniu importu dopasowań zachować ich
znaczenie jako wspólnych danych, nie wyłącznie tekstu lokalnego filtra.
Nie przypisywać Producenta części z kolumny marki motocykla. Wcześniejszy
minimalny zakres importu nie wdraża jeszcze dopasowań; wymóg pozostaje
obowiązującym kolejnym zakresem, opisanym w ADR-023.
