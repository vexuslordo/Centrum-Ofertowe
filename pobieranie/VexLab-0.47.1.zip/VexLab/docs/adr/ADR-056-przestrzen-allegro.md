# ADR-056 — układ przestrzeni pracy Allegro

Status: wykonanie referencji wizualnej właściciela 2026-11-09, zakres odczytu.

Nagłówek konta, pięć podsumowań, zakładki stanów, filtry, akcje, tabela
z miniaturą oraz prawy panel szczegółów odtwarzają układ nowej referencji.
To nie ustanawia danych przykładowych ani nowych reguł modelu Oferty.
Dostępny pozostaje odczyt szkiców INACTIVE i ich podgląd z ADR-055.
Pozostałe stany, metryki sprzedaży i polecenia zapisu są widoczne jako przyszłe
funkcje, zablokowane; brakujących liczb nie zastępujemy zerem ani danymi demo.

Techniczny SzkicAllegro ma opcjonalne pola SKU/cena/waluta/dostępność/primaryImage
z już pobieranego GET /sale/offers. Nie ma migracji i dodatkowych żądań na
każdy wiersz. Zdjęcia widocznych wierszy używają istniejącego ograniczonego
portu obrazów. Szczegóły zaznaczonego szkicu pobierane w tle po 180 ms;
jedno żądanie panelu naraz, odrzucenie wyniku innej sesji lub starszego wyboru.
Zmiana wiersza czyści poprzednie szczegóły. API nadal odczytuje tylko INACTIVE.

Filtr tekstu obejmuje bieżącą stronę 50 szkiców i jest tak opisany. Kategoria
i producent wymagają przyszłego mapowania; nie zgadujemy ich z tytułów.
Nowa oferta i Importuj prowadzą do istniejącego lokalnego procesu ZIP.
Publikuj, Edytuj, Usuń, Zakończ i zmiany cen/stanów nie wywołują API.
To nadal oddzielne, przyszłe przypadki użycia. Schemat 11 bez zmian.
