# ADR-021 — powłoka i pierwszy działający ekran VexLab

Data: 2026-11-02. Status: wdrożone odwracalne decyzje techniczne przyrostu 0.2.
Autor: Codex w ramach bieżącego polecenia tworzenia programu.

Powłoka używa natywnych PySide6 Widgets, wspólnych tokenów QSS i własnych
wektorowych ikon. Nie dodano QFluentWidgets, QtCharts, fontów ani logotypów
platform o nieuzgodnionych prawach. To implementacja początkowa, nie pełny
odbiór UI-REF-01. Oryginalny obraz nadal określa docelowy układ i opcje.

Działa nawigacja w kolejności referencji, zwijanie menu z dostępnymi nazwami,
ciemny/jasny/systemowy motyw i techniczny zapis preferencji przez port.
Tryb systemowy obserwuje `QStyleHints.colorSchemeChanged`; działanie konkretnego
systemu Windows pozostaje do weryfikacji. Przejście do modułu niewdrożonego
pokazuje jawną informację; przyciski publikacji/importu/AI są nieaktywne.

Ctrl+K skupia globalne wyszukiwanie **lokalnych Produktów po nazwie/SKU**.
Nie sugerujemy wyszukiwania Ofert/EAN, bo te funkcje jeszcze nie istnieją.
KPI Produktów pochodzi z rzeczywistego odczytu. Pozostałe KPI pokazują „—”
i „W przygotowaniu”; brak danych nie udaje wyniku zerowego. Ceny, ilości,
producenci, media i stany platform w tabeli pozostają bez odczytu.

Nagłówek: marka VexLab, rzeczywista wersja pakietu, nazwa użytkownika systemu
przekazana z adaptera do powłoki. Jest to odwracalny wybór źródła nazwy,
nie konto sprzedażowe, mechanizm logowania ani nowa encja domenowa.
Nie wpisujemy VexLabs/vexlabs ze screena jako użytkownika instalacji.

Po uruchomieniu bez flagi diagnostycznej otwiera się GUI. `--diagnostyka`
pozostaje bezokienkowym odczytem wersji. Windows ma także wejście
`vexlab-gui` typu gui-script. Nie przygotowano instalatora Windows.

Układ szeroki ma 4 KPI i 5 akcji w jednym rzędzie. Przy mniejszej szerokości
KPI przechodzą w 2 kolumny, akcje się zawijają, panele układają się pionowo.
Brak pełnego odbioru wysokiego kontrastu, Narratora, wielu monitorów i DPI.
Zrzuty Linux/offscreen nie stanowią takiego odbioru.
