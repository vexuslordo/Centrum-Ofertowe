# ADR-033 — dopasowania Produktu do motocykli

Data: 2026-11-03. Status: ZAAKCEPTOWANE przez właściciela w rozmowie
odpowiedzią „tak” na przedstawiony model: zero–wiele dopasowań, marka/model,
opcjonalne roczniki i wariant. Kontynuuje wymaganie z ADR-023.
Wdrożenie w 0.8: formularz, podgląd, strukturalne DTO i migracja 4→5.

## Scenariusz i granice

W formularzu Produktu użytkownik otwiera listę „Pasuje do motocykli”,
dodaje lub poprawia dopasowania i zatwierdza zmianę. Jeden Produkt może
mieć zero, jedno lub wiele dopasowań. Produkt pozostaje tym samym obiektem,
z tym samym SKU. Producent części jest niezależny od marki motocykla.
Pola są danymi użytkownika; aplikacja nie zawiera gotowych marek i modeli.

Brak dopasowań jest dozwolony dla wszystkich Produktów, w tym uniwersalnych
i niezwiązanych z motocyklami. Pusta lista oznacza brak zapisanych dopasowań;
nie potwierdza uniwersalności ani pasowania do wszystkich pojazdów.
Nie dodajemy teraz obowiązkowej klasyfikacji asortymentu.

## Przyjęte pola jednego dopasowania

| Pole | Zasada |
|---|---|
| Marka motocykla | Wymagana w dodanym dopasowaniu, np. Marka A |
| Model | Wymagany, np. Model X |
| Rocznik od | Opcjonalny; liczba całkowita od 1000 do 9999 |
| Rocznik do | Opcjonalny; wymaga „od”, nie mniejszy niż „od” |
| Wariant / uwagi o dopasowaniu | Opcjonalny tekst, np. tylko wersja S |

Oba roczniki puste: brak potwierdzonych danych o rocznikach, a nie „wszystkie”.
Ten sam rok w obu polach: jeden rocznik. Tylko „od”: koniec niepodany;
nie oznacza gwarancji dla wszystkich przyszłych roczników. Informacja ta
musi pozostać widoczna również w podglądzie wysyłki do kanałów.
Nie zgadujemy przedziałów z tytułu Produktu ani z daty bieżącej.

Wiersz całkowicie pusty nie tworzy dopasowania. Wiersz częściowo uzupełniony
bez marki lub modelu daje błąd, nie ciche pominięcie. Dokładny duplikat
(marka/model/wariant po trim i casefold oraz te same roczniki) jest odrzucany.
Zachowujemy wpisaną pisownię. Nie scalamy różnych wariantów lub nakładających
się zakresów, bo nie muszą znaczyć tego samego.

## Przykłady syntetyczne

| Produkt / SKU | Zapis |
|---|---|
| Część testowa / TEST-1 | Marka A, Model X, 2018–2020; Marka A, Model Y, 2021–2023, wersja S |
| Część testowa / TEST-2 | Marka B, Model Z, bez roczników — wymagają weryfikacji |
| Akcesorium uniwersalne / TEST-3 | Pusta lista, zapis Produktu dozwolony |
| Artykuł niezwiązany z motocyklami / TEST-4 | Pusta lista, zapis Produktu dozwolony |
| Niezweryfikowany produkt / TEST-5 | Pusta lista; nie oznaczamy go automatycznie jako uniwersalnego |

Przykłady są wyłącznie dokumentacją; żadnych seedów w nowej instalacji.

## Własność, transakcja i architektura

Dopasowania to wartości należące do Produktu w kontekście Katalogu,
bez nowej siedemnastej głównej encji lub globalnego rejestru motocykli.
Właścicielem danych jest użytkownik zatwierdzający edycję lokalnego Produktu.
Zmiana listy i danych Produktu powinna być atomowa, chroniona jego wersją.
Błąd lub konflikt nie może zapisać połowy listy ani nadpisać starszego odczytu.
Usunięcie dopasowania nie usuwa Produktu ani nie zmienia już opublikowanych ofert.

Wdrożenie: typ wartości i walidacja w domenie, komenda/DTO oraz port
repozytorium w przypadkach użycia, SQLite w adapterze, edytor w GUI,
kompozycja w bootstrap. GUI nie wykonuje SQL i nie parsuje nazw jako danych
potwierdzonych. Odczyt i zapis poza wątkiem GUI.

Migracja 4→5: podrzędna tabela dopasowań powiązana z ID Produktu,
bez zmiany opublikowanych migracji 1–4. Spójna kopia przed migracją; istniejące
Produkty otrzymują pustą listę, bez utraty nazw/opisów/mediów/cen.
Przywracanie na kopii i kompatybilność muszą mieć testy przed wydaniem.
Migracja jest wykonywana przy otwarciu starszej bazy w 0.8, z kopią.

## Przekazywanie do PrestaShop i Allegro

Wspólne DTO udostępnia pełną listę, oddzielnie od nazwy i opisu.
Przyszłe adaptery kanałów mapują dane zgodnie z rzeczywistym API, kategorią
i konfiguracją wybranego sklepu/konta. Kategoria PrestaShop jest odrębnym
przypisaniem, nie globalnym identyfikatorem motocykla. Bez nazw lub ID
platform w danych dopasowania Produktu.

Podgląd przyszłej publikacji ma wskazywać, co jest obsługiwane i co wymaga
decyzji. Brak wsparcia nie powoduje cichego pominięcia lub automatycznego
przepisania do opisu. Nie potwierdzono jeszcze mapowań API obu kanałów;
lokalny model nie stanowi dowodu gotowej integracji.

## Alternatywy

- Jeden motocykl na Produkt: prostszy formularz, ale utrata wielu dopasowań.
- Tylko tekst w opisie: już dostępny, lecz nie zapewnia struktury do mapowań.
- Globalny słownik pojazdów: wymaga źródła danych i osobnych decyzji;
  nie jest potrzebny do ręcznego zapisu pierwszego scenariusza.

Rekomendacja: lista zero–wiele, według pól powyżej, zatwierdzana przez użytkownika.

## Scenariusze odbioru

Dodać Produkt bez dopasowań; zapisać dwa motocykle przy jednym SKU;
sprawdzić restart, edycję/usunięcie wiersza, walidację częściowego wiersza,
roczników i duplikatu, konflikt wersji i rollback, migrację z zachowaniem
całego dotychczasowego katalogu i przywrócenie kopii. Zweryfikować klawiaturę,
pustą listę i oba motywy. Sprawdzić pełne strukturalne DTO bez zależności
od platform. Publikacja oraz import automatycznych dopasowań poza tym przyrostem.

Szczegóły wdrożenia i wyniki kontroli: [przyrost 0.8](../PRZYROST_0_8.md).
