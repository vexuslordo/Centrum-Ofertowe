# ADR-045 — opcjonalny EAN z cennika

2026-11-06. Właściciel polecił dodanie EAN do mapowania cennika. EAN jest
opcjonalnym identyfikatorem Produktu, nie nową encją i nie zastępuje SKU.
Bez EAN import jest poprawny. Kody są tekstem, zachowują zera wiodące;
obsługa EAN-8 i EAN-13 z kontrolą cyfry kontrolnej. Bez generowania,
dopełniania zerami, skracania ani zgadywania z nazwy. Nie wymagamy unikalności
EAN. Nie zmieniamy powiązań po SKU ani istniejących Produktów przy imporcie.

Jawne mapowanie odrębnej kolumny. Tekst i dokładna liczba całkowita zapisana
w XLSX mogą być ocenione jako EAN; nie odtwarzamy formatowania liczbowego.
Formuły, notacja naukowa, ułamki i błędne kody wymagają korekty. Surowy EAN
pozostaje w zapisanym cenniku i Do poprawy. Formularz korekty pozwala go
zmienić lub usunąć; finalne dodanie ponownie waliduje kod. Starsze dokumenty
bez pola EAN pozostają czytelne. Mapowanie, wartości i producenci wyłącznie
użytkownika. Automatyczne profile importu są osobną propozycją, niewdrożoną.

Schemat 10: opcjonalny tekstowy EAN Produktu oraz surowy EAN import_robocze.
Kopia 9→10, stare definicje migracji 1–9 niezmienione. Dotychczasowe Produkty
bez EAN, brak seedów. Edycja i masowa zmiana innych pól zachowują EAN;
puste pole w formularzu świadomie czyści kod. Podgląd i eksport zachowują
tekst. Bez integracji/zapisów w Subiekcie i kanałach sprzedaży. Przyszły
katalog tylko do odczytu i rozdzielenie ZIP pozostają odrębnym etapem.
