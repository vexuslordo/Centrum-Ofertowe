# ADR-065 — wyszukiwanie całego konta i lista wszystkich ofert

Polecenie właściciela 2026-11-13: wyszukiwanie nie może ograniczać się do
bieżących 50 rekordów. Dodać też możliwość wyświetlenia wszystkich ofert.

Swagger /sale/offers potwierdza name (tekst tytułu), external.id (dokładne
SKU) i offer.id, limit do 1000 oraz offset+limit do 10 000 000. Stary limit
VexLab 10 000 był własnym ograniczeniem, usuwamy go. Domyślne strony 50
pozostają dostępne obok 100/500/1000 i Wszystkie. Enter/Szukaj wykonują GET
z kryterium na serwerze, razem ze statusem i kontekstem konta.

Wszystkie pobiera partie po 1000 w tle, z postępem, anulowaniem i kontrolą
sesji. Nie prezentuje niepełnego wyniku jako całości. Zmienna liczba rekordów,
powtórzone identyfikatory lub pusta przedwczesna strona wymagają odświeżenia.
API nie zapewnia atomowego obrazu konta; taka kontrola nie wykrywa wszystkich
możliwych równoczesnych zmian. W pamięci maksymalnie 100 000 ofert; większy
wynik wymaga zawężenia lub przeglądania stron i wywołuje jawny komunikat.
Nie udajemy kompletnej listy przez ciche obcięcie.

Miniatury tylko widoczne, bez zmiany ich rozmiaru. Budowa tabeli z blokadą
sygnałów i odmalowania, aby uniknąć kwadratowego przeliczania zaznaczeń.
Wyniki wyszukiwania nie zastępują KPI całego konta. Odczyty nie rozszerzają
OAuth i nie uruchamiają zapisów ani publikacji. Bez zmian modelu i SQLite.
