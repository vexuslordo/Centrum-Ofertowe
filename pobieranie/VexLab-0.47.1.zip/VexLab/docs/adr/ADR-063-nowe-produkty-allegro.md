# ADR-063 — jawne zgłoszenie nowego produktu i szkic oferty

2026-11-13: właściciel wyjaśnił, że produkty z paczki nie istnieją w Katalogu
Allegro. Rozszerza to ograniczenie ADR-061 do istniejących UUID. Zachowujemy
odrębną, domyślną ścieżkę wyboru istniejącego produktu; nie podstawiamy innej
kartoteki dla obejścia braku dopasowania.

Potwierdzony kontrakt Swagger ProductOffer: name/category oraz
ProductOfferBase.parameters/images mogą stanowić pełną definicję produktu
w POST /sale/product-offers. Nie używamy osobnego POST product-proposals,
więc nie pojawia się druga, niezależna próba mutacji wymagająca ponowienia.
Definicja jest wysyłana tylko po jawnym wyborze trybu „Nowy produkt”.
publication.status pozostaje INACTIVE, republish=false. Skutek katalogowy
jest niezależny od nieaktywnej sprzedaży: potwierdzenie musi to wyjaśniać.

Kategoria wybierana przez użytkownika z API matching-categories; wymagania
pobierane z rzeczywistej kategorii liściowej. Parametry produktowe i ofertowe
mają odrębne role. Wartości wspólne oraz źródła SKU/EAN wybiera użytkownik,
bez zaszytego producenta, identyfikatorów parametrów i domyślnych marek.
Jawne zastosowanie kategorii/parametrów do serii; ceny pozostają per pozycja.

Ten sam trwały rejestr rezerwuje konto/środowisko/SKU przed jedynym POST.
Nieznany wynik, utrata metadanych i 202 nadal nie pozwalają ponowić POST.
Po zakończeniu wymagany GET oferty i GET przydzielonego produktu, weryfikacja
kategorii/nazwy/parametrów i INACTIVE. NOT_LISTED, brak UUID lub niezgodność
nie są sukcesem. Nie obiecujemy, że Allegro zaakceptuje nową kartotekę:
może dopasować istniejącą, zgłosić konflikt albo odrzucić dane.

Transport ma dwie rozłączne formy produktu: tylko istniejący UUID lub
ściśle określona definicja nowego produktu. Nie dopuszcza ACTIVE, harmonogramu,
publikacji ani dowolnych dodatkowych pól. Bez zmian lokalnego modelu Produktu,
schematu SQLite i Subiekta. Zachowana kompatybilność odcisków starych prób.
Testy na kontrolowanych odpowiedziach; bez mutacji rzeczywistego konta.
