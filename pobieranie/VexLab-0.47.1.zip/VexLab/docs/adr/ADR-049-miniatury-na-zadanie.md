# ADR-049 — miniatury katalogu na żądanie

2026-11-07. Decyzja techniczna w ramach polecenia właściciela kontynuowania
roadmapy po potwierdzeniu 0.20.4. Zakres: odciążenie odczytu obrazów i cache
w pamięci, wcześniej zapisane w kierunku integracji z Subiektem GT.

## Scenariusz i granice

Użytkownik przegląda duży katalog i przewija listę. Sam start, odświeżenie
lub zaznaczenie wszystkich wyników nie pobiera wszystkich BLOB miniatur.
Źródłem zdjęć pozostaje lokalna galeria; nie dodajemy sieciowego źródła
ani nowego bytu domenowego. Dotychczasowe dane, historia i kopie zachowane.

Nowe `ma_zdjecia` jest wyłącznie metadaną DTO odczytu, nie polem Produktu
w domenie lub SQLite. Seria pobierania zdjęć używa tej metadanej, aby nadal
pomijać istniejące galerie bez dodatkowych wywołań sieciowych.

## Decyzja

GUI wywołuje odczyt katalogu bez BLOB. Osobny port pobiera maksymalnie 32
miniatury ze wskazanymi ID i oczekiwanymi wersjami. SQLite łączy zdjęcie
z aktualną wersją Produktu; brak/inna wersja oznacza brak wyniku, nigdy
przypisanie według numeru wiersza. Dane pozostałych zdjęć nie są odczytywane.
Odpowiedź pojedynczej miniatury ograniczona w SQL do 512 KiB.

Komponent GUI śledzi widoczne wiersze, przewijanie i sortowanie. `data()`
modelu tabeli nie wykonuje I/O ani nie planuje odczytu wszystkich komórek
podczas pomiaru szerokości Qt. Jedna partia działa w tle, następna wynika
z aktualnego viewportu. Kluczem cache jest ID/wersja, nie indeks wiersza.
Odświeżenie zmienia generację i odrzuca spóźnione wyniki starego katalogu.

Cache LRU: maksymalnie 128 wpisów i 8 MiB szacowanego kosztu miniatur,
obrazy zeskalowane do 128×128. Obejmuje także brak/błąd, żeby nie ponawiać
żądania przy każdym malowaniu. Odświeżenie czyści cache i umożliwia ponowienie.
To limity techniczne pamięci tego komponentu, nie limit całego procesu Qt.
Nie powstają pliki cache na dysku. Szczegóły produktu ładują tekst natychmiast,
a miniaturę osobnym odczytem w tle; zamknięty dialog ignoruje wynik.

Pełny odczyt `KatalogProduktow.odczytaj()` pozostaje kompatybilny dla starszych
klientów. Powłoka GUI jawnie wybiera `z_miniaturami=False`. Operacje masowe,
wybór wszystkich wyników, eksport i kontrola wersji zachowują dotychczasowy
zakres. Nie wprowadzamy w tym przyroście stronicowania samych rekordów.

## Konsekwencje i odbiór

Bez migracji schematu 11 i nowych zależności. GUI nie importuje SQLite ani
adaptera. Porty i metadane są w przypadkach użycia; składanie nadal w bootstrapie.
Wymagane testy: BLOB tylko wskazanych wersji, 1000 wierszy z miniaturami,
selekcja wszystkich, sortowanie w trakcie odczytu, zmiana generacji, błąd
bez pętli ponowień, limit pamięci, rzeczywisty wątek i odświeżenie galerii.

Nadal osobno: stronicowanie tekstowych rekordów, retencja kopii i konektor GT.
Ta decyzja nie zmniejsza istniejącej bazy ani nie usuwa zdjęć użytkownika.
