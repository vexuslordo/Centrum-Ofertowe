# ADR-068 — prostsze okno przygotowania ofert Allegro

Polecenie właściciela: uprościć okno nowych szkiców i dopasować jego wygląd
do schematu całej aplikacji. Zmiana jednego ekranu do oceny, bez przenoszenia
stylu na pozostałe moduły przed oceną użytkownika.

Wykorzystujemy istniejące tokeny design_system: karta, opis, tytuły Allegro,
tabela, primary. Bez nowej palety, gradientów, bibliotek i zmian logo.
Dwie sekcje: Dane produktów (waluta/ilość, wybór istniejącego lub nowego
produktu) oraz Ustawienia Allegro (GPSR/dostawa/warunki, VAT i kompletność).
Edycja masowa, parametry i zaznaczenie znajdują się bezpośrednio nad tabelą.
Walidacja i tworzenie szkiców na dole, jedna akcja główna. Raporty,
sprawdzanie wyników, edycja pojedynczej pozycji, odznaczanie i naprawa
sygnatur w menu Więcej działań. Przycisk przerwania pojawia się podczas pracy.

Wszystkie dotychczasowe operacje, potwierdzenia i zabezpieczenia zachowane.
Dostępność pozycji menu odzwierciedla dostępność oryginalnych przycisków,
także po zmianie sesji (eksport raportu nadal dostępny). Menu wywołuje te
same kontrolery; brak zmian w API, domenie, schemacie i danych użytkownika.
Indywidualne SKU/EAN/ceny oraz oddzielna publikacja sprzedaży pozostają.

Naprzemienne tło wierszy, pełne nazwy i SKU w podpowiedziach; skrót „Gotowa”
wyłącznie w prezentacji, bez zmiany stanów raportu. Skala 100/200%, oba motywy.
Poprawka parsera VAT z docs/POPRAWKA_0_44_1.md wchodzi w ten sam ZIP 0.45.
