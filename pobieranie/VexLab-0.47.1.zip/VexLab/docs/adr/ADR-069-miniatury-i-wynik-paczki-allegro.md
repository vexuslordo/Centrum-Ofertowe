# ADR-069 — miniatury, kolory Dashboardu i potwierdzenie wysyłki

Właściciel wymaga miniatur po lewej w oknie przygotowania szkiców, takiej
samej wielkości jak w zakładce Allegro; kolorów górnych paneli jak Dashboard;
informacji po przesłaniu ofert oraz znaku zamiast napisu „Gotowa”.

Wspólny ObrazyOferty(miniatury=True) zapewnia 64×64, zachowanie proporcji,
białe tło i odczyty asynchroniczne za istniejącym portem PodgladZdjec.
Źródłem jest pierwsze zdjęcie galerii, następnie pierwszy obraz opisu.
Tworzymy miniatury widocznych wierszy, wspólny cache i kolejkę obsługuje
istniejący komponent. Brak zdjęcia i błędy nie blokują edycji lub wysyłki.
Zamknięcie ignoruje spóźnione odpowiedzi. Nowa kolumna jest wizualnie pierwsza;
logiczne indeksy pozostałych kolumn zachowane, aby nie zmienić edycji masowej.

Wspólna funkcja malowania tła z KafelekKPI: nie kopiujemy palety/gradientu.
Panel danych ma wariant produkty (niebieski), ustawień wariant aktywne
(zielony); czytelne podpisy i standardowe kontrolki w obu motywach.
Logo i istniejące kafelki Dashboardu zachowane.

Gotowość prezentowana wyśrodkowanym zielonym znakiem aktywne, opis w tooltip
oraz AccessibleTextRole i accessibleName. Stan DTO i raport pozostaje pełnym
tekstem. Wyniki po wysyłce nadal są tekstowe i zawierają ID Allegro.

Podsumowanie ostatniej wysyłki/odczytu dotyczy bieżącego zakresu: potwierdzone
Utworzono szkic / Szkic kompletny / Szkic do poprawy wymagają ID. Osobno
liczymy potwierdzone szkice do poprawy oraz pozycje bez potwierdzenia.
Timeout/unknown nie jest sukcesem. Bez nowych zapisów API, migracji bazy,
ponawiania POST lub publikacji sprzedaży. Dane i pliki użytkownika zachowane.
