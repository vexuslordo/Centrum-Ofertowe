# ADR-028 — pobieranie katalogów przez API dostawców i producentów

Data: 2026-11-02. Status: wymaganie właściciela; konektory niewdrożone.
Źródło: polecenie dodania możliwości połączenia API z magazynami dostawców
i producentów, aby pobierać ich bazy produktów.

## Zakres wymagania

VexLab ma pobierać katalog produktów bezpośrednio z API wskazanych partnerów,
jako kolejne źródło obok plików XLSX/CSV i przyszłych kanałów sprzedaży.
Dane zewnętrzne przechodzą mapowanie, walidację i podgląd przed zapisem
we wspólnym lokalnym katalogu; nie tworzymy konkurencyjnego modelu Produktu.
Producent i Dostawca pozostają odrębnymi rolami. Tożsamość podłączonego
dostawcy nie oznacza, że jest producentem wszystkich pobranych produktów.

Wymaganie dotyczy na razie pobierania bazy produktów. Dostępność, ilości,
ceny zakupu/sprzedaży, waluty, VAT i magazyny partnerów wymagają osobnego
uzgodnienia właściciela pól i zasad synchronizacji. Nie wpisywać ich
automatycznie jako ceny/stany lokalnego Produktu. Nie zakładać, że każde
API udostępnia wszystkie te informacje albo pozwala na publikację mediów.

## Następny konkretny przyrost

Najpierw wskazać jednego partnera, dokumentację API, zakres udostępnionych
danych, autoryzację, koszty/limity i środowisko testowe. Właściciel doprecyzował, że nie wybrał jeszcze partnera i chce tę możliwość
w przyszłości. Nie blokuje to bieżącego importu plików; nie żądać teraz
kluczy ani haseł. Wybór konkretnego partnera nastąpi przy realizacji.
Samo wymaganie nie jest dowodem dostępności określonego API. Nie tworzyć
pustej integracji, aktywnego przycisku „Połączono” ani fikcyjnego importu.

Docelowa architektura: adapter konkretnego partnera za portem źródła
katalogu → przypadek użycia przygotowania importu → walidacja/podgląd
i jawnie zatwierdzony zapis. Źródło API powinno współdzielić reguły importu
z plikami; nie podszywać się pod XLSX/CSV i nie wykonywać HTTP w GUI.
Zewnętrzne DTO i identyfikatory pozostają na granicy adaptera/mapowania.
Wymagane nowe porty i trwałe powiązania zaprojektować przy pierwszym partnerze,
bez rozszerzania listy 16 głównych bytów na podstawie samej nazwy integracji.

Przed realizacją ustalić mapowanie kodu partnera na obowiązkowe lokalne SKU,
identyfikację partnera/konta, producenta, niepełne pozycje oraz powtarzanie
importu. Nie zakładać globalnej unikalności kodów partnerów ani dopasowania
po samej nazwie. Aktualizacja istniejących produktów wymaga oddzielnego
podglądu różnic i uzgodnienia, których lokalnych danych wolno dotknąć.
Nie wdrażać automatycznego nadpisywania pod nazwą pobierania katalogu.

## Niezawodność i odbiór

Sprawdzić paginację, limity, timeout, brak sieci, wygaśnięcie autoryzacji,
niepełne strony, ponowienie i duplikaty. Raport ma rozróżniać pobrane,
dodane i odłożone Do poprawy; nie oznaczać częściowego odczytu jako pełnej
bazy partnera. Sieć i zapis w tle z widocznym stanem oraz bez sekretów
w logach. Sekrety przez port bezpiecznego magazynu; szczegóły implementacji
Windows do ustalenia przed rzeczywistym podłączeniem.

Testy mapowania i awarii na syntetycznych odpowiedziach, potem weryfikacja
z konkretnym API. Brak automatycznych zapisów/publikacji w systemie partnera.
Bieżący przyrost 0.5 dostarcza wyłącznie import plików, nie te konektory.
