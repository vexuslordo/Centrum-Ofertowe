# ADR-032 — lokalna galeria istniejącego Produktu

Data: 2026-11-03. Status: wdrożony przyrost techniczny w zakresie polecenia
właściciela „działamy dalej zgodnie z roadmapą”. Nie ustanawia nowych relacji
modelowych ani zgody na zewnętrzne API.

Scenariusz: użytkownik wskazuje jeden zapisany Produkt, dodaje lokalne zdjęcia,
porządkuje je i zatwierdza całą galerię. Zdjęcia należą do istniejącego zakresu
mediów Produktu z ADR-031. Kolejność i pierwsza miniatura korzystają z tabeli
zdjecia schematu 4. Bez migracji i nowych zależności.

Opcje ekranu: Dodaj z dysku → ograniczony odczyt/dekodowanie za portem plików;
podgląd → robocza lista zdjęć; góra/dół/usuń → zmiany robocze;
Zapisz → kontrola wersji, kopia SQLite, atomowa zamiana galerii;
Anuluj → odrzucenie zmian po potwierdzeniu. Menu Zdjęcia i media prowadzi
do wyboru Produktu w katalogu. Nie wykonuje zbiorczego pobierania.

Port repozytorium zwraca spójną migawkę wersji i zdjęć w transakcji odczytu.
Zapis sprawdza wersję Produktu pod BEGIN IMMEDIATE, wykonuje kopię i zwiększa
wersję. Nie zmienia nazw, SKU, opisu, producenta ani ceny. Błąd wycofuje całość.
Pusta galeria jest dozwolona; wyczyszczenie wymaga potwierdzenia.
Alternatywę zapisu każdej zmiany od razu odrzucono: utrudniałaby anulowanie.

Zachowano limit 5 zdjęć i ograniczenia kodeka z ADR-031: JPG/PNG/WebP,
wejście do 8 MiB i 16 mln pikseli, zapis JPEG do 1600 px i miniatura do 96 px.
Normalizacja usuwa metadane pliku; baza przechowuje nazwę źródłowego pliku,
bez pełnej ścieżki użytkownika. HTML/SVG odrzucane. Cały odczyt plików,
dekodowanie i SQL wykonują się poza wątkiem GUI; widoczny stan operacji.

Akceptacja techniczna: kolejność przeżywa odczyt, pierwsze zdjęcie trafia
do miniatury, usunięcie ostatniego usuwa miniaturę, kopia ma wcześniejszy stan,
konflikt i błąd nie nadpisują galerii. Anulowanie nie zapisuje zmian,
zamknięcie podczas pracy jest zablokowane. Testy używają tylko plików
syntetycznych i baz tymczasowych. Odbiór obu motywów/DPI na Windows otwarty.

Uzupełnienie 2026-11-03 (0.7.1), po zgłoszeniu właściciela: menu Zdjęcia
i media otwiera własny ekran z wyborem Produktu, miniaturami i galerią.
Zastępuje opisany wyżej alias do strony Produkty; model i zapis bez zmian.
