# ADR-038 — zapamiętywanie i rozpoznawanie układów paczek

Data: 2026-11-04. Status: wdrożone w 0.11 na podstawie zgody właściciela
na zapamiętywanie profili jako ustawień użytkownika i dalszego uproszczenia UI.
Nie zmienia modelu Produkt/Oferta ani schematu bazy 6.

## Scenariusz

Pierwsza paczka zawiera profil albo użytkownik jednorazowo wczytuje profil
z pliku/konfiguruje mapowanie. Po poprawnym odczycie program zapamiętuje
ustawienia w katalogu danych użytkownika. Następna paczka o tej samej
strukturze nie musi zawierać pliku profilu. Rozpoznanie działa po restarcie.

Profil należy do formatu, nie producenta. Kilku producentów może korzystać
z identycznego formatu; zmiana nazwy producenta nie tworzy nowej reguły.
Nie ma wbudowanych nazw plików, producentów, domen lub banerów. Zmiana
nazwy pliku danych wewnątrz ZIP nie wymusza ponownego mapowania.

## Dopasowanie

Zapamiętany rekord to istniejący profil odczytu wraz z zestawem pól pliku
i strukturą sekcji: klucze sekcji/elementów oraz występujące wartości typów.
Nie zapisuje treści ofert, SKU, cen, banerów lub adresów zdjęć. Nie przechowuje
ustawień publikacji lub sekretów kont. Nie jest nową encją biznesową.

Do automatycznego rozpoznania wymagany jest ten sam zestaw pól i taki sam
kształt sekcji. Liczba rekordów, kolejność/długość opisów i konkretne dane
nie są sygnaturą. Porównanie jest celowo ścisłe; dodanie nowego pola lub typu
może wymagać jednorazowego wyboru/profilu. Nie zgadujemy mapowania po nazwach.

Jeden pasujący układ → automatyczny podgląd; kilka pasujących układów lub
kilka identycznie zbudowanych zbiorów → krótka lista z nazwą układu i pliku.
Brak dopasowania → instrukcja jednorazowego wczytania profilu, bez pokazywania
formularza technicznego. Prawidłowy profil dołączony do ZIP ma pierwszeństwo;
błędny profil w ZIP blokuje automatyczny wybór zamiast cichego zastąpienia.

## Przechowywanie i błędy

Neutralne DTO/port pamięci w przypadkach użycia; adapter zapisuje pliki JSON
wersji 1 w profile_paczek obok katalog.sqlite3. Niezależnie od folderu
z rozpakowanym programem, bez migracji SQLite i nowych zależności.
Pusta instalacja nie zawiera zapamiętanych profili ani seedów.

Pliki mają identyfikatory SHA-256 od konfiguracji i sygnatury (bez nazwy
wyświetlanej i nazwy źródłowego pliku). Powtórne rozpoznanie tego samego
układu nie dubluje wpisów ani nie nadpisuje jego nazwy. Plik tymczasowy
w tym samym katalogu, flush/fsync i atomowe zastąpienie przy tworzeniu.
Limit 500 układów, 64 KiB na wpis; sprawdzanie struktury i identyfikatora,
bez wykonywania konfiguracji. Dowiązania do plików ustawień odrzucane.

Uszkodzone ustawienia nie są resetowane lub usuwane automatycznie.
Błąd odczytu pamięci ma jawny komunikat. Jeśli profil pochodzi z paczki/pliku,
a zapamiętanie się nie uda, podgląd nadal działa, z widoczną informacją,
że następnej paczki nie uda się rozpoznać na tej podstawie.

W edytorze zaawansowanym można usunąć aktualny zapamiętany układ po
potwierdzeniu; nie usuwa to Produktów lub ZIP-a. Ponowne jawne wczytanie
paczki z profilem może nauczyć program układu od nowa. Kopia SQLite nie
obejmuje tego osobnego folderu ustawień — profile można odtworzyć przez
ponowne wczytanie paczki/profilu lub kopię folderu profile_paczek.

## Użyteczność

Codzienna praca: Wybierz paczkę ZIP → automatyczny podgląd → Dodaj nowe
produkty do katalogu. Edytor mapowania jest osobnym oknem zaawansowanym,
a nie długą częścią głównej strony. Użytkownik nie musi rozumieć kluczy
items/type/content/url, aby wczytać znany układ. Profile są nadal jego danymi.

Testy: restart, brak profilu w kolejnej paczce, inna nazwa pliku i producenta,
zmiana struktury, dwa zgodne profile, brak nadpisania, uszkodzenie pliku,
awaria zapisu z zachowaniem podglądu i usunięcie układu. Rzeczywisty przykład
Evotech sprawdzany poza seedami i fixture'ami. Raport: ../PRZYROST_0_11.md.
