# ADR-064 — masowa edycja w przygotowaniu szkiców Allegro

Polecenie właściciela 2026-11-13: okno planu ZIP ma być miejscem masowej
edycji i przygotowania do wysyłki. Edycja dotyczy roboczych ofert i DTO
parametrów Allegro, bez zmian lokalnych Produktów, źródłowego ZIP-a i SQLite.

Wielokrotny wybór Ctrl/Shift, wybór widocznych i licznik zakresu. Oddzielnie
masowe tytuły/ceny/ilości oraz parametry pobrane z API i nowa kategoria.
Tylko jawnie wskazane pola zmieniają wartości; pozostałe parametry, źródła,
indywidualne ceny, SKU i EAN pozostają zachowane. Parametry wspólne wymagają
zgodnej kategorii i trybu produktu. Niezgodny zakres jest odrzucony w całości.

Edycja cen przez Decimal, bez zmiany waluty i z jawnym zaokrągleniem do 0.01.
Podgląd zmian przed zastosowaniem, żadnego POST w procesie edycji. Po zmianie
ponowna walidacja; błędy każdej pozycji widoczne w tabeli. Wysyłka obejmuje
zaznaczone gotowe pozycje lub gotowe pozycje całej paczki, jeśli brak wyboru;
zakres i liczba w potwierdzeniu. Stałe indeksy bez sortowania tabeli.

Trwały rejestr wyników i blokada ponawiania z 0.40/0.41 niezmienione. Edycja
nie zwalnia nieznanego wyniku ani nie publikuje sprzedaży. Bez nowej relacji
w modelu, migracji lub automatycznych zapisów na koncie w testach.
