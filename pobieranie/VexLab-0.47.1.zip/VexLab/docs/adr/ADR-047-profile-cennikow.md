# ADR-047 — zapamiętywanie układów cenników

2026-11-06. Decyzja wykonawcza w kontynuacji „działaj dalej” po 0.18,
realizująca wcześniejszy postulat uproszczenia różniących się cenników.
Zakres technicznych ustawień odczytu; bez nowego pojęcia domenowego,
publikacji, płatnego AI i zmiany schematu 10.

## Scenariusz i właściciel danych

Pierwszy plik → propozycja kolumn → sprawdzenie i korekta → podgląd →
Profil → Zapamiętaj układ. Kolejny plik → rozpoznanie struktury → podgląd →
osobny zapis cennika. Właścicielem mapowania jest użytkownik; profile leżą
w jego katalogu danych, a nie w kodzie, ZIP źródeł czy tabeli produktów.
Profile zawierają tylko nazwę, nagłówki, indeksy mapowania i opcjonalny UUID
producenta. Bez wartości z pozycji, zdjęć, danych zamówień i sekretów.

## Reguły

- Rozpoznanie porównuje pełną kolejność nagłówków z normalizacją spacji,
  wielkości liter i Unicode NFKC. Nazwa pliku i arkusza nie są kluczem.
  Wiersz nagłówków może się przesunąć. Zmiana kolejności lub nagłówka nie
  stosuje starego profilu. Jedna struktura może mieć kilka zapisanych profili.
- Jeden zgodny profil na jednym arkuszu uruchamia podgląd. Kilka zgodnych
  profili/arkuszy wymaga wyboru. Niedostępny producent nie jest automatycznie
  stosowany. Aktualizacja cennika zachowuje zablokowanego producenta.
- Producent jest widoczny również po zwinięciu mapowania. Waluta/netto-brutto
  są widoczne w podsumowaniu i cenach podglądu. Rozpoznanie nie jest dowodem,
  że plik rzeczywiście dotyczy tego producenta lub waluty; użytkownik to sprawdza.
- Propozycja pierwszego mapowania korzysta wyłącznie z jednoznacznych ogólnych
  nazw kolumn Nazwa/SKU i opcjonalnie EAN/Opis, w pierwszych 30 wierszach.
  Nie zgaduje producenta, ceny, waluty, VAT ani dopasowań motocykla. Niepewne
  lub nieznane nazwy wymagają ręcznego mapowania. Bez analizy płatnym AI.
- Cena, dopasowania i pozostałe pola mogą być zapamiętane po ręcznym wyborze
  i podglądzie. Zgoda na zapisany wynik formuły nie przechodzi do profilu;
  trzeba ją ponowić dla każdego pliku. Formuły nadal nie są wykonywane.
- Rozpoznanie i profil nie zapisują cenników ani Produktów. Zapis profilu jest
  osobną jawną akcją. Niepoprawne ustawienia nie są usuwane; ręczny import działa.
- Usunięcie wybranego profilu wymaga potwierdzenia i zachowuje cenniki/Produkty.

## Granice i ograniczenia

Reguły i port magazynu są w przypadkach użycia, JSON w adapterze, mały panel
w osobnym module GUI. Walidacja mapowania jest współdzielona z importerem.
I/O profili wykonuje istniejący mechanizm zadań, bez SQL i plików w GUI.

JSON v1: maksymalnie 500 profili i 64 KiB na plik, odrzucanie dowiązań,
powtórzonych kluczy, błędnych indeksów/typów i niezgodnego UUID. Zapis przez
plik tymczasowy, flush/fsync i os.replace; brak częściowego JSON przy awarii.
Usuwanie sprawdza bieżącą treść. Profile są odtwarzalnymi ustawieniami, nie
kopią cennika; katalog należy zachować przy przenoszeniu konfiguracji.

Pełne mapowanie pozostaje dostępne w Ustawieniach importu, razem z próbką.
Nie dodajemy edytora kodu, domen producentów, nazw realnych plików ani seedów.
Przyszłe integracje Allegro/PrestaShop/Subiekt nie są częścią tej zmiany.
