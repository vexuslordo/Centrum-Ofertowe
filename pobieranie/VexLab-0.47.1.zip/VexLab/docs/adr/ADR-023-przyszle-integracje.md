# ADR-023 — przyszłe importy, PrestaShop i kurierzy

Data: 2026-11-02. Status: kierunek zaakceptowany w bieżącej rozmowie;
szczegółowe kontrakty i model danych pozostają do zaprojektowania przy realizacji.

Właściciel zaakceptował lokalny model jako wspólne powiązanie danych, a nie
wymóg ręcznego przepisywania katalogu. Docelowo dane można pobrać z PrestaShop
i ofert Allegro. Nie utożsamiamy oferty Allegro, produktu katalogowego Allegro
i lokalnego Produktu; dopasowania nie opierają się wyłącznie na nazwie.
Macierz źródeł prawdy dla cen, dostępności i pozostałych pól wymaga decyzji.

Właściciel chce późniejszy scenariusz Allegro → PrestaShop z ustawieniami
docelowymi. Ustalono odłożenie realizacji. Docelowy kierunek przepływu:
adapter Allegro → port/przypadek użycia i wspólny model → adapter PrestaShop.
Nie dopuszczamy bezpośredniego uzależnienia jednego konektora od drugiego.
Profile ustawień, mapowanie kategorii/cech/kombinacji, ceny i podatki,
udostępnianie w sklepie oraz trwałe identyfikatory powiązań zostaną uzgodnione
przy konkretnym scenariuszu. Nie budujemy pustego frameworka ani tabel profili.

Obsługa przewoźników pozostaje w planie w obszarze Przesyłek: tworzenie,
etykiety i śledzenie. Przewoźnik nie jest KanałemSprzedaży. Dostawcy usług,
autoryzacja i dokładne reguły Przesyłki są otwarte; ten ADR nie ustanawia
siedemnastego bytu ani nowej relacji na podstawie samej nazwy integracji.

Przyszłe skutki zewnętrzne wymagają podglądu zakresu, autoryzacji,
idempotencji/deduplikacji i uzgadniania nieznanego wyniku. Nie wykonujemy
publikacji lub tworzenia przesyłek w ramach testów bieżącego katalogu.

Przyrost 0.4 nie implementuje żadnej z tych integracji. Istniejący graf
warstw wspiera ten kierunek; nie jest to dowód ukończenia kontraktów.

## Dopasowania do motocykli przekazywane do kanałów

WYMAGANIE właściciela, 2026-11-02: wybór/dopasowanie motocykla w lokalnym
katalogu ma być możliwy do przekazania z Produktem do PrestaShop i Allegro.
Dopasowania są wspólnymi danymi katalogu; identyfikatory i słowniki platform
należą do mapowania kanału. Nie ograniczać tej informacji do lokalnego
filtra ani wyłącznie tekstu opisu. Producent części i marka motocykla
pozostają różnymi informacjami. Produkty uniwersalne i niezwiązane
z motocyklami nie wymagają dopasowania; brak danych nie oznacza uniwersalności.

Przed wdrożeniem zaproponować konkretny model i przykłady, również produktu
pasującego do kilku motocykli. Liczność, pola (marka/model/rocznik/wariant),
źródła słowników i walidacja pozostają do uzgodnienia. Wymóg nie dodaje
automatycznie nowego bytu ani tabeli. Sama marka z cennika Evotech nie
określa konkretnego motocykla. Nie odgadywać potwierdzonych dopasowań
z tytułu bez jawnej weryfikacji.

Adaptery mają przekazywać zatwierdzone dopasowania w strukturach faktycznie
obsługiwanych przez kanał. Zweryfikować aktualne API i kategorie Allegro
oraz wersję, konfigurację i ewentualne moduły PrestaShop. Nie obiecywać
identycznych pól na obu platformach. Przed publikacją pokazywać podgląd
przekazywanych informacji i ograniczenia mapowania. Dane niemożliwe do
przekazania wymagają jawnego rozstrzygnięcia przez użytkownika, bez cichego
pominięcia lub automatycznej zamiany na opis.

Odbiór: właściwy Produkt/oferta i konto, wierność wspieranych dopasowań,
raport ograniczeń, wiele dopasowań oraz brak obowiązkowego pojazdu dla
pozostałego asortymentu. Zmiany/usunięcia dopasowań wymagają podglądu
przed zmianą danych kanału. Zasada dotyczy też przyszłego przepływu
Allegro → PrestaShop, jeśli źródło zawiera takie dane; braków nie odgadywać.
Funkcja i jej mapowania nie są jeszcze wdrożone.

## Kategorie pobierane z PrestaShop — decyzja właściciela

Data: 2026-11-02. Właściciel zaproponował pobieranie kategorii motocykli
bezpośrednio z PrestaShop przy wysyłaniu ofert i zaakceptował rozdzielenie
kategorii sklepu od wspólnych danych dopasowania Produktu do motocykla.

Docelowy proces: wybrać sklep docelowy → pobrać jego aktualne drzewo
kategorii → wskazać kategorię docelową → sprawdzić podgląd → zatwierdzić
wysłanie. Uwzględnić pełną ścieżkę kategorii, nie samą nazwę, bo nazwy mogą
się powtarzać. Identyfikator kategorii należy do konkretnego sklepu;
nie jest globalnym identyfikatorem motocykla ani kategorią Allegro.

Kategorie motocykli pobrane ze sklepu mogą ułatwiać przypisanie, lecz nie
ustanawiają automatycznie potwierdzonego dopasowania marka/model/rocznik.
Nie przenosić identyfikatorów PrestaShop bezpośrednio do Allegro. Wspólne
dopasowania pozostają niezależne i podlegają osobnemu mapowaniu kanałów.
Drzewo wyboru obejmuje także kategorie produktów uniwersalnych i pozostałego
asortymentu; nie ograniczać go do gałęzi motocykli.

Przed wdrożeniem sprawdzić API, uprawnienia oraz kontekst sklepu/języka
w konfiguracji właściciela. Wybór kategorii głównej/dodatkowych i ewentualne
propozycje mapowań zostaną doprecyzowane przy realizacji. Nie tworzyć,
nie zmieniać i nie usuwać kategorii sklepu na podstawie samego polecenia
ich pobierania. Niedostępność API, usunięta kategoria lub niejednoznaczne
przypisanie mają dawać czytelny błąd, bez zgadywania kategorii docelowej.

Odbiór przyszłego przyrostu: rzeczywiście pobrane kategorie wybranego sklepu,
rozróżnienie identycznych nazw po ścieżce/ID, prawidłowe przypisanie po
wysyłce i obsługa zmian kategorii pomiędzy wyborem a zapisem. Na obecnym
etapie zapisano decyzję; pobieranie kategorii i publikacja nie są wdrożone.
