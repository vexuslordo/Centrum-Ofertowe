# ADR-020 — lokalny katalog i początkowy schemat SQLite

Data: 2026-11-02. Status: wdrożony pierwszy scenariusz katalogu.
Decyzje modelowe właściciela: SKU jest **obowiązkowe i unikalne**;
„TEST-A” i „test-a” to **ten sam SKU**. Źródło: dwie odpowiedzi właściciela
w bieżącej rozmowie na pytania dotyczące konkretnej propozycji ADR-019.
Pozostałe decyzje implementacyjne: Codex, w ramach delegacji odwracalnych
wyborów technicznych. Nie oznacza akceptacji całego DOMAIN_MODEL.

## Zakres

Dodanie lokalnego szkicu Produktu, odczyt listy, wyszukiwanie po nazwie/SKU,
edycja nazwy/SKU/opisu, trwałość po restarcie i kopia katalogu.
Zachowano 16 głównych pojęć, implementując wyłącznie minimalny Produkt.
Nie ma relacji do Oferty, Producenta, Dostawcy, GPSR ani konta.
Nie ma ceny, magazynu, podatków, publikacji, EAN ani automatycznego importu.
Katalog lokalny jest właścicielem danych tego scenariusza.

Nazwa i SKU po usunięciu skrajnych odstępów są niepuste. Wpisana pisownia
SKU jest zachowana; klucz unikalności to Unicode `casefold()`, bez zmiany
znaków diakrytycznych lub usuwania znaków wewnątrz symbolu. Tak samo
traktujemy polskie litery. SKU nie jest identyfikatorem Produktu.
Opis jest opcjonalny i zachowuje treść użytkownika.

Techniczna tożsamość: UUID v4, generowany w przypadku użycia. Edycja zachowuje
ID i zwiększa wersję od 1. DTO nie ujawnia połączeń SQLite ani obiektów Qt.
Własne kody błędów przypadków użycia mapują błąd na pole formularza;
GUI nie analizuje tekstu wyjątku, by odgadnąć regułę.

## Trwałość

`sqlite3` z biblioteki standardowej; brak ORM i nowego frameworka migracji.
Połączenie jest tworzone i zamykane w kontekście pojedynczego wywołania,
w tym samym wątku. Parametry SQL są wiązane, nie składane z wejścia.
Domyślny tryb dziennika SQLite; nie włączono WAL bez pomiarów i potrzeby.
Klucze obce są włączone na połączeniach, choć ten schemat nie ma relacji.

Schemat 1 obejmuje tabelę `produkty` i techniczny rejestr `migracje`.
Pierwsze otwarcie tworzy tabele w jednej transakcji, z wersją `user_version`,
sumą SHA-256 skryptu i czasem UTC. Czysta instalacja ma 0 Produktów;
techniczny wpis migracji nie jest rekordem biznesowym.
Ograniczenie UNIQUE obejmuje klucz SKU i działa również przy równoczesnym zapisie.
Aktualizacja sprawdza wersję w WHERE; brak zgodności odrzuca zapis.

Wersja 0 oznacza wyłącznie nową pustą bazę bez cudzych tabel. Nieznana wersja,
obcy schemat, uszkodzony plik lub niezgodna suma zatrzymują otwieranie,
zachowując plik. Nie resetujemy i nie usuwamy bazy, aby naprawić błąd.
Ten schemat nie był publikowany przed ustaleniem reguły SKU. Po publikacji
zmianę należy wykonać kolejną migracją, nie edycją schematu 1.

Lokalizacja domyślna: `QStandardPaths.AppLocalDataLocation` dla organizacji/aplikacji
VexLab, plik `katalog.sqlite3`. Preferencje techniczne: `preferencje.ini`
w tym samym katalogu. Alternatywny katalog można wskazać jawnie parametrem
`--katalog-danych`; testy używają wyłącznie katalogów tymczasowych.

Kopia używa SQLite backup API, sprawdza `integrity_check`, nie nadpisuje
istniejącego pliku i nie pozwala kopiować do aktywnej bazy. Procedura
odtworzenia bez otwierania produkcyjnego pliku w testach jest w instrukcji
[danych i kopii](../DANE_I_KOPIE.md).
Nie istnieje migracja w dół ani obietnica zgodności z przyszłymi wersjami.

## GUI i praca w tle

Qt wywołuje przypadki użycia w QThreadPool; wynik wraca sygnałem do wątku GUI.
Nie ma SQL w GUI ani Qt w domenie. Numer żądania odrzuca spóźniony odczyt.
Awaria nie zamienia listy w pozornie pusty katalog; poprzedni odczyt jest
oznaczony jako poprzedni. Formularz po błędzie zachowuje wpisane dane.
Zamknięcie okna podczas aktywnego zadania jest wstrzymane zamiast przerywać zapis.

Wyszukiwanie i sortowanie aktualnego, w całości wczytanego katalogu są lokalne.
To rozwiązanie pierwszego przyrostu; stronicowanie i indeksowanie wymagają
pomiarów przed dużymi wolumenami. Nie deklarujemy wydajności dla nieustalonej skali.

## Dowody i alternatywy

Testy obejmują pustą instalację, trwałość, duplikat (także Unicode/casefold),
równoczesne dodanie, konflikt edycji na poziomie scenariusza i SQL,
rollback zapisu oraz przerwanej inicjalizacji, obcy/uszkodzony schemat,
kopię i odczyt odtworzonego katalogu. GUI testuje rzeczywisty formularz,
zachowanie danych po błędzie, Ctrl+K, motywy i responsywność wątku.

Alternatywy: unikalność zależna od wielkości liter została odrzucona przez
właściciela; SQLite NOCASE samo nie obejmuje wszystkich polskich liter.
ORM/migrator zwiększałby zakres bez potrzeby dla pierwszej tabeli.
Nie implementowano usuwania, scalania, retencji ani niewybranych relacji.
