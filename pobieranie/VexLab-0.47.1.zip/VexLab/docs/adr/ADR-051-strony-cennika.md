# ADR-051 — strony pozycji Cennika

2026-11-07. Decyzja techniczna w ramach kontynuacji roadmapy przez właściciela
po 0.22. Zakres: stronicowanie pozycji Cenników z zachowaniem globalnej
walidacji i porównania cen. Schemat 11 i reguły zapisów pozostają bez zmian.

## Scenariusz i granice

Cennik przechowuje źródłowy JSON jako jeden dokument. Wczytanie całej tablicy
do Pythona i utworzenie komórek Qt dla wszystkich opisów obciąża pamięć/UI.
Nie wolno jednak walidować tylko bieżącej strony: duplikat SKU może wystąpić
na innej stronie, a bazowa cena wymaga rozpatrzenia całego bazowego dokumentu.
Produkt/Producent i źródłowe ceny są dotychczasowymi pojęciami; indeks i strona
są wyłącznie modelami odczytu. Źródłem treści pozostaje zapisany cennik.

## Rozwiązanie

SQLite `json_each` odczytuje rekordy pojedynczo albo według wskazanych indeksów.
Sprawdzenie ID/wersji, limitu 64 MiB / 20 tys. rekordów i struktury dokumentu
odbywa się w transakcji odczytu. Pełny JSON nie trafia do Pythona w tym porcie.
Obsługa JSON musi być dostępna w SQLite dostarczonym z Pythonem; brak funkcji
powoduje jawny błąd odczytu, nie częściowy wynik. Nie dodajemy biblioteki/DDL.

Indeks podglądu zawiera nazwy/SKU, numery wierszy, statusy, ceny porównania
i problemy. Nie zawiera opisów ani dopasowań. Liczności SKU liczone globalnie,
walidacja pojedynczego rekordu używa wspólnego importera z tymi licznościami.
Wspólna funkcja porównania zachowuje dotychczasowe reguły cen i producenta.
Bazowe ceny odczytywane strumieniowo; znane SKU pobierane tylko dla symboli
danego dokumentu, bez pełnego katalogu i jego opisów/zdjęć.

GUI przechowuje lekki indeks i pełne dane tylko strony 100/250/500. Filtrowanie
SKU/nazwy i statusu obejmuje indeks całego dokumentu. EAN pozostaje widoczny,
jeśli występuje gdziekolwiek w dokumencie. Odczyty i przygotowanie indeksu
działają poza wątkiem Qt. Spóźniony wynik nie podmienia innego cennika;
zmiana filtra podczas przygotowania używa gotowego indeksu dla ostatniego
żądania, bez ponownego wykonywania całej walidacji.

## Wybór i zapis

Wybór oparty na indeksach źródłowych i ID/wersji dokumentu, nie numerach
wierszy aktualnej strony. Ctrl+A wybiera wszystkie wyniki filtra; przejście
strony zachowuje wybór. Nowy filtr czyści go. PPM, Ctrl/Shift i Escape mają
wspólne reguły z katalogiem. Wyjaśnienie błędu uwzględnia wszystkie duplikaty.

Dodanie pobiera pełne dane wyłącznie wskazanych pozycji. Przed zapisem
ponownie ocenia wybrany zestaw, dzięki czemu nadal można wybrać jedną
z duplikowanych pozycji. Wersja sprawdzana też w transakcji zapisu, z kopią
i atomowością starego przypadku użycia. Brak częściowego wyboru po błędzie.

## Ograniczenia i dowody

SQLite nadal analizuje zapisany JSON; nie jest to normalizacja dokumentu
do osobnych wierszy. Otworzenie porównania nadal przegląda cały dokument
w tle i potrzebuje pamięci na metadane. Przy wybraniu wszystkich pozycji
zapis wymaga pełnego jawnego zestawu. Nie obiecujemy stałego RAM całego
procesu ani obsługi katalogów większych niż obowiązujące limity.

Testy: zgodność ze starym porównaniem, duplikaty poza stroną, EAN, poprzednie
wydanie, ograniczenie liczby dekodowanych pełnych pozycji, kontrola wersji
przy pustym filtrze, zwolnienie generatora i brak częściowego indeksu po
błędzie. GUI: Ctrl+A, wybór między stronami, dokładny zakres dodania, klawiatura,
ostatni filtr/ostatni cennik, oba motywy i DPI. Brak zmiany schematu/migracji.
