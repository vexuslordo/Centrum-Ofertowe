# ADR-039 — cena z cennika i porównanie cen kanałów

Data: 2026-11-04. Status: WYMAGANIA właściciela potwierdzone w rozmowie;
pełna implementacja odczytów kanałów i ich modelu nadal przyszła.
Ten dokument nie stanowi dowodu działania API.

## Potwierdzony kierunek

Właściciel wymaga, aby kolumna Cena pokazywała cenę odniesienia z aktualnego
cennika producenta. Na pytanie o źródło wybrał „Z aktualnego cennika producenta”.
Kolumny Allegro i PrestaShop mają pokazywać rzeczywiste ceny z tych kanałów,
odczytane przez API dla właściwego konta/oferty, a nie kopię ceny ZIP/cennika.

Cena kanału równa cenie odniesienia lub wyższa: zielone oznaczenie.
Cena poniżej odniesienia: czerwone. To porównanie ceny, nie wyliczenie
zysku/marży lub ocena opłacalności. Wartość różnicy powinna być czytelna
również bez rozróżniania kolorów (kwota/znak/opis).

Brak danych nie jest zerem i nie ma pozytywnego koloru. Różne waluty lub
różna podstawa netto/brutto nie są porównywane automatycznie. Wartości
nieporównywalne, błąd odczytu i nieaktualne dane mają stan neutralny
z informacją o przyczynie. Pokazać czas ostatniego poprawnego odczytu;
nie przedstawiać starej ceny jako odczytanej właśnie teraz.

## Stan 0.11

W katalogu działa źródłowa cena sugerowana z cennika, z walutą, netto/brutto
i źródłem. Nie zmieniono jej danych lub reguł importu. Opis komórki wyjaśnia,
że jest to cena odniesienia z wczytanego cennika. Brak ceny w tej tabeli
po samym imporcie ZIP nadal jest poprawnym stanem, bo import Produktów
nie przenosi ceny gotowej Oferty do ceny sugerowanej katalogu.

Allegro i PrestaShop nie są podłączone — brak odczytów cen i brak zielonych/
czerwonych wartości bez rzeczywistych danych. Samo przyszłe połączenie
nie zastępuje implementacji pobierania, mapowania i odświeżania cen.
Nie dodano w 0.11 sztucznych cen kanałów ani modeli z fikcyjnym odczytem.

## Do ustalenia i sprawdzenia przed implementacją

Dla konkretnego scenariusza przygotować kontrakt: jakie konto/oferta
odpowiada SKU, co przy kilku kontach lub ofertach jednego Produktu,
źródła i własność pól, podstawa ceny/podatków i waluty, czas/zasady
odświeżania oraz status nieaktualności. Nie wybierać bez decyzji minimum
lub średniej z wielu ofert. Potrzebne zweryfikowane API i uprawnienia
wybranego konta/sklepu, bez sekretów w rozmowie lub jawnej bazie.

Źródło bazowe „aktualny cennik” wymaga również jawnego procesu aktualizacji
istniejących cen z podglądem i kopią. Obecne uzupełnianie brakujących cen
nie nadpisuje cen już zapisanych; nie wolno traktować go jako takiej
aktualizacji. Nie ustalono automatycznej konwersji walut/VAT ani częstotliwości.

Te dalsze decyzje dotyczą konkretnych kontraktów trwałości i integracji;
nie blokują zapamiętywania profili ani odświeżenia wyglądu programu.
