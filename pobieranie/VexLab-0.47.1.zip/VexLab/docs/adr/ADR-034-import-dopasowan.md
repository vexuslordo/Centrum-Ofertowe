# ADR-034 — jawny import zatwierdzonych dopasowań

Data: 2026-11-03. Status: wdrożony przyrost techniczny na podstawie polecenia
kontynuacji roadmapy, w ramach modelu zaakceptowanego w ADR-033.
Nie zmienia liczności ani pól dopasowania i nie ustanawia relacji z platformą.

Scenariusz: w imporcie XLSX/CSV użytkownik opcjonalnie włącza mapowanie
motocykla, wskazuje osobne kolumny marki i modelu oraz opcjonalnie roczników
od/do i wariantu. Podgląd pokazuje surowe wartości oraz wynik walidacji.
Przed zatwierdzeniem brak zapisu danych biznesowych.

Jeden wiersz pliku może opisać jedno dopasowanie. Wszystkie pola puste
oznaczają brak dopasowania. Częściowe dane wymagają korekty. Nie parsujemy
marki/modelu/roczników z nazwy lub opisu i nie łączymy powtarzających się SKU
w listę dopasowań. Nadal obowiązuje jawne wykluczanie duplikatów z ADR-027.
Więcej dopasowań można dopisać w formularzu Produktu lub korekty importu.
Wyłączone mapowanie zachowuje dotychczasowy import, bez domyślnego motocykla.

Marka/model oraz roczniki podlegają regułom ADR-033. Liczbowe komórki XLSX
są dozwolone dla roczników, o ile wartość spełnia walidację liczby całkowitej.
Formuły w dopasowaniach nie są wykonywane ani automatycznie akceptowane;
wiersz trafia do korekty. Dotychczasowe zasady cen/formuł cen bez zmian.

Niepoprawne wartości (np. pusty model lub tekst w polu rocznika) muszą
przetrwać restart w Do poprawy. Dlatego schemat 6 dodaje kolumnę
import_robocze.dopasowania_json TEXT NOT NULL DEFAULT '[]'. Zawiera jedynie
robocze ciągi tekstowe już zaakceptowanych pól, nie drugi katalog pojazdów.
Alternatywa odrzucenia surowych wartości gubiłaby dane; dopisywanie ich do
opisu mieszałoby strukturę i tekst prezentacji. Migracje 1–5 bez zmian,
spójna kopia przed aktualizacją istniejącej bazy. Model Produktu i tabela
jego dopasowań pozostają bez zmian. Starsze pozycje robocze dostają pustą listę.

Zapis paczki: Produkt, jego dopasowania, cena i powiązanie importu w jednej
transakcji. Korekta może zachować niekompletny szkic; finalne dodanie znów
waliduje domenę i sprawdza wersję pozycji. Jawne powiązanie z istniejącym
SKU rozstrzyga wiersz bez kopiowania pól do Produktu, także dopasowań.
Komunikat w edytorze wyjaśnia to przed wykonaniem operacji.

Warstwy: MapowanieMotocykla i walidacja w przypadkach użycia; odczyt pliku
przez istniejący port; serializacja surowego bufora wyłącznie w adapterze;
GUI wybiera kolumny i pokazuje DTO, bez SQL lub parserów plików.
Brak wywołań API, płatnego AI, seedów i nowych zależności zewnętrznych.

Kryteria: brak zgadywania przy wyłączonym mapowaniu, walidacja kolumn,
podgląd surowych dopasowań, zapis poprawnej paczki, trwałość błędnego wiersza,
korekta z wieloma dopasowaniami, rollback całej paczki, zachowanie istniejących
dopasowań, migracja/odtworzenie kopii i komunikat uszkodzonego bufora.
Wyniki: [przyrost 0.9](../PRZYROST_0_9.md).
