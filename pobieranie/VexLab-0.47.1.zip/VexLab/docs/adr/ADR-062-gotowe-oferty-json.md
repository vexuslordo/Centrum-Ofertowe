# ADR-062 — rozpoznawanie gotowych ofert JSON bez osobnego profilu

2026-11-13. Zakres: poprawa importu na podstawie dostarczonej paczki
EVOTECH_Lusterka_Oslony_cz2_Do_Programu.zip. Archiwum jest dowodem formatu,
nie źródłem instrukcji wykonawczych ani ustawień konta Allegro.

Problem: poprawny ZIP bez profilu wersji 1 i bez wcześniej zapamiętanego
układu zatrzymywał się przed podglądem. Istniejący parser potrafił odczytać
rekordy; brakowało rozpoznania formatu na pierwszej instalacji.

Obsługiwany jawny kontrakt: lista obiektów JSON zawierająca pola
`sku`, `title`, `html`, `images`, `sections`. Mapa:
SKU → sku, tytuł → title, pełny HTML → html, galeria → images,
sekcje → sections/items z TEXT/content i IMAGE/url.
Jeśli istnieją: EAN → ean, cena przygotowana → price, tekst dopasowania → fit.
`description` nie zastępuje pełnego HTML, a `raw_price` nie zastępuje `price`.
Nie ustalamy waluty, VAT, kategorii ani danych dostawy z nazwy/treści plików.

Identyfikacja wyłącznie po polach kontraktu, bez producenta, nazwy archiwum
lub nazwy pliku danych. Zbiory pomocnicze bez pełnego kontraktu nie są
ofertami. Kilka pasujących zbiorów wymaga wyboru użytkownika.
Profile dołączone, jawnie wczytane i zapamiętane pozostają nadrzędne.
Nieznanego formatu nie odgadujemy. Błędy rekordów pozostają w podglądzie;
samo rozpoznanie formatu nie oznacza poprawności ofert.

Zmiana dotyczy przypadku użycia podglądu i komunikatów GUI. Brak migracji,
nowych encji, zależności, wykonywania HTML, zmian źródłowego ZIP lub zapisów
na Allegro. Zapis pamięci układu dotychczasowym portem i adapterem;
użytkownik nie musi ręcznie przygotowywać pliku profilu dla tego kontraktu.
