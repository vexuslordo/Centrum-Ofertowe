# ADR-030 — ceny sugerowane i czyszczenie lokalnego katalogu

Data: 2026-11-02. Zakres właściciela: ceny z cenników są sugerowanymi cenami
sprzedaży, różne waluty; pokazać cenę w katalogu i umożliwić jego czyszczenie.
Decyzje techniczne przyrostu 0.6 opisane przed migracją schematu.

Cena sugerowana pozostaje źródłową informacją cennika, poza encją Produktu
oraz aktywną ceną Oferty. Wybór jednej kolumny ceny, waluty i netto/brutto
jest jawny w imporcie. Zapis Decimal bez float, kwota nieujemna, do 6 miejsc
po przecinku; pusta cena oznacza brak, nie zero. Nie przeliczamy walut, VAT
ani marż. Cena ma referencję Produktu i pochodzenie. Tabela i szczegóły
opisują ją jako sugerowaną i pokazują walutę oraz netto/brutto.
Nie dodajemy siedemnastego głównego bytu ani pola ceny do domenowego Produktu.

XLSX: liczba w kolumnie ceny jest prawidłowym wejściem, ale nie wykonujemy
formuł. Użycie wartości zapisanych przy formułach wymaga zaznaczenia osobnej
opcji; mogą być nieaktualne, importer nie przelicza Excela. Nieprawidłowa
cena trafia do korekty wraz z wierszem. W buforze można poprawić cenę,
walutę i netto/brutto. Powiązanie z istniejącym Produktem nie nadpisuje
jego ceny. Nie aktualizujemy automatycznie cen już istniejących Produktów.

Usuwanie dotyczy pojedynczego zaznaczonego Produktu albo dokładnej migawki
wyników widocznych przy wybraniu akcji. Przed wykonaniem interfejs podaje
liczbę i wymaga jawnego potwierdzenia; brak zgody nie wykonuje żadnego zapisu.
Adapter blokuje zapisujących, sprawdza wersje/istnienie wszystkich pozycji,
tworzy spójną kopię całej bazy w kopie_usuwania i dopiero usuwa w jednej
transakcji Produkty, ich źródłowe ceny i techniczne powiązania importu.
Błąd kopii lub konflikt blokuje całą operację. Nowo dodane poza migawką
Produkty pozostają; nie jest to polecenie skasowania pliku bazy.
Producenci i oczekujące Do poprawy pozostają bez zmian. Operacja dotyczy
wyłącznie lokalnego katalogu, bez usuwania w Allegro/PrestaShop.

Przywrócenie wymaga kopii w nowym katalogu zgodnie z DANE_I_KOPIE.md;
nie obiecujemy selektywnego Undo ani scalania późniejszych zmian. Usunięte
SKU można ponownie zaimportować. Jeśli przyszłe relacje biznesowe zablokują
FK, błąd ma wycofać usuwanie, a nie usuwać dodatkowe nieuzgodnione dane.

Schemat 4: tabela źródłowych cen sugerowanych i dodatkowe robocze pola ceny
w buforze importu. Schematy 1–3 i ich sumy pozostają niezmienione. Przed
migracją istniejącej bazy kopia; transakcyjny zapis migracji. Starsze programy
nie otwierają schematu 4. Powrót tylko ze starszą kopią w osobnym katalogu.

## Uzupełnianie cen i masowa edycja — konkrety wdrożenia

Osobny podgląd umożliwia uzupełnienie tylko brakujących cen po jednoznacznym
SKU, bez kasowania i ponownego dodawania istniejących Produktów. Pominięcia
mają numery wierszy i powody. Zapisywany dokładny plan z wersjami, kopią
w kopie_cen i jedną transakcją; wyścig ceny/wersji blokuje całość.
Nie nadpisuje już zapisanych cen, nazw, opisów, producentów ani mediów.

Wielokrotny wybór, Ctrl+A i przycisk Zaznacz wszystkie wyniki dotyczą
aktualnego filtra. Formularz masowy jawnie wybiera zmianę producenta
i tryb opisu: bez zmian/zastąp/dopisz/wyczyść. Pozostałe pola zachowane.
Kopia w kopie_edycji_masowej, blokada zapisujących i kontrola wersji
wszystkich Produktów, zapis w jednej transakcji. To nie masowa publikacja.

Schemat 4 obejmuje też dane źródła Producenta i lokalne zdjęcia z ADR-031;
nie zmieniono wcześniej wydanych schematów 1–3. Kopia całej bazy obejmuje media.
