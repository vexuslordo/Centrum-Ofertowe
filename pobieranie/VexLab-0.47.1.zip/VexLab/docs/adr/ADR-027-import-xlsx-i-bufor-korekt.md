# ADR-027 — import XLSX/CSV i trwały bufor korekt

Data: 2026-11-02. Status: wdrożone decyzje techniczne przyrostu 0.5.
Autor: Codex, w ramach polecenia kontynuowania pracy i delegacji technicznej.
Wymagania oraz decyzje właściciela: ADR-026. Wersja 0.5.0.dev0.

## Zakres i granice

Wdrożono lokalny import nazwy, SKU, opcjonalnego opisu i Producenta.
Nie zmieniono reguł Produktu ani Producenta i nie dodano głównego bytu.
Bufor korekt i potwierdzenia paczek są technicznymi zapisami procesu importu.
Ceny, EAN, parametry pojazdów i platformy nie są zapisywane przez ten proces.
Lista pomijanych kolumn jest widoczna przed podglądem i zatwierdzeniem.
Nagłówki w wyborze kolumn zachowują brzmienie źródła, aby nie mylić układów
różnych producentów; MARKA z przykładu Evotech oznacza markę motocykla,
pozostaje w pomijanych kolumnach i nie zasila Producenta części.

Port czytnika i magazynu oraz niezmienne DTO są w przypadkach użycia.
Adapter czytnika odpowiada za format, adapter SQLite za transakcję.
Katalog i bufor używają jednego pliku bazy; bootstrap składa implementacje.
GUI uruchamia odczyt, walidację i zapis poza głównym wątkiem.

## Format i limity

Obsługiwane: tabelaryczny XLSX (SharedStrings i inlineStr, luki w komórkach)
i CSV UTF-8, także z BOM, z wykrywaniem średnika, przecinka lub tabulatora.
Użytkownik jawnie wybiera arkusz, wiersz nagłówków i indeksy kolumn.
Nie zakładamy nazw Title/KOD ani kolejności Evotech w kodzie.
Nie obsługujemy XLS, XLSM, PDF, ODS, makr, obliczania formuł ani dowolnej
wizualnej struktury Excela. Zaawansowane formatowanie komórek nie jest
odtwarzane. Tekstowe SKU zachowuje zera; numeryczne pola oraz formuły
w mapowanych kolumnach wymagają korekty/świadomego wpisania tekstu na liście
Do poprawy. Nie odgadujemy utraconych zer i nie ufamy wynikowi formuły.

Limit pliku 20 MB; rozpakowanego XLSX 40 MB i 2000 elementów; 100 arkuszy,
łącznie 20000 wierszy, 250000 komórek, 256 kolumn, tekst komórki XLSX
32767 znaków. CSV podlega limitowi pliku, wierszy/kolumn oraz ograniczeniu
pola biblioteki csv. Przekroczenie i uszkodzony plik są jawnym błędem.
Wszystko wczytywane do pamięci; większe zbiory wymagają osobnego pomiaru.

Defusedxml 0.7.1 jest przypięte jako runtime, bez sieci w czytniku. Zakaz DTD,
encji i zewnętrznych encji, limity ZIP przed odczytem, brak wypakowywania
na dysk i brak pobierania zewnętrznych arkuszy. Lokalny wyjątek Bandit B405
na imporcie Element/ParseError dotyczy wyłącznie typu i klasy wyjątku;
parsowanie wykonuje defusedxml. Właściciel techniczny: Codex, zakres:
czytnik XLSX, przegląd przy zmianie parsera lub aktualizacji defusedxml.
Test DTD/encji potwierdza odrzucenie. Nie wyłączono kontroli globalnie.

## Plan i zapis

Podgląd pokazuje numery wierszy i powody problemów. Poprawne wiersze są
wstępnie zaznaczone; wszystkie powtarzające się SKU są wstępnie odłożone.
Użytkownik może jawnie wybrać jeden wiersz z grupy, po czym wybrany zestaw
jest walidowany ponownie. Samo zaznaczenie nie omija braków nazwy/SKU,
formuł i konfliktów z katalogiem. Producent sprawdzany ponownie przy zapisie.
Nie ma scalania, sufiksów ani nadpisania istniejących Produktów.

Zatwierdzenie tworzy jedną transakcję BEGIN IMMEDIATE: Produkty, powiązania
wierszy i pozycje Do poprawy zapisują się razem albo wcale. Także całkowicie
odłożoną paczkę można świadomie zapisać. ID paczki blokuje ponowienie tego
samego planu; ponowne otwarcie pliku tworzy nowy plan, w którym istniejące
SKU są konfliktami. To nie obietnica deduplikacji pliku według jego nazwy.
Błąd zachowuje podgląd. Zmiana mapowania/producenta unieważnia plan.
Wybór uszkodzonego nowego pliku nie pozostawia aktywnego starego planu.

Bufor zachowuje wyłącznie mapowane dane, Producenta, nazwę pliku, arkusz,
numer wiersza, powód i wersję korekty. Nie archiwizuje całego XLSX ani
pominiętych pól; nie jest więc kopią cennika. Korektę można zapisać bez
finalnego dodania. Dodanie Produktu usuwa pozycję oczekującą atomowo z zapisem
powiązania. Jawne przypisanie do istniejącego Produktu nie zmienia jego danych;
w tym przyroście wymaga zgodnego SKU. Inne kody/aliasy wymagają odrębnej
reguły. Kontrola wersji bufora blokuje utratę równoległych poprawek.

## Schemat 3, aktualizacja i powrót

Publikowane SCHEMAT 1 i MIGRACJA_2 oraz ich sumy pozostają niezmienione.
Migracja 3 dodaje importy, import_robocze i import_powiazania, bez zmiany
istniejących Produktów. Przed zmianą istniejącego schematu 2 tworzona jest
spójna kopia do kopie_migracji, potem transakcyjna migracja z kontrolą FK.
Brak kopii blokuje zmianę. Przy przejściu z 1 pozostaje kopia schematu 1
utworzona przez migrację 2; nowe puste bazy nie wymagają kopii.
Błędy nie resetują danych. Nowe bazy nie mają danych demonstracyjnych.

Wersje 0.3/0.4 nie otworzą schematu 3. Nie ma migracji w dół. Powrót wymaga
kopii sprzed aktualizacji w osobnym katalogu danych; nie obejmie zmian
wykonanych później. Pełne kroki: docs/DANE_I_KOPIE.md. Przykładowy cennik
właściciela przetestowano wyłącznie na tymczasowej bazie, bez dodania go do ZIP.
