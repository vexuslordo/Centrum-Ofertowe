# ADR-059 — lokalne propozycje edycji zdalnych szkiców Allegro

Status: wdrożone w 0.37 w zakresie formularza, plików roboczych i odczytu
aktualności. Zapis zmian w Allegro pozostaje niewdrożony i wyłączony.
Źródło: polecenie właściciela kontynuowania roadmapy, 2026-11-09.

## Kontekst i decyzja

Roadmapa wymaga edycji szkiców i jawnego zapisu po potwierdzeniu bieżącego
kontraktu API. Obecne środowisko ma wymuszoną listę domen bez
`developer.allegro.pl`; dostęp do dokumentacji nie jest dostępny. Oficjalny
README repozytorium allegro/allegro-api odsyła do tej domeny; próba pobrania
swagger.yaml z tego repozytorium zwróciła 404. Nie uznano tego za dowód
warunków zapisu, If-Match, ETag lub zachowania konfliktów.

Niezależna część wdrożenia przygotowuje jedną propozycję tytułu i sekcji
opisu szkicu INACTIVE, opartą na potwierdzonym koncie i świeżym GET.
Nie rozszerzamy transportu o PATCH/PUT, zakresów OAuth ani modeli bazy.
Zapis przez API jest wyłączony także po pomyślnym sprawdzeniu aktualności.

## Warstwy i dane

PropozycjaSzkicu jest małym, niemutowalnym DTO pracy użytkownika: środowisko,
ID konta/oferty, bazowy tytuł/sekcje oraz proponowany tytuł/sekcje. Nie jest
nowym agregatem Oferty ani konkurencyjnym Produktem. Nie zmienia ceny, stanu,
SKU, galerii lub metadanych zdalnej oferty. Nie otrzymuje tokenów, Client ID,
Client Secret ani pełnej odpowiedzi API.

PropozycjeSzkicow waliduje robocze dane, porównuje bazę z odczytem i obsługuje
port PlikiPropozycji. PropozycjeJSON zapisuje zamknięty, wersjonowany format,
limit 2 MiB, bez nadpisywania istniejących plików. Niepełny nowo utworzony plik
jest usuwany przy błędzie zapisu, a niepowodzenie sprzątania ma osobny komunikat.
Import odrzuca obce pola, powtórzone klucze JSON, nieprawidłowe adresy obrazów,
inny kontekst konta/środowiska/oferty lub inny tytuł/sekcje bazowe.

Bootstrap składa adapter i przypadek użycia. GUI ponownie używa EdytorOpisu:
formatowanie, układ sekcji, zdjęcia i podgląd. Otwarcie i zamknięcie bez zmian
zachowują oryginalne sekcje, bez przepisania HTML. Odczyty API i plików oraz
zapis lokalny idą przez istniejącą pulę zadań. GUI nie wykonuje SQL lub I/O
plików bezpośrednio. Schemat 11, migracje i zależności pozostają niezmienione.

## Aktualność i zamknięcie

Przygotowanie dostępne tylko dla wiersza INACTIVE, także na liście Wszystkie.
Przed otwarciem ponowny GET szkicu musi potwierdzić stan. Ręczne „Sprawdź
aktualność” sprawdza aktualną sesję/konto/środowisko i ponownie pobiera szkic.
Różny tytuł/sekcje lub stan oznaczają konflikt; propozycja pozostaje w formularzu.
Zmiana ceny, której nie edytujemy, nie powoduje konfliktu treści.

To porównanie dwóch odczytów, nie atomowa blokada zasobu ani gwarancja stanu
po odczycie. Nie wolno na tej podstawie deklarować bezpiecznego zapisu
równoległego w Allegro. Weryfikacja warunków zapisu i polityki nieznanego
wyniku pozostaje blokadą kolejnego etapu.

Rozłączenie konta zachowuje edycję i możliwość zapisu lokalnego; blokuje
sprawdzenie niewłaściwego kontekstu. Zamknięcie niezapisanej edycji pyta
o odrzucenie, domyślnie Nie. Zamknięcie programu uwzględnia otwarty edytor.
Błąd pliku/odczytu lub odmowa odrzucenia nie kasują treści.

## Dostęp do dokumentacji

Zapisano projekt konfiguracji środowiska dodający tylko publiczną domenę
`developer.allegro.pl` do listy niestandardowych domen; pakietowe presety
pozostają zachowane. Narzędzie zwróciło saved oraz requires_publish=true.
To nie oznacza zastosowania projektu do działającego środowiska. Użytkownik
musi przejrzeć/zapisać zmiany w ustawieniach i opublikować środowisko, a po
zastosowaniu należy ponownie potwierdzić obserwowany dostęp.
