# ADR-024 — przegląd i eksport istniejącego katalogu

Data: 2026-11-02. Status: odwracalna decyzja techniczna przyrostu 0.4.
Autor: Codex w ramach polecenia kontynuowania pracy i delegacji rutynowych decyzji.

Scenariusz: użytkownik filtruje lokalne Produkty po nazwie/SKU i producencie,
otwiera szczegóły bez edycji, a następnie eksportuje dokładnie widoczne wyniki
w bieżącej kolejności sortowania. Dostępny jest też filtr bez producenta
i jawne wyczyszczenie filtrów. Odświeżenie zachowuje wybór producenta i
zaznaczony Produkt po ID, jeżeli nadal należy do wyników.

Nie zmieniamy żadnych danych, niezmienników 16 bytów ani schematu 2.
Odczyt używa istniejących portów, zwraca DTO Produktów i Producentów.
GUI filtruje cały obecnie wczytany katalog, nie pojedynczą stronę wyników.
Pełne wczytywanie pozostaje ograniczeniem skali do osobnych pomiarów.

Eksport ma port w przypadkach użycia i adapter CSV z biblioteki standardowej.
GUI przechwytuje niezmienny zestaw DTO widocznych w chwili zlecenia;
późniejsza zmiana filtrów nie rozszerza zakresu operacji. I/O jest w tle.
Eksport jest blokowany po błędzie odczytu do czasu udanego odświeżenia.
Anulowanie wyboru pliku nie wykonuje zapisu; istniejący plik nie jest nadpisywany.

Format do arkusza: UTF-8 z BOM, separator średnik, cytowane pola, kolumny
Nazwa produktu / SKU / Opis / Producent. Nie eksportujemy fikcyjnych cen,
stanów, statusów platform ani niezaimplementowanych pól. Wartości mogące
zostać potraktowane jako formuły otrzymują ochronny apostrof; liczba takich
pól jest raportowana. Jest to eksport do arkusza, nie kontrakt importu API
lub kopia bazy; prefiks ochronny może być widoczny w innych czytnikach CSV.

Podgląd pokazuje pełną nazwę, SKU, producenta i opis jako zwykły tekst;
nie wykonuje HTML z danych. Podgląd nie zapisuje ani nie publikuje.
Istniejący dwuklik nadal otwiera edycję; osobny przycisk/Enter otwiera szczegóły.

Kryteria: łączenie filtrów, brak danych vs brak wyników vs awaria,
zachowanie wyboru przy odświeżeniu, zgodność eksportu z posortowanymi wynikami,
obsługa polskich liter/cudzysłowów/wielu linii, ochrona formuł,
brak nadpisania pliku i brak pozornego sukcesu po błędzie zapisu.
