# ADR-070 — sprawdzanie istniejących ofert przed wysyłką

Właściciel wymaga sprawdzania, czy oferty zostały już opublikowane, żeby nie
powielać ich na koncie Allegro. Osobny przypadek użycia, tylko GET.

Przycisk Sprawdź duplikaty w planie działa dla zaznaczonych lub widocznych
pozycji. Serwerowe wyszukiwanie /sale/offers po external.id (SKU/sygnatura),
a następnie po nazwie w razie braku SKU. Bez filtra publication.status,
więc obejmuje ACTIVE, INACTIVE, ENDED i pozostałe statusy zwracane przez API.
Nie polega na stronie 50 pozycji wyświetlanej w zakładce Allegro.

SKU jest porównywane po normalizacji tekstu. Przy historycznej sygnaturze
wymagamy takiego samego znormalizowanego tytułu; porównujemy EAN pobrany ze
szczegółów własnej oferty. Różne dostępne EAN wykluczają takie dopasowanie.
Brak EAN oznacza podejrzenie wymagające porównania, nie potwierdzenie tożsamości.
Na tym etapie także podejrzenie blokuje nowy szkic — jawny status i ID.
Sam EAN nie identyfikuje oferty: warianty lub dopasowania mogą go współdzielić.
Nie obiecujemy rozpoznania starych ofert z innym SKU i zmienionym tytułem.

Wyniki są stronicowane po 100, kontrola kompletności/zmiany totalCount,
maksymalnie 1000 dopasowań jednego zapytania. To granica bezpiecznej kontroli,
nie limit wielkości konta. Przekroczenie lub błąd blokują wysyłkę, nigdy nie
udają braku duplikatu. Cache wyłącznie w jednym przebiegu, bez trwałego indeksu.

Przed nowym tworzeniem dialog wykonuje świeżą kontrolę konta i pomija
znalezione pozycje. Próby już zarejestrowane lokalnie idą istniejącą ścieżką
sprawdzania, bez nowego POST. Nadal działa niezależna kontrola external.id
w serwisie tworzenia bezpośrednio przed POST. Żaden istniejący szkic lub oferta
nie jest modyfikowany, usuwany lub ponownie publikowany. Brak transakcyjnej
blokady innych aplikacji na koncie; obce równoczesne zapisy mogą zmienić wyniki.

Komunikaty zawierają ID, status, przyczynę dopasowania i tytuł. Stan Już na
Allegro jest osobno liczony jako pominięty, a nie nowo utworzony. Raport CSV
zachowuje wynik. Bez migracji, nowych scope i zmian domeny Produktu.


Doprecyzowanie właściciela w 0.47: przycisk Parametry produktów przeniesiony
do lewego panelu Dane produktów; ten sam formularz masowy i zakres zaznaczenia.
