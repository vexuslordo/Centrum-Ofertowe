# ADR-053 — sesja Allegro i odczyt szkiców

2026-11-08. Zakres zatwierdzony przez właściciela: najpierw Allegro,
połączenie konta, następnie szkice i edycja; GT odłożony. Przyjęta technicznie
sesja 0.25 bez trwałego modelu konta i bez rozstrzygania magazynu Windows P-07.

Alternatywy: trwałe logowanie wymaga magazynu sekretów; Authorization Code
wymaga odbiornika i konfiguracji redirect URI. Pierwszy przyrost korzysta
z Device Flow i odpowiednio zarejestrowanej aplikacji właściciela.

Decyzja: sesja wyłącznie w pamięci, potwierdzenie `/me` przed sukcesem,
odczyt stron INACTIVE. Konto i środowisko są częścią DTO sesji, nie Produktu.
Żadnego utrwalania relacji Produkt/Oferta, sekretów lub konta. Brak zapisów
na Allegro, osobne UI od szkiców lokalnych; edycja i zapis nadal do wykonania.
Brak refresh, po wygaśnięciu ponowne logowanie. Sekrety repr=False, stałe
hosty, brak redirectów, ograniczony odczyt i bezpieczne klasy błędów.

Konsekwencje: użytkownik wpisuje dane po każdym restarcie; odbiór na prawdziwej
aplikacji jest konieczny. Implementacja bez trwałego magazynu nie zatwierdza
żadnej propozycji P-07. Nowy schemat, publikacja i nowy model kont pozostają
poza tym przyrostem. Szczegóły docs/PRZYROST_0_25.md.
