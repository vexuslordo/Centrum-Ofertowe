# ADR-036 — paczki gotowych ofert w ZIP

Data: 2026-11-03. Status: WYMAGANIE właściciela z rozmowy.
Właściciel wymaga dodawania paczek już przygotowanych ofert, oprócz
istniejącego importu produktów z cenników. Potwierdzony format opakowania:
plik ZIP. Wewnętrzna struktura i kontrakt danych nie są jeszcze znane.
Funkcja niewdrożona; ten zapis nie zatwierdza całego modelu z ADR-035.

## Docelowy scenariusz

Osobne wejście importu gotowych ofert w obszarze Ofert. Wskazanie ZIP-a,
rozpoznanie zawartości, podgląd ofert i ich powiązanych plików, raport
problemów, wybór i zatwierdzenie zapisu lokalnego. Sam import nie jest
poleceniem publikacji do kanału i nie ustanawia potwierdzonej gotowości
oferty według zasad Allegro/PrestaShop.

Gotowy tytuł i opis mają być źródłem prezentacji, jeśli paczka je zawiera;
nie zastępować ich tekstem wygenerowanym z cennika lub nazwą Produktu.
Zachować rozdział Produkt/Oferta. Nie zakładać istnienia SKU, konta,
manifestu CSV/JSON/XML, dokumentów HTML ani określonej struktury katalogów
bez obejrzenia reprezentatywnej paczki.

## Informacje potrzebne z przykładu

Mała reprezentatywna paczka z jedną–dwiema ofertami pozwoli ustalić:
strukturę plików i grupowanie ofert, format tytułów/opisów, odniesienia
do zdjęć i ich kolejność, identyfikatory/SKU, ceny/waluty oraz ewentualne
metadane kanału. Odczyt ceny z pliku nie rozstrzyga jej własności ani
interpretacji podatkowej. Brak danych wymaga mapowania lub korekty,
a nie dopowiadania ich z nazw plików.

Przed implementacją: spisać rzeczywisty kontrakt i przykłady mapowania,
podgląd błędów, reguły powiązania z lokalnym Produktem oraz ponownego importu.
Jeśli brak Produktu lub SKU, przygotować konkretną decyzję zamiast ukrytego
utworzenia konkurencyjnego katalogu. Uwzględnić wiele ofert jednego Produktu.
Dotychczasowa propozycja kopiowania tytułu/opisu z Produktu w ADR-035 dotyczy
ręcznego utworzenia szkicu; nie może nadpisywać gotowej treści z ZIP-a.

## Granice techniczne

Archiwum i zawarte teksty są danymi, nie poleceniami. Nie wykonywać skryptów,
makr, JavaScript ani instrukcji z plików. Nie uruchamiać HTML jako aktywnej
strony. Nie zakładać pobierania zewnętrznych URL-i lub logowania do usług.

Czytnik archiwum za portem, poza wątkiem GUI. Przed rozpakowaniem sprawdzić
ścieżki (w tym .., ścieżki absolutne/Windows i dowiązania), duplikaty nazw,
liczbę i rozmiary plików, rozmiar po rozpakowaniu i współczynnik kompresji;
konkretne limity dobrać do sprawdzonego scenariusza, z widocznym błędem.
Nie rozpakowywać do katalogu programu lub danych użytkownika bez kontroli.
Pliki zaszyfrowane, uszkodzone i zagnieżdżone wymagają jawnej obsługi,
bez cichego pomijania treści. Obrazy przechodzą walidację kodeka.

Wyniki i błędy per oferta, brak częściowego niejawnego zapisu i cichego
nadpisania już istniejących danych. Migracja dopiero po ustaleniu modelu,
z kopią i testem odtworzenia. Brak danych demonstracyjnych w nowej bazie.

## Status pracy

Wymaganie i ZIP potwierdzone. Potrzebna reprezentatywna paczka do analizy.
Nie zmieniono kodu, schematu ani wersji aplikacji. Audyt 1.0 ma objąć
również ten scenariusz, jeśli zostanie wdrożony w badanym wydaniu.


## Przykład i doprecyzowanie właściciela — 2026-11-03

Otrzymano paczkę Evotech i wykonano [analizę zawartości](../ANALIZA_PACZKI_OFERT_EVOTECH.md).
200 gotowych rekordów, 51 odłożonych; układy zapisane per oferta,
zdjęcia jako URL-e. Kod importera nie jest jeszcze wdrożony.

WYMAGANIE właściciela: układ i ustawienia producenta są konfiguracją
użytkownika. Nie zaszywać Evotech, nazw plików, banerów, domen, treści,
kategorii lub wartości ustawień Allegro w kodzie ani domyślnych seedach.
Profil odczytu archiwum oddzielić od układu zapisanej oferty oraz od
konfiguracji publikacji wybranego konta. Podgląd ma zachowywać źródłową
strukturę sekcji, bez zastępowania jej jednym układem dla wszystkich.


## Cel końcowy doprecyzowany przez właściciela

2026-11-03 właściciel wskazał, że paczka ma docelowo być wysyłana bezpośrednio
na Allegro wraz z wymaganymi ustawieniami dobieranymi przez program i API.
Sam podgląd nie spełnia pełnego wymagania. Program ma pobrać wymagania
kategorii i ustawienia wybranego konta z API, dobrać je na podstawie profilu
i danych użytkownika, zweryfikować kompletność, wysłać i raportować wynik.
Nie zaszywać ustawień producenta lub konta w kodzie. Etap odczytu nie jest
upoważnieniem do fikcyjnego oznaczania gotowości/wysyłki. Przyrost 0.10
realizuje tylko [podgląd i profile](ADR-037-podglad-zip-profile-i-logo.md).
