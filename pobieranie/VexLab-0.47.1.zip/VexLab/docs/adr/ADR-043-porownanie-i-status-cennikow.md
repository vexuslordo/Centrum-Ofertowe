# ADR-043 — podgląd, porównanie cen i aktualny cennik

2026-11-06. Właściciel zaakceptował propozycję pięciu usprawnień słowami
„Podoba mi się. Wdrażamy”: podgląd obok listy, statusy pozycji, porównanie
cen, oznaczenia Aktualny/Archiwalny per producent oraz krótszy pasek i PPM.

Cennik pozostaje dokumentem źródłowym. Użytkownik zarządza flagą aktualności,
nie rok lub czas importu. Maksymalnie jeden aktualny dokument na producenta;
może nie być żadnego. Bez producenta brak możliwości oznaczenia jako aktualny.
Nowe i dotychczasowe dokumenty startują jako archiwalne; nic nie jest zgadywane.
Usunięcie aktualnego nie wybiera automatycznie następnego. Samo oznaczenie nie
nadpisuje Produktów lub ich cen. Aktualizacja cen pozostaje jawnym procesem;
istniejące uzupełnianie braków zachowane, masowe zastępowanie cen poza zakresem.

Zmiana flag w jednej transakcji z kopią, kontrolą wersji dokumentów producenta
sprzed potwierdzenia i zwiększeniem wersji zmienianych dokumentów. Konflikt
blokuje całą zmianę. Schemat 9: flaga i częściowy indeks unikalności, kopia
8→9. Zachować dokładne definicje migracji 1–8. Przywrócenie starszej aplikacji
wymaga kopii sprzed migracji, zmiany późniejsze nie są w niej zawarte.

Statusy pozycji: Do poprawy dla błędów (także istniejącego SKU), Nowy dla
nieznanego SKU, Inna cena dla różnej porównywalnej ceny, W katalogu dla reszty.
Cena bazowa jest obecną zapisaną ceną źródłową katalogu dopasowaną po SKU.
Porównanie w Decimal: cena cennika minus bazowa; procent względem bazowej.
Waluta i netto/brutto muszą być zgodne. Brak ceny, inny producent, waluta
lub netto/brutto → brak liczbowego porównania z wyjaśnieniem. Przy zerowej
bazowej różnica kwotowa istnieje, procent nieokreślony. Bez kursów/VAT/API.
Kolor statusu wspomaga tekst, nie ocenia opłacalności zmiany.

GUI: lista po lewej, wybór cennika odczytuje pozycje po prawej w tle,
na małej szerokości podział pionowy. Pasek Dodaj cennik / Dodaj do katalogu /
Więcej; inne akcje w menu i PPM, klawiatura, wielokrotny wybór, potwierdzenia
usuwania zachowane. Bez nowych encji głównych, SQL w GUI lub seedów.
