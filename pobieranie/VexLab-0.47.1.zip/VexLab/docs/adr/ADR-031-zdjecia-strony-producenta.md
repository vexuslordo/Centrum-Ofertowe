# ADR-031 — źródła zdjęć wpisywane przez użytkownika

Data: 2026-11-02. Wymaganie właściciela: przed dodaniem produktów wskazać
stronę producenta i pobierać zdjęcia na podstawie SKU. Potwierdził przykład
konkretnej strony, zastrzegając, że jej adres nie może być zaszyty w kodzie.
Nowa instalacja ma być pusta. Nie dodawać domyślnego producenta, domeny ani mediów.

Adres HTTPS będzie opcjonalną daną Producenta. Pobieranie ma działać za portem
źródła mediów, z adapterem dla jawnie wspieranego mechanizmu sklepu. Pierwszy
zakres: publiczny katalog Shopify, niezależny od nazwy producenta i domeny.
Sam dowolny URL nie oznacza, że można z niego pobrać produkt. Nie tworzyć
uniwersalnej obietnicy scrapowania każdej witryny ani nie wymyślać URL z SKU.

Warunek: dokładne dopasowanie SKU wariantu, nie wyłącznie podobny tytuł.
Brak i niejednoznaczność blokują przypisanie. Pokazać stronę źródłową,
tytuł i kandydatów zdjęć do akceptacji; zdjęcia produktu nadrzędnego mogą
obejmować inne warianty. Przy błędzie nie podmieniać obecnych zdjęć i nie
udawać powodzenia. Wybrany adres, pobranie i zapis są oddzielnymi czynnościami.

Transport tylko publiczny HTTPS, bez haseł w URL, bez wykonywania HTML/JS,
z timeoutami i limitami odpowiedzi. Sprawdzić format i rozmiary obrazów,
nie zapisywać SVG/HTML jako zdjęcia. I/O w tle, dane strony nie są poleceniami
programu. Klient bez sekretów i ciasteczek. Odpowiedzi błędów bez logowania
pełnych danych lub kluczy. Publiczny odczyt nie dowodzi prawa do dalszej publikacji
mediów; wskazanie źródła musi pozostać przy zapisanym zdjęciu.

Zdjęcia zaakceptowane przez użytkownika mają znaleźć się w bazie lokalnej
wraz z miniaturą i adresem pochodzenia, aby kopia katalogu je obejmowała.
Zapis Produktu i nowych mediów atomowy; zmiana zdjęć istniejącego Produktu
sprawdza wersję. Bez wybrania nowych zdjęć nie usuwać istniejących.
Usunięcie Produktu usuwa jego lokalne media po wykonaniu kopii.
To lokalny zakres Mediów, bez publikacji do Allegro/PrestaShop i bez nowego
głównego bytu. Nowe tabele w niewydanym jeszcze schemacie 4.

Weryfikacja źródła online musi być raportowana oddzielnie od testów na
syntetycznych odpowiedziach. Środowisko chmurowe ma ograniczenia domen;
nie obchodzić ich, nie udawać testu rzeczywistej witryny.
