# ADR-044 — jawne usuwanie produktów z lokalnymi szkicami

2026-11-06. Właściciel zgłosił, że Usuń zaznaczone / Usuń wszystkie wyniki
nie usuwa danych. Kod blokował całą grupę, jeśli choć jeden Produkt miał
szkic; komunikat błędu był wyłącznie w etykietach strony i pasku stanu.

Domyślna ochrona ADR-035 pozostaje. Przy blokadzie aplikacja odczytuje
powiązane szkice dla pierwotnie potwierdzonej grupy Produktów i pyta osobno,
czy usunąć Produkty ORAZ podaną liczbę lokalnych szkiców. Domyślnie Nie.
Nie oznacza to zgody na automatyczne usuwanie szkiców przy zwykłym usuwaniu.
Wariant rozszerzony jest uruchamiany wyłącznie po drugim potwierdzeniu.
Nie dotyczy kont, ofert i szkiców na Allegro/PrestaShop.

Migawka ID/wersji szkiców sprzed drugiego potwierdzenia oraz Produktów
sprzed pierwszego sprawdzana pod BEGIN IMMEDIATE. Dodanie, edycja lub
usunięcie szkicu w tym czasie blokuje całość. Jedna spójna kopia przed
zapisem; usunięcie lokalnych szkiców i Produktów w jednej transakcji.
Błąd cofa oba rodzaje danych. Inne Produkty i szkice, cenniki, producenci,
Do poprawy i historia importów pozostają. Ceny/media/powiązania importu
usuwanych Produktów jak wcześniej. Schemat 9 bez migracji, bez nowej encji.

Błędy usuwania są teraz widoczne w oknie ostrzeżenia. Sukces podaje
liczbę Produktów i dodatkowo szkiców oraz ścieżkę kopii. Kontrola w tle,
GUI bez SQL. Testy: oba warianty zakresu i potwierdzenie/anulowanie,
konflikty, rollback, kopia/odtworzenie, zachowanie niepowiązanych danych.
