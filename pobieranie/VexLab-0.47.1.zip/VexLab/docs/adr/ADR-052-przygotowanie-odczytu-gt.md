# ADR-052 — port odczytu katalogu i lokalny raport środowiska GT

Status: przyjęta dla przygotowania 0.24, 2026-11-07.

Kontekst: baza GT na serwerze, klient na laptopie. Transport, licencja
Sfery i uprawnienia nie są ustalone. Katalog GT ma być tylko do odczytu.

Decyzja: wydzielić OdczytKatalogu/PrzegladajKatalog, pozostawiając lokalne
komendy i dotychczasowe API zgodne. Adapter lokalnych metadanych Windows
za osobnym portem, ręczny raport wykonywany w tle. Wyłącznie KEY_READ;
brak połączeń SQL/COM, instalacji i zmian konfiguracji. Wynik nie ustawia
statusu połączenia. Nie dodawać sekretów ani nie zgadywać schematu GT.

Konsekwencje: można zbadać środowisko bez wyboru transportu. Rejestr może
być niepełny i nie weryfikuje licencji ani łączności. Przyszły konektor musi
zaprojektować zewnętrzną tożsamość i blokadę komend zapisu dla źródła GT.
Schemat 11 i dane użytkownika pozostają bez zmian.
