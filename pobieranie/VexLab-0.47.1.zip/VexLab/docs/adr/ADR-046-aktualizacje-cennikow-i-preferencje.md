# ADR-046 — porównania wydań, preferencje i seryjne zdjęcia

2026-11-06. Zakres z poleceń właściciela w rozmowie: bazowa z wybranego
aktualnego cennika producenta, aktualizacja wydania i różnica cen, przyczyny
Do poprawy, reset kreatora, edycja szybkich akcji, zdjęcia zaznaczenia.
Uzupełnia ADR-039/043/045; nie zatwierdza integracji ani automatycznych profili.

## Decyzje

Cennik źródłowy jest niezmienny. Aktualizacja tworzy dokument z poprzedni_id;
archiwizacja starego i przejęcie jego statusu aktualnego są jedną transakcją.
Wersja, producent i aktywność są sprawdzane w bazie pod blokadą zapisu.
Słabe odniesienie do starego dokumentu dopuszcza jego jawne usunięcie;
brak poprzednika daje brak porównania. Bez kopiowania produktów i ich cen.
Nowy / Aktualny / Archiwalny rozróżniają brak wyboru od archiwizacji.
Porównanie po SKU nie przelicza walut ani VAT. Powtarzające się SKU wymagają
zgodnej ceny w źródle bazowym. Użytkownik widzi źródło bazowej w podpowiedzi.

Preferencje szybkich akcji, adres źródła zdjęć i limit są danymi użytkownika
w QSettings. Lista akcji ma stabilne identyfikatory, nie przechowuje kodu.
Niepoprawne stare ustawienia mają bezpieczne wartości domyślne.

Zdjęcia: przypadek użycia steruje portem źródła i portem sesji zapisu.
I/O wykonuje zadanie poza GUI. Jedna kopia na serię i transakcja na produkt,
kontrola wersji i brak nadpisywania galerii. Zatrzymanie między żądaniami,
20 s timeout transportu, ograniczenia danych i dekodera, bez globalnego
połączenia SQLite. Zapisane produkty pozostają po częściowym błędzie.

`urllib.parse` jest dopuszczonym czysto tekstowym narzędziem walidacji URL
w przypadkach użycia; nie wykonuje I/O. Kontrola AST dopuszcza wyłącznie ten
moduł urllib, nadal odrzuca urllib.request i klientów HTTP. Adapter dodatkowo
sprawdza DNS i przekierowania. Nie wyłączono kontraktów warstw.

## Konsekwencje

Schemat 10 (jeszcze nieopublikowany przed tym przyrostem) obejmuje wszystkie
nowe pola wraz z EAN. Nie zmieniać migracji wcześniejszych wydań. Kopie mają
koszt dyskowy; limit zdjęć nie ogranicza kopii. Nie usuwać starych kopii bez
ustalenia retencji. Shopify musi udostępniać publiczny katalog i dokładne SKU;
obsługa konkretnej witryny wymaga weryfikacji na żywo. Zakres HTTP pozostaje
odczytem; brak publikacji i zapisów do platform.
