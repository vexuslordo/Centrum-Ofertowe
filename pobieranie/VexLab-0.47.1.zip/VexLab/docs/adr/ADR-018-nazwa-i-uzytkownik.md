# ADR-018 — nazwa VexLab i nazwa użytkownika

Data: 2026-11-02. Status: wymaganie właściciela projektu przyjęte bezpośrednio
z bieżącej rozmowy.
Źródło: „Popraw, że nazwa konta to będzie nazwa użytkownika.
Program ma nazywać się VexLab”.

Nazwa programu to **VexLab**, zachowując tę pisownię. Pakiet Python i komenda
techniczna nazywają się `vexlab`. Nie zmieniamy zdalnej nazwy repozytorium.

Obszar profilu w nagłówku ma wyświetlać **nazwę użytkownika**, zamiast stałej
nazwy konta lub demonstracyjnego `VexLabs`/`vexlabs`. Nie ustala to jeszcze
mechanizmu logowania, profili, źródła nazwy użytkownika ani uprawnień.
Nie wywodzimy z tego nowej encji biznesowej. Źródło nazwy określimy przy
wdrażaniu profilu; w fundamentach nie tworzymy ekranu ani fikcyjnego użytkownika.

KontaSprzedażowe zachowują znaczenie z modelu: konto platformy/sklepu
nie jest tożsame z użytkownikiem lokalnej aplikacji.

`assets/UI_REFERENCE.png` pozostaje niezmienionym wzorcem geometrii i opcji.
Nowe wymaganie zastępuje tekst marki i obszaru użytkownika na obrazie.
Napis 5.0 nadal nie wyznacza wersji wydania; bieżący fundament ma 0.1.0.dev0.

