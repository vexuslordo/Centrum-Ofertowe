# ADR-057 — odczyty i konfiguracja operacyjnego Dashboardu

Status: wdrożone w 0.35 w granicach istniejących źródeł danych.
Źródło: prompt i referencja właściciela z 2026-11-09; przebudowa tylko obszaru
Dashboardu, bez wymiany architektury i tworzenia frameworka.

## Decyzja

Dotychczasowy Dashboard zastępuje jeden DashboardView. Wspólny KafelekKPI
rozszerzono o wariant kompaktowy. Panel korzysta z małego StanDashboardu,
portu OdczytDashboardu i serwisu Dashboard z jednym cache snapshotu/TTL 30 s.
KatalogSQLite liczy agregaty w jednej migawce SQLite. Bootstrap przekazuje
implementację portu; GUI nie wykonuje SQL i uruchamia odczyty w istniejącym
mechanizmie zadań. Nie zmienia się agregat Produktu, jego właściciel ani
transakcje zapisu, nie ma migracji i zewnętrznych efektów.

Alternatywa pełnego ładowania katalogu do modelu GUI odrzucona: koszt pamięci,
BLOB i błędne statystyki ograniczone do strony. Nie dodajemy SQLAlchemy,
PyQtGraph ani globalnego serwisu/cache: QtCharts jest dostępny w PySide6.

Układ sekcji i widoczność są technicznymi preferencjami użytkownika, zapisanymi
w tym samym magazynie co pozostałe ustawienia. To punkt rozszerzenia dla
przyszłych nazwanych profili, bez ich obecnej implementacji. Nie ma dowolnego
systemu widgetów, pluginów lub modeli kanałów w GUI.

## Dane i ograniczenia

Agregaty obejmują cały lokalny katalog. Braki EAN/producenta/opisu to wskazówki,
nie nowe niezmienniki. Alerty prowadzą do filtrów stronicowanego odczytu,
obejmujących także zaznaczenia spoza bieżącej strony. UI nie traktuje danych
szkiców zdalnych jako wszystkich aktywnych ofert. Stan połączenia pochodzi
z potwierdzonej sesji Allegro.

Brak źródła oznacza —/brak odczytu, a nie zero ani sukces. Nie generujemy
przebiegów wykresów, procentowych zmian lub rankingów bez historii.
Przyszłe źródła sprzedaży/zamówień/magazynu/AI wymagają własnych przypadków
użycia, mapowań i ograniczonych odczytów poza GUI. Zrzut referencyjny nie
zatwierdza nowych reguł magazynowych, kosztów, marży ani statusów zamówień.

## Odbiór

Agregaty i cache na bazie tymczasowej, reset nieprawidłowych preferencji,
konfigurator, alerty i globalne filtry/wybór, rozłączenie konta, puste dane,
oba motywy, DPI i szerokości 1536/900. Dokładne rezultaty i ograniczenia
zapisane w docs/PRZYROST_0_35.md.
