# ADR-054 — konfiguracja Allegro w Ustawieniach i pamięć połączenia

2026-11-08. Właściciel zlecił przeniesienie łączenia API do Ustawień oraz
zapamiętanie połączenia, zastępując ograniczenie sesji 0.25/ADR-053. Doprecyzował,
że Allegro jest wspólną przestrzenią wszystkich działań kanału, także zamówień.

Decyzja techniczna: port MagazynAllegro, adapter pliku Windows DPAPI związany
z bieżącym użytkownikiem, bez flagi LOCAL_MACHINE. Bez nowych zależności i
zmian SQLite. Alternatywy: systemowy Credential Manager ma ograniczenie
rozmiaru pojedynczego sekretu; dotychczasowa pamięć procesu nie spełnia
wymagania restartu. Zakres P-07 rozstrzygnięty tylko dla połączenia Allegro.
Nie ustanawia to trwałego modelu wielu KontSprzedazowych ani ogólnego vaulta.

Zapis: Client ID/Secret, środowisko, potwierdzone ID/login konta oraz refresh
token, zaszyfrowane przed pierwszym zapisem na dysk. Access token pozostaje
w pamięci. Atomowy replace wyłącznie szyfrogramu. Brak jawnego fallbacku;
na innych systemach dostępna sesja bez zapamiętywania. Szyfrogram nie wchodzi
do ZIP-a źródeł ani kopii SQLite. Połączenie dotyczy jednego wybranego konta.

Odtworzenie: odczyt przez port, refresh grant, zapis obróconego refresh tokenu
przed /me, potwierdzenie tego samego ID konta przed stanem Połączono. Blokada
serializuje odnowienie i usunięcie w jednej instancji procesu, aby spóźniony zapis nie odtworzył usuniętego
połączenia. Koordynacja kilku procesów pozostaje przyszłym zakresem. Po błędzie sieci zapis zachowany do ponowienia; po cofnięciu zgody
wymagane jawne zapomnienie i ponowne połączenie. Nie udawać sukcesu trwałego
zapisu po błędzie szyfrowania/dysku. Zamknięcie czyści RAM, nie szyfrogram.

UI: panel połączenia w Ustawienia → Integracje, zakładka Allegro do operacji.
Brak fałszywych przycisków obsługi niezaimplementowanych zamówień/publikacji.
Szczegóły i ograniczenia: docs/PRZYROST_0_26.md. Natywny odbiór Windows i
rzeczywistego OAuth nadal wymagany; symulacja API nie potwierdza połączenia.
