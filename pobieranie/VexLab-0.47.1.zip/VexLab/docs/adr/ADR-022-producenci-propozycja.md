# ADR-022 — rejestr producentów i przypisanie do Produktu

Data: 2026-11-02. Status: wdrożony ograniczony scenariusz, po decyzji właściciela.
Źródło: polecenie kontynuowania pracy; DOMAIN_MODEL, karty Produktu i Producenta.

Scenariusz: użytkownik dodaje Producenta w zakładce Producenci, zmienia jego
nazwę lub dezaktywuje rekord, a w formularzu Produktu wybiera Producenta.
Nazwa producenta jest widoczna w katalogu produktów po ponownym uruchomieniu.
Nie tworzymy na tej podstawie Dostawcy lub PodmiotuGPSR.

Minimalny rejestr: stabilne ID, wymagana nazwa, aktywność i wersja edycji.
Nazwa nie jest globalnym identyfikatorem organizacji; nie scalamy rekordów
automatycznie i nie zakładamy jej unikalności. Powtórzone nazwy w wyborze
muszą być rozróżnialne przez identyfikator. Nie dodajemy NIP ani adresów
pod pretekstem tego scenariusza. Właścicielem danych jest lokalny Katalog.

Decyzja modelowa do rozstrzygnięcia:

| Wariant | Konsekwencje |
|---|---|
| Zero lub jeden producent na Produkt (rekomendacja) | Pozwala zachować istniejące szkice bez zgadywania producenta; można przypisać i zmienić jeden rekord |
| Dokładnie jeden producent | Dodawanie wymaga wcześniejszego utworzenia Producenta; stare Produkty wymagają uzupełnienia, bez wymyślonego rekordu domyślnego |
| Wielu producentów na Produkt | Wymaga osobnej listy przypisań i doprecyzowania znaczenia każdej relacji |

Rekomendowana dezaktywacja: rekord pozostaje w bazie i przy istniejących
Produktach, ale nie jest dostępny do nowych przypisań. Nie implementujemy
usuwania ani scalania. Zmiana nazwy nie zmienia ID i jest widoczna w odczycie
Produktów. Edycja sprawdza wersję; konflikt nie nadpisuje nowszych danych.

Techniczne wdrożenie po decyzji: kolejna migracja schematu zamiast edycji
opublikowanego schematu 1; kopia przed migracją, test zachowania danych 0.2,
rollback w przypadku błędu i brak automatycznych rekordów biznesowych.
Przypadki użycia udostępniają DTO, SQLite realizuje porty, GUI nie wykonuje SQL.

Przykłady wyłącznie testowe: „Producent testowy A”, dwa rekordy o tej samej
nazwie i różnych ID, Produkt bez przypisania oraz Produkt przypisany do
później dezaktywowanego Producenta. Nie są seedami nowej instalacji.

Odbiór: dodanie/edycja/dezaktywacja producenta, wybór według uzgodnionej
liczności, nazwa w tabeli, trwałość po restarcie, konflikt wersji, migracja
starej bazy na syntetycznej kopii, brak częściowego zapisu i brak utraty danych.

## Rozstrzygnięcie i wdrożenie 0.3

Właściciel w bieżącej rozmowie wybrał **zero lub jednego producenta**.
Istniejący Produkt może pozostać bez przypisania. Pozostała część konkretnej
propozycji została zrealizowana w tym ograniczonym scenariuszu, bez zmiany
znaczenia Dostawcy ani GPSR. Nie zatwierdza to pól, ról i relacji pozostałego modelu.

Edycja Producenta zachowuje ID; nazwa nie ma ograniczenia UNIQUE i nie służy
scalaniu. Nieaktywny rekord pozostaje widoczny przy wcześniejszym Produkcie;
można edytować pozostałe dane takiego Produktu lub odpiąć producenta.
Nowe przypisanie do nieaktywnego jest odrzucane również przez adapter pod
blokadą zapisu, gdy producent został dezaktywowany po otwarciu formularza.

Nowy schemat 2 dodaje tabelę producentów i opcjonalny klucz obcy w Produktach.
Tekst i suma wydanego schematu 1 pozostają niezmienione. Przed migracją
istniejącego schematu 1 powstaje spójna kopia SQLite w `kopie_migracji`.
Blokada zapisu obejmuje wykonanie kopii i migrację; inne zapisy czekają.
Kopia powstaje przez drugie połączenie odczytowe, przed modyfikacją schematu.
Brak możliwości utworzenia kopii blokuje migrację. DDL, zapis rejestru i
zmiana wersji są w jednej transakcji; błąd pozostawia poprzedni schemat.
Nowa pusta instalacja nie potrzebuje kopii pustego schematu pośredniego.
Nie nadpisujemy istniejących plików kopii i nie usuwamy bazy po błędzie.

Dodano ekran Producenci, formularz nazwy/aktywności, filtrowanie nazw i statusu,
wybór w formularzu Produktu oraz rzeczywistą nazwę w tabeli. Dwa rekordy o
tej samej nazwie są rozróżniane przez ID. I/O jest poza wątkiem GUI, a błędy
zachowują treść formularza. Nie ma usuwania ani automatycznego scalania.

Dowody: [raport 0.3](../RAPORT_PRZYROST_0_3.md) i testy migracji na stałym
SQL schematu 1 wyodrębnionym z rzeczywiście przekazanego ZIP VexLab 0.2.
