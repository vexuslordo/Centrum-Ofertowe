# ADR-042 — zdjęcia w edytorze szkicu i podgląd układu oferty

2026-11-05. WYMAGANIE właściciela: zdjęcia w edytorze i cała oferta
w widoku wizualnym. Zastępuje ograniczenie ADR-040 o braku odczytu obrazów.

Źródłami są adresy użytkownika zapisane w galerii i sekcjach szkicu.
Osobny port odczytu pojedynczego obrazu, adapter wykorzystuje istniejący
transport publicznego HTTPS i dekoder JPEG/PNG/WebP. Odrzuca lokalne adresy,
dane logowania, prywatne IP/DNS, niebezpieczne przekierowania, HTML/SVG;
limity 8 MiB i 16 MP, timeout 20 s. Nic nie jest wykonywane z HTML.
GUI nie wykonuje HTTP ani SQL. Jeden odczyt w tle naraz, deduplikacja,
cache jednego edytora do 32 obrazów i 32 MiB, kolejka do 100 adresów.
Błąd zdjęcia pokazuje komunikat i nie blokuje zapisu tekstu. Zamknięcie
edytora unieważnia odbiorców; spóźniona odpowiedź nie modyfikuje szkicu.

Podgląd pokazuje tytuł, zdjęcie galerii i sekcje w zapisanej kolejności,
z zachowaniem kolumn tekst/obraz. Jest przybliżeniem układu, nie oficjalną
walidacją lub gwarancją identycznego renderowania Allegro. Brak danych
ceny, dostawy lub konta nie jest uzupełniany fikcyjnymi wartościami.
Otwarcie i pobranie zdjęć nie zmienia opisu, Produktu ani bazy. Edycja
tekstu/sekcji zachowuje dotychczasowy proces atomowego zapisu szkicu.
Bez migracji poza niezależną biblioteką cenników. Integracja API nadal
niewdrożona. Testy: obraz, cache, błąd, zamknięcie, układ i brak mutacji.
