# ADR-041 — biblioteka zapisanych cenników

Data: 2026-11-05. Status: WYMAGANIE właściciela: lista cenników z rokiem,
pozycje dodawane do katalogu z menu kontekstowego, możliwość usuwania.
Po przedstawieniu kierunku właściciel polecił „działaj”.

Cennik jest trwałym dokumentem źródłowym importu, a nie drugim Produktem
ani siedemnastą główną encją. Nazwa, rok, opcjonalne wydanie/data i producent
są danymi użytkownika. Data wczytania jest metadanymi technicznymi.
Każdy zapis to oddzielny dokument, bez automatycznego nadpisywania
wcześniejszych wydań. Przechowujemy zmapowane dane pozycji, nie oryginalny
plik i nie wykonujemy jego formuł. Mapa i waluty jak w istniejącym importerze.

Zapis cennika nie tworzy Produktów. Po otwarciu listy wybrane pozycje
mogą zostać dodane do katalogu: znane SKU pomijane, nowe poprawne tworzone,
wybrane błędne odłożone do Do poprawy. Niezaznaczone pozostają w cenniku.
Dodanie ma kontrolę istnienia/wersji dokumentu w tej samej transakcji.
Nie nadpisujemy istniejących cen ani Produktów; jawne uzupełnianie braków
cen zachowuje dotychczasowy proces z podglądem. Rok nie wybiera automatycznie
ceny aktualnej i nie jest datą obserwacji kanału sprzedaży.

Usuwanie pojedynczych lub kilku cenników po potwierdzeniu i kopii bazy.
Usuwamy tylko dokumenty źródłowe, zachowując Produkty, ich ceny, szkice,
historię importów, pozycje Do poprawy i pliki na dysku. Współbieżny brak
lub zmiana dokumentu blokują cały zatwierdzony zakres, bez częściowego zapisu.

Schemat 8: tabela dokumentów źródłowych cenników z metadanymi i zapisanym
JSON-em pozycji, bez relacji usuwania do Produktów. Migracja 7→8 z kopią,
niezmienione definicje migracji 1–7, pusta nowa instalacja. Starsza wersja
wymaga odtworzenia kopii sprzed migracji. Testy: restart, źródło niezależne
od pliku, wybór/filtrowanie, znane SKU, błędy, rollback, kopia/odtworzenie,
usuwanie bez zmiany katalogu, klawiatura i oba motywy.
