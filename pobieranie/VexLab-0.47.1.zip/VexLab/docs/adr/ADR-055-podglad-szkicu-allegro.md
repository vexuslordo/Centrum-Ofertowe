# ADR-055 — odczyt szczegółów szkicu Allegro

Status: zakres istniejącego wymagania właściciela, kontynuacja roadmapy 2026-11-08.

Scenariusz: po odczycie listy użytkownik wskazuje jeden szkic i otwiera podgląd
rzeczywistej treści, zdjęć oraz źródłowej ceny. Granica: odczyt integracji,
bez zapisu modelu Produktu/Oferty, migracji i jakiegokolwiek polecenia publikacji.

Przypadek użycia sprawdza termin sesji i identyfikator przed API oraz termin
po odpowiedzi. Konektor GET /sale/product-offers/{id} mapuje tylko wymagane pola
na techniczny DTO; identyfikator musi odpowiadać żądaniu, status INACTIVE.
Niespójna odpowiedź kończy się błędem. Nie przechowujemy pełnej odpowiedzi API.
Wspólny ElementPodgladu opisuje wyłącznie prezentację, bez nowej relacji domenowej.
GUI używa istniejącego bezpiecznego renderera i portu podglądu obrazów; pobieranie
w tle, bez autoryzacji Allegro przekazywanej do adresów zdjęć. Generacja sesji
odrzuca spóźnione wyniki; rozłączenie zamyka podgląd i jego kolejkę zdjęć.

Alternatywa: sam link do strony Allegro nie realizuje podglądu w aplikacji.
Edycja i zapis nadal kolejny etap, z osobnym rozstrzygnięciem konfliktów.
Odbiór rzeczywistego API na koncie właściciela pozostaje otwarty.
