# VexLab 0.19 — mniej ustawiania cenników

2026-11-06. Wersja developerska 0.19.0.dev0. Schemat 10 bez migracji.

## Jak korzystać

1. Cenniki → Dodaj cennik → Wybierz plik.
2. Dla nowego układu program proponuje jednoznaczne kolumny nazwy, SKU,
   EAN i opisu. Sprawdź producenta i Ustawienia importu; cenę, walutę oraz
   netto/brutto wybierasz samodzielnie. Wyświetl podgląd.
3. Profil → Zapamiętaj układ… → nadaj własną nazwę. To zapis ustawienia
   użytkownika, a nie cennika lub produktów.
4. Następny plik tego układu otworzy podgląd automatycznie. Producent i
   podsumowanie waluty/netto-brutto są widoczne. Techniczne kolumny i surowa
   próbka chowają się w Ustawieniach importu; można je rozwinąć i zmienić.
5. Podaj nazwę/rok i zapisz cennik osobno, jak wcześniej. Kreator się czyści,
   ale zapamiętany profil pozostaje na kolejne importy.

Jeden producent może mieć kilka układów. Kilka zgodnych profili lub arkuszy
wymaga wyboru na liście. Zmiana nazwy pliku lub przesunięcie nagłówka nie
przeszkadza; inne nagłówki/kolejność nie uruchamiają starego mapowania.
Profil → Usuń profil… usuwa wybrany profil po potwierdzeniu, bez cenników
lub produktów. Aby zmienić profil, skoryguj mapowanie, obejrzyj podgląd,
zapamiętaj nowy wariant i ewentualnie usuń wcześniejszy.

## Dane i ograniczenia

Profile JSON są wyłącznie w `profile_cennikow` w katalogu danych użytkownika,
obok preferencji. Nie trzeba ich dołączać do cennika. Nie trafiają do kodu
ani produkcyjnych seedów. Nowa instalacja nadal nie ma danych biznesowych.
Awaria lub uszkodzony profil nie usuwa ustawień i pozostawia ręczny import.

Rozpoznanie oznacza zgodne nagłówki, nie gwarantuje zgodności treści,
producenta i waluty. Sprawdź podgląd przed zapisem. Propozycje dla nowych
układów obejmują ograniczoną listę ogólnych nazw w pierwszych 30 wierszach;
nie rozpoznają dowolnego dokumentu ani PDF. Obsługa XLSX/CSV pozostaje.
Nie ma płatnego AI. Zgoda na zapisane wyniki formuł musi być ponawiana
przy każdym pliku. Aktualizacja wydania nie zmienia producenta ze starego
cennika na producenta pasującego profilu.

## Przegląd jakości

Wydzielono panel profili, adapter JSON i przypadek użycia do osobnych
modułów. Walidacja mapowania jest wspólna z dotychczasowym importerem.
Przegląd objął brak niejawnego zapisu katalogu, zapis atomowy, uszkodzony
JSON, symlinki, limity, błędy zapisu i ochronę producenta aktualizowanego
cennika. Schemat i migracje porównano z opublikowaną paczką 0.18 — bez zmian.
Dług techniczny z audytu 0.18 nadal jest otwarty; ten przyrost go nie zamyka.
Odbiór Windows i audyt UX 1.0 pozostają osobno. Integracje nie są wdrożone.

## Wyniki weryfikacji

- Pełny `scripts/check.py`: 460 testów zaliczonych, ruff/format, mypy
  (65 modułów), siedem kontraktów importów, Bandit i diagnostyka poprawne.
- Po dopracowaniu panelu i zwinięciu próbki: ponowne 29 testów GUI profili,
  importera i Cenników przy skali 150% — powodzenie. Kontrole statyczne
  powtórzone na końcowym kodzie. Żadnych globalnych wyłączeń reguł.
- 22 testy nowych reguł i magazynu profili: rozpoznanie/restart, przesunięty
  nagłówek, kilka arkuszy/producentów, zmiana struktury, awaria zapisu,
  uszkodzony JSON, błędne typy/indeksy, duplikaty kluczy, symlink i rozmiar.
- Audyt pełnych zależności przechodnich runtime/dev: brak znanych podatności
  w sprawdzonych wersjach. Nie dodano nowych bibliotek.
- Zrzuty jasne/ciemne i 900×800 obejrzane; składane kontrolki mieszczą się
  w wąskim oknie. Testy są na Linux/offscreen, bez odbioru natywnego Windows.
- Schemat i migracje porównane z 0.18 (AST) — identyczne. Budowa wheel/sdist
  offline — powodzenie. Paczka źródeł zawiera kod, testy, instrukcję i ADR.
