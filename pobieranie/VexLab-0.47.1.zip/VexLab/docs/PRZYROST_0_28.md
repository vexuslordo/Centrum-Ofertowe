# VexLab 0.28 — uporządkowane Ustawienia

2026-11-08. Właściciel zaakceptował propozycję czterech zakładek odpowiedzią
„dawaj”. Bez zmian schematu 11, zależności, danych, połączeń lub uprawnień.

## Układ

- Ogólne: motyw, edycja wyboru/kolejności szybkich akcji oraz dyskretna
  informacja o użytkowniku systemu. Usunięto dużą osobną sekcję Profil.
- Integracje: lista usług ze stanem po lewej, konfiguracja po prawej.
  Allegro, PrestaShop i Subiekt GT. PrestaShop ma wyłącznie informację
  o przygotowaniu konektora; GT zachowuje ręczny raport środowiska, bez
  połączenia z bazą. Żaden taki odczyt nie oznacza Połączono.
- Dane i kopie: rzeczywista lokalizacja danych przekazana z bootstrapu oraz
  dotychczasowy proces tworzenia kopii SQLite. Lokalizacja tylko do odczytu;
  kopia nadal nie zawiera zapamiętanego połączenia. Przywracanie i zarządzanie
  miejscem pozostają przyszłe, bez pozornie działających przycisków.
- O programie: wersja i ręczna diagnostyka istniejącym przypadkiem użycia,
  raport do skopiowania. Wersje Python/PySide6/SQLite, czas i ID korelacji;
  bez kont, tokenów i danych klientów. Nie testuje integracji sprzedażowych.

## Allegro

Na początku stan konta i główna akcja Połącz konto. Client ID, Client Secret,
środowisko oraz wskazówki techniczne schowane w rozwijanej sekcji Dane
aplikacji. Próba połączenia bez danych odsłania sekcję i ustawia fokus
na brakującym polu, bez żądania sieciowego. Po potwierdzeniu konta sekcja się
zwija. Pokazywane są tylko akcje odpowiednie dla bieżącego stanu: zgoda,
anulowanie, wznowienie lub rozłączenie. Maskowanie i czyszczenie sekretu,
DPAPI, rotacja tokenów i zachowanie po restarcie pozostają dotychczasowe.

Skrót Ustawienia połączenia z Allegro wybiera główną kategorię Integracje
oraz właściwą usługę. Zakładka Allegro nadal jest obszarem działań kanału;
zaplanowane zamówienia, oferty i edycja szkiców pozostają w roadmapie.
Przyszłe konfiguracje usług mają trafiać do wspólnej listy.

Nowe komponenty GUI: SekcjaRozwijana, IntegracjeUstawien i InformacjeOProgramie.
Porty biznesowe nie zostały zmienione. Diagnostyka i raporty działają w tle.
Puste, błędne i nieaktualne raporty nie udają sukcesu; ponowna próba czyści
poprzedni wynik. Przewijanie poszczególnych paneli zachowane w małym oknie.

## Weryfikacja

Pełna kontrola `scripts/check.py`: 619 testów zaliczonych, jeden natywny
DPAPI pominięty na Linux. Ruff/format, mypy 85 modułów, siedem kontraktów
importów, Bandit i diagnostyka poprawne. Mypy win32 poprawne. Nowe scenariusze
sprawdzają cztery kategorie, skrót do konkretnej integracji, klawiaturę listy
i sekcji rozwijanej, raport/czyszczenie po błędzie oraz stany formularza konta.
Przy skalowaniu 150% zaliczono 16 testów paneli Ustawień i Allegro.

Obejrzano kategorie, odrębne usługi, dane aplikacji zwinięte i rozwinięte,
wersję jasną/ciemną 1536×1024 oraz małe okno 900×700. Zrzuty
`docs/screenshots/vexlab-settings-028-*.png` korzystają z tymczasowej pustej
bazy i pustego magazynu wizualnego. Raport techniczny zawiera rzeczywiste
wersje środowiska testowego, nie potwierdzenie połączenia z usługami.
Audyt zależności runtime/dev bez znanych podatności w chwili sprawdzenia;
wheel/sdist zbudowane offline. Natywny odbiór Windows pozostaje osobno.
