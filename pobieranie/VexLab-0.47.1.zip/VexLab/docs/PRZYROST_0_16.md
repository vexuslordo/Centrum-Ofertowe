# VexLab 0.16 — biblioteka cenników i zdjęcia w szkicu

2026-11-05. Polecenia właściciela: lista cenników z rokiem, wybieranie
produktów z menu kontekstowego i usuwanie; usunięcie mylącego przycisku
importu z Produktów; zdjęcia i widok całej oferty w edytorze szkicu.

## Obsługa cenników

1. Cenniki → Dodaj cennik → wskaż XLSX lub CSV.
2. Wybierz arkusz, nagłówki, kolumny i opcjonalnego producenta. Dla ceny
   podaj walutę i netto/brutto; zapisane wyniki formuł wymagają świadomej zgody.
3. Kliknij Sprawdź i pokaż podgląd. Podaj nazwę, rok i opcjonalne wydanie/datę, kliknij Zapisz cennik.
4. Lista pokazuje nazwę, producenta, rok, wydanie, liczbę pozycji, czas
   wczytania UTC i plik źródłowy. Filtr obejmuje nazwę/producenta/rok/wydanie.
5. Dwuklik otwiera pozycje z SKU, ceną źródłową i stanem W katalogu/Gotowy/błąd.
   Wyszukaj, zaznacz pozycje (Ctrl/Shift, Ctrl+A) i wybierz PPM → Dodaj do katalogu.
   Akcja jest także przyciskiem i dostępna przez Shift+F10 lub klawisz Menu.
6. Potwierdź zakres. Nowe poprawne SKU tworzą Produkty, znane zostają
   pominięte bez nadpisywania; wybrane błędne trafiają do Do poprawy.
   Niewybrane pozostają tylko w cenniku. Powstaje kopia bazy.
7. Na liście cenników zaznacz jeden lub kilka → Usuń zaznaczone.
   Potwierdzenie domyślnie Nie, jedna spójna kopia i atomowe usuwanie.
   Produkty, ich ceny, szkice, historia, Do poprawy i oryginalne pliki pozostają.

Zapisane są zmapowane dane źródłowe, nie oryginalny plik. Można go przenieść
lub usunąć bez utraty zapisanych pozycji. Kolejne wydania są osobnymi
cennikami; rok nie jest zgadywany i nie ustala automatycznie ceny aktywnej.
Uzupełnij brakujące ceny zachowuje dotychczasowy jawny podgląd i zapis.
Do poprawy i Import bezpośredni pozostają dostępne w obszarze cenników.

Pasek Produktów: Dodaj produkt, Odśwież, Więcej akcji. Usunięto przycisk
oraz pozycję menu importu przekierowującą do innej zakładki.

## Edytor szkicu

Szkice → wybierz szkic → Edytuj tytuł i opis. Obraz wybranej sekcji
jest widoczny obok tekstu. Zmiana adresu pobiera nowy podgląd po zakończeniu
wpisywania. Zakładka Cała oferta ze zdjęciami pokazuje tytuł, obraz główny,
miniatury galerii (pierwsze 32) i wszystkie sekcje w układzie kolumn.
Kliknięcie miniatury wybiera obraz główny. Edycja sekcji i przeciąganie
zachowują dotychczasowe działanie. Sam podgląd nie przepisuje danych szkicu.

Odczyt HTTPS w tle, jeden naraz; błędy widoczne zamiast zdjęcia. Cache
jednego edytora ograniczony do 32 obrazów / 32 MiB; kolejka do 100 adresów.
Tylko publiczne HTTPS, timeout, limity rozmiaru/pikseli, normalizowane
JPEG/PNG/WebP; HTML/SVG i zasoby lokalne nie są wykonywane ani odczytywane.
Zamknięcie dialogu zatrzymuje kolejkę; aktywny odczyt może dokończyć się
w tle, ale nie zmieni zamkniętego edytora ani bazy.

To przybliżenie wyglądu opisu, nie oficjalny renderer Allegro ani dowód
spełnienia wymagań publikacji. Wysyłka do Allegro nadal niewdrożona.
Zdjęcia wymagają sieci i dostępnego źródła na komputerze użytkownika.
Testy obrazów i zrzuty używają izolowanych danych syntetycznych; odbiór
na Windows oraz rzeczywistym CDN producenta pozostają do wykonania.

## Dane i odtworzenie

Schemat 8, migracja 7→8 z kopią w kopie_migracji. Dokładne definicje
schematu 1 i migracji 2–7 porównano z paczką 0.15.1 — niezmienione.
Nowa instalacja bez rekordów biznesowych. Nazwy, producenci, rok, pliki,
mapowanie i adresy zdjęć są danymi użytkownika; brak seedów producentów.
Cennik jest dokumentem importu, nie nowym konkurencyjnym Produktem.
Warstwy zachowane, GUI bez SQL/HTTP; odczyt i zapis przez porty.

Przed powrotem do starszej wersji zamknij program, zachowaj obecną bazę,
przywróć kopię sprzed migracji 8 i uruchom zgodną starszą wersję. Zmiany
wykonane po kopii nie będą w niej obecne. Nie otwieraj schematu 8 przez
starszą wersję. Kopie operacji cenników są w kopie_cennikow.

## Weryfikacja

Pełna kontrola lokalna scripts/check.py: lint, format, mypy strict,
siedem kontraktów warstw, Bandit, testy i diagnostyka. Testy obejmują
zapis/restart, wybrane SKU, zachowanie cen i dopasowań, duplikaty,
usuwanie z kopią, konflikty, błędy zapisu i migracji, rollback,
odtworzenie, oba motywy, listę 3000 pozycji i menu z klawiatury,
zdjęcia/cache, błąd i zamknięcie podczas pobierania.

Audyt pełnych zależności runtime i dev z uv.lock: brak znanych podatności
w dniu sprawdzenia. Budowanie wheel/sdist oraz izolowane zrzuty obu motywów.
To nie zastępuje odbioru Windows i zaplanowanego audytu technicznego/UX 1.0.
