# VexLab 0.35 — nowy Dashboard

Polecenie i nowa referencja właściciela, 2026-11-09. Zmienia się główny obszar
Dashboardu. Sidebar, topbar, globalne wyszukiwanie, logo VEX i działające moduły
pozostają zachowane. Nowa referencja zastępuje wcześniejszy układ czterech KPI
oraz tabeli ostatnich produktów na Dashboardzie.

## Układ i działania

Siedem kart: Produkty, Aktywne Allegro, Produkty PrestaShop, Zamówienia, Obrót,
Marża, Błędy. Poniżej sprzedaż z liniowym wykresem QtCharts i miejscem na udział
kanałów, statusy pięciu integracji, alerty, top produktów, ostatnie zamówienia,
kolejka/status, magazyn, aktywność, AI Center i kolorowe szybkie akcje.

Działają agregaty całego lokalnego katalogu: liczba produktów, braki zdjęć,
EAN, producenta i opisu oraz liczba pozycji Do poprawy. Kliknięcie alertu
ustawia filtr całego katalogu lub otwiera istniejącą listę korekt importu.
Brak EAN lub producenta jest poprawny w modelu; alert jest wskazówką jakości,
nie nowym warunkiem zapisu. Brak opisu oznacza pusty tekst po usunięciu spacji.

Allegro pokazuje wyłącznie potwierdzony stan istniejącej sesji. Zapamiętane
poświadczenia same nie oznaczają połączenia. Dashboard nie traktuje liczby
szkiców INACTIVE jako liczby aktywnych ofert.

Dostosuj Dashboard (koło zębate w nagłówku obszaru) pozwala ukrywać sekcje
oraz zmieniać kolejność przeciąganiem. Zmiany zapisują się automatycznie
w istniejących preferencjach, błędy zapisu pozostają widoczne. Profile
Sprzedawca/Manager/Magazyn/AI/Własny są przyszłym rozszerzeniem zapisanego
układu, bez implementowania systemu profili. Dotychczasowy wybór szybkich
skrótów jest zachowany pod „Moje skróty” i „Edytuj skróty”.

## Granice wdrożenia

Nie ma jeszcze wspólnego odczytu zamówień, sprzedaży, kosztów/marży,
magazynu, historii synchronizacji, wyników AI ani PrestaShop. Ich sekcje
pokazują brak odczytu / —. Nie ma fikcyjnych wykresów, procentowych zmian,
rankingów, klientów, statusów sukcesu ani danych demonstracyjnych. Linie,
udział kanałów i sparklines wymagają rzeczywistych danych historycznych;
bez nich wykres pozostaje pusty, pierścień neutralny, zmiana „Brak historii”.
Nie jest to ukończenie integracji i funkcji biznesowych z całego promptu.

Działające szybkie akcje prowadzą do obecnych formularzy/modułów. „Nowa oferta
Allegro” otwiera istniejący proces paczek ofert. Import obsługuje CSV/XLSX,
nie XML. Niewdrożone synchronizacje, raporty, AI i aktualizacje cen są
wyłączone z objaśnieniem. Nie wykonano żadnego zapisu w Allegro.

## Architektura, odczyty i cache

StanDashboardu jest małym modelem odczytu przypadków użycia, nie nowym modelem
Produktów ani kanałów. KatalogSQLite implementuje port agregatów w jednej
transakcji. Nie ładuje zdjęć BLOB, list produktów, ofert ani zamówień.
Dashboard ma jeden snapshot w pamięci, TTL 30 s, blokadę współbieżnego
odczytu; GUI uruchamia odczyt w istniejącej puli zadań. Zmiana liczby produktów
wymusza odświeżenie. Zmiany jakości mogą być widoczne po maksymalnie 30 s.
Cache nie jest zapisywany na dysku i nie zawiera danych konta/tokenów.

Brak migracji, zmiany schematu 11 i nowych pakietów. QtCharts pochodzi
z istniejącego PySide6. Rzeczywisty stos używa sqlite3; nie wprowadzono
SQLAlchemy pod wpływem błędnego założenia w dostarczonym prompcie.
Przyszłe źródła mogą dostarczać ograniczone modele odczytu; nie powstał
framework dashboardów ani równoległy stary widok.

## Weryfikacja

Testy obejmują agregaty i filtry poza pierwszą stroną, cache i wymuszenie,
trwałość/reset uszkodzonych preferencji, konfigurator, puste wykresy,
rzeczywiste wartości, rozłączenie konta i responsywność w obu motywach.
Zrzuty 1536×1024 i 900×700 zapisano w docs/screenshots/vexlab-dashboard-035-*.
Pełne wyniki kontroli i pomiar agregatów uzupełniane po zakończeniu sprawdzeń.
Nie testowano obciążenia 50 tys. ofert / 20 tys. zamówień, ponieważ ich
wspólne źródła nie istnieją. Test lokalnych agregatów nie jest takim dowodem.

Wyniki kontroli: pełna regresja 670 testów zaliczonych, 1 pominięty (natywne
DPAPI wymaga Windows). Po końcowych zmianach dodatkowo 18 testów panelu,
kafelków, agregatów i filtrów oraz 2 testy Dashboardu w głównym oknie —
zaliczone. Mypy dla Windows: 94 moduły bez błędów; ruff, formatowanie,
Bandit i 7 kontraktów importów poprawne. Sprawdzenie przy skalowaniu 150%:
9 testów zaliczonych.

Pomiar na izolowanej bazie 100 000 produktów: mediana pięciu odczytów
agregatów 38,56 ms, maksymalnie 83,59 ms. Odczyt cache poniżej 0,001 ms
(1000 wywołań). To pomiar tego środowiska, bez danych użytkownika i bez
symulowania nieistniejących źródeł ofert/zamówień. Nie jest gwarancją czasu
na konkretnym laptopie ani testem obciążenia rzeczywistych API.
