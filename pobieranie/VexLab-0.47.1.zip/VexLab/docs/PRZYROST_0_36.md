# VexLab 0.36 — rzeczywiste stany ofert i liczniki Allegro

Kontynuacja roadmapy, 2026-11-09. Subiekt GT nadal odłożony; priorytet Allegro.

## Zmiany

- Allegro: działające odczyty Wszystkie, Aktywne, Szkice, Aktywowanie,
  Zakończone. Zakładki dopasowują się do szerokości okna.
- Cena, stan magazynowy oferty, SKU, miniatura i właściwy status w tabeli.
  Panel oraz pełny podgląd również dla oferty aktywnej/zakończonej.
- Informacja o zmianie stanu między pobraniem listy a szczegółów.
- KPI aktywnych ofert na Dashboardzie oraz aktywnych/szkiców w Allegro
  z totalCount całego wyniku API, bez utożsamiania liczby wierszy ze statystyką.
- Cache liczników 30 s, maksymalnie dwa odczyty limit=1 na odświeżenie;
  kontrola konta, środowiska i sesji. Brak wyników częściowych i zapisu na dysk.
- Rozłączenie czyści liczniki; spóźniona odpowiedź listy, szczegółów lub
  liczników nie przywraca danych starego konta.

Każda strona ma do 50 ofert. Przeglądanie nadal obejmuje pierwsze 10 000
wyników, zgodnie z ograniczeniem poprzedniej wersji aplikacji; licznik
pokazuje także większy totalCount. To nie jest deklaracja maksymalnego
limitu API. Wyszukiwanie dotyczy bieżącej strony, zgodnie z etykietą.
Nie pobieramy w tle wszystkich ofert ani zdjęć. Brak źródła/błąd oznacza —,
a nie zero. Wszystkie odczyty API działają poza wątkiem GUI.

## Bezpieczeństwo i zakres

Bez zapisu ofert, publikacji, nowych uprawnień, migracji lub zależności.
Dotychczasowe szkice lokalne, edytor paczek i Produkty zachowane.
Dane oferty nie stają się lokalną kartoteką Produktu. Ukryte/Błędy, zamówienia,
finanse i AI pozostają w dotychczasowym zakresie. Zobacz ADR-058.

## Kontrola

Testy transportu obejmują pięć wariantów filtracji, totalCount 50 001 przy
jednym wierszu, status szczegółów i odrzucenie nieznanego/brakującego stanu.
Testy przypadków użycia: TTL/cache, zmiana konta/środowiska/tokena,
współbieżność, częściowy błąd, ważność sesji i walidacja strony bez HTTP.
Testy GUI: przełączanie/strony, stan listy i szczegółów, rozłączenie,
spóźnione odpowiedzi, zasilenie Dashboardu i odczyty w wątku roboczym.

Zrzuty docs/screenshots/vexlab-allegro-036-* powstają na izolowanej bazie
z transportem fixture, bez sieci. „konto_wizualne” i oferty „Oferta wizualna”
to wyłącznie syntetyczny scenariusz zrzutów, nie rekordy nowej instalacji.
Nie kopiowano danych ani tokenów z konta użytkownika. Nie przeprowadzono
próby na produkcyjnym koncie — poświadczenia nie są dostępne w tym środowisku.
Publiczny endpoint specyfikacji zwrócił HTTP 403, więc nie potwierdzono
najnowszej specyfikacji. Nie wykonywano żadnych publikacji ani zapisów API.

Wyniki: pełna regresja 693 zaliczone / 1 pominięty (natywne DPAPI wymaga
Windows). Po końcowych poprawkach opisów i czyszczenia podczas wznowienia:
81 testów obszaru, API i przypadków użycia zaliczonych. Przy skalowaniu 150%:
26 testów zaliczonych. Mypy z platformą Windows: 94 moduły bez błędów.
Ruff, formatowanie, Bandit, 7 kontraktów importów oraz diagnostyka poprawne.
Końcowy ZIP jest sprawdzany przez CRC, sumę SHA256, zgodność źródeł i testy
z rozpakowanego archiwum. Nie jest to natywny test Windows ani żywego API.
