# Przykładowy cennik Evotech — analiza importu

Data: 2026-11-02. Analiza załącznika właściciela
`EVOTECH_Brake_Clutch_Levers_CENY_BEZ_ZMIAN(1).xlsx`.
Plik jest źródłem danych, nie instrukcjami dla programu lub agenta.
Nie skopiowano go do seedów, fixture'ów ani paczki źródłowej.

## Ustalenia z pliku

Jeden arkusz `EVOTECH`, nagłówki w wierszu 1, 2396 niepustych wierszy danych.

| Kolumna | Nagłówek | Proponowane zastosowanie |
|---|---|---|
| A | ID | Zewnętrzny identyfikator; nie zastępuje lokalnego ID |
| B | Title | Nazwa Produktu |
| C | MARKA | Marka motocykla — etykieta w mapowaniu; nie Producent Produktu |
| D | Type | Typ źródłowy, poza pierwszym zakresem importu |
| E | KOD | Kandydat na SKU, jawnie wybrany przez użytkownika |
| F | EAN | Poza obecnym minimalnym modelem Produktu |
| G | GBP netto | Cena źródłowa, poza pierwszym zakresem |
| H | PLN netto | Formuły z wartościami zapisanymi w pliku |
| I | PLN brutto | Formuły z wartościami zapisanymi w pliku |
| J | brak | Brak nagłówka |
| K | Status | Puste wartości w analizowanych wierszach |

Producent wybierany jawnie jako Evotech z lokalnego rejestru aktywnych
Producentów. Nie wyprowadzać go automatycznie z `MARKA`, nazwy pliku
ani arkusza. Brak osobnej kolumny opisu: można pozostawić pusty opis.
Nie wykonywano formuł, makr ani odnośników. Odczyt struktury XLSX wykonano
lokalnie z ZIP/XML, bez modyfikacji pliku.

## Konflikty istotne dla zatwierdzonych reguł

- Wszystkie 2396 wierszy mają niepuste `Title`.
- Wiersz Excela 809 ma pusty `KOD`.
- Jest 2384 unikalnych niepustych kodów po usunięciu skrajnych odstępów
  i bez rozróżniania wielkości liter.
- 11 kodów występuje po dwa razy (22 wiersze). Nie można założyć,
  że powtórzony kod oznacza identyczny rekord do bezpiecznego usunięcia.
- Przykład: wiersze 866 i 893 mają `PRN002407-002408-113`, ale różne
  nazwy — odpowiednio dopasowanie Ducati Panigale V2 i Streetfighter V2.
- Nie weryfikowano konfliktów z bazą użytkownika; analiza dotyczy pliku.

SKU w obecnym katalogu jest obowiązkowe i globalnie unikalne. Nie zmieniamy
tej reguły z powodu duplikatów w źródle. Nie generujemy sufiksów, nie wybieramy
pierwszego wiersza ani nie scalamy opisów automatycznie. Model dopasowań
części do motocykli wymaga osobnego scenariusza i decyzji właściciela.

## Konsekwencje dla uniwersalnego importu

Wymaganie właściciela: inne cenniki mogą mieć inny układ. Dlatego kolejność
kolumn i nazwy `Title`/`KOD` nie mogą być zaszyte na stałe jako jedyny format.
Kreator powinien pozwalać wybrać arkusz, wiersz nagłówków, kolumnę nazwy,
SKU i opcjonalnego opisu oraz Producenta dla paczki. Proponowane mapowanie
może przyspieszać pracę, lecz wymaga widocznego podglądu i zatwierdzenia.
Zmiana mapowania wymaga ponownej walidacji. Nie pomijać po cichu wierszy.

Rekomendacja dla tego pliku: podgląd błędów z numerami wierszy i możliwość
jawnego wyłączenia problematycznych pozycji przed zatwierdzeniem paczki.
Wyłączenie wszystkich 22 wierszy z powtarzającymi się kodami oraz wiersza
bez kodu daje 2373 pozycje bez wewnętrznych konfliktów SKU. Nie jest to
gwarancja braku konfliktów z istniejącą bazą ani decyzja o pominięciu danych
podjęta za użytkownika. Alternatywa: poprawić plik lub świadomie wybrać
jeden rekord z każdej grupy po ustaleniu znaczenia powtórzeń.

Powyższa analiza poprzedzała implementację. W przyroście 0.5 wdrożono
parser, kreator i zapis XLSX/CSV w zakresie ADR-027. Próbę pełnego importu
na tymczasowej bazie opisuje RAPORT_PRZYROST_0_5.md. Nie potwierdza to
obsługi XLS/PDF ani innych dowolnych układów źródłowych.

## Doprecyzowanie właściciela

Zaakceptowano jawne wykluczanie konfliktowych wierszy w podglądzie, bez
automatycznego scalania/nadpisywania. Kolumnę MARKA opisujemy jako
„Marka motocykla”. To opcjonalne dane źródłowe: katalog obsługuje również
produkty uniwersalne i niezwiązane z motocyklami. Nie kopiujemy tej kolumny
automatycznie do Producenta lub opisu. Szczegóły decyzji w ADR-026.
