# VexLab 0.6 — raport przyrostu

Data: 2026-11-02. Wersja developerska 0.6.0.dev0.
Instrukcja: [Praca z katalogiem](PRACA_Z_KATALOGIEM_0_6.md).

## Co działa

- Źródłowa sugerowana cena sprzedaży: kwota, waluta i netto/brutto.
  Kolumna/currency wybierane jawnie w XLSX/CSV. Cena i pochodzenie w odczycie,
  tabeli i szczegółach. Nie jest aktywną ceną Oferty, brak przeliczania/VAT.
- Osobny podgląd uzupełniania brakujących cen istniejących Produktów po SKU.
  Lista zmian i pominięć, bez kasowania katalogu, bez nadpisania istniejącej
  ceny, nazwy, producenta lub opisu. Kontrola wersji i kopia przed transakcją.
- Opis z dwóch kolumn i opcjonalnie pełnej nazwy źródłowej; podgląd przed
  zapisem. Można też masowo dołączyć nazwę każdego już istniejącego Produktu
  do jego opisu, aby zachować model/roczniki zawarte w nazwie. Bez zgadywania
  strukturalnych dopasowań i bez tłumaczenia.
- Wielokrotny wybór, Ctrl+A, Zaznacz wszystkie wyniki i Odznacz. Licznik,
  zakres filtra, zachowanie selekcji po ID przy odświeżeniu.
- Masowe ustawienie/usunięcie producenta, zastąpienie/dopisanie/wyczyszczenie
  opisu i dołączenie własnej nazwy. Pozostałe dane zachowane. Kopia i atomowy
  zapis z kontrolą wersji. Wspólne wejścia Masowa edycja/Edycja masowa.
- Usuwanie zaznaczonych albo migawki wyników, z domyślną odmową w oknie
  potwierdzenia, spójną kopią i jedną transakcją. Wraz z Produktami usuwa
  źródłowe ceny, media i techniczne powiązania importu. Zachowuje Producentów,
  Do poprawy i dane spoza migawki. Brak kopii blokuje operację.
- Opcjonalna witryna Producenta jako dane użytkownika. Publiczny adapter
  Shopify, bez zaszytej domeny: wyszukanie dokładnego SKU wariantu, pobranie
  do 5 kandydatów zdjęć, tytuł/URL i jawny wybór w formularzu pojedynczego
  Produktu przed zapisem. JPEG do 1600 px, miniatury i pochodzenie w bazie.
  Pierwsza miniatura w tabeli/szczegółach. Pobranie nie zapisuje, zmiana SKU
  lub źródła unieważnia wybór. Zmiana zdjęć ma kopię. Brak nowego wyboru
  zachowuje poprzednie. Zapis Produktu i zdjęć atomowy.

## Architektura i zgodność danych

Schemat 4 dodaje źródłowe ceny, robocze pola cen, stronę Producenta i lokalne
zdjęcia. Opublikowane SCHEMAT 1, MIGRACJA_2 i MIGRACJA_3 pozostają niezmienione.
Kopie przed migracją, kontrola rejestru sum i FK, transakcyjny zapis.
Testy 3→4 obejmują zachowanie Produktów/bufora, przerwanie, brak kopii
i niezgodną sumę. Starsze wersje nie obsługują schematu 4. Nie ma migracji
w dół; powrót ze starszej kopii w nowym katalogu. DANE_I_KOPIE.md.

Domena Produktu nadal bez ceny, frameworków i modeli dostawców. Sugerowana
cena jest osobną wartością źródłową, odczyt przez DTO. Reguły Produktu/SKU
nie zmieniły się. Nie dodano głównego bytu. Zdjęcia pobierane za portem,
HTTP/JSON/codec w adapterze, składanie w bootstrap. GUI bez SQL/HTTP.
Nowa instalacja ma zero Produktów, Producentów, adresów i zdjęć. Brak domeny
przykładowego producenta w kodzie aplikacji. Nie załączono cennika właściciela
ani użytkowej bazy do paczki. Oryginalny wzorzec PNG zachowany.

## Sprawdzenia

Linux, Python 3.13.18, PySide6/Qt 6.12.0, uv 0.13.6.
Przed końcowym dołączeniem nazwy do masowego opisu: pełne scripts/check.py
zakończyło się sukcesem — 194 testy, ruff, format, mypy strict (35 plików),
7 kontraktów importów, bandit i diagnostyka. Dodatkowy test masowego
dołączania nazwy przeszedł razem z 18 wcześniejszymi testami cen/czyszczenia.
Końcowy wynik całej paczki jest dopisany poniżej po odtworzeniu ZIP.

Na przesłanym XLSX Evotech, wyłącznie w tymczasowej bazie: zasymulowano
katalog bez cen i uzupełniono 2373 ceny GBP netto, z 23 jawnymi pominięciami.
Nie usunięto Produktów. Kopia przed uzupełnieniem potwierdzona.
Próby mediów obejmują syntetyczne JSON i PNG: dokładne/niejednoznaczne SKU,
niebezpieczne adresy, HTML/SVG, dekodowanie, atomowy zapis, miniatury, kopię,
brak domyślnego źródła i utrwalenie adresu użytkownika. GUI: wybór zdjęć
przed zapisem, unieważnienie po zmianie SKU, masowa edycja, anulowanie
usuwania i migawka po zmianie filtra, podgląd i uzupełnienie cen.

Źródło zdjęć konkretnej witryny nie było wywoływane w tej chmurze;
polityka sieci ogranicza domeny. Nie obchodzono tych ograniczeń. Testy
kontrolowanych odpowiedzi nie potwierdzają dostępności/struktury konkretnej
witryny online. Wymagany odbiór na Windows. Zrzuty pustej bazy i oba motywy
wykonano offscreen; nie zastępują DPI/Narratora lub pełnego UI-REF-01.

Graf zależności runtime/dev nie zmienił się względem audytowanego 0.5;
nie powtarzano tego samego audytu. Zachowano pinned lock. Dwa lokalne
wyjątki: B310 przy otwarciu URL z walidacją publicznego HTTPS także na
redirectach oraz mypy call-overload dla QImage.save (runtime wymaga str,
stub 6.12 deklaruje bytes). Właściciel techniczny Codex, zakres adapter
mediów, przegląd przy aktualizacji Qt/transportu; testy kodeka i adresów
sprawdzają te ścieżki. Bez globalnego wyłączania kontroli.

## Pozostaje

Odbiór 0.6 na Windows i rzeczywistej witrynie. Masowe pobieranie mediów
w imporcie i inne mechanizmy witryn wymagają kolejnych przyrostów.
Nie wdrożono automatycznego tłumaczenia. Właściciel wskazał OpenAI API,
ale nie zaakceptował kosztu po pytaniu o bezpłatność; brak płatnych wywołań.
Nie wdrożono modelu dopasowań do pojazdów, EAN, przeliczania walut/VAT,
aktualizacji aktywnych cen Ofert, publikacji w kanałach, API katalogów partnerów,
kurierów ani dokumentów Subiekta. CSV katalogu nadal bez cen/zdjęć; pełne
dane obejmuje kopia SQLite. Nie wykonano push, publikacji ani CI.

## Końcowa weryfikacja paczki

ZIP odtworzono w /tmp/vexlab06-source/VexLab. Najpierw uv sync --frozen
--no-dev --offline utworzył czyste runtime z cache; bezpośredni interpreter
wykonał diagnostykę i import adaptera mediów. Sprawdzono ścieżkę importu
oraz metadane 0.6.0.dev0 z rozpakowanej paczki. Następnie doinstalowano
przypięte dev i pełne scripts/check.py przeszło: 195 testów, ruff/format,
mypy (35 plików), 7 kontraktów, bandit i diagnostyka.
To odtworzenie Linux z cache, nie pobranie na czystym Windows.

ZIP ma poprawne CRC, bez baz, XLSX właściciela, środowiska, sekretów i cache.
Stałe schematów 1–3, domenę Produktu i obraz referencyjny porównano
z wydanym 0.5.1: bez zmian. Blokada zgodna przez uv lock --check --offline.
git diff --check bez błędów. Dokumentacja końcowa dołączona do tej samej paczki.
