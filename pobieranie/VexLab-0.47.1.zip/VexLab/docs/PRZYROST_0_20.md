# VexLab 0.20 — ZIP ofert bez zakładania produktów

2026-11-06. Wersja developerska 0.20.0.dev0. Realizuje wcześniejszy kierunek
właściciela: paczka gotowych ofert nie ma zakładać kartotek w katalogu.
Docelowy zewnętrzny katalog: **Subiekt GT, tylko do odczytu** (potwierdzenie
właściciela w trakcie tego przyrostu). Konektor GT nie jest jeszcze wdrożony.

## Co zmienia się dla użytkownika

Nowe oferty → Wybierz ZIP → Oferty z paczki → Zapisz oferty jako lokalne
szkice… → sprawdź podsumowanie → zatwierdź. Program zapisuje wyłącznie szkice,
nie tworzy Produktów i nie modyfikuje istniejących kartotek. Z widoku ZIP
usunięto osobny przycisk dodawania Produktów, sprawdzanie katalogu i wybór
producenta nowych kartotek. Znane układy paczek nadal są rozpoznawane.

Nowy szkic przechowuje SKU, tytuł, pełny opis HTML, sekcje, galerię adresów,
EAN, cenę i dane źródłowe. Nie wymaga lokalnego Produktu, także gdy w katalogu
jest już taki SKU. Nie pobiera automatycznie obrazów do bazy. Jest dostępny
po restarcie; można go edytować, przestawiać sekcje, podglądać i usuwać.
Powtórzenie identycznej oferty pomija duplikat, a edycja nie zmienia odcisku
pierwotnego importu. Błędne wiersze są wymieniane w podsumowaniu i pomijane.

Zachowano dotychczasowe szkice i produkty. Stare szkice nadal wskazują dawne
Produkty; ich aktualność i ochrona wspólnego usuwania pozostają. Podpowiedź
w kolumnie Stan wyjaśnia, czy to dawne powiązanie, czy samodzielny szkic.
Nie usunięto automatycznie żadnych starych kartotek, zdjęć lub kopii.

## Baza i powrót do poprzedniej wersji

Schemat 11 rozdziela szkic od obowiązkowego lokalnego ID i wersji Produktu.
Migracja kopiuje wszystkie wartości i kolejność rowid, zachowuje indeks
powiązania i ograniczenia. Opublikowane schematy/migracje 1–10 niezmienione.
Kopia przed zmianą, transakcja i kontrola kluczy obcych. Nieznane dodatkowe
indeksy lub wyzwalacze tabeli szkice blokują przebudowę zamiast znikać.

Powrót do 0.19 wymaga zamknięcia programu, zabezpieczenia bieżącej bazy i
przywrócenia kopii schematu 10 z kopie_migracji. Nowsze szkice/zmiany nie
znajdą się w starszej kopii. Nie otwierać schematu 11 wersją 0.19.

## Jakość i granice

Usunięto zależność planowania szkiców od katalogu i dziedziczenie magazynu
szkiców po importerze Produktów. Wycofano dawny przypadek zakładania kartotek
z ZIP i nieużywaną konwersję HTML do opisu Produktu. Renderer szkicu zachowuje
swoje ograniczenia; zapisany HTML nie jest wykonywany. Nowe testy zastępują
oczekiwania dawnej funkcji: potwierdzają brak zapisów do katalogu, zamiast
oczekiwać tworzenia kartotek. Testy ochrony dawnych powiązań pozostały.

Przegląd obejmował porty/warstwy, transakcje, kopie, migracje, deduplikację,
edycję i UI. Mechanizm autoryzacji SQLite blokujący operacje zapisu w tabelach kartotek
potwierdza, że nowa ścieżka zapisuje wyłącznie szkice. Testy prawdziwego
schematu 10 obejmują odtworzenie kopii, zachowanie treści/ID/rowid/wersji,
przerwanie po kolejnych krokach przebudowy, brak kopii i obce indeksy/triggery.

To usuwa tworzenie dodatkowych kartotek z paczki, ale szkice nadal zajmują
miejsce na dysku. Nie wprowadzono automatycznej retencji kopii. Integracje
GT, Allegro, PrestaShop, zdalne szkice i zamówienia pozostają etapami roadmapy.
Odbiór natywnego Windows i audyt UX 1.0 nadal są otwarte.

## Wyniki sprawdzenia

- `scripts/check.py`: **475 testów zaliczonych**, ruff i format, mypy
  (64 moduły), siedem kontraktów importów, Bandit oraz diagnostyka poprawne.
- 11 testów GUI paczek i szkiców przy skali 150% — powodzenie. Zrzuty jasnego
  i ciemnego motywu oraz edytora wykonane na syntetycznych danych; bez Windows.
- Dziewięć testów migracji 10→11, w tym końcowe sprawdzenie deduplikacji
  dawnej oferty po zmianie schematu — powodzenie. Ponowny przegląd schematu
  i migracji 1–10 względem opublikowanego 0.19: definicje identyczne.
- Audyt pełnych zależności przechodnich runtime i dev: brak znanych podatności
  w sprawdzonych wersjach. Bez nowych bibliotek; wheel/sdist zbudowane offline.
