# VexLab 0.20.2 — kolorowe i bardziej zaokrąglone menu

2026-11-06, polecenie właściciela dotyczące bocznych belek menu.
Wersja 0.20.2.dev0. Wyłącznie prezentacja; schemat bazy 11 bez zmian.

Belki mają osobne kolory w palecie logo:

- Produkty — turkus.
- Oferty — fiolet.
- Sprzedaż — złoto.
- Analityka — niebieski.
- Narzędzia — lawendowy.

Motyw ciemny ma przyciemnione kolorowe tła, jasny odpowiednie pastelowe
warianty. Odrębne stany najechania, naciśnięcia, rozwinięcia i fokusu.
Promień belek zwiększony z 7 do 13 px, a zakładek/Dashboardu i przycisku
zwijania menu do 12 px. Rozmiary, kolejność, ikony, działanie rozwijania,
tryb samych ikon i zapis ustawień pozostają zachowane.

Kolory są tokenami wspólnego stylu, identyfikator grupy własnością widżetu.
Nie ma zmian danych biznesowych, profili producentów, odczytu zdjęć i integracji.
Przejrzano zrzuty obu motywów z otwartą Sprzedażą oraz wąskiego okna.
Obliczony minimalny kontrast tekst/tło belek we wszystkich zadeklarowanych
stanach: 5,92:1 dla ciemnego i 5,52:1 dla jasnego motywu. To sprawdzenie
konkretnych kolorów, nie pełny audyt dostępności aplikacji.
Odbiór natywnego Windows i audyt UX 1.0 nadal osobno.

## Weryfikacja

Końcowy `scripts/check.py`: 484 testy zaliczone, ruff/format, mypy
(66 modułów), siedem kontraktów importów, Bandit i diagnostyka poprawne.
18 testów okna i nawigacji powtórzono przy skali 150% — powodzenie.
Zrzuty obu motywów i wąskiego okna obejrzane. Audyt pełnych zależności
runtime/dev: brak znanych podatności w sprawdzonych wersjach. Wheel/sdist
zbudowane offline; nie dodano bibliotek.

Pierwszy przebieg ujawnił zbyt wczesne kończenie fixture testu Cenników przed
pierwszym odczytem katalogu. Fixture czeka teraz na potwierdzone zakończenie
odczytu, a nie tylko chwilowo pustą listę zadań. Nie zmieniano kodu odczytu.
Ponowny pełny przebieg przeszedł bez błędów. Porównanie z 0.20.1 potwierdziło
niezmienione pliki bazy, preferencji, szkiców i podglądu zdjęć.
