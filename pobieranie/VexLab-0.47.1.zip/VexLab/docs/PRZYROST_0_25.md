# VexLab 0.25 — połączenie konta Allegro i lista szkiców

2026-11-08. Użytkownik wybrał Allegro jako następny kierunek i potwierdził
posiadanie aplikacji produkcyjnej. Subiekt GT odłożony; brak Sfery potwierdzony,
docelowo integracja bez S2S. Ten przyrost nie wybiera transportu GT.
Schemat 11 bez migracji i zmian zależności. ADR-053.

## Połączenie na laptopie

1. Otwórz Sprzedaż → Allegro. Wybierz Allegro (produkcja) lub osobny Sandbox.
2. Wpisz Client ID i Client Secret bezpośrednio w programie. Aplikacja musi
   obsługiwać Device Flow: typ aplikacji bez dostępu do przeglądarki.
   Jeśli istniejąca aplikacja ma inny typ, zarejestruj osobną do tego procesu;
   nie zmieniaj konfiguracji używanej przez inne działające integracje.
3. W panelu Allegro API aplikacja powinna mieć zakresy
   `allegro:api:profile:read` i `allegro:api:sale:offers:read`.
4. Kliknij Połącz konto, następnie Otwórz zgodę w Allegro. Sprawdź właściwe
   konto w przeglądarce i zatwierdź zgodę. VexLab sprawdza ją w tle z odstępem
   wskazanym przez Allegro; slow_down wydłuża odstęp o pięć sekund.
5. Po pobraniu tokenu i potwierdzeniu konta przez `/me` pojawi się login.
   Lista szkiców jest pobierana automatycznie. Pobierz szkice odświeża listę;
   Poprzednia/Następna przechodzą po 50 rekordów.

Dane aplikacji i token nie są zapisywane w SQLite, preferencjach ani pliku.
Refresh token jest ignorowany. Po zamknięciu/rozłączeniu potrzebne będzie
ponowne logowanie. Rozłączenie usuwa lokalne odwołania do sesji; nie odwołuje
zgody aplikacji na Allegro i nie jest gwarancją fizycznego wyzerowania RAM.
Anulowanie ignoruje spóźnione wyniki, nie przerywa już wysłanego żądania HTTP.
Zamknięcie głównego okna czeka na pracujące zadania, a następnie czyści sesję.

## Zakres i ograniczenia

Lista pochodzi z `GET /sale/offers?publication.status=INACTIVE`, osobno od
lokalnych szkiców ZIP. Pokazuje ID i tytuł, do 10 tys. wyników API, bez
kopiowania całego konta do katalogu. Pusta strona i błąd są różnymi stanami;
błąd odczytu usuwa poprzednią stronę, ponowienie jest ręczne. Kolejne strony
nie są transakcyjną migawką konta; oferty mogą zmienić się na Allegro.

W tym przyroście nie ma podglądu pełnej treści, edycji ani zapisu zdalnego
szkicu. To kolejne kroki po odbiorze połączenia. Nie ma wywołań publikacji,
aktualizacji cen, zamówień, trwałego konta ani automatycznej synchronizacji.
Nagłówek i karta Dashboard pokazują rzeczywisty stan sesji, PrestaShop nadal
niewdrożony. Globalna etykieta nie deklaruje działania wszystkich integracji.

## Granice i weryfikacja

Przypadek użycia i techniczne DTO sesji nie zmieniają modelu Produktu/Oferty.
Konektor w `kanaly`, transport HTTPS w `adaptery`, składanie w bootstrapie.
Żądania tylko do stałych hostów produkcji/Sandbox, TLS, timeout 20 s, limit
odpowiedzi 2 MiB i brak przekierowań. POST jest dopuszczony tylko dla OAuth;
operacje zapisu ofert nie są dostępne. Treści błędów API i sekretów nie logować.

Oficjalne źródła: [repozytorium Allegro API](https://github.com/allegro/allegro-api)
i [wyjaśnienie Device Flow/Basic](https://github.com/allegro/allegro-api/issues/11764).
Pełny portal developer.allegro.pl był niedostępny z tego środowiska (blokada
sieci). Kontrakt implementacji wymaga odbioru rzeczywistą aplikacją użytkownika.
Testy korzystają z transportu symulowanego, nigdy z jego tokenów lub danych.
Nie potwierdzono logowania na żywym koncie, Sandbox ani natywnym Windows.

## Wyniki końcowe

`scripts/check.py`: 584 testy zaliczone, ruff i format bez uwag, mypy 82
moduły, siedem kontraktów warstw, Bandit oraz diagnostyka bez błędów.
Mypy z platformą win32 również poprawne. Nowy zakres: 49 testów, a przy
skalowaniu 150% sześć testów GUI zaliczonych. Obejrzano pusty panel w obu
motywach przy 1536×1024 i jasny 900×700. Zrzuty
`docs/screenshots/vexlab-allegro-025-*.png` nie pokazują rzeczywistego konta.
Audyt runtime/dev nie wykazał znanych podatności w chwili sprawdzenia.
Wheel/sdist zbudowane offline. Nie wykonano logowania na żywym koncie ani
natywnego odbioru Windows. Testy nie zastępują odbioru API użytkownika.
