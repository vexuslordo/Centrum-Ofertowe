# VexLab 0.10.1 — gotowa paczka bez ręcznego mapowania i lokalne Produkty

2026-11-03. Zgłoszenie właściciela: gotowy ZIP ma być gotowy w chwili
wczytania, bez wybierania pól JSON. Dodatkowo paczka ma dodawać Produkty
do lokalnego katalogu. Wdrożono oba scenariusze w istniejącym modelu,
bez nowej migracji lub trwałego modelu Oferty.

## Obsługa gotowej paczki

Nowe oferty → Wybierz gotową paczkę ZIP. Profil dołączony do archiwum
jest odczytywany i oferty pojawiają się automatycznie. Ręczne mapowanie
jest ukryte w konfiguracji zaawansowanej, dla autora formatu/profilu.

Przygotowano osobny ZIP użytkownika EVOTECH_Crash_Protection_GOTOWA_VexLab.zip.
Dodano tylko profil odczytu; wszystkie oryginalne 8 plików mają identyczną
treść. Profil wybiera plik pełnych rekordów, zamiast samej listy układów.
Oryginalna przesłana paczka pozostaje bez zmian. Żadna z paczek i żaden
profil Evotech nie są wbudowane w kod lub dystrybucję programu.

Dla innych producentów obowiązuje ten sam ogólny mechanizm: do ZIP-a
dołącza się własny profil JSON wersji 1 (wersja/ustawienia). Rozpoznawany
po strukturze, a nie nazwie pliku, producencie lub domenie. Jeden poprawny
profil uruchamia podgląd automatycznie. Przy kilku profilach wybiera się
właściwy z listy; program nie zgaduje. Nieprawidłowy profil daje błąd,
bez automatycznego zastąpienia innym układem. Starszy ZIP bez profilu wymaga
jawnego wczytania zewnętrznego profilu lub przygotowania gotowej paczki.
Treść konfiguracji jest danymi; brak wykonywania poleceń z plików.

## Zapis produktów do lokalnej bazy

Po podglądzie automatycznie sprawdzany jest katalog po SKU. Liczniki
pokazują nowe poprawne pozycje, pozycje Do poprawy i pozycje już istniejące.
Opcjonalnie można wskazać producenta z własnego rejestru; brak producenta
jest dozwolony. Przycisk Dodaj nowe produkty do katalogu zapisuje paczkę:

- nowe poprawne SKU → nowy Produkt z nazwą z tytułu i tekstem opisu;
- istniejące SKU bez rozróżniania wielkości liter → zachowanie dotychczasowych danych;
- błędne lub powtarzające się nowe SKU → trwała lista Cenniki → Do poprawy.

Opis HTML jest przekształcany do tekstu katalogowego, bez skryptów i pobierania
zasobów. Oryginalny opis oraz układ Oferty pozostają w ZIP-ie i podglądzie.
Cena gotowej oferty nie jest automatycznie ceną sugerowaną Produktu.
EAN, adresy zdjęć i tekst dopasowania nie tworzą nieuzgodnionych pól/relacji
w katalogu. Zdjęcia nie są pobierane i nie są w tym scenariuszu dodawane
do lokalnej galerii; wymagają osobnego wdrożenia. UI podaje zakres pól przed zapisem.

Wykorzystano istniejący atomowy zapis importu z kontrolą unikalności SKU,
powtórną walidacją przed zatwierdzeniem i buforem korekt. Odczyt, sprawdzenie
i zapis poza wątkiem GUI. Nie ma zapisu podczas samego podglądu; momentem
zapisu jest przycisk Dodaj nowe produkty. Po sukcesie katalog odświeża się,
a ponowny zapis tej samej otwartej paczki jest zablokowany.
Ponowne wczytanie rozpoznaje istniejące produkty i nie tworzy ich duplikatów.
Błędne wiersze przy ponownym świadomym imporcie mogą zostać odłożone ponownie,
jak przy dotychczasowym imporcie cenników; nie wdrożono scalania korekt.

Brak migracji: schemat 6. Dotychczasowe ceny, media, producenci i dopasowania
pozostają bez zmian. Nie wdrożono zapisu/publikacji Ofert ani ustawień API
Allegro; to nadal kolejny zakres wymagania właściciela.

## Weryfikacja

Testy profilu wewnątrz ZIP o dowolnej nazwie, wielu profili, błędnego profilu,
braku profilu, automatycznego przejścia do ofert i ukrycia mapowania.
Testy lokalnego importu: nowe i istniejące SKU, trwałe korekty, brak
nadpisania, powtórny import, duplikaty w paczce, konflikt po planowaniu,
wycofanie paczki przy awarii i opis bez HTML/skryptów.
Test GUI przechodzi przez gotowy ZIP → automatyczny podgląd → dodanie
produktów → odświeżenie katalogu i odłożenie niepoprawnej pozycji.

Przejście rzeczywistej gotowej paczki przez GUI sprawdzono na tymczasowej
bazie: automatyczny podgląd 200 ofert, zapis 200 Produktów oraz ponowne
wczytanie bez utworzenia duplikatów. To test Qt offscreen na syntetycznej
instalacji, nie pełny odbiór Windows/DPI/Narrator lub integracji Allegro.

Wynik końcowy scripts/check.py: 273 testy przeszły, ruff check/format,
mypy (44 pliki), 7 kontraktów importów, bandit i diagnostyka poprawne.
uv sync --frozen --offline i uv lock --check potwierdziły zgodność.
Nie zmieniono zewnętrznych zależności, bez ponownego audytu tego samego grafu.
Obejrzano ekran gotowej paczki i wykonano opisany przepływ na rzeczywistym
ZIP-ie użytkownika w izolowanej bazie. Zrzut z treścią paczki poza źródłami;
w dystrybucji tylko puste widoki i syntetyczne fixture'y.

ZIP programu rozpakowano osobno, potwierdzono import z jego src i uruchomiono
11 testów gotowej paczki, profili/GUI oraz importu Produktów — wszystkie
przeszły. CRC poprawne; bez baz, źródłowego ZIP-a użytkownika, profilu
producenta, środowiska i cache. Gotowy ZIP ofert przekazano jako osobny
artefakt użytkownika. Nie był to test świeżej instalacji Windows.
