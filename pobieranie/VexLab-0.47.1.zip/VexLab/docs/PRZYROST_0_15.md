# VexLab 0.15 — krótszy pasek produktów i menu kontekstowe

Data: 2026-11-05. Polecenie właściciela: ograniczyć liczbę przycisków nad
tabelą Produktów, użyć rozwijanego menu i udostępnić akcje pod prawym
przyciskiem myszy. Zmiana dotyczy wskazanego ekranu Produkty.

## Obsługa

Na pasku pozostają: Dodaj produkt, Importuj produkty z pliku…, Odśwież,
Więcej akcji. Przy węższym oknie przyciski układają się w dwóch rzędach.
Pozostałe funkcje są w menu Więcej akcji, podzielone separatorami:

- szczegóły, edycja i galeria jednego Produktu oraz wspólna zmiana danych;
- zaznaczanie wszystkich wyników i odznaczenie;
- Do poprawy — importy oraz eksport bieżących wyników do CSV;
- usunięcie zaznaczonych lub wszystkich bieżących wyników.

Prawy przycisk w tabeli otwiera menu z tymi samymi akcjami oraz dodawaniem,
importem i odświeżeniem. Korzystają z tych samych obiektów QAction oraz
istniejących procesów; nie ma osobnej logiki zapisu lub usuwania.

Kliknięcie prawym przyciskiem wiersza poza zaznaczeniem wybiera ten
wiersz. Kliknięcie w już zaznaczonej grupie zachowuje całą grupę.
Puste miejsce usuwa zaznaczenie i wyłącza akcje pojedynczych/zaznaczonych
Produktów. Nadal można wybrać operacje dotyczące całego katalogu lub
wyników filtra, z dotychczasowym potwierdzeniem przed usunięciem.

Shift+F10 lub klawisz Menu otwiera menu dla aktualnego wyboru bez zmiany
zaznaczenia. Enter i dwuklik pozostają skrótami szczegółów/edycji.
Ctrl+A oraz Ctrl/Shift i filtry zachowują dotychczasowe działanie.

## Dostępność i bezpieczeństwo

Szczegóły/edycja/galeria wymagają dokładnie jednego wybranego Produktu.
Wspólna zmiana i usunięcie zaznaczonych wymagają co najmniej jednego.
Pusta lista, błąd odczytu i trwające usuwanie wyłączają odpowiednie akcje.
Galeria jest dostępna po skonfigurowaniu istniejącej usługi galerii.

Menu mają identyczne stany i wywołują te same przypadki użycia. Zachowano
potwierdzenia, kopie, wersje i blokadę usunięcia Produktu mającego szkice.
Operacje pozostają poza wątkiem GUI. Zmiana nie usuwa danych podczas
instalacji i nie wykonuje publikacji lub synchronizacji.

Schemat bazy nadal 7, bez migracji lub nowych zależności. Domena, adaptery,
porty przypadków użycia, logo, kolorowe ikony i pozostałe moduły bez zmian.
To jawnie zlecone uproszczenie paska Produktów; układ menu bocznego zachowany.

## Weryfikacja

Nowe testy Qt sprawdzają współdzielone akcje i ich dostępność dla zera,
jednego oraz wielu wybranych wpisów, wywołanie szczegółów, rzeczywiste
zdarzenie menu kontekstowego Qt, kliknięcie innego wiersza, zachowanie
grupy, puste miejsce, anulowanie usuwania i otwarcie przez Shift+F10.
Dotychczasowy test odznaczania korzysta teraz z QAction w menu zamiast
przeniesionego przycisku. Nie wyłączono sprawdzeń wcześniejszych funkcji.

Obejrzano stronę Produkty i rozwinięte menu w obu motywach na pustej,
izolowanej instalacji. Zrzuty w docs/screenshots/vexlab-produkty-*.png.
Odbiór rzeczywistego Windows/DPI i pełny audyt kandydata 1.0 pozostają
osobnymi sprawdzeniami, testy Qt offscreen ich nie zastępują.

Zbudowano wheel i sdist offline. ZIP ma poprawne CRC i nie zawiera baz
użytkownika. Porównanie z 0.14.1 potwierdziło zgodność bajtową całego kodu
aplikacji poza GUI, w tym schematu i migracji. Z wypakowanego ZIP-a
przeszły cztery testy menu, prawego przycisku, klawiatury i zaznaczania.
Pełna kontrola wydania: **324 testy przeszły** (193,65 s). Ruff,
formatowanie, strict mypy (50 plików), siedem kontraktów importów,
Bandit i diagnostyka techniczna zakończyły się poprawnie.
