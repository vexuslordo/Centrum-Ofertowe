# VexLab 0.20.1 — rozwijane belki bocznego menu

2026-11-06, bezpośrednie polecenie właściciela. Wersja 0.20.1.dev0.

Kliknięcie belki Produkty, Oferty, Sprzedaż, Analityka lub Narzędzia
rozwija albo zwija jej zakładki. Można otworzyć kilka grup jednocześnie.
Dashboard pozostaje osobnym przyciskiem. Nazwy, kolejność, kolorowe ikony
zakładek i ich działanie zachowane. Samo kliknięcie belki nie zmienia strony.

Domyślnie grupy są zwinięte. Wybór strony z szybkiej akcji lub innego
skrótu automatycznie odsłania jej grupę. Można później schować aktywną grupę
bez opuszczania strony. Ręczny wybór rozwiniętych grup zapisuje się w
preferencjach użytkownika (wyglad/rozwiniete_grupy); stare ustawienia działają
bez migracji. Nie ma danych biznesowych w tych ustawieniach.

Belki mają strzałki, stan rozwinięcia oraz nazwy dostępności. Klawiatura:
Tab do belki, Spacja rozwija/zwija. Globalne Zwiń menu nadal pokazuje ikony
wszystkich zakładek; powrót do szerokiego panelu przywraca układ grup.
Awaria zapisu preferencji pozostawia dotychczasowy stan i pokazuje błąd.

Komponent SekcjaMenu jest osobnym modułem GUI. Preferencje przechodzą przez
istniejący port powłoki i adapter QSettings, z kontrolą znanych grup i duplikatów.
Zmiana dotyczy prezentacji i ustawień technicznych. Schemat bazy 11,
Produkty, szkice, cenniki i definicje migracji pozostają bez zmian.
Odbiór natywnego Windows pozostaje do wykonania; zrzuty i testy offscreen
obejmują oba motywy i skalę 150%.

## Zdjęcia w podglądzie paczki i zapisanego szkicu

Dodatkowe polecenie właściciela w trakcie pracy: pokazywać zdjęcia zamiast
adresów w Układzie sekcji. W tym samym wydaniu okno Podgląd oferty z paczki
oraz podgląd zapisanego szkicu używają wspólnego mechanizmu ObrazyOferty.
Sekcje pokazują rzeczywiste obrazy i sformatowany tekst z zachowaniem kolejności.
Dane i zdjęcia ma galerię z podglądem, zamiast listy adresów. Źródło opisu
pozostaje osobną zakładką do odczytu HTML.

Port PodgladZdjec jest przekazany z punktu składania przez stronę paczek/szkiców
do okna podglądu. Zdjęcia HTTPS pobierane przez istniejący ograniczony transport
w zadaniu poza GUI; obraz ładowania i błąd zamiast udawanej miniatury. Jeden
odczyt na powtarzający się adres w sesji, ograniczona pamięć cache, bez zapisu
obrazów w SQLite lub na dysku. Zamknięcie podglądu zatrzymuje kolejkę i ignoruje
spóźniony wynik trwającego odczytu. Przy ponownym otwarciu obrazy są odczytywane
na nowo. Brak dostępu do obrazu nie blokuje odczytu tekstu i zamknięcia okna.

Bezpieczny renderer tekstu wydzielono do tekst_podgladu.py, współdzielonego
przez edytor i oba podglądy, aby uniknąć cyklicznych importów. HTML nadal
nie pobiera zasobów i nie wykonuje kodu; pobierane są jawne obrazy galerii
oraz sekcji przez port. Nie zmieniono zapisanych szkiców, ofert i profili.
Testy wykorzystują obrazy syntetyczne i kontrolowane źródło, nie połączenia
z realnymi adresami użytkownika.

## Weryfikacja

- Pełny `scripts/check.py`: **484 zaliczone testy**, ruff i format bez uwag,
  mypy bez błędów w 66 modułach, siedem kontraktów importów, Bandit i diagnostyka.
- 34 testy GUI menu, okna paczek i obrazów przy skali 150% — powodzenie.
  Zrzuty rozwiniętej Sprzedaży, zwiniętych grup, obu motywów i wąskiego okna
  oraz sekcji z obrazami obejrzane. Brak odbioru na Windows.
- Testy obrazów obejmują galerię i sekcje, deduplikację odczytu w sesji,
  błąd, zamknięcie przed wynikiem, wejście z paczki i z zapisanego szkicu.
  Testy menu obejmują klawiaturę, automatyczne otwarcie grupy, trwałość,
  awarię zapisu i zachowanie globalnego trybu ikon.
- Audyt pełnych zależności przechodnich runtime/dev: brak znanych podatności
  w sprawdzonych wersjach. Bez nowych bibliotek. Wheel/sdist zbudowane offline.
