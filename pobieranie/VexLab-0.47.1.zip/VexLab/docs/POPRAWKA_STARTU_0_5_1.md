# Poprawka startu 0.5.1

Data: 2026-11-02. Zgłoszenie Windows: systemowy Python zwrócił
No module named vexlab. Dokładnego powodu wyboru tego interpretera nie
odtworzono na Linux. Użytkownik następnie potwierdził „działa”; brak
potwierdzenia, jakiego sposobu uruchomienia użył, więc nie przypisujemy
tego wyniku automatycznie do nowego pliku CMD.

CMD sprawdza kompletność folderu, wykonuje uv sync --frozen --no-dev,
a następnie wywołuje bezpośrednio .venv\Scripts\python.exe -m vexlab.
Błąd przygotowania środowiska przerywa start; komunikaty odróżniają
brak kompletnego folderu, nieudaną instalację i błąd aplikacji.
Zmienne ścieżek Pythona zerowane wyłącznie w lokalnym setlocal pliku CMD.
Nie usuwamy środowiska ani bazy. Funkcje i schemat 3 pozostają bez zmian.

Weryfikacja: ZIP rozpakowany osobno, nowa .venv przez frozen --no-dev
z lokalnego cache, bezpośredni interpreter wykonał diagnostykę i import
VexLab z rozpakowanego katalogu, metadane 0.5.1.dev0 zgodne. Sprawdzono
CRLF CMD i git diff --check. To test równoważnego startu na Linux;
nie uruchomiono cmd.exe ani ponownie pełnej funkcjonalnej macierzy 0.5.
Poprzednie 144 testy dotyczą niezmienionego kodu aplikacji 0.5.
