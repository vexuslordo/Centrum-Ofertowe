# VexLab 0.23 — strony pozycji Cenników

2026-11-07. Kontynuacja roadmapy przez właściciela. Wersja 0.23.dev0.
Schemat 11 bez migracji i nowych zależności. Decyzja techniczna: ADR-051.

## Obsługa

Pod pozycjami Cennika dostępne Poprzednia / Następna i 100, 250 lub 500
na stronę. Wyszukiwanie i filtr stanu obejmują cały dokument. Duplikaty SKU
występujące na innych stronach nadal otrzymują Do poprawy; kliknięcie statusu
wymienia odpowiednie wiersze źródłowe. Porównania z bazowym/poprzednim wydaniem
i kolumny cen pozostają zgodne z dotychczasowym działaniem.

Ctrl+A i menu wybierają wszystkie wyniki filtra, nie tylko widoczną stronę.
Przejście strony zachowuje wybór, Ctrl/Shift go rozszerza; zwykłe kliknięcie
rozpoczyna nowy. Odznacz/Escape czyści całość. Nowy filtr zaczyna nowy wybór
od pierwszej strony. Licznik pokazuje również pozycje poza stroną.
Dodaj do katalogu pobiera/zapisuje tylko wskazane indeksy. Jedną pozycję
spośród duplikatów nadal można wybrać i dodać jako pojedynczy Produkt.

## Odczyt

Pełne opisy i dopasowania nie są przechowywane dla całego podglądu w Qt.
Lekki indeks ocen powstaje w tle, a pełne rekordy JSON są odczytywane przez
SQLite tylko dla strony lub jawnego wyboru. Globalna walidacja i ceny
bazowe przechodzą dokument strumieniowo. Importer sprawdza znane SKU bez
odczytu całych kartotek, opisów i zdjęć katalogu.

Zapisany dokument nadal jest pojedynczym JSON. SQLite musi go analizować;
przygotowanie globalnego indeksu nadal zależy od jego wielkości. Wybór całego
dokumentu wymaga danych całego jawnego zestawu do zapisu. Nie jest to limit
pamięci całej aplikacji. Limity 20 tys. pozycji / 64 MiB pozostają.

## Subiekt GT — potwierdzone środowisko

Właściciel potwierdził: baza na serwerze i klient Subiekta GT na laptopie.
Zapisano to w `SUBIEKT_GT_ODCZYT_PLAN.md`. Nadal nie ustalono instancji,
wersji serwera, autoryzacji, licencji Sfery ani mechanizmu dostępu. Nie ma
połączenia z serwerem ani zapisu do GT. Przygotowanie stron nie jest dowodem
działającego konektora. Hasła nie są zbierane w rozmowie/plikach projektu.

## Weryfikacja

Nowe testy porównują wszystkie strony z dotychczasowym pełnym wynikiem.
Sprawdzają duplikaty między stronami, EAN, porównanie historyczne i odczyt
100 rekordów strony lub jednego wskazanego rekordu, kontrolę wersji także
dla pustego filtra, zamknięcie generatora i błędny dokument. GUI potwierdza
Ctrl+A dla całego dokumentu, wybór z różnych stron i dodanie dokładnie
wskazanych pozycji z zachowanymi opisami. Testy korzystają z baz tymczasowych.

## Pomiar syntetyczny i wyniki końcowe

Na tymczasowym cenniku 2000 pozycji, każda z opisem 16 384 znaków,
pełny odczyt zawierał 2000 pełnych pozycji / 32 768 000 znaków opisów,
a podgląd strony 100 pozycji / 1 638 400 znaków. Szczyt alokacji Python
(`tracemalloc`) wyniósł około 69 MB dla pełnego odczytu i 2,42 MB dla
przygotowania lekkiego indeksu oraz strony. To nie jest pomiar pamięci
natywnej SQLite/Qt ani gwarancja RAM całego procesu; SQLite nadal analizuje
JSON. Jawny wybór wszystkich nadal wymaga pełnego zestawu do zapisu.

`scripts/check.py`: **519 testów zaliczonych**, ruff i format bez uwag,
mypy poprawne (75 modułów), siedem kontraktów importów, Bandit i diagnostyka
bez błędów. Przy skalowaniu 125% i 150% zaliczono po 21 testów Cenników
oraz wielostronicowego wyboru katalogu. Audyt pełnych zależności runtime
/dev: brak znanych podatności w chwili sprawdzenia. Wheel/sdist zbudowane
offline. Opublikowany schemat i migracje porównane AST z 0.22 — identyczne.
Parser pojedynczego rekordu przeniesiony do wspólnego modułu bez zmiany
AST jego funkcji. Brak zmian zależności i danych użytkownika.

Obejrzano ciemny/jasny widok 1536×1024 i małe okno 900×800. Zrzuty
`docs/screenshots/vexlab-cennik-strony-023-*.png` korzystają wyłącznie
z tymczasowych danych wizualnych. Testy Linux/Qt offscreen nie zastępują
odbioru natywnego Windows ani audytu UX 1.0. ZIP sprawdzany przez CRC,
wykluczenie baz/środowiska/sekretów oraz testy po rozpakowaniu.
