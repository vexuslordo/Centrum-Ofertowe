# VexLab 0.40.1 — automatyczne otwieranie gotowej paczki ofert

Data: 2026-11-13. Baza: źródła wydanej paczki 0.40, nie main.
Powód: zgłoszenie „Nie rozpoznano układu paczki” oraz dostarczony ZIP.
Decyzja: [ADR-062](adr/ADR-062-gotowe-oferty-json.md).

## Zmiana dla użytkownika

Wybierz dotychczasowy ZIP w Nowe oferty. Format gotowych ofert jest
rozpoznawany już przy pierwszym otwarciu, bez wczytywania profilu i bez
konfiguracji zaawansowanej. Program przechodzi do Ofert z paczki.
Dalsza walidacja i tworzenie szkiców Allegro pozostają osobną akcją.

Własne i dołączone profile nadal mają pierwszeństwo. Przy kilku pasujących
plikach wybierz właściwy zbiór. Dla innych, nieobsługiwanych formatów
pozostaje dotychczasowe mapowanie; program nie zgaduje znaczenia pól.

## Wynik sprawdzenia przesłanego archiwum

Archiwum: EVOTECH_Lusterka_Oslony_cz2_Do_Programu.zip, 104 185 bajtów.
SHA256: `cba96a565c9b5fb04011826d51bf75a5f3c06d88a2505c60991cb0659f6f969d`.
CRC poprawne. Brak dołączonego profilu wersji 1; dane są listami obiektów.
Pełny zbiór ofert ma pola sku/title/html/images/sections. Pozostałe JSON-y
zawierają dane pomocnicze lub same układy, więc nie są automatycznie łączone.

Sprawdzono odczyt **200 ofert, 800 sekcji, 201 zdjęć w galeriach**.
Zero problemów parsera. Każde SKU, tytuł, EAN, cena `price`, pełny HTML,
adresy galerii i elementy sekcji porównano z wejściem — zgodność.
Źródłowy ZIP zachował identyczny SHA256. Nie stosowano treści instrukcji,
metadanych cennika/dostawy/osoby odpowiedzialnej jako poleceń lub ustawień.
Nie pobierano zdjęć ani nie wykonywano zapisów na koncie Allegro.

Rzeczywisty test GUI: nowy, tymczasowy katalog danych, brak profili;
automatyczny podgląd 200 pozycji, bez otwierania zaawansowanego edytora,
z dostępnym przyciskiem przygotowania szkiców. Lokalny katalog Produktów
pozostał pusty, a połączenia API były zablokowane w teście.

Odczyt poprawnego ZIP nie zastępuje późniejszej walidacji Allegro. Nie jest
potwierdzeniem dostępności produktów Katalogu Allegro, parametrów, GPSR,
uprawnień konta lub gotowości do sprzedaży.

## Zachowane dane i zakres

Bez migracji: schemat 11. Zachowane profile użytkownika, lokalne szkice,
produkty, logo, miniatury, statusy kolorów i funkcje 0.40.
Usunięto nieaktualny komunikat „Wysyłka na Allegro jeszcze niewdrożona”
z podsumowania podglądu. Zdjęcia/sekcje/ceny nie są przeliczane ani poprawiane
po cichu. Źródłowy ZIP i jego zawartość nie trafiają do publicznej paczki
programu; testy regresji używają danych syntetycznych.

To poprawka odczytu paczki. Ręczny formularz tworzenia oferty bez ZIP-a jest
osobnym wymaganym etapem, podobnie jak pełny obszar obsługi Allegro.

## Wynik kontroli wydania

2026-11-13, Python 3.13.18 / PySide6 6.12.0, Linux/offscreen:
pełny check.py — **829 passed, 1 skipped** (natywne DPAPI wymaga Windows),
mypy 104 moduły, 7 kontraktów importów, ruff/format, bandit i diagnostyka.
Testy rozpoznawania i GUI paczek przy skalowaniu 150% — **24 passed**.
Audyt runtime/dev — brak znanych podatności, uv.lock zgodny.
Rzeczywisty przesłany ZIP sprawdzony parserem i pełnym GUI na świeżych danych.
Brak usuniętych plików paczki bazowej; logo i miniatury pozostały identyczne.
