# VexLab 0.20.4 — natywny pasek tytułu

2026-11-07, polecenie właściciela po uruchomieniu programu na laptopie
z Windows. Wersja developerska 0.20.4.dev0. Schemat 11 bez zmian.

## Zachowanie

Pasek tytułu korzysta z natywnej ramki Windows. Minimalizacja, maksymalizacja,
zamykanie, przeciąganie i systemowe skróty pozostają obsługiwane przez system.
Nie wprowadzono własnego okna bez obramowania ani dodatkowej biblioteki.

Windows 11 obsługuje kolor tła i tekstu DWM: granat #17202D z jasnym tekstem
#EDF2FA albo jasny #EAF0F7 z tekstem #17263A. Są to tokeny nagłówka ze wspólnego
Design Systemu. Windows 10 obsługujący ciemne paski otrzymuje wariant systemowy;
nie deklarujemy na nim identycznego odcienia granatu. Starszy Windows bez obsługi
atrybutów zachowuje domyślną ramkę, bez blokowania startu programu.

Zmiana motywu ciemny/jasny/systemowy aktualizuje istniejące okna i dialogi.
Nowe okna dostają aktualne kolory po utworzeniu uchwytu i pokazaniu. Menu,
dymki i widżety wewnątrz okien nie otrzymują systemowej ramki.

## Granice techniczne

Adapter `adaptery/pasek_tytulu.py` podłączony wyłącznie w bootstrapie GUI.
GUI przekazuje komplet tokenów przez właściwość aplikacji Qt; nie importuje
adaptera ani WinAPI. Domena i przypadki użycia pozostają bez zmian. Diagnostyka
CLI nie ładuje tego adaptera. Poza Windows nie instaluje on filtra zdarzeń.

`DwmSetWindowAttribute` ma jawne typy argumentów, uchwyt o szerokości wskaźnika
i 32-bitowy HRESULT. Biblioteka pochodzi wyłącznie z System32. Atrybut 20 ma
fallback do 19 dla starszego Windows 10; nieobsługiwane kolory 35/36 są opcjonalne.
Nie zmieniono plików danych, migracji, preferencji ani zależności programu.

## Weryfikacja

Testy sprawdzają odmowę obsługi atrybutów starszego Windows, przejście między
motywami w głównym oknie i dialogu, zachowanie flag natywnej ramki, pomijanie
menu/potomków oraz start bez DWM i na innym systemie. Testy Qt wykonywane
w środowisku Linux z kontrolowanym zastępczym wywołaniem DWM.

Natywny wygląd i interakcje na Windows 10/11 wymagają odbioru na tych systemach;
testy Linux nie potwierdzają koloru faktycznie narysowanego przez Windows.
Przy odbiorze: zmienić motyw w Ustawieniach, otworzyć dialog, przełączyć fokus,
zminimalizować/przywrócić okno i sprawdzić maksymalizację oraz przeciąganie.

Pełne `scripts/check.py`: 491 testów zaliczonych, ruff i format bez uwag,
mypy poprawne (67 modułów), siedem kontraktów importów, Bandit i diagnostyka
bez błędów. Przy skalach 125% i 150% zaliczono po 25 testów okna/ramki.
Audyt pełnych zależności runtime i dev: brak znanych podatności. Wheel/sdist
zbudowane offline. Porównanie źródeł z 0.20.3: zmienione wyłącznie bootstrap
i Design System oraz dodany adapter; pliki bazy, preferencji i przypadków
użycia identyczne. Pakiet źródłowy sprawdzany przez CRC i testy po rozpakowaniu.
