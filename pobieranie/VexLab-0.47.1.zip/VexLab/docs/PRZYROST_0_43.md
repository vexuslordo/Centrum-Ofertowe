# VexLab 0.43 — kompletne dane szkicu, SKU i prostsze parametry

## Przygotowanie nowego szkicu

1. Wczytaj paczkę i wybierz kategorię/produkt. Domyślnie zaznaczone
   „Przygotuj komplet danych do publikacji” — wymaga poniższych ustawień.
2. Zaznacz grupę ofert tego samego producenta i kliknij **GPSR, dostawa
   i warunki…**. Bez zaznaczenia ustawienia dotyczą wszystkich widocznych.
3. Zakładka **GPSR**: producent z rejestru konta, osoba odpowiedzialna w UE
   albo jawne Nie dotyczy, własne informacje o bezpieczeństwie do 5000 znaków.
   Nie generujemy ani nie zgadujemy ostrzeżeń. Producent GPSR jest osobnym
   odwołaniem niż parametr kategorii „Producent”. Brakujący wpis rejestru
   dodaj w ustawieniach Allegro i pobierz listy ponownie.
4. **Dostawa**: cennik konta, czas wysyłki, kraj, miejscowość, kod pocztowy,
   województwo dla Polski. **Warunki sprzedaży**: zwroty, reklamacje,
   gwarancja albo jawny brak dodatkowej gwarancji i rodzaj faktury.
5. Zastosuj, uzupełnij wymagane parametry produktów i sprawdź plan.
   Wysyłka po osobnym potwierdzeniu tworzy tylko INACTIVE, bez sprzedaży.

Dla nowych zgód OAuth dodano `allegro:api:sale:settings:read`, wymagane przez
wszystkie listy GPSR, dostaw i warunków. Dotychczasowy token może nie mieć
tego zakresu. Włącz go w konfiguracji aplikacji Allegro, następnie
**Ustawienia → Integracje → Allegro → Zmień uprawnienia**. Przycisk pozwala
odnowić zgodę także bez zmiany checkboxa zapisu, bez rozłączania konta.
Anulowanie i odmowa zachowują dotychczasowy dostęp.

Ustawienia są odwołaniami do rzeczywistych danych tego konta, nie domyślnymi
markami ani seedami. Listy stronicowane, cache w pamięci do 60 s rozdzielony
według konta, środowiska i tokenu. Brak/nieaktualny identyfikator blokuje
wysyłkę przed uploadem zdjęć. Wybór grupy stosuje wspólne dane, zachowując
osobne SKU, EAN, ceny i ilości każdej oferty. Przy różnych producentach
przygotuj osobne grupy. Ustawienia robocze nie są zapisywane jako nowe byty
lokalnego katalogu ani utrwalane automatycznie po zamknięciu okna.

Po utworzeniu GET porównuje GPSR, tekst bezpieczeństwa, dostawę, lokalizację,
fakturę i odwołania do warunków. Nieznany wynik nadal nie pozwala ponowić
POST. Raport **Szkic kompletny** wymaga również `validation.errors=[]`
i `validatedAt` Allegro; **Szkic do poprawy** pokazuje błędy walidacji.
Brak dowodu walidacji pozostaje **Utworzono szkic**, bez obietnicy gotowości.
Reguły kategorii/warunkowe wymagania ostatecznie ocenia Allegro i mogą się
zmieniać do momentu osobnej publikacji. W tej wersji nie uruchamiamy sprzedaży.

Odznaczenie opcji kompletności pozostawia wcześniejsze tworzenie szkiców
roboczych; nie należy traktować ich jako gotowych do publikacji.

## Sygnatura = SKU

Nowe szkice otrzymują `external.id` równy SKU pozycji (do 100 znaków).
Techniczny hash jest wyłącznie kluczem rejestru zapobiegania duplikatom.
Preflight sprawdza SKU i stary klucz `vexlab-hash`, a odczyt dawnych prób
zachowuje kompatybilność i blokadę ponowień.

Dla już utworzonych szkiców: wczytaj tę samą paczkę, zaznacz pozycje i użyj
**Popraw stare sygnatury…**. Osobne potwierdzenie, wyłącznie własne szkice
zarejestrowane lokalnie i INACTIVE. GET potwierdza zgodność wcześniejszego
odcisku, PATCH zawiera tylko `external.id`, następny GET potwierdza SKU.
Brak rejestru, zmieniona treść, obca sygnatura lub aktywna oferta nie są
nadpisywane. Przycisk nie zmienia GPSR, tytułów, zdjęć ani cen wcześniej
utworzonych ofert. Nieznany wynik PATCH/202 ma własny trwały zapis; ponowne
użycie przycisku sprawdza wynik, nie wysyła ślepo kolejnego PATCH.

## Prostszy formularz parametrów

**Wymagane** zawiera pola potrzebne do przygotowania produktu/oferty;
**Dodatkowe** pozostałe parametry. Długie etykiety zawijają się, bez
poziomego przewijania. Role produkt/oferta są w podpowiedziach. SKU/EAN
pozostają automatyczne per pozycja i nie są kopiowane z pierwszego produktu.
Pola automatyczne są nieedytowalne, dopóki nie wybierzesz ręcznej wartości.
Źródła pod **Zaawansowane: zmień źródła wartości**, domyślnie ukryte.

## Zakres i weryfikacja

ADR-066. Bez migracji schematu 11 i nowych zależności. Oryginalny ZIP,
lokalne Produkty, logo, miniatury oraz funkcje 0.42 zachowane. Formularz
ręczny bez paczki i pełna obsługa zamówień/zwrotów prowizji pozostają dalszym
zakresem. Nie wykonywano mutacji rzeczywistego konta właściciela w testach.
Słowniki przygotowane wcześniej na koncie wybiera użytkownik; tworzenie
nowych rejestrów producentów GPSR nie jest ukrytym skutkiem tego formularza.

Testy obejmują wymagane dane, zgodność GET wszystkich pól, utratę danych,
brak scope, paginację, brak POST przy błędzie, sygnaturę SKU nowych szkiców,
naprawę starych, timeout/202, konflikt i aktywne/obce oferty, oba motywy,
DPI i klawiaturę. Syntetyczne podglądy: docs/screenshots/vexlab-*-043-*.

Wyniki wydania: scripts/check.py — 916 testów zaliczonych, 1 pominięty
(natywne DPAPI Windows). Ruff/format, mypy 110 modułów, 7 kontraktów importów,
bandit i diagnostyka poprawne. Audyt runtime i dev: brak znanych podatności.
47 testów GUI przy QT_SCALE_FACTOR=2 zaliczonych, podglądy obu motywów
obejrzane. Rzeczywisty ZIP: 200 ofert, 800 sekcji, brak problemów odczytu,
zachowany hash źródła. Podgląd pobrał 3 unikalne zdjęcia wybranej oferty,
bez zapisu lokalnego i wywołań API konta. Dane/zdjęcia z ZIP-a nie są
częścią dystrybucji. Testy ustawień i zapisów wykonano na odpowiedziach
kontrolowanych, nie na rzeczywistym koncie właściciela.
