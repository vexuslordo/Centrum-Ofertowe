# VexLab 0.30.2 — kompaktowy pasek produktów

Wyszukiwarka o szerokości 186 px i wysokości 36 px stoi bezpośrednio za
producentami w jednym rzędzie. Przyciski filtrów/listy/kafelków mają 36 px.
Pozostałe miejsce pozostaje po prawej stronie. Przy bardzo wąskim panelu
narzędzia przechodzą do drugiego rzędu, zachowując kompaktową szerokość.
Producenci nadal wyłącznie z danych użytkownika. Schemat i zależności bez zmian.
