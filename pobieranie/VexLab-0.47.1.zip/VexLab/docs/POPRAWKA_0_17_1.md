# VexLab 0.17.1 — usuwanie produktów powiązanych ze szkicami

2026-11-06. Przyczyną znalezioną w kodzie była ochrona Produktów z lokalnymi
szkicami: blokowała całą wybraną grupę. Komunikat pokazywał się tylko na
stronie i pasku stanu, więc łatwo było go przeoczyć. Bez bazy użytkownika
nie można potwierdzić, że to jedyna przyczyna jego konkretnego przypadku.

Usuń zaznaczone i Usuń wszystkie wyniki zachowują potwierdzenie i kopię.
Jeśli blokują szkice, pojawia się drugie pytanie z liczbą Produktów i
powiązanych lokalnych szkiców. Tak usuwa obie grupy atomowo, Nie pozostawia
wszystko. Inne błędy pokazują wyraźne okno zamiast samej etykiety.
Zdalne oferty/szkice nie są usuwane. Cenniki i producenci pozostają.

Zakres Produktów nie rozszerza się po zmianie filtra. Migawka wersji szkiców
chroni przed usunięciem treści zmienionej/dodanej po potwierdzeniu. Przed
zapisem spójna kopia w kopie_usuwania; błąd cofa szkice i Produkty. Aby
przywrócić dane, zamknij program i odtwórz kopię w osobnym katalogu danych.
Schemat 9 bez migracji. Decyzja ADR-044, brak zmian danych podczas startu.

Kontrola scripts/check.py oraz audyt zależności; dodatkowe testy wspólnego
usuwania, anulowania, zakresu, konfliktów, rollback i odtworzenia kopii.
Odbiór na Windows i audyt techniczny/UX 1.0 nadal osobnymi zadaniami.
