# Przyrost 0.18 — cenniki, EAN, szybkie akcje i zdjęcia

2026-11-06. Wersja developerska 0.18.0.dev0; odbiór na Windows pozostaje
po stronie użytkownika. Integracje Allegro, PrestaShop i Subiekt nie są wdrożone.

## Scenariusze użytkownika

- Cennik ma opcjonalną kolumnę EAN. Kod jest tekstem EAN-8/EAN-13 z kontrolą
  cyfry kontrolnej; brak jest poprawny, zera wiodące pozostają. Błędny kod
  trafia do poprawy. EAN jest także w formularzu i szczegółach Produktu i CSV.
- Zapis cennika czyści kreator, wskazanie pliku i podgląd. Zapisany dokument
  pozostaje w bibliotece, a oryginalny plik na dysku.
- Nowy cennik ma status Nowy. Więcej → Ustaw jako bazowy oznacza wybrany
  dokument jako Aktualny / bazowy dla producenta. Archiwalny oznacza jawnie
  zarchiwizowany lub zastąpiony dokument. Stare nieaktywne wpisy bez informacji
  o archiwizacji pokazują Nowy; program nie zgaduje wcześniejszej decyzji.
- Bazowa pochodzi z wybranego aktualnego cennika producenta, również bez
  produktu w katalogu. Różnica wymaga zgodnej waluty i netto/brutto. Brak
  ceny, niejednoznaczne SKU albo brak wyboru dają neutralne wyjaśnienie.
- Więcej / PPM → Aktualizuj cennik… zapisuje nowe wydanie, zachowując stare.
  Bazowa pokazuje stare wydanie, Cennik nowe, Różnica kwotę i procent, np.
  100 → 120 daje +20 (+20%). Jeżeli stary był aktualny, nowe przejmuje ten
  status atomowo; porównanie historyczne pozostaje. Usunięcie starego wydania
  powoduje jawny brak porównania, a nie porównanie nowego ze sobą.
- Kliknięcie komórki Do poprawy pokazuje przyczynę i źródłowy wiersz; przy
  duplikacie SKU także pozostałe wiersze. Sam podgląd niczego nie zapisuje.
- Ceny XLSX uwzględniają precyzję wspieranych formatów liczbowych, np.
  zapisane 830.245 przy formacie 0.00 daje 830.25. Formuły nie są wykonywane;
  ich zapisany wynik wymaga istniejącej jawnej zgody w imporcie. General nie
  określa precyzji; nieobsługiwane formaty wymagają tekstowej kwoty. To nie
  jest pełny silnik formatowania Excela ani gwarancja aktualności jego cache.
- Dashboard → Szybkie akcje → Edytuj: wybór, ukrycie, przeciąganie kolejności,
  przywrócenie domyślnych. Zapis w ustawieniach użytkownika; Anuluj nie zmienia
  wyboru. Funkcje przyszłe pozostają oznaczone jako niedostępne.
- Produkty → zaznacz pozycje (można wszystkie) → Więcej / PPM → Pobierz zdjęcia…:
  własny adres producenta i limit nowych danych, po jednym zdjęciu na SKU,
  bez zastępowania galerii. Postęp, zatrzymanie i raport błędów. Publiczny
  katalog Shopify i jednoznaczne SKU są wymagane; domeny nie są zaszyte.
  Domyślny limit 256 MB można zmienić (1–4096 MB). Dotyczy nowych danych zdjęć,
  nie całej bazy, transferu i kopii. Przed pierwszym zapisem powstaje jedna
  kopia bazy na serię. Każdy produkt ma oddzielny atomowy zapis; anulowanie
  zachowuje ukończone produkty. Trzy kolejne błędy zatrzymują serię.

## Dane i zgodność

Schemat 10 dodaje opcjonalne EAN, jawne archiwum i odniesienie do poprzedniego
wydania. Migracja z kopią i transakcją; opublikowane migracje 1–9 pozostają
bez zmian. Odniesienie historyczne jest słabe, aby pozwalać usuwać cenniki;
interfejs ostrzega o utracie porównania. Brak automatycznego usuwania danych,
kopii, zakładania producentów lub zapisu w kanałach.

## Weryfikacja i ograniczenia

Kontrole i audyt opisuje [raport techniczny](AUDYT_TECHNICZNY_0_18.md).
Testy korzystają wyłącznie z izolowanych baz i danych syntetycznych.
Nie potwierdzono działania na żywo ze stroną Evotech ani odbioru na Windows.
Nie wdrożono automatycznych profili cenników: to nadal propozycja.
Zamówienia Allegro/PrestaShop oraz edycja zdalnych szkiców są zapisane
w ROADMAP jako przyszłe etapy, bez fikcyjnego połączenia w bieżącej wersji.

### Wyniki końcowe

- `scripts/check.py`: 432 testy zaliczone, ruff/format, mypy (62 moduły),
  siedem kontraktów importów, Bandit i diagnostyka — powodzenie.
- Po poprawce wizualnej kolejności kolumn ponownie: 11 testów strony Cenniki,
  a przy skali 150% 13 testów cenników i dialogu zdjęć — powodzenie.
  Nowy test kolejności uzupełnia pełny zestaw o jeden scenariusz.
- Audyt zależności runtime i dev: brak znanych podatności w sprawdzonych
  wersjach. Budowa wheel i sdist offline — powodzenie.
- Zrzuty Cenników: ciemny/jasny motyw i wąskie okno, dane syntetyczne;
  Stan po lewej, Różnica po prawej. To odbiór Linux/offscreen, nie Windows.
