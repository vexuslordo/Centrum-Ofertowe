# Etap roboczy opisu 0.5.2

Poprawka laczenia opisu, dodatkowej kolumny i pelnej nazwy zrodlowej zostala
wlaczona do przyrostu 0.6, bez osobnego wydania 0.5.2. Biezaca instrukcja:
[Praca z katalogiem 0.6](PRACA_Z_KATALOGIEM_0_6.md). Raport:
[RAPORT_PRZYROST_0_6](RAPORT_PRZYROST_0_6.md).
