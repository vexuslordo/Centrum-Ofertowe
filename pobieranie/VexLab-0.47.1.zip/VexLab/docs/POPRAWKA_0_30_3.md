# VexLab 0.30.3 — wyszukiwarka po prawej

Producenci pozostają po lewej. Kompaktowa wyszukiwarka, filtr i przełączniki
widoków są wyrównane do prawej krawędzi panelu. Skorygowano odstępy wewnętrzne
przycisków ikon i pomiar szerokości producentów, aby nie ucinać menu Więcej.
Sprawdzono geometrię przy 420/760/930 px w obu motywach. Dane i schemat bez zmian.
