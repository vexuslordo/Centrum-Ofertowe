# Poprawka 0.35.1 — AI Center i transparentne logo

Polecenie właściciela 2026-11-09, porównanie dwóch wycinków AI Center.
Kafelki mają ciemne gradienty z delikatnym akcentem zamiast pełnego kolorowego
wypełnienia, pola ikon, tytuł, wartość i miejsce na zmianę. Pierwszy kafelek
ma fioletową ramkę. Układ 2+2+1, kompaktowy nagłówek i „Otwórz kreatora”
zamiast dolnego rzędu trzech przycisków. Przycisk otwiera istniejący moduł
opisów AI, który nadal jest w przygotowaniu; nie uruchamia płatnego API.

Liczby braków opisu/zdjęć pochodzą z lokalnego katalogu. Wygenerowane opisy,
SEO, optymalizacje i zmiany okresowe pozostają — bez niepotwierdzonych danych.
Nie skopiowano liczb 187/54/39 ani procentów z referencji.

Logo VEX było już plikiem PNG z kanałem alfa; renderer dodawał pod nim czarną
płytkę. Usunięto tę płytkę z nagłówka i ikony aplikacji, zachowując zasób,
proporcje i jasny znak. Nowy wygenerowany wariant porządkowania logo został
obejrzany, lecz nie zastępuje oryginału (nie poprawiał jego krawędzi).
Nie ma zmian danych, schematu, zależności ani logowania.

Sprawdzenia: mypy (94 moduły), 5 testów panelu/logo, te same testy przy
skalowaniu 150%, oba motywy i zrzuty 1536×1024 / 900×700. Test logo sprawdza
widoczny znak i rzeczywistą przezroczystość. Paczka ma osobną sumę SHA256.
