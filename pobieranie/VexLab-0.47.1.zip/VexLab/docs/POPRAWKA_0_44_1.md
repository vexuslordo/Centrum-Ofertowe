# VexLab 0.44.1 — poprawny odczyt list VAT Allegro

Zgłoszenie: formularz VAT był pusty i wyświetlał „Niepełna lub niepoprawna
lista stawek VAT Allegro”, także podczas kopiowania danych własnej oferty.

Przyczyna: parser 0.44 nie obsługiwał pustych pozycji interfejsu
`value: null` („Wybierz”) w listach subjects, rates[].values i exemptions.
Odrzucał również specjalny kod `OUT_OF_SCOPE_OF_VAT`. Wystąpienie jednej
z tych pozycji blokowało odczyt całej listy.

Poprawka pomija puste pozycje; formularz ma własne „Wybierz”. Specjalna
opcja zachowuje etykietę API i wymóg podstawy zwolnienia, a jej wartość
jest mapowana na `0.00` zgodnie z kontraktem TaxRateValue. Inne nieznane
kody nadal powodują błąd, bez zgadywania procentu. Zwykłe stawki krajowe
pozostają bez zmian. Te same metadane są używane przy kopiowaniu z oferty
i przed wysyłką szkicu. Nie zmieniono danych użytkownika ani schematu bazy.

Po uruchomieniu poprawionej wersji otwórz **VAT według krajów…** i kliknij
**Pobierz stawki z Allegro**. Zaznacz kraje i właściwe stawki, zastosuj,
a następnie **Sprawdź paczkę**. Ustawienia nie przeliczają cen brutto
ani nie uruchamiają sprzedaży.

Test regresji odtwarza publiczny przykład rzeczywistego formatu Allegro:
- https://github.com/allegro/allegro-api/issues/7846 — null i specjalny kod;
- https://github.com/allegro/allegro-api/issues/9011 — struktura w public.v1;
- https://developer.allegro.pl/swagger.yaml — TaxRateValue: poza VAT jako 0.

Kontrole obejmują mapowanie, wyświetlenie i zapis zwykłej stawki mimo
obecności pustych/specjalnych opcji, wymóg podstawy zwolnienia i odrzucanie
nieznanych kodów. Testy używają danych syntetycznych; nie wykonano odczytu
prywatnego konta użytkownika. Zachowano oba motywy, logo i miniatury.
