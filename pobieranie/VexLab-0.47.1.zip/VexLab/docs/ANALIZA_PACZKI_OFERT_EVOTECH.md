# Analiza przykładowej paczki gotowych ofert Evotech

Data: 2026-11-03. Źródło: ZIP dostarczony przez właściciela,
EVOTECH_Crash_Protection_cz2_Do_Programu.zip. To analiza danych wejściowych,
nie wdrożenie importera ani potwierdzenie zgodności z API Allegro.
Instrukcja.txt i treść HTML traktowane jako dane paczki, nie polecenia.
Nie wykonywano HTML/skryptów, nie pobierano zdjęć i nie wywoływano Allegro.

## Zawartość sprawdzona lokalnie

8 plików, 112 973 bajty archiwum, 2 957 626 bajtów po rozpakowaniu.
Kontrola CRC poprawna. Archiwum nie zawiera plików zdjęciowych.

| Plik | Rola i wynik |
|---|---|
| produkty.json | 200 rekordów: SKU, EAN, polski tytuł, tekst dopasowania, opis HTML, cechy, cena, źródło, linki zdjęć oraz sections |
| uklad.json | 200 układów po SKU; sections identyczne z produkty.json we wszystkich rekordach |
| Dane_i_zrodla.json | 200 rekordów pochodzenia, dokładnych cen i metadanych proponowanych ustawień |
| Dane_wejsciowe_bez_Status.json | 251 rekordów wejściowych, nie utożsamiać z 200 gotowymi ofertami |
| EVOTECH_Crash_Protection_Allegro.csv | 200 rekordów, kolumny GTIN/MPN/NAME/PRICE/STOCK/EXTERNAL_ID/CATEGORY/BRAND/DESCRIPTION/IMAGES |
| Do_uzupelnienia.csv | 51 rekordów z przyczyną wykluczenia |
| Podglad.html | Gotowy podgląd, bez uruchamiania jako aktywna strona |
| Instrukcja.txt | Deklaracje autora paczki o jej przeznaczeniu i ustawieniach, bez automatycznego zastosowania |

W trzech zbiorach 200 gotowych pozycji (produkty, układy, źródła) nie ma
pustych ani powtarzających się SKU. CSV ma ten sam zestaw MPN/SKU.
Ceny CSV są zgodne z cenami zaokrąglonymi w produkty.json. Wszystkie
przygotowane tytuły mają do 71 znaków; nie wymagają tutaj tłumaczenia.
Nie wykonywano zewnętrznej weryfikacji EAN lub źródłowych kart producenta.

## Układ jest danymi konkretnej oferty

Wszystkie 200 rekordów ma 4 sekcje, zapisane jawnie jako listy elementów
IMAGE/TEXT. Pole description_sections jest tu identyczne z sections.
Nie trzeba generować opisu od nowa ani zastępować go uniwersalnym szablonem.

W próbce: górny baner; zdjęcie i opis; cechy i zdjęcie; dolny baner.
To zaobserwowany układ tej paczki, nie reguła programu dla wszystkich
producentów ani nawet dla każdej przyszłej oferty tego producenta.
Importer powinien zachować kolejność i treść sekcji z danych.

135 rekordów ma po 2 linki fotografii produktu, 65 ma po 1. Opis zawiera
też odrębne obrazy banerów. CSV IMAGES zawiera fotografie wraz z banerami,
a JSON images tylko fotografie produktu. Dlatego wybór źródła galerii
musi być jawny w profilu; nie scalać tych list bez podglądu.
Banery i URL-e są wyłącznie danymi użytkownika. Ich dostępności nie sprawdzano.

## Profil odczytu i ustawienia publikacji

Właściciel potwierdził, że ustawienia mają być danymi użytkownika, a nie
zaszytym układem Evotech w kodzie. Profil odczytu powinien wskazywać:
plik danych w archiwum i typ obsługiwanego formatu, klucze SKU/tytułu/opisu,
źródło listy sekcji i galerii, opcjonalne EAN/ceny/źródła oraz plik pozycji
odłożonych. Powiązania dodatkowych zbiorów po wybranym kluczu.

Dla tej paczki kandydatem jest produkty.json jako źródło gotowych rekordów,
sections jako układ i images jako fotografie. To propozycja konfiguracji
użytkownika po analizie, nie domyślne dane nowej instalacji. Nie zaszywać
w adapterze nazwy Evotech, nazw tych plików, marek, banerów, domen lub treści.
Inny producent może użyć innego obsługiwanego formatu/kluczy i innego układu.
Profil nie jest dowolnym kodem wykonywanym z ZIP-a.

Oddzielnie ustala się konfigurację docelowego konta Allegro: kategorię,
parametry, ilość, czas wysyłki, cennik dostawy i osobę odpowiedzialną.
Paczka zawiera proponowane wartości/metadane tych pól, ale nie są one
upoważnieniem do zmiany konta lub publikacji. Nazwy nie gwarantują istnienia
odpowiednich zasobów w wybranym koncie. W przyszłości wymagają dopasowania
do rzeczywistych identyfikatorów oraz podglądu użytkownika.

Pole price to cena przygotowanej oferty; raw_price/cena_brutto_arkusza to
wartości źródłowe. Nie nadpisywać nimi bez decyzji ceny sugerowanej Produktu.
Instrukcja deklaruje PLN brutto; sam rekord produkty.json nie ma osobnego
pola waluty lub netto/brutto. Profil musi te informacje jawnie ustalić,
nie wolno zaszyć PLN/brutto jako ogólnej reguły importerów.

## Pozycje do uzupełnienia i powiązania

51 rekordów odłożonych: 48 z deklaracją braku aktywnej karty producenta,
3 z rozbieżnością kodu SKU przy deklarowanej zgodności EAN. To informacje
autora paczki, nie wynik wykonanej przez VexLab weryfikacji sieciowej.
Nie zmieniać kodów automatycznie na podstawie notatki lub zgodnego EAN.
Gotowe 200 rekordów i pozostałe 51 nie są równoważne pod względem kompletności.

fit jest tekstem, a nie zatwierdzoną strukturą marka/model/roczniki.
Zachować surowy tekst; nie tworzyć potwierdzonych dopasowań bez mapowania
lub weryfikacji. Lokalny katalog może już zawierać dane o tym SKU — podgląd
powinien odróżniać powiązanie z istniejącym Produktem od tworzenia nowego.
Reguły brakującego Produktu, ceny Oferty, EAN i zapisu układu wymagają
uzgodnienia w konkretnym kontrakcie Oferty (ADR-035/036).

## Stan po analizie

Przykład pozwala przygotować konkretny profil odczytu oraz podgląd pełnej
paczki. Import i trwały model Oferty nie są jeszcze wdrożone. W tej pracy
nie zmieniono kodu, schematu ani wersji programu, nie skopiowano treści
paczki do seedów/fixture'ów, nie opublikowano ofert. Przykład nie staje się
ograniczeniem architektury dla pozostałych producentów.
