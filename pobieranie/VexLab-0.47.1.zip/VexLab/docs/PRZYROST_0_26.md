# VexLab 0.26 — Allegro: Ustawienia i zapamiętane połączenie

2026-11-08. Polecenie właściciela: konfiguracja API w Ustawieniach,
zapamiętanie połączenia. Zakładka Allegro ma docelowo skupiać wszystkie działania
kanału, od nowych zamówień po oferty. ADR-054. Schemat 11 bez migracji;
brak nowych zależności. Brak zapisów ofert i publikacji w tym przyroście.

## Obsługa

Ustawienia → Integracje → Allegro — połączenie konta. Wybierz właściwe
środowisko, wpisz dane aplikacji Device Flow i połącz jak dotychczas.
Na Windows zaznaczone domyślnie Zapamiętaj połączenie na tym komputerze.
Dane nie są wysyłane do VexLab ani umieszczane w repozytorium; autoryzacja
odbywa się bezpośrednio z Allegro. Nie przekazuj sekretów w rozmowie.

Po restarcie VexLab odczytuje zapis w tle, odnawia token i potwierdza konto
przez /me. Dopiero wtedy pokazuje Połączono i pobiera stronę szkiców.
Przy wygaśnięciu access tokenu zapisane połączenie odnawia się automatycznie.
Nie ma cyklicznego pobierania całego konta ani automatycznej publikacji.

Brak sieci nie usuwa zapisu. W Ustawieniach użyj Wznów zapisane połączenie.
Po cofnięciu zgody lub błędnych danych wybierz Rozłącz i zapomnij, następnie
połącz ponownie. Rozłączenie usuwa lokalny zapis, nie odwołuje zgody w panelu
Allegro. Błąd usuwania jest widoczny i pozwala ponowić. Zamknięcie programu
zachowuje zapamiętanie. Odznaczona opcja daje połączenie tylko do zamknięcia.

Zakładka Sprzedaż → Allegro pozostaje przestrzenią operacji. Obecnie jest
lista szkiców i skrót do Ustawień. Zamówienia, pełny podgląd, edycja szkiców,
aktywne oferty, ceny, stany i pozostałe działania są kolejnymi etapami wspólnego
obszaru Allegro, a nie ustawieniami połączenia. Nie dodano fikcyjnych odczytów
lub liczników. Wspólny przyszły widok zamówień Allegro/PrestaShop pozostaje.

## Ochrona danych i ograniczenia

Port MagazynAllegro używa Windows DPAPI w zakresie bieżącego użytkownika.
Plik `polaczenia/allegro.dpapi` w katalogu danych zawiera wyłącznie szyfrogram.
Przed zapisaniem do pliku tymczasowego następuje szyfrowanie; finalizacja przez
atomowy replace. Limit odczytu 128 KiB, format wewnętrzny 1. Baza i preferencje
nie zawierają sekretów. Pakowanie wyklucza .dpapi. Kopia SQLite nie jest kopią
połączenia; przeniesienie programu na inny komputer/użytkownika wymaga
ponownego logowania. To nie jest ochrona przed procesem działającym jako
zalogowany użytkownik Windows ani gwarancja fizycznego wyzerowania pamięci.

Zapisano dane aplikacji, środowisko, ID/login konta i refresh token. Access
token nie jest utrwalany. Rotujący refresh token zapisywany przed odczytem
profilu, aby awaria /me go nie zgubiła. Brak nowego refresh w odpowiedzi zachowuje
poprzedni. Inny zwrócony ID konta blokuje sukces. Nieudany zapis nowej sesji
daje jawnie sesję bez zapamiętania; awaria odnowienia/utrwalenia nie udaje
trwałego sukcesu. Blokada serializuje odnowienie i zapomnienie w jednej instancji programu.
Jednoczesne odnawianie tego samego zapisu przez kilka procesów nie jest
obsługiwane; przed uruchomieniem nowej wersji zamknij poprzednią.

Na systemach innych niż Windows zapamiętywanie jest wyłączone; nie ma jawnego
pliku zastępczego. Testy na Linux nie zastępują odbioru DPAPI na Windows ani
żywego Allegro. Dołączono osobny test natywny uruchamiany tylko na Windows.

## Wyniki weryfikacji

`scripts/check.py`: 608 testów zaliczonych, jeden natywny test DPAPI pominięty
na Linux; ruff/format, mypy 83 modułów, siedem kontraktów importów, Bandit
i diagnostyka poprawne. Mypy z platformą win32 również poprawne. Przy skali
150% dziesięć testów GUI Allegro zaliczonych. Test okna sprawdza przeniesienie
pól do Ustawień, pracę poza wątkiem Qt oraz ponowne otwarcie z zachowanym
połączeniem na symulowanym API/magazynie. Testy sprawdzają atomowość zapisu,
brak jawnego pliku tymczasowego, rotację mimo błędu /me i serializację usunięcia.

Obejrzano Ustawienia i Allegro w obu motywach 1536×1024 oraz 900×700.
Zrzuty `docs/screenshots/vexlab-allegro-026-*.png` wykorzystują pusty magazyn
wizualny, bez połączenia na żywo i bez sekretów. Audyt runtime/dev nie wykazał
znanych podatności w chwili sprawdzenia. Wheel/sdist zbudowane offline.
Natywne DPAPI i rzeczywista autoryzacja nadal wymagają odbioru na laptopie.
