# VexLab — lokalne dane i kopie

Katalog zawiera dane użytkownika. Trzymaj go poza repozytorium i katalogiem
instalacji. Domyślną lokalizację wybiera Qt `AppLocalDataLocation` dla VexLab.
Możesz jawnie wybrać inną lokalizację podczas startu:

```powershell
uv run --frozen python -m vexlab --katalog-danych "C:\Dane\VexLab"
```

Pliki: `katalog.sqlite3` (Produkty, Producenci i techniczny rejestr schematu),
`preferencje.ini` (motyw i szerokość menu). Nowa baza nie zawiera
przykładowych Produktów, kont, producentów ani cenników.
Nie udostępniaj tej bazy testom automatycznym.

## Tworzenie kopii

W aplikacji otwórz Ustawienia → Utwórz kopię katalogu. Wybierz nowy plik
poza aktywną bazą. Istniejących plików VexLab nie nadpisuje. Komunikat
o powodzeniu pojawia się dopiero po wykonaniu kopii SQLite i kontroli
jej integralności. Kopia obejmuje katalog, nie ustawienia wyglądu.
Skopiowanie otwartego pliku bazy zwykłym kopiowaniem nie zastępuje tej funkcji.

## Sprawdzenie i odtworzenie

1. Zakończ zapis i zamknij wszystkie instancje VexLab korzystające z katalogu.
2. Zachowaj oryginalny katalog danych w osobnym miejscu; nie usuwaj bazy
   z błędem. Nie nadpisuj jedynej kopii pliku.
3. Utwórz nowy pusty katalog do odtworzenia. Umieść w nim kopię pod nazwą
   `katalog.sqlite3`. Użyj wersji VexLab zgodnej ze schematem kopii.
4. Uruchom VexLab z `--katalog-danych` wskazującym **nowy** katalog.
   Sprawdź listę, SKU i opisy własnych Produktów oraz brak błędu wersji.
5. Dopiero po sprawdzeniu używaj nowego katalogu do dalszej pracy.
   Zachowaj poprzedni plik do wyjaśnienia awarii.

Odtworzenie starszej kopii nie zawiera zmian wykonanych po jej utworzeniu.
Wersje 0.3/0.4 używały schematu 2. Bieżąca 0.5 używa schematu 3
i aktualizuje znane schematy 1 i 2. Nie aktualizuje obcych tabel,
nieznanych nowszych wersji ani uszkodzonych plików i nie resetuje ich
automatycznie. Przed przyszłą zmianą schematu potrzebne będą opis
kompatybilności, kopia i test migracji. Nie ma gwarantowanej migracji w dół.

## Aktualizacja 0.2 → 0.3

Zamknij poprzednie okna, rozpakuj nowy ZIP do osobnego folderu i uruchom
`Uruchom VexLab.cmd`. Domyślna lokalizacja danych nie zmieniła się.
Przed zmianą istniejącej bazy schematu 1 program wykonuje spójną kopię do
podfolderu `kopie_migracji` obok bazy, z unikalną nazwą pliku. Sprawdza
integralność kopii. Jeśli kopia się nie powiedzie, nie wykonuje migracji.

Migracja zachowuje ID, nazwy, SKU, opisy i wersje dotychczasowych Produktów.
Producent pozostaje nieprzypisany, bez domyślnego rekordu. Cała zmiana schematu
jest transakcyjna. Po aktualizacji wersja 0.2 nie obsłuży schematu 2.
Ewentualny powrót wymaga kopii sprzed aktualizacji umieszczonej w nowym katalogu
z wersją 0.2 i parametrem `--katalog-danych`, zamiast nadpisywania obecnych danych.
Kopia sprzed aktualizacji nie obejmuje późniejszych zmian.

## Aktualizacja do 0.5 — schemat 3

Zamknij starszy program, rozpakuj nowy ZIP osobno i uruchom plik CMD.
Miejsce danych się nie zmienia. Przed migracją ze schematu 2 powstaje kopia
ze sprawdzoną integralnością w kopie_migracji. Przy przejściu z 1 zachowana
jest kopia oryginalnego schematu 1. Nieudana kopia blokuje zmianę; przerwana
migracja 2→3 wycofuje nowe tabele i wpis migracji. Nie resetujemy bazy.

Schemat 3 dodaje importy, odłożone mapowane dane i powiązania do Produktów.
Kopia z Ustawień obejmuje również te tabele. Nie zawiera oryginalnych XLSX
ani pominiętych kolumn; zachowaj własny plik źródłowy, jeśli jest potrzebny.
Nowa instalacja nie zawiera cennika Evotech ani innych danych przykładowych.
Wersje 0.2–0.4 nie otworzą schematu 3. Aby wrócić, użyj kopii sprzed zmiany
z odpowiednim starszym programem w nowym katalogu danych. Nie nadpisuj
aktualnej bazy — zmiany wykonane po kopii nie pojawią się w starej wersji.

## Aktualizacja 0.6 — schemat 4

Przy pierwszym starcie 0.6 znany schemat 3 jest kopiowany do kopie_migracji
i transakcyjnie aktualizowany do 4. W starszych 1/2 zachowujemy kopię sprzed
łańcucha migracji. Istniejące Produkty, producenci i Do poprawy pozostają;
nowe ceny, źródła i zdjęcia są puste. Brak kopii blokuje aktualizację.

Schemat 4 zawiera sugerowane ceny źródłowe, robocze pola ceny, opcjonalny
adres producenta i obrazy JPEG/miniatury w SQLite. Kopia katalogu obejmuje
wszystko. Usuwanie, edycja masowa, uzupełnianie cen i zastąpienie zdjęć mają
dodatkowe kopie w podfolderach kopie_usuwania, kopie_edycji_masowej, kopie_cen
i kopie_zdjec. Ich przywrócenie wymaga osobnego katalogu zgodnie z procedurą
powyżej; nie ma automatycznego scalania późniejszych zmian.
Wersje 0.2–0.5 nie otworzą schematu 4; powrót wymaga starej kopii.
Instrukcja zakresu czyszczenia i uzupełniania: PRACA_Z_KATALOGIEM_0_6.md.
