# VexLab 0.13.1 — usuwanie wielu szkiców

Data: 2026-11-05. Polecenie właściciela: możliwość usuwania szkiców.
Rozszerzono dotychczasowe usuwanie pojedynczego wpisu o wybór wielu
oraz czyszczenie bieżących wyników wyszukiwania. Bez nowego modelu,
zmiany schematu 7, zależności lub integracji.

## Obsługa

Szkice → zaznacz wiersze (Ctrl/Shift) → Usuń zaznaczone szkice…
Zaznacz wszystkie wyniki lub Ctrl+A w tabeli wybiera wszystkie aktualne
wyniki. Odznacz usuwa zaznaczenie. Licznik pokazuje zakres wyboru.

Usuń wszystkie wyniki… działa na bieżącym filtrze. Aby wyczyścić wszystkie
lokalne szkice, wyczyść pole wyszukiwania i wybierz tę akcję.
Potwierdzenie podaje liczbę szkiców, zakres oraz informację o pozostawieniu
Produktów i kopii bazy. Domyślna odpowiedź: Nie. Pusta lista niczego nie
usuwa i nie otwiera zbędnego pytania. Do podglądu i edycji trzeba wybrać
jeden szkic; wielokrotne zaznaczenie nie wybiera ukrycie innego celu.

## Bezpieczeństwo i granice

Zakres ID/wersji utrwalany przed potwierdzeniem. Zmiana filtra w jego
trakcie nie rozszerza zakresu. Wpisy dodane później nie są usuwane.
Każda wskazana wersja jest sprawdzana przed pierwszym usunięciem.
Jedna spójna kopia całej bazy w kopie_szkicow i jedna transakcja.
Konflikt, awaria kopii lub błąd usuwania wycofują całą operację.
Po sukcesie widoczna ścieżka kopii i odświeżona lista.

Operacje I/O wykonują się poza wątkiem GUI. Produkty, ich zdjęcia,
ceny, dopasowania, producenci i źródłowe ZIP-y nie są usuwane.
Dotyczy tylko szkiców lokalnych; brak wywołań API Allegro i usuwania zdalnego.
Po usunięciu szkicu można ponownie utworzyć go z oryginalnego ZIP-a.

## Weryfikacja

Testy SQLite: konflikt dowolnego wpisu bez częściowego usunięcia, spójna
kopia ze stanem sprzed usunięcia, restart, brak zmian Produktów, błąd kopii
oraz awaria podczas wykonywania kolejnych usunięć z rollbackiem.
Test GUI: wybór wielu, anulowanie, Ctrl+A, odznaczenie, licznik, filtrowanie,
zakres uchwycony przed potwierdzeniem, pozostawienie szkiców poza filtrem,
czyszczenie całej listy i pusta lista. Testy offscreen nie zastępują
odbioru Windows/DPI ani obowiązkowego audytu kandydata 1.0.

Z rozpakowanej paczki źródłowej przeszły 23 testy szkiców i usuwania
w GUI. Sprawdzono CRC, brak baz/paczek użytkownika w dystrybucji oraz
zgodność schematu/migracji z 0.13. Zbudowano wheel i sdist offline.

Rzeczywista paczka użytkownika na izolowanej bazie: usunięcie 100 z 200
szkiców, a następnie pozostałych 100. Wszystkie 200 Produktów i ich dane
pozostały niezmienione. Źródłowy ZIP pozostał bez zmian.

Pełna kontrola wydania: **321 testów przeszło** (242,35 s), Ruff,
formatowanie, strict mypy (50 plików), siedem kontraktów importów,
Bandit oraz diagnostyka techniczna zakończone poprawnie.

Zapisano osobne zrzuty strony Szkice w obu motywach, na pustym izolowanym
widoku. Pełny generator wielostronicowy capture_ui nie ukończył próby w
limicie 10 s; przerwanie powodowało błąd sygnału po usunięciu obiektów Qt.
To ograniczenie narzędzia zrzutów wymaga diagnostyki przy audycie 1.0;
nie przedstawia się tej próby jako zakończonego odbioru całej powłoki.
