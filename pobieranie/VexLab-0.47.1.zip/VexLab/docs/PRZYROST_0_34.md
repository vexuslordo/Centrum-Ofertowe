# VexLab 0.34 — płaskie przyciski i logo VEX

Wspólny styl przycisków: jednolite tło, cienkie obramowanie, promień 6 px,
kompaktowe odstępy i ikony 16 px. Główna akcja ma płaski niebieski kolor.
Zmiana obejmuje formularze, paski akcji, okna dialogowe, szybkie akcje,
filtry producentów i malowane przyciski w katalogu. Widoczny fokus klawiatury,
hover/pressed/disabled zachowane, bez zmiany wywoływanych operacji.
Przyciski ikon zachowują kwadratowe pola 36 px; karty szybkich akcji nadal
mieszczą dwa wiersze tekstu. Jasny i ciemny motyw zachowane.

Nowe logo VEX w nagłówku i ikonie okna zamiast herbu. Ten sam znak renderowany
z zachowaniem proporcji na ciemnym polu, czytelny także w jasnym motywie.
Nazwa programu VexLab bez zmian. Zasób i pochodzenie: assets/VEX_LOGO.md.
Zawiera też kolorowe kafelki Allegro z poprawki 0.33.1.
Dane, sesja Allegro, schemat 11 i zależności bez zmian.

## Weryfikacja

Pełny scripts/check.py: 665 testów zaliczonych, 1 pominięty (natywne DPAPI
wymaga Windows), ruff/format, mypy 92 moduły, 7 kontraktów, Bandit i diagnostyka
bez błędów. Po dopasowaniu testu wymiarów ikony do DPR zaliczono 11 testów
logo/przycisków/filtrów przy 150%; test sprawdza rzeczywiste białe piksele znaku
i ciemne tło, a nie sam fakt istnienia pliku. Mypy win32 poprawne.
Obejrzano nowe logo i style w obu motywach oraz przy 900×700;
zrzuty docs/screenshots/vexlab-ui-034-*.png mają dane syntetyczne.
