# VexLab 0.40 — ZIP → nowe szkice Allegro

2026-11-12. Właściciel potwierdził działanie 0.39.1 i zlecił następny etap.
Źródła bazowe pochodzą z potwierdzonego ZIP-a 0.39.1, nie z main.
Decyzja i granice: [ADR-061](adr/ADR-061-tworzenie-szkicow-z-zip.md).

## Jak używać

1. Połącz konto w Ustawienia → Integracje → Allegro. Jeśli zgody na zapis
   jeszcze nie ma, zaznacz „Zezwól na zapis i tworzenie szkiców” i wybierz
   Zmień uprawnienia. Istniejąca zgoda offers:write pozostaje wystarczająca.
2. Nowe oferty → otwórz ZIP dotychczasowym profilem → Oferty z paczki →
   **Przygotuj szkice w Allegro…**. Nie trzeba zapisywać lokalnych szkiców.
3. Jawnie wybierz walutę cen brutto i ilość w każdym szkicu. Ceny pochodzą
   z mapowanego pola paczki; nie zgadujemy waluty ani przeliczeń netto/brutto.
4. **Sprawdź paczkę** wykonuje odczyty katalogu i wymagań kategorii. Jedyny
   pełny wynik wyszukiwania po prawidłowym EAN jest proponowany w planie.
   Sprawdź nazwę dopasowanego produktu przed zatwierdzeniem.
5. Dla braku/niejednoznacznego dopasowania wybierz wiersz → **Wybierz produkt
   Allegro…** → wyszukaj po EAN/nazwie i wskaż właściwą istniejącą kartotekę.
   Następnie **Uzupełnij wybraną…**: popraw cenę lub wprowadź wartości parametrów
   pobranych z rzeczywistej kategorii. Zastosowanie ponownie sprawdza plan.
6. **Utwórz szkice w Allegro…** pokazuje konto, środowisko, liczbę pozycji,
   walutę i ilość. Domyślne potwierdzenie to Nie. Wysyłane są tylko pozycje
   oznaczone jako gotowe; pozostałe pozostają w raporcie z przyczyną.
7. Zdjęcia trafiają na serwer Allegro, a ich nowe adresy do galerii i sekcji
   opisu. Tworzenie wysyła jawnie `INACTIVE` i `republish=false`.
   **Nie publikuje ofert do sprzedaży.**
8. Raport pokazuje stan każdej pozycji i ID Allegro. Wybór wiersza wyświetla
   szczegóły błędu/uwag. **Eksportuj raport…** zapisuje nowy CSV z kontem,
   środowiskiem, SKU, ID i wynikiem. Istniejący plik nie jest nadpisywany;
   komórki mogące być formułą arkusza są zabezpieczane.
9. Nowe pozycje można zobaczyć w Allegro → Szkice po odświeżeniu listy.

Zatrzymaj serię / zamknięcie podczas pracy zatrzymuje kolejne żądania i czeka
na raport. Żądania już wysłanego nie cofa. Zmiana/wygaśnięcie sesji blokuje
kolejne wysyłki; dotychczasowy raport można wyeksportować.

## Co jest sprawdzane

Konto, środowisko, ważność sesji i zgoda zapisu; SKU, tytuł, dodatnia cena
brutto do dwóch miejsc po przecinku, jawna waluta i ilość; poprawność EAN
przy automatycznym dopasowaniu; UUID produktu, rzeczywista kategoria i jej
bezwarunkowo wymagane parametry ofertowe; wartości słownikowe/liczbowe;
1–16 unikalnych zdjęć HTTPS z galerii/opisu, galeria nie może być pusta;
sekcje po 1–2 elementy i rozmiar opisu. Powtórzone SKU w jednej paczce są
blokowane przed tworzeniem. Przed wysyłką ponownie odczytujemy produkt i
wymagania; ich zmiana wymaga ponownego przygotowania planu.

Każde zdjęcie jest przesyłane raz dla pozycji, także gdy występuje w galerii
i wielu sekcjach. Kolejność galerii i sekcji jest zachowana; zdjęcia użyte
wyłącznie w opisie nie są dopisywane do galerii. Lokalna treść ZIP bez zmian.

## Wynik nieznany i ponowne otwarcie

Trwały rejestr w katalogu danych `tworzenie_allegro` zawiera skróty danych,
ID i identyfikator operacji — bez tokenów i treści opisów. Zachowaj ten folder
w kopiach danych aplikacji. Nie usuwaj plików, żeby „odblokować” ponowienie.

Klucz obejmuje konto/środowisko/SKU. W tym procesie nie tworzymy drugiej oferty
tego samego SKU, nawet po zmianie paczki. To celowa konserwatywna ochrona;
nie zmienia modelu Produktu ani prawa do wielu Ofert w przyszłych procesach.
`external.id` jest deterministyczny, a rezerwacja następuje przed POST.

- 201 wymaga GET i zgodności pól, parametrów oraz statusu INACTIVE.
- 202 oznacza przetwarzanie; **Sprawdź wyniki wysyłki** ręcznie sprawdza
  operację z uwzględnieniem Retry-After, a następnie treść szkicu.
- Timeout, 5xx, nieudokumentowana odpowiedź lub awaria metadanych pozostawiają
  blokadę. Nie ma automatycznego ponowienia POST.
- Po restarcie otwórz tę samą paczkę z tymi samymi ustawieniami i wybierz
  sprawdzenie wyniku. Nie trzeba ponownie przesyłać zdjęć.
- Jeśli po awarii brakuje informacji o przyjęciu/operacji, zgodny znaleziony
  szkic jest wskazany, ale nie ogłaszamy zakończenia zlecenia. Zachowaj raport
  i zweryfikuj stan w Allegro; ta wersja nie ma opcji wymuszania/odblokowania.
- Znana odmowa danych/autoryzacji/limitu nie jest sukcesem. Po poprawieniu
  przyczyny można wykonać kolejną jawną próbę. Nieznany wynik nią nie jest.

## Zakres pierwszej wersji i ograniczenia

Obsługujemy obecne profile JSON w ZIP i obrazy wskazane linkami HTTPS.
Nie odgadujemy nowego układu plików ani lokalnych nazw zdjęć w archiwum.
Nie tworzymy nowych produktów Katalogu Allegro, VexLab ani Subiekta.
Brak istniejącego produktu w Allegro wymaga osobnego przyszłego procesu.

Parametry produktowe pobiera Allegro z istniejącej kartoteki. Edytor obejmuje
pojedyncze wartości słownikowe/tekstowe/liczbowe parametrów ofertowych.
Ograniczenia kategorii, parametry warunkowe/wielowartościowe/zakresowe i HTML
ostatecznie waliduje Allegro. Jeśli serwer je odrzuci, raport podaje przyczynę;
nie udajemy pełnej lokalnej walidacji wszystkich kategorii.

Braki w dostawie, GPSR i innych ustawieniach potrzebnych do sprzedaży nie są
wypełniane fikcyjnymi danymi. Mogą wymagać konfiguracji konta lub uzupełnienia
szkicu w Allegro; uwagi/błędy walidacji z GET są przekazywane do raportu.
Utworzony INACTIVE **nie oznacza gotowości do publikacji**. Publikacja będzie
oddzielną, potwierdzaną operacją; ta wersja nie wysyła jej poleceń.

Nie wykonano rzeczywistych tworzeń na koncie właściciela. Testy transportu
korzystają z kontrolowanych odpowiedzi; podglądy ze sztucznych danych.
Odbiór na rzeczywistym koncie zacznij od jednej pozycji i porównaj treść,
zdjęcia, parametry oraz nieaktywny status przed użyciem większej paczki.

## Dane, architektura i dowody

Schemat SQLite 11, istniejące dane i logo/miniatury bez zmian. GUI nie wykonuje
HTTP ani SQL. I/O i seryjne operacje działają przez przypadek użycia w tle.
Nowe porty: APINowychSzkicow/RejestrTworzenia; adapter JSON i kanał API.
Transport dodatkowo blokuje inny status niż INACTIVE, harmonogram,
republish=true oraz pełną definicję nowej kartoteki produktu.

Podglądy w docs/screenshots/vexlab-nowe-szkice-040-dark.png i light.png;
skrypt scripts/capture_nowe_szkice.py nie korzysta z rzeczywistej sieci.
Aktualny Swagger pobrany 2026-11-12, SHA256:
`a58782fa8c9557e953a6e75a754eb4efdd55562856354a03ad593bb1f6dfb9a6`.
Pełny dokument API nie trafia do ZIP-a dystrybucyjnego.

Wynik kontroli 2026-11-12, Linux / Python 3.13.18 / PySide6 6.12.0:

- pełny `scripts/check.py`: **816 passed, 1 skipped**, ruff/format,
  mypy (104 moduły), 7 kontraktów importów, bandit i diagnostyka — sukces;
- po końcowych poprawkach prezentacji/klasyfikacji odpowiedzi: **59 passed**
  w testach nowego procesu, w tym pozytywny bezpiecznik POST/upload;
- Allegro i nowy dialog przy skalowaniu 150%: **38 passed**;
- audyt runtime i dev: brak znanych podatności, blokada uv zgodna;
- ocenione podglądy w obu motywach, zachowane logo i miniatury;
- jedyny pominięty test dotyczy natywnego DPAPI na Windows.

To dowody testów na kontrolowanych odpowiedziach, nie odbiór konta produkcyjnego.
