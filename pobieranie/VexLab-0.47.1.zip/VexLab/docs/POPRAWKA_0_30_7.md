# VexLab 0.30.7 — kolory sekcji menu jak KPI

Nagłówki bocznego menu korzystają ze wspólnej palety PALETA_KPI:
Produkty i Analityka — niebieski, Oferty — zielony, Sprzedaż — pomarańczowy,
Narzędzia — fioletowy. Gradienty i biały tekst jak na dużych kafelkach,
ze stanem najechania i widocznym fokusem. Paleta jest wspólna dla obu motywów.
Układ, nawigacja, dane i schemat bez zmian.
