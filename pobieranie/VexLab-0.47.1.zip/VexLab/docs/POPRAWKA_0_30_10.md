# VexLab 0.30.10 — przyciemnienie 43%

Gradienty kafelków i sekcji menu ustawiono na 57% wartości RGB pierwotnej
palety z 0.30.7, czyli przyciemnienie 43%, bez kumulowania poprzednich zmian.
Biały tekst i kolory ikon zachowane. Bez zmian danych, schematu i zależności.
