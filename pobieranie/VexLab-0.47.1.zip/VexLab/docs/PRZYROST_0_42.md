# VexLab 0.42 — masowe przygotowanie i wyszukiwanie całego konta

Polecenia właściciela 2026-11-13 obejmują trzy scenariusze.

## Masowa edycja w oknie przygotowania szkiców

- Wybór wielu wierszy Ctrl/Shift, „Zaznacz widoczne”, „Odznacz”, licznik
  zaznaczonych i gotowych oraz filtr Wszystkie/Gotowe/Do poprawy.
- „Edytuj zaznaczone…”: zmiana fragmentu tytułu, prefiks/sufiks, cena stała,
  zmiana o procent lub kwotę, ilości. Tylko zaznaczone pola, z podglądem
  wszystkich zmian przed Zastosuj. Cena liczona Decimal, zaokrąglenie 0.01
  HALF_UP. Waluta pozostaje jawnym wspólnym ustawieniem paczki.
- „Nowy produkt w Allegro…” stosuje wybraną kategorię do zaznaczonych pozycji;
  dodatkowa opcja wszystkich niedopasowanych pozostaje dostępna.
- „Parametry zaznaczonych…”: wspólny producent, stan i inne parametry
  pobrane z kategorii API. Wybór pól do zmiany, zachowanie pozostałych
  indywidualnych wartości i źródeł. Zakres wymaga tej samej kategorii i trybu
  istniejący/nowy produkt. Dla różnych kategorii edytuj grupy oddzielnie.
- Po edycji ponowna walidacja. Kolumna ilości pokazuje wyjątki dla każdej
  pozycji. Cena w edycji pojedynczej nadal zmienia tylko bieżący wiersz.
- Wysyłka obejmuje zaznaczone gotowe pozycje; bez zaznaczenia — gotowe
  widoczne pozycje. Zakres i liczba w potwierdzeniu, błędne pomijane.
  Raport zachowuje wyniki pozostałych pozycji, nie traci wyników po wysłaniu
  kolejnej grupy. Zgłoszenie produktu i INACTIVE jak w 0.41; sprzedaż osobno.

Edycja jest robocza w bieżącym oknie. Źródłowy ZIP, lokalne Produkty i SQLite
pozostają niezmienione. Zamknięcie okna usuwa niezapisane przygotowanie;
raport CSV zapisuje wyniki, a nie plik do odtworzenia formularza.

## Automatyczne SKU i EAN

W nowym produkcie EAN/GTIN otrzymuje EAN własnej pozycji paczki; SKU, kod
producenta i numer katalogowy części/producenta — SKU tej pozycji. Źródła
ustawiane automatycznie, widoczne w formularzu, nadal możliwe do zmiany.
Rozpoznawanie jednoznacznych nazw pól po normalizacji, bez zaszytych marek,
kategorii lub identyfikatorów parametrów. Nie mapujemy automatycznie numerów
zamienników, wagi lub strony zabudowy. Nietypowa nazwa wymaga własnego źródła.

Zmiana wspólnego producenta nie kopiuje EAN/SKU pierwszego produktu do
pozostałych. Brak EAN pozostaje pusty; błędna cyfra kontrolna blokuje pozycję.
Jawnie wpisana wartość ma pierwszeństwo przed automatyczną propozycją.

## Lista Allegro na całym koncie

Pole „Szukaj na całym koncie…” + Enter/Szukaj wysyła kryterium do Allegro:
tytuł (tekst), SKU (dokładne external.id) lub ID Allegro. Kryterium łączy się
z wybranym statusem. Wynik obejmuje konto, nie bieżące 50 wierszy; jego
strony i licznik na dole dotyczą znalezionego zakresu. Nie zastępuje KPI
całego konta liczbą znalezionych ofert. Wyczyść przywraca listę bez frazy.

Wybór 50/100/500/1000 na stronę oraz „Wszystkie”. Dla 13 182 ofert tryb
Wszystkie wykonuje 14 odczytów po maks. 1000, po czym pokazuje całą listę.
Postęp i przycisk przerwania, bez prezentowania niepełnego wyniku jako
kompletnego. Zmiana konta lub rozłączenie odrzucają spóźnione wyniki.
Wykryta zmiana liczby rekordów/duplikaty wymagają odświeżenia, nie cichego
pominięcia. API nie zapewnia atomowego obrazu zmieniającego się konta.

Usunięto własny limit 10 000: Swagger dopuszcza offset+limit do 10 000 000.
Tryb Wszystkie w pamięci ma limit 100 000 ofert; większy wynik wymaga
stron lub zawężenia i daje jawny komunikat. Miniatury nadal 64×64 i tylko
dla widocznych rekordów. Budowa tabeli blokuje zbędne sygnały przeliczeń.

ADR-064 i ADR-065. Schemat 11 bez migracji i nowych zależności. Logo, dane
użytkownika, pełny podgląd i dotychczasowe operacje zachowane. Ręczna nowa
oferta bez ZIP-a oraz pełna obsługa zamówień/zwrotów prowizji nadal kolejno.
Testy nie wykonywały zapisów na rzeczywistym koncie właściciela.

## Sprawdzenia wydania

scripts/check.py: 880 testów zaliczonych, jeden pominięty (natywne DPAPI
wymaga Windows); ruff, format, mypy 106 modułów, 7 kontraktów importów,
bandit i diagnostyka poprawne. Audyt zależności runtime i dev: brak znanych
podatności. GUI przy QT_SCALE_FACTOR=2: 45/45 testów. Oba motywy obejrzane
na syntetycznych podglądach w docs/screenshots/vexlab-przygotowanie-042-*.

Testy kontraktu listy pobierają 13 182 oferty, obejmują wyszukiwanie poza
pierwszą stroną, przerwanie, wygaśnięcie sesji, zmienny total, duplikaty
i puste przedwczesne strony. Osobny pomiar tabeli: 13 182 syntetyczne
rekordy zbudowane w 7.42 s w tym środowisku Linux, bez pobierania zdjęć;
czas urządzenia użytkownika i sieci może być inny.

Rzeczywisty ZIP: 200 ofert i 800 sekcji, brak problemów odczytu i zachowany
hash źródła. 200/200 planów ze źródłami SKU/EAN ustawionymi automatycznie
przy kontrolowanej kategorii/parametrach, bez wysyłki do Allegro. Pełny
podgląd pobrał wszystkie 3 unikalne zdjęcia wybranej oferty bez lokalnego
zapisu. Oryginalny ZIP i zdjęcia użytkownika nie są częścią dystrybucji.
