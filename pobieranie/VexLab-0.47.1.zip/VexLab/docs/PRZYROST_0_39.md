# VexLab 0.39 — ekran Allegro do oceny i zmiana uprawnień

Data: 2026-11-10. Źródło: potwierdzona paczka VexLab-0.38.zip wskazana przez
właściciela, nie kod main. Właściciel potwierdził działanie zapisu tytułu i opisu
w 0.38; nie traktujemy tego jako odbioru nowej autoryzacji lub UI 0.39.

## Zakres i kryteria

Jeden ekran wzorcowy: Allegro. Płaskie karty bez poświat i kolorowych ikon KPI,
wspólna typografia, odstępy 8/12/16, niebieski akcent zakładki, poziome podziały
tabeli, wyrównane kwoty i stany. Logo, menu, rzeczywiste liczniki, stronicowanie,
odczyty, podgląd i edycja szkiców zachowane. Miniatury nadal mają pola 64×64,
wiersze 76 i kolumnę 80; zdjęcia zachowują proporcje.

Wycofano z głównego widoku nieczynne filtry kategorii/producenta, zakładki
Ukryte/Błędy, puste pole Sprzedano i powielone nieczynne przyciski. Przyszłe
polecenia i tryby są oznaczone w menu Więcej działań jako w przygotowaniu.
Żadna działająca funkcja nie została wyłączona. Import/Nowa oferta nadal
prowadzą do lokalnych paczek; nie tworzą zdalnych ofert ani nie publikują.

Pozostałe ekrany nie otrzymały nowego stylu. Rozszerzenie wzorca wymaga oceny
właściciela. Oba motywy i węższe okno mają ten sam działający proces.

## Zmiana uprawnień

Ustawienia → Integracje → Allegro: checkbox „Zezwól na zapis tytułu i opisu
szkiców” jest dostępny także po połączeniu. Zaznacz lub odznacz, następnie
wybierz **Zmień uprawnienia** i potwierdź nową zgodę w Allegro. Nie trzeba
wybierać Rozłącz i zapomnij ani ponownie wpisywać danych aplikacji.

Sam checkbox nie zmienia uprawnień działającej sesji. Device Flow używa
nowego zakresu. Dotychczasowa sesja i zapis są zachowane podczas oczekiwania;
odczyty i edycja są wtedy zablokowane. Sukces wymaga tokenu i /me dla tego
samego konta i środowiska. Przy zapamiętanym połączeniu nowa konfiguracja
zostaje zapisana przed przełączeniem sesji. Anulowanie, odmowa, inne konto,
wygaśnięcie kodu i błąd zapisu pozostawiają dotychczasowe połączenie. Spóźnione
odpowiedzi są ignorowane. Nie zapisujemy sekretów do tekstu GUI/logów.

Odmowa zapisu po stronie API nadal wymaga poprawnego scope aplikacji Allegro;
wybór checkboxa nie dowodzi, że serwer faktycznie przyznał uprawnienia.
Zapis szkiców zachowuje blokady konfliktów/nieznanego wyniku z 0.38.

## Właściciele danych i granice

Zmiana dotyczy prezentacji oraz stanu autoryzacji KontoSprzedażowe/KanałSprzedaży.
Nie zmienia modelu Produktu, treści Oferty, tabel, migracji ani danych użytkownika.
GUI używa istniejących DTO i przypadków użycia; operacje sieciowe/DPAPI pozostają
w tle za portami. Ponowna zgoda jest oddzielona od zapisów ofert i publikacji.

## Podglądy

Skrypt `scripts/capture_allegro.py` używa osobnej tymczasowej bazy, sztucznego
konta Sandbox i sześciu syntetycznych ofert. Nie łączy się z Allegro ani nie
zasila danych produkcyjnych. Obrazy w docs/screenshots:

- vexlab-allegro-039-dark.png — 1536×1024, ciemny;
- vexlab-allegro-039-light.png — 1536×1024, jasny;
- vexlab-allegro-039-small.png — 1100×1024;
- vexlab-allegro-039-empty.png — stan niepołączony;
- vexlab-allegro-039-permissions-dark.png / permissions-light.png — zmiana zgody.

## Weryfikacja i ograniczenia

Testy obejmują: rozszerzenie i cofnięcie zgody, zapamiętaną i ulotną sesję,
anulowanie, spóźniony wynik, odmowę, inne konto i awarię zapisu. GUI: oba motywy,
klawiatura/wyszukiwanie, wybór, węższe okno, identyczne miniatury mieszczące
się we własnych komórkach. Pełny check.py i audyt zależności raportowane
przy wydaniu. Nie wykonujemy testowych zapisów na koncie użytkownika.
Linux/offscreen i symulacja DPI nie zastępują odbioru Windows, DPAPI i Narratora.
Ponowna zgoda wymaga sprawdzenia na rzeczywistym koncie przez właściciela.

Kolejny etap funkcjonalny: ZIP → nowe szkice Allegro, przesłanie zdjęć,
walidacja danych wymaganych przez kategorię i raport każdej pozycji. Potrzebne
jawne ustawienia użytkownika, trwałe uzgadnianie wyników i ochrona przed
powieleniem szkiców. Publikacja osobno i po potwierdzeniu. Etap nie jest
wdrożony przez tę zmianę UI.

## Wynik kontroli wydania

2026-11-10, Linux, CPython 3.13.18 / PySide6 6.12.0 / SQLite 3.53.1:

- `scripts/check.py`: ruff, format, mypy (100 modułów), 7 kontraktów importów,
  bandit, **758 passed / 1 skipped** i diagnostyka — kod wyjścia 0.
- Pominięty test: natywne DPAPI Windows; pozostałe testy magazynu wykonane
  z izolowanym szyfratorem testowym. Nie jest to dowód działania DPAPI na Linux.
- Allegro przy `QT_SCALE_FACTOR=1.5`: **29 passed**.
- `scripts/audit.py`: runtime i dev — brak znanych podatności w wyniku audytu.
- `uv lock --check --offline`: zgodność wersji i blokady, bez zmiany zależności.
- Oceniono zrzuty jasny/ciemny, węższe okno, niepołączone konto i panel zgody.

SHA256 pobranej paczki bazowej 0.38:
`8d01d3a5d53f797737aed86d48b380d35e1dc93aaf2c7d7c015cfc4d5cc2ebaa`.
Brak migracji, usuniętych plików bazowej paczki lub zmian zasobów logo.
Dystrybucja: wyłącznie nowy ZIP i jego SHA256 na `pobieranie/vexlab-0.15`;
źródła wewnątrz ZIP-a, bez commitowania ich luzem i bez zmiany main.
