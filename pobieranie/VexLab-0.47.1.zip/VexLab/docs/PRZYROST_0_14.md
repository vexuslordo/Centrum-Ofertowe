# VexLab 0.14 — wygląd inspirowany Windows 11

Data: 2026-11-05. Polecenie właściciela: unowocześnić wygląd w kierunku
Windows 11, zachowując dotychczasowe funkcje i układ aplikacji.

## Zmiana wizualna

- Lżejsze menu: płaskie pozycje, delikatny aktywny element, złoty znacznik.
- Warstwy okna, nawigacji, paneli i kontrolek mają odrębne, spójne tła.
- Zaokrąglone karty i kontrolki, subtelne obramowania, delikatne gradienty
  przycisków i kart KPI. Granat/turkus/fiolet/złoto pozostają kolorami marki.
- Segoe UI Variable tam, gdzie jest dostępne, czytelniejsze nagłówki.
- Pola tekstowe z dolną linią aktywności; spójny fokus klawiatury,
  wskazanie, wciśnięcie, zaznaczenie i stan niedostępny.
- Uporządkowane tabele, zakładki, listy, menu podręczne, dymki,
  pola edytora opisu, checkboxy i paski przewijania.
- Paleta Qt obejmuje również kontrolki bez własnej reguły QSS.
  Kolor ikon nawigacji dostosowuje się do wybranego motywu.

Zachowano menu, jego kolejność i zwijanie, rozmieszczenie dashboardu,
strony, przyciski i wszystkie operacje. Logo PNG pozostaje identyczne.
Nie zmieniano modelu, portów, bazy, importów danych, profili, integracji
lub zachowania cen. Schemat 7 bez migracji. Treści i ustawienia pozostają
danymi użytkownika; brak nowych seedów i nowych zależności.

To styl inspirowany Windows 11 na istniejącym PySide6. Pozostaje zwykła
systemowa ramka okna; nie wdrożono natywnego rozmycia Mica/Acrylic lub
własnego zamiennika przycisków zamykania i obsługi okna.

## Weryfikacja wizualna i techniczna

Wygenerowano i obejrzano dashboard oraz edytor opisu w motywie jasnym i
ciemnym. Generator obejmuje też producentów, import, media, masową edycję,
paczki i szkice na pustej izolowanej instalacji. Dane testowej tożsamości
nie są seedem programu. Obrazy: docs/screenshots.

Poprawiono narzędzie capture_ui: zamiast zbyt krótkiego limitu 10 s limit
60 s, zakończenie po opróżnieniu zadań I/O. Unika to usuwania obiektów Qt
podczas pracy generatora. Obie próby zrzutów 0.14 zakończyły się poprawnie.

Porównano źródła aplikacji z 0.13.1: zmienione są wyłącznie wspólny system
wyglądu oraz aktualizacja koloru ikon w metodzie motywu okna. Pozostały kod
aplikacji, definicje bazy i logo są zgodne bajtowo z poprzednią paczką.

Sprawdzono próbki kontrastu: tekst pomocniczy i nagłówki tabel przekraczają
4,5:1 w obu motywach, akcent fokusu jasnego motywu na białym tle 3,67:1.
Nie jest to pełny audyt dostępności. Odbiór rzeczywistego Windows 11,
DPI i czytnika ekranu nadal osobny; audyt techniczny i UX kandydata 1.0
pozostaje zaplanowany zgodnie z poleceniem właściciela.

Pełna kontrola wydania: **321 testów przeszło** (221,51 s). Ruff,
formatowanie, strict mypy (50 plików), siedem kontraktów importów,
Bandit i diagnostyka techniczna zakończone poprawnie.

Z wypakowanego ZIP-a przeszło dodatkowo sześć sprawdzeń GUI: zachowanie
preferencji motywu/menu, rozmiary 800/1100/1536, wizualna edycja opisu
oraz masowe usuwanie szkiców. Potwierdzono import z wypakowanych źródeł,
CRC paczki i brak baz użytkownika. Wheel/sdist zbudowano offline.
