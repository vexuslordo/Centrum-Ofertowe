# VexLab 0.47 — sprawdzanie ofert już obecnych na Allegro

„Parametry produktów…” są teraz w lewym panelu **1. Dane produktów**,
obok wyboru istniejącego i nowego produktu. Formularz oraz zakres zmian
pozostają takie same.

W oknie przygotowania ofert wybierz produkty i kliknij **Sprawdź duplikaty**.
Bez zaznaczenia sprawdzane są wszystkie widoczne pozycje.

Program szuka na całym koncie przez API Allegro: najpierw po SKU/sygnaturze,
następnie po dokładnie takim samym tytule, porównując EAN. Uwzględnia aktywne,
szkice i zakończone oferty. Wyniki nie są ograniczone do otwartej strony 50.

Znalezione pozycje otrzymują **Już na Allegro** i ID. Kliknij wiersz, aby
zobaczyć status (np. Aktywna), tytuł i przyczynę dopasowania. Pozycje są
pomijane przy tworzeniu szkiców. Także zgodny tytuł bez dostępnego EAN jest
pokazany jako podejrzenie do porównania i blokowany przed nowym zapisem.
Sam zgodny EAN przy innym tytule nie blokuje różnych dopasowań/produktów.

Przed wysyłką wykonywane jest ponowne sprawdzenie konta. Brak połączenia,
niepełny wynik lub zbyt szerokie zapytanie zatrzymuje nowe tworzenie.
Istniejące lokalne próby są odczytywane dotychczasową ścieżką, bez duplikatu.
Podsumowanie osobno pokazuje pozycje pominięte, bo są już na Allegro.

Stare oferty z innym SKU i zmienionym tytułem mogą wymagać ręcznego porównania.
Nie ma blokady równoczesnych zapisów innych aplikacji. Niczego nie usuwamy,
nie zmieniamy istniejących ofert ani nie uruchamiamy sprzedaży.
Miniatury, kolory Dashboardu, znak ✓, VAT i GPSR z poprzedniej paczki zachowane.

Następny etap wskazany przez właściciela: z tego samego miejsca wybór Allegro,
PrestaShop lub obu kanałów, układ treści właściwy dla każdego kanału, odrębne
wyniki i niezależne ponawianie. Publikacja PrestaShop nie jest jeszcze wdrożona.

Testy: istniejące SKU przy zmienionym tytule, stare sygnatury i EAN,
stronicowanie ponad 50, niepełne wyniki, blokada uploadu/POST, błąd sieci.
Testy korzystają z kontrolowanych odpowiedzi, bez logowania do konta użytkownika.
Bez zmian bazy lub plików użytkownika; publikowane tylko ZIP i SHA256.
