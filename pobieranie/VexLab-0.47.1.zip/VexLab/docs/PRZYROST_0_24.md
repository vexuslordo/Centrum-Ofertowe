# VexLab 0.24 — przygotowanie odczytu Subiekta GT

2026-11-07. Schemat 11 bez migracji i zmian zależności. ADR-052.

## Obsługa

Ustawienia → Subiekt GT — przygotowanie połączenia → Sprawdź środowisko.
Ręczne sprawdzenie działa w tle. Kopiuj raport udostępnia wynik do przekazania
osobie konfigurującej integrację. Ustawienia mają przewijanie w małym oknie.

Raport zawiera system, wersję i architekturę Pythona, wpisy instalacji
InsERT/Subiekt GT oraz rejestracje sterowników SQL Server. Widok rejestru
32/64-bit nie jest deklaracją architektury zainstalowanego programu.
Brak wpisu nie dowodzi braku instalacji. Częściowy odczyt ma ostrzeżenie;
ponowna próba usuwa poprzedni raport, także po błędzie. Na innych systemach
raport wyjaśnia brak obsługi odczytu rejestru Windows.

Odczytywane są wyłącznie metadane instalacji i sterowników z rejestru.
Nie są zbierane hasła, konfiguracje podmiotów ani dane serwera. Nie ma
połączenia z bazą, uruchomienia Sfery, testu licencji lub zapisu do rejestru.
Status integracji pozostaje niewdrożony. Nie dodano automatycznego skanowania.

## Granica katalogu

PrzegladajKatalog korzysta z portu OdczytKatalogu bez komend zapisu.
GUI kieruje zapytania stron i pełnego jawnego wyboru przez ten serwis.
Dotychczasowy lokalny katalog i jego edycja działają nadal. Nie włączono
alternatywnego źródła GT. Tożsamość zewnętrznych kartotek i wyłączenie komend
lokalnych dla przyszłego źródła GT nadal wymagają osobnego przyrostu.

## Dalszy krok i ograniczenia

Potwierdzono serwer bazy i klient GT na laptopie. Licencja Sfery pozostaje
nieustalona. Raport z laptopa pomoże ocenić instalację; nie zastępuje aktualnej
dokumentacji InsERT, weryfikacji uprawnień i testu rzeczywistego połączenia.
Mechanizm SQL/Sfera nie został wybrany. ZIP ofert nadal nie tworzy kartotek.

Testy sprawdzają port bez zapisu, walidację, rejestr 32/64-bit, prawa KEY_READ,
zamknięcie uchwytów, częściowy wynik i brak ujawniania wyjątków, ponowienie,
kopiowanie raportu oraz wykonanie poza wątkiem GUI. Rejestr jest symulowany;
testy Linux nie zastępują odbioru na natywnym Windows.

## Wyniki weryfikacji

`scripts/check.py`: 535 testów zaliczonych, ruff i format bez uwag, mypy
78 modułów, siedem kontraktów importów, Bandit i diagnostyka bez błędów.
Mypy z platformą win32 również poprawne. Przy skalowaniu 150%: dziewięć
testów panelu i stron katalogu zaliczonych. Audyt zależności runtime/dev
nie wykazał znanych podatności w chwili sprawdzenia. Wheel/sdist zbudowane
offline. Obejrzano widoki ciemny/jasny 1536×1024 i mały jasny 900×700
(`docs/screenshots/vexlab-gt-024-*.png`, środowisko Linux, bez fikcyjnego
potwierdzenia połączenia). Rejestr Windows i serwer wymagają natywnego odbioru.
