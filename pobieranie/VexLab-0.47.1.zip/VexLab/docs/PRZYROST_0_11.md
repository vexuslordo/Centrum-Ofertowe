# VexLab 0.11 — zapamiętane układy i nowoczesny wygląd

2026-11-04. Wdrożenie zaakceptowanego zapamiętywania układów paczek,
uproszczenia interfejsu i polecenia odświeżenia wyglądu z zachowaniem układu.
Schemat SQLite 6 i dane biznesowe bez zmian.

## Paczka bez pliku profilu za każdym razem

1. Pierwszy raz wczytaj paczkę z profilem albo zewnętrzny profil użytkownika.
2. Program otworzy oferty i zapamięta układ. Informacja o tym jest widoczna.
3. Kolejny ZIP o tej samej strukturze otworzy się bez pliku profilu,
   także po restarcie programu. Może pochodzić od innego producenta;
   liczy się struktura, nie marka. Nazwa pliku danych może się zmienić.
4. Jeśli pasuje kilka układów, wybierz jeden z krótkiej listy.
   Nowy lub zmieniony format wymaga jednorazowego profilu/mapowania.

Na głównej stronie nie ma tabeli technicznych ustawień. Konfiguracja
zaawansowana otwiera osobny edytor dla autora profilu. Normalny przebieg
pozostaje: ZIP → oferty → Dodaj nowe produkty do katalogu. Zakres importu
Produktów zachowany: SKU, nazwa, tekst opisu, opcjonalny producent,
bez nadpisania istniejących SKU i z trwałymi pozycjami Do poprawy.

Ustawienia są wyłącznie danymi użytkownika w profile_paczek obok bazy,
bez wbudowanego producenta, domeny lub banerów. Zmiana folderu programu
nie kasuje tych ustawień. Usunięcie aktualnego zapamiętanego układu jest
możliwe w edytorze po potwierdzeniu, bez usuwania Produktów i ZIP-ów.
Szczegóły algorytmu/limitów i zachowania po awarii: ADR-038.

Kopia bazy SQLite nie zawiera folderu profile_paczek. Można zachować jego
osobną kopię lub ponownie nauczyć programu układu przez profil/paczkę.
Uszkodzonych ustawień program nie resetuje. Błąd zapamiętania nie blokuje
podglądu, ale pojawia się informacja o nieudanym zapisie ustawień.

## Wygląd

Zachowano nagłówek, menu, cztery KPI, panele dashboardu, tabele i trasy.
Paleta zgodna z logo: granat, turkus, fiolet i złote akcenty. Zmieniono
wspólny styl kontrolek: płaskie listy i pola liczbowe z własnymi strzałkami,
spójne checkboxy, subtelne obramowania, zaokrąglenia, typografię, stany
hover/focus/pressed i aktywną pozycję menu. Użyto Qt Fusion i istniejącego
PySide6, bez nowej biblioteki UI lub zmiany zasad licencji. Oba motywy.
Logo transparentne i dotychczasowa nazwa/katalog danych pozostają zachowane.

## Ceny — ustalenie z rozmowy

Właściciel wskazał cennik producenta jako źródło ceny bazowej oraz API
Allegro/PrestaShop jako źródła cen kanałów. Zielony dla ceny kanału równej
lub wyższej od bazowej, czerwony poniżej; brak/nieporównywalne/stare dane
neutralne. Wymóg zapisano w ADR-039, nie wdrożono cen kanałów lub odczytów
API. Obecna cena sugerowana z wczytanego cennika i jej źródło pozostają
bez zmiany. Nie kopiowano ceny gotowej Oferty z ZIP-a do tego pola.

Nie wdrożono publikacji na Allegro ani trwałego modelu Oferty. Audyt
techniczny i użyteczności 1.0 nadal pozostaje zaplanowany, nie wykonany.
Pełny odbiór Windows/DPI/Narrator pozostaje osobnym sprawdzeniem.

## Czyszczenie Do poprawy

Na polecenie właściciela dodano usuwanie zaznaczonych wpisów (Ctrl/Shift) oraz czyszczenie całej aktualnie odczytanej listy. Obie akcje wymagają potwierdzenia z domyślną odpowiedzią Nie. Operacja w tle sprawdza wersje wszystkich wskazanych wpisów, tworzy spójną kopię bazy w `kopie_importow` i usuwa tylko wpisy `import_robocze` w jednej transakcji. Konflikt lub błąd kopii nie powoduje częściowego usunięcia. Produkty, producenci i pliki źródłowe pozostają bez zmian. Wpisy dodane równolegle po odczytaniu listy nie są objęte potwierdzeniem. Schemat bazy pozostaje w wersji 6.

## Weryfikacja wydania

- Zapamiętanie rzeczywistej paczki użytkownika i rozpoznanie 200 ofert z oryginalnego ZIP-a bez profilu po ponownym utworzeniu usług: poprawne.
- Zbudowano wheel i sdist offline; wheel zawiera logo PNG i pięć ikon SVG.
- Sprawdzono CRC paczki źródłowej oraz brak baz użytkownika i plików XLSX.
- Z wypakowanej paczki wykonano 49 testów pamięci profili, podglądu ZIP, importu i czyszczenia: wszystkie przeszły. Dodatkowy test awarii kopii potwierdził pozostawienie całej listy bez zmian.
- Schemat SQLite i kod domeny Produktu pozostają zgodne z 0.10.1; nie ma migracji danych.
- Końcowa pełna regresja po poprawieniu przygotowania nowego testu GUI: **286 testów przeszło** (175,32 s). Ruff, formatowanie, strict mypy (45 plików), siedem kontraktów importów, Bandit i diagnostyka techniczna zakończone poprawnie. Testy GUI uruchamiano bez ekranu; odbiór Windows pozostaje do wykonania.
