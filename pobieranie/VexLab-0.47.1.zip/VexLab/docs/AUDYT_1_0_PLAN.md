# Audyt wersji 1.0 — technika i doświadczenie użytkownika

Data wymagania: 2026-11-03. Właściciel: użytkownik projektu VexLab.
WYMAGANIE z rozmowy: przy dojściu do 1.0 przeprowadzić szczegółowy audyt
techniczny oraz sprawdzić z perspektywy użytkownika przyjazność i intuicyjność UI.
Status: zaplanowany, NIE przeprowadzony. Dotychczasowe testy przyrostów
nie zastępują tego audytu. Dokument określa sposób wykonania; nie deklaruje
zatwierdzonego całego zakresu biznesowego wersji 1.0 ani daty wydania.

## Punkt kontrolny

Przygotować kandydata do 1.0, ustalić i zapisać faktycznie wdrożony zakres,
wersję kodu/paczki, schemat, zależności oraz otwarte decyzje. Audyt ma dotyczyć
tej konkretnej paczki. Wyniki i poprawki muszą zostać sprawdzone przed
uznaniem wydania za odebrane. Numer 1.0 nie wynika automatycznie z tego,
że poprzednia wersja nazywała się 0.9; możliwe są kolejne przyrosty 0.x.

Nie przedstawiać niewdrożonych integracji jako funkcji poddanych odbiorowi.
Oddzielić brak implementacji od usterki wdrożonego zakresu. Nie ogłaszać
pełnego odbioru, jeśli zabrakło sprzętu, Windows, użytkownika lub dostępu
do odpowiednich środowisk testowych; zapisać brak dowodu i jego wpływ.

## Audyt techniczny

| Obszar | Sprawdzenie i wymagany dowód |
|---|---|
| Architektura | Rzeczywiste kierunki zależności sześciu warstw, porty, bootstrap, granice Produkt/Oferta i źródła prawdy; przegląd kodu oprócz kontraktów importów |
| Reguły i dane | SKU, przypisania producenta, pieniądze/waluty i dopasowania; walidacja wszystkich dróg zapisu, zgodność DTO i stanu bazy |
| SQLite | Migracje ze wspieranych wersji, kopie, ich rzeczywiste odtworzenie, awaria w trakcie zapisu, konflikty i równoczesne operacje; bez testowania na jedynej bazie właściciela |
| Import/eksport/media | Błędne XLSX/CSV, formuły, encje XML, limity plików i obrazów, duplikaty, trwałość Do poprawy, niebezpieczne dane tekstowe i eksport CSV |
| Wydajność | Praca z reprezentatywną liczbą produktów, mediów i importów; znany scenariusz 2375 produktów; czas, pamięć i reakcja GUI w trakcie odczytu/zapisu, nie tylko końcowy wynik |
| Zadania i błędy | Zamknięcie podczas pracy, przerwanie, blokada pliku, brak dostępu/miejsca, konflikt wersji, brak częściowego zapisu i zachowanie formularza po błędzie |
| Bezpieczeństwo | Sekrety, diagnostyka/logi, dane w ZIP, walidacja adresów/plików, TLS, brak wykonywania treści z importu; uprawnienia i integracje tylko w istniejącym zakresie |
| Zależności i licencje | Odtworzenie z blokady, audyt runtime i dev, znane podatności i ich ocena, zgodność licencji dystrybucji; brak sieci nie oznacza pozytywnego wyniku |
| Windows i paczka | Świeża wspierana instalacja, uruchamianie i aktualizacja, ścieżki z odstępami/polskimi znakami, konto bez administratora, zachowanie danych i preferencji |
| Testy | Ruff, format, mypy, kontrakty, bandit, testy jednostkowe/integracyjne/GUI; ocena luk i jakości testów, a nie tylko liczby lub zielonego wyniku |

W raporcie zapisać sprzęt, system, wersje, wolumen i sposób pomiaru. Nie
nadawać arbitralnych celów wydajności po obejrzeniu wyników; proponowane
progi oraz macierz wspieranych systemów wymagają ustalenia przed odbiorem.

## Audyt z perspektywy użytkownika

Dwie osobne części: przegląd ekspercki interfejsu i obserwacja właściciela
lub wskazanego użytkownika podczas wykonywania zadań na testowej kopii.
Ocena samego agenta lub automatycznych kliknięć nie potwierdza intuicyjności.

Przykładowe zadania, dostosowane do wdrożonego zakresu 1.0:

1. Pierwsze uruchomienie i ustalenie, gdzie zacząć pracę, bez instrukcji krok po kroku.
2. Dodanie produktu, znalezienie po SKU, edycja i powrót do listy.
3. Import cennika o innym układzie, wybór producenta/waluty/kolumn, odczyt podglądu i zapis.
4. Rozpoznanie błędnego wiersza, odnalezienie go po restarcie i poprawienie.
5. Dodanie produktu uniwersalnego bez motocykla i produktu pasującego do kilku modeli.
6. Dodanie zdjęć, wybór miniatury, kolejność, anulowanie i rozpoznanie momentu faktycznego zapisu.
7. Wyszukiwanie/filtry oraz przejście Produkty ↔ Zdjęcia i media, bez pomylenia obu miejsc pracy.
8. Wybór wszystkich wyników i edycja masowa z rozpoznaniem zakresu przed zatwierdzeniem.
9. Bezpieczne usunięcie testowych danych, rozpoznanie skutku i odnalezienie kopii.
10. Utworzenie/edycja szkicu Oferty, jeśli wdrożone; odróżnienie szkicu od publikacji.
11. Odzyskanie po błędzie: czy komunikat wyjaśnia problem i następny krok, a formularz zachowuje dane.
12. Praca klawiaturą, widoczność fokusu, małe okno i duży tekst, oba motywy, DPI i Narrator.

Dla zadania zapisać: sukces samodzielny / z pomocą / brak sukcesu, czas,
pomyłki, cofnięcia, miejsca zawahania, niezrozumiałe nazwy oraz komentarz
użytkownika. Przed próbą określić, co oznacza sukces. Nie podpowiadać
przycisków w poleceniu, gdy badamy ich odnajdywanie. Pomoc odnotować.

Ocenić spójność terminów i układu ze wzorcem UI-REF-01, kontrast, przewijanie,
widoczność akcji, liczbę kroków, stany puste/ładowania/błędów, dostępność
oraz odróżnienie „zmiana robocza”, „zapisano” i „wysłano”. Sprawdzić także,
czy widoczne, niewdrożone opcje nie wprowadzają użytkownika w błąd.

## Wynik i poprawki

Każde ustalenie ma: identyfikator, obszar, ważność, kroki odtworzenia,
oczekiwany i rzeczywisty wynik, dowód, wpływ na użytkownika/dane,
propozycję poprawki oraz wynik ponownego sprawdzenia. Rozdzielić błędy,
problemy użyteczności, propozycje ulepszeń i niezweryfikowane ryzyka.

Utrata danych, niewiarygodny zapis lub niewłaściwy odbiorca skutku
zewnętrznego wymagają naprawy i ponownego sprawdzenia. Inne ustalenia
przedstawić właścicielowi z priorytetem i wpływem; nie ukrywać ich pod
ogólnym „audyt zaliczony”. Wyniki mają obejmować osobne raporty techniczny
i użytkowy oraz wspólną listę napraw i odłożonych punktów z uzasadnieniem.

Testy używają syntetycznych danych lub uprawnionej kopii. Rzeczywista
publikacja i wysyłka dokumentów wymagają osobno określonego pilotażu;
plan audytu nie jest taką zgodą. Nie przekazywać sekretów lub danych
klientów do usług audytowych bez upoważnienia.
