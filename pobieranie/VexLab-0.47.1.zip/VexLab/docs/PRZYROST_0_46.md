# VexLab 0.46 — zdjęcia i czytelny wynik wysyłki

W oknie przygotowania ofert Allegro:

- Miniatury **64 × 64** po lewej, jak na liście Allegro. Pobierane w tle dla
  widocznych produktów, bez rozciągania zdjęć. Brak zdjęcia nie blokuje pracy.
- Górne panele mają wspólne tło Dashboardu: niebieskie dane produktów
  i zielone ustawienia Allegro. Oba motywy korzystają z tej samej palety.
- Zielony **✓** zastępuje „Gotowa”. Podpowiedź wyjaśnia gotowość do utworzenia
  szkicu; nie oznacza przesłania lub uruchomienia sprzedaży.
- Po wysyłce lub sprawdzeniu wyników pojawia się podsumowanie: ile szkiców
  potwierdzono w Allegro, ile zapisanych wymaga poprawy oraz ile nie ma
  potwierdzenia. Wiersze nadal zawierają wynik i ID, raport jest w menu.

SKU, EAN, ceny, ilości, edycja masowa, GPSR, VAT i wszystkie potwierdzenia
pozostają bez zmian. Stan pełny w raportach i dla czytników ekranu.
Nieznany wynik wymaga sprawdzenia odczytem; nie jest liczony jako sukces
ani nie powoduje ponownego POST. Publikacja sprzedaży pozostaje osobną akcją.

[Podgląd ciemny](screenshots/vexlab-przygotowanie-046-dark.png) ·
[Podgląd jasny](screenshots/vexlab-przygotowanie-046-light.png).
Dane i obrazki syntetyczne, reprodukcja:
`python scripts/capture_przygotowanie_046.py`.

Regresje: obraz prawidłowy i brak obrazu, wielkość 64×64, lewa kolumna,
zamykanie odczytu, znak gotowości zamieniany na wynik po wysyłce,
potwierdzenie pełne i częściowe z nieznanym wynikiem. Kontrole motywów/DPI
na Linuksie, bez zapisu na prywatnym koncie użytkownika i bez odbioru Windows.
Bez zmiany bazy, logo, plików i danych użytkownika.
