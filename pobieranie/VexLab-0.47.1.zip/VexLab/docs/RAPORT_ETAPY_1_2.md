# VexLab — raport pierwszego przyrostu

Data: 2026-11-02 (Europe/Warsaw). Autor wykonania: Codex.
Zakres polecenia: etapy 1–2 bez funkcjonalności biznesowych.

Korekta po porównaniu raportów: wyniki poniżej dotyczą wyłącznie lokalnego
stanu Python 3.12.14 / uv 0.12.23. Nie opisują zgłoszonego przez właściciela
środowiska 3.13.5 / uv 0.10.x. Python 3.12.14 nie jest aktualną rekomendacją
poprawki bezpieczeństwa. Dalszy kierunek to szereg 3.13; dokładny pin i test
czystego Windows pozostają otwarte w [ADR-011](adr/ADR-011-srodowisko.md).

## Materiał wejściowy

Przeczytano 7 dokumentów, rozpoczynając od AGENTS.md; obejrzano PNG
1536×1024. Bazą jest commit `08b2b04` istniejącego repozytorium.
W bieżącej wiadomości nie było dostępnego pliku ZIP ani identyfikatora do jego
pobrania; nie rozpakowywano i nie porównywano nieudostępnionego archiwum.
Oryginalny `assets/UI_REFERENCE.png` pozostaje bez zmian.

Obowiązuje marka **VexLab** i **nazwa użytkownika** w profilu, zgodnie
z późniejszą korektą właściciela. Nie wdrożono profilu ani logowania.

## Przyrost 1 — środowisko i jakość

Przygotowano `pyproject.toml`, `.python-version`, `uv.lock`, `.gitignore`,
izolowane `.venv`, skrypty kontroli i audytu oraz workflow Windows/Linux.
Wersje i uzasadnienia są w [ADR-011](adr/ADR-011-srodowisko.md).

Python 3.12.14, PySide6/Qt 6.12.0, SQLite 3.53.1 w aktualnym interpreterze
Linux. Wszystkie bezpośrednie wersje są przypięte, zależności przechodnie
i sumy artefaktów utrwalone w blokadzie. Dla zależności PySide6 sprawdzono
obecność wheel Windows x64 w blokadzie; nie oznacza to uruchomienia na Windows.

Druga czysta instalacja w `/tmp/vexlab-repro-20261102` odtworzyła ten sam
zestaw 52 dystrybucji i wersji co `.venv`. Powtórzono kontrole i testy
w tym środowisku. Artefakty build: wheel i sdist wersji 0.1.0.dev0.
Wheel zainstalowano w trzecim środowisku `/tmp/vexlab-wheel-20261102`;
diagnostyka modułowa i komenda `vexlab --diagnostyka` działają poza checkoutem.

Instalacja korzystała z oficjalnego PyPI i weryfikacji TLS. Ograniczenia
sandboxa wymagały dostępu przez skonfigurowane proxy. Standardowy cache uv
w `/home/agent` jest niezapisywalny w sandboxie; sprawdzono działającą
konfigurację `UV_CACHE_DIR=/tmp/vexlab-uv-cache`, bez zmiany uprawnień systemu.

## Przyrost 2 — fundament architektoniczny

Utworzono sześć warstw i zewnętrzny bootstrap zgodnie z
[ADR-001](adr/ADR-001-granice-warstw.md). Domena, GUI i kanały mają wyłącznie
opisane granice pakietów. Nie utworzono zastępczych klas dla 16 bytów.

Działa mały przepływ techniczny: bootstrap wstrzykuje zegar i czytnik wersji
do zapytania diagnostycznego; wynik jest niezmiennym DTO z czasem i korelacją.
CLI wyświetla rzeczywiste wersje, a błąd daje kod wyjścia 1 i korelację.
Nie otwiera pliku SQLite, nie tworzy kont, danych ani połączeń z platformami.
UUID korelacji nie narzuca domenowego formatu identyfikatorów.

Porty AI, importu, mediów i biznesowych modeli odczytu wymagają konkretnych
scenariuszy po przeglądzie modelu. Celowo nie projektowano ich pól i kontraktów
na podstawie samego obrazka. Fundament udowadnia techniczny kierunek zależności.

## Wyniki

| Sprawdzenie | Wynik w bieżącym Linux |
|---|---|
| pytest | 29 zaliczonych, 0 niezaliczonych, 0 pominiętych |
| ruff check / format | poprawne, 21 plików Python |
| mypy strict | brak błędów w 12 plikach źródłowych |
| import-linter | 7 kontraktów zachowanych, 0 naruszeń |
| bandit, źródła | brak zgłoszeń |
| pip-audit runtime | brak znanych podatności w pełnym grafie runtime |
| pip-audit dev | brak znanych podatności w pełnym grafie dev |
| uv lock --check | blokada zgodna z pyproject |
| Druga czysta instalacja | identyczne 52 dystrybucje i wersje |
| Wheel/sdist i instalacja wheel | poprawne; diagnostyka działa poza repozytorium |
| Qt offscreen | renderowanie kontrolki i obsługa zdarzenia timera poprawne |
| Windows CI / Windows 11 | przygotowane CI, niewykonane w tej sesji |

Testy negatywne celowo wprowadzają błędy importów, typu i formatu wyłącznie
w kopiach tymczasowych. Są zaliczone, gdy narzędzie wykryje naruszenie.
Sprawdzono również dozwolone pośrednie użycie domeny przez GUI za przypadkiem
użycia. Świeży proces importuje centrum mimo blokady Qt/SQL/HTTP.
Test startu potwierdza, że pusty katalog danych pozostaje pusty.

Audyt używa pełnych eksportów blokady runtime i dev; `--no-deps` wyłącza
ponowne rozwiązywanie, nie usuwa jawnie wyeksportowanych zależności.
To stan bazy znanych podatności w chwili wykonania, nie gwarancja bezpieczeństwa.
Nie nadano licencji projektowi ani nie zatwierdzono dystrybucji bibliotek.

## Konflikty i decyzje

- Historyczny zakaz kodowania zastępuje bieżące polecenie (ADR-017).
- K-01/P-01: zewnętrzny bootstrap, wdrożony technicznie na podstawie delegacji.
- P-11: przypięte środowisko developerskie; docelowy instalator i macierz
  użytkowników Windows pozostają otwarte.
- K-02: rekomendacja wspólnych pionowych scenariuszy etapów 6/7; bez logiki w GUI.
- K-07 i ADR-013–016: ceny, cenniki, media, szablony, metryki i AI wymagają
  decyzji modelowych przed tabelami lub publicznymi kontraktami.
- QFluentWidgets i licencja produktu pozostają otwarte; nie dodano zależności
  ani kosztów. Rekomendacja dalszego UI: własne komponenty PySide6 za fasadą.

## Co pozostaje

Nie ma GUI VexLab, dashboardu, integracji, modelu biznesowego, bazy ani migracji.
Test kontrolki Qt potwierdza instalację biblioteki, nie realizację UI-REF-01.
Windows, Narrator, DPI i zgodność wizualna wymagają rzeczywistego wykonania.
CI zapisano lokalnie; nie wysłano zmian, nie utworzono PR ani nie uruchomiono CI.

W szkicu konfiguracji chmury zapisano i potwierdzono `install_script` oraz
`start_skill`, zastępując wcześniejsze instrukcje dla samej dokumentacji.
Dokładny skrypt instalacyjny wykonano pomyślnie. Zapis szkicu nie jest
publikacją snapshotu; środowisko można przejrzeć, zapisać i opublikować
w ustawieniach. Nie zweryfikowano odtworzenia w nowym zadaniu chmurowym.

Następny przyrost: przegląd modelu i konkretnego scenariusza etapu 3,
z rekomendacjami i konsekwencjami nieustalonych pól/relacji. Nie trzeba
rozstrzygać całej domeny jednocześnie. Porty i schemat mają wynikać z
zatwierdzonego przyrostu, a nie z chęci wypełnienia pustych katalogów.
