"""Podgląd okna na 35 syntetycznych produktach, bez połączenia z Allegro."""

import sys
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

from capture_gpsr_allegro import Katalog
from PySide6.QtCore import QBuffer, QIODevice, QItemSelectionModel, Qt, QTimer
from PySide6.QtGui import QColor, QImage, QPainter
from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.rejestr_tworzenia_allegro import RejestrTworzeniaJSON
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.nowe_szkice_allegro import NoweSzkiceAllegro, UstawieniaSzkicu
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.powloka import Motyw


class ObrazTestowy:
    def pobierz_obraz(self, url: str) -> ZdjecieDane:
        image = QImage(256, 256, QImage.Format.Format_RGB32)
        image.fill(QColor("white"))
        painter = QPainter(image)
        painter.setBrush(QColor("#414A56"))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(35, 66, 186, 110, 18, 18)
        painter.setBrush(QColor("#A4B4C5"))
        painter.drawEllipse(74, 91, 108, 60)
        painter.setPen(QColor("#414A56"))
        painter.drawText(0, 190, 256, 30, Qt.AlignmentFlag.AlignCenter, "DEMO")
        painter.end()
        out = QBuffer()
        out.open(QIODevice.OpenModeFlag.WriteOnly)
        image.save(out, "PNG")
        data = bytes(out.data())
        return ZdjecieDane(url, data, data)


def main() -> int:
    app = QApplication(sys.argv)
    cel = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    parent = QWidget()
    with TemporaryDirectory(prefix="vexlab-preview-") as folder:
        api = Katalog()
        service = NoweSzkiceAllegro(api, RejestrTworzeniaJSON(Path(folder)), api)
        s = SesjaAllegro(
            KontoAllegro("test", "konto_testowe"),
            SrodowiskoAllegro.SANDBOX,
            "fixture",
            3700,
            aplikacja=AplikacjaAllegro("fixture", "fixture", zapis_szkicow=True),
        )
        o = OfertaPodglad(
            1,
            "SKU-TEST-001",
            "Osłona reflektora — model testowy",
            "<p>Dane testowe</p>",
            "5901234123457",
            "289.00",
            "",
            ("https://images.example.org/test.jpg",),
            (),
            (),
        )
        oferty = tuple(replace(o, sku=f"SKU-TEST-{i:03d}", cena=str(289 + i)) for i in range(1, 36))
        jobs = []
        w = DialogNowychSzkicow(
            parent,
            service,
            s,
            oferty,
            lambda *args: jobs.append(args),
            PodgladZdjec(ObrazTestowy()),
        )
        w.kompletny.setChecked(False)
        w.waluta.setCurrentIndex(w.waluta.findData("PLN"))
        for i in range(len(oferty)):
            w.ustawienia[i] = UstawieniaSzkicu(
                "PLN",
                1,
                nowy=True,
                kategoria="123",
                wartosci=(("stan", "nowy"), ("marka", "test"), ("masa", "1.2")),
                zrodla=(("kod", "sku"), ("ean", "ean")),
            )
        w.przygotuj()
        function, ok, _ = jobs.pop()
        ok(function())
        flags = QItemSelectionModel.SelectionFlag.Select | QItemSelectionModel.SelectionFlag.Rows
        for i in range(3):
            w.tabela.selectionModel().select(w.tabela.model().index(i, 0), flags)
        w.tabela.setCurrentCell(0, 0, QItemSelectionModel.SelectionFlag.NoUpdate)
        for motif, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motif)
            w.show()
            for _ in range(8):
                app.processEvents()
                while jobs:
                    function, success, _ = jobs.pop(0)
                    success(function())
            if not w.grab().save(str(cel / f"vexlab-przygotowanie-046-{name}.png")):
                return 1
        w.close()
    QTimer.singleShot(0, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
