"""Podglądy na danych syntetycznych, bez odczytów i zapisów kont Allegro."""

import sys
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import UUID

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QDialog, QWidget

from vexlab.adaptery.rejestr_tworzenia_allegro import RejestrTworzeniaJSON
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.gui.ustawienia_sprzedazy_allegro import DaneSprzedazyAllegro
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    NoweSzkiceAllegro,
    ParametrSzkicu,
    ProduktSzkicu,
    UstawieniaSzkicu,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import (
    SlownikiSprzedazy,
    UstawieniaSprzedazy,
    WyborSprzedazy,
)


class Katalog:
    def teraz(self):
        return 100

    def nowy_produkt(self, *args):
        return ProduktSzkicu(
            "",
            "Części testowe",
            "123",
            (
                ParametrSzkicu("stan", "Stan", "dictionary", True, (("nowy", "Nowy"),)),
                ParametrSzkicu(
                    "marka",
                    "Producent",
                    "dictionary",
                    True,
                    (("test", "Producent testowy"),),
                    True,
                    True,
                ),
                ParametrSzkicu("kod", "Numer katalogowy części", "string", False, (), True, True),
                ParametrSzkicu(
                    "masa", "Waga produktu z opakowaniem", "float", False, (), True, True
                ),
                ParametrSzkicu("ean", "EAN (GTIN)", "string", False, (), True, False),
                ParametrSzkicu(
                    "inne", "Numery katalogowe zamienników", "string", False, (), True, False
                ),
            ),
        )


def main() -> int:
    app = QApplication(sys.argv)
    cel = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    ids = [str(UUID(int=i)) for i in range(1, 7)]
    refs = SlownikiSprzedazy(
        *(
            (WyborSprzedazy(ident, nazwa, "Dane testowe"),)
            for ident, nazwa in zip(
                ids,
                (
                    "Producent testowy",
                    "Osoba testowa",
                    "Cennik standardowy",
                    "Zwrot 14 dni — test",
                    "Reklamacje — test",
                    "Gwarancja — test",
                ),
                strict=True,
            )
        )
    )
    u = UstawieniaSprzedazy(
        ids[0],
        ids[1],
        "Przykładowe pole na własne instrukcje i ostrzeżenia producenta. "
        "Treść wyłącznie do podglądu interfejsu.",
        ids[2],
        "P3D",
        ids[3],
        ids[4],
        "brak",
        "PL",
        "Miasto testowe",
        "00-001",
        "MAZOWIECKIE",
        "VAT",
    )
    parent = QWidget()
    wyniki = []
    for motyw, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
        zastosuj_motyw(app, motyw)
        d = DaneSprzedazyAllegro(parent, refs, u, 200)
        d.show()
        app.processEvents()
        for i, suffix in ((0, "gpsr"), (1, "dostawa"), (2, "warunki")):
            d.tabs.setCurrentIndex(i)
            app.processEvents()
            wyniki.append(d.grab().save(str(cel / f"vexlab-{suffix}-043-{name}.png")))
        d.reject()
    with TemporaryDirectory(prefix="vexlab-visual-") as folder:
        api = Katalog()
        service = NoweSzkiceAllegro(api, RejestrTworzeniaJSON(Path(folder)), api)
        s = SesjaAllegro(
            KontoAllegro("test", "konto_testowe"),
            SrodowiskoAllegro.SANDBOX,
            "fixture",
            3700,
            aplikacja=AplikacjaAllegro("fixture", "fixture", zapis_szkicow=True),
        )
        o = OfertaPodglad(
            1,
            "SKU-TEST-001",
            "Osłona testowa do motocykla",
            "<p>Opis testowy</p>",
            "5901234123457",
            "289.00",
            "",
            ("https://images.example.org/test.jpg",),
            (),
            (),
        )

        def run(f, ok, err):
            QTimer.singleShot(0, lambda: ok(f()))

        w = DialogNowychSzkicow(parent, service, s, (o, replace(o, sku="SKU-TEST-002")), run)
        w.waluta.setCurrentIndex(w.waluta.findData("PLN"))
        for i in range(2):
            w.ustawienia[i] = UstawieniaSzkicu(
                "PLN",
                1,
                nowy=True,
                kategoria="123",
                sprzedaz=u,
                wartosci=(("stan", "nowy"), ("marka", "test"), ("masa", "1.2")),
            )
        w.show()
        w.przygotuj()

        def gotowe():
            if w.trwa:
                QTimer.singleShot(20, gotowe)
                return
            w.tabela.selectRow(0)
            for motyw, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
                zastosuj_motyw(app, motyw)
                app.processEvents()
                wyniki.append(w.grab().save(str(cel / f"vexlab-przygotowanie-043-{name}.png")))

                def capture(name=name):
                    d = next((item for item in w.findChildren(QDialog) if item.isVisible()), None)
                    if d:
                        wyniki.append(d.grab().save(str(cel / f"vexlab-parametry-043-{name}.png")))
                        d.reject()

                QTimer.singleShot(60, capture)
                w.uzupelnij()
            w.reject()
            app.quit()

        QTimer.singleShot(100, gotowe)
        result = app.exec()
    return result or int(not all(wyniki))


if __name__ == "__main__":
    raise SystemExit(main())
