"""Podgląd okna na 35 syntetycznych produktach, bez połączenia z Allegro."""

import sys
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

from capture_gpsr_allegro import Katalog
from PySide6.QtCore import QItemSelectionModel, QTimer
from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.rejestr_tworzenia_allegro import RejestrTworzeniaJSON
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.nowe_szkice_allegro import NoweSzkiceAllegro, UstawieniaSzkicu
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.powloka import Motyw


def main() -> int:
    app = QApplication(sys.argv)
    cel = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    parent = QWidget()
    with TemporaryDirectory(prefix="vexlab-preview-") as folder:
        api = Katalog()
        service = NoweSzkiceAllegro(api, RejestrTworzeniaJSON(Path(folder)), api)
        s = SesjaAllegro(
            KontoAllegro("test", "konto_testowe"),
            SrodowiskoAllegro.SANDBOX,
            "fixture",
            3700,
            aplikacja=AplikacjaAllegro("fixture", "fixture", zapis_szkicow=True),
        )
        o = OfertaPodglad(
            1,
            "SKU-TEST-001",
            "Osłona reflektora — model testowy",
            "<p>Dane testowe</p>",
            "5901234123457",
            "289.00",
            "",
            ("https://images.example.org/test.jpg",),
            (),
            (),
        )
        oferty = tuple(replace(o, sku=f"SKU-TEST-{i:03d}", cena=str(289 + i)) for i in range(1, 36))
        jobs = []
        w = DialogNowychSzkicow(parent, service, s, oferty, lambda *args: jobs.append(args))
        w.kompletny.setChecked(False)
        w.waluta.setCurrentIndex(w.waluta.findData("PLN"))
        for i in range(len(oferty)):
            w.ustawienia[i] = UstawieniaSzkicu(
                "PLN",
                1,
                nowy=True,
                kategoria="123",
                wartosci=(("stan", "nowy"), ("marka", "test"), ("masa", "1.2")),
                zrodla=(("kod", "sku"), ("ean", "ean")),
            )
        w.przygotuj()
        function, ok, _ = jobs.pop()
        ok(function())
        flags = QItemSelectionModel.SelectionFlag.Select | QItemSelectionModel.SelectionFlag.Rows
        for i in range(3):
            w.tabela.selectionModel().select(w.tabela.model().index(i, 0), flags)
        w.tabela.setCurrentCell(0, 0, QItemSelectionModel.SelectionFlag.NoUpdate)
        for motif, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
            zastosuj_motyw(app, motif)
            w.show()
            app.processEvents()
            if not w.grab().save(str(cel / f"vexlab-przygotowanie-045-{name}.png")):
                return 1
        w.close()
    QTimer.singleShot(0, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
