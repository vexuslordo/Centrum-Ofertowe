"""Ekran oceny 0.39: izolowana baza, syntetyczne oferty, bez połączenia z API."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QSettings, QTimer
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.adaptery.propozycje_szkicow_json import PropozycjeJSON
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KontoAllegro,
    LicznikiAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StatusOfertyAllegro,
    StronaSzkicowAllegro,
    SzczegolySzkicuAllegro,
    SzkicAllegro,
)
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.przypadki_uzycia.propozycje_szkicow import PropozycjeSzkicow

OFERTY = tuple(
    SzkicAllegro(
        str(10001 + i),
        tytul,
        f"TEST-{i + 1:03}",
        cena,
        "PLN",
        i + 1,
        status=(
            StatusOfertyAllegro.AKTYWNA,
            StatusOfertyAllegro.ZAKONCZONA,
            StatusOfertyAllegro.SZKIC,
        )[i % 3],
    )
    for i, (tytul, cena) in enumerate(
        (
            ("Osłona chłodnicy motocykla — wariant czarny", "289.00"),
            ("Klamka hamulca z regulacją — aluminium", "179.90"),
            ("Zestaw mocowań do uchwytu tablicy", "119.00"),
            ("Ciężarki kierownicy — zestaw dwóch sztuk", "149.00"),
            ("Uchwyt nawigacji do motocykla", "219.00"),
            ("Osłona silnika — komplet montażowy", "459.00"),
        )
    )
)


class OdczytTestowy:
    mozna_zapamietac = False

    def teraz(self):
        return 100

    def szkice(self, sesja, offset=0):
        return StronaSzkicowAllegro(OFERTY, len(OFERTY), 0, 50)

    def oferty(self, sesja, status, offset=0):
        return self.szkice(sesja, offset)

    def oferta(self, sesja, ident):
        return self.szkic(sesja, ident)

    def szkic(self, sesja, ident):
        p = next(p for p in OFERTY if p.id == ident)
        return SzczegolySzkicuAllegro(
            p.id, p.tytul, p.sku, p.cena, p.waluta, p.stan, "Kategoria testowa", (), (), p.status
        )

    def liczniki(self, sesja):
        return LicznikiAllegro(2, 2)


def main() -> int:
    app = QApplication(sys.argv)
    cel = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    cel.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix="vexlab-allegro-visual-") as katalog:
        tmp = Path(katalog)
        repo = KatalogSQLite(tmp / "katalog.sqlite3")
        okno = OknoVexLab(
            PowlokaAplikacji(
                PreferencjeQt(QSettings(str(tmp / "prefs.ini"), QSettings.Format.IniFormat)),
                "Podgląd • dane testowe",
                "0.39.1 — ekran do oceny",
            ),
            KatalogProduktow(repo, repo),
            RejestrProducentow(repo),
            EksportujKatalog(EksportCSV()),
            ImportujProdukty(CzytnikTabel(), ImportSQLite(repo.plik), repo),
            allegro=OdczytTestowy(),
            propozycje_szkicow=PropozycjeSzkicow(PropozycjeJSON()),
        )
        okno.resize(1536, 1024)
        okno.show()
        okno.przejdz("Allegro")
        s = okno.strona_allegro
        wyniki = []
        etapy = iter(
            (
                ("dark", Motyw.CIEMNY, 1536),
                ("light", Motyw.JASNY, 1536),
                ("small", Motyw.CIEMNY, 1100),
                ("permissions-dark", Motyw.CIEMNY, 1536),
                ("permissions-light", Motyw.JASNY, 1536),
                ("empty", Motyw.CIEMNY, 1536),
            )
        )

        def nastepny():
            if okno._zadania or s.trwa:
                QTimer.singleShot(30, nastepny)
                return
            etap = next(etapy, None)
            if etap is None:
                okno.close()
                app.quit()
                return
            nazwa, motyw, szerokosc = etap
            okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(motyw))
            okno.resize(szerokosc, 1024)
            if nazwa.startswith("permissions"):
                okno._pokaz_ustawienia_allegro()
                s.zgoda_zapis.setChecked(True)
            else:
                okno.przejdz("Allegro")
                if nazwa == "empty":
                    s.anuluj()
                else:
                    s.tabela.selectRow(0)

            def zapisz():
                if okno._zadania or s._panel_trwa:
                    QTimer.singleShot(30, zapisz)
                    return
                wyniki.append(okno.grab().save(str(cel / f"vexlab-allegro-0391-{nazwa}.png")))
                nastepny()

            QTimer.singleShot(250, zapisz)

        def start():
            s.status_listy = None
            s.obszar.ustaw_status_listy(None)
            s._polaczono(
                SesjaAllegro(
                    KontoAllegro("TEST", "konto_testowe"),
                    SrodowiskoAllegro.SANDBOX,
                    "fixture",
                    3700,
                    aplikacja=AplikacjaAllegro("fixture", "fixture", SrodowiskoAllegro.SANDBOX),
                ),
                False,
            )
            nastepny()

        QTimer.singleShot(100, start)
        wynik = app.exec()
        return wynik if wynik else int(not wyniki or not all(wyniki))


if __name__ == "__main__":
    raise SystemExit(main())
