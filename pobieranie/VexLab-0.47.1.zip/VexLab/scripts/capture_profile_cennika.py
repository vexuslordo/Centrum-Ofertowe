"""Izolowany widok rozpoznanego cennika; wyłącznie dane syntetyczne."""

from importlib.metadata import version
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QSettings, QTimer
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.adaptery.profile_cennikow_json import ProfileCennikowJSON
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty, Mapowanie, MapowanieCeny
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow
from vexlab.przypadki_uzycia.profile_cennikow import ProfileCennikow


def main() -> int:
    app = QApplication([])
    cel = Path(__file__).resolve().parents[1] / "docs/screenshots"
    cel.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix="vexlab-profile-visual-") as folder:
        tmp = Path(folder)
        repo = CennikiSQLite(tmp / "test.sqlite3")
        imp = ImportujProdukty(CzytnikTabel(), repo, repo)
        prod = RejestrProducentow(repo)
        pid = prod.dodaj(DaneProducenta("Producent testowy")).id
        profile = ProfileCennikow(ProfileCennikowJSON(tmp / "profile"))
        plik = tmp / "Przykladowy_cennik_2027.csv"
        plik.write_text(
            "Nazwa;SKU;Cena\nProdukt testowy A;TEST-A;100\nProdukt testowy B;TEST-B;200\n",
            encoding="utf-8",
        )
        dane = imp.odczytaj(plik)
        profile.zapisz(
            dane, 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "PLN", "brutto")), pid, "Mój układ"
        )
        w = OknoVexLab(
            PowlokaAplikacji(
                PreferencjeQt(QSettings(str(tmp / "prefs.ini"), QSettings.Format.IniFormat)),
                "uzytkownik_testowy",
                version("vexlab"),
            ),
            KatalogProduktow(repo, repo),
            prod,
            EksportujKatalog(EksportCSV()),
            imp,
            cenniki=BibliotekaCennikow(repo, imp),
            profile_cennikow=profile,
        )
        w.show()
        sukces = []

        def zapisz(nazwa: str) -> None:
            sukces.append(w.grab().save(str(cel / nazwa)))

        def maly() -> None:
            zapisz("vexlab-profile-cennikow-small.png")
            w.close()
            app.quit()

        def jasny() -> None:
            zapisz("vexlab-profile-cennikow-light.png")
            w.resize(900, 800)
            QTimer.singleShot(150, maly)

        def gotowe() -> None:
            if w._zadania or w.strona_importu._trwa:
                QTimer.singleShot(30, gotowe)
                return
            zapisz("vexlab-profile-cennikow-dark.png")
            w.wybor_motywu.setCurrentIndex(w.wybor_motywu.findData(Motyw.JASNY))
            QTimer.singleShot(150, jasny)

        def wczytaj() -> None:
            if w._zadania:
                QTimer.singleShot(30, wczytaj)
                return
            s = w.strona_cennikow
            if s is not None:
                s.nowy()
            QTimer.singleShot(30, wczytaj_plik)

        def wczytaj_plik() -> None:
            if w._zadania or w.strona_importu._trwa:
                QTimer.singleShot(30, wczytaj_plik)
                return
            w.strona_importu._zadanie(lambda: (dane, prod.lista()), w.strona_importu._plik_wczytany)
            QTimer.singleShot(100, gotowe)

        def zacznij() -> None:
            if w._zadania:
                QTimer.singleShot(30, zacznij)
                return
            w.przejdz("Cenniki")
            QTimer.singleShot(100, wczytaj)

        QTimer.singleShot(100, zacznij)
        QTimer.singleShot(30000, lambda: app.exit(1))
        app.exec()
        w.pula.waitForDone(30000)
        return 0 if sukces == [True, True, True] else 1


if __name__ == "__main__":
    raise SystemExit(main())
