"""Powtarzalne kontrole lokalne i CI, bez operacji sieciowych."""

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    narzedzia = Path(sys.executable).parent
    linter = narzedzia / ("lint-imports.exe" if os.name == "nt" else "lint-imports")
    polecenia = [
        [sys.executable, "-m", "ruff", "check", "src", "tests", "scripts"],
        [sys.executable, "-m", "ruff", "format", "--check", "src", "tests", "scripts"],
        [sys.executable, "-m", "mypy", "src"],
        [str(linter), "--no-cache"],
        [sys.executable, "-m", "bandit", "-r", "src", "-q"],
        [sys.executable, "-m", "pytest"],
        [sys.executable, "-m", "vexlab", "--diagnostyka"],
    ]
    srodowisko = dict(os.environ)
    if sys.platform.startswith("linux"):
        srodowisko.setdefault("QT_QPA_PLATFORM", "offscreen")
    for polecenie in polecenia:
        print("Kontrola:", " ".join(polecenie), flush=True)
        wynik = subprocess.run(polecenie, cwd=ROOT, env=srodowisko, check=False)
        if wynik.returncode:
            return wynik.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
