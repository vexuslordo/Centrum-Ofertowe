"""Oddzielny audyt pełnych zależności runtime i developerskich z uv.lock."""

import os
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    wynik_audytu = 0
    uv = Path(sys.executable).parent / ("uv.exe" if os.name == "nt" else "uv")
    with TemporaryDirectory(prefix="vexlab-audit-") as katalog:
        for nazwa, grupa in [("runtime", ["--no-dev"]), ("dev", ["--only-group", "dev"])]:
            plik = Path(katalog) / f"{nazwa}.txt"
            eksport = subprocess.run(
                [
                    str(uv),
                    "export",
                    "--frozen",
                    "--format",
                    "requirements-txt",
                    "--no-emit-project",
                    "--no-hashes",
                    *grupa,
                    "--output-file",
                    str(plik),
                ],
                cwd=ROOT,
                check=False,
                stdout=subprocess.DEVNULL,
            )
            if eksport.returncode:
                return eksport.returncode
            print(f"Audyt {nazwa}: wszystkie zależności przechodnie z blokady", flush=True)
            # --no-deps nie pomija zależności: są już jawnie wyeksportowane z uv.lock.
            # --disable-pip wyłącza ponowny resolver, nie kontrolę podatności ani TLS.
            wynik = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pip_audit",
                    "--disable-pip",
                    "--no-deps",
                    "--progress-spinner",
                    "off",
                    "--requirement",
                    str(plik),
                ],
                cwd=ROOT,
                check=False,
            )
            if wynik.returncode:
                wynik_audytu = wynik.returncode
    return wynik_audytu


if __name__ == "__main__":
    raise SystemExit(main())
