"""Podgląd procesu nowych produktów na syntetycznych danych; żadnych żądań API ani publikacji."""

import sys
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QWidget

from vexlab.adaptery.rejestr_tworzenia_allegro import RejestrTworzeniaJSON
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.nowe_szkice_allegro import DialogNowychSzkicow
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    NoweSzkiceAllegro,
    ParametrSzkicu,
    ProduktSzkicu,
    UstawieniaSzkicu,
)
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.powloka import Motyw


class KatalogTestowy:
    def teraz(self):
        return 100

    def znajdz_produkty(self, *args):
        return (
            ProduktSzkicu(
                "c9e39cae-9cb6-11e9-a2a3-2a2ae2dbcce4", "Osłona testowa motocykla", "123"
            ),
        )

    def produkt_szkicu(self, s, ident):
        return ProduktSzkicu(
            ident,
            "Osłona testowa motocykla",
            "123",
            (ParametrSzkicu("11323", "Stan", "dictionary", True, (("11323_1", "Nowy"),)),),
        )

    def nowy_produkt(self, s, kategoria, odswiez=False):
        return ProduktSzkicu(
            "",
            "Części motocyklowe",
            kategoria,
            (
                ParametrSzkicu("11323", "Stan", "dictionary", True, (("11323_1", "Nowy"),)),
                ParametrSzkicu("kod", "Kod producenta", "string", False, (), True, True),
            ),
        )


def main() -> int:
    app = QApplication(sys.argv)
    cel = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    cel.mkdir(exist_ok=True)
    parent = QWidget()
    with TemporaryDirectory(prefix="vexlab-zip-visual-") as katalog:
        api = KatalogTestowy()
        serwis = NoweSzkiceAllegro(api, RejestrTworzeniaJSON(Path(katalog)), api)
        sesja = SesjaAllegro(
            KontoAllegro("test", "konto_testowe"),
            SrodowiskoAllegro.SANDBOX,
            "fixture",
            3700,
            aplikacja=AplikacjaAllegro("fixture", "fixture", zapis_szkicow=True),
        )
        oferta = OfertaPodglad(
            1,
            "TEST-001",
            "Osłona testowa do motocykla",
            "<p>Opis testowy</p>",
            "5901234123457",
            "289.00",
            "",
            ("https://images.example.org/test.jpg",),
            (),
            (),
        )
        oferty = (
            oferta,
            replace(oferta, numer=2, sku="TEST-002", cena="319.00"),
            replace(oferta, numer=3, sku="TEST-003", cena="brak"),
        )

        def uruchom(funkcja, sukces, blad):
            # Wyłącznie szybkie fixture'y bez sieci/dysku; produkcja używa Zadanie/Qt pool.
            QTimer.singleShot(0, lambda: sukces(funkcja()))

        d = DialogNowychSzkicow(parent, serwis, sesja, oferty, uruchom)
        d.setWindowTitle("VexLab 0.42 • podgląd na danych testowych")
        d.waluta.setCurrentIndex(d.waluta.findData("PLN"))
        for i in range(3):
            d.ustawienia[i] = UstawieniaSzkicu(
                "PLN",
                1,
                wartosci=(("11323", "11323_1"),),
                nowy=True,
                kategoria="123",
                zrodla=(("kod", "sku"),),
            )
        zastosuj_motyw(app, Motyw.CIEMNY)
        d.show()
        d.przygotuj()
        wyniki = []

        def jasny():
            wyniki.append(d.grab().save(str(cel / "vexlab-przygotowanie-042-light.png")))
            d.reject()
            app.quit()

        def gotowe():
            if d.trwa:
                QTimer.singleShot(20, gotowe)
                return
            d.zaznacz_widoczne()
            wyniki.append(d.grab().save(str(cel / "vexlab-przygotowanie-042-dark.png")))
            zastosuj_motyw(app, Motyw.JASNY)
            QTimer.singleShot(100, jasny)

        QTimer.singleShot(100, gotowe)
        r = app.exec()
        return r if r else int(not wyniki or not all(wyniki))


if __name__ == "__main__":
    raise SystemExit(main())
