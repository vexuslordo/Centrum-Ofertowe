@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if errorlevel 1 goto blad_folder
if not exist "pyproject.toml" goto blad_folder
if not exist "uv.lock" goto blad_folder
if not exist "src\vexlab\__main__.py" goto blad_folder
set "UV_PROJECT_ENVIRONMENT=%CD%\.venv"
set "PYTHONHOME="
set "PYTHONPATH="
echo Przygotowywanie srodowiska VexLab...
py -3.13 -m uv sync --frozen --no-dev --project "."
if errorlevel 1 goto blad_instalacji
if not exist ".venv\Scripts\python.exe" goto blad_instalacji
echo Uruchamianie VexLab...
".venv\Scripts\python.exe" -m vexlab
if errorlevel 1 goto blad_startu
exit /b 0
:blad_folder
echo Nie znaleziono pelnego folderu programu. Rozpakuj caly ZIP,
echo a potem otworz folder VexLab zawierajacy pyproject.toml i src.
goto koniec_bledu
:blad_instalacji
echo Nie udalo sie przygotowac srodowiska. Zachowaj komunikat powyzej.
echo Instrukcja instalacji Pythona i uv znajduje sie w README.md.
goto koniec_bledu
:blad_startu
echo Nie udalo sie uruchomic VexLab z lokalnego srodowiska.
echo Zachowaj komunikat bledu powyzej.
:koniec_bledu
pause
exit /b 1
