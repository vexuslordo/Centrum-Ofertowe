# Znak VEX

Znak dostarczony przez właściciela w rozmowie 2026-11-09 do wykorzystania
jako logo VexLab. Wersja PNG z przezroczystością przygotowana na podstawie
przesłanego obrazu; zachowano biało-srebrny monogram VEX.
Plik aplikacji: src/vexlab/gui/zasoby/vex-logo.png.
Nagłówek i ikona okna korzystają z tego samego zasobu, dopasowanego przez
renderer Qt do poziomego pola lub kwadratowej ikony na ciemnym tle.
Nie przypisujemy logo licencji Simple Icons ani Font Awesome.
Poprzedni znak vexlabs.png pozostaje w pakiecie historycznym, bez użycia w GUI.
