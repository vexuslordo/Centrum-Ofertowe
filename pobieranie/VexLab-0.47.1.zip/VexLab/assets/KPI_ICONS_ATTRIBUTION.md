# Ikony kafelków KPI

- Pudełko 3D: własne kształty SVG odtworzone według referencji właściciela.
- Metka i dokument: Font Awesome Free 6.7.2, `tag` i `file-lines`,
  Copyright 2024 Fonticons, Inc., CC BY 4.0.
  Źródła: https://github.com/FortAwesome/Font-Awesome/tree/6.7.2/svgs/solid
  Licencja: https://creativecommons.org/licenses/by/4.0/
  Informacje upstream: FONT_AWESOME_FREE_LICENSE.txt.

Modyfikacje: białe wypełnienie, osadzenie symboli w kwadratowych tłach
z gradientem i zaokrągleniem. Wykrzyknik w okręgu i tła kafelków są
lokalnymi kształtami SVG/Qt przygotowanymi dla VexLab. Brak pobierania ikon
z sieci podczas uruchamiania programu. Ikony używane tylko na kafelkach KPI;
pozostałe dotychczasowe ikony menu zachowane.
