from uuid import uuid4

import pytest

from vexlab.domena.producent import NieprawidlowyProducent, Producent


@pytest.mark.parametrize("nazwa", ["", "   ", " Nazwa"])
def test_producent_wymaga_niepustej_nazwy(nazwa: str) -> None:
    with pytest.raises(NieprawidlowyProducent):
        Producent(uuid4(), nazwa)


def test_zmiana_i_dezaktywacja_zachowuja_id() -> None:
    producent = Producent(uuid4(), "Testowy A")
    zmieniony = producent.zmien("Testowy B", False)
    assert zmieniony.id == producent.id
    assert zmieniony.wersja == 2
    assert zmieniony.aktywny is False
    assert producent.aktywny is True
