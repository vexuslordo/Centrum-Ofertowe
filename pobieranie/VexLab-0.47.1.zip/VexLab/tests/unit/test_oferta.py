from uuid import uuid4

import pytest

from vexlab.domena.oferta import SzkicOferty


@pytest.mark.parametrize("tytul", ["", "   "])
def test_szkic_wymaga_tytulu(tytul):
    with pytest.raises(ValueError):
        SzkicOferty(uuid4(), uuid4(), 1, tytul, "")


def test_edycja_nie_zmienia_produktu_i_zwieksza_wersje():
    s = SzkicOferty(uuid4(), uuid4(), 4, "Tytuł", "")
    n = s.zmien(" Nowy ", "<p>HTML</p>")
    assert n.id == s.id and n.produkt_id == s.produkt_id and n.wersja_produktu == 4
    assert n.wersja == 2 and n.tytul == "Nowy" and s.tytul == "Tytuł"


def test_samodzielny_szkic_ma_wlasna_wersje_i_nie_wymaga_produktu():
    s = SzkicOferty(uuid4(), None, None, "Oferta z ZIP", "<p>Opis</p>")
    n = s.zmien("Nowy tytuł", "<p>Nowy opis</p>")
    assert n.produkt_id is None and n.wersja_produktu is None and n.wersja == 2


@pytest.mark.parametrize("produkt,wersja", [(None, 1), (uuid4(), None), (uuid4(), 0)])
def test_powiazanie_produktu_wymaga_kompletnej_dodatniej_pary(produkt, wersja):
    with pytest.raises(ValueError):
        SzkicOferty(uuid4(), produkt, wersja, "Tytuł", "")
