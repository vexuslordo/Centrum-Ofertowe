from uuid import uuid4

import pytest

from vexlab.domena.produkt import DopasowanieMotocykla, NieprawidlowyProdukt, Produkt


@pytest.mark.parametrize("od,do", [(None, None), (2020, None), (2020, 2020), (1000, 9999)])
def test_roczniki_opcjonalne_i_graniczne(od, do):
    d = DopasowanieMotocykla("Marka", "Model", od, do)
    assert d.rok_od == od and d.rok_do == do


@pytest.mark.parametrize(
    "marka,model,od,do",
    [
        ("", "M", None, None),
        ("A", " ", None, None),
        ("A", "M", 999, None),
        ("A", "M", 2020, 10000),
        ("A", "M", None, 2020),
        ("A", "M", 2022, 2020),
        ("A", "M", True, None),
    ],
)
def test_odrzuca_niepelne_dopasowania_i_roczniki(marka, model, od, do):
    with pytest.raises(NieprawidlowyProdukt):
        DopasowanieMotocykla(marka, model, od, do)


def test_wiele_dopasowan_duplikat_i_zachowanie_przy_edycji():
    a = DopasowanieMotocykla("Marka", "Model", 2020, 2021, "S")
    b = DopasowanieMotocykla("Marka", "Model", 2020, 2021, "R")
    p = Produkt(uuid4(), "Część", "TEST", dopasowania=(a, b))
    assert p.zmien("Nowa nazwa", "TEST", "Opis").dopasowania == (a, b)
    assert p.zmien("Nowa", "TEST", "", dopasowania=()).dopasowania == ()
    with pytest.raises(NieprawidlowyProdukt, match="powtórzone"):
        Produkt(
            uuid4(),
            "Część",
            "TEST",
            dopasowania=(a, DopasowanieMotocykla(" marka ", "MODEL", 2020, 2021, "s")),
        )
