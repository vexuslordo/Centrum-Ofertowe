from dataclasses import FrozenInstanceError
from uuid import uuid4

import pytest

from vexlab.domena.produkt import NieprawidlowyProdukt, Produkt


@pytest.mark.parametrize(("nazwa", "sku"), [("", "A"), ("  ", "A"), ("A", ""), ("A", " ")])
def test_nazwa_i_sku_sa_obowiazkowe(nazwa: str, sku: str) -> None:
    with pytest.raises(NieprawidlowyProdukt):
        Produkt(uuid4(), nazwa, sku)


def test_edycja_zachowuje_id_i_zwieksza_wersje() -> None:
    p = Produkt(uuid4(), "Przed", "TEST-A")
    zmieniony = p.zmien("Po", "TEST-B", "Opis")
    assert zmieniony.id == p.id
    assert zmieniony.wersja == 2
    assert p.wersja == 1
    assert p.nazwa == "Przed"


def test_produkt_jest_niezmienny() -> None:
    produkt = Produkt(uuid4(), "Test", "TEST-A")
    with pytest.raises(FrozenInstanceError):
        produkt.sku = "INNY"


def test_nieprawidlowa_wersja_odrzucona() -> None:
    with pytest.raises(NieprawidlowyProdukt):
        Produkt(uuid4(), "Test", "TEST-A", wersja=0)
