from uuid import uuid4

import pytest

from vexlab.domena.produkt import NieprawidlowyProdukt, Produkt, sprawdz_ean


@pytest.mark.parametrize("ean", ["", "96385074", "5901234123457", "0123456789012"])
def test_opcjonalny_ean_i_zera_wiodace(ean):
    sprawdz_ean(ean)
    p = Produkt(uuid4(), "Nazwa", "SKU", ean=ean)
    assert p.zmien("Inna", "SKU", "Opis").ean == ean
    assert p.zmien("Inna", "SKU", "Opis", ean="").ean == ""


@pytest.mark.parametrize(
    "ean",
    [
        "123",
        "5901234123458",
        "96385075",
        " 96385074",
        "9638 5074",
        "９６３８５０７４",
        "5.901234123457E12",
        "96385074.0",
        None,
        96385074,
    ],
)
def test_bledny_ean_jest_jawnym_bledem_pola(ean):
    with pytest.raises(NieprawidlowyProdukt) as exc:
        Produkt(uuid4(), "Nazwa", "SKU", ean=ean)
    assert exc.value.pole == "ean"
