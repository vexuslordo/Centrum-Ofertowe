import json

import pytest

from vexlab import bootstrap
from vexlab.rdzen.kontrakty import BladTechniczny


def test_cli_zwraca_blad_z_korelacja_bez_fikcyjnego_sukcesu(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    def awaria() -> None:
        raise BladTechniczny("Brak wymaganej instalacji PySide6.")

    monkeypatch.setattr("sys.argv", ["vexlab", "--diagnostyka"])
    monkeypatch.setattr(bootstrap, "zloz_diagnostyke", awaria)
    assert bootstrap.main() == 1
    komunikat = json.loads(capsys.readouterr().out)
    assert komunikat["blad"] == "Brak wymaganej instalacji PySide6."
    assert komunikat["id_korelacji"]
    assert "zakres" not in komunikat
