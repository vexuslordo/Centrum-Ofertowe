from dataclasses import replace

import pytest

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.edycja_paczki_allegro import (
    ZmianyPaczek,
    zmien_parametry,
    zmien_pozycje,
)


def test_rozne_ceny_zaokraglenie_i_zachowane_pola_zrodlowe(nowe_szkice_fixture):
    _, _, _, _, o, u = nowe_szkice_fixture
    pairs = ((o, u), (replace(o, sku="2", cena="9.95"), replace(u, cena="19.95")))
    w = zmien_pozycje(
        pairs,
        ZmianyPaczek(
            cena="procent", wartosc="10", ilosc=12, tytuly=True, szukaj="Testowy", zamien="Nowy"
        ),
    )
    assert [u.cena for o, u in w] == ["135.74", "21.95"]
    assert all(u.ilosc == 12 for o, u in w)
    assert w[0][0].tytul.startswith("Nowy")
    assert w[0][0].ean == o.ean and w[0][0].sekcje == o.sekcje
    assert pairs[0] == (o, u) and not u.cena


@pytest.mark.parametrize(
    "zmiana",
    [
        ZmianyPaczek(cena="ustaw", wartosc="NaN"),
        ZmianyPaczek(cena="kwota", wartosc="-999"),
        ZmianyPaczek(tytuly=True, po="a" * 80),
        ZmianyPaczek(ilosc=-1),
    ],
)
def test_blad_nie_daje_czesciowego_wyniku(nowe_szkice_fixture, zmiana):
    _, _, _, _, o, u = nowe_szkice_fixture
    with pytest.raises(BladAllegro):
        zmien_pozycje(((o, u),), zmiana)
    assert not u.cena and u.ilosc == 1


def test_wspolny_producent_zachowuje_kody_i_zrodla(nowe_produkty_fixture):
    _, _, _, _, _, u = nowe_produkty_fixture
    u = replace(u, wartosci=(*u.wartosci, ("indywidualny", "wartość")))
    w = zmien_parametry(u, (("marka", "wybrana"),), ())
    assert dict(w.wartosci)["indywidualny"] == "wartość"
    assert w.zrodla == u.zrodla
    w = zmien_parametry(w, (("kod", "RĘCZNIE"),), ())
    assert "kod" not in dict(w.zrodla) and dict(w.zrodla)["ean"] == "ean"


def test_automatyczne_sku_ean_sa_per_oferta_i_mozna_je_zmienic(nowe_produkty_fixture):
    service, api, _, s, o, u = nowe_produkty_fixture
    u = replace(u, zrodla=())
    first = service.przygotuj(s, o, u)
    other = service.przygotuj(s, replace(o, sku="INNY", ean="4006381333931"), u)
    assert not first.bledy and not other.bledy
    assert dict(first.ustawienia.wartosci)["kod"] == o.sku
    assert dict(other.ustawienia.wartosci)["kod"] == "INNY"
    assert dict(other.ustawienia.wartosci)["ean"] == "4006381333931"
    manual = service.przygotuj(
        s, o, replace(u, wartosci=(*u.wartosci, ("kod", "własny"), ("ean", "")))
    )
    assert dict(manual.ustawienia.wartosci)["kod"] == "własny"
    assert dict(manual.ustawienia.wartosci)["ean"] == ""
    assert "POST" not in api.calls
