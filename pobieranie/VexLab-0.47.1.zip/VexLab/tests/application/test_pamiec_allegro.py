from dataclasses import replace
from threading import Event, Thread

import pytest

from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    BladAllegro,
    KontoAllegro,
    PolaczAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    TokenAllegro,
    ZapamietaneAllegro,
)


class Czas:
    def teraz(self):
        return 100


class Magazyn:
    def __init__(self):
        self.zapis = ZapamietaneAllegro(
            AplikacjaAllegro("test-client", "test-secret"),
            KontoAllegro("123", "testowy"),
            "old-refresh",
        )
        self.zapisy = []

    def odczytaj(self):
        return self.zapis

    def zapisz(self, d):
        self.zapis = d
        self.zapisy.append(d)

    def usun(self):
        self.zapis = None


class API:
    def __init__(self, magazyn):
        self.magazyn = magazyn
        self.error = None

    def odnow(self, aplikacja, token):
        assert aplikacja.sekret == "test-secret" and token == "old-refresh"
        return TokenAllegro("new-access", 3600, "rotated-refresh")

    def konto(self, s, token):
        assert self.magazyn.zapis.odswiezanie == "rotated-refresh"
        assert token == "new-access"
        if self.error:
            raise self.error
        return KontoAllegro("123", "testowy")


def test_przywrocenie_odnawia_token_i_potwierdza_konto_zanim_zwroci_sesje():
    m = Magazyn()
    s = PolaczAllegro(API(m), Czas(), m).przywroc()
    assert s.konto.id == "123" and s.wygasa == 3700
    assert s.token == "new-access" and s.odswiezanie == "rotated-refresh"
    assert "new-access" not in repr(s) and "rotated-refresh" not in repr(s)


def test_rotacja_zachowana_rowniez_po_bledzie_me():
    m = Magazyn()
    api = API(m)
    api.error = BladAllegro("SIEC", "Brak sieci")
    with pytest.raises(BladAllegro):
        PolaczAllegro(api, Czas(), m).przywroc()
    assert m.zapis.odswiezanie == "rotated-refresh"


def test_blad_odnowienia_nie_kasuje_zapisu_i_nie_udaje_sukcesu():
    class Odmowa(API):
        def odnow(self, *a):
            raise BladAllegro("WYGASLA", "Zgoda cofnięta")

    m = Magazyn()
    with pytest.raises(BladAllegro):
        PolaczAllegro(Odmowa(m), Czas(), m).przywroc()
    assert m.zapis.odswiezanie == "old-refresh" and not m.zapisy


def test_pusty_magazyn_nie_powoduje_zadania_api():
    m = Magazyn()
    m.zapis = None
    assert PolaczAllegro(object(), Czas(), m).przywroc() is None
    assert PolaczAllegro(object(), Czas()).przywroc() is None


def test_inne_konto_nie_jest_pokazywane_jako_polaczone():
    class Inne(API):
        def konto(self, *a):
            return KontoAllegro("other", "inne")

    m = Magazyn()
    with pytest.raises(BladAllegro, match="inne konto"):
        PolaczAllegro(Inne(m), Czas(), m).przywroc()


def test_zapamietanie_wymaga_refresh_i_nie_przechowuje_access_tokenu():
    m = Magazyn()
    c = PolaczAllegro(object(), Czas(), m)
    s = SesjaAllegro(m.zapis.konto, SrodowiskoAllegro.PRODUKCJA, "access", 3700)
    with pytest.raises(BladAllegro):
        c.zapamietaj(s)
    c.zapamietaj(replace(s, aplikacja=m.zapis.aplikacja, odswiezanie="refresh"))
    assert m.zapis.odswiezanie == "refresh" and not hasattr(m.zapis, "token")
    c.zapomnij()
    assert m.zapis is None


def test_zapomnij_czeka_na_odnowienie_i_zapis_nie_wraca_po_usunieciu():
    m = Magazyn()
    started, resume, done = Event(), Event(), Event()

    class Wolne(API):
        def odnow(self, *a):
            started.set()
            assert resume.wait(5)
            return super().odnow(*a)

    c = PolaczAllegro(Wolne(m), Czas(), m)
    wyniki = []
    t = Thread(target=lambda: wyniki.append(c.przywroc()))
    t.start()
    assert started.wait(5)
    d = Thread(target=lambda: (c.zapomnij(), done.set()))
    d.start()
    assert not done.wait(0.05)
    resume.set()
    t.join(5)
    d.join(5)
    assert not t.is_alive() and not d.is_alive() and wyniki and m.zapis is None
