import pytest

from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji, PreferencjePowloki
from vexlab.rdzen.kontrakty import BladTechniczny


def test_awaria_zapisu_preferencji_nie_zmienia_aktywnego_stanu() -> None:
    class AwariaPreferencji:
        def odczytaj(self) -> PreferencjePowloki:
            return PreferencjePowloki()

        def zapisz(self, preferencje: PreferencjePowloki) -> None:
            raise BladTechniczny("Brak zapisu")

    powloka = PowlokaAplikacji(AwariaPreferencji(), "testowy", "test")
    with pytest.raises(BladTechniczny):
        powloka.ustaw_motyw(Motyw.JASNY)
    assert powloka.preferencje.motyw == Motyw.CIEMNY
