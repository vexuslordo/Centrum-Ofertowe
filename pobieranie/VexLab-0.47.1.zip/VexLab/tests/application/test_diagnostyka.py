from datetime import UTC, datetime
from uuid import UUID

import pytest

from vexlab.przypadki_uzycia.diagnostyka import (
    DiagnozujSrodowisko,
    WersjeSrodowiska,
)
from vexlab.rdzen.kontrakty import BladTechniczny, IdKorelacji

CHWILA = datetime(2026, 11, 2, 12, tzinfo=UTC)
KORELACJA = IdKorelacji(UUID("00000000-0000-0000-0000-000000000001"))


class ZegarTestowy:
    def teraz(self) -> datetime:
        return CHWILA


class CzytnikTestowy:
    def odczytaj(self) -> WersjeSrodowiska:
        return WersjeSrodowiska("python-test", "qt-test", "sqlite-test")


def test_wymienny_port_zwraca_wstrzykniete_wersje_czas_i_korelacje() -> None:
    raport = DiagnozujSrodowisko(ZegarTestowy(), CzytnikTestowy()).wykonaj(KORELACJA)
    assert raport.wersje == WersjeSrodowiska("python-test", "qt-test", "sqlite-test")
    assert raport.czas == CHWILA
    assert raport.id_korelacji == KORELACJA


def test_awaria_portu_nie_jest_prezentowana_jako_sukces() -> None:
    class UszkodzonyCzytnik:
        def odczytaj(self) -> WersjeSrodowiska:
            raise BladTechniczny("Nie można odczytać wersji.")

    with pytest.raises(BladTechniczny, match="Nie można odczytać"):
        DiagnozujSrodowisko(ZegarTestowy(), UszkodzonyCzytnik()).wykonaj(KORELACJA)


def test_czas_bez_strefy_jest_odrzucany() -> None:
    class ZegarBezStrefy:
        def teraz(self) -> datetime:
            return CHWILA.replace(tzinfo=None)

    with pytest.raises(BladTechniczny, match="bez strefy"):
        DiagnozujSrodowisko(ZegarBezStrefy(), CzytnikTestowy()).wykonaj(KORELACJA)
