import pytest

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import PrzegladajKatalog, StronaKatalogu, ZapytanieKatalogu
from vexlab.rdzen.kontrakty import BladTechniczny


class TylkoOdczyt:
    def __init__(self):
        self.wywolania = []

    def strona_katalogu(self, zapytanie, wybrane, *, wszystkie=False):
        self.wywolania.append((zapytanie, wybrane, wszystkie))
        return StronaKatalogu((), (), 0, 0, 0, zapytanie.rozmiar)


def test_odczyt_dziala_bez_repozytorium_zapisujacego_i_rejestru_producentow():
    port = TylkoOdczyt()
    serwis = PrzegladajKatalog(port)
    q = ZapytanieKatalogu(fraza="A")
    assert not serwis.strona(q).produkty
    assert serwis.wszystkie_wyniki(q) == ()
    assert port.wywolania == [(q, (), False), (q, (), True)]
    assert not hasattr(serwis, "dodaj") and not hasattr(serwis, "usun")


def test_bledne_zapytanie_nie_wywoluje_portu():
    port = TylkoOdczyt()
    with pytest.raises(BladScenariuszaKatalogu):
        PrzegladajKatalog(port).strona(ZapytanieKatalogu(numer=-1))
    assert not port.wywolania


def test_awaria_odczytu_nie_zwraca_fikcyjnej_pustej_strony():
    class Awaria:
        def strona_katalogu(self, *args, **kwargs):
            raise BladTechniczny("Brak odczytu")

    with pytest.raises(BladTechniczny, match="Brak odczytu"):
        PrzegladajKatalog(Awaria()).strona(ZapytanieKatalogu())
