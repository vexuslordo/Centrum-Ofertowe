from dataclasses import replace
from threading import Event

import pytest

from tests.application.test_oferty_allegro import Czas, sesja
from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    PolaczAllegro,
    StronaSzkicowAllegro,
    SzkicAllegro,
)


class API:
    def __init__(self, total=13182):
        self.total, self.calls = total, []

    def szukaj_ofert(self, s, status, offset, limit, pole, fraza):
        self.calls.append((offset, limit, pole, fraza))
        return StronaSzkicowAllegro(
            tuple(
                SzkicAllegro(str(i), "Testowa oferta")
                for i in range(offset, min(offset + limit, self.total))
            ),
            self.total,
            offset,
            limit,
        )


def test_wszystkie_przekraczaja_dawny_limit_10000_i_postep():
    api, progress = API(), []
    w = PolaczAllegro(api, Czas()).lista(
        sesja(), None, 0, 0, "name", "", lambda: False, lambda a, b: progress.append((a, b))
    )
    assert len(w.szkice) == w.lacznie == 13182
    assert len(api.calls) == 14 and api.calls[-1][0] == 13000
    assert len({o.id for o in w.szkice}) == 13182
    assert progress[-1] == (13182, 13182)


def test_wyszukiwanie_jest_przekazywane_na_serwer_nie_na_strone():
    api = API(1)
    w = PolaczAllegro(api, Czas()).lista(
        sesja(), None, 0, 50, "external.id", "SKU-13001", lambda: False, lambda *a: None
    )
    assert api.calls == [(0, 50, "external.id", "SKU-13001")]
    assert len(w.szkice) == 1


@pytest.mark.parametrize("tryb", ["stop", "duplikat", "zmiana", "pusto", "limit", "wygasla"])
def test_niepelna_lista_lub_anulowanie_nie_sa_sukcesem(tryb):
    api, clock, stop = API(2001), Czas(), Event()
    original = api.szukaj_ofert

    def fetch(*args):
        page = original(*args)
        if tryb == "stop":
            stop.set()
        if tryb == "limit":
            return replace(page, lacznie=100001)
        if tryb == "wygasla":
            clock.czas = 2000
        if len(api.calls) > 1:
            if tryb == "duplikat":
                return replace(page, szkice=(SzkicAllegro("0", "Duplikat"),))
            if tryb == "zmiana":
                return replace(page, lacznie=2002)
            if tryb == "pusto":
                return replace(page, szkice=())
        return page

    api.szukaj_ofert = fetch
    with pytest.raises(BladAllegro):
        PolaczAllegro(api, clock).lista(
            sesja(), None, 0, 0, "name", "", stop.is_set, lambda *a: None
        )
