from datetime import UTC, datetime

import pytest

from vexlab.przypadki_uzycia.srodowisko_gt import SprawdzSrodowiskoGT, SrodowiskoGT
from vexlab.rdzen.kontrakty import BladTechniczny


class Zegar:
    def teraz(self):
        return datetime(2026, 11, 7, 12, tzinfo=UTC)


class Czytnik:
    def odczytaj(self):
        return SrodowiskoGT("Windows testowy", "3.13", 64)


def test_raport_potwierdza_tylko_zebrane_metadane():
    raport = SprawdzSrodowiskoGT(Czytnik(), Zegar()).wykonaj()
    assert raport.czas.tzinfo is UTC
    assert "Python: 3.13 (64-bit)" in raport.tekst
    assert "Połączenie z serwerem: nie było sprawdzane" in raport.tekst
    assert "licencji Sfery" in raport.tekst
    assert "Połączono" not in raport.tekst


def test_awaria_czytnika_nie_jest_sukcesem():
    class Awaria:
        def odczytaj(self):
            raise BladTechniczny("Nie można odczytać metadanych")

    with pytest.raises(BladTechniczny):
        SprawdzSrodowiskoGT(Awaria(), Zegar()).wykonaj()


def test_zegar_bez_strefy_nie_daje_wiarygodnego_raportu():
    class ZegarBezStrefy:
        def teraz(self):
            return datetime(2026, 11, 7, 12)

    with pytest.raises(BladTechniczny, match="bez strefy"):
        SprawdzSrodowiskoGT(Czytnik(), ZegarBezStrefy()).wykonaj()
