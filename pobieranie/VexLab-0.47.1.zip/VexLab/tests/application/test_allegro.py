import pytest

from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    BladAllegro,
    KontoAllegro,
    PolaczAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    TokenAllegro,
)


class Czas:
    value = 100.0

    def teraz(self):
        return self.value


class API:
    def __init__(self):
        self.wywolania = []

    def rozpocznij(self, a):
        self.wywolania.append("device")

    def token(self, a, k):
        self.wywolania.append("token")
        return TokenAllegro("test-access", 3600)

    def konto(self, s, t):
        self.wywolania.append("me")
        return KontoAllegro("123", "testowy")

    def szkice(self, *a):
        self.wywolania.append("szkice")


def test_sesja_wymaga_rzeczywistego_me_i_ma_termin():
    api = API()
    serwis = PolaczAllegro(api, Czas())
    sesja = serwis.sprawdz(AplikacjaAllegro("c", "s"), "device")
    assert api.wywolania == ["token", "me"] and sesja.konto.id == "123" and sesja.wygasa == 3700


def test_blad_me_nie_zwraca_polaczonej_sesji():
    class Odmowa(API):
        def konto(self, *a):
            raise BladAllegro("UPRAWNIENIA", "Brak dostępu")

    with pytest.raises(BladAllegro):
        PolaczAllegro(Odmowa(), Czas()).sprawdz(AplikacjaAllegro("c", "s"), "device")


@pytest.mark.parametrize(
    "klient,sekret", [("", "s"), ("c", ""), ("a:b", "s"), ("a", "s\n"), ("c", "x" * 1025)]
)
def test_bledne_dane_nie_wywoluja_sieci(klient, sekret):
    api = API()
    with pytest.raises(BladAllegro):
        PolaczAllegro(api, Czas()).rozpocznij(AplikacjaAllegro(klient, sekret))
    assert api.wywolania == []


@pytest.mark.parametrize("offset,termin", [(0, 100), (-50, 500), (10000000, 500), (1, 500)])
def test_wygasla_sesja_i_zla_strona_nie_wywoluja_api(offset, termin):
    api = API()
    s = SesjaAllegro(KontoAllegro("123", "testowy"), SrodowiskoAllegro.PRODUKCJA, "t", termin)
    with pytest.raises(BladAllegro):
        PolaczAllegro(api, Czas()).szkice(s, offset)
    assert api.wywolania == []


@pytest.mark.parametrize("ident,termin", [("123", 100), ("../me", 500), ("", 500)])
def test_podglad_odrzuca_wygasla_sesje_i_zly_id_przed_siecia(ident, termin):
    api = API()
    s = SesjaAllegro(KontoAllegro("1", "test"), SrodowiskoAllegro.PRODUKCJA, "test", termin)
    with pytest.raises(BladAllegro):
        PolaczAllegro(api, Czas()).szkic(s, ident)
    assert api.wywolania == []


def test_wygasniecie_w_trakcie_odczytu_nie_pokazuje_starego_podgladu():
    czas = Czas()

    class WygasajaceAPI(API):
        def szkic(self, sesja, ident):
            czas.value = 1000
            return object()

    s = SesjaAllegro(KontoAllegro("1", "test"), SrodowiskoAllegro.PRODUKCJA, "test", 500)
    with pytest.raises(BladAllegro) as exc:
        PolaczAllegro(WygasajaceAPI(), czas).szkic(s, "123")
    assert exc.value.kod == "WYGASLA"
