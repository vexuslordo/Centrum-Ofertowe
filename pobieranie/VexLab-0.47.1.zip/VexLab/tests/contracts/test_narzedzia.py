import subprocess
import sys
from pathlib import Path


def test_ruff_wykrywa_blad_i_zle_formatowanie(tmp_path: Path) -> None:
    plik = tmp_path / "blad.py"
    plik.write_text("x=nieznana_nazwa\n", encoding="utf-8")
    for argumenty in (["check", str(plik)], ["format", "--check", str(plik)]):
        wynik = subprocess.run(
            [sys.executable, "-m", "ruff", *argumenty], capture_output=True, text=True, timeout=30
        )
        assert wynik.returncode == 1, wynik.stdout + wynik.stderr


def test_mypy_wykrywa_niezgodny_typ(tmp_path: Path) -> None:
    plik = tmp_path / "blad.py"
    plik.write_text('liczba: int = "tekst"\n', encoding="utf-8")
    wynik = subprocess.run(
        [sys.executable, "-m", "mypy", "--strict", str(plik)],
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert wynik.returncode == 1, wynik.stdout + wynik.stderr
    assert "[assignment]" in wynik.stdout
