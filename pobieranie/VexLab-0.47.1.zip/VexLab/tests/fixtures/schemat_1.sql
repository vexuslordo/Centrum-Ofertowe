
CREATE TABLE produkty (
    id TEXT PRIMARY KEY NOT NULL,
    nazwa TEXT NOT NULL CHECK(length(trim(nazwa)) > 0),
    sku TEXT NOT NULL CHECK(length(trim(sku)) > 0),
    sku_klucz TEXT NOT NULL UNIQUE CHECK(length(sku_klucz) > 0),
    opis TEXT NOT NULL,
    wersja INTEGER NOT NULL CHECK(wersja >= 1)
)
