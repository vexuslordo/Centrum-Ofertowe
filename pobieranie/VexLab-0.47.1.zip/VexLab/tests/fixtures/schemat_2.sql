
CREATE TABLE produkty (
    id TEXT PRIMARY KEY NOT NULL,
    nazwa TEXT NOT NULL CHECK(length(trim(nazwa)) > 0),
    sku TEXT NOT NULL CHECK(length(trim(sku)) > 0),
    sku_klucz TEXT NOT NULL UNIQUE CHECK(length(sku_klucz) > 0),
    opis TEXT NOT NULL,
    wersja INTEGER NOT NULL CHECK(wersja >= 1)
)
;
CREATE TABLE migracje (wersja INTEGER PRIMARY KEY, suma_sha256 TEXT NOT NULL, zastosowano_utc TEXT NOT NULL);
CREATE TABLE producenci (id TEXT PRIMARY KEY NOT NULL, nazwa TEXT NOT NULL CHECK(length(trim(nazwa)) > 0), aktywny INTEGER NOT NULL CHECK(aktywny IN (0,1)), wersja INTEGER NOT NULL CHECK(wersja >= 1));
ALTER TABLE produkty ADD COLUMN producent_id TEXT REFERENCES producenci(id) ON DELETE RESTRICT;
INSERT INTO migracje VALUES (1, 'c7ca38cc3020dd79fd4b5defc91fa3c5d02ea7dd80123d6dd9ce53de43d09591', '2026-11-02');
INSERT INTO migracje VALUES (2, '980558eb1db19afd540b77a60e11171b5f0ed52d961cd75d582dd9e7c6e91dcd', '2026-11-02');
PRAGMA user_version=2;
