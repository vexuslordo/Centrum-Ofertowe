BEGIN TRANSACTION;
CREATE TABLE ceny_sugerowane (produkt_id TEXT PRIMARY KEY NOT NULL REFERENCES produkty(id), kwota TEXT NOT NULL, waluta TEXT NOT NULL, rodzaj TEXT NOT NULL CHECK(rodzaj IN ('netto','brutto')), zrodlo TEXT NOT NULL);
CREATE TABLE dopasowania (produkt_id TEXT NOT NULL REFERENCES produkty(id), kolejnosc INTEGER NOT NULL CHECK(kolejnosc >= 0), marka TEXT NOT NULL CHECK(length(trim(marka)) > 0), model TEXT NOT NULL CHECK(length(trim(model)) > 0), rok_od INTEGER CHECK(rok_od BETWEEN 1000 AND 9999), rok_do INTEGER CHECK(rok_do BETWEEN 1000 AND 9999), wariant TEXT NOT NULL, CHECK(rok_do IS NULL OR (rok_od IS NOT NULL AND rok_do >= rok_od)), PRIMARY KEY(produkt_id,kolejnosc));
CREATE TABLE import_powiazania (id TEXT PRIMARY KEY NOT NULL, paczka TEXT NOT NULL REFERENCES importy(id), wiersz INTEGER NOT NULL, produkt_id TEXT NOT NULL REFERENCES produkty(id), tryb TEXT NOT NULL CHECK(tryb IN ('dodano','powiazano')));
CREATE TABLE import_robocze (id TEXT PRIMARY KEY NOT NULL, paczka TEXT NOT NULL REFERENCES importy(id), wiersz INTEGER NOT NULL, nazwa TEXT NOT NULL, sku TEXT NOT NULL, opis TEXT NOT NULL, producent_id TEXT REFERENCES producenci(id), powod TEXT NOT NULL, wersja INTEGER NOT NULL CHECK(wersja >= 1), cena_tekst TEXT NOT NULL DEFAULT '', cena_waluta TEXT NOT NULL DEFAULT '', cena_rodzaj TEXT NOT NULL DEFAULT '');
CREATE TABLE importy (id TEXT PRIMARY KEY NOT NULL, zrodlo TEXT NOT NULL, arkusz TEXT NOT NULL, dodane INTEGER NOT NULL, odlozone INTEGER NOT NULL);
CREATE TABLE migracje (wersja INTEGER PRIMARY KEY, suma_sha256 TEXT NOT NULL, zastosowano_utc TEXT NOT NULL);
INSERT INTO "migracje" VALUES(1,'c7ca38cc3020dd79fd4b5defc91fa3c5d02ea7dd80123d6dd9ce53de43d09591','2026-11-03T16:02:33.049344+00:00');
INSERT INTO "migracje" VALUES(2,'980558eb1db19afd540b77a60e11171b5f0ed52d961cd75d582dd9e7c6e91dcd','2026-11-03T16:02:33.049666+00:00');
INSERT INTO "migracje" VALUES(3,'acc179ba10ac2260508a64cfd90ce63e4de1c5e5034f08b5f8b17c3a5c0b4148','2026-11-03T16:02:33.049896+00:00');
INSERT INTO "migracje" VALUES(4,'80783f88b87845dea8c24cdd6b4a6793042fd97cbc000620ca1fa2c37a1651b7','2026-11-03T16:02:33.050655+00:00');
INSERT INTO "migracje" VALUES(5,'5fc4704de5014ecb82fccdca149668b921d6581a8b8bfa4dc5ba0e37ac9ec852','2026-11-03T16:02:33.050846+00:00');
CREATE TABLE producenci (id TEXT PRIMARY KEY NOT NULL, nazwa TEXT NOT NULL CHECK(length(trim(nazwa)) > 0), aktywny INTEGER NOT NULL CHECK(aktywny IN (0,1)), wersja INTEGER NOT NULL CHECK(wersja >= 1), strona_www TEXT NOT NULL DEFAULT '');
CREATE TABLE produkty (
    id TEXT PRIMARY KEY NOT NULL,
    nazwa TEXT NOT NULL CHECK(length(trim(nazwa)) > 0),
    sku TEXT NOT NULL CHECK(length(trim(sku)) > 0),
    sku_klucz TEXT NOT NULL UNIQUE CHECK(length(sku_klucz) > 0),
    opis TEXT NOT NULL,
    wersja INTEGER NOT NULL CHECK(wersja >= 1)
, producent_id TEXT REFERENCES producenci(id) ON DELETE RESTRICT);
CREATE TABLE zdjecia (id TEXT PRIMARY KEY NOT NULL, produkt_id TEXT NOT NULL REFERENCES produkty(id), zrodlo TEXT NOT NULL, dane BLOB NOT NULL, miniatura BLOB NOT NULL, kolejnosc INTEGER NOT NULL, UNIQUE(produkt_id,kolejnosc));
COMMIT;
PRAGMA user_version=5;

ALTER TABLE import_robocze ADD COLUMN dopasowania_json TEXT NOT NULL DEFAULT '[]';
INSERT INTO migracje VALUES (6, 'f4f4c8505167908d644c00c896358d7d16ded6bcb0050a4495db434fbf4b1f28', '2026-11-03T00:00:00+00:00');
PRAGMA user_version=6;

CREATE TABLE szkice (id TEXT PRIMARY KEY, produkt_id TEXT NOT NULL REFERENCES produkty(id) ON DELETE RESTRICT, wersja_produktu INTEGER NOT NULL, tytul TEXT NOT NULL CHECK(length(trim(tytul))>0), opis TEXT NOT NULL, tresc_json TEXT NOT NULL, zrodlo TEXT NOT NULL, klucz TEXT NOT NULL UNIQUE, wersja INTEGER NOT NULL CHECK(wersja>0));
CREATE INDEX szkice_produkt ON szkice(produkt_id);
INSERT INTO migracje VALUES (7, '548b16ba7c0ec10a0b43d3ae2b71db2ff67187b3b689b111bf691c04bf432422', '2026-11-05T00:00:00+00:00');
PRAGMA user_version=7;

CREATE TABLE cenniki (id TEXT PRIMARY KEY, nazwa TEXT NOT NULL CHECK(length(trim(nazwa))>0), rok INTEGER NOT NULL CHECK(rok BETWEEN 1000 AND 9999), wydanie TEXT NOT NULL, producent_id TEXT REFERENCES producenci(id) ON DELETE RESTRICT, zrodlo TEXT NOT NULL, arkusz TEXT NOT NULL, liczba INTEGER NOT NULL CHECK(liczba>0), wczytano_utc TEXT NOT NULL, dane_json TEXT NOT NULL, wersja INTEGER NOT NULL CHECK(wersja>0));
INSERT INTO migracje VALUES (8, 'f9d4031f6096a3f62ec39b31c7f2e2b17a29c0d2d57c325d6d4aedb6afa14635', '2026-11-05T00:00:00+00:00');
PRAGMA user_version=8;

ALTER TABLE cenniki ADD COLUMN aktualny INTEGER NOT NULL DEFAULT 0 CHECK(aktualny IN (0,1) AND (aktualny=0 OR producent_id IS NOT NULL));
CREATE UNIQUE INDEX cenniki_aktualny_producent ON cenniki(producent_id) WHERE aktualny=1;
INSERT INTO migracje VALUES (9, '3e0d421248741ef6e4b6a1b4e8ffe87026ba67c63aedc8091b9da1ce3062d379', '2026-11-06T00:00:00+00:00');
PRAGMA user_version=9;
