from PySide6.QtWidgets import QWidget

from vexlab.gui.zdjecia_seryjne import DialogZdjecSeryjnych
from vexlab.przypadki_uzycia.zdjecia_seryjne import WynikZdjecSeryjnych


def test_adres_wymagany_przed_zadaniem_i_zapamietaniem(qtbot):
    parent = QWidget()
    qtbot.addWidget(parent)
    wywolania = []
    d = DialogZdjecSeryjnych(
        (),
        None,
        "",
        10,
        lambda *a: wywolania.append(a),
        lambda *a: wywolania.append(a),
        parent,
    )
    d.show()
    d.start.click()
    assert wywolania == []
    assert d.info.text() and not d.trwa and d.start.isEnabled()


def test_zatrzymanie_czeka_na_zadanie_i_pokazuje_wynik(qtbot):
    parent = QWidget()
    qtbot.addWidget(parent)
    zadania, zapamietane = [], []

    def uruchom(funkcja, gotowe, blad):
        zadania.append((funkcja, gotowe, blad))

    d = DialogZdjecSeryjnych(
        (),
        None,
        "https://example.com",
        10,
        lambda *a: zapamietane.append(a),
        uruchom,
        parent,
    )
    d.show()
    d.start.click()
    assert d.trwa and not d.start.isEnabled()
    assert zapamietane == [("https://example.com", 10)]
    d.reject()
    assert d.isVisible() and d.stop.is_set()
    zadania[0][1](WynikZdjecSeryjnych(1, 0, 0, (), 1024, "Anulowano", None))
    assert not d.trwa and "Zapisano: 1" in d.info.text()
    assert "Anulowano" in d.raport.toPlainText()
    d.reject()
    assert not d.isVisible()
