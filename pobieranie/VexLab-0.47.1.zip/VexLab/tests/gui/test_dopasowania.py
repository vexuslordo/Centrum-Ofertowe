from PySide6.QtWidgets import QDialog, QWidget

from vexlab.gui.dopasowania import EdytorDopasowan
from vexlab.gui.katalog import FormularzProduktu
from vexlab.przypadki_uzycia.katalog import DaneDopasowania


def test_edytor_puste_dodaj_usun_i_anuluj(qtbot, monkeypatch):
    parent = QWidget()
    qtbot.addWidget(parent)
    edytor = EdytorDopasowan((), parent)
    qtbot.addWidget(edytor)
    assert edytor.dane() == ()
    d = DaneDopasowania("A", "Model", "2020", "2020", "S")
    edytor.dodaj(d)
    edytor.dodaj(DaneDopasowania("B", "Inny"))
    edytor.usun()
    assert edytor.dane() == (d,)
    form = FormularzProduktu([], parent=parent)
    qtbot.addWidget(form)
    form.dopasowania = (d,)
    monkeypatch.setattr(EdytorDopasowan, "exec", lambda e: QDialog.DialogCode.Rejected)
    form.edytuj_dopasowania()
    assert form.dopasowania == (d,)
    form.ustaw_zapis(True)
    assert not form.dopasowania_przycisk.isEnabled()
