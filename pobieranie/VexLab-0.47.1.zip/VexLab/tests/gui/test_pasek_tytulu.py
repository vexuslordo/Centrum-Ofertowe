from collections.abc import Iterator

import pytest
from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication, QDialog, QMainWindow, QMenu, QWidget
from pytestqt.qtbot import QtBot

from vexlab.adaptery import pasek_tytulu
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.przypadki_uzycia.powloka import Motyw


def test_starszy_windows_ma_fallback_bez_przerwania_uruchomienia() -> None:
    wywolania: list[tuple[int, int, int]] = []

    def brak_obslugi(hwnd: int, atrybut: int, wartosc: int) -> int:
        wywolania.append((hwnd, atrybut, wartosc))
        return -2147024809  # E_INVALIDARG, np. kolory Win11 na Windows10.

    pasek_tytulu.ustaw_kolory(brak_obslugi, 2**40, True, QColor("#17202D"), QColor("#EDF2FA"))
    assert wywolania == [
        (2**40, 20, 1),
        (2**40, 19, 1),
        (2**40, 35, 0x2D2017),
        (2**40, 36, 0xFAF2ED),
    ]


@pytest.fixture
def ramki(qapp: QApplication) -> Iterator[list[tuple[int, int, int]]]:
    wywolania: list[tuple[int, int, int]] = []

    def ustaw(hwnd: int, atrybut: int, wartosc: int) -> int:
        wywolania.append((hwnd, atrybut, wartosc))
        return 0

    filtr = pasek_tytulu.PasekTytulu(qapp, ustaw)
    yield wywolania
    qapp.removeEventFilter(filtr)
    filtr.deleteLater()
    zastosuj_motyw(qapp, Motyw.CIEMNY)


def test_ramki_okna_i_dialogu_reaguja_na_motyw_bez_zmiany_przyciskow(
    qapp: QApplication, qtbot: QtBot, ramki: list[tuple[int, int, int]]
) -> None:
    zastosuj_motyw(qapp, Motyw.CIEMNY)
    okno = QMainWindow()
    qtbot.addWidget(okno)
    flagi = okno.windowFlags()
    okno.show()
    dialog = QDialog(okno)
    qtbot.addWidget(dialog)
    dialog.show()
    for widget in (okno, dialog):
        assert (int(widget.winId()), 35, 0x2D2017) in ramki
    ramki.clear()
    zastosuj_motyw(qapp, Motyw.JASNY)
    for widget in (okno, dialog):
        assert (int(widget.winId()), 20, 0) in ramki
        assert (int(widget.winId()), 35, 0xF7F0EA) in ramki
        assert (int(widget.winId()), 36, 0x3A2617) in ramki
    assert okno.windowFlags() == flagi
    assert not okno.windowFlags() & Qt.WindowType.FramelessWindowHint
    assert okno.windowFlags() & Qt.WindowType.WindowMinMaxButtonsHint
    assert okno.windowFlags() & Qt.WindowType.WindowCloseButtonHint


def test_menu_i_potomki_nie_dostaja_ramki(
    qapp: QApplication, qtbot: QtBot, ramki: list[tuple[int, int, int]]
) -> None:
    zastosuj_motyw(qapp, Motyw.CIEMNY)
    menu = QMenu()
    qtbot.addWidget(menu)
    menu.winId()
    dziecko = QWidget(menu)
    dziecko.winId()
    ramki.clear()
    for widget in (menu, dziecko):
        QApplication.sendEvent(widget, QEvent(QEvent.Type.WindowActivate))
    assert not ramki


def test_poza_windows_nie_laduje_biblioteki(
    qapp: QApplication, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(pasek_tytulu.sys, "platform", "linux")
    assert pasek_tytulu.zainstaluj_pasek_tytulu(qapp) is None


def test_brak_dwm_nie_blokuje_startu(qapp: QApplication, monkeypatch: pytest.MonkeyPatch) -> None:
    def niedostepna(*args: object, **kwargs: object) -> None:
        raise OSError("Brak DWM")

    monkeypatch.setattr(pasek_tytulu.sys, "platform", "win32")
    monkeypatch.setattr(pasek_tytulu.ctypes, "WinDLL", niedostepna, raising=False)
    assert pasek_tytulu.zainstaluj_pasek_tytulu(qapp) is None
