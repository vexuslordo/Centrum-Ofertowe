import pytest
from PySide6.QtCore import Qt

from vexlab.gui.dashboard import DashboardView, EdytorDashboardu
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.przypadki_uzycia.dashboard import StanDashboardu
from vexlab.przypadki_uzycia.powloka import Motyw, PreferencjePowloki


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_rzeczywiste_alerty_brak_fikcyjnych_statystyk_i_responsywnosc(qtbot, qapp, motyw):
    zastosuj_motyw(qapp, motyw)
    view = DashboardView(PreferencjePowloki())
    qtbot.addWidget(view)
    view.resize(1320, 900)
    view.show()
    view.ustaw_stan(StanDashboardu(120, 5, 7, 2, 3, 1))
    assert view.karty["produkty"].liczba.text() == "120"
    assert all(view.karty[k].liczba.text() == "—" for k in view.karty if k != "produkty")
    with qtbot.waitSignal(view.alert) as signal:
        view.alerty["ean"].click()
    assert signal.args == ["ean"]
    assert view.ai_wartosci["bez_opisu"].text() == "3"
    assert view.wykres.chart().series()[0].count() == 0
    view.ustaw_allegro("konto_testowe")
    assert view.panel_integracji.allegro.wartosci[0].text() == "konto_testowe"
    view.ustaw_allegro(None)
    assert "Niepołączono" in view.panel_integracji.allegro.status.text()
    view.resize(600, 700)
    qtbot.waitUntil(lambda: not view._szeroki)
    qtbot.waitUntil(lambda: view.horizontalScrollBar().maximum() == 0)


def test_konfigurator_emituje_zmiane_i_zachowuje_ukryta_sekcje(qtbot):
    view = DashboardView(PreferencjePowloki())
    qtbot.addWidget(view)
    edytor = EdytorDashboardu(PreferencjePowloki(), view)
    qtbot.addWidget(edytor)
    with qtbot.waitSignal(edytor.zmiana) as wynik:
        edytor.lista.item(0).setCheckState(Qt.CheckState.Unchecked)
    assert wynik.args[1] == ("kpi",)
    view.ukryte = ("kpi",)
    view.rozmiesc(True, wymus=True)
    assert view.sekcje["kpi"].isHidden()


def test_pionowe_karty_integracji_maja_konto_aktywny_licznik_i_reset(qtbot):
    from vexlab.przypadki_uzycia.allegro import LicznikiAllegro

    view = DashboardView(PreferencjePowloki())
    qtbot.addWidget(view)
    view.ustaw_allegro("konto_testowe")
    view.ustaw_liczniki_allegro(LicznikiAllegro(17, 3))
    karta = view.panel_integracji.allegro
    assert karta.etykiety[1].text() == "Aktywne:"
    assert karta.wartosci[1].text() == "17"
    assert karta.wartosci[2].text() == "—"
    assert not view.panel_integracji.presta.status.property("polaczono")
    with qtbot.waitSignal(view.cel) as wynik:
        view.zarzadzaj_przycisk.click()
    assert wynik.args == ["integracje"]
    view.ustaw_allegro(None)
    assert all(p.text() == "—" for p in karta.wartosci)
    assert view.karty["allegro"].liczba.text() == "—"
