from datetime import UTC, datetime
from uuid import uuid4

import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QLabel, QVBoxLayout, QWidget

from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.ustawienia import InformacjeOProgramie, IntegracjeUstawien, SekcjaRozwijana
from vexlab.przypadki_uzycia.diagnostyka import RaportDiagnostyczny, WersjeSrodowiska
from vexlab.przypadki_uzycia.powloka import Motyw
from vexlab.rdzen.kontrakty import IdKorelacji


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_integracje_lista_klawiatura_i_oddzielne_panele(qtbot, qapp, motyw):
    zastosuj_motyw(qapp, motyw)
    w = IntegracjeUstawien()
    qtbot.addWidget(w)
    panele = []
    for nazwa in ("Allegro", "PrestaShop", "Subiekt GT"):
        p = QWidget()
        QVBoxLayout(p).addWidget(QLabel(nazwa))
        panele.append(p)
        w.dodaj(nazwa, "Niepołączono", p)
    w.resize(700, 450)
    w.show()
    w.activateWindow()
    w.lista.setFocus()
    assert w.currentWidget() is panele[0]
    qtbot.keyClick(w.lista, Qt.Key.Key_Down)
    assert w.currentWidget() is panele[1]
    assert not panele[0].isVisible() and panele[1].isVisible()
    w.setCurrentWidget(panele[2])
    assert w.lista.currentRow() == 2 and panele[2].isVisible()
    w.ustaw_status(panele[0], "Połączono")
    assert "Połączono" in w.lista.item(0).text()
    assert w.currentWidget() is panele[2]


def test_rozwijana_sekcja_dostepna_z_klawiatury(qtbot):
    w = SekcjaRozwijana("Dane aplikacji")
    w.wnetrze.addWidget(QLabel("Konfiguracja"))
    qtbot.addWidget(w)
    w.show()
    assert not w.tresc.isVisible()
    qtbot.keyClick(w.przelacz, Qt.Key.Key_Space)
    assert w.tresc.isVisible()
    qtbot.keyClick(w.przelacz, Qt.Key.Key_Space)
    assert not w.tresc.isVisible()


def test_diagnostyka_raport_na_zadanie_i_blad_czysci_poprzedni(qtbot):
    jobs = []
    w = InformacjeOProgramie("test", object(), lambda *a: jobs.append(a))
    qtbot.addWidget(w)
    assert not w.kopiuj.isEnabled()
    w.wykonaj()
    w.wykonaj()
    assert len(jobs) == 1 and not w.sprawdz.isEnabled()
    r = RaportDiagnostyczny(
        IdKorelacji(uuid4()),
        datetime(2026, 11, 8, tzinfo=UTC),
        WersjeSrodowiska("3.13", "6.12", "3.53"),
    )
    jobs[-1][1](r)
    assert w.kopiuj.isEnabled() and w.raport.isReadOnly()
    assert "Python: 3.13" in w.raport.toPlainText()
    w.kopiuj.click()
    assert QApplication.clipboard().text() == w.raport.toPlainText()
    w.wykonaj()
    assert not w.raport.toPlainText() and not w.kopiuj.isEnabled()
    jobs[-1][2]("TECHNICZNY", "Brak odczytu")
    assert w.sprawdz.isEnabled() and not w.kopiuj.isEnabled() and w.info.text() == "Brak odczytu"
