from dataclasses import replace

from PySide6.QtWidgets import QCheckBox, QComboBox, QDialog

from tests.gui.test_masowa_paczka_allegro import select
from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from vexlab.gui.ustawienia_sprzedazy_allegro import DaneSprzedazyAllegro


def test_komplet_domyslnie_wymagany_i_zapis_ustawien_tylko_do_wyboru(
    qtbot, sprzedaz_fixture, monkeypatch
):
    base = sprzedaz_fixture[:6]
    o = base[4]
    w, jobs = panel(qtbot, base, (o, replace(o, sku="2")))
    w.kompletny.setChecked(True)
    w.ustawienia[0] = replace(w.ustawienia[0], sprzedaz=None)
    w.ustawienia[1] = replace(w.ustawienia[1], sprzedaz=None)
    select(w, (0,))

    def edit(d):
        assert not jobs
        assert d.tabs.count() == 3
        assert not d.producent.currentData()
        d.pobierz_listy()
        wykonaj(jobs)
        u = sprzedaz_fixture[5].sprzedaz
        for name in (
            "producent",
            "osoba",
            "dostawa",
            "czas",
            "zwroty",
            "reklamacje",
            "gwarancja",
            "wojewodztwo",
            "faktura",
        ):
            box = getattr(d, name)
            box.setCurrentIndex(box.findData(getattr(u, name)))
        d.inna_lokalizacja.setChecked(True)
        for name in ("kraj", "miasto", "kod"):
            getattr(d, name).setText(getattr(u, name))
        d.bezpieczenstwo.setPlainText(u.bezpieczenstwo)
        d.zapisz()
        assert d.wynik == u
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(DaneSprzedazyAllegro, "exec", edit)
    w.ustaw_sprzedaz()
    wykonaj(jobs)
    assert not w.plany[0].bledy and w.plany[1].bledy
    assert w.plany[0].ustawienia.sprzedaz == sprzedaz_fixture[5].sprzedaz
    assert "POST" not in base[1].calls


def test_parametry_sa_podzielone_i_zrodla_ukryte(qtbot, nowe_produkty_fixture, monkeypatch):
    w, jobs = panel(qtbot, nowe_produkty_fixture)
    w.przygotuj()
    wykonaj(jobs)
    select(w, (0,))

    def edit(d):
        from PySide6.QtWidgets import QLineEdit, QTabWidget

        tabs = d.findChild(QTabWidget)
        assert [tabs.tabText(i) for i in range(tabs.count())] == ["Wymagane", "Dodatkowe"]
        sources = [
            box for box in d.findChildren(QComboBox) if box.accessibleName().startswith("Źródło")
        ]
        assert sources
        assert all(
            box.isHidden() for box in sources if "Kod producenta" not in box.accessibleName()
        )
        assert not next(
            box for box in sources if "Kod producenta" in box.accessibleName()
        ).isHidden()
        advanced = next(c for c in d.findChildren(QCheckBox) if c.text().startswith("Zaawansowane"))
        advanced.setChecked(True)
        assert all(not box.isHidden() for box in sources)
        kod = next(c for c in d.findChildren(QLineEdit) if c.accessibleName() == "Kod producenta")
        assert not kod.isEnabled()
        source = next(c for c in sources if "Kod producenta" in c.accessibleName())
        source.setCurrentIndex(source.findData(""))
        assert kod.isEnabled()
        return QDialog.DialogCode.Rejected

    monkeypatch.setattr(QDialog, "exec", edit)
    w.uzupelnij()
    assert "POST" not in nowe_produkty_fixture[1].calls


def test_okno_otwiera_sie_przed_odpowiedzia_i_pokazuje_blad_oraz_ponowienie(
    qtbot, sprzedaz_fixture
):
    from PySide6.QtWidgets import QWidget

    from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import SlownikiSprzedazy

    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = DaneSprzedazyAllegro(
        parent,
        SlownikiSprzedazy((), (), (), (), (), ()),
        None,
        200,
        pobierz=lambda: sprzedaz_fixture[-1],
        uruchom=lambda *args: jobs.append(args),
    )
    d.show()
    qtbot.waitUntil(lambda jobs=jobs: bool(jobs))
    assert d.isVisible() and not d.zastosuj.isEnabled()
    assert "Pobieranie" in d.status.text()
    d.bezpieczenstwo.setPlainText("Własna treść do zachowania")
    jobs[-1][2]("UPRAWNIENIA", "Brak sale:settings:read. Odnów zgodę.")
    assert d.isVisible() and "settings:read" in d.status.text() and d.odswiez.isEnabled()
    assert not d.zastosuj.isEnabled()
    d.odswiez.click()
    jobs[-1][1](sprzedaz_fixture[-1])
    assert d.producent.count() == 2 and d.zastosuj.isEnabled()
    assert d.bezpieczenstwo.toPlainText() == "Własna treść do zachowania"


def test_zamkniecie_podczas_odczytu_ignoruje_spozniony_wynik(qtbot, sprzedaz_fixture):
    from PySide6.QtWidgets import QWidget

    from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import SlownikiSprzedazy

    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = DaneSprzedazyAllegro(
        parent,
        SlownikiSprzedazy((), (), (), (), (), ()),
        None,
        1,
        pobierz=lambda: sprzedaz_fixture[-1],
        uruchom=lambda *args: jobs.append(args),
    )
    d.show()
    qtbot.waitUntil(lambda jobs=jobs: bool(jobs))
    d.reject()
    jobs[-1][1](sprzedaz_fixture[-1])
    assert not d.isVisible() and d.producent.count() == 1


def test_blad_jednej_listy_pokazuje_pozostale_ustawienia(qtbot, sprzedaz_fixture):
    from PySide6.QtWidgets import QWidget

    from vexlab.przypadki_uzycia.ustawienia_sprzedazy_allegro import SlownikiSprzedazy

    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = DaneSprzedazyAllegro(
        parent,
        SlownikiSprzedazy((), (), (), (), (), ()),
        None,
        1,
        pobierz=lambda: sprzedaz_fixture[-1],
        uruchom=lambda *args: jobs.append(args),
    )
    d.show()
    qtbot.waitUntil(lambda jobs=jobs: bool(jobs))
    jobs[-1][1](replace(sprzedaz_fixture[-1], gwarancje=(), bledy=(("gwarancje", "HTTP 500"),)))
    assert d.producent.count() == d.dostawa.count() == 2
    assert "Gwarancje: HTTP 500" in d.status.text()


def test_przycisk_naprawde_otwiera_okno_takze_przy_odmowie_api(qtbot, sprzedaz_fixture):
    from PySide6.QtCore import QTimer

    w, jobs = panel(qtbot, sprzedaz_fixture[:6])
    observed = []

    def sprawdz():
        d = next(child for child in w.findChildren(DaneSprzedazyAllegro) if child.isVisible())
        observed.append(d.isVisible())
        d.pobierz_listy()
        jobs[-1][2]("UPRAWNIENIA", "Brak settings:read")
        assert "settings:read" in d.status.text()
        assert not d.zastosuj.isEnabled()
        d.reject()

    QTimer.singleShot(0, sprawdz)
    w.sprzedaz_przycisk.click()
    assert observed == [True] and "POST" not in sprzedaz_fixture[1].calls


def test_lokalizacja_domyslnie_z_konta_a_reczna_opcjonalna(qtbot, sprzedaz_fixture):
    from PySide6.QtWidgets import QWidget

    parent = QWidget()
    qtbot.addWidget(parent)
    config = replace(sprzedaz_fixture[5].sprzedaz, kraj="", miasto="", kod="", wojewodztwo="")
    d = DaneSprzedazyAllegro(parent, sprzedaz_fixture[-1], config, 200)
    d.tabs.setCurrentIndex(1)
    d.show()
    assert not d.inna_lokalizacja.isChecked()
    assert all(w.isHidden() for w in (d.kraj, d.miasto, d.kod, d.wojewodztwo))
    d.inna_lokalizacja.setChecked(True)
    assert all(not w.isHidden() for w in (d.kraj, d.miasto, d.kod, d.wojewodztwo))
    d.miasto.setText("Wpisana lokalizacja")
    d.inna_lokalizacja.setChecked(False)
    d.zapisz()
    assert d.wynik == config and d.miasto.text() == "Wpisana lokalizacja"


def test_okno_gpsr_nie_daje_sie_scisnac_po_otwarciu_i_pobraniu(qtbot, qapp, sprzedaz_fixture):
    from PySide6.QtWidgets import QWidget

    from vexlab.gui.design_system import zastosuj_motyw
    from vexlab.przypadki_uzycia.powloka import Motyw

    parent = QWidget()
    qtbot.addWidget(parent)
    for theme in (Motyw.CIEMNY, Motyw.JASNY):
        zastosuj_motyw(qapp, theme)
        jobs = []
        d = DaneSprzedazyAllegro(
            parent,
            sprzedaz_fixture[-1],
            None,
            35,
            pobierz=lambda: sprzedaz_fixture[-1],
            uruchom=lambda *a, jobs=jobs: jobs.append(a),
        )
        screen = d.screen().availableGeometry()
        minimum_w = min(720, screen.width() - 48)
        minimum_h = min(560, screen.height() - 80)
        d.show()
        qtbot.waitUntil(lambda jobs=jobs: bool(jobs))
        d.resize(210, 360)
        assert d.width() >= minimum_w and d.height() >= minimum_h
        jobs[-1][1](jobs[-1][0]())
        qtbot.wait(10)
        assert d.width() >= minimum_w and d.height() >= minimum_h
        for i in range(3):
            d.tabs.setCurrentIndex(i)
            assert d.tabs.tabBar().tabRect(i).right() < d.tabs.width()
        d.reject()
