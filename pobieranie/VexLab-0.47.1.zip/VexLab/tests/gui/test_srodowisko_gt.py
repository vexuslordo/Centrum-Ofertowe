from datetime import UTC, datetime

from PySide6.QtWidgets import QApplication

from vexlab.gui.srodowisko_gt import PanelSrodowiskaGT
from vexlab.przypadki_uzycia.srodowisko_gt import SprawdzSrodowiskoGT, SrodowiskoGT


class Zegar:
    def teraz(self):
        return datetime(2026, 11, 7, 12, tzinfo=UTC)


class Czytnik:
    def odczytaj(self):
        return SrodowiskoGT("Windows testowy", "3.13", 64)


def test_panel_czeka_na_prawdziwy_wynik_i_kopiuje_raport(qtbot):
    zadania = []
    w = PanelSrodowiskaGT(SprawdzSrodowiskoGT(Czytnik(), Zegar()), lambda *a: zadania.append(a))
    qtbot.addWidget(w)
    w.show()
    w.wykonaj()
    w.wykonaj()
    assert len(zadania) == 1 and w.trwa
    assert not w.sprawdz.isEnabled() and not w.kopiuj.isEnabled()
    assert not w.raport.toPlainText()
    fn, ok, err = zadania[0]
    ok(fn())
    assert w.raport.isReadOnly() and w.kopiuj.isEnabled()
    assert "nie było sprawdzane" in w.raport.toPlainText()
    w.kopiuj.click()
    assert QApplication.clipboard().text() == w.raport.toPlainText()


def test_awaria_po_poprzednim_wyniku_nie_pozostawia_raportu_do_kopiowania(qtbot):
    zadania = []
    w = PanelSrodowiskaGT(SprawdzSrodowiskoGT(Czytnik(), Zegar()), lambda *a: zadania.append(a))
    qtbot.addWidget(w)
    w.wykonaj()
    fn, ok, err = zadania[-1]
    ok(fn())
    w.wykonaj()
    assert not w.kopiuj.isEnabled() and not w.raport.toPlainText()
    zadania[-1][2]("TECHNICZNY", "Błąd odczytu")
    assert not w.trwa and w.sprawdz.isEnabled() and not w.kopiuj.isEnabled()
    assert "Nie udało się" in w.info.text()


def test_brak_czytnika_nie_udaje_wykonanego_sprawdzenia(qtbot):
    zadania = []
    w = PanelSrodowiskaGT(None, lambda *a: zadania.append(a))
    qtbot.addWidget(w)
    assert not w.sprawdz.isEnabled()
    w.wykonaj()
    assert zadania == []
