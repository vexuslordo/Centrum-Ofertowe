import json
from collections.abc import Iterator
from zipfile import ZipFile

import pytest
from PySide6.QtCore import QSettings, QUrl
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QFileDialog, QTextBrowser

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.paczki_zip import CzytnikZIP, ProfileJSON
from vexlab.adaptery.pamiec_profili import PamiecProfiliJSON
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.gui.design_system import logo_aplikacji
from vexlab.gui.okno import OknoVexLab
from vexlab.gui.paczki_ofert import TekstPodgladu, bezpieczny_html
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek, ProfilPaczki
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


@pytest.fixture
def okno(qtbot, tmp_path) -> Iterator[OknoVexLab]:
    repo = ImportSQLite(tmp_path / "k.sqlite3")
    kat = KatalogProduktow(repo, repo)
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        kat,
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
        szkice=SzkiceOfert(SzkiceSQLite(repo.plik)),
        paczki=PodgladPaczek(
            CzytnikZIP(), ProfileJSON(), PamiecProfiliJSON(tmp_path / "profile_paczek")
        ),
    )
    qtbot.addWidget(w)
    w.show()
    qtbot.waitUntil(lambda: not w._zadania and w._katalog_wczytany)
    yield w
    qtbot.waitUntil(lambda: not w._zadania)
    if w.strona_szkicow.dialog:
        w.strona_szkicow.dialog.reject()
    if w.strona_paczek.dialog:
        w.strona_paczek.dialog.reject()
    w.close()


def czekaj(qtbot, w):
    qtbot.waitUntil(lambda: not w._zadania and not w.strona_paczek.trwa)


def test_zip_profil_podglad_bez_zmiany_katalogu_i_blad_nowego_pliku(
    qtbot, okno, tmp_path, monkeypatch
):
    zipfile = tmp_path / "paczka.zip"
    with ZipFile(zipfile, "w") as z:
        z.writestr(
            "moje.json",
            json.dumps(
                [
                    {
                        "kod": "TEST",
                        "tytul": "Gotowy tytuł",
                        "html": '<h1>Opis</h1><script>SECRET</script><img src="file:///etc/passwd">',
                        "sekcje": [{"bloki": [{"typ": "T", "tekst": "<p>Zachowaj kolejność</p>"}]}],
                    }
                ]
            ),
        )
    profil = ProfilPaczki(
        "Mój profil",
        "moje.json",
        "kod",
        "tytul",
        opis="html",
        sekcje="sekcje",
        lista_elementow="bloki",
        typ_elementu="typ",
        tresc_elementu="tekst",
        adres_elementu="url",
        typ_tekstu="T",
        typ_obrazu="I",
    )
    plik_profilu = tmp_path / "profil.json"
    ProfileJSON().zapisz(plik_profilu, profil)
    monkeypatch.setattr(
        QFileDialog,
        "getOpenFileName",
        lambda *a: (str(zipfile if "ZIP" in a[-1] else plik_profilu), ""),
    )
    okno.przejdz("Nowe oferty")
    czekaj(qtbot, okno)
    s = okno.strona_paczek
    assert okno.stos.currentWidget() is s and s is not okno.strony["Produkty"]
    s.wczytaj_profil()
    czekaj(qtbot, okno)
    s.otworz()
    czekaj(qtbot, okno)
    assert s.profil() == profil
    s.podglad()
    czekaj(qtbot, okno)
    qtbot.waitUntil(lambda: s.tabela.item(0, 2) is not None)
    assert s.tabela.item(0, 2).text() == "Gotowy tytuł"
    assert not okno.katalog.wyszukaj()
    s.tabela.selectRow(0)
    s.szczegoly()
    assert s.dialog is not None
    teksty = [b.toPlainText() for b in s.dialog.findChildren(QTextBrowser)]
    assert any("Opis" in t for t in teksty) and not any("SECRET" in t for t in teksty)
    s.dialog.reject()
    qtbot.waitUntil(lambda: s.dialog is None)
    s.struktura["typ_tekstu"].setText("Nowy")
    assert not s.oferty and s.tabela.rowCount() == 0
    zipfile.write_bytes(b"zly zip")
    s.otworz()
    czekaj(qtbot, okno)
    assert s.paczka is None and s.tabela.rowCount() == 0
    assert "Nie można" in s.info.text()


def test_html_bez_skryptow_adresow_i_zasobow(qtbot):
    tekst = (
        '<h1 onclick="alert(1)">Tytuł</h1><script>sekret</script>'
        '<a href="javascript:x">Link</a><img src="https://example.test/a.png">'
        "<style>body{}</style>"
    )
    wynik = bezpieczny_html(tekst)
    assert wynik == "<h1>Tytuł</h1>Link"
    widget = TekstPodgladu(tekst)
    qtbot.addWidget(widget)
    assert widget.toPlainText() == "Tytuł\nLink"
    assert widget.loadResource(2, QUrl("file:///etc/passwd")) is None
    assert not widget.openLinks() and not widget.openExternalLinks()


def test_logo_transparentne_i_oba_motywy(qtbot, okno):
    pixmap = logo_aplikacji().pixmap(256, 256)
    assert not pixmap.isNull()
    obraz = pixmap.toImage().convertToFormat(QImage.Format.Format_ARGB32)
    assert obraz.hasAlphaChannel() and obraz.pixelColor(0, 0).alpha() == 0
    for motyw in (Motyw.CIEMNY, Motyw.JASNY):
        okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(motyw))
        okno.przejdz("Nowe oferty")
        assert okno.strona_paczek.isVisible()
        okno.resize(800, 620)
        qtbot.wait(10)
        assert okno.width() == 800


def test_gotowy_zip_otwiera_oferty_automatycznie_bez_mapowania(qtbot, okno, tmp_path, monkeypatch):
    from dataclasses import asdict

    plik = tmp_path / "gotowa.zip"
    profil = ProfilPaczki("Układ producenta użytkownika", "oferty.json", "kod", "tytul")
    with ZipFile(plik, "w") as z:
        z.writestr("oferty.json", json.dumps([{"kod": "AUTO-1", "tytul": "Gotowa oferta"}]))
        z.writestr("moj-profil.json", json.dumps({"wersja": 1, "ustawienia": asdict(profil)}))
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a: (str(plik), ""))
    okno.przejdz("Nowe oferty")
    czekaj(qtbot, okno)
    s = okno.strona_paczek
    s.otworz()
    czekaj(qtbot, okno)
    qtbot.waitUntil(lambda: s.tabela.item(0, 2) is not None)
    assert s.tabs.currentIndex() == 1
    assert s.oferty[0].sku == "AUTO-1"
    assert s.tabela.item(0, 2).text() == "Gotowa oferta"
    assert not s.konfiguracja.isVisible() and not s.rozwin_konfiguracje.isChecked()
    assert not okno.katalog.wyszukaj()


def test_wiele_profili_wymaga_tylko_wyboru_i_nie_zgaduje(qtbot, okno, tmp_path, monkeypatch):
    from dataclasses import asdict

    plik = tmp_path / "kilka.zip"
    with ZipFile(plik, "w") as z:
        for i in (1, 2):
            profil = ProfilPaczki(f"Układ {i}", f"oferty{i}.json", "kod", "tytul")
            z.writestr(f"oferty{i}.json", json.dumps([{"kod": f"SKU-{i}", "tytul": f"Tytuł {i}"}]))
            z.writestr(f"profil{i}.json", json.dumps({"wersja": 1, "ustawienia": asdict(profil)}))
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a: (str(plik), ""))
    okno.przejdz("Nowe oferty")
    czekaj(qtbot, okno)
    s = okno.strona_paczek
    s.otworz()
    czekaj(qtbot, okno)
    assert not s.oferty and s.wybor_profilu.isVisible()
    s.wybor_profilu.setCurrentIndex(2)
    czekaj(qtbot, okno)
    assert s.oferty[0].sku == "SKU-2"


def test_bledny_lub_brakujacy_profil_nie_otwiera_starych_ofert(qtbot, okno, tmp_path, monkeypatch):
    from dataclasses import asdict

    plik = tmp_path / "niegotowa.zip"
    profil = ProfilPaczki("Zły", "oferty.json", "kod", "tytul")
    with ZipFile(plik, "w") as z:
        z.writestr("oferty.json", json.dumps([{"kod": "A", "tytul": "Tytuł"}]))
        z.writestr("profil.json", json.dumps({"wersja": 99, "ustawienia": asdict(profil)}))
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a: (str(plik), ""))
    okno.przejdz("Nowe oferty")
    czekaj(qtbot, okno)
    s = okno.strona_paczek
    s.otworz()
    czekaj(qtbot, okno)
    assert not s.oferty and "nieprawidłowy" in s.info.text()
    with ZipFile(plik, "w") as z:
        z.writestr("oferty.json", json.dumps([{"kod": "A", "tytul": "Tytuł"}]))
    s.otworz()
    czekaj(qtbot, okno)
    assert not s.oferty and "Nie rozpoznano układu" in s.info.text()
    assert not s.konfiguracja.isVisible()


def test_paczka_pokazuje_oferty_bez_akcji_zakladania_produktow(qtbot, okno, tmp_path, monkeypatch):
    from dataclasses import asdict

    from vexlab.przypadki_uzycia.katalog import DaneProduktu

    stary = okno.katalog.dodaj(DaneProduktu("Stary produkt", "OLD", "Zachowaj opis"))
    plik = tmp_path / "gotowa-z-produktami.zip"
    profil = ProfilPaczki("Mój układ", "dane.json", "sku", "tytul", opis="opis")
    with ZipFile(plik, "w") as z:
        z.writestr(
            "dane.json",
            json.dumps(
                [
                    {"sku": "OLD", "tytul": "Nie nadpisuj", "opis": "Inny opis"},
                    {"sku": "NEW", "tytul": "Nowy produkt", "opis": "<p>Gotowy opis</p>"},
                    {"sku": "", "tytul": "Brak SKU", "opis": "Popraw później"},
                ]
            ),
        )
        z.writestr("ustawienia.json", json.dumps({"wersja": 1, "ustawienia": asdict(profil)}))
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a: (str(plik), ""))
    okno.przejdz("Nowe oferty")
    czekaj(qtbot, okno)
    s = okno.strona_paczek
    s.otworz()
    czekaj(qtbot, okno)
    from PySide6.QtWidgets import QPushButton

    assert len(s.oferty) == 3 and not s.konfiguracja.isVisible()
    assert not any("Dodaj nowe produkty" in b.text() for b in s.findChildren(QPushButton))
    assert okno.katalog.wyszukaj() == [stary]
    assert okno.importer.oczekujace() == ()


def test_program_pamieta_uklad_i_otwiera_nastepny_zip_bez_profili(
    qtbot, okno, tmp_path, monkeypatch
):
    from dataclasses import asdict

    profil = ProfilPaczki("Zapamiętaj mnie", "oferty.json", "kod", "tytul")
    plik = tmp_path / "pierwsza.zip"
    with ZipFile(plik, "w") as z:
        z.writestr("oferty.json", json.dumps([{"kod": "PIERWSZY", "tytul": "Oferta"}]))
        z.writestr("profil.json", json.dumps({"wersja": 1, "ustawienia": asdict(profil)}))
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a: (str(plik), ""))
    okno.przejdz("Nowe oferty")
    czekaj(qtbot, okno)
    s = okno.strona_paczek
    s.otworz()
    czekaj(qtbot, okno)
    assert "Zapamiętany" in s.info_profili.text()
    drugi = tmp_path / "druga.zip"
    with ZipFile(drugi, "w") as z:
        z.writestr("zmieniona-nazwa.json", json.dumps([{"kod": "DRUGI", "tytul": "Nowa oferta"}]))
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a: (str(drugi), ""))
    s.otworz()
    czekaj(qtbot, okno)
    assert s.oferty[0].sku == "DRUGI" and s.tabs.currentIndex() == 1
    assert not s.konfiguracja.isVisible()
    assert not s.dialog_konfiguracji.isVisible()
    assert not s.wybor_profilu.isVisible()
    assert not okno.katalog.wyszukaj()


def test_szkice_z_zip_potwierdzenie_lista_edycja_i_usuniecie(qtbot, okno, monkeypatch):
    from PySide6.QtWidgets import QDialogButtonBox, QLineEdit, QMessageBox

    from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad, PaczkaOfert

    s = okno.strona_paczek
    oferta = OfertaPodglad(1, "TEST-SZKIC", "Tytuł z ZIP", "<p>Opis</p>", "", "", "", (), (), ())
    s.paczka = PaczkaOfert("test.zip", (), ())
    s.oferty = (oferta,)
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    s.przygotuj_szkice()
    czekaj(qtbot, okno)
    assert okno.szkice.lista() == () and okno.katalog.wyszukaj() == []
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    s.przygotuj_szkice()
    czekaj(qtbot, okno)
    assert len(okno.szkice.lista()) == 1
    okno.przejdz("Szkice")
    qtbot.waitUntil(lambda: not okno._zadania and not okno.strona_szkicow.trwa)
    strona = okno.strona_szkicow
    assert strona.tabela.rowCount() == 1
    assert okno.strony["Szkice"] is not okno.strony["Nowe oferty"]
    strona.szukaj.setText("brak takiego")
    assert strona.tabela.rowCount() == 0
    strona.szukaj.clear()
    strona.tabela.selectRow(0)
    strona.edytuj()
    d = strona.dialog
    t = d.findChild(QLineEdit, "tytul_szkicu")
    t.setText("Nowy tytuł szkicu")
    d.findChild(QDialogButtonBox).accepted.emit()
    qtbot.waitUntil(lambda: not okno._zadania and not strona.trwa)
    assert strona.widoczne[0].oferta.tytul == "Nowy tytuł szkicu"
    assert okno.katalog.wyszukaj() == []
    strona.tabela.selectRow(0)
    strona.podglad()
    assert strona.dialog.windowTitle().startswith("Szkic lokalny")
    strona.dialog.reject()
    strona.usun()
    qtbot.waitUntil(lambda: not okno._zadania and not strona.trwa)
    assert strona.tabela.rowCount() == 0 and len(okno.katalog.wyszukaj()) == 0


def test_edytor_wizualny_anulowanie_blad_i_zapis_ukladu(qtbot, okno):
    from PySide6.QtWidgets import QDialogButtonBox, QLineEdit

    from vexlab.gui.edytor_opisu import EdytorOpisu, TekstWizualny
    from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad

    o = OfertaPodglad(1, "EDIT-1", "Test", "<p>Oryginał</p>", "", "", "", (), (), ())
    okno.szkice.zapisz(okno.szkice.zaplanuj((o,), "test.zip"))
    okno.przejdz("Szkice")
    s = okno.strona_szkicow
    qtbot.waitUntil(lambda: not okno._zadania and not s.trwa)
    s.tabela.selectRow(0)
    s.edytuj()
    dialog = s.dialog
    edytor = dialog.findChild(EdytorOpisu)
    edytor.findChild(TekstWizualny).setPlainText("Anulowany tekst")
    dialog.reject()
    assert okno.szkice.lista()[0].oferta.opis == o.opis
    s.edytuj()
    dialog = s.dialog
    edytor = dialog.findChild(EdytorOpisu)
    edytor.findChild(TekstWizualny).setPlainText("Zapisany tekst")
    edytor.dodaj_zdjecie("")
    buttons = dialog.findChild(QDialogButtonBox)
    buttons.accepted.emit()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert dialog.isVisible() and dialog.isEnabled() and not dialog.trwa
    assert "Zapisany tekst" in edytor.opis()
    assert okno.szkice.lista()[0].oferta == o
    pole = edytor.pole.findChild(QLineEdit)
    pole.setText("https://example.test/nowe.png")
    pole.textEdited.emit(pole.text())
    buttons.accepted.emit()
    qtbot.waitUntil(lambda: not okno._zadania and not s.trwa)
    saved = okno.szkice.lista()[0].oferta
    assert "Zapisany tekst" in saved.opis and len(saved.sekcje) == 2
    assert saved.sekcje[1][0].adres == pole.text()
    assert okno.katalog.wyszukaj() == []


def test_masowe_usuwanie_szkicow_zaznaczenie_filtr_i_anulowanie(qtbot, okno, monkeypatch):
    from dataclasses import replace

    from PySide6.QtCore import QItemSelectionModel, Qt
    from PySide6.QtWidgets import QMessageBox

    from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad

    o = OfertaPodglad(1, "TEST-A", "Grupa A", "", "", "", "", (), (), ())
    oferty = tuple(
        replace(o, numer=i, sku=f"TEST-{i}", tytul="Grupa A" if i < 3 else "Grupa B")
        for i in range(5)
    )
    okno.szkice.zapisz(okno.szkice.zaplanuj(oferty, "test.zip"))
    okno.przejdz("Szkice")
    s = okno.strona_szkicow
    qtbot.waitUntil(lambda: not okno._zadania and not s.trwa)
    s.tabela.selectRow(0)
    s.tabela.selectionModel().select(
        s.tabela.model().index(2, 0),
        QItemSelectionModel.SelectionFlag.Select | QItemSelectionModel.SelectionFlag.Rows,
    )
    assert "Zaznaczono: 2" in s.info_wybor.text()
    s.edytuj()
    assert "dokładnie jeden" in s.info.text() and s.dialog is None
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    s.usun()
    assert len(okno.szkice.lista()) == 5
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    s.usun()
    qtbot.waitUntil(lambda: not okno._zadania and not s.trwa)
    assert s.tabela.rowCount() == 3 and len(okno.katalog.wyszukaj()) == 0
    s.szukaj.setText("Grupa A")
    assert s.tabela.rowCount() == 2
    s.tabela.setFocus()
    qtbot.keyClick(s.tabela, Qt.Key.Key_A, Qt.KeyboardModifier.ControlModifier)
    assert len(s.tabela.selectionModel().selectedRows(0)) == 2
    qtbot.mouseClick(s.odznacz, Qt.MouseButton.LeftButton)
    assert not s.tabela.selectionModel().selectedRows(0)

    def potwierdzenie(*args):
        # Zmiana filtra podczas potwierdzenia nie zmienia zatwierdzonego zakresu.
        s.szukaj.setText("Grupa B")
        return QMessageBox.StandardButton.Yes

    monkeypatch.setattr(QMessageBox, "question", potwierdzenie)
    s.usun(True)
    qtbot.waitUntil(lambda: not okno._zadania and not s.trwa)
    pozostale = okno.szkice.lista()
    assert len(pozostale) == 1 and pozostale[0].oferta.tytul == "Grupa B"
    assert len(okno.katalog.wyszukaj()) == 0
    s.szukaj.setText("Nie ma takiego szkicu")
    s.usun(True)
    assert "Brak szkiców" in s.info.text()
    s.szukaj.clear()
    s.usun(True)
    qtbot.waitUntil(lambda: not okno._zadania and not s.trwa)
    assert okno.szkice.lista() == () and len(okno.katalog.wyszukaj()) == 0


def test_zdjecia_w_oknie_paczki_i_zapisanego_szkicu(qtbot, okno):
    from PySide6.QtCore import QBuffer, QIODevice

    from vexlab.gui.podglad_oferty import ObrazPodgladu
    from vexlab.przypadki_uzycia.media import ZdjecieDane
    from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
    from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec

    image = QImage(100, 50, QImage.Format.Format_RGB32)
    image.fill(0xFF22AACC)
    out = QBuffer()
    out.open(QIODevice.OpenModeFlag.WriteOnly)
    assert image.save(out, "PNG")
    dane = bytes(out.data())
    wywolania = []

    class Zrodlo:
        def pobierz_obraz(self, url):
            wywolania.append(url)
            return ZdjecieDane(url, dane, dane)

    serwis = PodgladZdjec(Zrodlo())
    o = OfertaPodglad(
        1,
        "ZDJ",
        "Podgląd",
        "<p>Opis</p>",
        "",
        "",
        "",
        ("https://example.test/a.png",),
        ((ElementPodgladu("obraz", adres="https://example.test/a.png"),),),
        (),
    )
    okno.przejdz("Nowe oferty")
    p = okno.strona_paczek
    p.zdjecia = serwis
    p.oferty = (o,)
    p.tabela.setRowCount(1)
    p.tabela.setCurrentCell(0, 0)
    p.szczegoly()
    qtbot.waitUntil(lambda: not okno._zadania and len(wywolania) == 1)
    assert all(not x.obraz.isNull() for x in p.dialog.findChildren(ObrazPodgladu))
    p.dialog.reject()
    okno.szkice.zapisz(okno.szkice.zaplanuj((o,), "zdjecia.zip"))
    okno.przejdz("Szkice")
    s = okno.strona_szkicow
    s.zdjecia = serwis
    qtbot.waitUntil(lambda: not okno._zadania and not s.trwa)
    s.tabela.setCurrentCell(0, 0)
    s.podglad()
    qtbot.waitUntil(lambda: not okno._zadania and len(wywolania) == 2)
    assert all(not x.obraz.isNull() for x in s.dialog.findChildren(ObrazPodgladu))
    s.dialog.reject()
    assert s.dialog is None and okno.katalog.wyszukaj() == []


def test_menu_glownego_przycisku_otwiera_istniejace_obszary_bez_importu(qtbot, okno):
    b = okno.dashboard.przyciski_akcji[1]
    assert b.isEnabled()
    b.click()
    assert okno.stos.currentWidget() is okno.strony["Nowe oferty"]
    okno.przejdz("Szkice")
    assert okno.stos.currentWidget() is okno.strony["Szkice"]
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.model.rowCount() == 0


def test_gotowy_format_bez_profilu_otwiera_200_ofert_i_zapamietuje(
    qtbot, okno, tmp_path, monkeypatch
):
    plik = tmp_path / "inna-nazwa.zip"
    rekordy = [
        {
            "sku": f"TEST-{i}",
            "title": f"Testowy produkt numer {i}",
            "html": "<p>Gotowy opis</p>",
            "images": ["https://images.example.org/test.jpg"],
            "sections": [{"items": [{"type": "TEXT", "content": "<p>Opis</p>"}]}],
            "price": "123.40",
            "ean": "5901234123457",
        }
        for i in range(200)
    ]
    with ZipFile(plik, "w") as z:
        z.writestr("nowy-folder/plik.json", json.dumps(rekordy))
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a: (str(plik), ""))
    okno.przejdz("Nowe oferty")
    s = okno.strona_paczek
    s.otworz()
    czekaj(qtbot, okno)
    qtbot.waitUntil(lambda: s.tabela.item(199, 2) is not None)
    assert len(s.oferty) == s.tabela.rowCount() == 200
    assert s.tabs.currentIndex() == 1 and not s.dialog_konfiguracji.isVisible()
    assert s.tabela.item(199, 1).text() == "TEST-199"
    assert s.przygotuj_allegro.isEnabled()
    assert "niewdrożona" not in s.info.text()
    assert len(s.serwis.pamiec.lista()) == 1
    assert okno.model.rowCount() == 0


def test_podglad_bez_zapisu_lokalnego_ma_port_zdjec_z_okna_glownego(qtbot, tmp_path):
    from threading import get_ident

    from PySide6.QtCore import QBuffer, QIODevice, Qt

    from vexlab.gui.podglad_oferty import ObrazPodgladu
    from vexlab.przypadki_uzycia.media import ZdjecieDane
    from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
    from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec

    image = QImage(200, 100, QImage.Format.Format_RGB32)
    image.fill(Qt.GlobalColor.blue)
    out = QBuffer()
    out.open(QIODevice.OpenModeFlag.WriteOnly)
    image.save(out, "PNG")
    png = bytes(out.data())
    watki = []

    class Zrodlo:
        def pobierz_obraz(self, url):
            watki.append(get_ident())
            return ZdjecieDane(url, png, png)

    repo = ImportSQLite(tmp_path / "nowy.sqlite3")
    photos = PodgladZdjec(Zrodlo())
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "ustawienia.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
        paczki=PodgladPaczek(CzytnikZIP(), ProfileJSON()),
        podglad_zdjec=photos,
    )
    qtbot.addWidget(w, before_close_func=lambda _: qtbot.waitUntil(lambda: not w._zadania))
    w.show()
    qtbot.waitUntil(lambda: not w._zadania)
    s = w.strona_paczek
    assert s.zdjecia is photos
    o = OfertaPodglad(
        1,
        "TEST",
        "Pełny tytuł oferty",
        "<p>Opis</p>",
        "",
        "123",
        "",
        ("https://images.example.org/photo.jpg",),
        ((ElementPodgladu("obraz", adres="https://images.example.org/photo.jpg"),),),
        (),
    )
    s._pokaz((o,))
    s.tabela.selectRow(0)
    s.szczegoly()
    d = s.dialog
    assert d is not None
    qtbot.waitUntil(lambda: not w._zadania and not d.obrazy.trwa and bool(watki))
    assert d.tabs.currentWidget() is d.pelna_oferta
    assert all(not p.obraz.isNull() for p in d.pelna_oferta.findChildren(ObrazPodgladu))
    assert all(t != get_ident() for t in watki)
    assert w.model.rowCount() == 0 and w.szkice is None
    assert s.oferty == (o,)
    d.reject()
    assert s.dialog is None
