import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel

from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.przyciski import KartaAkcji
from vexlab.przypadki_uzycia.powloka import Motyw


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_karta_pozostaje_przyciskiem_dla_klawiatury_i_myszy(qtbot, qapp, motyw):
    zastosuj_motyw(qapp, motyw)
    b = KartaAkcji("Cenniki", "cennik", "Przeglądaj i porównuj ceny")
    qtbot.addWidget(b)
    b.resize(280, 76)
    b.show()
    b.activateWindow()
    b.setFocus()
    qtbot.waitUntil(b.hasFocus)
    clicks = []
    b.clicked.connect(lambda: clicks.append(True))
    qtbot.keyClick(b, Qt.Key.Key_Space)
    assert clicks == [True]
    qtbot.mouseClick(b, Qt.MouseButton.LeftButton)
    assert clicks == [True, True]
    b.setEnabled(False)
    qtbot.keyClick(b, Qt.Key.Key_Space)
    qtbot.mouseClick(b, Qt.MouseButton.LeftButton)
    assert clicks == [True, True]
    assert b.accessibleName() == "Cenniki" and b.accessibleDescription()


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_waska_karta_zawija_tekst_bez_wychodzenia_poza_przycisk(qtbot, qapp, motyw):
    zastosuj_motyw(qapp, motyw)
    b = KartaAkcji("Edycja masowa", "edytuj", "Zmień dane zaznaczonych produktów")
    qtbot.addWidget(b)
    b.show()
    b.resize(160, b.heightForWidth(160))
    qapp.processEvents()
    assert not b.grab().isNull()
    labels = [x for x in b.findChildren(QLabel) if x.text()]
    assert len(labels) == 2
    for label in labels:
        assert b.rect().contains(label.geometry())
        assert label.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
