from dataclasses import replace
from uuid import uuid4

import pytest
from PySide6.QtCore import QSettings, Qt
from PySide6.QtWidgets import QMessageBox

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty, PozycjaImportu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow


def czekaj(qtbot, w):
    qtbot.waitUntil(
        lambda: (
            not w._zadania
            and not w.strona_cennikow._podglad_trwa
            and not w.strona_cennikow._budowanie_pozycji
        )
    )


@pytest.fixture
def okno(qtbot, tmp_path):
    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    importer = ImportujProdukty(CzytnikTabel(), repo, repo)
    b = BibliotekaCennikow(repo, importer)
    rows = tuple(
        PozycjaImportu(
            uuid4(),
            uuid4(),
            "test.csv",
            "A",
            i + 2,
            DaneProduktu(f"Produkt {i:04d}", f"SKU-{i:04d}", f"Pełny opis {i}"),
        )
        for i in range(350)
    )
    rows = (
        rows[:250]
        + (replace(rows[250], dane=replace(rows[250].dane, sku="SKU-0000")),)
        + rows[251:]
    )
    b.zapisz("Test", 2026, "", importer.ocen(rows))
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "p.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        importer,
        cenniki=b,
    )
    qtbot.addWidget(w, before_close_func=lambda w: qtbot.waitUntil(lambda: not w._zadania))
    w.show()
    qtbot.waitUntil(lambda: w._katalog_wczytany and not w._zadania)
    w.przejdz("Cenniki")
    qtbot.waitUntil(lambda: w.strona_cennikow.tabela.rowCount() == 1 and not w._zadania)
    w.strona_cennikow.tabela.selectRow(0)
    qtbot.waitUntil(lambda: w.strona_cennikow.indeks is not None)
    czekaj(qtbot, w)
    yield w
    czekaj(qtbot, w)
    w.close()


def test_tabela_ma_jedna_strone_i_filtr_obejmuje_caly_cennik(qtbot, okno):
    s = okno.strona_cennikow
    assert s.wiersze.rowCount() == len(s.pozycje) == 100
    assert len(s.indeks.pozycje) == 350
    s.pasek_stron.nastepna.click()
    czekaj(qtbot, okno)
    assert s.pozycje[0].indeks == 100
    s.filtr.setText("SKU-0349")
    czekaj(qtbot, okno)
    assert s.wiersze.rowCount() == 1 and s.pozycje[0].indeks == 349
    assert s._strona == 0


def test_ctrl_a_i_odznacz_obejmuja_inne_strony(qtbot, okno):
    s = okno.strona_cennikow
    s.wiersze.setFocus()
    qtbot.keyClick(s.wiersze, Qt.Key.Key_A, Qt.KeyboardModifier.ControlModifier)
    assert len(s._indeksy_wyboru()) == 350
    assert len(s.wiersze.selectionModel().selectedRows()) == 100
    s._zmien_strone(3)
    czekaj(qtbot, okno)
    assert len(s._indeksy_wyboru()) == 350 and s.wiersze.rowCount() == 50
    s.wiersze.clearSelection()
    assert not s._indeksy_wyboru() and not s.dodaj_przycisk.isEnabled()


def test_dodanie_wyboru_z_dwoch_stron_nie_dodaje_calego_dokumentu(qtbot, okno, monkeypatch):
    s = okno.strona_cennikow
    s.wiersze.selectRow(0)
    s._zmien_strone(1)
    czekaj(qtbot, okno)
    rect = s.wiersze.visualRect(s.wiersze.model().index(1, 1))
    qtbot.mouseClick(
        s.wiersze.viewport(),
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.ControlModifier,
        rect.center(),
    )
    assert s._indeksy_wyboru() == frozenset({0, 101})
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    s.dodaj()
    czekaj(qtbot, okno)
    produkty = okno.katalog.wyszukaj()
    assert {p.sku for p in produkty} == {"SKU-0000", "SKU-0101"}
    assert {p.opis for p in produkty} == {"Pełny opis 0", "Pełny opis 101"}


def test_problem_duplikatu_pokazuje_wiersz_z_innej_strony(qtbot, okno):
    s = okno.strona_cennikow
    s.status_pozycji.setCurrentText("Do poprawy")
    czekaj(qtbot, okno)
    assert {p.indeks for p in s.pozycje} == {0, 250}
    s.pokaz_problem(0, 6)
    assert s.problem_dialog is not None
    assert "2, 252" in s.problem_dialog.text()
    s.problem_dialog.accept()
