from collections.abc import Iterator
from pathlib import Path

import pytest
from PySide6.QtCore import QSettings, Qt
from pytestqt.qtbot import QtBot

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow


@pytest.fixture
def okno(qtbot: QtBot, tmp_path: Path) -> Iterator[OknoVexLab]:
    repo = KatalogSQLite(tmp_path / "katalog.sqlite3")
    ustawienia = QSettings(str(tmp_path / "ustawienia.ini"), QSettings.Format.IniFormat)
    widget = OknoVexLab(
        PowlokaAplikacji(PreferencjeQt(ustawienia), "testowy", "test"),
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), ImportSQLite(repo.plik), repo),
    )
    qtbot.addWidget(widget)
    widget.show()
    qtbot.waitUntil(lambda: widget._katalog_wczytany and not widget._zadania)
    yield widget
    qtbot.waitUntil(lambda: not widget._zadania)
    widget.close()


def test_dodanie_producenta_przypisanie_i_zmiana_nazwy(qtbot: QtBot, okno: OknoVexLab) -> None:
    okno.przejdz("Producenci")
    page = okno.strona_producentow
    qtbot.waitUntil(lambda: not okno._zadania)
    assert page.model.rowCount() == 0
    qtbot.mouseClick(page.dodaj, Qt.MouseButton.LeftButton)
    dialog = page.formularz
    assert dialog is not None
    dialog.nazwa.setText("Producent testowy A")
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert page.model.rowCount() == 1
    producent = page.model.producenci[0]
    okno.dodaj_produkt()
    qtbot.waitUntil(lambda: okno.formularz is not None)
    produkt = okno.formularz
    assert produkt is not None
    produkt.nazwa.setText("Produkt testowy")
    produkt.sku.setText("TEST-A")
    produkt.producent.setCurrentIndex(produkt.producent.findData(str(producent.id)))
    qtbot.mouseClick(produkt.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.model.data(okno.model.index(0, 3)) == "Producent testowy A"
    okno.przejdz("Producenci")
    qtbot.waitUntil(lambda: not okno._zadania)
    page.edytuj_indeks(page.filtr.index(0, 0))
    dialog = page.formularz
    assert dialog is not None
    dialog.nazwa.setText("Producent testowy B")
    dialog.aktywny.setChecked(False)
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.model.data(okno.model.index(0, 3)) == "Producent testowy B"
    assert not page.model.producenci[0].aktywny
    page.nieaktywni.setChecked(False)
    assert page.filtr.rowCount() == 0
    page.nieaktywni.setChecked(True)
    assert page.filtr.rowCount() == 1


def test_formularz_produktu_pozwala_zachowac_nieaktywnego_ale_nie_wybiera_go_dla_nowego(
    qtbot: QtBot, okno: OknoVexLab
) -> None:
    p = okno.producenci.dodaj(DaneProducenta("Testowy A"))
    produkt = okno.katalog.dodaj(DaneProduktu("Test", "TEST-A", producent_id=p.id))
    okno.producenci.edytuj(p.id, p.wersja, DaneProducenta(p.nazwa, False))
    okno.odswiez()
    qtbot.waitUntil(lambda: not okno._zadania)
    okno.edytuj_indeks(okno.filtr.index(0, 1))
    qtbot.waitUntil(lambda: okno.formularz is not None)
    dialog = okno.formularz
    assert dialog is not None
    assert dialog.producent.currentData() == str(p.id)
    assert "nieaktywny" in dialog.producent.currentText()
    dialog.nazwa.setText("Nowa nazwa")
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.model.produkty[0].id == produkt.id
    assert okno.model.produkty[0].producent_id == p.id
    okno.dodaj_produkt()
    qtbot.waitUntil(lambda: okno.formularz is not None)
    assert okno.formularz.producent.findData(str(p.id)) == -1


def test_dezaktywacja_po_otwarciu_formularza_nie_pozwala_na_nowe_przypisanie(
    qtbot: QtBot, okno: OknoVexLab
) -> None:
    p = okno.producenci.dodaj(DaneProducenta("Testowy A"))
    okno.dodaj_produkt()
    qtbot.waitUntil(lambda: okno.formularz is not None)
    dialog = okno.formularz
    assert dialog is not None
    dialog.nazwa.setText("Nie zapisuj")
    dialog.sku.setText("TEST-A")
    dialog.producent.setCurrentIndex(dialog.producent.findData(str(p.id)))
    okno.producenci.edytuj(p.id, 1, DaneProducenta(p.nazwa, False))
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert dialog.isVisible()
    assert "nieaktywny" in dialog.blad.text()
    assert dialog.nazwa.text() == "Nie zapisuj"
    assert dialog.sku.text() == "TEST-A"
    assert okno.katalog.wyszukaj() == []


def test_identczne_nazwy_producentow_maja_rozroznialne_wybory(
    qtbot: QtBot, okno: OknoVexLab
) -> None:
    a = okno.producenci.dodaj(DaneProducenta("Testowa nazwa"))
    b = okno.producenci.dodaj(DaneProducenta("Testowa nazwa"))
    okno.dodaj_produkt()
    qtbot.waitUntil(lambda: okno.formularz is not None)
    combo = okno.formularz.producent
    index_a = combo.findData(str(a.id))
    index_b = combo.findData(str(b.id))
    assert index_a >= 0 and index_b >= 0
    assert combo.itemText(index_a) != combo.itemText(index_b)


def test_konflikt_edycji_producenta_zachowuje_formularz(qtbot: QtBot, okno: OknoVexLab) -> None:
    p = okno.producenci.dodaj(DaneProducenta("Przed"))
    okno.przejdz("Producenci")
    page = okno.strona_producentow
    qtbot.waitUntil(lambda: not okno._zadania)
    page.edytuj_indeks(page.filtr.index(0, 0))
    dialog = page.formularz
    assert dialog is not None
    dialog.nazwa.setText("Moja zmiana")
    okno.producenci.edytuj(p.id, p.wersja, DaneProducenta("Inny zapis"))
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert dialog.isVisible()
    assert "innym formularzu" in dialog.blad.text()
    assert dialog.nazwa.text() == "Moja zmiana"
    assert dialog.zapisz.isEnabled()


def test_walidacja_pustej_nazwy_i_wyszukiwanie_polskich_liter(
    qtbot: QtBot, okno: OknoVexLab
) -> None:
    okno.przejdz("Producenci")
    page = okno.strona_producentow
    qtbot.waitUntil(lambda: not okno._zadania)
    page.otworz_formularz(None)
    dialog = page.formularz
    assert dialog is not None
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert dialog.blad.text()
    dialog.nazwa.setText("Żółty testowy")
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    page.szukaj.setText("ŻÓŁTY")
    assert page.filtr.rowCount() == 1
    page.szukaj.setText("brak dopasowania")
    assert page.filtr.rowCount() == 0
