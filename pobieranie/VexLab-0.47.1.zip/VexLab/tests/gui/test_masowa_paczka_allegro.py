from dataclasses import replace

import pytest
from PySide6.QtCore import QItemSelectionModel
from PySide6.QtWidgets import QCheckBox, QDialog

from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from vexlab.gui.masowa_paczka_allegro import MasowaPaczkaAllegro


def select(w, rows):
    w.tabela.clearSelection()
    for row in rows:
        w.tabela.selectionModel().select(
            w.tabela.model().index(row, 0),
            QItemSelectionModel.SelectionFlag.Select | QItemSelectionModel.SelectionFlag.Rows,
        )
    w.tabela.setCurrentCell(rows[0], 0, QItemSelectionModel.SelectionFlag.NoUpdate)


def test_edycja_wybranego_zakresu_z_podgladem_i_ilosciami(qtbot, nowe_szkice_fixture, monkeypatch):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(qtbot, nowe_szkice_fixture, (o, replace(o, sku="2"), replace(o, sku="3")))
    select(w, (0, 2))

    def edit(d):
        assert len(d.pozycje) == 2 and not d.zastosuj.isEnabled()
        d.ceny.setChecked(True)
        d.wartosc.setText("500")
        d.liczby.setChecked(True)
        d.ilosc.setValue(7)
        d.sprawdz()
        assert d.zastosuj.isEnabled()
        d.wartosc.setText("600")
        assert not d.zastosuj.isEnabled()
        d.sprawdz()
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(MasowaPaczkaAllegro, "exec", edit)
    w.edytuj_masowo()
    wykonaj(jobs)
    assert [p.ustawienia.cena for p in w.plany] == ["600.00", "", "600.00"]
    assert [p.ustawienia.ilosc for p in w.plany] == [7, 1, 7]
    assert "POST" not in nowe_szkice_fixture[1].calls


def test_wspolne_parametry_tylko_zaznaczone_i_zmieniane(qtbot, nowe_produkty_fixture, monkeypatch):
    o = nowe_produkty_fixture[4]
    w, jobs = panel(qtbot, nowe_produkty_fixture, (o, replace(o, sku="2"), replace(o, sku="3")))
    w.przygotuj()
    wykonaj(jobs)
    select(w, (0, 2))

    def edit(d):
        checks = d.findChildren(QCheckBox)
        assert not any(c.isChecked() for c in checks)
        next(c for c in checks if "Stan" in c.text()).setChecked(True)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", edit)
    w.uzupelnij(True)
    wykonaj(jobs)
    assert [dict(p.ustawienia.wartosci)["kod"] for p in w.plany] == [o.sku, "2", "3"]
    assert "POST" not in nowe_produkty_fixture[1].calls


def test_wysylka_wylacznie_zaznaczonych_i_filtr_nie_wybiera_ukrytych(qtbot, nowe_szkice_fixture):
    o = nowe_szkice_fixture[4]
    w, jobs = panel(
        qtbot, nowe_szkice_fixture, (o, replace(o, sku="2"), replace(o, sku="3", cena="brak"))
    )
    w.przygotuj()
    wykonaj(jobs)
    w.filtr.setCurrentIndex(1)
    w.zaznacz_widoczne()
    assert w.wybrane() == (0, 1)
    select(w, (1,))
    w.wyslij(False)
    wykonaj(jobs)
    assert [r.stan for r in w.wyniki] == ["Gotowa do utworzenia", "Utworzono szkic", "Do poprawy"]
    assert nowe_szkice_fixture[1].calls.count("POST") == 1


@pytest.mark.parametrize("z_paczki", [True, False])
def test_numer_katalogowy_ma_widoczny_wybor_recznie_lub_osobno_z_paczki(
    qtbot, nowe_produkty_fixture, monkeypatch, z_paczki
):
    from PySide6.QtWidgets import QComboBox, QLineEdit

    o = nowe_produkty_fixture[4]
    w, jobs = panel(qtbot, nowe_produkty_fixture, (o, replace(o, sku="DRUGI-KOD")))
    # Pierwsza pozycja ma wcześniej ręczną wartość; wybór paczki ma przełączyć całą grupę.
    w.ustawienia[0] = replace(
        w.ustawienia[0],
        wartosci=(*w.ustawienia[0].wartosci, ("kod", "STARY")),
        zrodla=(("ean", "ean"),),
    )
    w.przygotuj()
    wykonaj(jobs)
    select(w, (0, 1))

    def edit(d):
        source = next(
            c
            for c in d.findChildren(QComboBox)
            if c.accessibleName() == "Źródło parametru Kod producenta"
        )
        assert not source.isHidden()
        assert "Z paczki" in source.itemText(source.findData("sku"))
        assert "ręcznie" in source.itemText(source.findData(""))
        source.setCurrentIndex(source.findData("sku" if z_paczki else ""))
        source.activated.emit(source.currentIndex())
        pole = next(c for c in d.findChildren(QLineEdit) if c.accessibleName() == "Kod producenta")
        assert pole.isEnabled() != z_paczki
        if not z_paczki:
            pole.setText("WŁASNY-KOD")
        assert next(
            c for c in d.findChildren(QCheckBox) if "Kod producenta" in c.text()
        ).isChecked()
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, "exec", edit)
    w.tabela.setCurrentCell(-1, -1, QItemSelectionModel.SelectionFlag.NoUpdate)
    assert w.wybrane() == (0, 1)
    w.uzupelnij(True)
    wykonaj(jobs)
    expected = [o.sku, "DRUGI-KOD"] if z_paczki else ["WŁASNY-KOD", "WŁASNY-KOD"]
    assert [dict(p.ustawienia.wartosci)["kod"] for p in w.plany] == expected
    assert all(dict(p.ustawienia.wartosci)["ean"] == p.oferta.ean for p in w.plany)
    assert "POST" not in nowe_produkty_fixture[1].calls
