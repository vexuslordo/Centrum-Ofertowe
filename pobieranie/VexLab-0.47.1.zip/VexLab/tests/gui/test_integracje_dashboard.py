import pytest
from PySide6.QtCore import Qt

from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.integracje_dashboard import PanelIntegracji, PasekIntegracji
from vexlab.przypadki_uzycia.powloka import Motyw


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_dwie_karty_maja_rzeczywisty_stan_i_nie_wymyslaja_liczb(qtbot, qapp, motyw):
    zastosuj_motyw(qapp, motyw)
    panel = PanelIntegracji()
    qtbot.addWidget(panel)
    panel.resize(350, 255)
    panel.show()
    qapp.processEvents()
    assert "Niepołączono" in panel.allegro.status.text()
    assert "Niepołączono" in panel.presta.status.text()
    assert all(x.text() == "—" for x in panel.allegro.wartosci + panel.presta.wartosci)
    panel.allegro.ustaw("konto_testowe")
    assert panel.allegro.status.property("polaczono") is True
    assert panel.allegro.wartosci[0].text() == "konto_testowe"
    assert panel.allegro.wartosci[0].textFormat() == Qt.TextFormat.PlainText
    assert panel.presta.status.property("polaczono") is False
    assert panel.rect().contains(panel.allegro.geometry())
    assert panel.rect().contains(panel.presta.geometry())
    panel.allegro.ustaw(None)
    assert panel.allegro.wartosci[0].text() == "—"
    assert not panel.allegro.status.property("polaczono")
    with qtbot.waitSignal(panel.zarzadzaj):
        panel.zarzadzaj_przycisk.click()


def test_naglowek_pokazuje_konto_tylko_po_potwierdzeniu(qtbot):
    pasek = PasekIntegracji(True)
    qtbot.addWidget(pasek)
    assert not pasek.status.property("polaczono")
    pasek.ustaw("testowy")
    assert "testowy" in pasek.status.text()
    assert pasek.status.property("polaczono")
    assert "PrestaShop: integracja w przygotowaniu" in pasek.status.toolTip()
    pasek.ustaw(None)
    assert "testowy" not in pasek.status.text()
    assert not pasek.status.property("polaczono")
