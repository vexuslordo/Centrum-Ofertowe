import pytest
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QFileDialog, QInputDialog, QMessageBox

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.adaptery.profile_cennikow_json import ProfileCennikowJSON
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty, Mapowanie, MapowanieCeny
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow
from vexlab.przypadki_uzycia.profile_cennikow import ProfileCennikow


@pytest.fixture
def okno(qtbot, tmp_path):
    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    imp = ImportujProdukty(CzytnikTabel(), repo, repo)
    producenci = RejestrProducentow(repo)
    producenci.dodaj(DaneProducenta("Producent A"))
    producenci.dodaj(DaneProducenta("Producent B"))
    profile = ProfileCennikow(ProfileCennikowJSON(tmp_path / "profile"))
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)),
            "test",
            "test",
        ),
        KatalogProduktow(repo, repo),
        producenci,
        EksportujKatalog(EksportCSV()),
        imp,
        cenniki=BibliotekaCennikow(repo, imp),
        profile_cennikow=profile,
    )
    qtbot.addWidget(w)
    w.show()
    qtbot.waitUntil(lambda: not w._zadania)
    w.przejdz("Cenniki")
    qtbot.waitUntil(lambda: not w._zadania)
    w.strona_cennikow.nowy()
    qtbot.waitUntil(lambda: not w._zadania)
    yield w
    qtbot.waitUntil(lambda: not w._zadania)
    w.close()


def czekaj(qtbot, w):
    qtbot.waitUntil(lambda: not w._zadania and not w.strona_importu._trwa)


def wczytaj(qtbot, w, tmp_path, monkeypatch, nazwa="cennik.csv", tekst=None):
    plik = tmp_path / nazwa
    plik.write_text(tekst or "Nazwa;SKU;Cena\nProdukt;A;100\n", encoding="utf-8")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **kw: (str(plik), ""))
    w.strona_importu.wybierz_plik()
    czekaj(qtbot, w)
    return plik


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_pierwszy_import_zapamietanie_i_kolejny_automatyczny_podglad(
    qtbot, okno, tmp_path, monkeypatch, motyw
):
    okno.powloka.ustaw_motyw(motyw)
    okno._motyw()
    wczytaj(qtbot, okno, tmp_path, monkeypatch)
    p = okno.strona_importu
    panel = p.panel_profili
    assert p.kol_nazwa.currentData() == 0 and p.kol_sku.currentData() == 1
    assert not p.oceny and not p.ustawienia_importu.isHidden()
    assert p.kol_cena.currentData() is None
    p.kol_cena.setCurrentIndex(p.kol_cena.findData(2))
    p.waluta.setCurrentText("PLN")
    p.rodzaj_ceny.setCurrentText("brutto")
    p.producent.setCurrentIndex(1)
    pid = p.producent.currentData()
    p.podglad.click()
    czekaj(qtbot, okno)
    monkeypatch.setattr(QInputDialog, "getText", lambda *a, **kw: ("Mój cennik", False))
    panel.zapisz.trigger()
    assert okno.profile_cennikow.magazyn.lista() == ()
    monkeypatch.setattr(QInputDialog, "getText", lambda *a, **kw: ("Mój cennik", True))
    panel.zapisz.trigger()
    czekaj(qtbot, okno)
    assert len(okno.profile_cennikow.magazyn.lista()) == 1
    assert panel.usun.isEnabled()
    okno.strona_cennikow.nowy()
    czekaj(qtbot, okno)
    wczytaj(
        qtbot,
        okno,
        tmp_path,
        monkeypatch,
        "zmieniona.csv",
        "Opis pliku;;\nNazwa;SKU;Cena\nNowy produkt;B;120\n",
    )
    assert p.oceny[0].pozycja.dane.sku == "B"
    assert p.oceny[0].pozycja.cena.tekst == "120"
    assert p.naglowek.value() == 2 and p.producent.currentData() == pid
    assert p.ustawienia_importu.isHidden() and not p.formuly_cen.isChecked()
    assert okno.cenniki.lista() == () and okno.katalog.wyszukaj() == []
    panel.ustawienia.click()
    assert not p.ustawienia_importu.isHidden()
    okno.strona_cennikow.rok.setValue(2027)
    okno.strona_cennikow.zapisz.click()
    czekaj(qtbot, okno)
    assert len(okno.cenniki.lista()) == 1 and p.plik is None
    assert p.panel_profili.wybor.count() == 1
    assert len(okno.profile_cennikow.magazyn.lista()) == 1
    assert okno.katalog.wyszukaj() == []


def test_kilka_profili_wymaga_wyboru_i_usuniecie_nie_rusza_cennikow(
    qtbot, okno, tmp_path, monkeypatch
):
    plik = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    f = okno.importer.odczytaj(plik)
    for nazwa, pid in [("A", None), ("B", okno.producenci.lista()[0].id)]:
        okno.profile_cennikow.zapisz(f, 0, Mapowanie(1, 0, 1), pid, nazwa)
    wczytaj(qtbot, okno, tmp_path, monkeypatch)
    p = okno.strona_importu
    panel = p.panel_profili
    assert panel.wybor.count() == 3 and not p.oceny
    assert panel.wybor.currentIndex() == 0
    panel.wybor.setCurrentIndex(1)
    czekaj(qtbot, okno)
    assert p.oceny and p.ustawienia_importu.isHidden()
    before = okno.cenniki.lista()
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **kw: QMessageBox.StandardButton.No)
    panel.usun.trigger()
    assert len(okno.profile_cennikow.magazyn.lista()) == 2
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **kw: QMessageBox.StandardButton.Yes)
    panel.usun.trigger()
    czekaj(qtbot, okno)
    assert len(okno.profile_cennikow.magazyn.lista()) == 1
    assert okno.cenniki.lista() == before and okno.katalog.wyszukaj() == []


def test_aktualizacja_nie_przejmuje_producenta_z_innego_profilu(qtbot, okno, tmp_path, monkeypatch):
    plik = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    f = okno.importer.odczytaj(plik)
    a, b = okno.producenci.lista()
    mapa = Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "PLN", "brutto"))
    id = okno.cenniki.zapisz("Stary", 2026, "", okno.importer.zaplanuj(f, 0, mapa, a.id))
    okno.profile_cennikow.zapisz(f, 0, mapa, b.id, "Inny producent")
    s = okno.strona_cennikow
    s.odswiez()
    czekaj(qtbot, okno)
    s.tabela.selectRow(0)
    assert s._wybrane()[0].id == id
    s.aktualizuj_cennik()
    czekaj(qtbot, okno)
    wczytaj(qtbot, okno, tmp_path, monkeypatch)
    p = okno.strona_importu
    assert p.producent.currentData() == str(a.id) and not p.producent.isEnabled()
    assert p.panel_profili.wybor.count() == 1 and not p.oceny


def test_uszkodzony_profil_nie_blokuje_recznego_podgladu(qtbot, okno, tmp_path, monkeypatch):
    folder = okno.profile_cennikow.magazyn.katalog
    folder.mkdir()
    (folder / "zepsuty.json").write_text("{}")
    wczytaj(qtbot, okno, tmp_path, monkeypatch)
    p = okno.strona_importu
    assert "Nie można odczytać" in p.panel_profili.info.text()
    p.kol_nazwa.setCurrentIndex(p.kol_nazwa.findData(0))
    p.kol_sku.setCurrentIndex(p.kol_sku.findData(1))
    p.podglad.click()
    czekaj(qtbot, okno)
    assert p.oceny and (folder / "zepsuty.json").exists()
