import pytest
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QComboBox, QVBoxLayout, QWidget

from vexlab.gui.design_system import zastosuj_motyw
from vexlab.przypadki_uzycia.powloka import Motyw


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_wybor_ma_kontrastowe_tlo_i_potwierdza_klawiatura(qtbot, qapp, motyw):
    zastosuj_motyw(qapp, motyw)
    w = QWidget()
    qtbot.addWidget(w)
    layout = QVBoxLayout(w)
    combo = QComboBox()
    combo.addItems(["Producent A", "Producent B", "Producent C"])
    combo.setCurrentIndex(1)
    layout.addWidget(combo)
    w.resize(420, 120)
    w.show()
    combo.showPopup()
    qapp.processEvents()
    view = combo.view()
    image = view.viewport().grab().toImage()
    selected = view.visualRect(view.model().index(1, 0))
    other = view.visualRect(view.model().index(0, 0))
    scale = image.devicePixelRatio()
    assert image.pixelColor(
        int((selected.right() - 8) * scale), int(selected.center().y() * scale)
    ) == QColor("#1767B6")
    assert image.pixelColor(
        int((other.right() - 8) * scale), int(other.center().y() * scale)
    ) != QColor("#1767B6")
    qtbot.keyClick(view, Qt.Key.Key_Down)
    qtbot.keyClick(view, Qt.Key.Key_Return)
    assert combo.currentText() == "Producent C"
    assert combo.count() == 3
