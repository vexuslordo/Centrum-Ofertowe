from dataclasses import replace

from PySide6.QtCore import QMimeData, QModelIndex, QPointF, Qt
from PySide6.QtGui import QDragEnterEvent, QDropEvent

from vexlab.gui.edytor_opisu import EdytorOpisu, TekstWizualny, html_edytora
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad


def dane():
    return OfertaPodglad(
        1,
        "TEST",
        "Tytuł",
        "<h1>Pełny opis</h1><p><b>Tekst</b></p>",
        "",
        "",
        "",
        ("https://example.test/foto.png",),
        (
            (ElementPodgladu("tekst", "<p>Pierwszy tekst</p>"),),
            (ElementPodgladu("tekst", "<p>Drugi tekst</p>"),),
        ),
        (),
    )


def edytor(qtbot, oferta=None):
    e = EdytorOpisu(oferta or dane())
    qtbot.addWidget(e)
    e.resize(1000, 650)
    e.show()
    return e


def test_renderowanie_bez_html_i_otwarcie_bez_zmiany_danych(qtbot):
    d = dane()
    e = edytor(qtbot)
    tekst = e.findChild(TekstWizualny)
    assert tekst.toPlainText() == "Pierwszy tekst" and "<p>" not in tekst.toPlainText()
    assert e.opis() == d.opis and e.wynik_sekcji() == d.sekcje and not e.zmieniony
    e.lista.setCurrentRow(1)
    e.tabs.setCurrentIndex(1)
    assert "Pełny opis" in e.podglad.toPlainText()
    assert not e.zmieniony


def test_edycja_formatowanie_i_strzalki_zmieniaja_zapisany_uklad(qtbot):
    e = edytor(qtbot)
    tekst = e.findChild(TekstWizualny)
    tekst.selectAll()
    tekst.insertPlainText("Nowy tekst")
    tekst.selectAll()
    e.formatuj(tekst, "bold")
    assert "<b>Nowy tekst</b>" in e.sekcje()[0][0].tekst
    assert "Nowy tekst" in e.opis()
    e.przesun(1)
    assert "Nowy tekst" in e.sekcje()[1][0].tekst
    e.usun()
    assert len(e.sekcje()) == 1 and "Nowy tekst" not in e.opis()


def test_przeniesienie_wiersza_modelu_uzywane_przez_drag_drop(qtbot):
    e = edytor(qtbot)
    model = e.lista.model()
    assert model.moveRows(QModelIndex(), 0, 1, QModelIndex(), 2)
    assert "Drugi" in e.sekcje()[0][0].tekst
    assert "Pierwszy" in e.sekcje()[1][0].tekst
    assert e.zmieniony and e.opis().index("Drugi") < e.opis().index("Pierwszy")


def test_drag_drop_adresu_z_galerii_tworzacy_sekcje(qtbot):
    e = edytor(qtbot)
    mime = e.galeria.mimeData([e.galeria.item(0)])
    wejscie = QDragEnterEvent(
        QPointF(e.lista.rect().center()),
        Qt.DropAction.CopyAction,
        mime,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    e.lista.dragEnterEvent(wejscie)
    assert wejscie.isAccepted()
    drop = QDropEvent(
        QPointF(e.lista.rect().center()),
        Qt.DropAction.CopyAction,
        mime,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    e.lista.dropEvent(drop)
    assert drop.isAccepted()
    assert e.sekcje()[-1] == (ElementPodgladu("obraz", adres=dane().zdjecia[0]),)
    assert len(e.oferta.zdjecia) == 1


def test_brak_sekcji_nie_powoduje_konwersji_przed_zmiana(qtbot):
    d = replace(dane(), sekcje=())
    e = edytor(qtbot, d)
    assert e.findChild(TekstWizualny).toPlainText().startswith("Pełny opis")
    assert e.wynik_sekcji() == () and e.opis() == d.opis


def test_wklejenie_html_bez_skryptow_plikow_lub_obrazow(qtbot):
    e = edytor(qtbot)
    tekst = e.findChild(TekstWizualny)
    mime = QMimeData()
    mime.setHtml('<script>sekret()</script><img src="file:///tajny"><p><b>Widoczne</b></p>')
    tekst.selectAll()
    tekst.insertFromMimeData(mime)
    assert "sekret" not in tekst.toPlainText() and "Widoczne" in tekst.toPlainText()
    assert "file:///" not in e.opis() and "<b>Widoczne</b>" in e.opis()
    assert tekst.loadResource(2, "https://example.test/obraz") is None
    assert "font-weight" not in html_edytora(tekst.toHtml())


def test_paczka_z_banerem_otwiera_od_razu_sekcje_tekstu(qtbot):
    d = dane()
    sekcje = ((ElementPodgladu("obraz", adres="https://example.test/baner.png"),),) + d.sekcje
    e = edytor(qtbot, replace(d, sekcje=sekcje))
    assert e.lista.currentRow() == 1
    assert e.pole.findChild(TekstWizualny).toPlainText() == "Pierwszy tekst"
    assert not e.zmieniony and e.wynik_sekcji() == sekcje
