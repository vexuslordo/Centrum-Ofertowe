from uuid import uuid4

from PySide6.QtWidgets import QMessageBox, QWidget

from vexlab.gui.galeria import GaleriaProduktu
from vexlab.przypadki_uzycia.galeria import GaleriaDTO
from vexlab.przypadki_uzycia.media import ZdjecieDane


class Serwis:
    def __init__(self):
        self.zapisane = []

    def zapisz(self, dane):
        self.zapisane.append(dane)


def test_galeria_zmiany_robocze_zapis_i_potwierdzenie_czyszczenia(qtbot, monkeypatch):
    parent = QWidget()
    qtbot.addWidget(parent)
    serwis = Serwis()
    zdjecia = (ZdjecieDane("A", b"a", b"a"), ZdjecieDane("B", b"b", b"b"))
    dane = GaleriaDTO(uuid4(), 1, zdjecia)
    odswiezenia = []
    dialog = GaleriaProduktu(
        dane, "Test", serwis, lambda fn, ok, err: ok(fn()), lambda: odswiezenia.append(1), parent
    )
    qtbot.addWidget(dialog)
    dialog.przesun(1)
    assert dialog.zdjecia == list(zdjecia[::-1]) and serwis.zapisane == []
    dialog.zapisz()
    assert serwis.zapisane[0].zdjecia == zdjecia[::-1] and odswiezenia == [1]
    dialog.usun()
    dialog.usun()
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    dialog.zapisz()
    assert len(serwis.zapisane) == 1
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    dialog.zapisz()
    assert serwis.zapisane[-1].zdjecia == ()


def test_zamkniecie_blokowane_w_trakcie_zapisu_i_ochrona_zmian(qtbot, monkeypatch):
    parent = QWidget()
    qtbot.addWidget(parent)
    dane = GaleriaDTO(uuid4(), 1, (ZdjecieDane("A", b"a", b"a"),))
    dialog = GaleriaProduktu(dane, "Test", Serwis(), lambda *a: None, lambda: None, parent)
    qtbot.addWidget(dialog)
    dialog.show()
    dialog.usun()
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    dialog.reject()
    assert dialog.isVisible()
    dialog.zajetosc(True, "Zapisywanie…")
    dialog.close()
    assert dialog.isVisible() and not dialog.zapisz_przycisk.isEnabled()
    dialog.blad("BLAD", "Nie zapisano")
    assert dialog.zapisz_przycisk.isEnabled() and dialog.info.text() == "Nie zapisano"
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    dialog.reject()
    assert not dialog.isVisible()
