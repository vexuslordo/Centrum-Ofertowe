from threading import get_ident

import pytest
from PySide6.QtCore import QSettings, Qt
from PySide6.QtWidgets import QFileDialog, QPushButton

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow


@pytest.fixture
def okno(qtbot, tmp_path):
    repo = ImportSQLite(tmp_path / "test.sqlite3")
    rejestr = RejestrProducentow(repo)
    rejestr.dodaj(DaneProducenta("Producent testowy"))
    w = OknoVexLab(
        PowlokaAplikacji(
            PreferencjeQt(QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)),
            "testowy",
            "test",
        ),
        KatalogProduktow(repo, repo),
        rejestr,
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), repo, repo),
    )
    qtbot.addWidget(w)
    w.show()
    qtbot.waitUntil(lambda: not w._zadania and w._katalog_wczytany)
    yield w
    qtbot.waitUntil(lambda: not w._zadania)
    if w.strona_importu.dialog:
        w.strona_importu.dialog.reject()
    if w.formularz:
        w.formularz.reject()
    w.close()


def czekaj(qtbot, okno):
    qtbot.waitUntil(lambda: not okno._zadania and not okno.strona_importu._trwa)


def wczytaj(qtbot, okno, tmp_path, monkeypatch):
    plik = tmp_path / "test.csv"
    plik.write_text(
        "Kod;Nazwa;Opis;Cena\n0007;Łącznik;Opis;123\nDUP;A;;1\ndup;B;;2\n;Bez SKU;;3\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **kw: (str(plik), ""))
    okno.przejdz("Cenniki")
    czekaj(qtbot, okno)
    s = okno.strona_importu
    qtbot.mouseClick(s.wybierz, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    s.kol_nazwa.setCurrentIndex(s.kol_nazwa.findData(1))
    s.kol_sku.setCurrentIndex(s.kol_sku.findData(0))
    s.kol_opis.setCurrentIndex(s.kol_opis.findData(2))
    s.producent.setCurrentIndex(1)
    return s


def test_pelny_import_i_korekta_z_klawiatury(qtbot, okno, tmp_path, monkeypatch):
    s = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    assert "Cena" in s.pominiete.text()
    qtbot.mouseClick(s.podglad, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert s.wyniki.rowCount() == 4
    assert s.wyniki.item(0, 0).checkState() == Qt.CheckState.Checked
    assert s.wyniki.item(1, 0).checkState() == Qt.CheckState.Unchecked
    qtbot.mouseClick(s.zapisz, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert len(okno.katalog.wyszukaj()) == 1
    assert okno.katalog.wyszukaj()[0].sku == "0007"
    assert okno.katalog.wyszukaj()[0].producent_nazwa == "Producent testowy"
    assert s.korekty.rowCount() == 3
    assert "1 nowych" in s.raport.text()
    row = next(i for i, p in enumerate(s.pozycje) if not p.dane.sku)
    s.korekty.selectRow(row)
    qtbot.mouseClick(s.popraw_przycisk, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    d = s.dialog
    assert d is not None
    d.sku.setFocus()
    qtbot.keyClicks(d.sku, "NOWY")
    add = next(
        b for b in d.findChildren(QPushButton) if b.text() == "Dodaj poprawiony Produkt do katalogu"
    )
    qtbot.mouseClick(add, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert s.dialog is None
    assert s.korekty.rowCount() == 2
    assert len(okno.katalog.wyszukaj()) == 2


def test_zmiana_mapowania_uniewaznia_plan_i_anulowanie_nie_zapisuje(
    qtbot, okno, tmp_path, monkeypatch
):
    s = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    s.zaplanuj()
    czekaj(qtbot, okno)
    assert s.zapisz.isEnabled()
    s.producent.setCurrentIndex(0)
    assert not s.zapisz.isEnabled() and not s.oceny
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **kw: ("", ""))
    s.wybierz_plik()
    assert not okno.katalog.wyszukaj()
    assert not s.serwis.oczekujace()


def test_blad_zapisu_zachowuje_podglad_i_nic_nie_zapisuje(qtbot, okno, tmp_path, monkeypatch):
    s = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    s.zaplanuj()
    czekaj(qtbot, okno)
    s.wyniki.item(1, 0).setCheckState(Qt.CheckState.Checked)
    s.wyniki.item(2, 0).setCheckState(Qt.CheckState.Checked)
    s.zatwierdz()
    czekaj(qtbot, okno)
    assert s.oceny and s.zapisz.isEnabled()
    assert "błędy" in s.info.text()
    assert not okno.katalog.wyszukaj()
    assert not s.serwis.oczekujace()


def test_odczyt_i_zapis_poza_watkiem_gui(qtbot, okno, tmp_path, monkeypatch):
    watki = []
    orig = okno.importer.odczytaj

    def odczyt(p):
        watki.append(get_ident())
        return orig(p)

    monkeypatch.setattr(okno.importer, "odczytaj", odczyt)
    s = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    orig_zapis = okno.importer.zatwierdz

    def zapis(*args):
        watki.append(get_ident())
        return orig_zapis(*args)

    monkeypatch.setattr(okno.importer, "zatwierdz", zapis)
    s.zaplanuj()
    czekaj(qtbot, okno)
    s.zatwierdz()
    czekaj(qtbot, okno)
    assert len(watki) == 2 and all(w != get_ident() for w in watki)


def test_wejscie_z_formularza_do_importu(qtbot, okno):
    okno.dodaj_produkt()
    czekaj(qtbot, okno)
    d = okno.formularz
    assert d is not None
    b = next(
        b for b in d.findChildren(QPushButton) if b.text() == "Importuj wiele produktów z pliku…"
    )
    qtbot.mouseClick(b, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert okno.formularz is None
    assert okno.stos.currentWidget() is okno.strona_importu


def test_korekta_blad_i_zapis_szkicu_na_pozniej(qtbot, okno, tmp_path, monkeypatch):
    s = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    s.zaplanuj()
    czekaj(qtbot, okno)
    s.zatwierdz()
    czekaj(qtbot, okno)
    row = next(i for i, p in enumerate(s.pozycje) if not p.dane.sku)
    pid = s.pozycje[row].id
    s.korekty.selectRow(row)
    s.edytuj()
    czekaj(qtbot, okno)
    d = s.dialog
    assert d is not None
    b = next(
        b for b in d.findChildren(QPushButton) if b.text() == "Dodaj poprawiony Produkt do katalogu"
    )
    qtbot.mouseClick(b, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert s.dialog is d and d.isEnabled()
    assert d.sku.hasFocus()
    d.sku.setText("POZNIEJ")
    qtbot.mouseClick(d.zapisz, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert s.dialog is None
    assert next(p for p in s.serwis.oczekujace() if p.id == pid).dane.sku == "POZNIEJ"
    assert len(okno.katalog.wyszukaj()) == 1


def test_motywy_i_male_okno_maja_dostepne_kontrolki(qtbot, okno):
    from vexlab.przypadki_uzycia.powloka import Motyw

    okno.przejdz("Cenniki")
    czekaj(qtbot, okno)
    okno.resize(800, 620)
    for motyw in (Motyw.CIEMNY, Motyw.JASNY):
        okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(motyw))
        qtbot.wait(20)
        s = okno.strona_importu
        assert s.wybierz.isVisible()
        assert s.naglowek.isEnabled()
        assert not s.zapisz.isEnabled()
        assert okno.width() == 800
        assert okno.height() == 620


def test_blad_nowego_pliku_uniewaznia_poprzedni_plan(qtbot, okno, tmp_path, monkeypatch):
    s = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    s.zaplanuj()
    czekaj(qtbot, okno)
    assert s.oceny
    plik = tmp_path / "uszkodzony.xlsx"
    plik.write_bytes(b"Nie XLSX")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **kw: (str(plik), ""))
    s.wybierz_plik()
    czekaj(qtbot, okno)
    assert s.plik is None and not s.oceny and not s.zapisz.isEnabled()
    assert "Nie można" in s.info.text()
    assert not okno.katalog.wyszukaj()


def test_opis_z_nazwy_i_dodatkowych_pol_widoczny_przed_zapisem(qtbot, okno, tmp_path, monkeypatch):
    s = wczytaj(qtbot, okno, tmp_path, monkeypatch)
    s.dolacz_nazwe.setChecked(True)
    s.zaplanuj()
    czekaj(qtbot, okno)
    assert s.oceny[0].pozycja.dane.opis == "Łącznik\n\nOpis"
    assert s.wyniki.item(0, 4).text() == "Łącznik\n\nOpis"
    s.wyniki.selectRow(0)
    s.podglad_wiersza()
    assert s.podglad_dialog is not None
    assert s.podglad_dialog.opis.toPlainText() == "Łącznik\n\nOpis"
    assert s.podglad_dialog.opis.isReadOnly()
    s.podglad_dialog.reject()
    qtbot.waitUntil(lambda: s.podglad_dialog is None)
    s.dolacz_nazwe.setChecked(False)
    assert not s.oceny and not s.zapisz.isEnabled()


def test_mapowanie_dopasowan_podglad_i_trwala_korekta(qtbot, okno, tmp_path, monkeypatch):
    from vexlab.przypadki_uzycia.katalog import DaneDopasowania

    p = tmp_path / "motocykle.csv"
    p.write_text(
        "Nazwa;SKU;Marka;Model;Od;Do\nCzęść;A;Marka A;Model X;2018;2020\nInna;B;Marka B;;zły;\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **kw: (str(p), ""))
    okno.przejdz("Cenniki")
    czekaj(qtbot, okno)
    s = okno.strona_importu
    s.wybierz_plik()
    czekaj(qtbot, okno)
    s.kol_nazwa.setCurrentIndex(s.kol_nazwa.findData(0))
    s.kol_sku.setCurrentIndex(s.kol_sku.findData(1))
    assert not s.moto_grupa.isChecked()
    s.moto_grupa.setChecked(True)
    s.zaplanuj()
    assert "Wskaż kolumny" in s.info.text()
    for box, indeks in zip(s.kolumny_moto, (2, 3, 4, 5, None), strict=True):
        box.setCurrentIndex(box.findData(indeks))
    s.zaplanuj()
    czekaj(qtbot, okno)
    assert s.wyniki.item(0, 0).checkState() == Qt.CheckState.Checked
    assert s.wyniki.item(1, 0).checkState() == Qt.CheckState.Unchecked
    assert "Model X" in s.wyniki.item(0, 7).text()
    s.wyniki.selectRow(1)
    s.podglad_wiersza()
    assert "zły" in s.podglad_dialog.dopasowania_podglad.toPlainText()
    s.podglad_dialog.reject()
    qtbot.waitUntil(lambda: s.podglad_dialog is None)
    s.zatwierdz()
    czekaj(qtbot, okno)
    assert okno.katalog.wyszukaj("A")[0].dopasowania[0].rok_do == 2020
    s.tabs.setCurrentIndex(1)
    s.odswiez()
    czekaj(qtbot, okno)
    s.korekty.selectRow(0)
    s.edytuj()
    czekaj(qtbot, okno)
    d = s.dialog
    assert d.dopasowania[0].rok_od == "zły" and d.dopasowania[0].model == ""
    d.dopasowania = (DaneDopasowania("Marka B", "Model Y", "2021"),)
    qtbot.mouseClick(d.zapisz, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert s.dialog is None
    s.korekty.selectRow(0)
    s.edytuj()
    czekaj(qtbot, okno)
    d = s.dialog
    assert d.dopasowania[0].model == "Model Y"
    dodaj = next(
        b for b in d.findChildren(QPushButton) if b.text() == "Dodaj poprawiony Produkt do katalogu"
    )
    qtbot.mouseClick(dodaj, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert okno.katalog.wyszukaj("B")[0].dopasowania[0].rok_od == 2021
    s.tabs.setCurrentIndex(0)
    s.moto_grupa.setChecked(False)
    assert not s.oceny and not s.zapisz.isEnabled()


def test_czyszczenie_odlozonych_anulowanie_wybor_i_cala_lista(qtbot, okno, tmp_path, monkeypatch):
    from PySide6.QtWidgets import QMessageBox

    wczytaj(qtbot, okno, tmp_path, monkeypatch)
    s = okno.strona_importu
    qtbot.mouseClick(s.podglad, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    qtbot.mouseClick(s.zapisz, Qt.MouseButton.LeftButton)
    czekaj(qtbot, okno)
    assert len(s.pozycje) > 1
    liczba = len(s.pozycje)
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.No)
    s.usun_odlozone(True)
    assert len(s.pozycje) == liczba
    monkeypatch.setattr(QMessageBox, "question", lambda *a: QMessageBox.StandardButton.Yes)
    s.korekty.selectRow(0)
    s.usun_odlozone(False)
    czekaj(qtbot, okno)
    assert len(s.pozycje) == liczba - 1
    s.usun_odlozone(True)
    czekaj(qtbot, okno)
    assert s.korekty.rowCount() == 0
    assert len(s.katalog.wyszukaj()) == 1


def test_mapowanie_ean_podglad_i_poprawienie_blednego_kodu(qtbot, okno, tmp_path, monkeypatch):
    plik = tmp_path / "ean.csv"
    plik.write_text(
        "SKU;Nazwa;EAN\nA;Produkt A;0123456789012\nB;Produkt B;5901234123458\n", encoding="utf-8"
    )
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **kw: (str(plik), ""))
    okno.przejdz("Cenniki")
    czekaj(qtbot, okno)
    s = okno.strona_importu
    s.wybierz_plik()
    czekaj(qtbot, okno)
    s.kol_nazwa.setCurrentIndex(s.kol_nazwa.findData(1))
    s.kol_sku.setCurrentIndex(s.kol_sku.findData(0))
    s.kol_ean.setCurrentIndex(s.kol_ean.findData(2))
    s.zaplanuj()
    czekaj(qtbot, okno)
    assert s.wyniki.item(0, 8).text() == "0123456789012"
    assert "EAN" in s.wyniki.item(1, 6).text()
    s.zatwierdz()
    czekaj(qtbot, okno)
    assert okno.katalog.wyszukaj()[0].ean == "0123456789012"
    s.korekty.selectRow(0)
    s.edytuj()
    czekaj(qtbot, okno)
    dialog = s.dialog
    assert dialog is not None and dialog.ean.text() == "5901234123458"
    dialog.ean.setText("5901234123457")
    button = next(
        b
        for b in dialog.findChildren(QPushButton)
        if b.text() == "Dodaj poprawiony Produkt do katalogu"
    )
    button.click()
    czekaj(qtbot, okno)
    assert {p.ean for p in okno.katalog.wyszukaj()} == {"0123456789012", "5901234123457"}
    assert s.korekty.rowCount() == 0


def test_formularz_i_szczegoly_ean_z_walidacja(qtbot, okno):
    okno.dodaj_produkt()
    czekaj(qtbot, okno)
    dialog = okno.formularz
    assert dialog is not None
    dialog.nazwa.setText("Produkt")
    dialog.sku.setText("EAN-TEST")
    dialog.ean.setText("5901234123458")
    dialog.zapisz.click()
    czekaj(qtbot, okno)
    assert "EAN" in dialog.blad.text() and okno.katalog.wyszukaj() == []
    dialog.ean.setText("0123456789012")
    dialog.zapisz.click()
    czekaj(qtbot, okno)
    assert okno.katalog.wyszukaj()[0].ean == "0123456789012"
    from vexlab.gui.katalog import SzczegolyProduktu

    details = SzczegolyProduktu(okno.katalog.wyszukaj()[0], okno)
    qtbot.addWidget(details)
    assert details.ean.text() == "0123456789012" and details.ean.isReadOnly()
