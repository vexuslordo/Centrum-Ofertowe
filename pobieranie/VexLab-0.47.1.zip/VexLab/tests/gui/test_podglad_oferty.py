from dataclasses import replace

from PySide6.QtCore import QBuffer, QIODevice, Qt
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QLineEdit

from vexlab.gui.edytor_opisu import EdytorOpisu
from vexlab.gui.podglad_oferty import ObrazPodgladu, TekstSekcji
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec


def png():
    image = QImage(100, 50, QImage.Format.Format_RGB32)
    image.fill(Qt.GlobalColor.blue)
    out = QBuffer()
    out.open(QIODevice.OpenModeFlag.WriteOnly)
    assert image.save(out, "PNG")
    return bytes(out.data())


def oferta():
    return OfertaPodglad(
        1,
        "SKU",
        "Tytuł",
        "<p>Opis</p>",
        "",
        "",
        "",
        ("https://example.test/a.png",),
        (
            (
                ElementPodgladu("obraz", adres="https://example.test/a.png"),
                ElementPodgladu("tekst", "<h2>Opis sekcji</h2><p>Treść</p>"),
            ),
        ),
        (),
    )


def test_zdjecia_w_edytorze_i_pelny_uklad_bez_zmiany_szkicu(qtbot):
    wywolania = []

    class Zrodlo:
        def pobierz_obraz(self, url):
            wywolania.append(url)
            return ZdjecieDane(url, png(), png())

    def uruchom(fn, ok, blad):
        ok(fn())

    d = oferta()
    e = EdytorOpisu(d, zdjecia=PodgladZdjec(Zrodlo()), uruchom=uruchom)
    qtbot.addWidget(e)
    e.resize(1100, 700)
    e.show()
    qtbot.waitUntil(lambda: len(wywolania) == 1)
    assert not e.findChild(ObrazPodgladu).obraz.isNull()
    e.tabs.setCurrentIndex(2)
    qtbot.waitUntil(lambda: not e.obrazy.trwa)
    assert len(wywolania) == 1
    assert all(not img.obraz.isNull() for img in e.pelna_oferta.findChildren(ObrazPodgladu))
    assert "Opis sekcji" in e.pelna_oferta.findChild(TekstSekcji).toPlainText()
    assert e.opis() == d.opis and e.wynik_sekcji() == d.sekcje and not e.zmieniony
    e.findChild(QLineEdit).setText("https://example.test/b.png")
    e.findChild(QLineEdit).editingFinished.emit()
    qtbot.waitUntil(lambda: len(wywolania) == 2)


def test_blad_pobierania_i_zamkniecie_podczas_odczytu(qtbot):
    zadania = []

    def uruchom(fn, ok, blad):
        zadania.append((fn, ok, blad))

    class Zrodlo:
        def pobierz_obraz(self, url):
            return ZdjecieDane(url, png(), png())

    e = EdytorOpisu(oferta(), zdjecia=PodgladZdjec(Zrodlo()), uruchom=uruchom)
    qtbot.addWidget(e)
    e.show()
    qtbot.waitUntil(lambda: bool(zadania))
    zadania[0][2]("MEDIA", "Brak sieci")
    assert "Nie udało" in e.findChild(ObrazPodgladu).text()
    assert not e.zmieniony
    f = EdytorOpisu(replace(oferta(), zdjecia=()), zdjecia=PodgladZdjec(Zrodlo()), uruchom=uruchom)
    f.show()
    qtbot.waitUntil(lambda: len(zadania) == 2)
    f.deleteLater()
    qtbot.wait(10)
    zadania[1][1](ZdjecieDane("url", png(), png()))


def test_podglad_paczki_pokazuje_zdjecia_w_galerii_i_sekcjach(qtbot):
    from PySide6.QtWidgets import QPlainTextEdit, QWidget

    from vexlab.gui.paczki_ofert import SzczegolyPaczki

    parent = QWidget()
    qtbot.addWidget(parent)
    wywolania = []
    dane = png()

    class Zrodlo:
        def pobierz_obraz(self, url):
            wywolania.append(url)
            return ZdjecieDane(url, dane, dane)

    def uruchom(fn, ok, blad):
        ok(fn())

    d = SzczegolyPaczki(oferta(), parent, PodgladZdjec(Zrodlo()), uruchom)
    d.show()
    qtbot.waitUntil(lambda: len(wywolania) == 1 and not d.obrazy.trwa)
    obrazy = d.findChildren(ObrazPodgladu)
    assert len(obrazy) == 6 and all(not img.obraz.isNull() for img in obrazy)
    assert d.tabs.currentWidget() is d.pelna_oferta
    assert "Opis sekcji" in d.pelna_oferta.findChild(TekstSekcji).toPlainText()
    sekcje = next(i for i in range(d.tabs.count()) if d.tabs.tabText(i) == "Układ sekcji")
    d.tabs.setCurrentIndex(sekcje)
    assert "Opis sekcji" in d.tabs.widget(sekcje).findChild(TekstSekcji).toPlainText()
    assert not any(
        "https://" in p.toPlainText() for p in d.tabs.widget(1).findChildren(QPlainTextEdit)
    )
    assert oferta().sekcje[0][0].adres == "https://example.test/a.png"
    d.reject()
    assert not d.obrazy.aktywne


def test_podglad_paczki_blad_i_zamkniecie_przed_wynikiem(qtbot):
    from PySide6.QtWidgets import QWidget

    from vexlab.gui.paczki_ofert import SzczegolyPaczki

    parent = QWidget()
    qtbot.addWidget(parent)
    zadania = []

    def uruchom(fn, ok, blad):
        zadania.append((fn, ok, blad))

    class Zrodlo:
        def pobierz_obraz(self, url):
            return ZdjecieDane(url, png(), png())

    serwis = PodgladZdjec(Zrodlo())
    d = SzczegolyPaczki(oferta(), parent, serwis, uruchom)
    d.show()
    qtbot.waitUntil(lambda: len(zadania) == 1)
    zadania[0][2]("MEDIA", "Brak sieci")
    assert all("Nie udało" in img.text() for img in d.findChildren(ObrazPodgladu))
    d.reject()
    e = SzczegolyPaczki(oferta(), parent, serwis, uruchom)
    e.show()
    qtbot.waitUntil(lambda: len(zadania) == 2)
    e.reject()
    e.deleteLater()
    qtbot.wait(10)
    zadania[1][1](ZdjecieDane("https://example.test/a.png", png(), png()))


def test_tabela_przechowuje_miniature_zamiast_pelnego_obrazu(qtbot):
    from PySide6.QtWidgets import QWidget

    from vexlab.gui.podglad_oferty import ObrazyOferty

    mini = png()

    class Zrodlo:
        def pobierz_obraz(self, url):
            return ZdjecieDane(url, b"pelne-dane-nie-sa-ladowane-przez-tabele", mini)

    parent = QWidget()
    qtbot.addWidget(parent)
    manager = ObrazyOferty(
        parent, PodgladZdjec(Zrodlo()), lambda fn, ok, blad: ok(fn()), miniatury=True
    )
    label = manager.obraz("https://example.test/mini.png")
    qtbot.waitUntil(lambda: not label.obraz.isNull())
    assert label.obraz.width() == 100 and label.obraz.height() == 50
    assert manager.cache["https://example.test/mini.png"] == mini
    manager.zamknij()


def test_kwadratowe_miniatury_maja_staly_rozmiar_i_zachowuja_proporcje(qtbot):
    for szerokosc, wysokosc in ((240, 60), (60, 240)):
        image = QImage(szerokosc, wysokosc, QImage.Format.Format_RGB32)
        image.fill(Qt.GlobalColor.blue)
        out = QBuffer()
        out.open(QIODevice.OpenModeFlag.WriteOnly)
        assert image.save(out, "PNG")
        label = ObrazPodgladu("", kwadratowy=True)
        qtbot.addWidget(label)
        label.ustaw(bytes(out.data()))
        label.show()
        assert label.width() == label.height() == 64
        pixmap = label.pixmap()
        assert max(pixmap.width(), pixmap.height()) == 56
        assert pixmap.width() * wysokosc == pixmap.height() * szerokosc


def test_cala_oferta_domyslnie_zawiera_caly_opis_galerie_i_metadane(qtbot):
    from PySide6.QtWidgets import QLabel, QWidget

    from vexlab.gui.paczki_ofert import SzczegolyPaczki

    parent = QWidget()
    qtbot.addWidget(parent)
    d = oferta()
    dialog = SzczegolyPaczki(d, parent)
    dialog.resize(1000, 750)
    dialog.show()
    assert dialog.tabs.currentIndex() == 0 and dialog.tabs.tabText(0) == "Cała oferta"
    assert dialog.tabs.currentWidget() is dialog.pelna_oferta
    assert "Opis sekcji" in dialog.pelna_oferta.findChild(TekstSekcji).toPlainText()
    assert any(
        "Cena z paczki" in label.text() for label in dialog.pelna_oferta.findChildren(QLabel)
    )
    assert len(dialog.pelna_oferta.findChildren(ObrazPodgladu)) == 3
    assert dialog.windowFlags() & Qt.WindowType.WindowMaximizeButtonHint
    assert d == oferta()
    dialog.reject()


def test_brak_sekcji_pokazuje_pelny_tekst_html_bez_zasobow(qtbot):
    from PySide6.QtWidgets import QWidget

    from vexlab.gui.paczki_ofert import SzczegolyPaczki

    parent = QWidget()
    qtbot.addWidget(parent)
    d = SzczegolyPaczki(
        replace(
            oferta(),
            sekcje=(),
            opis='<h2>Cały opis</h2><p>Koniec opisu</p><script>ukryte</script><img src="file:///etc/passwd">',
        ),
        parent,
    )
    d.show()
    text = d.pelna_oferta.findChild(TekstSekcji).toPlainText()
    assert "Cały opis" in text and "Koniec opisu" in text and "ukryte" not in text
    d.reject()


def test_dlugi_tytul_i_opis_mieszcza_sie_w_przewijanej_stronie_w_obu_motywach(qtbot, qapp):
    from PySide6.QtWidgets import QLabel, QWidget

    from vexlab.gui.design_system import zastosuj_motyw
    from vexlab.gui.paczki_ofert import SzczegolyPaczki
    from vexlab.przypadki_uzycia.powloka import Motyw

    parent = QWidget()
    qtbot.addWidget(parent)
    dane = replace(
        oferta(),
        tytul="Długi tytuł oferty motocykla " * 8,
        sekcje=(
            (
                ElementPodgladu("obraz", adres=oferta().zdjecia[0]),
                ElementPodgladu(
                    "tekst",
                    "<h2>Pełny opis</h2>"
                    + "<p>Kolejny akapit oferty do przewijania.</p>" * 70
                    + "<p>OSTATNI AKAPIT</p>",
                ),
            ),
        ),
    )
    d = SzczegolyPaczki(dane, parent)
    d.show()
    try:
        for motyw in (Motyw.CIEMNY, Motyw.JASNY):
            zastosuj_motyw(qapp, motyw)
            for szerokosc in (1100, 700):
                d.resize(szerokosc, 700)
                qapp.processEvents()
                scroll = d.pelna_oferta
                title = scroll.widget().layout().itemAt(0).widget()
                assert isinstance(title, QLabel)
                assert title.height() >= title.heightForWidth(title.width())
                assert title.y() >= 0
                text = scroll.findChild(TekstSekcji)
                assert text.height() >= text.document().size().height()
                assert "OSTATNI AKAPIT" in text.toPlainText()
                assert scroll.verticalScrollBar().maximum() > 0
                scroll.verticalScrollBar().setValue(0)
                scroll.setFocus()
                qtbot.keyClick(scroll, Qt.Key.Key_PageDown)
                assert scroll.verticalScrollBar().value() > 0
    finally:
        d.reject()
        zastosuj_motyw(qapp, Motyw.CIEMNY)
