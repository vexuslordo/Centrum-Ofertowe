from pathlib import Path

import pytest
from PySide6.QtGui import QIcon

from vexlab.gui import kafelek_kpi


@pytest.mark.parametrize("wariant", ["produkty", "aktywne", "szkice", "bledy"])
def test_ikona_ma_bialy_symbol_a_nie_samo_kolorowe_tlo(qapp, wariant):
    """Qt SVG Tiny potrafi zaakceptować dokument, ignorując nieobsługiwane elementy."""
    plik = Path(kafelek_kpi.__file__).with_name("zasoby") / "kpi" / f"{wariant}.svg"
    obraz = QIcon(str(plik)).pixmap(56, 56).toImage()
    assert not obraz.isNull()
    biale = 0
    for y in range(obraz.height()):
        for x in range(obraz.width()):
            c = obraz.pixelColor(x, y)
            if c.alpha() > 240 and min(c.red(), c.green(), c.blue()) > 240:
                biale += 1
    assert biale > 30
