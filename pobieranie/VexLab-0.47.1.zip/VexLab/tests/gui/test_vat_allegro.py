from dataclasses import replace

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QWidget

from tests.gui.test_masowa_paczka_allegro import select
from tests.gui.test_nowe_szkice_allegro import panel, wykonaj
from vexlab.gui.vat_allegro import VATAllegro
from vexlab.przypadki_uzycia.vat_allegro import StawkaVAT, UstawieniaVAT


def dialog(qtbot, fixture, ustawienia=None):
    parent = QWidget()
    qtbot.addWidget(parent)
    jobs = []
    d = VATAllegro(
        parent,
        "123",
        2,
        ustawienia,
        lambda: fixture[-1],
        lambda ident: fixture[5].vat,
        lambda *a: jobs.append(a),
        lambda: True,
        konto="konto_testowe",
    )
    d._parent_test = parent
    d.show()
    qtbot.waitUntil(lambda: bool(jobs))
    return d, jobs


def test_okno_przed_get_i_wybor_lub_reczne_stawki_per_kraj(qtbot, vat_fixture):
    d, jobs = dialog(qtbot, vat_fixture)
    assert d.isVisible() and not d.stosuj.isChecked() and d.tabela.rowCount() == 0
    wykonaj(jobs)
    assert d.tabela.rowCount() == 4
    assert not any(item.checkState() == Qt.CheckState.Checked for item, _ in d._wiersze.values())
    pl, plrate = d._wiersze["PL"]
    cz, czrate = d._wiersze["CZ"]
    pl.setCheckState(Qt.CheckState.Checked)
    plrate.setCurrentIndex(plrate.findData("23.00"))
    cz.setCheckState(Qt.CheckState.Checked)
    czrate.setEditText("21,00")
    d.zapisz()
    assert d.wynik == UstawieniaVAT(
        (StawkaVAT("PL", "23.00", "23%"), StawkaVAT("CZ", "21.00")), "GOODS"
    )
    assert "POST" not in vat_fixture[1].calls


def test_blad_odczytu_retry_i_kopia_z_oferty(qtbot, vat_fixture):
    d, jobs = dialog(qtbot, vat_fixture)
    jobs[-1][2]("SIEC", "Brak połączenia")
    assert d.isVisible() and "Brak połączenia" in d.status.text()
    d.odswiez.click()
    wykonaj(jobs)
    d.ident.setText("12345678")
    d.kopiuj.click()
    wykonaj(jobs)
    assert d.stosuj.isChecked()
    d.zapisz()
    assert {r.kraj: r.wartosc for r in d.wynik.stawki} == {"PL": "23.00", "CZ": "21.00"}


def test_niedozwolona_reczna_stawka_nie_zamyka_okna(qtbot, vat_fixture):
    d, jobs = dialog(qtbot, vat_fixture)
    wykonaj(jobs)
    item, box = d._wiersze["PL"]
    item.setCheckState(Qt.CheckState.Checked)
    box.setEditText("99")
    d.zapisz()
    assert d.isVisible() and d.wynik is None and "nie jest dostępna" in d.status.text()


def test_zamkniety_formularz_ignoruje_spoznione_wyniki(qtbot, vat_fixture):
    d, jobs = dialog(qtbot, vat_fixture)
    d.reject()
    wykonaj(jobs)
    assert d._meta is None and not d.isVisible()


def test_vat_aplikowany_tylko_wybranym_wierszom_bez_zmiany_cen(qtbot, vat_fixture, monkeypatch):
    base = vat_fixture[:6]
    o = base[4]
    w, jobs = panel(qtbot, base, (o, replace(o, sku="2", cena="456.78")))
    for i in range(2):
        w.ustawienia[i] = replace(w.ustawienia[i], vat=None)
    w.przygotuj()
    wykonaj(jobs)
    select(w, (0,))

    def edit(d):
        assert not d._busy and not d.isVisible()
        d.pobierz()
        wykonaj(jobs)
        item, box = d._wiersze["CZ"]
        item.setCheckState(Qt.CheckState.Checked)
        box.setEditText("21")
        d.zapisz()
        assert d.wynik is not None
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(VATAllegro, "exec", edit)
    w.ustaw_vat()
    wykonaj(jobs)
    assert w.plany[0].ustawienia.vat.stawki[0].kraj == "CZ"
    assert w.plany[1].ustawienia.vat is None
    assert [p.ustawienia.cena or p.oferta.cena for p in w.plany] == [o.cena, "456.78"]
    assert "POST" not in base[1].calls


def test_zmiana_sesji_blokuje_zastosowanie_vat(qtbot, vat_fixture):
    d, jobs = dialog(qtbot, vat_fixture)
    d._aktualne = lambda: False
    wykonaj(jobs)
    d.zapisz()
    assert d.wynik is None and d.isVisible() and "Sesja konta" in d.status.text()


def test_reczna_stawka_zatwierdzona_enter_nie_staje_sie_pustym_id(qtbot, vat_fixture):
    d, jobs = dialog(qtbot, vat_fixture)
    wykonaj(jobs)
    item, box = d._wiersze["CZ"]
    item.setCheckState(Qt.CheckState.Checked)
    box.setEditText("21,00")
    qtbot.keyClick(box.lineEdit(), Qt.Key.Key_Return)
    if d.wynik is None:
        d.zapisz()
    assert d.wynik.stawki == (StawkaVAT("CZ", "21.00"),)


def test_lista_api_z_null_i_poza_vat_wyswietla_stawki(qtbot, vat_fixture):
    from vexlab.kanaly.vat_allegro import mapuj_vat

    meta = mapuj_vat(
        {
            "subjects": [{"value": None, "label": "Wybierz"}, {"value": "GOODS", "label": "Towar"}],
            "rates": [
                {
                    "countryCode": "PL",
                    "values": [
                        {"value": None, "label": "Wybierz"},
                        {"value": "23.00", "label": "23%"},
                        {
                            "value": "OUT_OF_SCOPE_OF_VAT",
                            "label": "Poza VAT / NP",
                            "exemptionRequired": True,
                        },
                    ],
                }
            ],
            "exemptions": [{"value": None, "label": "Wybierz"}],
        },
        "123",
    )
    d, jobs = dialog(qtbot, (*vat_fixture[:-1], meta))
    wykonaj(jobs)
    assert d.tabela.rowCount() == 1
    item, box = d._wiersze["PL"]
    assert [box.itemText(i) for i in range(box.count())] == [
        "Wybierz stawkę…",
        "23%",
        "Poza VAT / NP",
    ]
    item.setCheckState(Qt.CheckState.Checked)
    box.setCurrentIndex(1)
    d.zapisz()
    assert d.wynik == UstawieniaVAT((StawkaVAT("PL", "23.00", "23%"),), "GOODS")
