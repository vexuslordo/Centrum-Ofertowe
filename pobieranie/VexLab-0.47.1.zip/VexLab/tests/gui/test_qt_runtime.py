from PySide6.QtCore import QTimer, qVersion
from PySide6.QtWidgets import QLabel
from pytestqt.qtbot import QtBot


def test_qt_przetwarza_zdarzenia_i_renderuje_kontrolke(qtbot: QtBot) -> None:
    """Test instalacji Qt, nie implementacja ani odbiór dashboardu UI-REF-01."""
    kontrolka = QLabel("Test środowiska Qt")
    qtbot.addWidget(kontrolka)
    kontrolka.resize(240, 60)
    kontrolka.show()
    QTimer.singleShot(0, lambda: kontrolka.setText("Zdarzenie obsłużone"))
    qtbot.waitUntil(lambda: kontrolka.text() == "Zdarzenie obsłużone")
    assert not kontrolka.grab().isNull()
    assert qVersion() == "6.12.0"
