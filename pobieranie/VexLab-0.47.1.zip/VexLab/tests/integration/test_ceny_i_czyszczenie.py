import sqlite3
from contextlib import closing
from dataclasses import replace
from decimal import Decimal

import pytest

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.domena.cena import CenaSugerowana
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.importowanie import (
    Arkusz,
    CenaImportu,
    ImportujProdukty,
    Komorka,
    Mapowanie,
    MapowanieCeny,
    PlikImportu,
)
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow, ZmianaMasowa
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow
from vexlab.rdzen.kontrakty import BladTechniczny


@pytest.fixture
def uslugi(tmp_path):
    repo = ImportSQLite(tmp_path / "katalog.sqlite3")
    return repo, KatalogProduktow(repo, repo), ImportujProdukty(CzytnikTabel(), repo, repo)


def plik(cena="123.45", problem=""):
    return PlikImportu(
        "cennik.xlsx",
        (
            Arkusz(
                "Arkusz",
                (
                    (1, (Komorka("Nazwa"), Komorka("Kod"), Komorka("Cena"))),
                    (2, (Komorka("Produkt"), Komorka("TEST"), Komorka(cena, problem))),
                ),
            ),
        ),
    )


@pytest.mark.parametrize("waluta", ["GBP", "EUR", "PLN"])
def test_cena_sugerowana_z_waluta_bez_przeliczania_i_w_kopii(uslugi, tmp_path, waluta):
    repo, kat, imp = uslugi
    plan = imp.zaplanuj(plik(), 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, waluta, "netto")), None)
    assert not plan[0].problem
    imp.zatwierdz(plan, frozenset([plan[0].pozycja.id]))
    p = kat.wyszukaj()[0]
    assert p.cena_sugerowana.kwota == "123.45"
    assert p.cena_sugerowana.waluta == waluta
    assert p.cena_sugerowana.rodzaj == "netto"
    assert "cennik.xlsx" in p.cena_sugerowana.zrodlo
    kopia = tmp_path / "kopia.sqlite3"
    kat.utworz_kopie(kopia)
    drugi = ImportSQLite(kopia)
    assert KatalogProduktow(drugi, drugi).wyszukaj() == [p]


@pytest.mark.parametrize("tekst", ["-1", "NaN", "Infinity", "1,234.56", "1.2345678", "nie cena"])
def test_nieprawidlowa_cena_nie_przechodzi(tekst):
    with pytest.raises(ValueError):
        CenaSugerowana.z_tekstu(tekst, "EUR", "netto")


def test_przecinek_i_zero_nie_sa_brakiem_ceny():
    assert CenaSugerowana.z_tekstu("1 234,50", "EUR", "brutto").kwota == Decimal("1234.50")
    assert CenaImportu("0", "GBP", "netto").sprawdz().kwota == 0
    assert CenaImportu("", "GBP", "netto").sprawdz() is None


def test_formuly_ceny_wymagaja_jawnego_wyboru(uslugi):
    _, _, imp = uslugi
    source = plik("830.25", "Formuła w mapowanym polu — wpisz wartość tekstową")
    o = imp.zaplanuj(source, 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "PLN", "brutto")), None)
    assert "Formuła" in o[0].problem
    o = imp.zaplanuj(
        source, 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "PLN", "brutto", True)), None
    )
    assert not o[0].problem
    o = imp.zaplanuj(
        plik("125", "Komórka liczbowa — potwierdź tekst"),
        0,
        Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "GBP", "netto")),
        None,
    )
    assert not o[0].problem


def test_cena_do_poprawy_trwala_i_korekta_atomowa(uslugi):
    repo, kat, imp = uslugi
    o = imp.zaplanuj(
        plik("błąd"), 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "EUR", "brutto")), None
    )
    imp.zatwierdz(o, frozenset())
    p = ImportSQLite(repo.plik).oczekujace()[0]
    assert p.cena == CenaImportu("błąd", "EUR", "brutto")
    imp.popraw(replace(p, cena=CenaImportu("99,50", "EUR", "brutto")))
    p = imp.oczekujace()[0]
    imp.rozstrzygnij(p)
    assert kat.wyszukaj()[0].cena_sugerowana.etykieta == "99,50 EUR brutto"


def test_usuwanie_migawki_tworzace_kopie_i_bez_naruszania_innych_danych(uslugi):
    repo, kat, imp = uslugi
    producent = RejestrProducentow(repo).dodaj(DaneProducenta("Test"))
    o = imp.zaplanuj(
        plik(), 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "EUR", "netto")), producent.id
    )
    imp.zatwierdz(o, frozenset([o[0].pozycja.id]))
    p = kat.wyszukaj()[0]
    inny = kat.dodaj(DaneProduktu("Zachowaj", "INNY"))
    kopia = kat.usun((p,))
    assert kopia.parent.name == "kopie_usuwania"
    assert [x.id for x in kat.wyszukaj()] == [inny.id]
    assert repo.lista_producentow()[0].id == producent.id
    with closing(sqlite3.connect(repo.plik)) as c:
        assert c.execute("SELECT count(*) FROM ceny_sugerowane").fetchone()[0] == 0
        assert c.execute("SELECT count(*) FROM import_powiazania").fetchone()[0] == 0
    stare = ImportSQLite(kopia)
    assert len(KatalogProduktow(stare, stare).wyszukaj()) == 2
    assert KatalogProduktow(stare, stare).wyszukaj("TEST")[0].cena_sugerowana.kwota == "123.45"
    # Zwolnione SKU daje się ponownie zaimportować.
    o = imp.zaplanuj(plik(), 0, Mapowanie(1, 0, 1), None)
    assert not o[0].problem


def test_blad_kopii_blokuje_usuwanie_i_masowe_zmiany(uslugi, monkeypatch):
    repo, kat, _ = uslugi
    p = kat.dodaj(DaneProduktu("A", "A", "Opis"))

    def awaria(*a):
        raise BladTechniczny("Brak miejsca na kopię")

    monkeypatch.setattr(repo, "_kopia_spojna", awaria)
    for fn in (
        lambda: kat.usun((p,)),
        lambda: kat.zmien_masowo((p,), ZmianaMasowa(opis_tryb="wyczysc")),
    ):
        with pytest.raises(BladTechniczny):
            fn()
    assert kat.wyszukaj() == [p]


def test_konflikt_wersji_wycofuje_cale_usuwanie_i_masowa_edycje(uslugi):
    _, kat, _ = uslugi
    a = kat.dodaj(DaneProduktu("A", "A"))
    b = kat.dodaj(DaneProduktu("B", "B"))
    kat.edytuj(b.id, b.wersja, DaneProduktu("B zmieniony", "B"))
    with pytest.raises(BladScenariuszaKatalogu):
        kat.usun((a, b))
    with pytest.raises(BladScenariuszaKatalogu):
        kat.zmien_masowo((a, b), ZmianaMasowa(opis_tryb="zastap", opis="Nowy"))
    assert len(kat.wyszukaj()) == 2
    assert kat.wyszukaj("A")[0].opis == ""


def test_masowa_producent_i_opis_zachowuje_sku_cene_i_reszte(uslugi):
    repo, kat, imp = uslugi
    producent = RejestrProducentow(repo).dodaj(DaneProducenta("Producent"))
    o = imp.zaplanuj(plik(), 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "GBP", "netto")), None)
    imp.zatwierdz(o, frozenset([o[0].pozycja.id]))
    p = kat.wyszukaj()[0]
    kopia = kat.zmien_masowo((p,), ZmianaMasowa(True, producent.id, "dopisz", "Opis polski"))
    nowy = kat.wyszukaj()[0]
    assert kopia.exists()
    assert (nowy.id, nowy.sku, nowy.nazwa, nowy.cena_sugerowana) == (
        p.id,
        p.sku,
        p.nazwa,
        p.cena_sugerowana,
    )
    assert nowy.producent_id == producent.id and nowy.opis == "Opis polski"
    assert nowy.wersja == p.wersja + 1


def test_uzupelnienie_cen_istniejacych_bez_kasowania_i_nadpisania_danych(uslugi):
    repo, kat, imp = uslugi
    produkt = kat.dodaj(DaneProduktu("Moja polska nazwa", "TEST", "Mój opis"))
    o = imp.zaplanuj(plik(), 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "EUR", "netto")), None)
    plan = imp.zaplanuj_uzupelnienie_cen(o)
    assert len(plan.pozycje) == 1
    kopia = imp.uzupelnij_ceny(plan)
    p = kat.wyszukaj()[0]
    assert (p.id, p.nazwa, p.opis, p.sku) == (produkt.id, produkt.nazwa, produkt.opis, produkt.sku)
    assert p.cena_sugerowana.etykieta == "123,45 EUR netto"
    assert kopia.exists()
    with pytest.raises(BladScenariuszaKatalogu):
        imp.uzupelnij_ceny(plan)
    with pytest.raises(BladScenariuszaKatalogu):
        imp.zaplanuj_uzupelnienie_cen(o)
    assert p == kat.wyszukaj()[0]


def test_niejednoznaczne_sku_nie_uzupelnia_ceny(uslugi):
    _, kat, imp = uslugi
    kat.dodaj(DaneProduktu("A", "TEST"))
    source = plik()
    a = source.arkusze[0]
    source = replace(source, arkusze=(replace(a, wiersze=(*a.wiersze, (3, a.wiersze[1][1]))),))
    o = imp.zaplanuj(source, 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "EUR", "netto")), None)
    with pytest.raises(BladScenariuszaKatalogu):
        imp.zaplanuj_uzupelnienie_cen(o)
    assert kat.wyszukaj()[0].cena_sugerowana is None


def test_masowo_dolacza_wlasna_nazwe_z_modelem_do_opisu_bez_zgadywania(uslugi):
    _, kat, _ = uslugi
    a = kat.dodaj(DaneProduktu("Klamka - Honda CRF1000L (2016-2019)", "MOTO", "Honda"))
    b = kat.dodaj(DaneProduktu("Produkt uniwersalny", "UNI"))
    kat.zmien_masowo((a, b), ZmianaMasowa(dolacz_nazwe=True))
    p = kat.wyszukaj("MOTO")[0]
    assert p.opis == "Honda\n\nKlamka - Honda CRF1000L (2016-2019)"
    assert kat.wyszukaj("UNI")[0].opis == "Produkt uniwersalny"
    kat.zmien_masowo(tuple(kat.wyszukaj()), ZmianaMasowa(dolacz_nazwe=True))
    assert kat.wyszukaj("MOTO")[0].opis == p.opis
