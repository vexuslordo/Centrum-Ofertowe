"""Kontrakt zapisu i odzyskiwanie po nieznanym wyniku, bez prawdziwej sieci."""

import json
from dataclasses import replace

import pytest

from vexlab.adaptery.rejestr_zapisow_allegro import RejestrZapisowJSON
from vexlab.kanaly.zapis_szkicu_allegro import ZapisSzkicuAPI
from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    KontoAllegro,
    OdpowiedzAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StatusOfertyAllegro,
    SzczegolySzkicuAllegro,
)
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu
from vexlab.przypadki_uzycia.propozycje_szkicow import PropozycjeSzkicow
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import (
    PrzyjecieZapisu,
    ZapiszSzkicAllegro,
    klucz,
    pola_zapisu,
)


class Czas:
    def teraz(self):
        return 100


@pytest.fixture
def zapis(tmp_path):
    s = SesjaAllegro(KontoAllegro("1", "fixture"), SrodowiskoAllegro.SANDBOX, "sekret-token", 1000)
    d = SzczegolySzkicuAllegro(
        "123",
        "Bazowy tytul szkicu",
        "SKU",
        "10",
        "PLN",
        1,
        "1",
        (),
        ((ElementPodgladu("tekst", "<p>Źródło</p>"),),),
    )
    p = replace(PropozycjeSzkicow.rozpocznij(s, d), tytul="Zmieniony tytul szkicu")

    class API:
        aktualny = d
        calls = 0
        wynik = PrzyjecieZapisu()
        blad = None
        koniec = False

        def szkic(self, sesja, ident):
            assert sesja is s and ident == "123"
            return self.aktualny

        def zmien_szkic(self, sesja, ident, pola):
            self.calls += 1
            assert pola == {"name": p.tytul}
            if self.blad:
                raise self.blad
            self.aktualny = replace(d, tytul=p.tytul)
            return self.wynik

        def operacja_szkicu(self, sesja, ident, operacja):
            assert operacja == "op-123"
            return self.koniec

    api = API()
    rejestr = RejestrZapisowJSON(tmp_path / "rejestr")
    return ZapiszSzkicAllegro(api, rejestr, Czas()), api, rejestr, s, p, d


def test_zapis_weryfikuje_odczyt_i_wysyla_tylko_zmienione_pole(zapis):
    case, api, r, s, p, d = zapis
    assert case.zapisz(s, p).tytul == p.tytul
    assert api.calls == 1 and r.odczytaj(klucz(p)) is None


@pytest.mark.parametrize("zmiana", ["tytul", "sekcje", "status", "konto", "srodowisko", "wygasla"])
def test_konflikt_lub_inny_kontekst_nie_wysyla_patch(zapis, zmiana):
    case, api, r, s, p, d = zapis
    if zmiana == "tytul":
        api.aktualny = replace(d, tytul="Ktoś zmienił tytuł")
    elif zmiana == "sekcje":
        api.aktualny = replace(d, sekcje=())
    elif zmiana == "status":
        api.aktualny = replace(d, status=StatusOfertyAllegro.AKTYWNA)
    elif zmiana == "konto":
        s = replace(s, konto=KontoAllegro("2", "inne"))
    elif zmiana == "srodowisko":
        s = replace(s, srodowisko=SrodowiskoAllegro.PRODUKCJA)
    else:
        s = replace(s, wygasa=1)
    with pytest.raises(BladAllegro):
        case.zapisz(s, p)
    assert api.calls == 0 and r.odczytaj(klucz(p)) is None


def test_timeout_blokuje_ponowienie_takze_po_restarcie_i_odzyskuje_wynik(zapis):
    case, api, r, s, p, d = zapis
    api.blad = BladAllegro("NIEZNANY", "Nieznany wynik")
    with pytest.raises(BladAllegro):
        case.zapisz(s, p)
    nowy = ZapiszSzkicAllegro(api, RejestrZapisowJSON(r.katalog), Czas())
    with pytest.raises(BladAllegro, match="Poprzedni zapis"):
        nowy.zapisz(s, p)
    with pytest.raises(BladAllegro, match="nie potwierdza"):
        nowy.sprawdz(s, p)
    assert api.calls == 1
    api.aktualny = replace(d, tytul=p.tytul)
    assert nowy.sprawdz(s, p).tytul == p.tytul and r.odczytaj(klucz(p)) is None
    assert "sekret-token" not in repr(list(r.katalog.glob("*")))


def test_202_nie_oznacza_sukcesu_i_sprawdzenie_nie_powtarza_patch(zapis):
    case, api, r, s, p, d = zapis
    api.wynik = PrzyjecieZapisu("op-123")
    with pytest.raises(BladAllegro, match="przyjęło"):
        case.zapisz(s, p)
    with pytest.raises(BladAllegro, match="przetwarza"):
        case.sprawdz(s, p)
    api.koniec = True
    assert case.sprawdz(s, p).tytul == p.tytul and api.calls == 1


def test_jednoznaczna_odmowa_zwalnia_blokade(zapis):
    case, api, r, s, p, d = zapis
    api.blad = BladAllegro("ODRZUCONO", "403")
    with pytest.raises(BladAllegro):
        case.zapisz(s, p)
    assert r.odczytaj(klucz(p)) is None


def test_uszkodzony_rejestr_nie_pozwala_ominac_blokady(zapis):
    case, api, r, s, p, d = zapis
    r.katalog.mkdir()
    (r.katalog / (klucz(p) + ".json")).write_bytes(b"{")
    with pytest.raises(BladAllegro, match="rejestru"):
        case.zapisz(s, p)
    assert api.calls == 0


def test_walidacja_tytulu_opisu_i_niezmieniony_html(zapis):
    case, api, r, s, p, d = zapis
    for t in ["Za mało", "x" * 76, "jedensuperdlugitytul"]:
        with pytest.raises(BladAllegro):
            pola_zapisu(replace(p, tytul=t))
    assert pola_zapisu(p) == {"name": p.tytul}
    tekst = ((ElementPodgladu("tekst", "<p>Żółć &amp; <b>tekst</b></p>"),),)
    pola = pola_zapisu(replace(p, tytul=p.tytul_bazowy, sekcje=tekst))
    assert pola == {
        "description": {"sections": [{"items": [{"type": "TEXT", "content": tekst[0][0].tekst}]}]}
    }
    with pytest.raises(BladAllegro, match="bajtów"):
        pola_zapisu(replace(p, sekcje=((ElementPodgladu("tekst", "ą" * 21000),),)))


class Transport:
    def __init__(self, *odpowiedzi):
        self.odpowiedzi = list(odpowiedzi)
        self.calls = []

    def wyslij(self, *args):
        self.calls.append(args)
        r = self.odpowiedzi.pop(0)
        if isinstance(r, Exception):
            raise r
        return r


@pytest.mark.parametrize("status", [400, 401, 403, 404, 409, 422, 429])
def test_mapper_odmowy_bez_tresci_i_sekretow(zapis, status):
    _, _, _, s, p, _ = zapis
    t = Transport(OdpowiedzAllegro(status, b"PRYWATNE"))
    with pytest.raises(BladAllegro) as exc:
        ZapisSzkicuAPI(t).zmien_szkic(s, "123", pola_zapisu(p))
    assert exc.value.kod == "ODRZUCONO" and "PRYWATNE" not in str(exc.value)
    metoda, url, naglowki, dane = t.calls[0]
    assert metoda == "PATCH" and url.endswith("/sale/product-offers/123")
    assert json.loads(dane) == {"name": p.tytul}
    assert naglowki["Content-Type"] == "application/vnd.allegro.public.v1+json"


@pytest.mark.parametrize(
    "location",
    [
        "",
        "https://evil.invalid/123",
        "https://api.allegro.pl/sale/product-offers/123/operations/op-123",
        "/wrong",
    ],
)
def test_202_odrzuca_obce_lub_bledne_location(zapis, location):
    _, _, _, s, p, _ = zapis
    with pytest.raises(BladAllegro) as exc:
        ZapisSzkicuAPI(Transport(OdpowiedzAllegro(202, b"{}", location))).zmien_szkic(
            s, "123", pola_zapisu(p)
        )
    assert exc.value.kod == "NIEZNANY"


def test_202_i_303_konczy_sie_bez_sledzenia_obcego_url(zapis):
    _, _, _, s, p, _ = zapis
    baza = "https://api.allegro.pl.allegrosandbox.pl/sale/product-offers/123"
    t = Transport(
        OdpowiedzAllegro(202, b"{}", baza + "/operations/op-123"),
        OdpowiedzAllegro(202, b"{}"),
        OdpowiedzAllegro(303, b"", baza),
    )
    api = ZapisSzkicuAPI(t)
    assert api.zmien_szkic(s, "123", pola_zapisu(p)).operacja == "op-123"
    assert not api.operacja_szkicu(s, "123", "op-123")
    assert api.operacja_szkicu(s, "123", "op-123")
    assert len(t.calls) == 3 and all(x[1].startswith(baza) for x in t.calls)


@pytest.mark.parametrize(
    "wynik", [OdpowiedzAllegro(500, b"PRYWATNE"), BladAllegro("SIEC", "sekret")]
)
def test_nieznany_wynik_mappera_nie_zacheca_do_ponowienia(zapis, wynik):
    _, _, _, s, p, _ = zapis
    with pytest.raises(BladAllegro) as exc:
        ZapisSzkicuAPI(Transport(wynik)).zmien_szkic(s, "123", pola_zapisu(p))
    assert exc.value.kod == "NIEZNANY" and "sekret" not in str(exc.value)


def test_retry_after_wstrzymuje_kolejne_sprawdzenie(zapis):
    _, _, _, s, p, _ = zapis
    baza = "https://api.allegro.pl.allegrosandbox.pl/sale/product-offers/123"
    t = Transport(OdpowiedzAllegro(202, b"{}", baza + "/operations/op-123", 60))
    api = ZapisSzkicuAPI(t)
    api.zmien_szkic(s, "123", pola_zapisu(p))
    with pytest.raises(BladAllegro, match="Retry-After"):
        api.operacja_szkicu(s, "123", "op-123")
    assert len(t.calls) == 1


@pytest.mark.parametrize("pola", [{"publication": {}}, {"name": "x", "price": 1}, {}])
def test_transport_odrzuca_niedozwolone_pola_przed_siecia(monkeypatch, pola):
    from vexlab.adaptery import allegro_http

    monkeypatch.setattr(allegro_http, "build_opener", lambda *a: pytest.fail("Nie wolno wysłać"))
    with pytest.raises(BladAllegro):
        allegro_http.HTTPSAllegro().wyslij(
            "PATCH", "https://api.allegro.pl/sale/product-offers/123", {}, json.dumps(pola).encode()
        )


def test_sesja_tylko_do_odczytu_nie_wysyla_zapisu(zapis):
    from vexlab.przypadki_uzycia.allegro import AplikacjaAllegro

    case, api, r, s, p, d = zapis
    s = replace(s, aplikacja=AplikacjaAllegro("fixture", "fixture"))
    with pytest.raises(BladAllegro, match="ponownie"):
        case.zapisz(s, p)
    assert api.calls == 0


def test_czesciowy_wynik_200_nie_zwalnia_blokady(zapis):
    case, api, r, s, p, d = zapis
    prawdziwy_patch = api.zmien_szkic

    def czesciowy(*args):
        wynik = prawdziwy_patch(*args)
        api.aktualny = d
        return wynik

    api.zmien_szkic = czesciowy
    with pytest.raises(BladAllegro, match="nie potwierdza"):
        case.zapisz(s, p)
    assert r.odczytaj(klucz(p)) is not None
    with pytest.raises(BladAllegro, match="Poprzedni zapis"):
        case.zapisz(s, p)
    assert api.calls == 1


def test_rownolegle_instancje_nie_wysylaja_dwoch_patch(zapis):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Event

    case, api, r, s, p, d = zapis
    rozpoczal, kontynuuj = Event(), Event()
    odczyty = [0]

    def odczyt(sesja, ident):
        odczyty[0] += 1
        if odczyty[0] == 1:
            rozpoczal.set()
            assert kontynuuj.wait(timeout=5)
            return d
        return api.aktualny

    api.szkic = odczyt
    drugi = ZapiszSzkicAllegro(api, RejestrZapisowJSON(r.katalog), Czas())
    with ThreadPoolExecutor(max_workers=1) as executor:
        pierwszy = executor.submit(case.zapisz, s, p)
        try:
            assert rozpoczal.wait(timeout=5)
            with pytest.raises(BladAllegro):
                drugi.zapisz(s, p)
        finally:
            kontynuuj.set()
        assert pierwszy.result(timeout=5).tytul == p.tytul
    # Również po zwolnieniu rezerwacji świeży GET blokuje starą propozycję.
    with pytest.raises(BladAllegro, match="zmieniła"):
        drugi.zapisz(s, p)
    assert api.calls == 1
