import csv
import json
import shutil
import sqlite3
from contextlib import closing
from dataclasses import asdict, replace
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.importowanie import (
    Arkusz,
    ImportujProdukty,
    Komorka,
    Mapowanie,
    PlikImportu,
    PozycjaImportu,
)
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow, ZmianaMasowa
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.rdzen.kontrakty import BladTechniczny


@pytest.fixture
def uslugi(tmp_path):
    r = CennikiSQLite(tmp_path / "test.sqlite3")
    i = ImportujProdukty(CzytnikTabel(), r, r)
    return BibliotekaCennikow(r, i), KatalogProduktow(r, r), r


def test_csv_cennik_restart_import_i_korekta_ean(uslugi, tmp_path):
    s, kat, r = uslugi
    plik = tmp_path / "test.csv"
    plik.write_text(
        "SKU;Nazwa;EAN\nA;Produkt A;0123456789012\nB;Produkt B;5901234123458\nC;Bez EAN;\n",
        encoding="utf-8",
    )
    oceny = s.importer.zaplanuj(s.importer.odczytaj(plik), 0, Mapowanie(1, 1, 0, ean=2), None)
    assert not oceny[0].problem and "EAN" in oceny[1].problem and not oceny[2].problem
    s.zapisz("Cennik EAN", 2026, "", oceny)
    c = s.lista()[0]
    plik.unlink()
    nowy = BibliotekaCennikow(CennikiSQLite(r.plik), s.importer)
    assert nowy.pozycje(c)[0].pozycja.dane.ean == "0123456789012"
    w = s.dodaj(c, frozenset({0, 1, 2}))
    assert (w.dodane, w.odlozone) == (2, 1)
    assert next(p for p in kat.wyszukaj() if p.sku == "A").ean == "0123456789012"
    p = r.oczekujace()[0]
    assert p.dane.ean == "5901234123458"
    poprawiona = replace(p, dane=replace(p.dane, ean="5901234123457"), powod="")
    s.importer.popraw(poprawiona)
    poprawiona = r.oczekujace()[0]
    s.importer.rozstrzygnij(poprawiona)
    assert next(p for p in kat.wyszukaj() if p.sku == "B").ean == "5901234123457"
    assert r.oczekujace() == ()


def test_edycja_masowa_media_i_eksport_zachowuja_ean(uslugi, tmp_path):
    _, kat, r = uslugi
    p = kat.dodaj(DaneProduktu("Nazwa", "A", ean="0123456789012"))
    p = kat.edytuj(p.id, p.wersja, DaneProduktu("Zmieniona", "A"))
    assert p.ean == "0123456789012"
    kat.zmien_masowo((p,), ZmianaMasowa(opis_tryb="zastap", opis="Nowy opis"))
    p = kat.wyszukaj()[0]
    assert p.ean == "0123456789012"
    zdjecie = ZdjecieDane("https://example.test/a.jpg", b"photo", b"thumb")
    p = kat.edytuj(p.id, p.wersja, DaneProduktu("Nazwa", "A"), (zdjecie,))
    assert kat.wyszukaj()[0].ean == "0123456789012"
    drugi = kat.dodaj(DaneProduktu("Drugi", "B", ean="0123456789012"), (zdjecie,))
    assert drugi.ean == p.ean  # EAN nie jest kluczem SKU ani nie jest unikalny.
    csv_file = tmp_path / "eksport.csv"
    EksportCSV().zapisz(csv_file, tuple(kat.wyszukaj()))
    with csv_file.open(encoding="utf-8-sig", newline="") as file:
        dane = list(csv.reader(file, delimiter=";"))
    assert dane[0][-1] == "EAN" and all(row[-1] == "0123456789012" for row in dane[1:])
    p = kat.wyszukaj()[0]
    kat.edytuj(p.id, p.wersja, DaneProduktu(p.nazwa, p.sku, ean=""))
    assert next(x for x in kat.wyszukaj() if x.id == p.id).ean == ""


@pytest.mark.parametrize(
    "ean,problem,ok",
    [
        ("5901234123457", "Komórka liczbowa — sprawdź", True),
        ("5.901234123457E12", "Komórka liczbowa — sprawdź", False),
        ("5901234123457", "Formuła w mapowanym polu", False),
    ],
)
def test_liczbowe_ean_i_formuly_bez_zgadywania(uslugi, ean, problem, ok):
    s, _, _ = uslugi
    plik = PlikImportu(
        "test.xlsx",
        (
            Arkusz(
                "A",
                (
                    (1, (Komorka("Nazwa"), Komorka("SKU"), Komorka("EAN"))),
                    (2, (Komorka("Produkt"), Komorka("A"), Komorka(ean, problem))),
                ),
            ),
        ),
    )
    wynik = s.importer.zaplanuj(plik, 0, Mapowanie(1, 0, 1, ean=2), None)
    assert bool(wynik[0].problem) != ok
    with pytest.raises(BladScenariuszaKatalogu, match="odrębną kolumnę EAN"):
        s.importer.zaplanuj(plik, 0, Mapowanie(1, 0, 1, ean=1), None)


def test_stary_json_bez_ean_jest_czytelny(uslugi):
    s, kat, r = uslugi
    p = PozycjaImportu(uuid4(), uuid4(), "test.csv", "A", 2, DaneProduktu("Nazwa", "SKU"))
    s.zapisz("Stary", 2025, "", s.importer.ocen((p,)))
    c = s.lista()[0]
    data = asdict(p)
    del data["dane"]["ean"]
    with closing(sqlite3.connect(r.plik)) as conn, conn:
        conn.execute(
            "UPDATE cenniki SET dane_json=? WHERE id=?",
            (json.dumps([data], default=str), str(c.id)),
        )
    assert s.pozycje(c)[0].pozycja.dane.ean is None
    assert s.dodaj(c, frozenset({0})).dodane == 1 and kat.wyszukaj()[0].ean == ""


def test_migracja10_kopia_i_odtworzenie_danych9(tmp_path):
    plik = tmp_path / "test.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_9.sql"
    pid = str(uuid4())
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.executescript(fixture.read_text())
        conn.execute("INSERT INTO produkty VALUES (?,'Stary','SKU','sku','Opis',3,NULL)", (pid,))
    r = CennikiSQLite(plik)
    assert r.wyszukaj("")[0].ean == "" and str(r.wyszukaj("")[0].id) == pid
    (kopia,) = (tmp_path / "kopie_migracji").glob("*.sqlite3")
    with closing(sqlite3.connect(kopia)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 9
        assert "ean" not in [x[1] for x in conn.execute("PRAGMA table_info(produkty)")]
    restore = tmp_path / "restore.sqlite3"
    shutil.copyfile(kopia, restore)
    assert CennikiSQLite(restore).wyszukaj("") == r.wyszukaj("")
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.execute("UPDATE migracje SET suma_sha256='inna' WHERE wersja=10")
    with pytest.raises(BladTechniczny):
        r.wyszukaj("")


@pytest.mark.parametrize("kopia", [False, True])
def test_awaria_migracji_ean_cofa_cala_zmiane(tmp_path, monkeypatch, kopia):
    plik = tmp_path / "test.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_9.sql"
    orig = sqlite3.connect
    with closing(orig(plik)) as conn, conn:
        conn.executescript(fixture.read_text())
    if kopia:
        (tmp_path / "kopie_migracji").write_text("blokada")

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("INSERT INTO migracje VALUES (10"):
                raise sqlite3.OperationalError("awaria")
            return super().execute(sql, parameters)

    if not kopia:
        monkeypatch.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
    with pytest.raises(BladTechniczny):
        CennikiSQLite(plik).wyszukaj("")
    with closing(orig(plik)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 9
        assert "ean" not in [x[1] for x in conn.execute("PRAGMA table_info(produkty)")]
