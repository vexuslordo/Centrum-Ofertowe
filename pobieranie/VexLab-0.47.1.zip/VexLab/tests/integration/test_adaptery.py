from datetime import timedelta
from importlib.metadata import PackageNotFoundError

import pytest

from vexlab.adaptery import srodowisko
from vexlab.rdzen.kontrakty import BladTechniczny


def test_zegar_systemowy_zwraca_utc() -> None:
    assert srodowisko.ZegarSystemowy().teraz().utcoffset() == timedelta(0)


def test_brak_pyside6_zwraca_bezpieczny_blad(monkeypatch: pytest.MonkeyPatch) -> None:
    def brak_pakietu(nazwa: str) -> str:
        raise PackageNotFoundError(nazwa)

    monkeypatch.setattr(srodowisko, "version", brak_pakietu)
    with pytest.raises(BladTechniczny, match="Brak wymaganej instalacji PySide6"):
        srodowisko.CzytnikWersjiSystemowych().odczytaj()
