from dataclasses import replace

import pytest

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import odcisk_zdalny
from vexlab.przypadki_uzycia.sygnatury_allegro import napraw_sygnature
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import PrzyjecieZapisu


def legacy(fixture):
    service, api, repo, s, o, u = fixture
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    key = service.klucz(s, o.sku)
    d = next(iter(api.wyniki.values()))
    d["external"]["id"] = "vexlab-" + key
    r = repo.odczytaj(key)
    repo.zapisz(key, replace(r, tresc=odcisk_zdalny(d)))

    def patch(session, ident, pola):
        api.calls.append("PATCH")
        assert pola == {"external": {"id": o.sku}}
        d["external"] = pola["external"]
        return PrzyjecieZapisu()

    api.zmien_szkic = patch
    return service, api, repo, s, o, p, d


def test_stara_sygnatura_poprawiona_jednym_patch_i_nie_psuje_rejestru(nowe_szkice_fixture):
    service, api, repo, s, o, p, d = legacy(nowe_szkice_fixture)
    assert napraw_sygnature(service, api, s, o.sku).stan == "Sygnatura poprawiona"
    assert d["external"] == {"id": o.sku}
    assert service.sprawdz(s, p).stan == "Utworzono szkic"
    assert napraw_sygnature(service, api, s, o.sku).stan == "Sygnatura poprawiona"
    assert api.calls.count("PATCH") == api.calls.count("POST") == 1
    assert all(
        o.sku not in path.read_text() and s.token not in path.read_text()
        for path in repo.katalog.glob("*.json")
    )


@pytest.mark.parametrize("stan", ["ACTIVE", "inna_sygnatura", "zmiana_tresci", "brak_rejestru"])
def test_nie_zmienia_aktywnych_obcych_i_zmienionych_ofert(nowe_szkice_fixture, stan):
    service, api, repo, s, o, _, d = legacy(nowe_szkice_fixture)
    if stan == "ACTIVE":
        d["publication"]["status"] = "ACTIVE"
    if stan == "inna_sygnatura":
        d["external"]["id"] = "inny"
    if stan == "zmiana_tresci":
        d["name"] = "Zmieniona nazwa po utworzeniu"
    if stan == "brak_rejestru":
        repo.usun(service.klucz(s, o.sku))
        assert napraw_sygnature(service, api, s, o.sku).stan == "Pominięto"
    else:
        with pytest.raises(BladAllegro):
            napraw_sygnature(service, api, s, o.sku)
    assert "PATCH" not in api.calls


@pytest.mark.parametrize("skutek", [False, True])
def test_timeout_nie_ponawia_patch_po_restarcie(nowe_szkice_fixture, skutek):
    service, api, _, s, o, _, d = legacy(nowe_szkice_fixture)

    def patch(*args):
        api.calls.append("PATCH")
        if skutek:
            d["external"] = {"id": o.sku}
        raise BladAllegro("NIEZNANY", "Timeout")

    api.zmien_szkic = patch
    with pytest.raises(BladAllegro):
        napraw_sygnature(service, api, s, o.sku)
    result = napraw_sygnature(service, api, s, o.sku)
    assert result.stan == ("Sygnatura poprawiona" if skutek else "Wynik nieznany")
    assert api.calls.count("PATCH") == 1


def test_202_naprawy_sprawdzany_bez_ponawiania(nowe_szkice_fixture):
    service, api, _, s, o, _, d = legacy(nowe_szkice_fixture)

    def patch(*args):
        api.calls.append("PATCH")
        d["external"] = {"id": o.sku}
        return PrzyjecieZapisu("test-op")

    api.zmien_szkic = patch
    assert napraw_sygnature(service, api, s, o.sku).stan == "Przetwarzanie"
    api.zakonczona = False
    assert napraw_sygnature(service, api, s, o.sku).stan == "Przetwarzanie"
    api.zakonczona = True
    assert napraw_sygnature(service, api, s, o.sku).stan == "Sygnatura poprawiona"
    assert api.calls.count("PATCH") == 1
