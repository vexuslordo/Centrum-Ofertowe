"""Kontrakt 0.20 zastępuje dawny import Produktów z ZIP: zapis tylko szkiców."""

import sqlite3
from dataclasses import replace

from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.szkice import SzkiceOfert


def oferta(sku="NEW", tytul="Gotowa oferta"):
    return OfertaPodglad(
        1,
        sku,
        tytul,
        "<p>Opis &amp; fakty</p><script>Nie wykonuj</script><ul><li>Cecha</li></ul>",
        "123",
        "999",
        "Motocykl w tekście",
        ("https://example.test/a.jpg",),
        (),
        (),
    )


def test_nowe_i_istniejace_sku_nie_zmieniaja_katalogu_i_korekt(tmp_path):
    repo = SzkiceSQLite(tmp_path / "k.sqlite3")
    kat = KatalogProduktow(repo, repo)
    stary = kat.dodaj(DaneProduktu("Zachowaj", "OLD", "Stary opis", ean="5901234123457"))
    s = SzkiceOfert(repo)
    tabele = (
        "produkty",
        "producenci",
        "ceny_sugerowane",
        "zdjecia",
        "dopasowania",
        "importy",
        "import_robocze",
        "import_powiazania",
        "cenniki",
    )

    def snapshot():
        with repo._polaczenie() as c:
            # Nazwy pochodzą wyłącznie ze stałej testu.
            return {t: tuple(tuple(r) for r in c.execute(f"SELECT * FROM {t}")) for t in tabele}

    przed = snapshot()
    plan = s.zaplanuj(
        (oferta("old", "Inny tytuł"), oferta(), replace(oferta(""), problemy=("Brak SKU",))),
        "paczka.zip",
    )
    assert len(plan.pozycje) == 2 and len(plan.bledy) == 1
    assert s.zapisz(plan).zapisane == 2
    assert snapshot() == przed and kat.wyszukaj() == [stary]
    assert all(d.produkt_id is None for d in s.lista())


def test_sql_blokuje_kazdy_zapis_w_kartotekach_a_szkice_dzialaja(tmp_path, monkeypatch):
    repo = SzkiceSQLite(tmp_path / "k.sqlite3")
    s = SzkiceOfert(repo)
    assert s.lista() == ()
    orig = sqlite3.connect
    zapisy = []

    def polacz(*args, **kw):
        conn = orig(*args, **kw)

        def kontrola(akcja, tabela, kolumna, baza, wyzwalacz):
            if akcja in (
                sqlite3.SQLITE_INSERT,
                sqlite3.SQLITE_UPDATE,
                sqlite3.SQLITE_DELETE,
            ) and tabela in {"produkty", "importy", "import_robocze", "import_powiazania"}:
                zapisy.append((akcja, tabela))
                return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK

        conn.set_authorizer(kontrola)
        return conn

    monkeypatch.setattr(sqlite3, "connect", polacz)
    assert s.zapisz(s.zaplanuj((oferta(),), "paczka.zip")).zapisane == 1
    assert not zapisy


def test_wiele_prezentacji_sku_to_szkice_bez_wspolnej_kartoteki(tmp_path):
    repo = SzkiceSQLite(tmp_path / "k.sqlite3")
    s = SzkiceOfert(repo)
    plan = s.zaplanuj((oferta(), oferta("new", "Druga prezentacja")), "paczka.zip")
    assert s.zapisz(plan).zapisane == 2
    assert s.zapisz(plan).pominiete == 2
    assert repo.wyszukaj("") == []
    assert all(d.produkt_id is None and not d.zrodlo_zmienione for d in s.lista())


def test_usuniecie_niezaleznego_produktu_nie_usuwaja_szkicu_o_tym_sku(tmp_path):
    repo = SzkiceSQLite(tmp_path / "k.sqlite3")
    kat = KatalogProduktow(repo, repo)
    s = SzkiceOfert(repo)
    plan = s.zaplanuj((oferta(),), "paczka.zip")
    produkt = kat.dodaj(DaneProduktu("Równoległy katalog", "NEW"))
    s.zapisz(plan)
    przed = s.lista()
    kat.usun((produkt,))
    assert kat.wyszukaj() == [] and s.lista() == przed


def test_html_i_adresy_sa_zachowane_bez_konwersji_na_opis_produktu(tmp_path):
    repo = SzkiceSQLite(tmp_path / "k.sqlite3")
    s = SzkiceOfert(repo)
    o = oferta()
    s.zapisz(s.zaplanuj((o,), "paczka.zip"))
    assert s.lista()[0].oferta == o and repo.wyszukaj("") == []
