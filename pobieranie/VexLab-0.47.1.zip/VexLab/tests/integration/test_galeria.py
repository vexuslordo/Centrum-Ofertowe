import sqlite3
from contextlib import closing
from dataclasses import replace

import pytest
from PySide6.QtCore import QBuffer, QIODevice
from PySide6.QtGui import QImage

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.zdjecia_lokalne import LokalneZdjecia
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.galeria import GaleriaDTO, GaleriaProduktow
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.rdzen.kontrakty import BladTechniczny


@pytest.fixture
def dane(tmp_path):
    repo = KatalogSQLite(tmp_path / "baza.sqlite3")
    kat = KatalogProduktow(repo, repo)
    p = kat.dodaj(DaneProduktu("Produkt", "SKU", "Opis zachowany"))
    pliki = []
    for i, kolor in enumerate((0xFF0000, 0x0000FF)):
        image = QImage(24, 24, QImage.Format.Format_RGB32)
        image.fill(kolor)
        buf = QBuffer()
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        assert image.save(buf, "PNG")
        plik = tmp_path / f"foto{i}.png"
        plik.write_bytes(bytes(buf.data().data()))
        pliki.append(plik)
    serwis = GaleriaProduktow(repo, LokalneZdjecia())
    zdjecia = serwis.wczytaj_pliki(tuple(pliki))
    return repo, kat, p, serwis, zdjecia


def test_kolejnosc_miniatura_czyszczenie_kopia_i_inne_dane(dane):
    repo, kat, p, serwis, zdjecia = dane
    stara = serwis.odczytaj(p.id)
    kopia = serwis.zapisz(replace(stara, zdjecia=zdjecia))
    assert kopia.exists()
    nowa = serwis.odczytaj(p.id)
    assert nowa.wersja == p.wersja + 1 and nowa.zdjecia == zdjecia
    assert kat.odczytaj().produkty[0].miniatura == zdjecia[0].miniatura
    serwis.zapisz(replace(nowa, zdjecia=zdjecia[::-1]))
    assert kat.odczytaj().produkty[0].miniatura == zdjecia[1].miniatura
    kopia = serwis.zapisz(replace(serwis.odczytaj(p.id), zdjecia=()))
    assert serwis.odczytaj(p.id).zdjecia == ()
    produkt = kat.odczytaj().produkty[0]
    assert (produkt.nazwa, produkt.sku, produkt.opis) == (p.nazwa, p.sku, p.opis)
    assert produkt.miniatura is None
    with closing(sqlite3.connect(kopia)) as conn:
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert conn.execute("SELECT count(*) FROM zdjecia").fetchone()[0] == 2
    assert all(str(repo.plik.parent) not in z.zrodlo for z in zdjecia)


def test_konflikt_nie_nadpisuje_zdjec(dane):
    repo, kat, p, serwis, zdjecia = dane
    stara = serwis.odczytaj(p.id)
    serwis.zapisz(replace(stara, zdjecia=zdjecia))
    with pytest.raises(BladScenariuszaKatalogu, match="zmienił"):
        serwis.zapisz(stara)
    assert serwis.odczytaj(p.id).zdjecia == zdjecia


def test_blad_w_srodku_zapisu_wycofuje_cala_galerie(dane):
    repo, kat, p, serwis, zdjecia = dane
    serwis.zapisz(replace(serwis.odczytaj(p.id), zdjecia=zdjecia))
    przed = serwis.odczytaj(p.id)
    with pytest.raises(BladTechniczny):
        serwis.zapisz(replace(przed, zdjecia=(zdjecia[0], replace(zdjecia[1], dane=b""))))
    assert serwis.odczytaj(p.id) == przed


def test_odrzuca_limit_i_brak_pliku(dane, tmp_path):
    repo, kat, p, serwis, zdjecia = dane
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.zapisz(GaleriaDTO(p.id, p.wersja, zdjecia * 3))
    for plik, tresc in (
        (tmp_path / "html.png", b"<html>"),
        (tmp_path / "duzy.png", b"x" * (8 * 1024 * 1024 + 1)),
    ):
        plik.write_bytes(tresc)
        with pytest.raises(BladScenariuszaKatalogu):
            serwis.wczytaj_pliki((plik,))
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.wczytaj_pliki((tmp_path / "brak.png",))
    assert serwis.odczytaj(p.id).zdjecia == ()
