import json
import sqlite3
from contextlib import closing

import pytest
from PySide6.QtCore import QBuffer, QIODevice
from PySide6.QtGui import QImage

from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.zdjecia_shopify import ZdjeciaShopify, adres_https, obraz
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow
from vexlab.rdzen.kontrakty import BladTechniczny


def png():
    img = QImage(16, 16, QImage.Format.Format_RGB32)
    img.fill(0xFF0000)
    buf = QBuffer()
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    assert img.save(buf, "PNG")
    return bytes(buf.data().data())


class Transport:
    def __init__(self, sku="TEST", liczba=1):
        self.sku = sku
        self.liczba = liczba
        self.urls = []

    def odczytaj(self, url, limit):
        self.urls.append(url)
        if "/search/suggest.json?" in url:
            return json.dumps(
                {
                    "resources": {
                        "results": {
                            "products": [{"url": f"/products/test{i}"} for i in range(self.liczba)]
                        }
                    }
                }
            ).encode()
        if url.endswith(".js"):
            return json.dumps(
                {
                    "title": "Produkt testowy",
                    "variants": [{"sku": self.sku}],
                    "images": ["https://cdn.example/image.png"],
                }
            ).encode()
        return png()


def test_wyszukuje_sku_uzytkownika_i_dekoduje_zdjecia_bez_domeny_producenta_w_kodzie():
    t = Transport()
    wynik = ZdjeciaShopify(t).pobierz("https://wlasny-sklep.example", "test")
    assert wynik.sku == "test" and len(wynik.zdjecia) == 1
    assert wynik.strona_produktu == "https://wlasny-sklep.example/products/test0"
    assert t.urls[0].startswith("https://wlasny-sklep.example/search/suggest.json?")
    assert wynik.zdjecia[0].dane.startswith(b"\xff\xd8")
    assert wynik.zdjecia[0].zrodlo == "https://cdn.example/image.png"


@pytest.mark.parametrize("sku,liczba", [("INNY", 1), ("TEST", 2), ("TEST", 0)])
def test_brak_lub_niejednoznacznosc_sku_blokuja_zdjecia(sku, liczba):
    t = Transport(sku, liczba)
    with pytest.raises(BladScenariuszaKatalogu):
        ZdjeciaShopify(t).pobierz("https://shop.example", "TEST")
    assert not any(url.endswith(".png") for url in t.urls)


@pytest.mark.parametrize(
    "url",
    [
        "http://shop.example",
        "file:///tmp/a",
        "https://localhost",
        "https://127.0.0.1/a",
        "https://user:pass@shop.example",
        "https://shop.example:8080",
    ],
)
def test_niebezpieczne_adresy_odrzucone(url):
    with pytest.raises(BladScenariuszaKatalogu):
        adres_https(url)


@pytest.mark.parametrize("dane", [b"<html>not a photo</html>", b"<svg/>", b""])
def test_html_svg_i_puste_nie_sa_zdjeciami(dane):
    with pytest.raises(BladScenariuszaKatalogu):
        obraz(dane, "https://cdn.example/photo")


def test_zapis_produktu_z_mediami_atomowy_kopia_i_zachowanie_bez_nowych_zdjec(tmp_path):
    repo = ImportSQLite(tmp_path / "test.sqlite3")
    kat = KatalogProduktow(repo, repo)
    z = obraz(png(), "https://cdn.example/zdjecie.png")
    p = kat.dodaj(DaneProduktu("Produkt", "TEST"), (z,))
    odczyt = kat.wyszukaj()[0]
    assert odczyt.miniatura == z.miniatura
    kat.edytuj(p.id, p.wersja, DaneProduktu("Zmieniony", "TEST"))
    assert kat.wyszukaj()[0].miniatura == z.miniatura
    kopia = tmp_path / "kopia.sqlite3"
    kat.utworz_kopie(kopia)
    with closing(sqlite3.connect(kopia)) as c:
        assert c.execute("SELECT dane FROM zdjecia").fetchone()[0] == z.dane
    kat.usun(tuple(kat.wyszukaj()))
    assert not repo.miniatury()


def test_blad_mediow_nie_pozostawia_czesciowego_produktu(tmp_path):
    repo = ImportSQLite(tmp_path / "test.sqlite3")
    kat = KatalogProduktow(repo, repo)
    with pytest.raises(BladTechniczny):
        kat.dodaj(
            DaneProduktu("Produkt", "TEST"), (ZdjecieDane("https://cdn.example/x", b"", b""),)
        )
    assert kat.wyszukaj() == []


def test_strona_producenta_jest_dana_trwala_a_nowa_baza_pusta(tmp_path):
    repo = ImportSQLite(tmp_path / "test.sqlite3")
    rejestr = RejestrProducentow(repo)
    assert rejestr.lista() == [] and repo.miniatury() == {}
    p = rejestr.dodaj(DaneProducenta("Własny", strona_www="https://moja-strona.example"))
    drugi = RejestrProducentow(ImportSQLite(repo.plik))
    assert drugi.lista()[0].strona_www == p.strona_www
    nowe = drugi.edytuj(
        p.id, p.wersja, DaneProducenta("Nowa nazwa", strona_www="https://inna.example")
    )
    assert nowe.strona_www == "https://inna.example"
