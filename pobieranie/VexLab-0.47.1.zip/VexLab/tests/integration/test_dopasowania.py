import sqlite3
from contextlib import closing
from dataclasses import replace

import pytest

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.galeria import GaleriaDTO
from vexlab.przypadki_uzycia.katalog import (
    DaneDopasowania,
    DaneProduktu,
    KatalogProduktow,
    ZmianaMasowa,
)
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.rdzen.kontrakty import BladTechniczny

DOPASOWANIA = (
    DaneDopasowania(" Marka A ", "Model X", "2018", "2020"),
    DaneDopasowania("Marka B", "Model Y", "2021", "", "S"),
)


def test_crud_restart_masowa_zdjecia_i_usuwanie_z_kopia(tmp_path):
    plik = tmp_path / "katalog.sqlite3"
    repo = KatalogSQLite(plik)
    kat = KatalogProduktow(repo, repo)
    p = kat.dodaj(DaneProduktu("Nazwa", "SKU", dopasowania=DOPASOWANIA))
    assert p.dopasowania[0].marka == "Marka A" and len(p.dopasowania) == 2
    assert p.dopasowania[1].rok_do is None
    kat = KatalogProduktow(KatalogSQLite(plik), repo)
    assert kat.wyszukaj()[0].dopasowania == p.dopasowania
    kat.zmien_masowo((p,), ZmianaMasowa(opis_tryb="zastap", opis="Nowy opis"))
    nowy = kat.wyszukaj()[0]
    assert nowy.dopasowania == p.dopasowania
    foto = ZdjecieDane("syntetyczne", b"obraz", b"mini")
    nowy = kat.edytuj(p.id, nowy.wersja, DaneProduktu("Po edycji", "SKU"), (foto,))
    assert nowy.dopasowania == p.dopasowania
    repo.zapisz_galerie(GaleriaDTO(nowy.id, nowy.wersja, ()))
    nowy = kat.wyszukaj()[0]
    assert nowy.dopasowania == p.dopasowania
    kopia = kat.usun((nowy,))
    assert kat.wyszukaj() == []
    with closing(sqlite3.connect(kopia)) as c:
        assert c.execute("SELECT count(*) FROM dopasowania").fetchone()[0] == 2
        assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def test_walidacja_nie_zapisuje_czesci_produktu_i_konflikt(tmp_path):
    repo = KatalogSQLite(tmp_path / "k.sqlite3")
    kat = KatalogProduktow(repo, repo)
    p = kat.dodaj(DaneProduktu("Uniwersalny", "SKU"))
    assert p.dopasowania == ()
    for lista in (
        (DaneDopasowania("A", ""),),
        (DaneDopasowania("A", "M", "zle"),),
        (DOPASOWANIA[0], DOPASOWANIA[0]),
    ):
        with pytest.raises(BladScenariuszaKatalogu):
            kat.edytuj(p.id, p.wersja, DaneProduktu("Nie zapisz", "INNY", dopasowania=lista))
        assert kat.wyszukaj()[0] == p
    nowy = kat.edytuj(p.id, p.wersja, DaneProduktu("Zmiana", "SKU", dopasowania=DOPASOWANIA))
    with pytest.raises(BladScenariuszaKatalogu, match="Odśwież"):
        kat.edytuj(p.id, p.wersja, DaneProduktu("Stary odczyt", "SKU", dopasowania=()))
    assert kat.wyszukaj()[0] == nowy
    pusty = kat.edytuj(
        p.id, nowy.wersja, DaneProduktu("Zmiana", "SKU", dopasowania=(DaneDopasowania("", ""),))
    )
    assert pusty.dopasowania == ()


def test_awaria_zapisu_listy_wycofuje_nazwe_i_stare_dopasowania(tmp_path, monkeypatch):
    repo = KatalogSQLite(tmp_path / "k.sqlite3")
    kat = KatalogProduktow(repo, repo)
    p = kat.dodaj(DaneProduktu("Przed", "SKU", dopasowania=DOPASOWANIA))
    orig = repo._zapisz_dopasowania

    def przerwij(conn, produkt):
        orig(conn, replace(produkt, dopasowania=produkt.dopasowania[:1]))
        raise BladTechniczny("Awaria po pierwszym wierszu")

    monkeypatch.setattr(repo, "_zapisz_dopasowania", przerwij)
    with pytest.raises(BladTechniczny):
        kat.edytuj(p.id, p.wersja, DaneProduktu("Po zmianie", "SKU", dopasowania=DOPASOWANIA[::-1]))
    assert kat.wyszukaj()[0] == p
