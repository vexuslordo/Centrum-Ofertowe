import json
import shutil
import sqlite3
from contextlib import closing
from dataclasses import asdict, replace
from pathlib import Path
from uuid import UUID

import pytest

from vexlab.adaptery.szkice_sqlite import SzkiceSQLite, _klucz
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.szkice import SzkiceOfert
from vexlab.rdzen.kontrakty import BladTechniczny

PID = "10000000-0000-0000-0000-000000000001"
SID = "20000000-0000-0000-0000-000000000001"


def baza10(tmp_path):
    plik = tmp_path / "legacy.sqlite3"
    o = OfertaPodglad(
        1,
        "OLD",
        "Oryginalny tytuł",
        "<p>Opis</p>",
        "5901234123457",
        "123.45",
        "Model",
        ("https://example.test/a.jpg",),
        ((ElementPodgladu("tekst", "<p>Treść</p>"),),),
        (),
    )
    with closing(sqlite3.connect(plik)) as c, c:
        c.executescript((Path(__file__).parents[1] / "fixtures/schemat_10.sql").read_text())
        c.execute(
            "INSERT INTO produkty (id,nazwa,sku,sku_klucz,opis,wersja) VALUES (?,?,?,?,?,?)",
            (PID, "Dawny produkt", "OLD", "old", "Zachowaj kartotekę", 3),
        )
        c.execute(
            "INSERT INTO szkice (rowid,id,produkt_id,wersja_produktu,tytul,opis,tresc_json,"
            "zrodlo,klucz,wersja) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (
                42,
                SID,
                PID,
                3,
                "Edytowany tytuł",
                "<p>Edytowany opis</p>",
                json.dumps(asdict(o), ensure_ascii=False),
                "dawna.zip",
                _klucz(o),
                7,
            ),
        )
    return plik, o


def snapshot(plik):
    with closing(sqlite3.connect(plik)) as c:
        return c.execute("PRAGMA user_version").fetchone()[0], c.execute(
            "SELECT rowid,* FROM szkice"
        ).fetchall()


def test_migracja_zachowuje_calosc_szkicu_kartoteke_kolejnosc_i_kopie(tmp_path):
    plik, o = baza10(tmp_path)
    przed = snapshot(plik)
    repo = SzkiceSQLite(plik)
    s = SzkiceOfert(repo)
    (d,) = s.lista()
    assert (
        d.id == UUID(SID) and d.produkt_id == UUID(PID) and d.wersja_produktu == 3 and d.wersja == 7
    )
    assert not d.zrodlo_zmienione
    assert d.oferta.sekcje == o.sekcje and d.oferta.zdjecia == o.zdjecia
    assert d.oferta.tytul == "Edytowany tytuł" and d.oferta.opis == "<p>Edytowany opis</p>"
    assert snapshot(plik) == (11, przed[1])
    (kopia,) = list((tmp_path / "kopie_migracji").glob("*.sqlite3"))
    assert snapshot(kopia) == przed
    with closing(sqlite3.connect(plik)) as c:
        assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert not c.execute("PRAGMA foreign_key_check").fetchall()
        assert c.execute("SELECT 1 FROM sqlite_master WHERE name='szkice_produkt'").fetchone()
    kat = KatalogProduktow(repo, repo)
    p = kat.wyszukaj()[0]
    kat.edytuj(p.id, p.wersja, as_dane(p))
    assert s.lista()[0].zrodlo_zmienione
    assert s.zapisz(s.zaplanuj((o,), "powtorzenie.zip")).pominiete == 1
    s.zapisz(s.zaplanuj((replace(o, tytul="Nowa prezentacja"),), "nowa.zip"))
    assert len(s.lista()) == 2 and any(d.produkt_id is None for d in s.lista())
    assert len(kat.wyszukaj()) == 1
    odtworz = tmp_path / "restore.sqlite3"
    shutil.copyfile(kopia, odtworz)
    assert len(SzkiceSQLite(odtworz).lista()) == 1


def as_dane(p):
    from vexlab.przypadki_uzycia.katalog import DaneProduktu

    return DaneProduktu("Zmieniony katalog", p.sku)


@pytest.mark.parametrize(
    "krok",
    [
        "INSERT INTO szkice_nowe",
        "DROP TABLE szkice",
        "ALTER TABLE szkice_nowe",
        "INSERT INTO migracje VALUES (11",
    ],
)
def test_przerwanie_po_kroku_wycofuje_cala_migracje(tmp_path, monkeypatch, krok):
    plik, _ = baza10(tmp_path)
    przed = snapshot(plik)
    orig = sqlite3.connect

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            wynik = super().execute(sql, parameters)
            if sql.startswith(krok):
                raise sqlite3.OperationalError("Test po kroku migracji")
            return wynik

    with monkeypatch.context() as m:
        m.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
        with pytest.raises(BladTechniczny):
            SzkiceSQLite(plik).lista()
    assert snapshot(plik) == przed
    with closing(orig(plik)) as c:
        assert not c.execute("SELECT 1 FROM sqlite_master WHERE name='szkice_nowe'").fetchall()
        assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    assert len(list((tmp_path / "kopie_migracji").glob("*.sqlite3"))) == 1


def test_awaria_kopii_blokuje_przebudowe(tmp_path):
    plik, _ = baza10(tmp_path)
    przed = snapshot(plik)
    (tmp_path / "kopie_migracji").write_text("Blokada folderu")
    with pytest.raises(BladTechniczny):
        SzkiceSQLite(plik).lista()
    assert snapshot(plik) == przed


@pytest.mark.parametrize(
    "sql",
    [
        "CREATE INDEX moj_indeks ON szkice(tytul)",
        "CREATE TRIGGER moj_trigger AFTER DELETE ON szkice BEGIN SELECT 1; END",
    ],
)
def test_migracja_nie_usuwaja_niestandardowych_obiektow(tmp_path, sql):
    plik, _ = baza10(tmp_path)
    with closing(sqlite3.connect(plik)) as c, c:
        c.execute(sql)
    przed = snapshot(plik)
    with pytest.raises(BladTechniczny, match="Niestandardowe"):
        SzkiceSQLite(plik).lista()
    assert snapshot(plik) == przed


def test_suma_migracji_i_pary_powiazania_sa_chronione(tmp_path):
    plik, _ = baza10(tmp_path)
    assert SzkiceSQLite(plik).lista()
    with closing(sqlite3.connect(plik)) as c, c:
        for pid, wersja in ((None, 1), (PID, None), (PID, 0)):
            with pytest.raises(sqlite3.IntegrityError):
                c.execute(
                    "UPDATE szkice SET produkt_id=?,wersja_produktu=? WHERE id=?",
                    (pid, wersja, SID),
                )
        c.execute("UPDATE migracje SET suma_sha256='inna' WHERE wersja=11")
    with pytest.raises(BladTechniczny, match="schematu"):
        SzkiceSQLite(plik).lista()
