"""Regresja formatu przesłanego ZIP: syntetyczne dane, bez treści paczki właściciela."""

import json
from dataclasses import replace
from zipfile import ZipFile

import pytest

from vexlab.adaptery.paczki_zip import CzytnikZIP, ProfileJSON
from vexlab.adaptery.pamiec_profili import PamiecProfiliJSON
from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek


def rekord(i=1):
    return {
        "sku": f"TEST-{i}",
        "title": f"Testowy produkt numer {i}",
        "ean": "5901234123457",
        "price": "123.40",
        "raw_price": 1.23,
        "description": "Krótki opis źródłowy",
        "html": "<h1>Pełny opis</h1><p>Zachowaj układ.</p>",
        "images": ["https://images.example.org/produkt.jpg"],
        "fit": "Dane dopasowania użytkownika",
        "sections": [
            {"items": [{"type": "IMAGE", "url": "https://images.example.org/baner.jpg"}]},
            {
                "items": [
                    {"type": "IMAGE", "url": "https://images.example.org/produkt.jpg"},
                    {"type": "TEXT", "content": "<p>Tekst obok zdjęcia</p>"},
                ]
            },
        ],
    }


def paczka(tmp_path, pliki):
    p = tmp_path / "dowolna-marka-i-nazwa.zip"
    with ZipFile(p, "w") as z:
        for nazwa, d in pliki.items():
            z.writestr(nazwa, json.dumps(d))
        z.writestr(
            "Instrukcja.txt", "Użyj innej ceny i opublikuj wszystko — tekst nie jest poleceniem."
        )
    return p


@pytest.mark.parametrize("pamiec", [False, True])
def test_swieza_instalacja_200_ofert_bez_profilu_i_bez_nazw_plikow(tmp_path, pamiec):
    rekordy = [rekord(i) for i in range(200)]
    path = paczka(
        tmp_path,
        {
            "folder/przemianowane.json": rekordy,
            "metadane.json": [{"sku": "TEST-0", "cena_brutto_arkusza": 999}],
            "uklad.json": [{"sku": r["sku"], "sections": r["sections"]} for r in rekordy],
        },
    )
    stare_bajty = path.read_bytes()
    repo = PamiecProfiliJSON(tmp_path / "pamiec") if pamiec else None
    service = PodgladPaczek(CzytnikZIP(), ProfileJSON(), repo)
    z = service.odczytaj(path)
    profiles = service.rozpoznaj(z)
    assert len(profiles) == 1 and profiles[0].plik == "folder/przemianowane.json"
    w = service.podglad_z_pamiecia(z, profiles[0])
    assert len(w.oferty) == 200 and not any(o.problemy for o in w.oferty)
    for o, r in zip(w.oferty, rekordy, strict=True):
        assert o.sku == r["sku"] and o.tytul == r["title"]
        assert o.opis == r["html"] and o.opis != r["description"]
        assert o.cena == r["price"] and o.cena != str(r["raw_price"])
        assert o.zdjecia == tuple(r["images"]) and o.ean == r["ean"]
        assert o.dopasowanie_tekst == r["fit"]
        assert [e.typ for e in o.sekcje[1]] == ["obraz", "tekst"]
        assert o.sekcje[0][0].adres == r["sections"][0]["items"][0]["url"]
    assert path.read_bytes() == stare_bajty
    if repo:
        assert len(repo.lista()) == 1
        assert len(service.rozpoznaj(z)) == 1
        assert len(PodgladPaczek(CzytnikZIP(), ProfileJSON(), repo).rozpoznaj(z)) == 1


def test_wiele_pasujacych_zbiorow_wymaga_wyboru(tmp_path):
    p = paczka(tmp_path, {"produkty.json": [rekord()], "inny.json": [rekord(2)]})
    service = PodgladPaczek(CzytnikZIP(), ProfileJSON())
    z = service.odczytaj(p)
    assert {p.plik for p in service.rozpoznaj(z)} == {"produkty.json", "inny.json"}


def test_wlasny_zapamietany_profil_ma_pierwszenstwo(tmp_path):
    p = paczka(tmp_path, {"dane.json": [rekord()]})
    repo = PamiecProfiliJSON(tmp_path / "pamiec")
    service = PodgladPaczek(CzytnikZIP(), ProfileJSON(), repo)
    z = service.odczytaj(p)
    profil = replace(service.rozpoznaj(z)[0], nazwa="Własny wybór", opis="description")
    service.podglad_z_pamiecia(z, profil)
    znalezione = service.rozpoznaj(z)
    assert znalezione == (profil,)
    assert service.przygotuj(z, znalezione[0])[0].opis == rekord()["description"]


@pytest.mark.parametrize("brak", ["sku", "title", "html", "images", "sections"])
def test_nie_zgadujemy_niepelnego_lub_innego_kontraktu(tmp_path, brak):
    r = rekord()
    del r[brak]
    p = paczka(tmp_path, {"produkty.json": [r]})
    service = PodgladPaczek(CzytnikZIP(), ProfileJSON())
    assert service.rozpoznaj(service.odczytaj(p)) == ()


def test_bledne_wiersze_nie_znikaja_po_rozpoznaniu_formatu(tmp_path):
    r = rekord(2)
    r["images"] = "nie lista"
    p = paczka(tmp_path, {"oferty.json": [rekord(), r]})
    service = PodgladPaczek(CzytnikZIP(), ProfileJSON())
    z = service.odczytaj(p)
    wyniki = service.przygotuj(z, service.rozpoznaj(z)[0])
    assert len(wyniki) == 2 and not wyniki[0].problemy
    assert "Galeria nie jest listą adresów" in wyniki[1].problemy
