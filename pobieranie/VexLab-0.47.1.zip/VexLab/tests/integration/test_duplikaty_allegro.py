from dataclasses import replace
from urllib.parse import parse_qs, urlsplit

import pytest

from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.duplikaty_allegro import IstniejacaOferta, SprawdzDuplikatyAllegro


def test_sku_aktywnej_oferty_blokuje_nawet_inny_tytul(nowe_szkice_fixture):
    _, _, _, s, o, _ = nowe_szkice_fixture

    class API:
        def kandydaci_duplikatow(self, s, pole, fraza):
            assert pole == "external.id"
            return (IstniejacaOferta("123", "Starszy tytuł", o.sku, "ACTIVE"),)

    result = SprawdzDuplikatyAllegro(API()).sprawdz(s, (o,))
    assert result[0][0].ident == "123" and result[0][0].status == "ACTIVE"


@pytest.mark.parametrize("ean,znaleziono", [("5901234123457", True), ("INNY", False), ("", True)])
def test_stara_sygnatura_porownanie_tytulu_i_ean(nowe_szkice_fixture, ean, znaleziono):
    _, _, _, s, o, _ = nowe_szkice_fixture
    o = replace(o, ean="5901234123457")

    class API:
        def kandydaci_duplikatow(self, s, pole, fraza):
            return (
                ()
                if pole == "external.id"
                else (IstniejacaOferta("123", o.tytul.upper(), "vexlab-stary", "ENDED"),)
            )

        def ean_duplikatu(self, s, ident):
            return (ean,) if ean else ()

    result = SprawdzDuplikatyAllegro(API()).sprawdz(s, (o,))
    assert bool(result[0]) == znaleziono
    if result[0]:
        assert result[0][0].status == "ENDED"


def test_wyszukiwanie_paginowane_bez_filtra_statusu_i_limitu_50(nowe_szkice_fixture, monkeypatch):
    s = nowe_szkice_fixture[3]
    api = NoweSzkiceAPI(None)
    calls = []

    def get(env, token, url):
        q = parse_qs(urlsplit(url).query)
        calls.append(q)
        offset = int(q["offset"][0])
        return {
            "offers": [
                {
                    "id": str(i + 1),
                    "name": "Test",
                    "external": {"id": "SKU"},
                    "publication": {"status": "ACTIVE" if i < 100 else "INACTIVE"},
                }
                for i in range(offset, min(offset + 100, 101))
            ],
            "totalCount": 101,
        }

    monkeypatch.setattr(api, "_get", get)
    results = api.kandydaci_duplikatow(s, "external.id", "SKU")
    assert len(results) == 101 and results[-1].status == "INACTIVE"
    assert [q["offset"] for q in calls] == [["0"], ["100"]]
    assert all("publication.status" not in q and q["limit"] == ["100"] for q in calls)


@pytest.mark.parametrize(
    "data",
    [
        {"offers": [], "totalCount": 1},
        {"offers": [], "totalCount": 1001},
        {"offers": None, "totalCount": 0},
    ],
)
def test_niepelna_lista_nie_oznacza_braku_duplikatu(nowe_szkice_fixture, monkeypatch, data):
    api = NoweSzkiceAPI(None)
    monkeypatch.setattr(api, "_get", lambda *args: data)
    with pytest.raises(BladAllegro, match="pełnych wyników"):
        api.kandydaci_duplikatow(nowe_szkice_fixture[3], "name", "Produkt")
