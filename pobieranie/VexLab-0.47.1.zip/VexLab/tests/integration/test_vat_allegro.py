import json
from copy import deepcopy
from dataclasses import replace
from urllib.parse import parse_qs, urlsplit

import pytest

from tests.integration.test_nowe_szkice_allegro import Transport, odpowiedz
from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.kanaly.vat_allegro import mapuj_vat
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.vat_allegro import (
    OpcjaVAT,
    StawkaVAT,
    UstawieniaVAT,
    normalizuj_vat,
    pola_vat,
    sprawdz_vat,
)


def test_vat_per_kraj_w_post_get_bez_zmiany_ceny_i_bez_powtorzen(vat_fixture):
    service, api, _, s, o, u, _ = vat_fixture
    p = service.przygotuj(s, o, u)
    assert not p.bledy
    assert service.utworz(s, p, lambda: False).stan == "Utworzono szkic"
    d = api.przeslane
    assert d["taxSettings"] == {
        "rates": [{"countryCode": "PL", "rate": "23.00"}, {"countryCode": "CZ", "rate": "21.00"}],
        "subject": "GOODS",
    }
    assert d["sellingMode"]["price"] == {"amount": o.cena, "currency": u.waluta}
    assert d["external"] == {"id": o.sku} and d["publication"]["status"] == "INACTIVE"
    assert "additionalMarketplaces" not in d
    assert service.utworz(s, p, lambda: False).ident == "12345678"
    assert api.calls.count("POST") == 1


@pytest.mark.parametrize(
    "bad",
    [
        UstawieniaVAT(()),
        UstawieniaVAT((StawkaVAT("PL", "NaN"),), "GOODS"),
        UstawieniaVAT((StawkaVAT("PL", "99"),), "GOODS"),
        UstawieniaVAT((StawkaVAT("DE", "19"),), "GOODS"),
        UstawieniaVAT((StawkaVAT("PL", "23"), StawkaVAT("PL", "23")), "GOODS"),
        UstawieniaVAT((StawkaVAT("PL", "0"),), "GOODS"),
        UstawieniaVAT((StawkaVAT("PL", "23"),), "NIEDOSTEPNY"),
        UstawieniaVAT((StawkaVAT("PL", "23"),), "GOODS", "ZLE"),
    ],
)
def test_bledny_vat_blokuje_wysylke_przed_zdjeciami(vat_fixture, bad):
    service, api, _, s, o, u, _ = vat_fixture
    p = service.przygotuj(s, o, replace(u, vat=bad))
    assert p.bledy
    with pytest.raises(BladAllegro):
        service.utworz(s, p, lambda: False)
    assert "POST" not in api.calls and "zdjecie" not in api.calls


@pytest.mark.parametrize(
    "value,expected", [("23", "23.00"), ("21,00", "21.00"), ("0%", "0.00"), ("100", "100.00")]
)
def test_normalizacja_recznej_stawki(value, expected):
    assert normalizuj_vat(value) == expected


@pytest.mark.parametrize("value", ["-1", "101", "23.123", "Infinity", "1e1", ""])
def test_odrzuca_niepoprawne_stawki(value):
    with pytest.raises(BladAllegro):
        normalizuj_vat(value)


def test_zwolnienie_wymagane_z_metadata_i_jednoznaczny_wybor_zera(vat_fixture):
    meta = vat_fixture[-1]
    u = UstawieniaVAT((StawkaVAT("PL", "0"),), "GOODS", "TEST_EXEMPTION")
    sprawdz_vat(u, meta)
    countries = (("PL", (*dict(meta.kraje)["PL"], OpcjaVAT("0.00", "Zero — test", False))),)
    ambiguous = replace(meta, kraje=countries)
    with pytest.raises(BladAllegro, match="konkretną"):
        sprawdz_vat(u, ambiguous)
    sprawdz_vat(replace(u, stawki=(StawkaVAT("PL", "0", "Zero — test"),), zwolnienie=""), ambiguous)


@pytest.mark.parametrize(
    "bad",
    [
        None,
        {"rates": [{"countryCode": "PL", "rate": "8.00"}], "subject": "GOODS"},
        {
            "rates": [
                {"countryCode": "PL", "rate": "23.00"},
                {"countryCode": "CZ", "rate": "21.00"},
            ],
            "subject": "BAD",
        },
    ],
)
def test_get_niezgodny_vat_nie_jest_sukcesem_i_blokuje_powtorzenie(vat_fixture, bad):
    service, api, _, s, o, u, _ = vat_fixture
    p = service.przygotuj(s, o, u)
    service.utworz(s, p, lambda: False)
    next(iter(api.wyniki.values()))["taxSettings"] = bad
    with pytest.raises(BladAllegro, match="VAT"):
        service.utworz(s, p, lambda: False)
    assert api.calls.count("POST") == 1


def data(meta):
    return {
        "rates": [
            {
                "countryCode": c,
                "values": [
                    {
                        "value": v.wartosc,
                        "label": v.etykieta,
                        "exemptionRequired": v.wymaga_zwolnienia,
                    }
                    for v in values
                ],
            }
            for c, values in meta.kraje
        ],
        "subjects": [{"value": v, "label": label} for v, label in meta.przedmioty],
        "exemptions": [{"value": v, "label": label} for v, label in meta.zwolnienia],
    }


def test_api_mapuje_stawki_i_kopiuje_vat_wlasnej_oferty_po_kategorii(vat_fixture):
    _, _, _, s, _, u, meta = vat_fixture
    raw = {
        "category": {"id": "123"},
        "taxSettings": {
            "rates": [{"countryCode": "PL", "rate": "23"}, {"countryCode": "CZ", "rate": "21"}],
            "subject": "GOODS",
            "exemption": None,
        },
    }
    t = Transport(
        odpowiedz(200, data(meta)),
        odpowiedz(200, raw),
        odpowiedz(200, {**raw, "category": {"id": "999"}}),
    )
    api = NoweSzkiceAPI(t)
    assert api.vat_kategorii(s, "123") == meta
    assert api.vat_kategorii(s, "123") == meta and len(t.calls) == 1
    assert parse_qs(urlsplit(t.calls[0][1]).query) == {"category.id": ["123"]}
    assert api.vat_oferty(s, "12345", "123") == u.vat
    with pytest.raises(BladAllegro, match="inną kategorię"):
        api.vat_oferty(s, "12346", "123")
    assert all(call[0] == "GET" for call in t.calls)


def test_pusta_lista_i_bledne_metadane_nie_podstawiaja_domyslnych_stawek():
    assert not mapuj_vat({"rates": []}, "123").kraje
    with pytest.raises(BladAllegro):
        mapuj_vat({"rates": [{"countryCode": "PL", "values": None}]}, "123")


@pytest.mark.parametrize("zmiana", [None, "ACTIVE", "dodatkowe", "stawka", "powtorzony_kraj"])
def test_transport_dopuszcza_vat_ale_nie_publikacje_i_obce_pola(vat_fixture, monkeypatch, zmiana):
    from vexlab.adaptery import allegro_http

    service, api, _, s, o, u, _ = vat_fixture
    service.utworz(s, service.przygotuj(s, o, u), lambda: False)
    d = deepcopy(api.przeslane)
    if zmiana == "ACTIVE":
        d["publication"]["status"] = "ACTIVE"
    if zmiana == "dodatkowe":
        d["taxSettings"]["extra"] = True
    if zmiana == "stawka":
        d["taxSettings"]["rates"][0]["rate"] = "999.00"
    if zmiana == "powtorzony_kraj":
        d["taxSettings"]["rates"].append(d["taxSettings"]["rates"][0])
    calls = []

    def opener(*a):
        calls.append(True)
        raise BladAllegro("TEST", "Transport dopuszczony")

    monkeypatch.setattr(allegro_http, "build_opener", opener)
    with pytest.raises(BladAllegro):
        allegro_http.HTTPSAllegro().wyslij(
            "POST", "https://api.allegro.pl/sale/product-offers", {}, json.dumps(d).encode()
        )
    assert bool(calls) == (zmiana is None)


def test_zmiana_dostepnych_stawek_i_timeout_nie_pozwalaja_ponowic_tworzenia(vat_fixture):
    service, api, _, s, o, u, meta = vat_fixture
    p = service.przygotuj(s, o, u)
    api.vat_kategorii = lambda *a, **kw: replace(meta, kraje=())
    with pytest.raises(BladAllegro, match="zmieniły"):
        service.utworz(s, p, lambda: False)
    assert "POST" not in api.calls and "zdjecie" not in api.calls
    api.vat_kategorii = lambda *a, **kw: meta
    api.awaria = "timeout"
    with pytest.raises(BladAllegro):
        service.utworz(s, p, lambda: False)
    assert service.utworz(s, p, lambda: False).stan == "Wymaga sprawdzenia"
    assert api.calls.count("POST") == 1


def test_kopia_z_oferty_pobiera_stawki_takze_przy_pustych_polach_opcjonalnych(vat_fixture):
    s, meta = vat_fixture[3], vat_fixture[-1]
    raw = {
        "category": {"id": "123"},
        "taxSettings": {
            "rates": [{"countryCode": "PL", "rate": "23.00"}],
            "subject": None,
            "exemption": None,
        },
    }
    api = NoweSzkiceAPI(Transport(odpowiedz(200, raw), odpowiedz(200, data(meta))))
    u = api.vat_oferty(s, "12345", "123")
    assert u.stawki == (StawkaVAT("PL", "23.00"),) and u.przedmiot == ""
    with pytest.raises(BladAllegro, match="rodzaj"):
        sprawdz_vat(u, meta)


def test_odpowiedz_allegro_z_pustymi_wyborami_i_poza_vat():
    # Publiczny przykład Allegro: allegro/allegro-api#7846, struktura public #9011.
    d = {
        "subjects": [{"label": "Towar", "value": "GOODS"}, {"label": "Wybierz", "value": None}],
        "rates": [
            {
                "countryCode": "PL",
                "values": [
                    {"label": "23%", "value": "23.00", "exemptionRequired": False},
                    {
                        "label": "Poza VAT / NP",
                        "value": "OUT_OF_SCOPE_OF_VAT",
                        "exemptionRequired": True,
                    },
                    {"label": "Wybierz", "value": None, "exemptionRequired": False},
                ],
            }
        ],
        "exemptions": [
            {"label": "Procedura marży", "value": "MARGIN_SCHEME"},
            {"label": "Wybierz", "value": None},
        ],
    }
    meta = mapuj_vat(d, "316871")
    assert meta.przedmioty == (("GOODS", "Towar"),)
    assert meta.zwolnienia == (("MARGIN_SCHEME", "Procedura marży"),)
    assert [o.wartosc for o in meta.kraje[0][1]] == ["23.00", "0.00"]
    regular = UstawieniaVAT((StawkaVAT("PL", "23.00", "23%"),), "GOODS")
    sprawdz_vat(regular, meta)
    special = UstawieniaVAT((StawkaVAT("PL", "0.00", "Poza VAT / NP"),), "GOODS", "MARGIN_SCHEME")
    sprawdz_vat(special, meta)
    assert pola_vat(special)["rates"] == [{"countryCode": "PL", "rate": "0.00"}]
    with pytest.raises(BladAllegro, match="zwolnienia"):
        sprawdz_vat(replace(special, zwolnienie=""), meta)


def test_nieznany_symbol_vat_nadal_nie_jest_zamieniany_na_zero():
    with pytest.raises(BladAllegro, match="lista stawek"):
        mapuj_vat(
            {"rates": [{"countryCode": "PL", "values": [{"value": "UNKNOWN", "label": "Inne"}]}]},
            "316871",
        )
