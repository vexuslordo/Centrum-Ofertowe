from zipfile import ZipFile

import pytest

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.format_ceny_xlsx import widoczna_cena
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty, Mapowanie, MapowanieCeny


@pytest.mark.parametrize(
    "raw,fmt,wynik",
    [
        ("830.2450000000002", "0.00", "830.25"),
        ("9.995", "#,##0.00", "10.00"),
        ("830.9", "0", "831"),
        ("1.2345E3", '#,##0.00" zł"', "1234.50"),
        ("1.2", "0.##", "1.2"),
        ("1", "0.00", "1.00"),
        ("1234.5678", "General", None),
    ],
)
def test_format_ceny_odpowiada_wyswietlanej_kwocie(raw, fmt, wynik):
    tekst, problem = widoczna_cena(raw, fmt)
    assert tekst == wynik and not problem


@pytest.mark.parametrize(
    "fmt", ["0%", "0.00E+00", "dd/mm/yyyy", "# ?/?", "0,", "[>=10]0.00", "0.0000000"]
)
def test_niewspierane_formaty_nie_sa_zgadywane(fmt):
    assert widoczna_cena("123.45", fmt)[1]


def test_xlsx_zapisany_wynik_formuly_zaokraglony_jak_w_arkuszu(tmp_path):
    plik = tmp_path / "test.xlsx"
    ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    with ZipFile(plik, "w") as z:
        z.writestr(
            "xl/workbook.xml",
            f'<workbook xmlns="{ns}" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<sheets><sheet name="Cennik" sheetId="1" r:id="r1"/></sheets></workbook>',
        )
        z.writestr(
            "xl/_rels/workbook.xml.rels",
            '<Relationships><Relationship Id="r1" Type="/worksheet" '
            'Target="worksheets/sheet1.xml"/></Relationships>',
        )
        z.writestr(
            "xl/styles.xml",
            f'<styleSheet xmlns="{ns}"><cellXfs><xf numFmtId="0"/><xf '
            f'numFmtId="2"/></cellXfs></styleSheet>',
        )
        z.writestr(
            "xl/worksheets/sheet1.xml",
            f'<worksheet xmlns="{ns}"><sheetData><row r="1"><c r="A1" '
            f't="inlineStr"><is><t>Nazwa</t></is></c><c r="B1" '
            f't="inlineStr"><is><t>SKU</t></is></c><c r="C1" '
            f't="inlineStr"><is><t>Cena</t></is></c></row><row r="2"><c r="A2" '
            f't="inlineStr"><is><t>Produkt</t></is></c><c r="B2" '
            f't="inlineStr"><is><t>A</t></is></c><c r="C2" '
            f's="1"><f>1/0</f><v>830.2450000000002</v></c></row></sheetData>'
            f"</worksheet>",
        )
    repo = ImportSQLite(tmp_path / "test.sqlite3")
    s = ImportujProdukty(CzytnikTabel(), repo, repo)
    dane = s.odczytaj(plik)
    assert dane.arkusze[0].wiersze[1][1][2].tekst == "830.2450000000002"
    oceny = s.zaplanuj(
        dane, 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "PLN", "brutto", True)), None
    )
    assert oceny[0].pozycja.cena.tekst == "830.25" and not oceny[0].problem
    bez_zgody = s.zaplanuj(
        dane, 0, Mapowanie(1, 0, 1, cena=MapowanieCeny(2, "PLN", "brutto")), None
    )
    assert "Formuła" in bez_zgody[0].problem
