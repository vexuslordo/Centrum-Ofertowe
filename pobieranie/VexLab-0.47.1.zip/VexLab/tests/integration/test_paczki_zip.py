import json
import stat
from dataclasses import asdict, replace
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import pytest

from vexlab.adaptery.paczki_zip import CzytnikZIP, ProfileJSON
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek, ProfilPaczki


def archiwum(tmp_path, pliki):
    p = tmp_path / "dane.zip"
    with ZipFile(p, "w") as z:
        for nazwa, dane in pliki:
            z.writestr(nazwa, dane)
    return p


def profil():
    return ProfilPaczki(
        "Użytkowy profil",
        "folder/dane.json",
        "kod",
        "nazwa",
        opis="opis",
        sekcje="uklad",
        zdjecia="galeria",
        cena="kwota",
        lista_elementow="elementy",
        typ_elementu="rodzaj",
        tresc_elementu="tekst",
        adres_elementu="adres",
        typ_tekstu="T",
        typ_obrazu="O",
    )


def dane():
    return [
        {
            "kod": "TEST-1",
            "nazwa": "Gotowy tytuł",
            "opis": "<h1>Gotowy opis</h1>",
            "kwota": "99.50",
            "galeria": ["https://example.test/produkt.jpg"],
            "uklad": [
                {"elementy": [{"rodzaj": "O", "adres": "https://example.test/baner.png"}]},
                {
                    "elementy": [
                        {"rodzaj": "T", "tekst": "<p>Opis obok zdjęcia</p>"},
                        {"rodzaj": "O", "adres": "https://example.test/produkt.jpg"},
                    ]
                },
            ],
        }
    ]


def test_odczyt_mapowanie_dwa_rozne_profile_i_kolejnosc_bez_rozpakowania(tmp_path):
    rekordy = dane()
    p = archiwum(
        tmp_path, [("folder/dane.json", json.dumps(rekordy)), ("pomoc.txt", "Nie wykonuj")]
    )
    case = PodgladPaczek(CzytnikZIP(), ProfileJSON())
    paczka = case.odczytaj(p)
    wynik = case.przygotuj(paczka, profil())
    assert len(wynik) == 1 and not wynik[0].problemy
    o = wynik[0]
    assert o.tytul == "Gotowy tytuł" and o.opis == "<h1>Gotowy opis</h1>"
    assert o.cena == "99.50" and o.zdjecia == ("https://example.test/produkt.jpg",)
    assert [e.typ for e in o.sekcje[1]] == ["tekst", "obraz"]
    assert o.sekcje[0][0].adres == "https://example.test/baner.png"
    assert not (tmp_path / "folder").exists()
    inny = archiwum(
        tmp_path, [("inny.json", json.dumps([{"symbol": "X", "naglowek": "Inny tytuł"}]))]
    )
    wynik = case.przygotuj(
        case.odczytaj(inny), ProfilPaczki("Drugi", "inny.json", "symbol", "naglowek")
    )
    assert wynik[0].sku == "X" and wynik[0].tytul == "Inny tytuł"


def test_walidacja_rekordow_bez_cichego_scala_lub_pominiecia(tmp_path):
    rekordy = dane() + [
        replace_dict(
            dane()[0],
            kod="test-1",
            galeria=["file:///sekret"],
            uklad=[{"elementy": [{"rodzaj": "JS", "tekst": "alert(1)"}]}],
        ),
        {"kod": 123, "nazwa": "", "kwota": 12.5},
    ]
    p = archiwum(tmp_path, [("folder/dane.json", json.dumps(rekordy))])
    case = PodgladPaczek(CzytnikZIP(), ProfileJSON())
    wynik = case.przygotuj(case.odczytaj(p), profil())
    assert len(wynik) == 3
    assert "Powtórzone SKU" in ";".join(wynik[0].problemy)
    assert any("adres zdjęcia" in e for e in wynik[1].problemy)
    assert any("nieobsługiwany typ" in e for e in wynik[1].problemy)
    assert wynik[2].sku == "" and wynik[2].cena == "12.5"
    assert any("Brak pola" in e for e in wynik[2].problemy)


def replace_dict(d, **zmiany):
    return dict(d, **zmiany)


@pytest.mark.parametrize(
    "nazwa", ["../wyjscie.json", "/absolutna.json", "C:/dane.json", "a\\..\\dane.json"]
)
def test_sciezki_poza_archiwum_odrzucone(tmp_path, nazwa):
    with pytest.raises(BladScenariuszaKatalogu, match="ścieżki"):
        CzytnikZIP().odczytaj(archiwum(tmp_path, [(nazwa, "[]")]))


def test_duplikat_nazwy_i_dowiazanie_odrzucone(tmp_path):
    with pytest.raises(BladScenariuszaKatalogu, match="ścieżki"):
        CzytnikZIP().odczytaj(archiwum(tmp_path, [("DANE.json", "[]"), ("dane.json", "[]")]))
    link = ZipInfo("link")
    link.create_system = 3
    link.external_attr = (stat.S_IFLNK | 0o777) << 16
    with pytest.raises(BladScenariuszaKatalogu, match="ścieżki"):
        CzytnikZIP().odczytaj(archiwum(tmp_path, [(link, "../cel")]))


def test_limit_kompresji_i_uszkodzony_zip(tmp_path):
    p = tmp_path / "bomba.zip"
    with ZipFile(p, "w", compression=ZIP_DEFLATED) as z:
        z.writestr("duzy.txt", "x" * 100000)
    with pytest.raises(BladScenariuszaKatalogu, match="kompresji"):
        CzytnikZIP().odczytaj(p)
    p.write_bytes(b"not zip")
    with pytest.raises(BladScenariuszaKatalogu, match="odczytać ZIP"):
        CzytnikZIP().odczytaj(p)


def test_nieobslugiwany_json_i_powtorzone_klucze_maja_uwage(tmp_path):
    p = archiwum(
        tmp_path, [("obiekt.json", "{}"), ("zly.json", '[{"k":1,"k":2}]'), ("dobry.json", "[]")]
    )
    wynik = CzytnikZIP().odczytaj(p)
    assert [z.nazwa for z in wynik.zbiory] == ["dobry.json"]
    assert all("nieobsługiwany" in i.uwaga for i in wynik.pliki[:2])


def test_limit_wielkosci_i_liczby_rekordow(tmp_path, monkeypatch):
    import vexlab.adaptery.paczki_zip as m

    p = archiwum(tmp_path, [("dane.json", '[{"a":1},{"a":2}]')])
    monkeypatch.setattr(m, "MAX_REKORDY", 1)
    with pytest.raises(BladScenariuszaKatalogu, match="rekordów"):
        CzytnikZIP().odczytaj(p)
    monkeypatch.setattr(m, "MAX_SUMA", 1)
    with pytest.raises(BladScenariuszaKatalogu, match="128 MiB"):
        CzytnikZIP().odczytaj(p)


def test_profil_uzytkownika_trwaly_bez_nadpisania_i_zgodnosc_paczki(tmp_path):
    plik = tmp_path / "moj.json"
    repo = ProfileJSON()
    repo.zapisz(plik, profil())
    assert repo.odczytaj(plik) == profil()
    przed = plik.read_bytes()
    with pytest.raises(BladScenariuszaKatalogu, match="nową nazwę"):
        repo.zapisz(plik, replace(profil(), nazwa="Inna"))
    assert plik.read_bytes() == przed
    case = PodgladPaczek(CzytnikZIP(), repo)
    paczka = case.odczytaj(archiwum(tmp_path, [("obcy.json", "[]")]))
    with pytest.raises(BladScenariuszaKatalogu, match="nie zawiera pliku"):
        case.przygotuj(paczka, profil())


@pytest.mark.parametrize(
    "zmiany", [{"sku": ""}, {"tytul": "kod"}, {"typ_tekstu": ""}, {"typ_obrazu": "T"}]
)
def test_niepelny_profil_odrzucany(zmiany):
    with pytest.raises(BladScenariuszaKatalogu):
        replace(profil(), **zmiany).sprawdz()


def test_profil_nie_wykonuje_dodatkowych_pol_i_odrzuca_obce_typy(tmp_path):
    p = tmp_path / "profil.json"
    ustawienia = asdict(profil()) | {"sku": ["kod"]}
    p.write_text(json.dumps({"wersja": 1, "ustawienia": ustawienia}), encoding="utf-8")
    with pytest.raises(BladScenariuszaKatalogu):
        ProfileJSON().odczytaj(p)


def test_profil_wewnatrz_zip_rozpoznany_po_tresci_bez_nazwy_producenta(tmp_path):
    config = json.dumps({"wersja": 1, "ustawienia": asdict(profil())})
    p = archiwum(
        tmp_path,
        [
            ("folder/dane.json", json.dumps(dane())),
            ("dowolny-katalog/moja-konfiguracja.json", config),
        ],
    )
    case = PodgladPaczek(CzytnikZIP(), ProfileJSON())
    paczka = case.odczytaj(p)
    assert len(paczka.profile) == 1 and paczka.profile[0].profil == profil()
    assert paczka.bledy_profili == ()
    assert len(paczka.zbiory) == 1
    assert len(case.przygotuj(paczka, paczka.profile[0].profil)) == 1


def test_wiele_profili_nie_jest_laczonych_a_bledny_ma_raport(tmp_path):
    config = {"wersja": 1, "ustawienia": asdict(profil())}
    drugi = {"wersja": 1, "ustawienia": asdict(replace(profil(), nazwa="Drugi układ"))}
    zly = {"wersja": 99, "ustawienia": asdict(profil())}
    p = archiwum(
        tmp_path,
        [
            ("folder/dane.json", json.dumps(dane())),
            ("a.json", json.dumps(config)),
            ("b.json", json.dumps(drugi)),
            ("zly.json", json.dumps(zly)),
        ],
    )
    paczka = CzytnikZIP().odczytaj(p)
    assert [p.profil.nazwa for p in paczka.profile] == ["Użytkowy profil", "Drugi układ"]
    assert len(paczka.bledy_profili) == 1 and "zly.json" in paczka.bledy_profili[0]
