import sqlite3
from contextlib import closing
from dataclasses import replace

import pytest

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.importowanie import (
    Arkusz,
    ImportujProdukty,
    Komorka,
    Mapowanie,
    MapowanieMotocykla,
    PlikImportu,
)
from vexlab.przypadki_uzycia.katalog import DaneDopasowania, DaneProduktu, KatalogProduktow
from vexlab.rdzen.kontrakty import BladTechniczny


@pytest.fixture
def serwis(tmp_path):
    repo = ImportSQLite(tmp_path / "katalog.sqlite3")
    return ImportujProdukty(CzytnikTabel(), repo, repo)


def plik(serwis, tmp_path):
    p = tmp_path / "dane.csv"
    p.write_text(
        "Nazwa;SKU;Marka;Model;Od;Do;Wariant\n"
        "Część;A;Marka A;Model X;2018;2020;S\nInna;B;Marka B;;zły;;\nUniwersalny;U;;;;;\n",
        encoding="utf-8",
    )
    return serwis.odczytaj(p)


MAPA = Mapowanie(1, 0, 1, motocykl=MapowanieMotocykla(2, 3, 4, 5, 6))


def test_csv_podglad_paczka_restart_szkic_i_wiele_poprawionych_dopasowan(serwis, tmp_path):
    oceny = serwis.zaplanuj(plik(serwis, tmp_path), 0, MAPA, None)
    assert [bool(o.problem) for o in oceny] == [False, True, False]
    assert serwis.katalog.wyszukaj("") == []
    raport = serwis.zatwierdz(oceny, frozenset(o.pozycja.id for o in oceny if not o.problem))
    assert (raport.dodane, raport.odlozone) == (2, 1)
    kat = KatalogProduktow(serwis.katalog, serwis.katalog)
    assert kat.wyszukaj("A")[0].dopasowania[0].rok_do == 2020
    assert kat.wyszukaj("U")[0].dopasowania == ()
    repo = ImportSQLite(serwis.magazyn.plik)
    drugi = ImportujProdukty(CzytnikTabel(), repo, repo)
    p = drugi.oczekujace()[0]
    assert p.dane.dopasowania[0].rok_od == "zły" and p.dane.dopasowania[0].model == ""
    nowa = replace(
        p,
        dane=replace(
            p.dane,
            dopasowania=(
                DaneDopasowania("Marka B", "Model Y", "2021"),
                DaneDopasowania("Marka C", "Model Z"),
            ),
        ),
    )
    drugi.popraw(nowa)
    p = drugi.oczekujace()[0]
    assert len(p.dane.dopasowania) == 2
    drugi.rozstrzygnij(p)
    assert drugi.oczekujace() == ()
    assert len(kat.wyszukaj("B")[0].dopasowania) == 2


@pytest.mark.parametrize(
    "moto",
    [
        MapowanieMotocykla(2, 2),
        MapowanieMotocykla(0, 3),
        MapowanieMotocykla(-1, 3),
        MapowanieMotocykla(2, 99),
    ],
)
def test_niepoprawne_mapowanie_nie_tworz_paczki(serwis, tmp_path, moto):
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.zaplanuj(plik(serwis, tmp_path), 0, replace(MAPA, motocykl=moto), None)
    assert serwis.oczekujace() == ()


def test_wylaczone_dopasowania_nie_odgaduja_ich_z_nazwy(serwis, tmp_path):
    oceny = serwis.zaplanuj(plik(serwis, tmp_path), 0, Mapowanie(1, 0, 1), None)
    assert not any(o.problem for o in oceny)
    assert all(o.pozycja.dane.dopasowania is None for o in oceny)


@pytest.mark.parametrize(
    "problem,kolumna,blad",
    [
        ("Komórka liczbowa — potwierdź tekst", 4, False),
        ("Formuła w mapowanym polu", 4, True),
        ("Komórka liczbowa — potwierdź tekst", 2, True),
    ],
)
def test_rocznik_liczbowy_dozwolony_ale_formula_i_liczbowa_marka_nie(
    serwis, problem, kolumna, blad
):
    naglowki = tuple(Komorka(x) for x in ("Nazwa", "SKU", "Marka", "Model", "Od"))
    pola = [Komorka(x) for x in ("Część", "TEST", "Marka A", "Model X", "2020")]
    pola[kolumna] = replace(pola[kolumna], problem=problem)
    p = PlikImportu("syntetyczny.xlsx", (Arkusz("A", ((1, naglowki), (2, tuple(pola)))),))
    ocena = serwis.zaplanuj(p, 0, Mapowanie(1, 0, 1, motocykl=MapowanieMotocykla(2, 3, 4)), None)[0]
    assert bool(ocena.problem) is blad


def test_powiazanie_z_istniejacym_sku_nie_nadpisuje_dopasowan(serwis, tmp_path):
    kat = KatalogProduktow(serwis.katalog, serwis.katalog)
    p = kat.dodaj(
        DaneProduktu("Zachowaj", "A", dopasowania=(DaneDopasowania("Moja", "Mój model"),))
    )
    oceny = serwis.zaplanuj(plik(serwis, tmp_path), 0, MAPA, None)
    serwis.zatwierdz(oceny, frozenset())
    roboczy = next(x for x in serwis.oczekujace() if x.dane.sku == "A")
    serwis.rozstrzygnij(roboczy, p.id)
    assert kat.wyszukaj("Zachowaj")[0] == p


def test_awaria_listy_w_paczce_nie_zostawia_produktow_i_czesci_dopasowan(
    serwis, tmp_path, monkeypatch
):
    oceny = serwis.zaplanuj(plik(serwis, tmp_path), 0, MAPA, None)
    orig = serwis.magazyn._dodaj_importowany

    def awaria(conn, p):
        orig(conn, p)
        raise BladTechniczny("Awaria po zapisie produktu i dopasowania")

    monkeypatch.setattr(serwis.magazyn, "_dodaj_importowany", awaria)
    with pytest.raises(BladTechniczny):
        serwis.zatwierdz(oceny, frozenset([oceny[0].pozycja.id]))
    assert serwis.katalog.wyszukaj("") == [] and serwis.oczekujace() == ()
    with closing(sqlite3.connect(serwis.magazyn.plik)) as c:
        assert c.execute("SELECT count(*) FROM dopasowania").fetchone()[0] == 0
        assert c.execute("SELECT count(*) FROM importy").fetchone()[0] == 0


def test_uszkodzony_json_bufora_nie_jest_cicho_pominiety(serwis, tmp_path):
    oceny = serwis.zaplanuj(plik(serwis, tmp_path), 0, MAPA, None)
    serwis.zatwierdz(oceny, frozenset())
    with closing(sqlite3.connect(serwis.magazyn.plik)) as c, c:
        c.execute("UPDATE import_robocze SET dopasowania_json='[1]'")
    with pytest.raises(BladTechniczny, match="dopasowań"):
        serwis.oczekujace()
