from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.domena.producent import Producent
from vexlab.domena.produkt import KonfliktEdycji
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow


def aplikacja(tmp_path: Path):
    repo = KatalogSQLite(tmp_path / "katalog.sqlite3")
    return KatalogProduktow(repo, repo), RejestrProducentow(repo), repo


def test_pusta_instalacja_i_trwalosc_producenta(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    assert rejestr.lista() == []
    producent = rejestr.dodaj(DaneProducenta(" Testowy A "))
    assert rejestr.lista() == [producent]
    assert producent.nazwa == "Testowy A"
    assert aplikacja(tmp_path)[1].lista() == [producent]
    assert katalog.wyszukaj() == []


def test_przypisanie_jednego_producenta_i_odpiecie(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    producent = rejestr.dodaj(DaneProducenta("Testowy A"))
    produkt = katalog.dodaj(DaneProduktu("Testowy produkt", "TEST-A", producent_id=producent.id))
    assert produkt.producent_id == producent.id
    assert produkt.producent_nazwa == producent.nazwa
    assert aplikacja(tmp_path)[0].wyszukaj() == [produkt]
    odpięty = katalog.edytuj(produkt.id, produkt.wersja, DaneProduktu(produkt.nazwa, produkt.sku))
    assert odpięty.producent_id is None and odpięty.producent_nazwa is None
    assert rejestr.lista() == [producent]


def test_zmiana_nazwy_widoczna_w_katalogu_bez_zmiany_id_produktu(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    producent = rejestr.dodaj(DaneProducenta("Przed"))
    p = katalog.dodaj(DaneProduktu("Test", "TEST-A", producent_id=producent.id))
    rejestr.edytuj(producent.id, producent.wersja, DaneProducenta("Po"))
    wynik = katalog.wyszukaj()[0]
    assert wynik.id == p.id and wynik.wersja == p.wersja
    assert wynik.producent_id == producent.id
    assert wynik.producent_nazwa == "Po"


def test_dezaktywacja_zachowuje_przypisania_ale_blokuje_nowe(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    producent = rejestr.dodaj(DaneProducenta("Testowy A"))
    produkt = katalog.dodaj(DaneProduktu("Test", "TEST-A", producent_id=producent.id))
    rejestr.edytuj(producent.id, 1, DaneProducenta(producent.nazwa, False))
    assert katalog.wyszukaj()[0].producent_id == producent.id
    zachowany = katalog.edytuj(
        produkt.id, 1, DaneProduktu("Edycja", "TEST-A", producent_id=producent.id)
    )
    assert zachowany.producent_id == producent.id
    with pytest.raises(BladScenariuszaKatalogu) as blad:
        katalog.dodaj(DaneProduktu("Nowy", "TEST-B", producent_id=producent.id))
    assert blad.value.kod == "PRODUCENT_NIEAKTYWNY"
    assert len(katalog.wyszukaj()) == 1


def test_zmiana_na_nieaktywnego_producenta_jest_wycofana(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    a = rejestr.dodaj(DaneProducenta("A"))
    b = rejestr.dodaj(DaneProducenta("B", False))
    p = katalog.dodaj(DaneProduktu("Test", "TEST-A", producent_id=a.id))
    with pytest.raises(BladScenariuszaKatalogu):
        katalog.edytuj(p.id, 1, DaneProduktu("Nie zapisuj", "TEST-A", producent_id=b.id))
    assert katalog.wyszukaj() == [p]


def test_nieistniejacy_producent_nie_tworzy_produktu(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    with pytest.raises(BladScenariuszaKatalogu) as blad:
        katalog.dodaj(DaneProduktu("Test", "TEST-A", producent_id=uuid4()))
    assert blad.value.kod == "PRODUCENT_NIE_ISTNIEJE"
    assert katalog.wyszukaj() == []


def test_nazwy_nie_sa_kluczem_deduplikacji(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    a = rejestr.dodaj(DaneProducenta("Ta sama nazwa"))
    b = rejestr.dodaj(DaneProducenta("Ta sama nazwa"))
    assert a.id != b.id
    assert len(rejestr.lista()) == 2


def test_konflikt_wersji_producenta_nie_nadpisuje_danych(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    a = rejestr.dodaj(DaneProducenta("Przed"))
    nowy = rejestr.edytuj(a.id, 1, DaneProducenta("Po"))
    with pytest.raises(BladScenariuszaKatalogu) as blad:
        rejestr.edytuj(a.id, 1, DaneProducenta("Spóźniona zmiana"))
    assert blad.value.kod == "KONFLIKT_WERSJI"
    assert rejestr.lista() == [nowy]
    with pytest.raises(KonfliktEdycji):
        repo.zapisz_producenta(Producent(a.id, "Inna", True, 2), 1)


def test_pusta_nazwa_odrzucona_przed_utworzeniem_bazy(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    with pytest.raises(BladScenariuszaKatalogu) as blad:
        rejestr.dodaj(DaneProducenta("  "))
    assert blad.value.kod == "WALIDACJA_PRODUCENTA"
    assert not repo.plik.exists()


def test_kopia_zachowuje_producenta_i_powiazanie(tmp_path: Path) -> None:
    katalog, rejestr, repo = aplikacja(tmp_path)
    a = rejestr.dodaj(DaneProducenta("Testowy A"))
    p = katalog.dodaj(DaneProduktu("Test", "TEST-A", producent_id=a.id))
    kopia = tmp_path / "kopia.sqlite3"
    katalog.utworz_kopie(kopia)
    nowy_repo = KatalogSQLite(kopia)
    assert KatalogProduktow(nowy_repo, nowy_repo).wyszukaj() == [p]
    assert RejestrProducentow(nowy_repo).lista() == [a]
