import sqlite3
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.domena.produkt import KonfliktEdycji, Produkt, SKUJuzIstnieje
from vexlab.przypadki_uzycia.katalog import (
    BladScenariuszaKatalogu,
    DaneProduktu,
    KatalogProduktow,
)
from vexlab.rdzen.kontrakty import BladTechniczny


def katalog(tmp_path: Path) -> KatalogProduktow:
    repo = KatalogSQLite(tmp_path / "dane" / "katalog.sqlite3")
    return KatalogProduktow(repo, repo)


def test_pusta_instalacja_i_trwalosc_po_ponownym_otwarciu(tmp_path: Path) -> None:
    app = katalog(tmp_path)
    assert app.wyszukaj() == []
    zapisany = app.dodaj(DaneProduktu("Produkt testowy", "TEST-A", "Opis"))
    assert katalog(tmp_path).wyszukaj() == [zapisany]


def test_duplikat_sku_nie_tworzy_czesciowego_zapisu(tmp_path: Path) -> None:
    app = katalog(tmp_path)
    pierwszy = app.dodaj(DaneProduktu("Pierwszy", "TEST-A"))
    with pytest.raises(BladScenariuszaKatalogu) as blad:
        app.dodaj(DaneProduktu("Drugi", "TEST-A"))
    assert blad.value.kod == "SKU_ZAJETE"
    assert app.wyszukaj() == [pierwszy]


def test_edycja_na_sku_innego_produktu_jest_w_calości_wycofana(tmp_path: Path) -> None:
    app = katalog(tmp_path)
    a = app.dodaj(DaneProduktu("A", "TEST-A"))
    b = app.dodaj(DaneProduktu("B", "TEST-B"))
    with pytest.raises(BladScenariuszaKatalogu):
        app.edytuj(b.id, b.wersja, DaneProduktu("Zmieniony", a.sku))
    assert app.wyszukaj("TEST-B") == [b]


def test_konflikt_wersji_nie_nadpisuje_nowszych_danych(tmp_path: Path) -> None:
    app = katalog(tmp_path)
    stary = app.dodaj(DaneProduktu("Przed", "TEST-A"))
    nowy = app.edytuj(stary.id, 1, DaneProduktu("Po", "TEST-A"))
    with pytest.raises(BladScenariuszaKatalogu) as blad:
        app.edytuj(stary.id, 1, DaneProduktu("Nadpisanie", "TEST-A"))
    assert blad.value.kod == "KONFLIKT_WERSJI"
    assert app.wyszukaj() == [nowy]


def test_atomowy_warunek_wersji_w_adapterze(tmp_path: Path) -> None:
    repo = KatalogSQLite(tmp_path / "katalog.sqlite3")
    produkt = Produkt(uuid4(), "Test", "TEST-A")
    repo.dodaj(produkt)
    repo.zapisz(produkt.zmien("Nowa", produkt.sku, ""), 1)
    with pytest.raises(KonfliktEdycji):
        repo.zapisz(produkt.zmien("Spóźniona", produkt.sku, ""), 1)
    assert repo.pobierz(produkt.id).nazwa == "Nowa"


def test_wyszukiwanie_polskich_liter_i_parametryzacja(tmp_path: Path) -> None:
    app = katalog(tmp_path)
    zapisany = app.dodaj(DaneProduktu("Żółty produkt", "SKU-' OR 1=1 --"))
    assert app.wyszukaj("ŻÓŁTY") == [zapisany]
    assert app.wyszukaj("' OR 1=1") == [zapisany]
    assert app.wyszukaj("nieistniejący") == []
    assert app.wyszukaj() == [zapisany]


def test_sku_ignoruje_wielkosc_liter_i_skrajne_odstepy(tmp_path: Path) -> None:
    app = katalog(tmp_path)
    a = app.dodaj(DaneProduktu("  A  ", "  TEST-A  "))
    assert a.nazwa == "A" and a.sku == "TEST-A"
    with pytest.raises(BladScenariuszaKatalogu):
        app.dodaj(DaneProduktu("B", "TEST-A "))
    with pytest.raises(BladScenariuszaKatalogu):
        app.dodaj(DaneProduktu("C", "test-a"))
    assert len(app.wyszukaj()) == 1


def test_unikalnosc_sku_obsluguje_polskie_litery(tmp_path: Path) -> None:
    app = katalog(tmp_path)
    zapisany = app.dodaj(DaneProduktu("A", "ŻÓŁĆ"))
    with pytest.raises(BladScenariuszaKatalogu):
        app.dodaj(DaneProduktu("B", "żółć"))
    assert app.wyszukaj()[0].sku == zapisany.sku


def test_rownoczesne_dodanie_tego_samego_sku_ma_jeden_sukces(tmp_path: Path) -> None:
    repo = KatalogSQLite(tmp_path / "katalog.sqlite3")

    def dodaj(numer: int) -> bool:
        try:
            repo.dodaj(Produkt(uuid4(), f"Test {numer}", "TEST-A"))
        except SKUJuzIstnieje:
            return False
        return True

    with ThreadPoolExecutor(max_workers=2) as pool:
        wyniki = list(pool.map(dodaj, [1, 2]))
    assert sorted(wyniki) == [False, True]
    assert len(repo.wyszukaj("")) == 1


def test_kopia_odtwarza_dane_i_nie_nadpisuje_istniejacego_pliku(tmp_path: Path) -> None:
    app = katalog(tmp_path)
    zapisany = app.dodaj(DaneProduktu("Test", "TEST-A"))
    kopia = tmp_path / "kopia.sqlite3"
    app.utworz_kopie(kopia)
    repo_kopii = KatalogSQLite(kopia)
    assert KatalogProduktow(repo_kopii, repo_kopii).wyszukaj() == [zapisany]
    oryginal = kopia.read_bytes()
    with pytest.raises(BladTechniczny):
        app.utworz_kopie(kopia)
    assert kopia.read_bytes() == oryginal


def test_kopia_nie_moze_nadpisac_aktywnej_bazy(tmp_path: Path) -> None:
    repo = KatalogSQLite(tmp_path / "katalog.sqlite3")
    repo.wyszukaj("")
    with pytest.raises(BladTechniczny):
        repo.wykonaj_kopie(repo.plik)
    assert repo.wyszukaj("") == []


@pytest.mark.parametrize("obcy_schemat", [False, True])
def test_nieznana_baza_nie_jest_modyfikowana(tmp_path: Path, obcy_schemat: bool) -> None:
    plik = tmp_path / "obca.sqlite3"
    with closing(sqlite3.connect(plik)) as conn, conn:
        if obcy_schemat:
            conn.execute("CREATE TABLE obce (id TEXT)")
        else:
            conn.execute("PRAGMA user_version = 2")
    oryginal = plik.read_bytes()
    with pytest.raises(BladTechniczny):
        KatalogSQLite(plik).wyszukaj("")
    assert plik.read_bytes() == oryginal


def test_uszkodzona_baza_nie_jest_usuwana(tmp_path: Path) -> None:
    plik = tmp_path / "uszkodzona.sqlite3"
    plik.write_bytes(b"to nie jest sqlite")
    with pytest.raises(BladTechniczny):
        KatalogSQLite(plik).wyszukaj("")
    assert plik.read_bytes() == b"to nie jest sqlite"


def test_niedostepny_katalog_danych_daje_bezpieczny_blad(tmp_path: Path) -> None:
    plik = tmp_path / "to-plik"
    plik.write_text("zachowaj")
    with pytest.raises(BladTechniczny, match="Nie można"):
        KatalogSQLite(plik / "katalog.sqlite3").wyszukaj("")
    assert plik.read_text() == "zachowaj"


def test_walidacja_przed_utworzeniem_pliku_bazy(tmp_path: Path) -> None:
    with pytest.raises(BladScenariuszaKatalogu) as blad:
        katalog(tmp_path).dodaj(DaneProduktu("Nazwa", "  "))
    assert blad.value.kod == "WALIDACJA_SKU"
    assert not (tmp_path / "dane").exists()


def test_przerwana_inicjalizacja_wycofuje_caly_schemat(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    plik = tmp_path / "przerwana.sqlite3"
    oryginalne_connect = sqlite3.connect

    class Przerwanie(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql == "PRAGMA user_version = 1":
                raise sqlite3.OperationalError("Symulacja przerwania")
            return super().execute(sql, parameters)

    with monkeypatch.context() as context:
        context.setattr(
            sqlite3,
            "connect",
            lambda *args, **kwargs: oryginalne_connect(*args, **kwargs, factory=Przerwanie),
        )
        with pytest.raises(BladTechniczny):
            KatalogSQLite(plik).wyszukaj("")
    with closing(oryginalne_connect(plik)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 0
        assert conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall() == []
    assert KatalogSQLite(plik).wyszukaj("") == []


def test_niezgodna_suma_migracji_blokuje_otwarcie_bez_usuwania_danych(tmp_path: Path) -> None:
    plik = tmp_path / "katalog.sqlite3"
    repo = KatalogSQLite(plik)
    repo.dodaj(Produkt(uuid4(), "Test", "TEST-A"))
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.execute("UPDATE migracje SET suma_sha256='niezgodna'")
    with pytest.raises(BladTechniczny, match="schematu"):
        repo.wyszukaj("")
    with closing(sqlite3.connect(plik)) as conn:
        assert conn.execute("SELECT count(*) FROM produkty").fetchone()[0] == 1
