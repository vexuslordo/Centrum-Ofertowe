from contextlib import closing
from dataclasses import replace
from uuid import uuid4

import pytest

from vexlab.adaptery import cenniki_odczyt_sqlite as odczyt
from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.importowanie import CenaImportu, ImportujProdukty, PozycjaImportu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.strony_cennika import PrzegladCennika
from vexlab.rdzen.kontrakty import BladTechniczny


@pytest.fixture
def dane(tmp_path):
    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    importer = ImportujProdukty(CzytnikTabel(), repo, repo)
    b = BibliotekaCennikow(repo, importer)
    rows = tuple(
        PozycjaImportu(
            uuid4(),
            uuid4(),
            "test.csv",
            "A",
            i + 2,
            DaneProduktu(
                f"Produkt {i:04d}",
                f"SKU-{i:04d}",
                "DUZY_OPIS " * 1000,
                ean="5901234123457" if i == 300 else "",
            ),
            cena=CenaImportu("12.50", "EUR", "brutto"),
        )
        for i in range(350)
    )
    rows = (
        rows[:250]
        + (replace(rows[250], dane=replace(rows[250].dane, sku=" sku-0000 ")),)
        + rows[251:]
    )
    id = b.zapisz("Test", 2026, "", importer.ocen(rows))
    c = next(c for c in b.lista() if c.id == id)
    return repo, b, c, PrzegladCennika(b)


def test_strony_zgodne_z_pelnym_porownaniem_duplikaty_globalne_i_ean(dane, monkeypatch):
    repo, b, c, przeglad = dane
    pelne = b.pozycje(c)
    monkeypatch.setattr(repo, "pozycje", lambda *a: pytest.fail("Pełny JSON w Pythonie"))
    monkeypatch.setattr(repo, "wyszukaj", lambda *a: pytest.fail("Pełny katalog"))
    indeks = przeglad.przygotuj(c)
    assert "DUZY_OPIS" not in repr(indeks)
    strony = [przeglad.strona(c, indeks, numer=n) for n in range(4)]
    assert [len(s.pozycje) for s in strony] == [100, 100, 100, 50]
    assert tuple(p for s in strony for p in s.pozycje) == pelne
    assert all(s.ma_ean for s in strony)
    bledy = przeglad.strona(c, indeks, stan="Do poprawy")
    assert {p.indeks for p in bledy.pozycje} == {0, 250}
    assert all("Powtórzone SKU" in p.problem for p in bledy.pozycje)


def test_pobierane_sa_tylko_pozycje_strony_lub_jawnego_wyboru(dane, monkeypatch):
    repo, b, c, przeglad = dane
    indeks = przeglad.przygotuj(c)
    dekoduj = odczyt._dekoduj
    wywolania = []

    def policz(tekst):
        wywolania.append(1)
        return dekoduj(tekst)

    monkeypatch.setattr(odczyt, "_dekoduj", policz)
    monkeypatch.setattr(repo, "pozycje", lambda *a: pytest.fail("Pełny JSON"))
    przeglad.strona(c, indeks, numer=1)
    assert len(wywolania) == 100
    wywolania.clear()
    assert b.dodaj(c, frozenset({349})).dodane == 1
    assert len(wywolania) == 1
    nowy = CennikiSQLite(repo.plik)
    produkt = KatalogProduktow(nowy, nowy).wyszukaj()[0]
    assert produkt.sku == "SKU-0349" and produkt.opis == "DUZY_OPIS " * 1000


def test_wersja_sprawdzana_takze_dla_pustego_filtra_i_generator_zwalnia_polaczenie(dane):
    repo, b, c, przeglad = dane
    indeks = przeglad.przygotuj(c)
    with pytest.raises(ValueError), closing(repo.iteruj_pozycje(c.id, c.wersja)) as rows:
        next(rows)
        raise ValueError("Błąd odbiorcy")
    with repo._polaczenie() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("UPDATE cenniki SET wersja=wersja+1 WHERE id=?", (str(c.id),))
    with pytest.raises(BladScenariuszaKatalogu):
        przeglad.strona(c, indeks, fraza="nie istnieje")


def test_nieprawidlowy_json_nie_tworzyl_czesciowego_indeksu(dane):
    repo, b, c, przeglad = dane
    with repo._polaczenie() as conn:
        conn.execute("UPDATE cenniki SET dane_json='{}' WHERE id=?", (str(c.id),))
    with pytest.raises(BladTechniczny):
        przeglad.przygotuj(c)


def test_porownanie_poprzedniego_wydania_bez_pelnego_odczytu_json(dane, monkeypatch):
    from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow

    repo, b, c, przeglad = dane
    pid = RejestrProducentow(repo).dodaj(DaneProducenta("Producent testowy")).id
    rows = tuple(
        replace(p, dane=replace(p.dane, producent_id=pid)) for p in repo.pozycje(c.id, c.wersja)
    )
    bazowy = b.zapisz(
        "Bazowy",
        2025,
        "",
        b.importer.ocen(tuple(replace(p, cena=CenaImportu("10", "EUR", "brutto")) for p in rows)),
    )
    baza = next(c for c in b.lista() if c.id == bazowy)
    b.oznacz(baza, True, b.lista())
    baza = next(c for c in b.lista() if c.id == bazowy)
    nowy = b.zapisz("Nowe wydanie", 2026, "", b.importer.ocen(rows), poprzedni=baza)
    doc = next(c for c in b.lista() if c.id == nowy)
    monkeypatch.setattr(repo, "pozycje", lambda *a: pytest.fail("Pełny JSON"))
    indeks = przeglad.przygotuj(doc)
    p = przeglad.strona(doc, indeks, fraza="SKU-0349").pozycje[0]
    assert p.roznica == "+2,50 EUR (+25,00%)" and p.stan == "Inna cena"
