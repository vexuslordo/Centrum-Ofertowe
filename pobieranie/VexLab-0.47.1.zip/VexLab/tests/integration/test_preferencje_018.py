import pytest
from PySide6.QtCore import QSettings

from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji
from vexlab.rdzen.kontrakty import BladTechniczny


def magazyn(plik):
    return PreferencjeQt(QSettings(str(plik), QSettings.Format.IniFormat))


@pytest.mark.parametrize("akcje", [(), ("szkice", "cenniki", "produkty")])
def test_wlasne_akcje_i_zrodlo_zdjec_po_restarcie(tmp_path, akcje):
    plik = tmp_path / "prefs.ini"
    p = PowlokaAplikacji(magazyn(plik), "test", "test")
    p.ustaw_szybkie_akcje(akcje)
    p.ustaw_zrodlo_zdjec("https://example.com", 12)
    nowe = PowlokaAplikacji(magazyn(plik), "test", "test").preferencje
    assert nowe.szybkie_akcje == akcje
    assert nowe.strona_zdjec == "https://example.com"
    assert nowe.limit_zdjec_mb == 12


@pytest.mark.parametrize("tekst", ['["nieznana"]', '["szkice","szkice"]', "{}", "[1]", "bad"])
def test_uszkodzone_akcje_przywracaja_domyslne(tmp_path, tekst):
    plik = tmp_path / "prefs.ini"
    q = QSettings(str(plik), QSettings.Format.IniFormat)
    q.setValue("dashboard/szybkie_akcje", tekst)
    q.sync()
    assert magazyn(plik).odczytaj().szybkie_akcje is None


def test_awaria_zapisu_nie_podmienia_aktywnych_akcji_i_zrodla(tmp_path):
    class Awaria:
        def odczytaj(self):
            return magazyn(tmp_path / "prefs.ini").odczytaj()

        def zapisz(self, nowe):
            raise BladTechniczny("Brak zapisu")

    p = PowlokaAplikacji(Awaria(), "test", "test")
    stare = p.preferencje
    with pytest.raises(BladTechniczny):
        p.ustaw_szybkie_akcje(("szkice",))
    assert p.preferencje == stare
    with pytest.raises(BladTechniczny):
        p.ustaw_zrodlo_zdjec("https://example.com", 12)
    assert p.preferencje == stare


def test_grupy_menu_po_ponownym_odczycie_i_odpornosc_na_bledne_ustawienia(tmp_path):
    plik = tmp_path / "menu.ini"
    p = PowlokaAplikacji(magazyn(plik), "test", "test")
    p.ustaw_grupy(("OFERTY", "SPRZEDAŻ"))
    assert magazyn(plik).odczytaj().rozwiniete_grupy == ("OFERTY", "SPRZEDAŻ")
    for tekst in ('["nieznana"]', '["OFERTY","OFERTY"]', "[1]", "{}", "bad"):
        q = QSettings(str(plik), QSettings.Format.IniFormat)
        q.setValue("wyglad/rozwiniete_grupy", tekst)
        q.sync()
        assert magazyn(plik).odczytaj().rozwiniete_grupy == ()
