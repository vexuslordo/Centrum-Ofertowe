import shutil
import sqlite3
from contextlib import closing
from dataclasses import replace
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.cenniki_sqlite import CennikiSQLite
from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.cenniki import BibliotekaCennikow
from vexlab.przypadki_uzycia.importowanie import CenaImportu, ImportujProdukty, PozycjaImportu
from vexlab.przypadki_uzycia.katalog import DaneDopasowania, DaneProduktu, KatalogProduktow
from vexlab.rdzen.kontrakty import BladTechniczny


@pytest.fixture
def uslugi(tmp_path):
    repo = CennikiSQLite(tmp_path / "k.sqlite3")
    importer = ImportujProdukty(CzytnikTabel(), repo, repo)
    return BibliotekaCennikow(repo, importer), KatalogProduktow(repo, repo), repo


def pozycje():
    paczka = uuid4()
    return tuple(
        PozycjaImportu(
            uuid4(),
            paczka,
            "user.csv",
            "A",
            i + 2,
            DaneProduktu(
                nazwa,
                sku,
                "Opis",
                None,
                (DaneDopasowania("Marka", "Model", "2020", "2024", ""),) if i == 0 else (),
            ),
            cena=CenaImportu("12,30", "EUR", "brutto"),
        )
        for i, (nazwa, sku) in enumerate((("Pierwszy", "ABC"), ("Drugi", "DEF"), ("Błędny", "")))
    )


def zapisz(s, rows=None):
    s.zapisz("Cennik użytkownika", 2025, "marzec", s.importer.ocen(rows or pozycje()))
    return s.lista()[0]


def test_zapis_bez_produktow_restart_wybor_i_pominiecie_znanych(uslugi):
    s, kat, repo = uslugi
    rows = pozycje()
    c = zapisz(s, rows)
    assert kat.wyszukaj() == [] and repo.oczekujace() == ()
    assert c.rok == 2025 and c.wydanie == "marzec" and c.liczba == 3
    restart = BibliotekaCennikow(CennikiSQLite(repo.plik), s.importer)
    assert tuple(p.pozycja for p in restart.pozycje(c)) == rows
    wynik = restart.dodaj(c, frozenset({0}))
    assert (wynik.dodane, wynik.odlozone, wynik.pominiete) == (1, 0, 0)
    p = kat.wyszukaj()[0]
    assert p.sku == "ABC" and p.dopasowania[0].rok_do == 2024
    assert p.cena_sugerowana.waluta == "EUR" and p.cena_sugerowana.kwota == "12.30"
    assert repo.oczekujace() == ()
    assert restart.pozycje(c)[0].w_katalogu
    w = s.dodaj(c, frozenset({0, 1, 2}))
    assert (w.dodane, w.odlozone, w.pominiete) == (1, 1, 1)
    assert next(x for x in kat.wyszukaj() if x.sku == "ABC") == p
    assert len(repo.oczekujace()) == 1
    assert "Brak SKU" in repo.oczekujace()[0].powod
    assert s.dodaj(c, frozenset({0, 1})).kopia is None


def test_usuwanie_wielu_kopia_i_produkty_pozostaja(uslugi, tmp_path):
    s, kat, repo = uslugi
    c = zapisz(s)
    s.dodaj(c, frozenset({0, 2}))
    zapisz(s)
    zapisane = s.lista()
    produkty, robocze = kat.wyszukaj(), repo.oczekujace()
    kopia = s.usun(zapisane)
    assert s.lista() == () and kat.wyszukaj() == produkty and repo.oczekujace() == robocze
    restore = tmp_path / "restore.sqlite3"
    shutil.copyfile(kopia, restore)
    assert CennikiSQLite(restore).lista() == zapisane
    with pytest.raises(BladScenariuszaKatalogu):
        s.dodaj(c, frozenset({1}))
    assert kat.wyszukaj() == produkty


def test_konflikt_blad_kopii_i_awaria_srodka_usuwania_atomowe(uslugi, tmp_path):
    s, kat, repo = uslugi
    c = zapisz(s)
    with pytest.raises(BladScenariuszaKatalogu):
        s.usun((replace(c, wersja=2),))
    folder = tmp_path / "kopie_cennikow"
    shutil.rmtree(folder)
    folder.write_text("blokada")
    with pytest.raises(BladTechniczny):
        s.dodaj(c, frozenset({0}))
    assert kat.wyszukaj() == [] and s.lista() == (c,)
    with pytest.raises(BladTechniczny):
        s.usun((c,))
    folder.unlink()
    zapisz(s)
    lists = s.lista()
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute(
            "CREATE TRIGGER stop_delete BEFORE DELETE ON cenniki WHEN old.id='"
            + str(lists[1].id)
            + "' BEGIN SELECT RAISE(ABORT,'stop'); END"
        )
    with pytest.raises(BladTechniczny):
        s.usun(lists)
    assert s.lista() == lists


def test_duplikat_mozna_wybrac_jeden_a_zly_cennik_nie_nadpisuje(uslugi):
    s, kat, repo = uslugi
    rows = pozycje()
    c = zapisz(s, (rows[0], replace(rows[1], dane=replace(rows[1].dane, sku="abc"))))
    assert "Powtórzone" in s.pozycje(c)[0].problem
    assert s.dodaj(c, frozenset({0})).dodane == 1
    assert s.dodaj(c, frozenset({1})).pominiete == 1
    for nazwa, rok in (("", 2025), ("A", 0)):
        with pytest.raises(BladScenariuszaKatalogu):
            s.zapisz(nazwa, rok, "", s.importer.ocen(rows))
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute("UPDATE cenniki SET dane_json='[{}]' WHERE id=?", (str(c.id),))
    with pytest.raises(BladTechniczny):
        s.pozycje(c)


def test_czesciowy_import_cofa_sie_po_bledzie(uslugi):
    s, kat, repo = uslugi
    c = zapisz(s)
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute(
            "CREATE TRIGGER stop_add BEFORE INSERT ON produkty WHEN new.sku='DEF' "
            "BEGIN SELECT RAISE(ABORT,'stop'); END"
        )
    with pytest.raises(BladTechniczny):
        s.dodaj(c, frozenset({0, 1}))
    assert kat.wyszukaj() == [] and repo.oczekujace() == ()


def test_migracja8_kopia_odtworzenie_i_suma(tmp_path):
    plik = tmp_path / "k.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_7.sql"
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.executescript(fixture.read_text())
    repo = CennikiSQLite(plik)
    assert repo.lista() == ()
    (kopia,) = (tmp_path / "kopie_migracji").glob("*.sqlite3")
    with closing(sqlite3.connect(kopia)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 7
    restore = tmp_path / "restore.sqlite3"
    shutil.copyfile(kopia, restore)
    assert CennikiSQLite(restore).lista() == ()
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.execute("UPDATE migracje SET suma_sha256='inna' WHERE wersja=8")
    with pytest.raises(BladTechniczny):
        repo.lista()


@pytest.mark.parametrize("kopia", [False, True])
def test_przerwana_migracja8_lub_brak_kopii_nie_zmienia_bazy(tmp_path, monkeypatch, kopia):
    plik = tmp_path / "k.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_7.sql"
    orig = sqlite3.connect
    with closing(orig(plik)) as conn, conn:
        conn.executescript(fixture.read_text())
    if kopia:
        (tmp_path / "kopie_migracji").write_text("blokada")

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("INSERT INTO migracje VALUES (8"):
                raise sqlite3.OperationalError("awaria")
            return super().execute(sql, parameters)

    if not kopia:
        monkeypatch.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
    with pytest.raises(BladTechniczny):
        CennikiSQLite(plik).lista()
    with closing(orig(plik)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 7
        assert not conn.execute("SELECT 1 FROM sqlite_master WHERE name='cenniki'").fetchall()


def test_migracja8_zachowuje_produkt_szkic_i_cene_w_kopii(tmp_path, stare_powiazania):
    from vexlab.adaptery.szkice_sqlite import SzkiceSQLite
    from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
    from vexlab.przypadki_uzycia.szkice import SzkiceOfert

    plik = tmp_path / "k.sqlite3"
    repo = SzkiceSQLite(plik)
    kat = KatalogProduktow(repo, repo)
    szkice = SzkiceOfert(repo)
    oferta = OfertaPodglad(1, "A", "Szkic", "<p>Opis</p>", "", "", "", (), (), ())
    szkice.zapisz(szkice.zaplanuj((oferta,), "user.zip"))
    stare_powiazania(szkice, kat, repo)
    before = szkice.lista()
    # Fixture opublikowanego schematu 7 z rzeczywistą treścią szkicu.
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.execute("ALTER TABLE produkty DROP COLUMN ean")
        conn.execute("ALTER TABLE import_robocze DROP COLUMN ean")
        conn.execute("DROP TABLE cenniki")
        conn.execute("DELETE FROM migracje WHERE wersja>=8")
        conn.execute("PRAGMA user_version=7")
    cenniki = CennikiSQLite(plik)
    assert cenniki.lista() == ()
    assert szkice.lista() == before and kat.wyszukaj()[0].sku == "A"
    (kopia,) = (tmp_path / "kopie_migracji").glob("*.sqlite3")
    with closing(sqlite3.connect(kopia)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 7
        assert conn.execute("SELECT tytul FROM szkice").fetchone()[0] == "Szkic"


def z_producentem(s, repo, nazwa, producent):
    rows = tuple(replace(p, dane=replace(p.dane, producent_id=producent)) for p in pozycje())
    id = s.zapisz(nazwa, 2026, "", s.importer.ocen(rows))
    return next(c for c in s.lista() if c.id == id)


def test_aktualny_per_producent_restart_archiwizacja_i_usuwanie(uslugi):
    from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow

    s, kat, repo = uslugi
    producent = RejestrProducentow(repo).dodaj(DaneProducenta("Producent A"))
    inny = RejestrProducentow(repo).dodaj(DaneProducenta("Producent B"))
    a = z_producentem(s, repo, "Wydanie A", producent.id)
    b = z_producentem(s, repo, "Wydanie B", producent.id)
    c = z_producentem(s, repo, "Inny producent", inny.id)
    assert not any(x.aktualny for x in s.lista())
    s.oznacz(a, True, s.lista())
    s.oznacz(c, True, s.lista())
    s.oznacz(b, True, s.lista())
    all_rows = CennikiSQLite(repo.plik).lista()
    assert {x.id for x in all_rows if x.aktualny} == {b.id, c.id}
    assert next(x for x in all_rows if x.id == a.id).wersja == 3
    assert kat.wyszukaj() == []
    aktualny = next(x for x in all_rows if x.id == b.id)
    s.oznacz(aktualny, False, all_rows)
    assert {x.id for x in s.lista() if x.aktualny} == {c.id}
    s.usun((next(x for x in s.lista() if x.id == c.id),))
    assert not any(x.aktualny for x in s.lista())
    with pytest.raises(BladScenariuszaKatalogu, match="producenta"):
        s.oznacz(zapisz(s), True, s.lista())


def test_status_wersje_konflikt_rollback_i_kopia(uslugi, tmp_path):
    from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow

    s, kat, repo = uslugi
    pid = RejestrProducentow(repo).dodaj(DaneProducenta("Producent")).id
    a = z_producentem(s, repo, "A", pid)
    b = z_producentem(s, repo, "B", pid)
    stara_lista = s.lista()
    kopia = s.oznacz(a, True, stara_lista)
    restore = tmp_path / "restore-status.sqlite3"
    shutil.copyfile(kopia, restore)
    assert not any(x.aktualny for x in CennikiSQLite(restore).lista())
    with pytest.raises(BladScenariuszaKatalogu):
        s.oznacz(b, True, stara_lista)
    before = s.lista()
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute(
            "CREATE TRIGGER stop_flag BEFORE UPDATE OF aktualny ON cenniki WHEN "
            "new.nazwa='B' BEGIN SELECT RAISE(ABORT,'stop'); END"
        )
    with pytest.raises(BladTechniczny):
        s.oznacz(b, True, before)
    assert s.lista() == before
    folder = tmp_path / "kopie_cennikow"
    shutil.rmtree(folder)
    folder.write_text("blokada")
    with pytest.raises(BladTechniczny):
        s.oznacz(next(x for x in before if x.id == a.id), False, before)
    assert s.lista() == before


def test_porownanie_statusy_ceny_i_bledne_istniejace_sku(uslugi):
    s, kat, repo = uslugi
    from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow

    pid = RejestrProducentow(repo).dodaj(DaneProducenta("Producent bazowy")).id
    row = pozycje()[0]
    row = replace(row, dane=replace(row.dane, producent_id=pid))
    baza = zapisz(s, (row,))
    s.oznacz(baza, True, s.lista())
    s.importer.zatwierdz(s.importer.ocen((row,)), frozenset({row.id}))
    c = zapisz(s, (replace(row, cena=CenaImportu("15.30", "EUR", "brutto")),))
    p = s.pozycje(c)[0]
    assert p.stan == "Inna cena" and p.cena_bazowa.kwota == "12.30"
    assert p.roznica == "+3,00 EUR (+24,39%)"
    d = zapisz(s, (replace(row, cena=CenaImportu("xxx", "EUR", "brutto")),))
    p = s.pozycje(d)[0]
    assert p.w_katalogu and p.stan == "Do poprawy" and p.roznica == "—"
    assert kat.wyszukaj()[0].cena_sugerowana.kwota == "12.30"


@pytest.mark.parametrize(
    "baza,nowa,waluta,rodzaj,oczekiwany,uwaga",
    [
        ("10", "12.50", "EUR", "brutto", "+2,50 EUR (+25,00%)", ""),
        ("10", "7.5", "EUR", "brutto", "-2,50 EUR (-25,00%)", ""),
        ("10", "10.000", "EUR", "brutto", "0,00 EUR (0,00%)", ""),
        ("0", "2", "EUR", "brutto", "+2,00 EUR (procent nieokreślony — bazowa 0)", ""),
        ("0", "0", "EUR", "brutto", "0,00 EUR (procent nieokreślony — bazowa 0)", ""),
        ("10", "12", "GBP", "brutto", "—", "waluty"),
        ("10", "12", "EUR", "netto", "—", "netto/brutto"),
        ("10", "", "EUR", "brutto", "—", "Brak ceny"),
    ],
)
def test_porownanie_bez_zgadywania_walut_i_vat(baza, nowa, waluta, rodzaj, oczekiwany, uwaga):
    from vexlab.przypadki_uzycia.cenniki import porownaj
    from vexlab.przypadki_uzycia.katalog import CenaSugerowanaDTO

    row = replace(pozycje()[0], cena=CenaImportu(nowa, waluta, rodzaj))
    delta, info, _ = porownaj(row, CenaSugerowanaDTO(baza, "EUR", "brutto", "test"))
    assert delta == oczekiwany and uwaga in info


def test_migracja9_cennik_pozostaje_archiwalny_kopia_i_odtworzenie(tmp_path):
    plik = tmp_path / "k.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_8.sql"
    id = str(uuid4())
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.executescript(fixture.read_text())
        conn.execute(
            "INSERT INTO cenniki VALUES (?,'Cennik',2026,'',NULL,'test','A',1,'2026','[]',1)", (id,)
        )
    repo = CennikiSQLite(plik)
    c = repo.lista()[0]
    assert str(c.id) == id and c.wersja == 1 and not c.aktualny
    (kopia,) = (tmp_path / "kopie_migracji").glob("*.sqlite3")
    with closing(sqlite3.connect(kopia)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 8
    restore = tmp_path / "restore9.sqlite3"
    shutil.copyfile(kopia, restore)
    assert CennikiSQLite(restore).lista() == (c,)
    with closing(sqlite3.connect(plik)) as conn, conn:
        conn.execute("UPDATE migracje SET suma_sha256='inna' WHERE wersja=9")
    with pytest.raises(BladTechniczny):
        repo.lista()


@pytest.mark.parametrize("kopia", [False, True])
def test_przerwanie_migracji9_nie_zmienia_schematu8(tmp_path, monkeypatch, kopia):
    plik = tmp_path / "k.sqlite3"
    fixture = Path(__file__).resolve().parents[1] / "fixtures/schemat_8.sql"
    orig = sqlite3.connect
    with closing(orig(plik)) as conn, conn:
        conn.executescript(fixture.read_text())
    if kopia:
        (tmp_path / "kopie_migracji").write_text("blokada")

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("INSERT INTO migracje VALUES (9"):
                raise sqlite3.OperationalError("awaria")
            return super().execute(sql, parameters)

    if not kopia:
        monkeypatch.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
    with pytest.raises(BladTechniczny):
        CennikiSQLite(plik).lista()
    with closing(orig(plik)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 8
        assert "aktualny" not in [r[1] for r in conn.execute("PRAGMA table_info(cenniki)")]


def test_baza_z_aktualnego_cennika_bez_katalogu_i_nowe_statusy(uslugi):
    from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow

    s, kat, repo = uslugi
    pid = RejestrProducentow(repo).dodaj(DaneProducenta("Producent")).id
    old = z_producentem(s, repo, "Bazowy", pid)
    assert old.status == "Nowy"
    assert not s.pozycje(old)[0].cena_bazowa
    s.oznacz(old, True, s.lista())
    row = replace(
        pozycje()[0],
        dane=replace(pozycje()[0].dane, producent_id=pid),
        cena=CenaImportu("15.30", "EUR", "brutto"),
    )
    id = s.zapisz("Porównywany", 2026, "", s.importer.ocen((row,)))
    nowy = next(c for c in s.lista() if c.id == id)
    p = s.pozycje(nowy)[0]
    assert kat.wyszukaj() == [] and p.cena_bazowa.kwota == "12.30"
    assert p.stan == "Inna cena" and p.roznica == "+3,00 EUR (+24,39%)"
    assert "Bazowy" in p.cena_bazowa.zrodlo
    s.oznacz(nowy, True, s.lista())
    assert next(c for c in s.lista() if c.id == old.id).status == "Archiwalny"
    assert next(c for c in s.lista() if c.id == id).status == "Aktualny / bazowy"
    nowy = next(c for c in s.lista() if c.id == id)
    assert s.pozycje(nowy)[0].roznica == "0,00 EUR (0,00%)"


def test_powtorzone_sku_w_bazowym_wymaga_zgodnych_cen(uslugi):
    from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow

    s, _, repo = uslugi
    pid = RejestrProducentow(repo).dodaj(DaneProducenta("Producent")).id
    r = pozycje()[0]
    r = replace(r, dane=replace(r.dane, producent_id=pid))
    for zgodne in (True, False):
        other = replace(
            r, id=uuid4(), wiersz=3, cena=CenaImportu("12.30" if zgodne else "100", "EUR", "brutto")
        )
        id = s.zapisz("Duplikaty", 2026, "", s.importer.ocen((r, other)))
        c = next(c for c in s.lista() if c.id == id)
        s.oznacz(c, True, s.lista())
        c = next(c for c in s.lista() if c.id == id)
        ceny, braki = s._ceny_bazowe(c)
        assert ("abc" in ceny) == zgodne
        if not zgodne:
            assert "Niejednoznaczna" in braki["abc"]


def test_aktualizacja_wydania_zachowuje_baze_i_historie_po_aktywacji(uslugi):
    from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow

    s, kat, repo = uslugi
    pid = RejestrProducentow(repo).dodaj(DaneProducenta("Producent")).id
    c = z_producentem(s, repo, "Cennik", pid)
    s.oznacz(c, True, s.lista())
    c = next(c for c in s.lista() if c.aktualny)
    r = pozycje()[0]
    r = replace(
        r, dane=replace(r.dane, producent_id=pid), cena=CenaImportu("15.30", "EUR", "brutto")
    )
    id = s.zapisz("Nowe wydanie", 2027, "", s.importer.ocen((r,)), poprzedni=c)
    nowy = next(c for c in s.lista() if c.id == id)
    assert nowy.aktualny and nowy.poprzedni_id == c.id
    assert next(x for x in s.lista() if x.id == c.id).archiwalny
    p = s.pozycje(nowy)[0]
    assert p.cena_bazowa.kwota == "12.30" and p.roznica == "+3,00 EUR (+24,39%)"
    assert kat.wyszukaj() == []
    s.usun((next(x for x in s.lista() if x.id == c.id),))
    assert "usunięte" in s.pozycje(nowy)[0].porownanie
    assert s.pozycje(nowy)[0].cena_bazowa is None


def test_awaria_nowego_wydania_nie_archiwizuje_poprzedniego(uslugi):
    from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow

    s, kat, repo = uslugi
    pid = RejestrProducentow(repo).dodaj(DaneProducenta("Producent")).id
    c = z_producentem(s, repo, "Cennik", pid)
    s.oznacz(c, True, s.lista())
    c = s.lista()[0]
    rows = s.magazyn.pozycje(c.id, c.wersja)
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute(
            "CREATE TRIGGER stop_update BEFORE INSERT ON cenniki WHEN "
            "new.nazwa='Nowy' BEGIN SELECT RAISE(ABORT,'stop'); END"
        )
    with pytest.raises(BladTechniczny):
        s.zapisz("Nowy", 2027, "", s.importer.ocen(rows), poprzedni=c)
    assert s.lista() == (c,)
