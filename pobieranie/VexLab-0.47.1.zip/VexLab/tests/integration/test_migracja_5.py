import shutil
import sqlite3
from contextlib import closing
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.rdzen.kontrakty import BladTechniczny

FIXTURE = Path(__file__).resolve().parents[1] / "fixtures" / "schemat_4.sql"


def stara(plik):
    pid, producent, paczka, roboczy = [str(uuid4()) for _ in range(4)]
    with closing(sqlite3.connect(plik)) as c, c:
        c.executescript(FIXTURE.read_text())
        c.execute(
            "INSERT INTO producenci VALUES (?, 'Producent', 1, 2, 'https://example.test')",
            (producent,),
        )
        c.execute(
            "INSERT INTO produkty VALUES (?, 'Nazwa', 'SKU', 'sku', 'Opis', 8, ?)", (pid, producent)
        )
        c.execute(
            "INSERT INTO ceny_sugerowane VALUES (?, '99.99', 'EUR', 'netto', 'cennik')", (pid,)
        )
        c.execute(
            "INSERT INTO zdjecia VALUES (?, ?, 'plik', ?, ?, 0)",
            (str(uuid4()), pid, b"obraz", b"mini"),
        )
        c.execute("INSERT INTO importy VALUES (?, 'test.csv', 'A', 0, 1)", (paczka,))
        c.execute(
            "INSERT INTO import_robocze VALUES (?, ?, 3, 'Roboczy', '', '', "
            "NULL, 'Brak SKU', 1, '', '', '')",
            (roboczy, paczka),
        )
    return pid


def test_migracja_4_do_5_zachowuje_calosc_i_odtwarza_kopie(tmp_path):
    plik = tmp_path / "k.sqlite3"
    pid = stara(plik)
    repo = KatalogSQLite(plik)
    p = repo.wyszukaj("")[0]
    assert str(p.id) == pid and p.wersja == 8 and p.dopasowania == ()
    assert repo.miniatury()[p.id] == b"mini"
    assert repo.ceny_sugerowane()[p.id].waluta == "EUR"
    kopie = list((tmp_path / "kopie_migracji").glob("*.sqlite3"))
    assert len(kopie) == 1
    for tabela in (
        "produkty",
        "producenci",
        "zdjecia",
        "ceny_sugerowane",
        "import_robocze",
        "importy",
    ):
        with closing(sqlite3.connect(kopie[0])) as stary, closing(sqlite3.connect(plik)) as nowy:
            kolumny = ",".join(r[1] for r in stary.execute(f"PRAGMA table_info({tabela})"))
            assert (
                stary.execute(f"SELECT {kolumny} FROM {tabela}").fetchall()
                == nowy.execute(f"SELECT {kolumny} FROM {tabela}").fetchall()
            )
    przywrocony = tmp_path / "przywrocony.sqlite3"
    shutil.copyfile(kopie[0], przywrocony)
    with closing(sqlite3.connect(przywrocony)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 4
        assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    assert KatalogSQLite(przywrocony).wyszukaj("")[0] == p


def test_przerwanie_migracji5_wycofuje_ddl_i_wersje(tmp_path, monkeypatch):
    plik = tmp_path / "k.sqlite3"
    pid = stara(plik)
    orig = sqlite3.connect

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("INSERT INTO migracje VALUES (5"):
                raise sqlite3.OperationalError("przerwanie")
            return super().execute(sql, parameters)

    with monkeypatch.context() as m:
        m.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
        with pytest.raises(BladTechniczny):
            KatalogSQLite(plik).wyszukaj("")
    with closing(orig(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 4
        assert c.execute("SELECT id FROM produkty").fetchone()[0] == pid
        assert not c.execute("SELECT 1 FROM sqlite_master WHERE name='dopasowania'").fetchall()
    assert len(list((tmp_path / "kopie_migracji").glob("*.sqlite3"))) == 1


def test_brak_kopii_i_niezgodny_checksum_blokuja_aktualizacje(tmp_path):
    plik = tmp_path / "k.sqlite3"
    stara(plik)
    blokada = tmp_path / "kopie_migracji"
    blokada.write_text("blokada")
    with pytest.raises(BladTechniczny):
        KatalogSQLite(plik).wyszukaj("")
    with closing(sqlite3.connect(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 4
    blokada.unlink()
    repo = KatalogSQLite(plik)
    repo.wyszukaj("")
    with closing(sqlite3.connect(plik)) as c, c:
        c.execute("UPDATE migracje SET suma_sha256='zle' WHERE wersja=5")
    with pytest.raises(BladTechniczny):
        repo.wyszukaj("")
