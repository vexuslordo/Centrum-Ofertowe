import sys
from types import SimpleNamespace

import pytest

from vexlab.adaptery import srodowisko_gt as gt
from vexlab.przypadki_uzycia.srodowisko_gt import InstalacjaGT


class Rejestr:
    def __init__(self):
        self.pola = []

    def podklucze(self, galaz, path, widok):
        return ("GT", "Inne") if galaz == "HKLM" and widok == 32 else ()

    def wartosc(self, galaz, path, nazwa, widok):
        self.pola.append((path, nazwa))
        if path.endswith("GT"):
            return "InsERT GT" if nazwa == "DisplayName" else "1.86 test"
        assert nazwa == "DisplayName"  # Nie pobieramy wersji ani ścieżek innych programów.
        return "Inne oprogramowanie"

    def wartosci(self, galaz, path, widok):
        return {
            "ODBC Driver 18 for SQL Server": "Installed",
            "Microsoft Access": "Installed",
            "SQL Server nieaktywny": "Not Installed",
        }


def test_obserwacje_dotycza_wpisow_instalacji_i_oddzielnych_widokow_odbc(monkeypatch):
    monkeypatch.setattr(gt.platform, "system", lambda: "Windows")
    rejestr = Rejestr()
    wynik = gt.SrodowiskoGTWindows(rejestr).odczytaj()
    assert wynik.instalacje == (InstalacjaGT("InsERT GT", "1.86 test", 32),)
    assert {p.widok_rejestru for p in wynik.sterowniki} == {32, 64}
    assert {p.nazwa for p in wynik.sterowniki} == {"ODBC Driver 18 for SQL Server"}
    assert not wynik.uwagi
    assert {nazwa for _, nazwa in rejestr.pola} == {"DisplayName", "DisplayVersion"}


def test_brak_uprawnien_daje_uwagi_zamiast_fikcyjnej_pelnej_obserwacji(monkeypatch):
    monkeypatch.setattr(gt.platform, "system", lambda: "Windows")

    class BrakDostepu(Rejestr):
        def podklucze(self, *args):
            raise PermissionError("PRYWATNE_DANE")

    wynik = gt.SrodowiskoGTWindows(BrakDostepu()).odczytaj()
    assert not wynik.instalacje and wynik.uwagi
    assert wynik.sterowniki
    assert "PRYWATNE_DANE" not in repr(wynik)


def test_poza_windows_nie_odczytuje_rejestru(monkeypatch):
    monkeypatch.setattr(gt.platform, "system", lambda: "Linux")

    class Niedostepny:
        def podklucze(self, *args):
            pytest.fail("Niedozwolony odczyt")

    wynik = gt.SrodowiskoGTWindows(Niedostepny()).odczytaj()
    assert not wynik.obslugiwany and not wynik.instalacje and not wynik.sterowniki


def test_metadane_nie_zawieraja_znakow_sterujacych(monkeypatch):
    monkeypatch.setattr(gt.platform, "system", lambda: "Windows")

    class Metadane(Rejestr):
        def wartosc(self, galaz, path, nazwa, widok):
            return "InsERT GT\r\n\x1b" + "x" * 300

    wynik = gt.SrodowiskoGTWindows(Metadane()).odczytaj()
    assert all(
        len(p.nazwa) <= 160 and "\n" not in p.nazwa and "\x1b" not in p.nazwa
        for p in wynik.instalacje
    )


def test_adapter_otwiera_klucze_tylko_do_odczytu_i_zamyka_uchwyty(monkeypatch):
    otwarcia, zamkniecia = [], []

    class Klucz:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            zamkniecia.append(1)

    def otworz(*args):
        otwarcia.append(args)
        return Klucz()

    modul = SimpleNamespace(
        HKEY_LOCAL_MACHINE=1,
        HKEY_CURRENT_USER=2,
        KEY_READ=0x20019,
        KEY_WOW64_32KEY=0x200,
        KEY_WOW64_64KEY=0x100,
        OpenKey=otworz,
        QueryInfoKey=lambda key: (1, 1, 0),
        EnumKey=lambda key, i: "GT",
        QueryValueEx=lambda key, name: ("test", 1),
        EnumValue=lambda key, i: ("ODBC Driver 18 for SQL Server", "Installed", 1),
    )
    with monkeypatch.context() as m:
        m.setattr(sys, "platform", "win32")
        m.setitem(sys.modules, "winreg", modul)
        r = gt.RejestrWindows()
        assert r.podklucze("HKLM", "X", 32) == ("GT",)
        assert r.wartosc("HKCU", "X", "DisplayName", 64) == "test"
        assert r.wartosci("HKLM", "X", 64) == {"ODBC Driver 18 for SQL Server": "Installed"}
    assert [a[3] for a in otwarcia] == [0x20219, 0x20119, 0x20119]
    assert len(zamkniecia) == 3


def test_brak_klucza_jest_odrozniany_od_odmowy_dostepu(monkeypatch):
    def brak(*args):
        raise FileNotFoundError("Brak klucza")

    modul = SimpleNamespace(
        HKEY_LOCAL_MACHINE=1,
        HKEY_CURRENT_USER=2,
        KEY_READ=0x20019,
        KEY_WOW64_32KEY=0x200,
        KEY_WOW64_64KEY=0x100,
        OpenKey=brak,
    )
    with monkeypatch.context() as m:
        m.setattr(sys, "platform", "win32")
        m.setitem(sys.modules, "winreg", modul)
        r = gt.RejestrWindows()
        assert r.podklucze("HKLM", "X", 32) == ()
        assert r.wartosc("HKLM", "X", "DisplayName", 32) == ""
        assert r.wartosci("HKLM", "X", 32) == {}

        def odmowa(*args):
            raise PermissionError("Odmowa")

        modul.OpenKey = odmowa
        with pytest.raises(PermissionError):
            r.podklucze("HKLM", "X", 32)
