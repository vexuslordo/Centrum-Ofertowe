from PySide6.QtCore import QSettings

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.przypadki_uzycia.dashboard import SEKCJE_DASHBOARDU, Dashboard
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow, ZapytanieKatalogu
from vexlab.przypadki_uzycia.powloka import PowlokaAplikacji


def test_agregaty_cache_i_filtry_poza_pierwsza_strona(tmp_path):
    repo = KatalogSQLite(tmp_path / "k.sqlite3")
    katalog = KatalogProduktow(repo, repo)
    for i in range(102):
        katalog.dodaj(DaneProduktu(f"Produkt {i:03}", f"SKU-{i}", "Opis" if i < 101 else ""))
    serwis = Dashboard(repo)
    stan = serwis.odczytaj()
    assert (stan.produkty, stan.bez_zdjec, stan.bez_ean, stan.bez_producenta) == (
        102,
        102,
        102,
        102,
    )
    assert stan.bez_opisu == 1
    katalog.dodaj(DaneProduktu("Nowy", "NOWY", ""))
    assert serwis.odczytaj() is stan
    assert serwis.odczytaj(odswiez=True).bez_opisu == 2
    wynik = katalog.odczyt.strona(ZapytanieKatalogu(opis=False), ())
    assert wynik.liczba == 2
    assert {p.sku for p in wynik.produkty} == {"SKU-101", "NOWY"}
    assert repo.stan_dashboardu().do_poprawy == 0


def test_uklad_zapamietuje_kolejnosc_i_ukryte_sekcje(tmp_path):
    q = QSettings(str(tmp_path / "prefs.ini"), QSettings.Format.IniFormat)
    powloka = PowlokaAplikacji(PreferencjeQt(q), "test", "test")
    kolejnosc = tuple(reversed(SEKCJE_DASHBOARDU))
    powloka.ustaw_dashboard(kolejnosc, ("ai", "top"))
    zapis = PreferencjeQt(q).odczytaj()
    assert zapis.dashboard_kolejnosc == kolejnosc
    assert zapis.dashboard_ukryte == ("ai", "top")
    q.setValue("dashboard/uklad", '{"kolejnosc":null,"ukryte":[]}')
    assert PreferencjeQt(q).odczytaj().dashboard_kolejnosc == SEKCJE_DASHBOARDU
