import sqlite3
from contextlib import closing
from dataclasses import replace
from zipfile import ZipFile

import pytest

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.importowanie import (
    Arkusz,
    ImportujProdukty,
    Komorka,
    Mapowanie,
    PlikImportu,
)
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.producenci import DaneProducenta, RejestrProducentow
from vexlab.rdzen.kontrakty import BladTechniczny


def tabela(rows):
    return PlikImportu(
        "test.xlsx",
        (
            Arkusz(
                "Dowolny",
                tuple((i, tuple(Komorka(s) for s in row)) for i, row in enumerate(rows, 1)),
            ),
        ),
    )


@pytest.fixture
def serwis(tmp_path):
    repo = ImportSQLite(tmp_path / "katalog.sqlite3")
    return ImportujProdukty(CzytnikTabel(), repo, repo)


def plan(serwis, rows=None, producent=None):
    return serwis.zaplanuj(
        tabela(
            rows
            or [
                ["Nazwa", "Kod"],
                ["Dobry", "001"],
                ["Konflikt A", "DUP"],
                ["Konflikt B", "dup"],
                ["Brak", ""],
            ]
        ),
        0,
        Mapowanie(1, 0, 1),
        producent,
    )


def test_paczka_trwalosc_korekta_i_brak_duplikatu_po_ponowieniu(serwis):
    oceny = plan(serwis)
    assert [bool(o.problem) for o in oceny] == [False, True, True, True]
    wynik = serwis.zatwierdz(oceny, frozenset([oceny[0].pozycja.id]))
    assert (wynik.dodane, wynik.odlozone) == (1, 3)
    drugi = ImportujProdukty(CzytnikTabel(), ImportSQLite(serwis.magazyn.plik), serwis.katalog)
    ocz = drugi.oczekujace()
    assert len(ocz) == 3
    assert serwis.katalog.wyszukaj("")[0].sku == "001"
    with pytest.raises(BladScenariuszaKatalogu):
        drugi.zatwierdz(oceny, frozenset())
    p = next(p for p in ocz if p.dane.sku == "")
    nowy = replace(p, dane=DaneProduktu("Poprawiony", "NOWY", "Opis"))
    drugi.popraw(nowy)
    with pytest.raises(BladScenariuszaKatalogu):
        drugi.rozstrzygnij(nowy)
    zapisany = next(p for p in drugi.oczekujace() if p.id == nowy.id)
    assert zapisany.wersja == 2
    drugi.rozstrzygnij(zapisany)
    assert len(drugi.oczekujace()) == 2
    with pytest.raises(BladScenariuszaKatalogu):
        drugi.rozstrzygnij(zapisany)
    assert len(drugi.katalog.wyszukaj("")) == 2


def test_wybor_jednego_duplikatu_i_powiazanie_drugiego_bez_nadpisania(serwis):
    oceny = plan(serwis, [["Nazwa", "Kod"], ["Pierwszy", "DUP"], ["Inne dopasowanie", "dup"]])
    serwis.zatwierdz(oceny, frozenset([oceny[0].pozycja.id]))
    produkt = serwis.katalog.wyszukaj("")[0]
    p = serwis.oczekujace()[0]
    serwis.rozstrzygnij(p, produkt.id)
    assert not serwis.oczekujace()
    assert serwis.katalog.wyszukaj("") == [produkt]
    with closing(sqlite3.connect(serwis.magazyn.plik)) as c:
        assert c.execute("SELECT tryb FROM import_powiazania ORDER BY tryb").fetchall() == [
            ("dodano",),
            ("powiazano",),
        ]


def test_konflikt_po_podgladzie_nie_zapisuje_nawet_pierwszego_wiersza(serwis):
    oceny = plan(serwis, [["Nazwa", "Kod"], ["A", "A"], ["B", "B"]])
    kat = KatalogProduktow(serwis.katalog, serwis.katalog)
    kat.dodaj(DaneProduktu("Istniejący", "B"))
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.zatwierdz(oceny, frozenset(o.pozycja.id for o in oceny))
    assert len(kat.wyszukaj()) == 1
    assert not serwis.oczekujace()


def test_awaria_w_srodku_transakcji_wycofuje_produkty_paczke_i_korekty(serwis, monkeypatch):
    oceny = plan(serwis)
    orig = serwis.magazyn._powiaz

    def przerwij(*args):
        orig(*args)
        raise BladTechniczny("Test awarii")

    monkeypatch.setattr(serwis.magazyn, "_powiaz", przerwij)
    with pytest.raises(BladTechniczny):
        serwis.zatwierdz(oceny, frozenset([oceny[0].pozycja.id]))
    assert not serwis.katalog.wyszukaj("")
    assert not serwis.oczekujace()
    with closing(sqlite3.connect(serwis.magazyn.plik)) as c:
        assert c.execute("SELECT count(*) FROM importy").fetchone()[0] == 0


def test_dezaktywacja_producenta_po_podgladzie_blokuje_paczke(serwis):
    rejestr = RejestrProducentow(serwis.katalog)
    p = rejestr.dodaj(DaneProducenta("Producent"))
    oceny = plan(serwis, producent=p.id)
    rejestr.edytuj(p.id, p.wersja, DaneProducenta(p.nazwa, False))
    with pytest.raises(BladScenariuszaKatalogu, match="nieaktywny"):
        serwis.zatwierdz(oceny, frozenset([oceny[0].pozycja.id]))
    assert not serwis.katalog.wyszukaj("")
    # Całą paczkę można świadomie odłożyć, by przypisać producenta później.
    assert serwis.zatwierdz(oceny, frozenset()).odlozone == 4


def test_mapowanie_dowolnych_kolumn_i_wiersza_naglowka(serwis):
    plik = tabela([["Tytuł pliku"], ["Symbol", "Opis", "Nazwa"], ["0007", "Opis", "Uniwersalny"]])
    o = serwis.zaplanuj(plik, 0, Mapowanie(2, 2, 0, 1), None)
    assert o[0].pozycja.dane == DaneProduktu("Uniwersalny", "0007", "Opis")
    assert not o[0].problem
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.zaplanuj(plik, 0, Mapowanie(2, 0, 0), None)


def test_powiazanie_wymaga_zgodnego_sku_i_nie_gubi_pozycji(serwis):
    oceny = plan(serwis)
    serwis.zatwierdz(oceny, frozenset([oceny[0].pozycja.id]))
    p = serwis.oczekujace()[0]
    produkt = serwis.katalog.wyszukaj("")[0]
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.rozstrzygnij(p, produkt.id)
    assert len(serwis.oczekujace()) == 3


def xlsx(path, rows, shared="", relationship=None):
    ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    with ZipFile(path, "w") as z:
        z.writestr(
            "xl/workbook.xml",
            (
                f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                "<sheets>"
                '<sheet name="Inny" r:id="r1"/>'
                "</sheets>"
                "</workbook>"
            ),
        )
        z.writestr(
            "xl/_rels/workbook.xml.rels",
            relationship
            or (
                "<Relationships>"
                '<Relationship Id="r1" Type="x/worksheet" Target="worksheets/sheet1.xml"/>'
                "</Relationships>"
            ),
        )
        z.writestr(
            "xl/worksheets/sheet1.xml",
            f'<worksheet xmlns="{ns}"><sheetData>{rows}</sheetData></worksheet>',
        )
        if shared:
            z.writestr("xl/sharedStrings.xml", shared)
    return path


def test_xlsx_inline_shared_formuly_liczby_i_luki(tmp_path):
    ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    plik = xlsx(
        tmp_path / "t.xlsx",
        (
            '<row r="1">'
            '<c r="A1" t="inlineStr">'
            "<is>"
            "<t>Nazwa</t>"
            "</is>"
            "</c>"
            '<c r="C1" t="s">'
            "<v>0</v>"
            "</c>"
            "</row>"
            '<row r="3">'
            '<c r="A3" t="inlineStr">'
            "<is>"
            "<t>Łącznik</t>"
            "</is>"
            "</c>"
            '<c r="C3" t="s">'
            "<v>1</v>"
            "</c>"
            '<c r="D3">'
            "<f>1+1</f>"
            "<v>2</v>"
            "</c>"
            '<c r="E3">'
            "<v>7</v>"
            "</c>"
            "</row>"
        ),
        f'<sst xmlns="{ns}"><si><t>SKU</t></si><si><t>0007</t></si></sst>',
    )
    p = CzytnikTabel().odczytaj(plik)
    assert p.arkusze[0].nazwa == "Inny"
    nr, c = p.arkusze[0].wiersze[1]
    assert nr == 3
    assert c[1].tekst == "" and c[2].tekst == "0007"
    assert c[3].problem and c[4].problem


@pytest.mark.parametrize("rozszerzenie", ["xls", "pdf", "xlsm"])
def test_nieobslugiwane_formaty(tmp_path, rozszerzenie):
    p = tmp_path / f"plik.{rozszerzenie}"
    p.write_bytes(b"x")
    with pytest.raises(BladScenariuszaKatalogu):
        CzytnikTabel().odczytaj(p)


def test_csv_utf8_cytowanie_i_zera(tmp_path):
    p = tmp_path / "t.csv"
    p.write_text('\ufeffNazwa;Kod;Opis\nŁącznik;0007;"Pierwszy\ndrugi"\n', encoding="utf-8")
    odczyt = CzytnikTabel().odczytaj(p)
    row = odczyt.arkusze[0].wiersze[1][1]
    assert [c.tekst for c in row] == ["Łącznik", "0007", "Pierwszy\ndrugi"]


def test_xml_encje_i_zewnetrzny_arkusz_odrzucane(tmp_path):
    p = xlsx(tmp_path / "t.xlsx", "")
    with ZipFile(p, "a") as z:
        z.writestr("xl/sharedStrings.xml", '<!DOCTYPE s [<!ENTITY x "Niedozwolone">]><s>&x;</s>')
    with pytest.raises(BladScenariuszaKatalogu):
        CzytnikTabel().odczytaj(p)
    p = xlsx(
        tmp_path / "external.xlsx",
        "",
        relationship=(
            "<Relationships>"
            '<Relationship Id="r1" Type="x/worksheet" Target="https://example.invalid/a" '
            'TargetMode="External"/>'
            "</Relationships>"
        ),
    )
    with pytest.raises(BladScenariuszaKatalogu):
        CzytnikTabel().odczytaj(p)


def test_zly_zip_i_limity(tmp_path, monkeypatch):
    p = tmp_path / "t.xlsx"
    p.write_bytes(b"not a zip")
    with pytest.raises(BladScenariuszaKatalogu):
        CzytnikTabel().odczytaj(p)
    from vexlab.adaptery import czytnik_importu

    monkeypatch.setattr(czytnik_importu, "MAX_PLIK", 1)
    with pytest.raises(BladScenariuszaKatalogu, match="20 MB"):
        CzytnikTabel().odczytaj(p)


def test_wyscig_sku_w_trakcie_zapisu_wycofuje_wczesniejsze_wiersze(serwis, monkeypatch):
    oceny = plan(serwis, [["Nazwa", "Kod"], ["A", "A"], ["B", "B"]])
    magazyn = serwis.magazyn
    oryginal = magazyn.zatwierdz_paczke

    def po_ocenie(pozycje, wybrane):
        KatalogProduktow(serwis.katalog, serwis.katalog).dodaj(DaneProduktu("Równoległy", "B"))
        return oryginal(pozycje, wybrane)

    monkeypatch.setattr(magazyn, "zatwierdz_paczke", po_ocenie)
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.zatwierdz(oceny, frozenset(o.pozycja.id for o in oceny))
    assert [p.sku for p in serwis.katalog.wyszukaj("")] == ["B"]
    assert not serwis.oczekujace()
    with closing(sqlite3.connect(magazyn.plik)) as c:
        assert c.execute("SELECT count(*) FROM importy").fetchone()[0] == 0


def test_awaria_po_dodaniu_poprawionego_produktu_zachowuje_pozycje(serwis, monkeypatch):
    oceny = plan(serwis, [["Nazwa", "Kod"], ["Nowy", "N"]])
    serwis.zatwierdz(oceny, frozenset())
    p = serwis.oczekujace()[0]

    def awaria(*args):
        raise BladTechniczny("Przerwanie zapisu")

    monkeypatch.setattr(serwis.magazyn, "_powiaz", awaria)
    with pytest.raises(BladTechniczny):
        serwis.rozstrzygnij(p)
    assert not serwis.katalog.wyszukaj("")
    assert serwis.oczekujace() == (p,)


def test_puste_nazwy_i_formuly_w_mapowanych_polach_blokuja_zapis(serwis):
    plik = PlikImportu(
        "t.xlsx",
        (
            Arkusz(
                "A",
                (
                    (1, (Komorka("Nazwa"), Komorka("SKU"))),
                    (2, (Komorka(""), Komorka("X"))),
                    (3, (Komorka("Obliczone", "Formuła"), Komorka("Y"))),
                ),
            ),
        ),
    )
    oceny = serwis.zaplanuj(plik, 0, Mapowanie(1, 0, 1), None)
    assert all(o.problem for o in oceny)
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.zatwierdz(oceny, frozenset(o.pozycja.id for o in oceny))
    assert not serwis.katalog.wyszukaj("")


def test_opis_laczy_nazwe_model_i_roczniki_bez_zgadywania(serwis):
    plik = tabela(
        [
            ["Nazwa", "SKU", "Marka motocykla", "Opis"],
            ["Brake lever - Honda CRF1000L Africa Twin (2016 - 2019)", "TEST", "Honda", "Opis"],
            ["Produkt uniwersalny", "UNI", "", ""],
        ]
    )
    oceny = serwis.zaplanuj(plik, 0, Mapowanie(1, 0, 1, 3, 2, True), None)
    assert oceny[0].pozycja.dane.opis == (
        "Brake lever - Honda CRF1000L Africa Twin (2016 - 2019)\n\nOpis\n\nHonda"
    )
    assert oceny[1].pozycja.dane.opis == "Produkt uniwersalny"
    assert not any(o.problem for o in oceny)
    serwis.zatwierdz(oceny, frozenset(o.pozycja.id for o in oceny))
    zapisany = serwis.katalog.wyszukaj("TEST")[0]
    assert zapisany.opis == oceny[0].pozycja.dane.opis


def test_nazwa_moze_byc_jednoczesnie_kolumna_opisu_i_nie_powiela_sie(serwis):
    o = serwis.zaplanuj(
        tabela([["Nazwa", "SKU"], ["Nazwa z modelem", "001"]]),
        0,
        Mapowanie(1, 0, 1, 0, 0, True),
        None,
    )
    assert o[0].pozycja.dane.opis == "Nazwa z modelem"
    assert not o[0].problem


def test_formuly_w_dodatkowym_opisie_nie_przechodza_walidacji(serwis):
    plik = PlikImportu(
        "t.xlsx",
        (
            Arkusz(
                "A",
                (
                    (1, (Komorka("Nazwa"), Komorka("SKU"), Komorka("Dane"))),
                    (2, (Komorka("Produkt"), Komorka("X"), Komorka("Wyliczone", "Formuła"))),
                ),
            ),
        ),
    )
    o = serwis.zaplanuj(plik, 0, Mapowanie(1, 0, 1, None, 2), None)
    assert "Formuła" in o[0].problem
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.zatwierdz(o, frozenset([o[0].pozycja.id]))


def test_usuwanie_korekt_kopia_i_konflikt_bez_czesciowego_usuniecia(serwis):
    oceny = plan(serwis)
    serwis.zatwierdz(oceny, frozenset([oceny[0].pozycja.id]))
    pozycje = serwis.oczekujace()
    serwis.popraw(pozycje[-1])
    with pytest.raises(BladScenariuszaKatalogu):
        serwis.usun_oczekujace(pozycje)
    assert len(serwis.oczekujace()) == 3
    aktualne = serwis.oczekujace()
    kopia = serwis.usun_oczekujace(aktualne[:1])
    assert kopia.is_file()
    with closing(sqlite3.connect(kopia)) as conn:
        assert conn.execute("SELECT COUNT(*) FROM import_robocze").fetchone()[0] == 3
    assert len(serwis.oczekujace()) == 2
    serwis.usun_oczekujace(serwis.oczekujace())
    assert serwis.oczekujace() == ()
    assert len(KatalogProduktow(serwis.magazyn, serwis.magazyn).wyszukaj()) == 1


def test_blad_kopii_nie_usuwaja_korekt(serwis, monkeypatch):
    oceny = plan(serwis)
    serwis.zatwierdz(oceny, frozenset())
    przed = serwis.oczekujace()

    def awaria(*args):
        raise BladTechniczny("Brak miejsca na kopię")

    monkeypatch.setattr(serwis.magazyn, "_kopia_spojna", awaria)
    with pytest.raises(BladTechniczny):
        serwis.usun_oczekujace(przed)
    assert serwis.oczekujace() == przed
