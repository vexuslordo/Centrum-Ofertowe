from urllib.error import HTTPError, URLError

import pytest

from vexlab.adaptery import allegro_http as m
from vexlab.przypadki_uzycia.allegro import BladAllegro


@pytest.mark.parametrize(
    "url,metoda",
    [
        ("http://allegro.pl/me", "GET"),
        ("https://evil.invalid/me", "GET"),
        ("https://user:pass@allegro.pl/me", "GET"),
        ("https://allegro.pl:444/me", "GET"),
        ("https://allegro.pl/me#bad", "GET"),
        ("https://api.allegro.pl/sale/offers", "PATCH"),
        ("https://api.allegro.pl/sale/offers", "POST"),
    ],
)
def test_obcy_host_lub_zapis_odrzucany_przed_polaczeniem(monkeypatch, url, metoda):
    monkeypatch.setattr(m, "build_opener", lambda *a: pytest.fail("Nie powinno być sieci"))
    with pytest.raises(BladAllegro):
        m.HTTPSAllegro().wyslij(metoda, url, {}, None)


def test_transport_timeout_limit_zamyka_uchwyt_i_nie_followuje_redirect(monkeypatch):
    class Response:
        code = 200
        closed = False

        def __enter__(self):
            return self

        def __exit__(self, *a):
            self.closed = True

        def read(self, n):
            self.limit = n
            return b"x" * n

    r = Response()
    wywolania = []

    class Opener:
        def open(self, req, timeout):
            wywolania.append((req, timeout))
            return r

    monkeypatch.setattr(m, "build_opener", lambda *a: Opener())
    with pytest.raises(BladAllegro, match="limit"):
        m.HTTPSAllegro().wyslij("GET", "https://api.allegro.pl/me", {}, None)
    assert r.closed and r.limit == 2 * 1024 * 1024 + 1 and wywolania[0][1] == 20
    assert (
        m.BezPrzekierowan().redirect_request(None, None, 302, "", None, "https://evil.invalid")
        is None
    )


def test_blad_sieci_nie_ujawnia_sekretow(monkeypatch):
    class Opener:
        def open(self, *a, **k):
            raise URLError("PRYWATNE")

    monkeypatch.setattr(m, "build_opener", lambda *a: Opener())
    with pytest.raises(BladAllegro) as e:
        m.HTTPSAllegro().wyslij("GET", "https://api.allegro.pl/me", {}, None)
    assert "PRYWATNE" not in str(e.value)


def test_status_http_z_trescia_trafia_do_mapperowania_i_uchwyt_zamkniety(monkeypatch):
    from io import BytesIO

    body = BytesIO(b'{"error":"authorization_pending"}')
    err = HTTPError("https://allegro.pl/auth/oauth/token", 400, "bad", {}, body)

    class Opener:
        def open(self, *a, **k):
            raise err

    monkeypatch.setattr(m, "build_opener", lambda *a: Opener())
    r = m.HTTPSAllegro().wyslij("POST", "https://allegro.pl/auth/oauth/token", {}, b"x")
    assert r.status == 400 and b"authorization_pending" in r.dane and body.closed
