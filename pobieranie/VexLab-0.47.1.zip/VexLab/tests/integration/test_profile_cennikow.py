import json
from dataclasses import replace
from uuid import uuid4

import pytest

from vexlab.adaptery.profile_cennikow_json import ProfileCennikowJSON
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.importowanie import (
    Arkusz,
    Komorka,
    Mapowanie,
    MapowanieCeny,
    PlikImportu,
)
from vexlab.przypadki_uzycia.profile_cennikow import ProfileCennikow, propozycja
from vexlab.rdzen.kontrakty import BladTechniczny


def tabela(nazwa="cennik.csv", naglowki=("Nazwa", "SKU", "EAN", "Cena"), nr=1):
    return PlikImportu(
        nazwa,
        (
            Arkusz(
                "Arkusz",
                (
                    (nr, tuple(Komorka(x) for x in naglowki)),
                    (nr + 1, (Komorka("Produkt"), Komorka("A"), Komorka(""), Komorka("100"))),
                ),
            ),
        ),
    )


@pytest.fixture
def uslugi(tmp_path):
    repo = ProfileCennikowJSON(tmp_path / "profile")
    return ProfileCennikow(repo), repo


def test_pierwszy_plik_propozycja_bez_zgadywania_ceny_i_zapisu(uslugi):
    s, repo = uslugi
    wynik = s.rozpoznaj(tabela())
    assert wynik.zgodne == () and wynik.propozycja.mapa == Mapowanie(1, 0, 1, ean=2)
    assert not repo.katalog.exists()


def test_rozpoznanie_po_restarcie_nowa_nazwa_i_przesuniety_naglowek(uslugi):
    s, repo = uslugi
    pid = uuid4()
    mapa = Mapowanie(1, 0, 1, cena=MapowanieCeny(3, "PLN", "brutto", True), ean=2)
    p = s.zapisz(tabela(), 0, mapa, pid, "Mój układ")
    nowe = ProfileCennikow(ProfileCennikowJSON(repo.katalog))
    r = nowe.rozpoznaj(tabela("nowy.xlsx", nr=5))
    assert len(r.zgodne) == 1 and r.propozycja is None
    d = r.zgodne[0]
    assert d.profil.id == p.id and d.profil.producent_id == pid
    assert d.mapa.naglowek == 5 and not d.mapa.cena.zapisane_formuly
    assert d.mapa.cena.waluta == "PLN" and d.mapa.cena.rodzaj == "brutto"
    assert nowe.zapisz(tabela(nr=5), 0, replace(mapa, naglowek=5), pid, "Mój układ").id == p.id
    assert len(repo.lista()) == 1


@pytest.mark.parametrize(
    "naglowki",
    [
        ("SKU", "Nazwa", "EAN", "Cena"),
        ("Nazwa", "SKU", "EAN", "Cena", "Uwagi"),
        ("Nazwa", "SKU", "EAN", "Inna cena"),
    ],
)
def test_zmiana_struktury_nie_stosuje_starego_profilu(uslugi, naglowki):
    s, _ = uslugi
    s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), None, "Układ")
    assert s.rozpoznaj(tabela(naglowki=naglowki)).zgodne == ()


def test_kilka_profili_lub_arkuszy_nie_jest_jednoznaczne(uslugi):
    s, _ = uslugi
    a = s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), uuid4(), "Producent A")
    b = s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), uuid4(), "Producent B")
    assert {d.profil.id for d in s.rozpoznaj(tabela()).zgodne} == {a.id, b.id}
    p = tabela()
    assert len(s.rozpoznaj(replace(p, arkusze=p.arkusze * 2)).zgodne) == 4
    assert propozycja(replace(p, arkusze=p.arkusze * 2)) is None


def test_powtorzone_naglowki_bez_propozycji():
    assert propozycja(tabela(naglowki=("Name", "SKU", "SKU"))) is None
    assert propozycja(tabela(naglowki=("Unknown", "Code"))) is None


def test_normalizacja_spacji_i_wielkosci_liter(uslugi):
    s, _ = uslugi
    s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), None, "Układ")
    assert len(s.rozpoznaj(tabela(naglowki=(" NAZWA ", "sku", " EAN ", "cena"))).zgodne) == 1


def test_usuniecie_profili_nie_uszkadza_innych_ustawien(uslugi):
    s, repo = uslugi
    a = s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), None, "A")
    b = s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), None, "B")
    s.usun(a)
    assert repo.lista() == (b,)
    with pytest.raises(BladTechniczny):
        s.usun(a)


def test_awaria_atomowego_zapisu_zachowuje_profile(uslugi, monkeypatch):
    import vexlab.adaptery.profile_cennikow_json as modul

    s, repo = uslugi
    a = s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), None, "A")

    def awaria(*args):
        raise OSError("Brak miejsca")

    monkeypatch.setattr(modul.os, "replace", awaria)
    with pytest.raises(BladTechniczny):
        s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), None, "B")
    assert repo.lista() == (a,)
    assert len(list(repo.katalog.iterdir())) == 1


@pytest.mark.parametrize(
    "zmien",
    [
        lambda d: d.update(wersja=2),
        lambda d: d.update(naglowki=[1]),
        lambda d: d["mapa"].update(sku=True),
        lambda d: d["mapa"].update(nazwa=-1),
        lambda d: d["mapa"].update(ean=200),
        lambda d: d["mapa"].update(dolacz_nazwe_zrodlowa="false"),
        lambda d: d.update(producent_id="nie-uuid"),
    ],
)
def test_uszkodzony_profil_pozostaje_i_daje_reczny_import(uslugi, zmien):
    s, repo = uslugi
    p = s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), None, "A")
    plik = repo.katalog / f"{p.id}.json"
    dane = json.loads(plik.read_text())
    zmien(dane)
    plik.write_text(json.dumps(dane))
    before = plik.read_bytes()
    r = s.rozpoznaj(tabela())
    assert r.problem and r.zgodne == () and r.propozycja is None
    assert plik.read_bytes() == before


def test_dowiazanie_ustawien_odrzucone(uslugi, tmp_path):
    s, repo = uslugi
    p = s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), None, "A")
    plik = repo.katalog / f"{p.id}.json"
    cel = tmp_path / "inny.json"
    plik.rename(cel)
    plik.symlink_to(cel)
    assert s.rozpoznaj(tabela()).problem
    with pytest.raises(BladTechniczny):
        s.usun(p)
    assert cel.exists()


def test_zbyt_dlugi_i_powtorzony_klucz_odrzucone(uslugi):
    s, repo = uslugi
    p = s.zapisz(tabela(), 0, Mapowanie(1, 0, 1), None, "A")
    plik = repo.katalog / f"{p.id}.json"
    plik.write_text('{"wersja":1,"wersja":1}')
    assert s.rozpoznaj(tabela()).problem
    plik.write_text(" " * 65537)
    assert s.rozpoznaj(tabela()).problem


@pytest.mark.parametrize(
    "mapa",
    [
        Mapowanie(1, 0, 0),
        Mapowanie(1, 0, 1, ean=0),
        Mapowanie(1, 0, 1, cena=MapowanieCeny(3, "PLN", "?")),
    ],
)
def test_bledne_mapowanie_nie_zapisuje_profilu(uslugi, mapa):
    s, repo = uslugi
    with pytest.raises(BladScenariuszaKatalogu):
        s.zapisz(tabela(), 0, mapa, None, "A")
    assert not repo.katalog.exists()
