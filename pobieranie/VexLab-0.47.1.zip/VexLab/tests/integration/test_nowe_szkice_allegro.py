import json
from copy import deepcopy
from dataclasses import replace

import pytest

from vexlab.adaptery.rejestr_tworzenia_allegro import RejestrTworzeniaJSON
from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, OdpowiedzAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import NoweSzkiceAllegro, ProbaTworzenia


def test_utworzenie_inactive_z_przeslanymi_zdjeciami_i_deduplikacja_po_restarcie(
    nowe_szkice_fixture,
):
    serwis, api, repo, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, u)
    assert not p.bledy
    w = serwis.utworz(s, p, lambda: False)
    assert w.stan == "Utworzono szkic" and w.ident == "12345678"
    d = next(iter(api.wyniki.values()))
    assert d["publication"] == {"status": "INACTIVE", "republish": False}
    assert d["productSet"] == [{"product": {"id": api.produkt.id}}]
    assert d["images"] == [d["description"]["sections"][0]["items"][1]["url"]]
    assert d["images"][0].startswith("https://a.allegroimg.com/")
    drugi = NoweSzkiceAllegro(api, RejestrTworzeniaJSON(repo.katalog), api)
    assert drugi.utworz(s, p, lambda: False).ident == w.ident
    assert api.calls.count("POST") == 1 and api.calls.count("zdjecie") == 1
    zapis = next(repo.katalog.glob("*.json")).read_text()
    assert all(v not in zapis for v in (s.token, "test-secret", o.opis, o.tytul, o.sku))


@pytest.mark.parametrize(
    "pole,wartosc",
    [
        ("tytul", "krótki"),
        ("cena", "NaN"),
        ("cena", "-1"),
        ("cena", "12.345"),
        ("cena", "1e999"),
        ("zdjecia", ()),
        ("ean", "5901234123458"),
        ("sekcje", ()),
        ("sku", ""),
    ],
)
def test_bledne_dane_blokuja_post(nowe_szkice_fixture, pole, wartosc):
    serwis, api, _, s, o, u = nowe_szkice_fixture
    o = replace(o, **{pole: wartosc})
    if pole == "sekcje":
        o = replace(o, opis="")
    p = serwis.przygotuj(s, o, u)
    assert p.bledy
    with pytest.raises(BladAllegro):
        serwis.utworz(s, p, lambda: False)
    assert "POST" not in api.calls and "zdjecie" not in api.calls


@pytest.mark.parametrize(
    "u_zmiany",
    [
        {"waluta": ""},
        {"ilosc": -1},
        {"ilosc": True},
        {"wartosci": ()},
        {"wartosci": (("11323", "nie-istnieje"),)},
    ],
)
def test_ustawienia_i_parametry_wymagane(nowe_szkice_fixture, u_zmiany):
    serwis, api, _, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, replace(u, **u_zmiany))
    assert p.bledy
    assert "POST" not in api.calls


def test_inne_konto_wygasniecie_i_zgoda_blokuja_zapis(nowe_szkice_fixture):
    serwis, api, _, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, u)
    for sesja in (
        replace(s, konto=replace(s.konto, id="inne")),
        replace(s, wygasa=1),
        replace(s, aplikacja=replace(s.aplikacja, zapis_szkicow=False)),
    ):
        with pytest.raises(BladAllegro):
            serwis.utworz(sesja, p, lambda: False)
    assert "POST" not in api.calls


def test_niejednoznaczny_katalog_wymaga_wyboru(nowe_szkice_fixture):
    serwis, api, _, s, o, u = nowe_szkice_fixture
    api.znajdz_produkty = lambda *a: (api.produkt, api.produkt)
    assert serwis.przygotuj(s, o, u).bledy
    assert not serwis.przygotuj(s, o, replace(u, produkt=api.produkt.id)).bledy


def test_timeout_po_skutku_nie_ponawia_post_takze_po_zmianie_danych(nowe_szkice_fixture):
    serwis, api, repo, s, o, u = nowe_szkice_fixture
    api.awaria = "timeout"
    p = serwis.przygotuj(s, o, u)
    with pytest.raises(BladAllegro, match="Timeout"):
        serwis.utworz(s, p, lambda: False)
    drugi = NoweSzkiceAllegro(api, RejestrTworzeniaJSON(repo.katalog), api)
    assert drugi.utworz(s, p, lambda: False).stan == "Wymaga sprawdzenia"
    with pytest.raises(BladAllegro, match="inną wersję"):
        drugi.utworz(s, drugi.przygotuj(s, replace(o, cena="999.00"), u), lambda: False)
    assert api.calls.count("POST") == 1


def test_odrzucenie_zwalnia_rezerwacje_a_awaria_zdjec_nie_wysyla_oferty(nowe_szkice_fixture):
    serwis, api, repo, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, u)
    api.awaria = "zdjecie"
    with pytest.raises(BladAllegro):
        serwis.utworz(s, p, lambda: False)
    assert "POST" not in api.calls
    api.awaria = "odrzucono"
    with pytest.raises(BladAllegro):
        serwis.utworz(s, p, lambda: False)
    assert repo.odczytaj(serwis.klucz(s, o.sku)) is None
    api.awaria = ""
    assert serwis.utworz(s, p, lambda: False).stan == "Utworzono szkic"


def test_anulowanie_przed_i_miedzy_zdjeciami(nowe_szkice_fixture):
    serwis, api, repo, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, u)
    assert serwis.utworz(s, p, lambda: True).stan == "Anulowano"
    assert "zdjecie" not in api.calls
    p = serwis.przygotuj(
        s, replace(o, zdjecia=(*o.zdjecia, "https://images.example.org/drugi.png")), u
    )
    assert serwis.utworz(s, p, lambda: "zdjecie" in api.calls).stan == "Anulowano"
    assert "POST" not in api.calls
    assert repo.odczytaj(serwis.klucz(s, o.sku)) is None


def test_async_202_tylko_po_zakonczeniu_operacji_i_get(nowe_szkice_fixture):
    serwis, api, _, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, u)
    api.async_mode, api.zakonczona = True, False
    assert serwis.utworz(s, p, lambda: False).stan == "Przetwarzanie"
    assert "operacja" not in api.calls
    assert serwis.sprawdz(s, p).stan == "Przetwarzanie"
    api.zakonczona = True
    assert serwis.sprawdz(s, p).stan == "Utworzono szkic"
    assert api.calls.count("POST") == 1


@pytest.mark.parametrize(
    "pole,wartosc",
    [
        ("publication", {"status": "ACTIVE"}),
        ("name", "Inny tytuł"),
        ("images", []),
        ("parameters", []),
        ("category", {"id": "inna"}),
    ],
)
def test_get_musi_potwierdzic_tresc_i_inactive(nowe_szkice_fixture, pole, wartosc):
    serwis, api, _, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, u)
    serwis.utworz(s, p, lambda: False)
    next(iter(api.wyniki.values()))[pole] = wartosc
    with pytest.raises(BladAllegro, match="różni|odpowiada"):
        serwis.sprawdz(s, p)
    assert api.calls.count("POST") == 1


def test_rejestr_wylacznosc_uszkodzenie_i_atomowa_metadana(tmp_path):
    r = RejestrTworzeniaJSON(tmp_path)
    p = ProbaTworzenia("a" * 64, "b" * 64)
    r.rozpocznij("c" * 64, p)
    with pytest.raises(BladAllegro):
        RejestrTworzeniaJSON(tmp_path).rozpocznij("c" * 64, p)
    r.zapisz("c" * 64, replace(p, status=201, ident="123"))
    assert r.odczytaj("c" * 64).ident == "123"
    (tmp_path / ("c" * 64 + ".json")).write_text("broken")
    with pytest.raises(BladAllegro):
        r.odczytaj("c" * 64)
    with pytest.raises(BladAllegro):
        r.odczytaj("../../outside")


class Transport:
    def __init__(self, *odpowiedzi):
        self.odpowiedzi = list(odpowiedzi)
        self.calls = []

    def wyslij(self, *args):
        self.calls.append(args)
        r = self.odpowiedzi.pop(0)
        if isinstance(r, Exception):
            raise r
        return r


def odpowiedz(status, body, location="", retry=0):
    return OdpowiedzAllegro(status, json.dumps(body).encode(), location, retry)


def test_upload_i_create_202_kieruja_na_osobne_hosty_i_nie_loguja_sekretu(nowe_szkice_fixture):
    _, _, _, s, _, _ = nowe_szkice_fixture
    host = "https://api.allegro.pl.allegrosandbox.pl"
    t = Transport(
        odpowiedz(201, {"location": "https://a.allegroimg.com/test.jpg"}),
        odpowiedz(202, {"id": "123"}, host + "/sale/product-offers/123/operations/op", 10),
    )
    api = NoweSzkiceAPI(t)
    api.wyslij_zdjecie(s, "https://images.example.org/photo.jpg")
    p = api.utworz_szkic(s, {"publication": {"status": "INACTIVE"}})
    assert p.status == 202 and p.ident == "123" and p.operacja == "op"
    assert t.calls[0][1] == "https://upload.allegro.pl.allegrosandbox.pl/sale/images"
    assert t.calls[1][1] == host + "/sale/product-offers"
    with pytest.raises(BladAllegro, match="Odczekaj"):
        api.operacja_tworzenia(s, "123", "op")
    assert len(t.calls) == 2


@pytest.mark.parametrize(
    "status,body,location",
    [
        (201, {}, ""),
        (202, {"id": "123"}, "https://evil.invalid/x"),
        (
            202,
            {"id": "123"},
            "https://api.allegro.pl.allegrosandbox.pl/sale/product-offers/999/operations/op",
        ),
        (500, {}, ""),
        (404, {}, ""),
        (409, {}, ""),
        (303, {}, ""),
    ],
)
def test_niejednoznaczne_odpowiedzi_nie_sa_sukcesem(nowe_szkice_fixture, status, body, location):
    _, _, _, s, _, _ = nowe_szkice_fixture
    with pytest.raises(BladAllegro) as e:
        NoweSzkiceAPI(Transport(odpowiedz(status, body, location))).utworz_szkic(s, {})
    assert e.value.kod == "NIEZNANY"


@pytest.mark.parametrize("status", [400, 401, 403, 422, 429])
def test_odrzucenia_sa_jednoznaczne_i_czytelne(nowe_szkice_fixture, status):
    _, _, _, s, _, _ = nowe_szkice_fixture
    with pytest.raises(BladAllegro, match="Brakuje parametru") as e:
        NoweSzkiceAPI(
            Transport(odpowiedz(status, {"errors": [{"userMessage": "Brakuje parametru"}]}))
        ).utworz_szkic(s, {})
    assert e.value.kod == "ODRZUCONO"


@pytest.mark.parametrize(
    "zmiana",
    [
        {"publication": {"status": "ACTIVE"}},
        {"publication": {"status": "INACTIVE", "startingAt": "later"}},
        {"productSet": [{"product": {"id": "abc", "name": "Nowy produkt"}}]},
        {"delivery": {}},
        {"productSet": []},
    ],
)
def test_transport_blokuje_publikacje_i_tworzenie_kartotek_przed_siecia(monkeypatch, zmiana):
    from vexlab.adaptery import allegro_http

    monkeypatch.setattr(allegro_http, "build_opener", lambda *a: pytest.fail("Sieć zabroniona"))
    d = {
        "publication": {"status": "INACTIVE", "republish": False},
        "productSet": [{"product": {"id": "c9e39cae-9cb6-11e9-a2a3-2a2ae2dbcce4"}}],
    }
    d.update(deepcopy(zmiana))
    with pytest.raises(BladAllegro):
        allegro_http.HTTPSAllegro().wyslij(
            "POST", "https://api.allegro.pl/sale/product-offers", {}, json.dumps(d).encode()
        )


def test_zip_przez_rzeczywisty_czytnik_profil_i_kanal_do_szkicu(tmp_path, nowe_szkice_fixture):
    from zipfile import ZipFile

    from vexlab.adaptery.paczki_zip import CzytnikZIP, ProfileJSON
    from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek, ProfilPaczki

    _, api, repo, s, o, u = nowe_szkice_fixture
    zip_path = tmp_path / "gotowe.zip"
    with ZipFile(zip_path, "w") as z:
        z.writestr(
            "dane.json",
            json.dumps(
                [
                    {
                        "sku": o.sku,
                        "tytul": o.tytul,
                        "ean": o.ean,
                        "cena": o.cena,
                        "opis": o.opis,
                        "zdjecia": list(o.zdjecia),
                    }
                ]
            ),
        )
    czytnik = PodgladPaczek(CzytnikZIP(), ProfileJSON())
    oferty = czytnik.przygotuj(
        czytnik.odczytaj(zip_path),
        ProfilPaczki(
            "test",
            "dane.json",
            "sku",
            "tytul",
            opis="opis",
            ean="ean",
            cena="cena",
            zdjecia="zdjecia",
        ),
    )
    assert len(oferty) == 1 and not oferty[0].problemy

    class Kanal:
        def __init__(self):
            self.calls = []
            self.dane = None

        def wyslij(self, metoda, url, naglowki, dane):
            self.calls.append((metoda, url))
            assert naglowki["Authorization"] == "Bearer " + s.token
            if "/sale/products?" in url:
                return odpowiedz(
                    200,
                    {
                        "products": [
                            {
                                "id": api.produkt.id,
                                "name": api.produkt.nazwa,
                                "category": {"id": "123"},
                            }
                        ]
                    },
                )
            if url.endswith("/sale/products/" + api.produkt.id):
                return odpowiedz(
                    200,
                    {"id": api.produkt.id, "name": api.produkt.nazwa, "category": {"id": "123"}},
                )
            if url.endswith("/parameters"):
                return odpowiedz(
                    200,
                    {
                        "parameters": [
                            {
                                "id": "11323",
                                "name": "Stan",
                                "type": "dictionary",
                                "required": True,
                                "options": {"describesProduct": False},
                                "dictionary": [{"id": "11323_1", "value": "Nowy"}],
                            }
                        ]
                    },
                )
            if url.endswith("/sale/images"):
                return odpowiedz(201, {"location": "https://a.allegroimg.com/photo.jpg"})
            if "/sale/offers?" in url:
                return odpowiedz(200, {"offers": [], "totalCount": 0})
            if metoda == "POST":
                self.dane = json.loads(dane)
                assert self.dane["publication"] == {"status": "INACTIVE", "republish": False}
                return odpowiedz(201, {"id": "123"})
            if url.endswith("/sale/product-offers/123"):
                return odpowiedz(200, {**self.dane, "id": "123"})
            pytest.fail("Nieprzewidziana operacja: " + url)

    transport = Kanal()
    serwis = NoweSzkiceAllegro(NoweSzkiceAPI(transport), repo, api)
    p = serwis.przygotuj(s, oferty[0], u)
    assert not p.bledy
    assert serwis.utworz(s, p, lambda: False).stan == "Utworzono szkic"
    assert sum(method == "POST" for method, url in transport.calls) == 2
    assert zip_path.exists() and not list(tmp_path.glob("*.sqlite*"))


def test_awaria_metadanych_po_post_nie_zwalnia_rezerwacji(nowe_szkice_fixture, monkeypatch):
    serwis, api, repo, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, u)
    monkeypatch.setattr(
        repo,
        "zapisz",
        lambda *a: (_ for _ in ()).throw(BladAllegro("REJESTR", "Awaria metadanych")),
    )
    with pytest.raises(BladAllegro, match="metadanych"):
        serwis.utworz(s, p, lambda: False)
    assert serwis.utworz(s, p, lambda: False).stan == "Wymaga sprawdzenia"
    assert api.calls.count("POST") == 1


def test_ostrzezenia_i_braki_publikacji_z_get_sa_w_raporcie(nowe_szkice_fixture):
    serwis, api, _, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, u)
    serwis.utworz(s, p, lambda: False)
    next(iter(api.wyniki.values()))["validation"] = {
        "errors": [{"userMessage": "Brak danych GPSR"}]
    }
    wynik = serwis.sprawdz(s, p)
    assert wynik.stan == "Szkic do poprawy" and "GPSR" in wynik.komunikat


def test_swiezy_preflight_blokuje_zmiane_wymagan_przed_zdjeciami(nowe_szkice_fixture):
    serwis, api, _, s, o, u = nowe_szkice_fixture
    p = serwis.przygotuj(s, o, u)
    api.produkt = replace(api.produkt, kategoria="999")
    with pytest.raises(BladAllegro, match="zmieniły"):
        serwis.utworz(s, p, lambda: False)
    assert "POST" not in api.calls and "zdjecie" not in api.calls


@pytest.mark.parametrize("upload", [False, True])
def test_transport_dopuszcza_prawidlowy_szkic_i_upload(monkeypatch, upload):
    from vexlab.adaptery import allegro_http

    calls = []

    class Response:
        code = 201
        headers = {}

        def __enter__(self):
            return self

        def __exit__(self, *a):
            pass

        def read(self, n):
            return b'{"id":"123"}'

    class Opener:
        def open(self, req, timeout):
            calls.append(req)
            return Response()

    monkeypatch.setattr(allegro_http, "build_opener", lambda *a: Opener())
    if upload:
        url = "https://upload.allegro.pl/sale/images"
        d = {"url": "https://images.example.org/photo.jpg"}
    else:
        url = "https://api.allegro.pl/sale/product-offers"
        d = {
            "publication": {"status": "INACTIVE", "republish": False},
            "productSet": [{"product": {"id": "c9e39cae-9cb6-11e9-a2a3-2a2ae2dbcce4"}}],
        }
    assert allegro_http.HTTPSAllegro().wyslij("POST", url, {}, json.dumps(d).encode()).status == 201
    assert len(calls) == 1 and calls[0].get_method() == "POST"
