from dataclasses import replace
from uuid import uuid4

import pytest

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.zdjecia_lokalne import LokalneZdjecia
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.galeria import GaleriaDTO, GaleriaProduktow
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.media import ZdjecieDane


def test_lista_bez_blobow_i_odczyt_tylko_wskazanych_aktualnych_wersji(tmp_path, monkeypatch):
    repo = KatalogSQLite(tmp_path / "test.sqlite3")
    katalog = KatalogProduktow(repo, repo)
    a = katalog.dodaj(DaneProduktu("A", "A"), (ZdjecieDane("a", b"pelne-a", b"mini-a"),))
    b = katalog.dodaj(DaneProduktu("B", "B"), (ZdjecieDane("b", b"pelne-b", b"mini-b"),))
    c = katalog.dodaj(DaneProduktu("C", "C"))

    def zakaz():
        raise AssertionError("Lista nie może pobierać wszystkich miniatur")

    monkeypatch.setattr(repo, "miniatury", zakaz)
    lista = katalog.odczytaj(z_miniaturami=False).produkty
    assert all(p.miniatura is None for p in lista)
    assert {p.id for p in lista if p.ma_zdjecia} == {a.id, b.id}
    assert katalog.pobierz_miniatury(((a.id, a.wersja), (c.id, c.wersja))) == {a.id: b"mini-a"}
    assert katalog.pobierz_miniatury(((uuid4(), 1),)) == {}
    galeria = GaleriaProduktow(repo, LokalneZdjecia())
    galeria.zapisz(
        replace(GaleriaDTO(a.id, a.wersja, ()), zdjecia=(ZdjecieDane("n", b"n", b"nowa"),))
    )
    assert katalog.pobierz_miniatury(((a.id, a.wersja),)) == {}
    assert katalog.pobierz_miniatury(((a.id, a.wersja + 1),)) == {a.id: b"nowa"}
    assert katalog.pobierz_miniatury(()) == {}


def test_partia_ma_limit_i_nie_dopuszcza_powtorzen(tmp_path):
    repo = KatalogSQLite(tmp_path / "test.sqlite3")
    katalog = KatalogProduktow(repo, repo)
    with pytest.raises(BladScenariuszaKatalogu):
        katalog.pobierz_miniatury(tuple((uuid4(), 1) for _ in range(33)))
    pid = uuid4()
    with pytest.raises(BladScenariuszaKatalogu):
        katalog.pobierz_miniatury(((pid, 1), (pid, 2)))
    assert not repo.plik.exists()
