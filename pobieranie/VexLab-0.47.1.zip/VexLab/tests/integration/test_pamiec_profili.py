import json
from dataclasses import replace
from zipfile import ZipFile

import pytest

from vexlab.adaptery.paczki_zip import CzytnikZIP, ProfileJSON
from vexlab.adaptery.pamiec_profili import PamiecProfiliJSON
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.paczki_ofert import PodgladPaczek, ProfilPaczki


def profil():
    return ProfilPaczki(
        "Mój układ",
        "oferty.json",
        "kod",
        "tytul",
        sekcje="uklad",
        lista_elementow="bloki",
        typ_elementu="rodzaj",
        tresc_elementu="tekst",
        adres_elementu="adres",
        typ_tekstu="tekst",
        typ_obrazu="obraz",
    )


def rekord():
    return {
        "kod": "TEST",
        "tytul": "Gotowa oferta",
        "uklad": [{"bloki": [{"rodzaj": "tekst", "tekst": "<p>Opis</p>"}]}],
    }


def paczka(tmp_path, nazwa="oferty.json", dane=None):
    plik = tmp_path / "dane.zip"
    with ZipFile(plik, "w") as z:
        z.writestr(nazwa, json.dumps([rekord() if dane is None else dane]))
    return CzytnikZIP().odczytaj(plik)


def case(tmp_path):
    return PodgladPaczek(CzytnikZIP(), ProfileJSON(), PamiecProfiliJSON(tmp_path / "profile"))


def test_zapamietanie_restart_i_rozpoznanie_bez_pliku_profili(tmp_path):
    c = case(tmp_path)
    p = paczka(tmp_path)
    assert c.rozpoznaj(p) == ()
    assert not (tmp_path / "profile").exists()
    wynik = c.podglad_z_pamiecia(p, profil())
    assert len(wynik.oferty) == 1 and "Zapamiętany" in wynik.informacja
    drugi = case(tmp_path)
    inne = paczka(tmp_path, "inny-katalog/nowa-nazwa.json", rekord() | {"kod": "INNY-PRODUCENT"})
    rozpoznane = drugi.rozpoznaj(inne)
    assert len(rozpoznane) == 1 and rozpoznane[0].plik == "inny-katalog/nowa-nazwa.json"
    assert drugi.przygotuj(inne, rozpoznane[0])[0].sku == "INNY-PRODUCENT"


def test_ten_sam_format_nie_nadpisuje_nazwy_i_nie_dubluje_ustawien(tmp_path):
    c = case(tmp_path)
    p = paczka(tmp_path)
    c.podglad_z_pamiecia(p, profil())
    (plik,) = (tmp_path / "profile").glob("*.json")
    przed = plik.read_bytes()
    c.podglad_z_pamiecia(p, replace(profil(), nazwa="Inna nazwa"))
    assert plik.read_bytes() == przed and len(c.pamiec.lista()) == 1


@pytest.mark.parametrize(
    "dane",
    [
        rekord() | {"dodatkowe_pole": "inne"},
        rekord() | {"uklad": [{"inne_bloki": []}]},
        rekord() | {"uklad": [{"bloki": [{"rodzaj": "nowy-typ", "tekst": "x"}]}]},
    ],
)
def test_zmiana_struktury_nie_jest_rozpoznawana_na_sile(tmp_path, dane):
    c = case(tmp_path)
    c.podglad_z_pamiecia(paczka(tmp_path), profil())
    assert c.rozpoznaj(paczka(tmp_path, dane=dane)) == ()


def test_dwie_prezentacje_tego_samego_formatu_daja_wybor(tmp_path):
    c = case(tmp_path)
    p = paczka(tmp_path, dane=rekord() | {"drugi_tytul": "Inna oferta"})
    c.podglad_z_pamiecia(p, profil())
    c.podglad_z_pamiecia(p, replace(profil(), nazwa="Drugi układ", tytul="drugi_tytul"))
    assert {x.nazwa for x in c.rozpoznaj(p)} == {"Mój układ", "Drugi układ"}


def test_uszkodzona_pamiec_nie_jest_resetowana_i_nie_blokuje_podgladu(tmp_path):
    c = case(tmp_path)
    p = paczka(tmp_path)
    c.podglad_z_pamiecia(p, profil())
    (plik,) = (tmp_path / "profile").glob("*.json")
    plik.write_text("uszkodzony plik", encoding="utf-8")
    with pytest.raises(BladScenariuszaKatalogu, match="odczytać"):
        c.rozpoznaj(p)
    wynik = c.podglad_z_pamiecia(p, profil())
    assert len(wynik.oferty) == 1 and "nie udało" in wynik.informacja
    assert plik.read_text() == "uszkodzony plik"


def test_awaria_zapisu_nie_niszczy_innych_ustawien_i_sprzata_tmp(tmp_path, monkeypatch):
    import vexlab.adaptery.pamiec_profili as adapter

    c = case(tmp_path)
    p = paczka(tmp_path)
    c.podglad_z_pamiecia(p, profil())
    (plik,) = (tmp_path / "profile").glob("*.json")
    przed = plik.read_bytes()
    inne = paczka(tmp_path, dane=rekord() | {"nowe": "pole"})

    def awaria(*a):
        raise OSError("Brak miejsca")

    monkeypatch.setattr(adapter.os, "replace", awaria)
    wynik = c.podglad_z_pamiecia(inne, profil())
    assert "nie udało" in wynik.informacja and len(wynik.oferty) == 1
    assert plik.read_bytes() == przed
    assert not list((tmp_path / "profile").glob("*.tmp"))


def test_usuwanie_ukladu_nie_zmienia_paczki(tmp_path):
    c = case(tmp_path)
    p = paczka(tmp_path)
    c.podglad_z_pamiecia(p, profil())
    c.zapomnij(p, profil())
    assert c.rozpoznaj(p) == ()
    assert c.przygotuj(p, profil())[0].sku == "TEST"
