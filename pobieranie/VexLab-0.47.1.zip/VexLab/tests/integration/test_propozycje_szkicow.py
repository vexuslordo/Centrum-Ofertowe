import json
from dataclasses import replace

import pytest

from vexlab.adaptery.propozycje_szkicow_json import LIMIT, PropozycjeJSON
from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StatusOfertyAllegro,
    SzczegolySzkicuAllegro,
)
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu
from vexlab.przypadki_uzycia.propozycje_szkicow import PropozycjeSzkicow
from vexlab.rdzen.kontrakty import BladTechniczny


def dane():
    s = SesjaAllegro(
        KontoAllegro("1", "fixture"),
        SrodowiskoAllegro.SANDBOX,
        "access-nigdy-do-pliku",
        5000,
        "refresh-nigdy-do-pliku",
    )
    d = SzczegolySzkicuAllegro(
        "123",
        "Tytuł źródłowy",
        "SKU",
        "10",
        "PLN",
        1,
        "1",
        (),
        ((ElementPodgladu("tekst", "<p>Źródło &amp; <b>tekst</b></p>"),),),
    )
    return s, d


def test_plik_propozycji_roundtrip_bez_sekretow_i_bez_nadpisania(tmp_path):
    s, d = dane()
    serwis = PropozycjeSzkicow(PropozycjeJSON())
    baza = serwis.rozpocznij(s, d)
    nowa = serwis.zmien(baza, "Proponowany tytuł", baza.sekcje)
    cel = tmp_path / "propozycja.json"
    serwis.zapisz(cel, nowa)
    assert serwis.wczytaj(cel, baza) == nowa
    tekst = cel.read_text()
    assert s.token not in tekst and s.odswiezanie not in tekst
    assert nowa.tytul_bazowy == d.tytul and nowa.sekcje_bazowe == d.sekcje
    with pytest.raises(BladTechniczny, match="już istnieje"):
        serwis.zapisz(cel, baza)
    assert serwis.wczytaj(cel, baza) == nowa


def test_sprawdzenie_konfliktu_nie_modyfikuje_propozycji():
    s, d = dane()
    serwis = PropozycjeSzkicow(PropozycjeJSON())
    p = serwis.zmien(serwis.rozpocznij(s, d), "Moja propozycja", d.sekcje)
    serwis.sprawdz_aktualnosc(p, replace(d, cena="20"))
    with pytest.raises(BladAllegro) as exc:
        serwis.sprawdz_aktualnosc(p, replace(d, tytul="Ktoś zmienił w Allegro"))
    assert exc.value.kod == "KONFLIKT" and p.tytul == "Moja propozycja"
    with pytest.raises(BladAllegro) as exc:
        serwis.sprawdz_aktualnosc(p, replace(d, status=StatusOfertyAllegro.AKTYWNA))
    assert exc.value.kod == "STAN"


@pytest.mark.parametrize(
    "zmiana",
    [
        {"konto_id": "2"},
        {"oferta_id": "124"},
        {"srodowisko": SrodowiskoAllegro.PRODUKCJA},
        {"tytul_bazowy": "Inna baza"},
    ],
)
def test_nie_wczytuje_propozycji_innego_konta_lub_bazy(tmp_path, zmiana):
    s, d = dane()
    serwis = PropozycjeSzkicow(PropozycjeJSON())
    baza = serwis.rozpocznij(s, d)
    cel = tmp_path / "inna.json"
    serwis.zapisz(cel, replace(baza, **zmiana))
    with pytest.raises(BladAllegro):
        serwis.wczytaj(cel, baza)
    assert baza.tytul == d.tytul


@pytest.mark.parametrize(
    "dane", [b"{}", b"[[]]", b'{"format":1,"format":2}', b"[" * 2000, b"x" * (LIMIT + 1)]
)
def test_bledny_lub_nadmierny_plik_ma_jawny_blad(tmp_path, dane):
    plik = tmp_path / "blad.json"
    plik.write_bytes(dane)
    with pytest.raises(BladTechniczny):
        PropozycjeJSON().odczytaj(plik)


def test_odrzuca_niebezpieczny_adres_i_nadmiarowe_pola(tmp_path):
    s, d = dane()
    serwis = PropozycjeSzkicow(PropozycjeJSON())
    baza = serwis.rozpocznij(s, d)
    with pytest.raises(BladAllegro):
        serwis.zmien(baza, "Tytuł", ((ElementPodgladu("obraz", adres="file:///sekret"),),))
    cel = tmp_path / "p.json"
    serwis.zapisz(cel, baza)
    obj = json.loads(cel.read_text())
    obj["propozycja"]["token"] = "obce-pole"
    cel.write_text(json.dumps(obj))
    with pytest.raises(BladTechniczny):
        serwis.wczytaj(cel, baza)


def test_tylko_szkic_moze_byc_zrodlem_propozycji():
    s, d = dane()
    with pytest.raises(BladAllegro):
        PropozycjeSzkicow.rozpocznij(s, replace(d, status=StatusOfertyAllegro.AKTYWNA))


def test_przerwany_zapis_nie_zostawia_gotowego_pliku(tmp_path, monkeypatch):
    from pathlib import Path

    s, d = dane()
    p = PropozycjeSzkicow.rozpocznij(s, d)
    cel = tmp_path / "przerwany.json"
    oryginalne_open = Path.open

    class PrzerwanyPlik:
        def __enter__(self):
            self.plik = oryginalne_open(cel, "xb")
            return self

        def write(self, dane):
            self.plik.write(dane[:10])
            raise OSError("Awaria fixture")

        def __exit__(self, *args):
            self.plik.close()

    def otworz(path, *args, **kwargs):
        return PrzerwanyPlik() if path == cel else oryginalne_open(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", otworz)
    with pytest.raises(BladTechniczny, match="Nie udało"):
        PropozycjeJSON().zapisz(cel, p)
    assert not cel.exists()
