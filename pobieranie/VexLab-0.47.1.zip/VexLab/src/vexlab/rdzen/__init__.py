"""Minimalne kontrakty techniczne niezależne od domeny i infrastruktury."""
