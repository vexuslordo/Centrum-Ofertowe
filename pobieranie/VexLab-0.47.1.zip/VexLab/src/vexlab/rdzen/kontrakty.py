"""Zegar, korelacja diagnostyczna i bezpieczny błąd techniczny."""

from datetime import datetime
from typing import NewType, Protocol
from uuid import UUID

IdKorelacji = NewType("IdKorelacji", UUID)


class Zegar(Protocol):
    """Dostarcza jednoznaczną chwilę z informacją o strefie czasowej."""

    def teraz(self) -> datetime: ...


class BladTechniczny(RuntimeError):
    """Bezpieczny komunikat techniczny, bez sekretów i danych użytkownika."""
