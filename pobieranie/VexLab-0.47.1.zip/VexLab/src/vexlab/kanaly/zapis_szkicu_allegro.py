"""Kontrakt PATCH i status operacji według dostarczonego Swagger Allegro."""

import json
import re
import time
from urllib.parse import urlsplit

from vexlab.kanaly.allegro import AllegroAPI, hosty
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro, TransportAllegro
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import PrzyjecieZapisu


class ZapisSzkicuAPI(AllegroAPI):
    def __init__(self, transport: TransportAllegro) -> None:
        super().__init__(transport)
        self.transport_zapisu = transport
        self.odczekaj: dict[tuple[str, str], float] = {}

    @staticmethod
    def _sciezka(ident: str) -> str:
        if not re.fullmatch(r"[0-9]{1,100}", ident):
            raise BladAllegro("ADRES", "Nieprawidłowy identyfikator szkicu.")
        return "/sale/product-offers/" + ident

    @staticmethod
    def _naglowki(s: SesjaAllegro) -> dict[str, str]:
        return {
            "Authorization": "Bearer " + s.token,
            "Accept": "application/vnd.allegro.public.v1+json",
            "Content-Type": "application/vnd.allegro.public.v1+json",
        }

    def zmien_szkic(
        self, sesja: SesjaAllegro, ident: str, pola: dict[str, object]
    ) -> PrzyjecieZapisu:
        sygnatura = pola.get("external")
        tylko_sku = (
            set(pola) == {"external"}
            and isinstance(sygnatura, dict)
            and set(sygnatura) == {"id"}
            and isinstance(sygnatura["id"], str)
            and 0 < len(sygnatura["id"]) <= 100
        )
        if not tylko_sku and (not pola or not set(pola) <= {"name", "description"}):
            raise BladAllegro("POLA", "Dozwolone tytuł/opis albo osobna zmiana sygnatury szkicu.")
        _, host = hosty(sesja.srodowisko)
        sciezka = self._sciezka(ident)
        try:
            r = self.transport_zapisu.wyslij(
                "PATCH",
                host + sciezka,
                self._naglowki(sesja),
                json.dumps(pola, ensure_ascii=False).encode(),
            )
        except BladAllegro:
            raise BladAllegro(
                "NIEZNANY",
                "Nie potwierdzono wyniku zapisu. Użyj sprawdzenia wyniku, nie ponawiaj wysyłki.",
            ) from None
        if r.status in {400, 401, 403, 404, 409, 422, 429}:
            komunikaty = {
                400: "Allegro odrzuciło dane zapisu (400).",
                401: "Sesja wygasła (401). Połącz konto ponownie.",
                403: (
                    "Brak zgody na zapis (403). Włącz allegro:api:sale:offers:write "
                    "i połącz konto ponownie."
                ),
                404: "Szkic nie jest dostępny (404).",
                409: "Allegro blokuje edycję w bieżącym stanie lub przetwarza inną zmianę (409).",
                422: "Allegro odrzuciło tytuł lub opis (422). Sprawdź treść i dopuszczalny HTML.",
                429: "Limit zapisów Allegro (429). Odczekaj przed kolejną jawną próbą.",
            }
            raise BladAllegro("ODRZUCONO", komunikaty[r.status])
        if r.status == 200:
            return PrzyjecieZapisu()
        if r.status == 202:
            self.odczekaj[(sesja.srodowisko.value, ident)] = time.monotonic() + r.odstep
            try:
                u = urlsplit(r.lokalizacja)
            except ValueError:
                raise BladAllegro(
                    "NIEZNANY", "Nieprawidłowy adres operacji. Sprawdź wynik później."
                ) from None
            if (
                u.scheme != "https"
                or u.netloc != urlsplit(host).netloc
                or u.query
                or u.fragment
                or not re.fullmatch(re.escape(sciezka) + r"/operations/[A-Za-z0-9-]{1,100}", u.path)
            ):
                raise BladAllegro(
                    "NIEZNANY",
                    "Przyjęto zapis, ale brak prawidłowego adresu operacji. Sprawdź wynik później.",
                )
            return PrzyjecieZapisu(u.path.rsplit("/", 1)[1])
        raise BladAllegro(
            "NIEZNANY", "Nieznany wynik zapisu Allegro. Sprawdź wynik, nie wysyłaj ponownie."
        )

    def operacja_szkicu(self, sesja: SesjaAllegro, ident: str, operacja: str) -> bool:
        klucz = (sesja.srodowisko.value, ident)
        if time.monotonic() < self.odczekaj.get(klucz, 0):
            raise BladAllegro(
                "PRZETWARZANIE", "Odczekaj zgodnie z Retry-After Allegro przed sprawdzeniem wyniku."
            )
        if not re.fullmatch(r"[A-Za-z0-9-]{1,100}", operacja):
            raise BladAllegro("ADRES", "Nieprawidłowy identyfikator operacji.")
        _, host = hosty(sesja.srodowisko)
        sciezka = self._sciezka(ident)
        r = self.transport_zapisu.wyslij(
            "GET", host + sciezka + "/operations/" + operacja, self._naglowki(sesja), None
        )
        if r.status == 303:
            # Nigdy nie podążamy automatycznie za przekierowaniem.
            if r.lokalizacja != host + sciezka:
                raise BladAllegro(
                    "ODPOWIEDZ", "Nieprawidłowy adres wyniku operacji. Zachowano blokadę."
                )
            return True
        if r.status == 202:
            self.odczekaj[klucz] = time.monotonic() + r.odstep
            return False
        raise BladAllegro(
            "NIEZNANY", "Nie potwierdzono zakończenia operacji. Zachowano blokadę zapisu."
        )
