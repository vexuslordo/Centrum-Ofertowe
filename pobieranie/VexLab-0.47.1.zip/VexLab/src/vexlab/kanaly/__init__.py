"""Miejsce na przyszłe konektory; nie ma jeszcze połączeń z platformami."""
