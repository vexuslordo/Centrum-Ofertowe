"""Mapowanie GET metadanych podatkowych, bez wyznaczania stawek za użytkownika."""

import re
from typing import Any

from vexlab.kanaly.allegro import tekst
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.vat_allegro import OpcjaVAT, VATKategorii, normalizuj_vat


def mapuj_vat(d: dict[str, Any], kategoria: str) -> VATKategorii:
    try:
        kraje = []
        rows = d.get("rates", [])
        if not isinstance(rows, list) or len(rows) > 32:
            raise ValueError("rates")
        for row in rows:
            country = tekst(row, "countryCode", 2)
            if not re.fullmatch(r"[A-Z]{2}", country):
                raise ValueError("country")
            values = row["values"]
            if not isinstance(values, list) or len(values) > 100:
                raise ValueError("values")
            rates = []
            for r in values:
                if "value" in r and r["value"] is None:
                    continue  # Allegro dodaje pozycję interfejsu „Wybierz”.
                flag = r.get("exemptionRequired", False)
                if type(flag) is not bool:
                    raise ValueError("exemption")
                value = tekst(r, "value")
                if value == "OUT_OF_SCOPE_OF_VAT":
                    value = "0"  # OfferTaxRate: poza VAT jest przesyłane jako 0.
                rates.append(OpcjaVAT(normalizuj_vat(value), tekst(r, "label"), flag))
            kraje.append((country, tuple(rates)))
        if len({c for c, _ in kraje}) != len(kraje):
            raise ValueError("duplicate")

        def options(key: str) -> tuple[tuple[str, str], ...]:
            values = d.get(key, [])
            if not isinstance(values, list) or len(values) > 100:
                raise ValueError(key)
            result = tuple(
                (tekst(v, "value"), tekst(v, "label"))
                for v in values
                if not ("value" in v and v["value"] is None)
            )
            if len(dict(result)) != len(result):
                raise ValueError("duplicate")
            return result

        return VATKategorii(kategoria, tuple(kraje), options("subjects"), options("exemptions"))
    except (KeyError, ValueError, TypeError, AttributeError, BladAllegro):
        raise BladAllegro(
            "ODPOWIEDZ", "Niepełna lub niepoprawna lista stawek VAT Allegro."
        ) from None
