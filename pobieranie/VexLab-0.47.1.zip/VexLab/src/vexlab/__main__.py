"""Uruchomienie jawnej diagnostyki technicznej przez python -m."""

from vexlab.bootstrap import main

raise SystemExit(main())
