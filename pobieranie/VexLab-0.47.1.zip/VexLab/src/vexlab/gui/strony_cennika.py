"""Tabela źródłowych pozycji, wybór wszystkich wyników niezależny od strony."""

from collections.abc import Callable

from PySide6.QtGui import QKeyEvent, QMouseEvent
from PySide6.QtWidgets import QAbstractItemView, QHeaderView, QTableWidget

from vexlab.gui.wybor_tabeli import wybor_klawiatura, wybor_mysza


class TabelaPozycji(QTableWidget):
    def __init__(
        self, naglowki: list[str], wszystkie: Callable[[], None], odznacz: Callable[[], None]
    ) -> None:
        super().__init__(0, len(naglowki))
        self.wszystkie, self.odznacz = wszystkie, odznacz
        self.setHorizontalHeaderLabels(naglowki)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.horizontalHeader().setStretchLastSection(True)

    def selectAll(self) -> None:
        self.wszystkie()

    def clearSelection(self) -> None:
        self.odznacz()

    def mousePressEvent(self, event: QMouseEvent) -> None:
        wybor_mysza(self, event, self.odznacz)
        super().mousePressEvent(event)

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if not wybor_klawiatura(event, self.odznacz):
            super().keyPressEvent(event)
