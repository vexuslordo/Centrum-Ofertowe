"""Wspólne gesty wyboru obejmującego również inne strony tabeli."""

from collections.abc import Callable

from PySide6.QtCore import QModelIndex, Qt
from PySide6.QtGui import QKeyEvent, QMouseEvent
from PySide6.QtWidgets import QTableView


def wybor_mysza(tabela: QTableView, event: QMouseEvent, wyczysc: Callable[[], None]) -> None:
    indeks = tabela.indexAt(event.position().toPoint())
    bez_modyfikatorow = not event.modifiers() & (
        Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier
    )
    if bez_modyfikatorow and (
        event.button() == Qt.MouseButton.LeftButton
        or (
            event.button() == Qt.MouseButton.RightButton
            and not tabela.selectionModel().isRowSelected(indeks.row(), QModelIndex())
        )
    ):
        wyczysc()


def wybor_klawiatura(event: QKeyEvent, wyczysc: Callable[[], None]) -> bool:
    if event.key() == Qt.Key.Key_Escape:
        wyczysc()
        event.accept()
        return True
    if (
        event.key()
        in (
            Qt.Key.Key_Up,
            Qt.Key.Key_Down,
            Qt.Key.Key_Home,
            Qt.Key.Key_End,
            Qt.Key.Key_PageUp,
            Qt.Key.Key_PageDown,
        )
        and not event.modifiers()
    ):
        wyczysc()
    return False
