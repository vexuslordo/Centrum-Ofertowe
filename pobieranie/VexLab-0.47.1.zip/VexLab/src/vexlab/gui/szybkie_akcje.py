"""Edycja listy skrótów bez zapisu przed akceptacją."""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDialogButtonBox,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.przypadki_uzycia.szybkie_akcje import AKCJE, DOMYSLNE_AKCJE


class EdytorSzybkichAkcji(QDialog):
    def __init__(self, wybrane: tuple[str, ...], parent: QWidget) -> None:
        super().__init__(parent)
        self.setWindowTitle("Szybkie akcje")
        self.resize(430, 560)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Zaznacz skróty i przeciągnij je, aby ustawić kolejność."))
        self.lista = QListWidget()
        self.lista.setAccessibleName("Skróty — wybór i kolejność")
        self.lista.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        layout.addWidget(self.lista, 1)
        self.blad = QLabel("")
        self.blad.setWordWrap(True)
        layout.addWidget(self.blad)
        self.domyslne = QPushButton("Przywróć domyślne")
        self.domyslne.clicked.connect(lambda: self.wypelnij(DOMYSLNE_AKCJE))
        layout.addWidget(self.domyslne)
        self.przyciski = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        self.przyciski.button(QDialogButtonBox.StandardButton.Save).setText("Zapisz")
        self.przyciski.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        self.przyciski.rejected.connect(self.reject)
        layout.addWidget(self.przyciski)
        self.wypelnij(wybrane)

    def wypelnij(self, wybrane: tuple[str, ...]) -> None:
        self.lista.clear()
        mapa = {a.id: a for a in AKCJE}
        for id in (*wybrane, *(a.id for a in AKCJE if a.id not in wybrane)):
            a = mapa[id]
            item = QListWidgetItem(a.nazwa + (" — w przygotowaniu" if not a.dostepna else ""))
            item.setData(Qt.ItemDataRole.UserRole, id)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked if id in wybrane else Qt.CheckState.Unchecked)
            self.lista.addItem(item)

    def wynik(self) -> tuple[str, ...]:
        return tuple(
            str(self.lista.item(i).data(Qt.ItemDataRole.UserRole))
            for i in range(self.lista.count())
            if self.lista.item(i).checkState() == Qt.CheckState.Checked
        )
