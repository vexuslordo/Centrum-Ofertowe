"""Powłoka PySide6 i lokalny katalog; pełny odbiór UI-REF-01 pozostaje otwarty."""
