"""Spokojny wzorzec przestrzeni Allegro; odczyty i edycja szkiców."""

from functools import partial

from PySide6.QtCore import (
    QDateTime,
    QEvent,
    QModelIndex,
    QPersistentModelIndex,
    QSize,
    Qt,
    QTimer,
    Signal,
)
from PySide6.QtGui import QColor, QGuiApplication, QPainter, QPalette, QResizeEvent, QShowEvent
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMenu,
    QPushButton,
    QSplitter,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionViewItem,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona, ikona_menu
from vexlab.gui.podglad_oferty import ObrazyOferty
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.gui.widoki_katalogu import NaglowekWyboru
from vexlab.przypadki_uzycia.allegro import (
    LicznikiAllegro,
    StatusOfertyAllegro,
    StronaSzkicowAllegro,
    SzczegolySzkicuAllegro,
)
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec

ETYKIETY_STATUSOW = {
    StatusOfertyAllegro.SZKIC: "Szkic",
    StatusOfertyAllegro.AKTYWNA: "Aktywna",
    StatusOfertyAllegro.AKTYWOWANA: "Aktywowanie",
    StatusOfertyAllegro.ZAKONCZONA: "Zakończona",
}
OPIS_ODCZYTU = (
    "Edycja tytułu i opisu jest dostępna dla szkiców. Zapis wymaga zgody konta. "
    "Publikacja będzie osobną, potwierdzaną akcją."
)


def przycisk(nazwa: str, symbol: str = "", dostepny: bool = True) -> QPushButton:
    b = QPushButton(nazwa)
    b.setProperty("akcjaAllegro", True)
    if symbol:
        b.setIcon(ikona(symbol, "#96B9DB"))
        b.setIconSize(QSize(16, 16))
    b.setEnabled(dostepny)
    b.setAccessibleName(nazwa)
    if not dostepny:
        b.setToolTip("Działanie będzie dostępne po wdrożeniu odpowiedniej operacji Allegro API.")
    return b


class DelegatStatusuAllegro(QStyledItemDelegate):
    """Kolor statusu pozostaje widoczny również na zaznaczonym wierszu."""

    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex | QPersistentModelIndex,
    ) -> None:
        opcja = QStyleOptionViewItem(option)
        self.initStyleOption(opcja, index)
        tekst = opcja.text
        opcja.text = ""
        styl = opcja.widget.style() if opcja.widget is not None else QApplication.style()
        styl.drawControl(QStyle.ControlElement.CE_ItemViewItem, opcja, painter, opcja.widget)
        painter.save()
        painter.setFont(opcja.font)
        painter.setPen(opcja.palette.color(QPalette.ColorRole.Text))
        prostokat = opcja.rect.adjusted(6, 0, -6, 0)
        tekst = opcja.fontMetrics.elidedText(tekst, Qt.TextElideMode.ElideRight, prostokat.width())
        painter.drawText(
            prostokat, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, tekst
        )
        painter.restore()


class ObszarAllegro(QWidget):
    ustawienia = Signal()
    nowa = Signal()
    szczegoly = Signal()
    edytuj_propozycje = Signal()
    pomoc = Signal()
    status_zadany = Signal(object)

    def __init__(
        self,
        tabela: QTableWidget,
        status: QLabel,
        odswiez: QPushButton,
        podglad: QPushButton,
        poprzednia: QPushButton,
        nastepna: QPushButton,
        zakres: QLabel,
        zdjecia: PodgladZdjec | None,
        uruchom: Uruchom,
    ) -> None:
        super().__init__()
        self.tabela, self.zdjecia, self.uruchom = tabela, zdjecia, uruchom
        self.obrazy = ObrazyOferty(self, zdjecia, uruchom)
        self.obrazy_tabeli = ObrazyOferty(self, zdjecia, uruchom, miniatury=True)
        self._zdjecia_wierszy: dict[str, str] = {}
        self._statusy_wierszy: dict[str, StatusOfertyAllegro] = {}
        self.status_listy: StatusOfertyAllegro | None = StatusOfertyAllegro.SZKIC
        self._miniatury: set[str] = set()
        self.propozycje_dostepne = False
        self._opcje_filtrow: list[QWidget] = []
        self._statystyki: list[QWidget] = []
        self._tryby: list[QWidget] = []
        self.timer_miniatur = QTimer(self)
        self.timer_miniatur.setSingleShot(True)
        self.timer_miniatur.timeout.connect(self._miniatury_widoczne)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)
        layout.addLayout(self._naglowek(status))
        layout.addLayout(self._metryki())
        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.addWidget(self._lista(odswiez, poprzednia, nastepna, zakres))
        self.splitter.addWidget(self._panel_szczegolow(podglad))
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setSizes([850, 280])
        layout.addWidget(self.splitter, 1)

    def _kolor_statusu(self, status: StatusOfertyAllegro) -> QColor:
        ciemny = self.palette().color(QPalette.ColorRole.Window).lightness() < 128
        kolory = {
            StatusOfertyAllegro.SZKIC: ("#F4CE64", "#805B00"),
            StatusOfertyAllegro.AKTYWNA: ("#49D78C", "#13713D"),
            StatusOfertyAllegro.ZAKONCZONA: ("#FF858B", "#BA2535"),
            StatusOfertyAllegro.AKTYWOWANA: ("#75BCFF", "#1765AC"),
        }
        return QColor(kolory[status][0 if ciemny else 1])

    def _odswiez_kolory_statusow(self) -> None:
        for row in range(self.tabela.rowCount()):
            ident, item = self.tabela.item(row, 0), self.tabela.item(row, 7)
            status = self._statusy_wierszy.get(ident.text()) if ident is not None else None
            if item is not None and status is not None:
                item.setForeground(self._kolor_statusu(status))
        status_panelu = self.status_oferty.property("statusAllegro")
        if isinstance(status_panelu, StatusOfertyAllegro):
            self.status_oferty.setStyleSheet(f"color:{self._kolor_statusu(status_panelu).name()};")

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.PaletteChange and hasattr(self, "status_oferty"):
            self._odswiez_kolory_statusow()

    def _naglowek(self, status: QLabel) -> QHBoxLayout:
        head = QHBoxLayout()
        znak = QLabel()
        znak.setPixmap(ikona_menu("Allegro", True).pixmap(42, 42))
        head.addWidget(znak)
        opis = QVBoxLayout()
        top = QHBoxLayout()
        title = etykieta("Allegro")
        title.setObjectName("tytulStronyAllegro")
        top.addWidget(title)
        self._opis_naglowka = QLabel("Oferty i szkice na Twoim koncie")
        self._opis_naglowka.setObjectName("opisAllegro")
        top.addWidget(self._opis_naglowka)
        top.addStretch()
        opis.addLayout(top)
        info = QHBoxLayout()
        self.konto = etykieta("Konto: —")
        self.konto.setWordWrap(False)
        info.addWidget(self.konto)
        info.addWidget(status, 1)
        self.ostatni = etykieta("Ostatni odczyt: —")
        self.ostatni.setObjectName("opisAllegro")
        self.ostatni.setWordWrap(False)
        info.addWidget(self.ostatni)
        opis.addLayout(info)
        head.addLayout(opis, 1)
        config = przycisk("Ustawienia połączenia", "ustawienia")
        config.clicked.connect(self.ustawienia.emit)
        head.addWidget(config)
        self._pomoc = przycisk("Pomoc Allegro", "pomoc")
        self._pomoc.clicked.connect(self.pomoc.emit)
        head.addWidget(self._pomoc)
        return head

    def _metryki(self) -> QHBoxLayout:
        metrics = QHBoxLayout()
        metrics.setSpacing(8)
        self.liczniki: dict[str, QLabel] = {}
        self.podpisy_licznikow: dict[str, QLabel] = {}
        for nazwa, wariant, podpis in (
            ("Aktywne oferty", "pomaranczowy", "Brak danych API"),
            ("Szkice", "niebieski", "Nieopublikowane oferty"),
            ("Błędy", "czerwony", "Brak danych API"),
            ("Sprzedano (30 dni)", "zielony", "sztuk"),
            ("Obrót (30 dni)", "zloty", "Brak danych API"),
        ):
            card = QFrame()
            card.setObjectName("kpiAllegro")
            card.setProperty("wariantAllegro", wariant)
            box = QHBoxLayout(card)
            box.setContentsMargins(16, 12, 16, 12)
            labels = QVBoxLayout()
            labels.setSpacing(3)
            heading = etykieta(nazwa)
            heading.setObjectName("opisAllegro")
            labels.addWidget(heading)
            value = etykieta("—")
            value.setObjectName("licznikAllegro")
            labels.addWidget(value)
            desc = etykieta(podpis)
            desc.setObjectName("podpisAllegro")
            self.podpisy_licznikow[nazwa] = desc
            labels.addWidget(desc)
            self.liczniki[nazwa] = value
            box.addLayout(labels, 1)
            metrics.addWidget(card, 1)
            if nazwa in {"Sprzedano (30 dni)", "Obrót (30 dni)"}:
                self._statystyki.append(card)
        return metrics

    def _lista(
        self, odswiez: QPushButton, poprzednia: QPushButton, nastepna: QPushButton, zakres: QLabel
    ) -> QFrame:
        tabela = self.tabela
        left = QFrame()
        left.setObjectName("obszarOfertAllegro")
        body = QVBoxLayout(left)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(12)
        tabs = QGridLayout()
        self._tabs_layout = tabs
        self._przyciski_tabow: list[QPushButton] = []
        self.taby: dict[StatusOfertyAllegro | None, QPushButton] = {}
        self.nazwy_tabow: dict[StatusOfertyAllegro | None, str] = {}
        for status, nazwa in (
            (None, "Wszystkie"),
            (StatusOfertyAllegro.AKTYWNA, "Aktywne"),
            (StatusOfertyAllegro.SZKIC, "Szkice"),
            (StatusOfertyAllegro.AKTYWOWANA, "Aktywowanie"),
            (StatusOfertyAllegro.ZAKONCZONA, "Zakończone"),
        ):
            b = przycisk(nazwa + " (—)")
            b.setProperty("tabAllegro", True)
            b.setCheckable(True)
            b.setChecked(status == self.status_listy)
            b.clicked.connect(partial(self.status_zadany.emit, status))
            self.taby[status] = b
            self.nazwy_tabow[status] = nazwa
            self._przyciski_tabow.append(b)
        self.tab_szkice = self.taby[StatusOfertyAllegro.SZKIC]
        self._kolumny_tabow = 0
        self._rozmiesc_taby(3)
        body.addLayout(tabs)
        filters = QHBoxLayout()
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj na całym koncie…")
        self.szukaj.setAccessibleName("Szukaj na całym koncie Allegro")
        self.szukaj.setToolTip(
            "Wpisz kryterium i naciśnij Enter lub Szukaj. SKU i ID: dokładna wartość."
        )
        self.szukaj.addAction(ikona("szukaj"), QLineEdit.ActionPosition.LeadingPosition)
        self.szukaj.setClearButtonEnabled(True)
        self.szukaj.setMinimumWidth(140)
        self.szukaj.setMaximumWidth(260)
        self.szukaj.textChanged.connect(self._filtruj)
        self.zdalne_szukaj = False
        self.pole_szukania = QComboBox()
        for nazwa, value in (
            ("Tytuł", "name"),
            ("SKU (dokładne)", "external.id"),
            ("ID Allegro", "offer.id"),
        ):
            self.pole_szukania.addItem(nazwa, value)
        filters.addWidget(self.pole_szukania)
        filters.addWidget(self.szukaj, 2)
        self.szukaj_przycisk = przycisk("Szukaj")
        filters.addWidget(self.szukaj_przycisk)
        filters.addStretch(1)
        clear = przycisk("Wyczyść")
        clear.clicked.connect(self.szukaj.clear)
        filters.addWidget(clear)
        body.addLayout(filters)
        actions = QHBoxLayout()
        new = przycisk("Nowa oferta", "dodaj")
        new.setObjectName("primary")
        new.clicked.connect(self.nowa.emit)
        new.setToolTip("Przejdź do przygotowania lokalnej paczki nowych ofert.")
        actions.addWidget(new)
        imp = przycisk("Importuj", "pobierz")
        imp.clicked.connect(self.nowa.emit)
        imp.setToolTip("Wczytaj lokalną paczkę ZIP nowych ofert.")
        actions.addWidget(imp)
        odswiez.setText("Odśwież")
        odswiez.setProperty("akcjaAllegro", True)
        odswiez.setIcon(ikona("synchronizacja"))
        actions.addWidget(odswiez)
        actions.addStretch()
        more = przycisk("Więcej działań", "wiecej")
        menu = QMenu(more)
        for nazwa in (
            "Publikuj",
            "Masowa edycja",
            "Duplikuj",
            "Zmień cenę",
            "Zmień stan",
            "Zakończ",
            "Usuń",
            "Kafelki",
            "Kanban",
        ):
            action = menu.addAction(nazwa + " — w przygotowaniu")
            action.setEnabled(False)
        more.setMenu(menu)
        actions.addWidget(more)
        body.addLayout(actions)
        tabela.setObjectName("tabelaAllegro")
        tabela.setColumnCount(10)
        tabela.setHorizontalHeaderLabels(
            [
                "ID Allegro",
                "Tytuł oferty",
                "Zdjęcie",
                "SKU",
                "Cena",
                "Stan",
                "Sprzedano",
                "Status",
                "Akcje",
                "",
            ]
        )
        self.naglowek = NaglowekWyboru(
            tabela, lambda: self._zaznacz(True), lambda: self._zaznacz(False)
        )
        self.naglowek.setAccessibleName("Zaznacz wszystkie szkice pobrane na bieżącej stronie")
        tabela.setHorizontalHeader(self.naglowek)
        tabela.setItemDelegateForColumn(7, DelegatStatusuAllegro(tabela))
        tabela.setColumnHidden(0, True)
        tabela.setColumnHidden(6, True)
        tabela.setShowGrid(False)
        tabela.setAlternatingRowColors(False)
        header = tabela.horizontalHeader()
        for visual, logical in enumerate((9, 2, 1, 3, 4, 5, 6, 7, 8)):
            header.moveSection(header.visualIndex(logical), visual)
        header.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        for col in (4, 5):
            item = tabela.horizontalHeaderItem(col)
            if item is not None:
                item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for col, width in (
            (9, 30),
            (2, 80),
            (3, 110),
            (4, 112),
            (5, 48),
            (6, 66),
            (7, 100),
            (8, 74),
        ):
            tabela.setColumnWidth(col, width)
        tabela.verticalHeader().hide()
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        tabela.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
        tabela.verticalHeader().setDefaultSectionSize(76)
        tabela.verticalScrollBar().valueChanged.connect(lambda *_: self.timer_miniatur.start(50))
        tabela.itemSelectionChanged.connect(self._zaznaczenie)
        tabela.itemChanged.connect(lambda *_: self._zaznaczenie())
        body.addWidget(tabela, 1)
        bulk = QHBoxLayout()
        self.zaznaczenie = etykieta("Zaznaczono: 0")
        bulk.addWidget(self.zaznaczenie)
        bulk.addStretch()
        body.addLayout(bulk)
        pages = QHBoxLayout()
        pages.addWidget(zakres, 1)
        pages.addWidget(poprzednia)
        pages.addWidget(nastepna)
        self.przerwij = przycisk("Przerwij pobieranie")
        self.przerwij.setEnabled(False)
        pages.addWidget(self.przerwij)
        self.rozmiar_strony = QComboBox()
        self.rozmiar_strony.setAccessibleName("Liczba wyświetlanych ofert Allegro")
        for rozmiar in (50, 100, 500, 1000):
            self.rozmiar_strony.addItem(f"{rozmiar} na stronę", rozmiar)
        self.rozmiar_strony.addItem("Wszystkie", 0)
        pages.addWidget(self.rozmiar_strony)
        body.addLayout(pages)
        return left

    def _panel_szczegolow(self, podglad: QPushButton) -> QFrame:
        self.panel = QFrame()
        self.panel.setObjectName("szczegolyAllegro")
        right = QVBoxLayout(self.panel)
        right.setContentsMargins(16, 16, 16, 16)
        right.setSpacing(12)
        heading = QLabel("Szczegóły oferty")
        heading.setObjectName("tytulSekcjiAllegro")
        right.addWidget(heading)
        self.photo = QVBoxLayout()
        right.addLayout(self.photo)
        self.tytul = etykieta("Wybierz ofertę z listy")
        self.tytul.setObjectName("tytulOfertyAllegro")
        right.addWidget(self.tytul)
        self.id = etykieta("ID Allegro: —")
        self.id.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        right.addWidget(self.id)
        self.status_oferty = etykieta("Stan oferty: —")
        right.addWidget(self.status_oferty)
        self.pola: dict[str, QLabel] = {}
        form = QGridLayout()
        for i, nazwa in enumerate(
            (
                "Cena",
                "Stan magazynowy",
                "Sprzedano",
                "Wyświetlenia",
                "Obserwujący",
                "Kategoria",
                "SKU / EAN",
            )
        ):
            label = QLabel("SKU" if nazwa == "SKU / EAN" else nazwa)
            label.setObjectName("opisAllegro")
            form.addWidget(label, i, 0)
            value = etykieta("—")
            self.pola[nazwa] = value
            form.addWidget(value, i, 1)
        right.addLayout(form)
        right.addWidget(podglad)
        self.edytuj_propozycje_przycisk = przycisk("Przygotuj edycję szkicu", "edytuj", False)
        self.edytuj_propozycje_przycisk.setToolTip(
            "Edytuj tytuł i opis szkicu, a następnie potwierdź zapis w Allegro."
        )
        self.edytuj_propozycje_przycisk.clicked.connect(self.edytuj_propozycje.emit)
        right.addWidget(self.edytuj_propozycje_przycisk)
        self.uwaga = etykieta(OPIS_ODCZYTU)
        self.uwaga.setObjectName("podpisAllegro")
        right.addWidget(self.uwaga)
        right.addStretch()
        self.panel.setMinimumWidth(240)
        self.panel.setMaximumWidth(300)
        return self.panel

    def ustaw_strone(self, strona: StronaSzkicowAllegro, *, liczniki: bool = True) -> None:
        if liczniki:
            status = self.status_listy
            self.taby[status].setText(f"{self.nazwy_tabow[status]} ({strona.lacznie})")
            if status == StatusOfertyAllegro.SZKIC:
                self.liczniki["Szkice"].setText(str(strona.lacznie))
            elif status == StatusOfertyAllegro.AKTYWNA:
                self.liczniki["Aktywne oferty"].setText(str(strona.lacznie))
                self.podpisy_licznikow["Aktywne oferty"].setText("Oferty ACTIVE całego wyniku")
        self.ostatni.setText(
            "Ostatni odczyt: " + QDateTime.currentDateTime().toString("dd.MM.yyyy HH:mm")
        )
        self._zdjecia_wierszy.clear()
        self._statusy_wierszy = {p.id: p.status for p in strona.szkice}
        self._miniatury.clear()
        for row, p in enumerate(strona.szkice):
            for col, value in (
                (2, "—"),
                (3, p.sku or "—"),
                (4, f"{p.cena.replace('.', ',')} {p.waluta}" if p.cena else "—"),
                (5, str(p.stan) if p.stan is not None else "—"),
                (6, "—"),
                (7, "● " + ETYKIETY_STATUSOW[p.status]),
            ):
                item = QTableWidgetItem(value)
                if col in {4, 5, 6}:
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
                    )
                if col == 7:
                    item.setForeground(self._kolor_statusu(p.status))
                self.tabela.setItem(row, col, item)
            checkbox = QTableWidgetItem()
            checkbox.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            checkbox.setCheckState(Qt.CheckState.Unchecked)
            self.tabela.setItem(row, 9, checkbox)
            host = QWidget()
            buttons = QHBoxLayout(host)
            buttons.setContentsMargins(4, 0, 4, 0)
            buttons.setSpacing(4)
            edit = QToolButton()
            edit.setObjectName("akcjaWierszaAllegro")
            edit.setIcon(ikona("edytuj"))
            mozna_edytowac = self.propozycje_dostepne and p.status == StatusOfertyAllegro.SZKIC
            edit.setEnabled(mozna_edytowac)
            edit.setAccessibleName("Przygotuj propozycję edycji szkicu")
            edit.setToolTip("Edytuj tytuł i opis szkicu; zapis w Allegro wymaga potwierdzenia.")
            edit.clicked.connect(partial(self._edytuj_wiersz, row))
            buttons.addWidget(edit)
            b = QToolButton()
            b.setObjectName("akcjaWierszaAllegro")
            b.setIcon(ikona("wiecej"))
            b.setAccessibleName(f"Akcje oferty {p.id}")
            menu = QMenu(b)
            menu.addAction("Podgląd oferty", self.szczegoly.emit)
            akcja_edycji = menu.addAction("Przygotuj edycję szkicu", self.edytuj_propozycje.emit)
            akcja_edycji.setEnabled(mozna_edytowac)
            menu.addAction("Kopiuj ID Allegro", partial(QGuiApplication.clipboard().setText, p.id))
            b.setMenu(menu)
            b.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            b.pressed.connect(lambda r=row: self.tabela.selectRow(r))
            buttons.addWidget(b)
            self.tabela.setCellWidget(row, 8, host)
            if p.zdjecie:
                self._zdjecia_wierszy[p.id] = p.zdjecie
        self._filtruj()
        self.timer_miniatur.start(0)

    def _edytuj_wiersz(self, row: int) -> None:
        self.tabela.selectRow(row)
        self.edytuj_propozycje.emit()

    def _filtruj(self) -> None:
        fraza = "" if self.zdalne_szukaj else self.szukaj.text().casefold().strip()
        for row in range(self.tabela.rowCount()):
            title, sku = self.tabela.item(row, 1), self.tabela.item(row, 3)
            self.tabela.setRowHidden(
                row,
                bool(fraza)
                and fraza
                not in (
                    (title.text() if title else "") + " " + (sku.text() if sku else "")
                ).casefold(),
            )
        row = self.tabela.currentRow()
        if row >= 0 and self.tabela.isRowHidden(row):
            self.tabela.setCurrentCell(-1, -1)
            self.tabela.clearSelection()
            self._wyczysc_panel()
        self.timer_miniatur.start(0)

    def _zaznaczenie(self) -> None:
        count = 0
        for r in range(self.tabela.rowCount()):
            item = self.tabela.item(r, 9)
            if item is not None and item.checkState() == Qt.CheckState.Checked:
                count += 1
        self.zaznaczenie.setText(f"Zaznaczono: {count}")
        self.naglowek.ustaw(count, self.tabela.rowCount())
        row = self.tabela.currentRow()
        title, ident = self.tabela.item(row, 1), self.tabela.item(row, 0)
        if title is not None and ident is not None:
            if self.id.text() != "ID Allegro: " + ident.text():
                self.uwaga.setText(OPIS_ODCZYTU)
                status = self._statusy_wierszy.get(ident.text())
                self.status_oferty.setProperty("statusAllegro", status)
                self.status_oferty.setText(
                    "● " + ETYKIETY_STATUSOW[status] if status else "Stan oferty: —"
                )
                self.status_oferty.setStyleSheet(
                    f"color:{self._kolor_statusu(status).name()};" if status else ""
                )
                self._wyczysc_zdjecie()
                for pole in self.pola.values():
                    pole.setText("—")
                for key, col in (("Cena", 4), ("Stan magazynowy", 5), ("SKU / EAN", 3)):
                    cell = self.tabela.item(row, col)
                    self.pola[key].setText(cell.text() if cell else "—")
            self.tytul.setText(title.text())
            self.id.setText("ID Allegro: " + ident.text())

    def _miniatury_widoczne(self) -> None:
        if not self.tabela.isVisible():
            return
        for row in range(self.tabela.rowCount()):
            index = self.tabela.model().index(row, 2)
            if not self.tabela.isRowHidden(row) and self.tabela.visualRect(index).intersects(
                self.tabela.viewport().rect()
            ):
                item = self.tabela.item(row, 0)
                if item is None or item.text() in self._miniatury:
                    continue
                url = self._zdjecia_wierszy.get(item.text())
                image = self.obrazy_tabeli.obraz(url or "")
                if url and image.obraz.isNull():
                    image.setText("")
                if not url:
                    image.setText("—")
                    image.setAccessibleName("Brak zdjęcia oferty")
                host = QWidget()
                box = QHBoxLayout(host)
                box.setContentsMargins(4, 4, 4, 4)
                box.addWidget(image, 0, Qt.AlignmentFlag.AlignCenter)
                self.tabela.setCellWidget(row, 2, host)
                pozycja = self.tabela.item(row, 2)
                if pozycja is not None:
                    pozycja.setText("")
                self._miniatury.add(item.text())

    def pokaz_szczegoly(self, d: SzczegolySzkicuAllegro) -> None:
        ident = self.tabela.item(self.tabela.currentRow(), 0)
        if (
            ident is None
            or ident.text() != d.id
            or self.tabela.isRowHidden(self.tabela.currentRow())
        ):
            return
        poprzedni = self._statusy_wierszy.get(d.id)
        self.uwaga.setText(
            OPIS_ODCZYTU
            if poprzedni == d.status
            else "Stan oferty zmienił się od odczytu listy. Odśwież listę."
        )
        self.status_oferty.setText("● " + ETYKIETY_STATUSOW[d.status])
        self.status_oferty.setProperty("statusAllegro", d.status)
        self.status_oferty.setStyleSheet(f"color:{self._kolor_statusu(d.status).name()};")
        self.tytul.setText(d.tytul)
        self.id.setText("ID Allegro: " + d.id)
        for key, value in (
            ("Cena", f"{d.cena.replace('.', ',')} {d.waluta}" if d.cena else "—"),
            ("Stan magazynowy", str(d.stan) if d.stan is not None else "—"),
            ("Kategoria", d.kategoria or "—"),
            ("SKU / EAN", d.sku or "—"),
        ):
            self.pola[key].setText(value)
        self._wyczysc_zdjecie()
        if d.zdjecia:
            image = self.obrazy.obraz(d.zdjecia[0])
            image.setMinimumHeight(120)
            image.setMaximumHeight(170)
            self.photo.addWidget(image)

    def wyczysc(self) -> None:
        self.naglowek.ustaw(0, 0)
        self.zaznaczenie.setText("Zaznaczono: 0")
        self.timer_miniatur.stop()
        self.obrazy.zamknij()
        self.obrazy_tabeli.zamknij()
        self.obrazy = ObrazyOferty(self, self.zdjecia, self.uruchom)
        self.obrazy_tabeli = ObrazyOferty(self, self.zdjecia, self.uruchom, miniatury=True)
        self._zdjecia_wierszy.clear()
        self._miniatury.clear()
        # Czyszczenie bieżącej strony nie kasuje odczytów innych zakładek/konta.
        self.taby[self.status_listy].setText(self.nazwy_tabow[self.status_listy] + " (—)")
        self.ostatni.setText("Ostatni odczyt: —")
        self._wyczysc_panel()

    def _wyczysc_zdjecie(self) -> None:
        while self.photo.count():
            item = self.photo.takeAt(0)
            widget = item.widget() if item is not None else None
            if widget is not None:
                widget.hide()
                widget.deleteLater()

    def _wyczysc_panel(self) -> None:
        self.tytul.setText("Wybierz ofertę z listy")
        self.id.setText("ID Allegro: —")
        self.status_oferty.setText("Stan oferty: —")
        self.status_oferty.setProperty("statusAllegro", None)
        self.status_oferty.setStyleSheet("")
        self.uwaga.setText(OPIS_ODCZYTU)
        for pole in self.pola.values():
            pole.setText("—")
        self._wyczysc_zdjecie()

    def ustaw_status_listy(self, status: StatusOfertyAllegro | None) -> None:
        self.status_listy = status
        for s, b in self.taby.items():
            b.setChecked(s == status)

    def ustaw_liczniki(self, dane: LicznikiAllegro | None) -> None:
        self.podpisy_licznikow["Aktywne oferty"].setText(
            "Oferty ACTIVE całego konta" if dane else "Brak danych API"
        )
        for status, nazwa, liczba in (
            (StatusOfertyAllegro.AKTYWNA, "Aktywne oferty", dane.aktywne if dane else None),
            (StatusOfertyAllegro.SZKIC, "Szkice", dane.szkice if dane else None),
        ):
            value = str(liczba) if liczba is not None else "—"
            self.liczniki[nazwa].setText(value)
            self.liczniki[nazwa].setToolTip("Odczyt całego konta z Allegro API; cache do 30 s.")
            self.taby[status].setText(f"{self.nazwy_tabow[status]} ({value})")

    def ustaw_konto(self, login: str | None) -> None:
        self.konto.setText("Konto: " + (login or "—"))
        if login is None:
            self.ustaw_liczniki(None)
            for status, b in self.taby.items():
                b.setText(self.nazwy_tabow[status] + " (—)")

    def _zaznacz(self, zaznacz: bool) -> None:
        poprzedni = self.tabela.blockSignals(True)
        try:
            for row in range(self.tabela.rowCount()):
                item = self.tabela.item(row, 9)
                if item is not None:
                    item.setCheckState(
                        Qt.CheckState.Checked if zaznacz else Qt.CheckState.Unchecked
                    )
        finally:
            self.tabela.blockSignals(poprzedni)
        self._zaznaczenie()

    def _rozmiesc_taby(self, kolumny: int) -> None:
        if self._kolumny_tabow == kolumny:
            return
        self._kolumny_tabow = kolumny
        for i, b in enumerate(self._przyciski_tabow):
            self._tabs_layout.removeWidget(b)
            self._tabs_layout.addWidget(b, i // kolumny, i % kolumny)
        for i in range(7):
            self._tabs_layout.setColumnStretch(i, int(i < kolumny))

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        if not hasattr(self, "panel"):
            return
        self._rozmiesc_taby(5 if self.width() >= 1050 else 3)
        szeroki = self.width() >= 950
        self.panel.setVisible(szeroki)
        self._pomoc.setVisible(szeroki)
        self._opis_naglowka.setVisible(szeroki)
        for w in self._statystyki:
            w.setVisible(szeroki)
        for w in self._opcje_filtrow + self._tryby:
            w.setVisible(self.width() >= 1100)
        self.timer_miniatur.start(0)

    def showEvent(self, event: QShowEvent) -> None:
        super().showEvent(event)
        self.timer_miniatur.start(0)
