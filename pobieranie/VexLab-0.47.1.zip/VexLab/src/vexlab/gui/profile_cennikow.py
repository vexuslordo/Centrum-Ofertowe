"""Mały panel profili; odczyt/zapis ustawień przez przypadek użycia w zadaniu."""

from typing import TYPE_CHECKING, cast
from uuid import UUID

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMenu,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.profile_cennikow import (
    DopasowanieCennika,
    ProfilCennika,
    ProfileCennikow,
    RozpoznanieCennika,
)

if TYPE_CHECKING:
    from vexlab.gui.importowanie import StronaImportu


class PanelProfiliCennikow(QWidget):
    def __init__(self, strona: "StronaImportu", serwis: ProfileCennikow) -> None:
        super().__init__(strona)
        self.strona, self.serwis = strona, serwis
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        top = QHBoxLayout()
        self.wybor = QComboBox()
        self.wybor.setAccessibleName("Profil układu cennika")
        self.wybor.addItem("Ustaw kolumny ręcznie", None)
        self.wybor.currentIndexChanged.connect(self.zastosuj)
        top.addWidget(self.wybor, 1)
        self.menu_przycisk = QPushButton("Profil")
        menu = QMenu(self.menu_przycisk)
        self.zapisz = menu.addAction("Zapamiętaj układ…", self.zapamietaj)
        self.usun = menu.addAction("Usuń profil…", self.usun_profil)
        self.menu_przycisk.setMenu(menu)
        self.ustawienia = QPushButton("Ustawienia importu ▾")
        self.ustawienia.clicked.connect(self.przelacz)
        for b in (self.menu_przycisk, self.ustawienia):
            top.addWidget(b)
        layout.addLayout(top)
        self.info = QLabel("Wybierz plik. Zatwierdzony układ możesz zapamiętać.")
        self.info.setTextFormat(Qt.TextFormat.PlainText)
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        self.wyczysc()

    def pokaz_ustawienia(self, pokaz: bool) -> None:
        self.strona.ustawienia_importu.setVisible(pokaz)
        self.ustawienia.setText("Ustawienia importu ▾" if pokaz else "Ustawienia importu ▸")

    def przelacz(self) -> None:
        self.pokaz_ustawienia(self.strona.ustawienia_importu.isHidden())

    def wyczysc(self) -> None:
        self.wybor.blockSignals(True)
        self.wybor.clear()
        self.wybor.addItem("Ustaw kolumny ręcznie", None)
        self.wybor.blockSignals(False)
        self.usun.setEnabled(False)
        self.zapisz.setEnabled(False)
        self.info.setText("Wybierz plik. Zatwierdzony układ możesz zapamiętać.")

    def rozpoznaj(self) -> None:
        self.wyczysc()
        plik = self.strona.plik
        if plik is not None:
            self.strona._zadanie(lambda: self.serwis.rozpoznaj(plik), self._gotowe)

    def _gotowe(self, wynik: object) -> None:
        r = cast(RozpoznanieCennika, wynik)
        p = self.strona
        self.zapisz.setEnabled(True)
        zgodne = [
            d
            for d in r.zgodne
            if d.profil is not None
            and p.producent.findData(str(d.profil.producent_id) if d.profil.producent_id else None)
            >= 0
            and (
                p.producent.isEnabled()
                or p.producent.currentData()
                == (str(d.profil.producent_id) if d.profil.producent_id else None)
            )
        ]
        self.wybor.blockSignals(True)
        for d in zgodne:
            if d.profil is None or p.plik is None:
                continue
            self.wybor.addItem(
                f"{d.profil.nazwa} • {p.plik.arkusze[d.arkusz].nazwa} • wiersz {d.mapa.naglowek}",
                d,
            )
        self.wybor.blockSignals(False)
        self.pokaz_ustawienia(True)
        if r.problem:
            self.info.setText(r.problem)
        elif len(zgodne) == 1:
            self.wybor.setCurrentIndex(1)
        elif zgodne:
            self.info.setText("Kilka pasujących układów. Wybierz profil i sprawdź podgląd.")
        elif r.propozycja:
            p.zastosuj_mape(r.propozycja)
            self.info.setText(
                "Propozycja kolumn do sprawdzenia. Wybierz producenta, cenę, "
                "walutę i netto/brutto, "
                "jeśli importujesz ceny. Po podglądzie możesz zapamiętać układ."
            )
        else:
            self.info.setText("Nie rozpoznano jednoznacznego układu. Ustaw kolumny ręcznie.")

    def zastosuj(self, indeks: int) -> None:
        d = cast(DopasowanieCennika | None, self.wybor.itemData(indeks))
        self.usun.setEnabled(d is not None and d.profil is not None)
        if d is None:
            self.pokaz_ustawienia(True)
            return
        self.strona.zastosuj_mape(d)
        self.pokaz_ustawienia(False)
        cena = d.mapa.cena
        kwota = f"Cena: {cena.waluta} {cena.rodzaj}. " if cena else "Bez importu ceny. "
        self.info.setText(
            "Rozpoznano zapisany układ. "
            + kwota
            + "Sprawdź producenta i podgląd; zapis cennika jest osobny."
        )
        self.strona.zaplanuj()

    def zapamietaj(self) -> None:
        p = self.strona
        if p.plik is None or not p.oceny:
            self.info.setText("Najpierw ustaw kolumny i sprawdź podgląd.")
            return
        try:
            mapa = p.mapowanie()
        except BladScenariuszaKatalogu as exc:
            self.info.setText(str(exc))
            return
        nazwa, ok = QInputDialog.getText(self, "Zapamiętaj układ", "Nazwa profilu")
        if not ok:
            return
        plik, arkusz = p.plik, p.arkusz.currentIndex()
        pid = p.producent.currentData()
        producent = UUID(pid) if pid else None

        def gotowe(w: object) -> None:
            profil = cast(ProfilCennika, w)
            self.wybor.blockSignals(True)
            self.wybor.addItem(profil.nazwa, DopasowanieCennika(arkusz, profil.mapa, profil))
            self.wybor.setCurrentIndex(self.wybor.count() - 1)
            self.wybor.blockSignals(False)
            self.usun.setEnabled(True)
            self.info.setText(f"Zapamiętano: {profil.nazwa}. Profil jest ustawieniem użytkownika.")

        p._zadanie(lambda: self.serwis.zapisz(plik, arkusz, mapa, producent, nazwa), gotowe)

    def usun_profil(self) -> None:
        d = cast(DopasowanieCennika | None, self.wybor.currentData())
        if d is None or d.profil is None:
            return
        profil = d.profil
        if (
            QMessageBox.question(
                self,
                "Usuń profil",
                "Usunąć wybrany profil układu? Cenniki i produkty pozostaną.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return

        def gotowe(w: object) -> None:
            self.wyczysc()
            self.zapisz.setEnabled(True)
            self.pokaz_ustawienia(True)
            self.info.setText(
                "Usunięto profil. Mapowanie bieżącego pliku pozostaje do sprawdzenia."
            )

        self.strona._zadanie(lambda: self.serwis.usun(profil), gotowe)
