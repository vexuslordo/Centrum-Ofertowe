"""Komponenty uporządkowanych Ustawień; wyłącznie prezentacja i nawigacja."""

from typing import cast
from uuid import uuid4

from PySide6.QtCore import QEvent, QSize, Qt
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QStackedWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona, ikona_menu
from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.diagnostyka import DiagnozujSrodowisko, RaportDiagnostyczny
from vexlab.rdzen.kontrakty import IdKorelacji


class SekcjaRozwijana(QWidget):
    def __init__(self, tytul: str) -> None:
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.przelacz = QToolButton()
        self.przelacz.setText(tytul)
        self.przelacz.setAccessibleName(tytul)
        self.przelacz.setCheckable(True)
        self.przelacz.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.przelacz.toggled.connect(self.ustaw_otwarte)
        layout.addWidget(self.przelacz, 0, Qt.AlignmentFlag.AlignLeft)
        self.tresc = QWidget()
        self.wnetrze = QVBoxLayout(self.tresc)
        self.wnetrze.setContentsMargins(0, 8, 0, 8)
        layout.addWidget(self.tresc)
        self.ustaw_otwarte(False)

    def ustaw_otwarte(self, otwarte: bool) -> None:
        self.przelacz.setChecked(otwarte)
        self.przelacz.setArrowType(Qt.ArrowType.DownArrow if otwarte else Qt.ArrowType.RightArrow)
        self.tresc.setVisible(otwarte)


class IntegracjeUstawien(QWidget):
    def __init__(self) -> None:
        super().__init__()
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)
        self.lista = QListWidget()
        self.lista.setAccessibleName("Wybierz integrację")
        self.lista.setMinimumWidth(156)
        self.lista.setMaximumWidth(208)
        self.lista.setIconSize(QSize(24, 24))
        self.lista.setUniformItemSizes(True)
        layout.addWidget(self.lista)
        self.stos = QStackedWidget()
        layout.addWidget(self.stos, 1)
        self.lista.currentRowChanged.connect(self.stos.setCurrentIndex)
        self.panele: list[QWidget] = []
        self.nazwy: list[str] = []
        self.obszary: list[QScrollArea] = []

    def dodaj(self, nazwa: str, status: str, panel: QWidget) -> None:
        ciemny = QApplication.palette().color(QPalette.ColorRole.Window).lightness() < 128
        obraz = (
            ikona_menu(nazwa, ciemny)
            if nazwa != "Subiekt GT"
            else ikona("produkt", "#59AEFF" if ciemny else "#176CC1")
        )
        item = QListWidgetItem(obraz, f"{nazwa}\n{status}")
        item.setSizeHint(QSize(156, 66))
        item.setToolTip(f"{nazwa}: {status}")
        self.lista.addItem(item)
        wnetrze = panel.layout()
        if wnetrze is not None:
            wnetrze.setContentsMargins(18, 18, 18, 18)
            wnetrze.setAlignment(Qt.AlignmentFlag.AlignTop)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(panel)
        self.stos.addWidget(scroll)
        self.panele.append(panel)
        self.nazwy.append(nazwa)
        self.obszary.append(scroll)
        if self.lista.currentRow() < 0:
            self.lista.setCurrentRow(0)

    def setCurrentWidget(self, panel: QWidget) -> None:
        if panel in self.panele:
            self.lista.setCurrentRow(self.panele.index(panel))

    def currentWidget(self) -> QWidget | None:
        i = self.lista.currentRow()
        return self.panele[i] if 0 <= i < len(self.panele) else None

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() in (
            QEvent.Type.PaletteChange,
            QEvent.Type.ApplicationPaletteChange,
        ) and hasattr(self, "nazwy"):
            ciemny = QApplication.palette().color(QPalette.ColorRole.Window).lightness() < 128
            for i, nazwa in enumerate(self.nazwy):
                obraz = (
                    ikona_menu(nazwa, ciemny)
                    if nazwa != "Subiekt GT"
                    else ikona("produkt", "#59AEFF" if ciemny else "#176CC1")
                )
                self.lista.item(i).setIcon(obraz)

    def ustaw_status(self, panel: QWidget, status: str) -> None:
        if panel in self.panele:
            i = self.panele.index(panel)
            item = self.lista.item(i)
            item.setText(f"{self.nazwy[i]}\n{status}")
            item.setToolTip(f"{self.nazwy[i]}: {status}")


class InformacjeOProgramie(QWidget):
    def __init__(self, wersja: str, serwis: DiagnozujSrodowisko | None, uruchom: Uruchom) -> None:
        super().__init__()
        self.wersja, self.serwis, self.uruchom = wersja, serwis, uruchom
        self.trwa = False
        layout = QVBoxLayout(self)
        tytul = QLabel(f"VexLab {wersja}")
        tytul.setObjectName("tytul")
        layout.addWidget(tytul)
        opis = QLabel("Informacje techniczne i raport pomocny przy zgłaszaniu problemów.")
        opis.setWordWrap(True)
        layout.addWidget(opis)
        buttons = QHBoxLayout()
        self.sprawdz = QPushButton("Sprawdź środowisko")
        self.sprawdz.setEnabled(serwis is not None)
        self.sprawdz.clicked.connect(self.wykonaj)
        self.kopiuj = QPushButton("Kopiuj raport")
        self.kopiuj.setEnabled(False)
        self.kopiuj.clicked.connect(self._kopiuj)
        buttons.addWidget(self.sprawdz)
        buttons.addWidget(self.kopiuj)
        buttons.addStretch()
        layout.addLayout(buttons)
        self.info = QLabel("Utwórz raport, jeśli chcesz sprawdzić środowisko programu.")
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        self.raport = QPlainTextEdit()
        self.raport.setAccessibleName("Raport techniczny VexLab")
        self.raport.setReadOnly(True)
        self.raport.setMinimumHeight(190)
        self.raport.hide()
        layout.addWidget(self.raport)
        layout.addStretch()

    def wykonaj(self) -> None:
        serwis = self.serwis
        if serwis is None or self.trwa:
            return
        self.trwa = True
        self.sprawdz.setEnabled(False)
        self.kopiuj.setEnabled(False)
        self.raport.clear()
        self.raport.hide()
        self.info.setText("Sprawdzanie środowiska…")
        identyfikator = IdKorelacji(uuid4())

        def gotowe(wynik: object) -> None:
            r = cast(RaportDiagnostyczny, wynik)
            self.trwa = False
            self.sprawdz.setEnabled(True)
            self.raport.setPlainText(
                f"VexLab {self.wersja}\nSprawdzono: {r.czas.isoformat(timespec='seconds')}\n"
                f"Python: {r.wersje.python}\n"
                f"PySide6: {r.wersje.pyside6}\nSQLite: {r.wersje.sqlite}\n"
                f"Identyfikator raportu: {r.id_korelacji}\n"
                "Raport techniczny nie potwierdza połączeń z kanałami ani z Subiektem."
            )
            self.raport.show()
            self.kopiuj.setEnabled(True)
            self.info.setText("Raport gotowy do skopiowania.")

        def blad(kod: str, tekst: str) -> None:
            self.trwa = False
            self.sprawdz.setEnabled(True)
            self.info.setText(tekst)

        self.uruchom(lambda: serwis.wykonaj(identyfikator), gotowe, blad)

    def _kopiuj(self) -> None:
        if self.kopiuj.isEnabled():
            QApplication.clipboard().setText(self.raport.toPlainText())
