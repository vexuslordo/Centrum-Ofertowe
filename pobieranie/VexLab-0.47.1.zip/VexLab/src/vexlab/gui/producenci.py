"""Rejestr producentów z własnym stanem odczytu i formularzem."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import (
    QAbstractTableModel,
    QModelIndex,
    QPersistentModelIndex,
    QSortFilterProxyModel,
    Qt,
    Signal,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from vexlab.przypadki_uzycia.producenci import DaneProducenta, ProducentDTO, RejestrProducentow

Indeks = QModelIndex | QPersistentModelIndex
Uruchom = Callable[
    [Callable[[], object], Callable[[object], None], Callable[[str, str], None] | None], None
]


class ModelProducentow(QAbstractTableModel):
    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.producenci: list[ProducentDTO] = []

    def ustaw(self, producenci: list[ProducentDTO]) -> None:
        self.beginResetModel()
        self.producenci = producenci
        self.endResetModel()

    def rowCount(self, parent: Indeks | None = None) -> int:
        return 0 if parent is not None and parent.isValid() else len(self.producenci)

    def columnCount(self, parent: Indeks | None = None) -> int:
        return 0 if parent is not None and parent.isValid() else 3

    def data(self, index: Indeks, role: int = Qt.ItemDataRole.DisplayRole) -> object:
        if not index.isValid() or not 0 <= index.row() < len(self.producenci):
            return None
        p = self.producenci[index.row()]
        if role == Qt.ItemDataRole.DisplayRole:
            return (p.nazwa, "Aktywny" if p.aktywny else "Nieaktywny", str(p.id))[index.column()]
        if role in (Qt.ItemDataRole.ToolTipRole, Qt.ItemDataRole.AccessibleTextRole):
            return f"{p.nazwa}, {'aktywny' if p.aktywny else 'nieaktywny'}, ID: {p.id}"
        return None

    def headerData(
        self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole
    ) -> object:
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return ("Nazwa producenta", "Status", "Identyfikator")[section]
        return None


class FiltrProducentow(QSortFilterProxyModel):
    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.fraza = ""
        self.pokaz_nieaktywnych = True

    def ustaw(self, fraza: str, nieaktywni: bool) -> None:
        self.beginFilterChange()
        self.fraza = fraza.strip().casefold()
        self.pokaz_nieaktywnych = nieaktywni
        self.endFilterChange(QSortFilterProxyModel.Direction.Rows)

    def filterAcceptsRow(self, row: int, parent: Indeks) -> bool:
        model = cast(ModelProducentow, self.sourceModel())
        p = model.producenci[row]
        return self.fraza in p.nazwa.casefold() and (p.aktywny or self.pokaz_nieaktywnych)


class FormularzProducenta(QDialog):
    def __init__(self, producent: ProducentDTO | None, parent: QWidget) -> None:
        super().__init__(parent)
        self.producent = producent
        self.setWindowTitle("Edytuj producenta" if producent else "Dodaj producenta")
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        pola = QFormLayout()
        self.nazwa = QLineEdit(producent.nazwa if producent else "")
        self.nazwa.setAccessibleName("Nazwa producenta, wymagane")
        self.strona_www = QLineEdit(producent.strona_www if producent else "")
        self.strona_www.setPlaceholderText(
            "https://… — opcjonalny adres wpisywany przez użytkownika"
        )
        self.strona_www.setAccessibleName("Strona internetowa producenta, opcjonalna")
        self.aktywny = QCheckBox("Aktywny — dostępny do nowych przypisań")
        self.aktywny.setChecked(producent.aktywny if producent else True)
        pola.addRow("Nazwa *", self.nazwa)
        pola.addRow("Strona WWW", self.strona_www)
        pola.addRow(self.aktywny)
        layout.addLayout(pola)
        opis = QLabel(
            "Dezaktywacja nie usuwa producenta ani jego wcześniejszych przypisań do produktów."
        )
        opis.setWordWrap(True)
        opis.setObjectName("opis")
        layout.addWidget(opis)
        self.blad = QLabel()
        self.blad.setWordWrap(True)
        self.blad.setObjectName("ostrzezenie")
        self.blad.setAccessibleName("Błąd zapisu producenta")
        layout.addWidget(self.blad)
        self.przyciski = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        self.zapisz = self.przyciski.button(QDialogButtonBox.StandardButton.Save)
        self.zapisz.setText("Zapisz lokalnie")
        self.zapisz.setObjectName("primary")
        self.przyciski.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        self.przyciski.rejected.connect(self.reject)
        layout.addWidget(self.przyciski)
        self.nazwa.setFocus()

    def dane(self) -> DaneProducenta:
        return DaneProducenta(self.nazwa.text(), self.aktywny.isChecked(), self.strona_www.text())

    def ustaw_zapis(self, trwa: bool) -> None:
        self.nazwa.setEnabled(not trwa)
        self.aktywny.setEnabled(not trwa)
        self.strona_www.setEnabled(not trwa)
        self.przyciski.setEnabled(not trwa)
        self.zapisz.setText("Zapisywanie…" if trwa else "Zapisz lokalnie")

    def pokaz_blad(self, kod: str, komunikat: str) -> None:
        self.ustaw_zapis(False)
        self.blad.setText(komunikat)
        self.nazwa.setFocus()

    def reject(self) -> None:
        if self.zapisz.isEnabled():
            super().reject()


class StronaProducentow(QWidget):
    zmieniono = Signal()
    status = Signal(str)

    def __init__(self, rejestr: RejestrProducentow, uruchom: Uruchom, parent: QWidget) -> None:
        super().__init__(parent)
        self.rejestr = rejestr
        self.uruchom = uruchom
        self.setObjectName("strona")
        self.formularz: FormularzProducenta | None = None
        self.tabela: QTableView
        self._odczyt = 0
        self._blad_odczytu: str | None = None
        self._wczytano = False
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        tytul = QLabel("Producenci")
        tytul.setObjectName("marka")
        layout.addWidget(tytul)
        opis = QLabel("Lokalny rejestr producentów • niezależny od dostawców i podmiotów GPSR")
        opis.setWordWrap(True)
        opis.setObjectName("opis")
        layout.addWidget(opis)
        pasek = QHBoxLayout()
        self.dodaj = QPushButton("Dodaj producenta")
        self.dodaj.setObjectName("primary")
        self.dodaj.clicked.connect(lambda: self.otworz_formularz(None))
        pasek.addWidget(self.dodaj)
        self.edytuj = QPushButton("Edytuj zaznaczonego")
        self.edytuj.clicked.connect(lambda: self.edytuj_indeks(self.tabela.currentIndex()))
        pasek.addWidget(self.edytuj)
        self.odswiez_przycisk = QPushButton("Odśwież")
        self.odswiez_przycisk.clicked.connect(self.odswiez)
        pasek.addWidget(self.odswiez_przycisk)
        pasek.addStretch()
        layout.addLayout(pasek)
        filtry = QHBoxLayout()
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj producenta po nazwie…")
        self.szukaj.setAccessibleName("Szukaj producenta po nazwie")
        self.szukaj.setClearButtonEnabled(True)
        self.szukaj.textChanged.connect(self._filtruj)
        filtry.addWidget(self.szukaj, 1)
        self.nieaktywni = QCheckBox("Pokaż nieaktywnych")
        self.nieaktywni.setChecked(True)
        self.nieaktywni.toggled.connect(self._filtruj)
        filtry.addWidget(self.nieaktywni)
        layout.addLayout(filtry)
        self.info = QLabel("Odczyt jeszcze nie został wykonany.")
        self.info.setWordWrap(True)
        self.info.setObjectName("opis")
        layout.addWidget(self.info)
        self.model = ModelProducentow(self)
        self.filtr = FiltrProducentow(self)
        self.filtr.setSourceModel(self.model)
        self.filtr.setSortCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.tabela = QTableView()
        self.tabela.setAccessibleName("Rejestr producentów")
        self.tabela.setModel(self.filtr)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.verticalHeader().hide()
        self.tabela.verticalHeader().setDefaultSectionSize(46)
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.tabela.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tabela.setSortingEnabled(True)
        self.tabela.sortByColumn(0, Qt.SortOrder.AscendingOrder)
        self.tabela.doubleClicked.connect(self.edytuj_indeks)
        layout.addWidget(self.tabela, 1)

    def odswiez(self) -> None:
        self._odczyt += 1
        numer = self._odczyt
        self.info.setText("Odczytywanie producentów…")
        self.uruchom(
            self.rejestr.lista,
            lambda wynik: self._lista(numer, wynik),
            lambda kod, komunikat: self._blad(numer, komunikat),
        )

    def _lista(self, numer: int, wynik: object) -> None:
        if numer != self._odczyt:
            return
        self._wczytano = True
        self._blad_odczytu = None
        self.model.ustaw(cast(list[ProducentDTO], wynik))
        self._opis()

    def _blad(self, numer: int, komunikat: str) -> None:
        if numer != self._odczyt:
            return
        if self._wczytano:
            komunikat += " Wyświetlono poprzedni odczyt producentów."
        self._blad_odczytu = komunikat
        self.info.setText(komunikat)
        self.status.emit(komunikat)

    def _filtruj(self) -> None:
        self.filtr.ustaw(self.szukaj.text(), self.nieaktywni.isChecked())
        self._opis()

    def _opis(self) -> None:
        if self._blad_odczytu is not None:
            self.info.setText(self._blad_odczytu)
        elif not self._wczytano:
            return
        elif not self.model.producenci:
            self.info.setText("Brak producentów. Dodaj pierwszy rekord.")
        else:
            self.info.setText(
                f"Znaleziono {self.filtr.rowCount()} z {len(self.model.producenci)} producentów."
            )

    def edytuj_indeks(self, indeks: Indeks) -> None:
        if not indeks.isValid():
            self.status.emit("Zaznacz producenta do edycji.")
            return
        wiersz = self.filtr.mapToSource(indeks).row()
        self.otworz_formularz(self.model.producenci[wiersz])

    def otworz_formularz(self, producent: ProducentDTO | None) -> None:
        if self.formularz is not None:
            self.formularz.raise_()
            return
        dialog = FormularzProducenta(producent, self)
        self.formularz = dialog
        dialog.setModal(True)
        dialog.przyciski.accepted.connect(lambda: self._zapisz(dialog))
        dialog.finished.connect(lambda: self._zwolnij(dialog))
        dialog.open()

    def _zwolnij(self, dialog: FormularzProducenta) -> None:
        if self.formularz is dialog:
            self.formularz = None
        dialog.deleteLater()

    def _zapisz(self, dialog: FormularzProducenta) -> None:
        dane = dialog.dane()
        producent = dialog.producent
        dialog.ustaw_zapis(True)

        def operacja() -> ProducentDTO:
            if producent is None:
                return self.rejestr.dodaj(dane)
            return self.rejestr.edytuj(producent.id, producent.wersja, dane)

        def zapisano(wynik: object) -> None:
            dialog.accept()
            self.odswiez()
            self.zmieniono.emit()

        self.uruchom(operacja, zapisano, dialog.pokaz_blad)
