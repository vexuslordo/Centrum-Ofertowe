"""Wykonanie I/O poza wątkiem Qt; wyniki wracają sygnałami do odbiorcy GUI."""

import logging
from collections.abc import Callable

from PySide6.QtCore import QObject, QRunnable, Signal, Slot

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.katalog import BladScenariuszaKatalogu
from vexlab.rdzen.kontrakty import BladTechniczny


class SygnalyZadania(QObject):
    wynik = Signal(object)
    blad = Signal(str, str)
    zakonczono = Signal()


class Zadanie(QRunnable):
    def __init__(self, funkcja: Callable[[], object]) -> None:
        super().__init__()
        self.funkcja = funkcja
        self.sygnaly = SygnalyZadania()

    @Slot()
    def run(self) -> None:
        try:
            wynik = self.funkcja()
        except BladScenariuszaKatalogu as blad:
            self.sygnaly.blad.emit(blad.kod, str(blad))
        except BladAllegro as blad:
            self.sygnaly.blad.emit(blad.kod, str(blad))
        except BladTechniczny as blad:
            self.sygnaly.blad.emit("TECHNICZNY", str(blad))
        except Exception as blad:
            # Błędy nieoczekiwane mają osobną kategorię; bez treści danych w logu/GUI.
            logging.getLogger(__name__).error("Nieoczekiwany błąd zadania: %s", type(blad).__name__)
            self.sygnaly.blad.emit(
                "WEWNETRZNY", "Nieoczekiwany błąd wewnętrzny. Zachowano formularz."
            )
        else:
            self.sygnaly.wynik.emit(wynik)
        finally:
            self.sygnaly.zakonczono.emit()
