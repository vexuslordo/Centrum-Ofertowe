"""Lokalna galeria: zmiany robocze zatwierdzane jednym zapisem."""

from collections.abc import Callable
from pathlib import Path
from typing import cast

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QCloseEvent, QIcon, QPixmap
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.przypadki_uzycia.galeria import GaleriaDTO, GaleriaProduktow
from vexlab.przypadki_uzycia.media import ZdjecieDane

Uruchom = Callable[
    [Callable[[], object], Callable[[object], None], Callable[[str, str], None]], None
]


class GaleriaProduktu(QDialog):
    def __init__(
        self,
        dane: GaleriaDTO,
        nazwa: str,
        serwis: GaleriaProduktow,
        uruchom: Uruchom,
        odswiez: Callable[[], None],
        parent: QWidget,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(f"Zdjęcia — {nazwa}")
        self.resize(740, 620)
        self.dane = dane
        self.zdjecia = list(dane.zdjecia)
        self.serwis = serwis
        self.uruchom = uruchom
        self.odswiez = odswiez
        self.trwa = False
        layout = QVBoxLayout(self)
        layout.addWidget(
            QLabel("Do 5 zdjęć. Pierwsze jest miniaturą produktu. Zmiany wymagają zapisu.")
        )
        self.lista = QListWidget()
        self.lista.setAccessibleName("Zdjęcia produktu w kolejności")
        self.lista.setIconSize(QSize(64, 64))
        self.lista.currentRowChanged.connect(self.podglad)
        layout.addWidget(self.lista)
        self.obraz = QLabel("Brak zdjęć")
        self.obraz.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.obraz.setMinimumHeight(220)
        layout.addWidget(self.obraz)
        akcje = QHBoxLayout()
        self.przyciski = []
        for tekst, funkcja in (
            ("Dodaj z dysku…", self.dodaj),
            ("Usuń zdjęcie", self.usun),
            ("Przesuń w górę", lambda: self.przesun(-1)),
            ("Przesuń w dół", lambda: self.przesun(1)),
        ):
            button = QPushButton(tekst)
            button.clicked.connect(funkcja)
            self.przyciski.append(button)
            akcje.addWidget(button)
        layout.addLayout(akcje)
        self.info = QLabel()
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        dol = QHBoxLayout()
        self.zapisz_przycisk = QPushButton("Zapisz galerię")
        self.zapisz_przycisk.setObjectName("primary")
        self.zapisz_przycisk.clicked.connect(self.zapisz)
        self.anuluj = QPushButton("Anuluj")
        self.anuluj.clicked.connect(self.reject)
        dol.addWidget(self.zapisz_przycisk)
        dol.addWidget(self.anuluj)
        layout.addLayout(dol)
        self.odrysuj(0)

    def odrysuj(self, indeks: int) -> None:
        self.lista.clear()
        for i, z in enumerate(self.zdjecia):
            pix = QPixmap()
            pix.loadFromData(z.miniatura)
            self.lista.addItem(QListWidgetItem(QIcon(pix), f"{i + 1}. {z.zrodlo}"))
        self.lista.setCurrentRow(min(indeks, len(self.zdjecia) - 1))
        self.podglad(self.lista.currentRow())

    def podglad(self, indeks: int) -> None:
        self.obraz.clear()
        if 0 <= indeks < len(self.zdjecia):
            pix = QPixmap()
            pix.loadFromData(self.zdjecia[indeks].dane)
            self.obraz.setPixmap(
                pix.scaled(
                    620,
                    260,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
        else:
            self.obraz.setText("Brak zdjęć — dodaj pliki JPG, PNG lub WebP.")

    def zajetosc(self, trwa: bool, tekst: str = "") -> None:
        self.trwa = trwa
        for widget in [*self.przyciski, self.zapisz_przycisk, self.anuluj, self.lista]:
            widget.setEnabled(not trwa)
        self.info.setText(tekst)

    def blad(self, kod: str, tekst: str) -> None:
        self.zajetosc(False, tekst)

    def dodaj(self) -> None:
        pliki, _ = QFileDialog.getOpenFileNames(
            self, "Wybierz zdjęcia", "", "Zdjęcia (*.jpg *.jpeg *.png *.webp)"
        )
        if not pliki:
            return
        if len(self.zdjecia) + len(pliki) > 5:
            self.info.setText(
                "Galeria mieści maksymalnie 5 zdjęć. Usuń zbędne lub wybierz mniej plików."
            )
            return
        sciezki = tuple(Path(p) for p in pliki)
        self.zajetosc(True, "Odczytywanie zdjęć…")

        def gotowe(wynik: object) -> None:
            self.zdjecia.extend(cast(tuple[ZdjecieDane, ...], wynik))
            self.odrysuj(len(self.zdjecia) - 1)
            self.zajetosc(False)

        self.uruchom(lambda: self.serwis.wczytaj_pliki(sciezki), gotowe, self.blad)

    def usun(self) -> None:
        i = self.lista.currentRow()
        if i >= 0:
            self.zdjecia.pop(i)
            self.odrysuj(i)

    def przesun(self, kierunek: int) -> None:
        i = self.lista.currentRow()
        j = i + kierunek
        if 0 <= i < len(self.zdjecia) and 0 <= j < len(self.zdjecia):
            self.zdjecia[i], self.zdjecia[j] = self.zdjecia[j], self.zdjecia[i]
            self.odrysuj(j)

    def zapisz(self) -> None:
        if tuple(self.zdjecia) == self.dane.zdjecia:
            self.accept()
            return
        if (
            not self.zdjecia
            and QMessageBox.question(
                self,
                "Wyczyść galerię",
                "Usunąć wszystkie zdjęcia tego produktu? Powstanie kopia bazy.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        dane = GaleriaDTO(self.dane.produkt_id, self.dane.wersja, tuple(self.zdjecia))
        self.zajetosc(True, "Tworzenie kopii i zapisywanie galerii…")

        def gotowe(wynik: object) -> None:
            self.zajetosc(False)
            self.accept()
            self.odswiez()

        self.uruchom(lambda: self.serwis.zapisz(dane), gotowe, self.blad)

    def reject(self) -> None:
        if self.trwa:
            return
        if (
            tuple(self.zdjecia) != self.dane.zdjecia
            and QMessageBox.question(
                self,
                "Niezapisane zdjęcia",
                "Odrzucić zmiany galerii?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        super().reject()

    def closeEvent(self, event: QCloseEvent) -> None:
        event.ignore()
        self.reject()
