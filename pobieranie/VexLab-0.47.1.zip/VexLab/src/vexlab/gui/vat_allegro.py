"""Wybór VAT per kraj z metadanych albo z własnej oferty, odczyty w tle."""

from collections.abc import Callable
from typing import cast

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.vat_allegro import (
    StawkaVAT,
    UstawieniaVAT,
    VATKategorii,
    normalizuj_vat,
    sprawdz_vat,
)


class VATAllegro(QDialog):
    def __init__(
        self,
        parent: QWidget,
        kategoria: str,
        liczba: int,
        ustawienia: UstawieniaVAT | None,
        pobierz: Callable[[], VATKategorii],
        z_oferty: Callable[[str], UstawieniaVAT],
        uruchom: Uruchom,
        aktualne: Callable[[], bool],
        konto: str = "",
    ) -> None:
        super().__init__(parent)
        self.kategoria, self._pobierz, self._oferta, self._uruchom, self._aktualne = (
            kategoria,
            pobierz,
            z_oferty,
            uruchom,
            aktualne,
        )
        self._meta: VATKategorii | None = None
        self._poprzednie = ustawienia
        self.wynik: UstawieniaVAT | None = None
        self._zamkniete = self._busy = False
        self._wiersze: dict[str, tuple[QTableWidgetItem, QComboBox]] = {}
        self.finished.connect(self._zamknij)
        self.setWindowTitle(f"VAT według krajów • {liczba} ofert")
        self.resize(850, 720)
        layout = QVBoxLayout(self)
        layout.addWidget(
            etykieta(
                f"Konto: {konto} • kategoria: {kategoria}. "
                "Zaznacz obsługiwane kraje i wskaż ich stawki VAT."
            )
        )
        layout.addWidget(
            etykieta(
                "Ustawienie VAT nie zmienia cen brutto i nie włącza sprzedaży w innych krajach."
            )
        )
        self.stosuj = QCheckBox("Przekaż poniższe stawki VAT do zaznaczonych szkiców")
        self.stosuj.setChecked(ustawienia is not None)
        layout.addWidget(self.stosuj)
        self.status = etykieta("Pobieranie dopuszczalnych stawek z Allegro…")
        layout.addWidget(self.status)
        self.odswiez = QPushButton("Pobierz stawki z Allegro")
        self.odswiez.clicked.connect(self.pobierz)
        layout.addWidget(self.odswiez)
        source = QHBoxLayout()
        self.ident = QLineEdit()
        self.ident.setPlaceholderText("ID własnej oferty Allegro z ustawionym VAT")
        self.ident.setAccessibleName("ID oferty źródłowej VAT")
        self.kopiuj = QPushButton("Pobierz VAT z oferty")
        self.kopiuj.clicked.connect(self.kopiuj_oferte)
        source.addWidget(self.ident, 1)
        source.addWidget(self.kopiuj)
        layout.addLayout(source)
        self.tabela = QTableWidget(0, 2)
        self.tabela.setHorizontalHeaderLabels(
            ("Obsługiwany kraj", "Stawka VAT — wybierz lub wpisz %")
        )
        self.tabela.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tabela.setColumnWidth(0, 210)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.verticalHeader().hide()
        self.tabela.itemChanged.connect(self._wybor_kraju)
        layout.addWidget(self.tabela, 1)
        form = QFormLayout()
        self.przedmiot, self.zwolnienie = QComboBox(), QComboBox()
        for box in (self.przedmiot, self.zwolnienie):
            box.setMinimumContentsLength(20)
            box.setSizeAdjustPolicy(
                QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
            )
        self.przedmiot.addItem("Wybierz…", "")
        self.zwolnienie.addItem("Nie dotyczy", "")
        form.addRow("Rodzaj sprzedaży", self.przedmiot)
        form.addRow("Zwolnienie / procedura szczególna", self.zwolnienie)
        layout.addLayout(form)
        self.info = etykieta(
            "Lista zawiera opcje dopuszczalne przez Allegro dla tej kategorii. "
            "Wybierz stawki właściwe dla swoich produktów. Bez zaznaczenia opcji "
            "przekazania VAT nie nadpiszemy ustawień Allegro."
        )
        layout.addWidget(self.info)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        self.zastosuj = buttons.button(QDialogButtonBox.StandardButton.Save)
        self.zastosuj.setText(f"Zastosuj do {liczba} ofert")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.accepted.connect(self.zapisz)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.stosuj.toggled.connect(self._przyciski)
        self._przyciski()
        QTimer.singleShot(0, self.pobierz)

    def _zamknij(self, _result: int) -> None:
        self._zamkniete = True

    def _przyciski(self) -> None:
        self.odswiez.setEnabled(not self._busy)
        self.kopiuj.setEnabled(not self._busy and self._meta is not None)
        self.tabela.setEnabled(not self._busy)
        self.przedmiot.setEnabled(not self._busy)
        self.zwolnienie.setEnabled(not self._busy)
        self.zastosuj.setEnabled(
            not self.stosuj.isChecked() or (not self._busy and self._meta is not None)
        )

    def _wybor_kraju(self, _item: QTableWidgetItem) -> None:
        if any(item.checkState() == Qt.CheckState.Checked for item, _ in self._wiersze.values()):
            self.stosuj.setChecked(True)

    def _ustaw_stawke(self, kraj: str) -> None:
        if kraj not in self._wiersze:
            return
        item, _ = self._wiersze[kraj]
        item.setCheckState(Qt.CheckState.Checked)
        self.stosuj.setChecked(True)

    def _wartosc(self, box: QComboBox) -> tuple[str, str]:
        if box.currentIndex() > 0 and box.currentText() == box.itemText(box.currentIndex()):
            return str(box.currentData()), box.currentText()
        return box.currentText(), ""

    def formularz(self) -> UstawieniaVAT:
        rows = []
        for country, (item, box) in self._wiersze.items():
            if item.checkState() == Qt.CheckState.Checked:
                value, label = self._wartosc(box)
                rows.append(StawkaVAT(country, value, label))
        return UstawieniaVAT(
            tuple(rows), str(self.przedmiot.currentData()), str(self.zwolnienie.currentData())
        )

    def _pokaz(self, u: UstawieniaVAT | None) -> None:
        if self._meta is None:
            return
        selected = {r.kraj: r for r in u.stawki} if u else {}
        kraje = dict(self._meta.kraje)
        for country in selected:
            kraje.setdefault(country, ())
        prev = self.tabela.blockSignals(True)
        self._wiersze.clear()
        self.tabela.setRowCount(len(kraje))
        try:
            for row, (country, options) in enumerate(kraje.items()):
                nazwy = {
                    "PL": "Polska",
                    "CZ": "Czechy",
                    "SK": "Słowacja",
                    "HU": "Węgry",
                    "LT": "Litwa",
                }
                item = QTableWidgetItem(
                    f"{nazwy[country]} ({country})" if country in nazwy else country
                )
                item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(
                    Qt.CheckState.Checked if country in selected else Qt.CheckState.Unchecked
                )
                self.tabela.setItem(row, 0, item)
                box = QComboBox()
                box.setEditable(True)
                box.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
                box.setAccessibleName("Stawka VAT " + country)
                box.addItem("Wybierz stawkę…", "")
                for option in options:
                    box.addItem(option.etykieta, option.wartosc)
                if country in selected:
                    r = selected[country]
                    matches = [
                        i
                        for i in range(1, box.count())
                        if box.itemData(i) == r.wartosc
                        and (not r.etykieta or box.itemText(i) == r.etykieta)
                    ]
                    if len(matches) == 1:
                        box.setCurrentIndex(matches[0])
                    else:
                        box.setEditText(r.wartosc)
                box.currentIndexChanged.connect(lambda _i, c=country: self._ustaw_stawke(c))
                editor = box.lineEdit()
                if editor is not None:
                    editor.textEdited.connect(lambda _text, c=country: self._ustaw_stawke(c))
                self.tabela.setCellWidget(row, 1, box)
                self.tabela.setRowHeight(row, max(44, box.sizeHint().height() + 10))
                self._wiersze[country] = (item, box)
        finally:
            self.tabela.blockSignals(prev)
        for box, rows, value, prompt in (
            (self.przedmiot, self._meta.przedmioty, u.przedmiot if u else "", "Wybierz…"),
            (self.zwolnienie, self._meta.zwolnienia, u.zwolnienie if u else "", "Nie dotyczy"),
        ):
            box.clear()
            box.addItem(prompt, "")
            for ident, label in rows:
                box.addItem(label, ident)
            index = box.findData(value)
            if value and index < 0:
                box.addItem("Niedostępne: " + value, value)
                index = box.count() - 1
            if not value and box is self.przedmiot and len(rows) == 1:
                index = 1
            box.setCurrentIndex(max(0, index))

    def _zadanie(self, f: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self._busy or self._zamkniete:
            return
        self._busy = True
        self._przyciski()

        def aktywne() -> bool:
            if self._zamkniete:
                return False
            self._busy = False
            if not self._aktualne():
                self.status.setText("Sesja konta zmieniła się. Otwórz VAT ponownie.")
                self.zastosuj.setEnabled(False)
                return False
            return True

        def ok(result: object) -> None:
            if not aktywne():
                return
            sukces(result)
            self._przyciski()

        def blad(kod: str, opis: str) -> None:
            if not aktywne():
                return
            self.status.setText(opis + " Możesz ponowić pobieranie.")
            self._przyciski()

        self._uruchom(f, ok, blad)

    def pobierz(self) -> None:
        if self._busy or self._zamkniete:
            return
        current = self.formularz() if self._meta else self._poprzednie
        self.status.setText("Pobieranie dopuszczalnych stawek VAT…")

        def ok(result: object) -> None:
            self._meta = cast(VATKategorii, result)
            self._pokaz(current)
            self.status.setText(
                "Stawki pobrane. Zaznacz obsługiwane kraje."
                if self._meta.kraje
                else "Allegro nie udostępnia stawek VAT w tej kategorii."
            )

        self._zadanie(self._pobierz, ok)

    def kopiuj_oferte(self) -> None:
        if self._meta is None or self._busy:
            return
        ident = self.ident.text().strip()
        if not ident:
            self.status.setText("Wpisz ID własnej oferty Allegro.")
            return
        self.status.setText("Pobieranie VAT z oferty " + ident + "…")

        def ok(result: object) -> None:
            self._pokaz(cast(UstawieniaVAT, result))
            self.stosuj.setChecked(True)
            self.status.setText(
                "VAT pobrany z oferty " + ident + ". Sprawdź kraje i zastosuj do grupy."
            )

        self._zadanie(lambda: self._oferta(ident), ok)

    def zapisz(self) -> None:
        if not self._aktualne():
            self.status.setText("Sesja konta zmieniła się. Otwórz VAT ponownie.")
            return
        if not self.stosuj.isChecked():
            self.wynik = None
            self.accept()
            return
        if self._busy or self._meta is None:
            self.status.setText("Najpierw pobierz dostępne stawki z Allegro.")
            return
        try:
            raw = self.formularz()
            sprawdz_vat(raw, self._meta)
            u = UstawieniaVAT(
                tuple(StawkaVAT(r.kraj, normalizuj_vat(r.wartosc), r.etykieta) for r in raw.stawki),
                raw.przedmiot,
                raw.zwolnienie,
            )
            sprawdz_vat(u, self._meta)
        except BladAllegro as exc:
            self.status.setText(str(exc))
            return
        self.wynik = u
        self.accept()
