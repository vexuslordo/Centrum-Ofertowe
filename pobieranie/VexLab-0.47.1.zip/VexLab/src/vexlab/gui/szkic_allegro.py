"""Podgląd wskazanego szkicu konta Allegro; bez edycji i publikacji."""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QDialogButtonBox, QVBoxLayout, QWidget

from vexlab.gui.podglad_oferty import ObrazyOferty, PodgladOferty
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import SesjaAllegro, SzczegolySzkicuAllegro
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec


class PodgladSzkicuAllegro(QDialog):
    def __init__(
        self,
        parent: QWidget,
        szczegoly: SzczegolySzkicuAllegro,
        sesja: SesjaAllegro,
        zdjecia: PodgladZdjec | None,
        uruchom: Uruchom,
    ) -> None:
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowTitle("Podgląd oferty Allegro")
        self.resize(1000, 760)
        self.szczegoly = szczegoly
        self.obrazy = ObrazyOferty(self, zdjecia, uruchom)
        self.finished.connect(lambda _: self.obrazy.zamknij())
        layout = QVBoxLayout(self)
        layout.addWidget(
            etykieta(
                f"{sesja.srodowisko.value} • {sesja.konto.login} • "
                f"ID: {szczegoly.id} • {szczegoly.status.value}"
            )
        )
        cena = f"{szczegoly.cena} {szczegoly.waluta}" if szczegoly.cena else "Brak ceny"
        stan = str(szczegoly.stan) if szczegoly.stan is not None else "—"
        layout.addWidget(
            etykieta(f"Cena: {cena} • Dostępne: {stan} • Kategoria: {szczegoly.kategoria or '—'}")
        )
        self.podglad = PodgladOferty(self.obrazy)
        oferta = OfertaPodglad(
            0,
            szczegoly.sku,
            szczegoly.tytul,
            "",
            "",
            cena,
            "",
            szczegoly.zdjecia,
            szczegoly.sekcje,
            (),
        )
        self.podglad.pokaz(oferta, szczegoly.sekcje)
        layout.addWidget(self.podglad, 1)
        if not szczegoly.sekcje:
            layout.addWidget(etykieta("Ta oferta nie zawiera opisu."))
        layout.addWidget(
            etykieta(
                "Dane pobrane z Allegro. Podgląd nie zapisuje zmian ani nie uruchamia sprzedaży."
            )
        )
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        buttons.rejected.connect(self.close)
        layout.addWidget(buttons)
