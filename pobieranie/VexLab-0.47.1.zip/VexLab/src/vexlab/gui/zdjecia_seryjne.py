"""Konfiguracja, postęp i zatrzymanie pobierania zdjęć zaznaczenia."""

from collections.abc import Callable
from threading import Event
from typing import cast

from PySide6.QtCore import QObject, Signal, Slot
from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import (
    QCheckBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.importowanie import DialogPotwierdzenia
from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import ProduktDTO
from vexlab.przypadki_uzycia.media import strona_zdjec
from vexlab.przypadki_uzycia.zdjecia_seryjne import PobierzZdjeciaSeryjnie, WynikZdjecSeryjnych
from vexlab.rdzen.kontrakty import BladTechniczny


class PostepZdjec(QObject):
    zmiana = Signal(int, int, str)


class DialogZdjecSeryjnych(DialogPotwierdzenia):
    zapisano = Signal()

    def __init__(
        self,
        produkty: tuple[ProduktDTO, ...],
        serwis: PobierzZdjeciaSeryjnie,
        strona: str,
        limit_mb: int,
        zapamietaj: Callable[[str, int], None],
        uruchom: Uruchom,
        parent: QWidget,
    ) -> None:
        super().__init__(parent)
        self.produkty, self.serwis, self.zapamietaj, self.uruchom = (
            produkty,
            serwis,
            zapamietaj,
            uruchom,
        )
        self.stop = Event()
        self.sygnaly = PostepZdjec(self)
        self.sygnaly.zmiana.connect(self.postep)
        self.setWindowTitle("Pobierz zdjęcia po SKU")
        self.resize(600, 520)
        layout = QVBoxLayout(self)
        label = QLabel(
            f"Wybrano produktów: {len(produkty)}. Pobieramy po jednym zdjęciu; "
            f"istniejące galerie pozostają."
        )
        label.setWordWrap(True)
        layout.addWidget(label)
        self.konfiguracja = QWidget()
        form = QFormLayout(self.konfiguracja)
        self.strona = QLineEdit(strona)
        self.strona.setPlaceholderText("https://adres-strony-producenta")
        self.strona.setAccessibleName("Strona internetowa producenta")
        self.limit = QSpinBox()
        self.limit.setRange(1, 4096)
        self.limit.setSuffix(" MB")
        self.limit.setValue(limit_mb)
        self.pamietaj = QCheckBox("Zapamiętaj adres i limit w moich ustawieniach")
        self.pamietaj.setChecked(True)
        form.addRow("Strona producenta", self.strona)
        form.addRow("Limit nowych danych zdjęć", self.limit)
        form.addRow(self.pamietaj)
        layout.addWidget(self.konfiguracja)
        info = QLabel(
            "Obsługiwany jest publiczny katalog Shopify. Przed pierwszym "
            "zapisem powstanie jedna kopia bazy; zajmuje dodatkowe miejsce."
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        self.pasek = QProgressBar()
        self.pasek.setRange(0, len(produkty))
        layout.addWidget(self.pasek)
        self.info = QLabel("")
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        self.raport = QPlainTextEdit()
        self.raport.setReadOnly(True)
        layout.addWidget(self.raport, 1)
        buttons = QHBoxLayout()
        self.start = QPushButton("Pobierz zdjęcia")
        self.start.setObjectName("primary")
        self.start.clicked.connect(self.pobierz)
        self.zamknij = QPushButton("Zamknij")
        self.zamknij.clicked.connect(self.reject)
        buttons.addWidget(self.start)
        buttons.addWidget(self.zamknij)
        layout.addLayout(buttons)

    @Slot(int, int, str)
    def postep(self, i: int, total: int, tekst: str) -> None:
        self.pasek.setRange(0, total)
        self.pasek.setValue(i)
        self.info.setText(tekst)

    def pobierz(self) -> None:
        if self.trwa:
            return
        try:
            strona = strona_zdjec(self.strona.text())
            limit = self.limit.value()
            if self.pamietaj.isChecked():
                self.zapamietaj(strona, limit)
        except (BladScenariuszaKatalogu, BladTechniczny, ValueError) as exc:
            self.info.setText(str(exc))
            return
        self.stop.clear()
        self.trwa = True
        self.konfiguracja.setEnabled(False)
        self.start.setEnabled(False)
        self.zamknij.setText("Zatrzymaj")
        self.info.setText("Pobieranie zdjęć…")

        def gotowe(w: object) -> None:
            self.trwa = False
            wynik = cast(WynikZdjecSeryjnych, w)
            self.start.hide()
            self.zamknij.setText("Zamknij")
            self.info.setText(
                f"Zapisano: {wynik.zapisane}; pominięto: {wynik.pominiete}; błędy: "
                f"{wynik.nieudane}. "
                f"Nowe zdjęcia: {wynik.bajty / 1024 / 1024:.2f} MB."
            )
            self.raport.setPlainText(
                "\n".join(
                    filter(
                        None,
                        (
                            wynik.powod_zatrzymania,
                            f"Kopia: {wynik.kopia}" if wynik.kopia else "Bez zmian w bazie.",
                            *(f"{sku}: {blad}" for sku, blad in wynik.bledy),
                        ),
                    )
                )
            )
            self.zapisano.emit()

        def blad(kod: str, tekst: str) -> None:
            self.trwa = False
            self.zamknij.setText("Zamknij")
            self.info.setText(tekst)
            self.start.setEnabled(True)
            self.konfiguracja.setEnabled(True)
            self.zapisano.emit()

        self.uruchom(
            lambda: self.serwis.wykonaj(
                self.produkty, strona, limit, self.stop.is_set, self.sygnaly.zmiana.emit
            ),
            gotowe,
            blad,
        )

    def _zatrzymaj(self) -> None:
        self.stop.set()
        self.info.setText("Zatrzymywanie po bieżącym odczycie. Zakończone zapisy pozostają.")

    def reject(self) -> None:
        if self.trwa:
            self._zatrzymaj()
        else:
            super().reject()

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.trwa:
            self._zatrzymaj()
            event.ignore()
        else:
            super().closeEvent(event)
