"""Podgląd i jawne zastosowanie roboczej edycji wybranych pozycji."""

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.edycja_paczki_allegro import ZmianyPaczek, zmien_pozycje
from vexlab.przypadki_uzycia.nowe_szkice_allegro import UstawieniaSzkicu
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad


class MasowaPaczkaAllegro(QDialog):
    def __init__(
        self, parent: QWidget, pozycje: tuple[tuple[OfertaPodglad, UstawieniaSzkicu], ...]
    ) -> None:
        super().__init__(parent)
        self.pozycje = pozycje
        self.wynik: tuple[tuple[OfertaPodglad, UstawieniaSzkicu], ...] = ()
        self.setWindowTitle(f"Edytuj zaznaczone • {len(pozycje)} pozycji")
        self.resize(980, 700)
        layout = QVBoxLayout(self)
        layout.addWidget(
            etykieta(
                "Wybierz pola do zmiany i sprawdź podgląd. "
                "SKU, EAN, zdjęcia i opis zostają zachowane."
            )
        )
        form = QFormLayout()
        self.tytuly = QCheckBox("Zmień tytuły")
        self.szukaj, self.zamien, self.przed, self.po = (QLineEdit() for _ in range(4))
        form.addRow(self.tytuly)
        for nazwa, pole in (
            ("Znajdź fragment", self.szukaj),
            ("Zastąp przez", self.zamien),
            ("Dodaj na początku", self.przed),
            ("Dodaj na końcu", self.po),
        ):
            pole.setAccessibleName(nazwa)
            form.addRow(nazwa, pole)
        self.ceny = QCheckBox("Zmień ceny brutto")
        self.tryb = QComboBox()
        for nazwa, value in (
            ("Ustaw cenę", "ustaw"),
            ("Zmień o procent (+/−)", "procent"),
            ("Zmień o kwotę (+/−)", "kwota"),
        ):
            self.tryb.addItem(nazwa, value)
        self.wartosc = QLineEdit()
        self.wartosc.setAccessibleName("Wartość zmiany ceny")
        form.addRow(self.ceny, self.tryb)
        form.addRow("Wartość", self.wartosc)
        self.liczby = QCheckBox("Zmień ilości")
        self.ilosc = QSpinBox()
        self.ilosc.setRange(0, 10000000)
        self.ilosc.setValue(1)
        form.addRow(self.liczby, self.ilosc)
        layout.addLayout(form)
        self.podglad = QPushButton("Pokaż zmiany")
        layout.addWidget(self.podglad)
        self.tabela = QTableWidget(0, 5)
        self.tabela.setHorizontalHeaderLabels(
            ("SKU", "Tytuł po zmianie", "Cena przed → po", "Ilość przed → po", "Waluta")
        )
        self.tabela.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setColumnWidth(1, 360)
        layout.addWidget(self.tabela, 1)
        self.info = etykieta(
            "Zmiany dotyczą tylko przygotowywanej paczki. Wysyłka wymaga osobnego potwierdzenia."
        )
        layout.addWidget(self.info)
        self.buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Apply | QDialogButtonBox.StandardButton.Cancel
        )
        self.zastosuj = self.buttons.button(QDialogButtonBox.StandardButton.Apply)
        self.zastosuj.setText(f"Zastosuj do {len(pozycje)} pozycji")
        self.zastosuj.setEnabled(False)
        self.zastosuj.clicked.connect(self.accept)
        self.buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        self.podglad.clicked.connect(self.sprawdz)
        for pole in (self.szukaj, self.zamien, self.przed, self.po, self.wartosc):
            pole.textChanged.connect(self.uniewaznij)
        for check in (self.tytuly, self.ceny, self.liczby):
            check.toggled.connect(self.uniewaznij)
        self.tryb.currentIndexChanged.connect(self.uniewaznij)
        self.ilosc.valueChanged.connect(self.uniewaznij)

    def uniewaznij(self) -> None:
        self.wynik = ()
        self.zastosuj.setEnabled(False)

    def sprawdz(self) -> None:
        self.uniewaznij()
        if not any(c.isChecked() for c in (self.tytuly, self.ceny, self.liczby)):
            self.info.setText("Wybierz co najmniej jedno pole do zmiany.")
            return
        try:
            self.wynik = zmien_pozycje(
                self.pozycje,
                ZmianyPaczek(
                    str(self.tryb.currentData()) if self.ceny.isChecked() else "",
                    self.wartosc.text(),
                    self.ilosc.value() if self.liczby.isChecked() else None,
                    self.tytuly.isChecked(),
                    self.szukaj.text(),
                    self.zamien.text(),
                    self.przed.text(),
                    self.po.text(),
                ),
            )
        except BladAllegro as exc:
            self.info.setText(str(exc))
            return
        self.tabela.setRowCount(len(self.wynik))
        for i, ((old, before), (new, after)) in enumerate(
            zip(self.pozycje, self.wynik, strict=True)
        ):
            for j, value in enumerate(
                (
                    new.sku,
                    new.tytul,
                    f"{before.cena or old.cena} → {after.cena or new.cena}",
                    f"{before.ilosc} → {after.ilosc}",
                    after.waluta,
                )
            ):
                self.tabela.setItem(i, j, QTableWidgetItem(value))
        self.zastosuj.setEnabled(True)
        self.info.setText(
            f"Podgląd zmian dla {len(self.wynik)} pozycji. "
            "Zastosuj, aby ponownie sprawdzić plan Allegro."
        )
