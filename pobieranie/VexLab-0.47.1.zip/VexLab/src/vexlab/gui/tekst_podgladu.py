"""Wspólny bezpieczny tekst podglądu; HTML nie ładuje zasobów."""

from html import escape
from html.parser import HTMLParser

from PySide6.QtCore import Qt, QUrl
from PySide6.QtWidgets import QLabel, QTextBrowser


class FiltrHTML(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.wynik: list[str] = []
        self.ukryte = 0
        self.zakazane = {"script", "style", "iframe", "object", "svg"}
        self.dozwolone = {
            "p",
            "b",
            "strong",
            "i",
            "em",
            "u",
            "ul",
            "ol",
            "li",
            "br",
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            "h6",
        }

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self.zakazane:
            self.ukryte += 1
        elif not self.ukryte and tag in self.dozwolone:
            self.wynik.append(f"<{tag}>")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.zakazane:
            self.ukryte = max(0, self.ukryte - 1)
        elif not self.ukryte and tag in self.dozwolone and tag != "br":
            self.wynik.append(f"</{tag}>")

    def handle_data(self, data: str) -> None:
        if not self.ukryte:
            self.wynik.append(escape(data))


def bezpieczny_html(tekst: str) -> str:
    parser = FiltrHTML()
    parser.feed(tekst)
    parser.close()
    return "".join(parser.wynik)


class TekstPodgladu(QTextBrowser):
    def __init__(self, tekst: str) -> None:
        super().__init__()
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setHtml(bezpieczny_html(tekst))
        self.setMinimumHeight(120)

    def loadResource(self, typ: int, nazwa: QUrl | str) -> object:
        return None  # Nigdy nie odczytuj zasobów z dysku/sieci na żądanie HTML.


def etykieta(tekst: str) -> QLabel:
    label = QLabel(tekst)
    label.setTextFormat(Qt.TextFormat.PlainText)
    label.setWordWrap(True)
    return label
