"""Jawny zakres i pola masowej zmiany lokalnych Produktów."""

from collections import Counter
from uuid import UUID

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QLabel,
    QPlainTextEdit,
    QProgressBar,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.katalog import nazwa_wyboru_producenta
from vexlab.przypadki_uzycia.katalog import ZmianaMasowa
from vexlab.przypadki_uzycia.producenci import ProducentDTO


class FormularzMasowy(QDialog):
    def __init__(self, liczba: int, producenci: list[ProducentDTO], parent: QWidget) -> None:
        super().__init__(parent)
        self.setWindowTitle("Edycja masowa — lokalne Produkty")
        self.setMinimumWidth(500)
        self.trwa = False
        layout = QVBoxLayout(self)
        opis = QLabel(
            f"Zakres: {liczba} zaznaczonych Produktów. Zmieniasz tylko wybrane pola.\n"
            "Przed zapisem powstanie kopia bazy. Bez publikacji w kanałach."
        )
        opis.setWordWrap(True)
        layout.addWidget(opis)
        self.zmien_producenta = QCheckBox("Zmień producenta we wszystkich zaznaczonych")
        self.producent = QComboBox()
        self.producent.addItem("Usuń przypisanie producenta", None)
        self.producent.setEnabled(False)
        nazwy = Counter(p.nazwa.casefold() for p in producenci)
        for p in producenci:
            if p.aktywny:
                self.producent.addItem(nazwa_wyboru_producenta(p, nazwy), str(p.id))
        self.zmien_producenta.toggled.connect(self.producent.setEnabled)
        layout.addWidget(self.zmien_producenta)
        layout.addWidget(self.producent)
        layout.addWidget(QLabel("Opis we wszystkich zaznaczonych:"))
        self.tryb = QComboBox()
        for text, kod in [
            ("Nie zmieniaj opisu", "bez_zmian"),
            ("Zastąp opis", "zastap"),
            ("Dopisz do opisu", "dopisz"),
            ("Wyczyść opis", "wyczysc"),
        ]:
            self.tryb.addItem(text, kod)
        self.opis = QPlainTextEdit()
        self.opis.setAccessibleName("Tekst zmiany opisu zaznaczonych Produktów")
        layout.addWidget(self.tryb)
        layout.addWidget(self.opis)
        self.dolacz_nazwe = QCheckBox("Dołącz nazwę każdego produktu do jego opisu")
        self.dolacz_nazwe.setToolTip(
            "Kopiuje nazwę z modelem/rocznikami, jeśli są podane. "
            "Bez tłumaczenia i zgadywania dopasowania."
        )
        layout.addWidget(self.dolacz_nazwe)
        self.blad = QLabel()
        self.blad.setTextFormat(Qt.TextFormat.PlainText)
        self.blad.setWordWrap(True)
        layout.addWidget(self.blad)
        self.postep = QProgressBar()
        self.postep.setRange(0, 0)
        self.postep.setAccessibleName("Trwa sprawdzanie, wykonywanie kopii i zapis zmian masowych")
        self.postep.hide()
        layout.addWidget(self.postep)
        self.przyciski = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        self.zapisz = self.przyciski.button(QDialogButtonBox.StandardButton.Save)
        self.zapisz.setText("Zastosuj do zaznaczonych")
        self.zapisz.setObjectName("primary")
        self.przyciski.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        self.przyciski.rejected.connect(self.reject)
        layout.addWidget(self.przyciski)

    def dane(self) -> ZmianaMasowa:
        pid = self.producent.currentData()
        return ZmianaMasowa(
            self.zmien_producenta.isChecked(),
            UUID(pid) if pid else None,
            str(self.tryb.currentData()),
            self.opis.toPlainText(),
            self.dolacz_nazwe.isChecked(),
        )

    def ustaw_trwa(self, trwa: bool) -> None:
        self.trwa = trwa
        self.postep.setVisible(trwa)
        self.zapisz.setText("Zapisywanie…" if trwa else "Zastosuj do zaznaczonych")
        self.setEnabled(not trwa)

    def reject(self) -> None:
        if not self.trwa:
            super().reject()
