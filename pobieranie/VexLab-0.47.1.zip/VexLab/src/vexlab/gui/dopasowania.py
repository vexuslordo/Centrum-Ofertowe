"""Edytor roboczej listy dopasowań. Walidacja i zapis należą do scenariusza Produktu."""

from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.przypadki_uzycia.katalog import DaneDopasowania


class EdytorDopasowan(QDialog):
    def __init__(self, dane: tuple[DaneDopasowania, ...], parent: QWidget) -> None:
        super().__init__(parent)
        self.setWindowTitle("Pasuje do motocykli")
        self.resize(820, 420)
        layout = QVBoxLayout(self)
        tekst = QLabel(
            "Lista jest opcjonalna — także dla produktów uniwersalnych i pozostałego asortymentu. "
            "Dodany wiersz wymaga marki i modelu. Puste roczniki oznaczają brak danych; "
            "sam rok od oznacza niepodany koniec. Zmiany zapiszesz wraz z Produktem."
        )
        tekst.setWordWrap(True)
        layout.addWidget(tekst)
        self.tabela = QTableWidget(0, 5)
        self.tabela.setAccessibleName(
            "Dopasowania: marka motocykla, model, rocznik od, rocznik do, wariant"
        )
        self.tabela.verticalHeader().hide()
        self.tabela.verticalHeader().setDefaultSectionSize(36)
        self.tabela.setHorizontalHeaderLabels(
            ["Marka motocykla *", "Model *", "Rocznik od", "Rocznik do", "Wariant / uwagi"]
        )
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        for d in dane:
            self.dodaj(d)
        layout.addWidget(self.tabela)
        pasek = QHBoxLayout()
        dodaj = QPushButton("Dodaj motocykl")
        dodaj.clicked.connect(lambda: self.dodaj(DaneDopasowania("", "")))
        pasek.addWidget(dodaj)
        usun = QPushButton("Usuń wybrany wiersz")
        usun.clicked.connect(self.usun)
        pasek.addWidget(usun)
        layout.addLayout(pasek)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Zastosuj w formularzu")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def dodaj(self, dane: DaneDopasowania) -> None:
        i = self.tabela.rowCount()
        self.tabela.insertRow(i)
        for j, tekst in enumerate((dane.marka, dane.model, dane.rok_od, dane.rok_do, dane.wariant)):
            self.tabela.setItem(i, j, QTableWidgetItem(tekst))
        self.tabela.setCurrentCell(i, 0)

    def usun(self) -> None:
        i = self.tabela.currentRow()
        if i >= 0:
            self.tabela.removeRow(i)

    def dane(self) -> tuple[DaneDopasowania, ...]:
        wynik = []
        for i in range(self.tabela.rowCount()):
            pola = [
                item.text() if (item := self.tabela.item(i, j)) is not None else ""
                for j in range(5)
            ]
            wynik.append(DaneDopasowania(*pola))
        return tuple(wynik)
