"""Rozwijana grupa nawigacji; widoczność nie zmienia aktywnej strony."""

from PySide6.QtCore import QEvent, QSize, Qt
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import QApplication, QFrame, QSizePolicy, QToolButton, QVBoxLayout

from vexlab.gui.design_system import ikona


class SekcjaMenu(QFrame):
    def __init__(self, nazwa: str) -> None:
        super().__init__()
        self.nazwa = nazwa.capitalize()
        self.setObjectName("sekcjaMenu")
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        self.uklad = layout
        self.belka = QToolButton()
        self.belka.setObjectName("grupaMenu")
        self.belka.setProperty("grupa", nazwa)
        self.belka.setText(self.nazwa)
        self.belka.setCheckable(True)
        self.belka.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.belka.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        layout.addWidget(self.belka)
        self.pozycje = QFrame()
        self.pozycje.setObjectName("pozycjeMenu")
        self.lista = QVBoxLayout(self.pozycje)
        self.lista.setContentsMargins(10, 0, 0, 5)
        self.lista.setSpacing(2)
        layout.addWidget(self.pozycje)

    def ustaw(self, rozwinieta: bool, kompakt: bool) -> None:
        self.belka.setChecked(rozwinieta)
        self._ikona()
        akcja = "Zwiń" if rozwinieta else "Rozwiń"
        self.belka.setAccessibleName(f"{akcja} grupę {self.nazwa}")
        self.belka.setToolTip(self.belka.accessibleName())
        self.belka.setVisible(not kompakt)
        self.pozycje.setVisible(kompakt or rozwinieta)
        self.uklad.setContentsMargins(0, 0, 0, 0 if kompakt else 2)
        self.lista.setContentsMargins(0 if kompakt else 10, 0, 0, 0 if kompakt else 5)

    def _ikona(self) -> None:
        ciemny = QApplication.palette().color(QPalette.ColorRole.Window).lightness() < 128
        kolory = {
            "Produkty": ("#7DA1C3", "#3D6E9B"),
            "Oferty": ("#7BA990", "#3D7459"),
            "Sprzedaż": ("#B59A80", "#846347"),
            "Analityka": ("#899FB9", "#526E91"),
            "Narzędzia": ("#A294BB", "#796095"),
        }
        kolor = kolory.get(self.nazwa, ("#91A4BA", "#536E8B"))[0 if ciemny else 1]
        symbol = "zwin_grupe" if self.belka.isChecked() else "rozwin_grupe"
        self.belka.setIcon(ikona(symbol, kolor))
        self.belka.setIconSize(QSize(12, 12))

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() in (
            QEvent.Type.PaletteChange,
            QEvent.Type.ApplicationPaletteChange,
        ) and hasattr(self, "belka"):
            self._ikona()
