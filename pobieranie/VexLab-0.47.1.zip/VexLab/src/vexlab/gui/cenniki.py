"""Biblioteka cenników: źródło → wybór pozycji → katalog."""

from collections.abc import Callable
from pathlib import Path
from typing import cast
from uuid import UUID

from PySide6.QtCore import QEvent, QItemSelection, QItemSelectionModel, QPoint, Qt, QTimer, Signal
from PySide6.QtGui import QBrush, QKeySequence, QPalette, QResizeEvent, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QSplitter,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from vexlab.gui.design_system import kolor_statusu_cennika
from vexlab.gui.importowanie import StronaImportu, tabela
from vexlab.gui.producenci import Uruchom
from vexlab.gui.przyciski import PrzyciskAkcji
from vexlab.gui.strony_cennika import TabelaPozycji
from vexlab.gui.strony_katalogu import PasekStron
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.cenniki import (
    BibliotekaCennikow,
    CennikDTO,
    PozycjaCennika,
    WynikCennika,
)
from vexlab.przypadki_uzycia.strony_cennika import IndeksCennika, PrzegladCennika, StronaCennika


class StronaCennikow(QWidget):
    zmieniono = Signal()

    def __init__(
        self, serwis: BibliotekaCennikow, importer: StronaImportu, uruchom: Uruchom
    ) -> None:
        super().__init__()
        self.serwis, self.importer, self.uruchom = serwis, importer, uruchom
        self.przeglad = PrzegladCennika(serwis)
        self.indeks: IndeksCennika | None = None
        self._strona = 0
        self._rozmiar = 100
        self._wybrane_pozycje: set[int] = set()
        self._przywracanie = False
        self._budowanie_pozycji = False
        self.cenniki: tuple[CennikDTO, ...] = ()
        self.pozycje: tuple[PozycjaCennika, ...] = ()
        self.cennik: CennikDTO | None = None
        self._trwa = False
        self._generacja = 0
        self._numer_podgladu = 0
        self._podglad_trwa = False
        self._budowanie_listy = False
        self._aktualizowany: CennikDTO | None = None
        self._wybor_po_zapisie: UUID | None = None
        self.setObjectName("strona")
        layout = QVBoxLayout(self)
        self.stos = QStackedWidget()
        layout.addWidget(self.stos, 1)
        self.info = etykieta("")
        layout.addWidget(self.info)
        self.raport = etykieta("")
        layout.addWidget(self.raport)
        self.biblioteka = QWidget()
        uklad = QVBoxLayout(self.biblioteka)
        tytul = etykieta("Cenniki")
        tytul.setObjectName("marka")
        uklad.addWidget(tytul)
        uklad.addWidget(
            etykieta("Wybierz cennik, porównaj ceny i dodaj wybrane produkty do katalogu.")
        )
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj nazwy, producenta lub roku…")
        self.szukaj.textChanged.connect(self._lista)
        uklad.addWidget(self.szukaj)
        actions = QHBoxLayout()
        self.dodaj_cennik_przycisk = PrzyciskAkcji("Dodaj cennik", "dodaj")
        self.dodaj_cennik_przycisk.setObjectName("primary")
        self.dodaj_cennik_przycisk.clicked.connect(self.nowy)
        actions.addWidget(self.dodaj_cennik_przycisk)
        self.dodaj_przycisk = QPushButton("Dodaj do katalogu")
        self.dodaj_przycisk.clicked.connect(self.dodaj)
        actions.addWidget(self.dodaj_przycisk)
        self.wiecej = QToolButton()
        self.wiecej.setObjectName("menuAkcji")
        self.wiecej.setText("Więcej")
        self.wiecej.setAccessibleName("Więcej akcji cenników")
        self.wiecej.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.menu = QMenu(self)
        self.aktualizuj_akcja = self.menu.addAction("Aktualizuj cennik…", self.aktualizuj_cennik)
        self.menu.addAction("Odśwież", self.odswiez)
        self.aktualny_akcja = self.menu.addAction(
            "Ustaw jako bazowy (aktualny)…", lambda: self.oznacz(True)
        )
        self.archiwalny_akcja = self.menu.addAction("Archiwizuj…", lambda: self.oznacz(False))
        self.menu.addSeparator()
        self.menu.addAction("Zaznacz wszystkie produkty", lambda: self.wiersze.selectAll())
        self.menu.addAction("Odznacz produkty", lambda: self.wiersze.clearSelection())
        self.menu.addAction("Uzupełnij brakujące ceny…", self.ceny)
        self.menu.addSeparator()
        self.menu.addAction("Do poprawy", self.korekty)
        self.menu.addAction("Import bezpośredni…", self.bezposredni)
        self.menu.addSeparator()
        self.usun_akcja = self.menu.addAction("Usuń zaznaczone cenniki…", self.usun)
        self.menu.aboutToShow.connect(self._stan_akcji)
        self.wiecej.setMenu(self.menu)
        actions.addWidget(self.wiecej)
        actions.addStretch()
        uklad.addLayout(actions)
        self.podzial = QSplitter(Qt.Orientation.Horizontal)
        self.panel_listy = QWidget()
        lista_layout = QVBoxLayout(self.panel_listy)
        lista_layout.setContentsMargins(0, 0, 0, 0)
        self.tabela = tabela(["Cennik", "Producent", "Rok", "Status"])
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tabela.verticalHeader().hide()
        self.tabela.setAccessibleName("Zapisane cenniki — wybierz do podglądu")
        for i, width in enumerate((105, 100, 75, 100)):
            self.tabela.setColumnWidth(i, width)
        self.tabela.itemSelectionChanged.connect(lambda: self.otworz())
        self.tabela.doubleClicked.connect(self.otworz)
        self.tabela.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tabela.customContextMenuRequested.connect(self._menu_cennikow)
        lista_layout.addWidget(self.tabela, 1)
        self.podzial.addWidget(self.panel_listy)
        uklad.addWidget(self.podzial, 1)
        self.stos.addWidget(self.biblioteka)
        self.kreator = QWidget()
        uklad = QVBoxLayout(self.kreator)
        top = QHBoxLayout()
        b = QPushButton("← Cenniki")
        b.clicked.connect(self.wroc)
        top.addWidget(b)
        self.zapisz = QPushButton("Zapisz cennik")
        self.zapisz.clicked.connect(self.zapisz_cennik)
        top.addWidget(self.zapisz)
        direct = QPushButton("Import bezpośredni…")
        direct.clicked.connect(self.bezposredni)
        top.addWidget(direct)
        uklad.addLayout(top)
        self.metadane = QWidget()
        form = QFormLayout(self.metadane)
        self.nazwa = QLineEdit()
        self.rok = QSpinBox()
        self.rok.setRange(0, 9999)
        self.rok.setSpecialValueText("Podaj rok")
        self.wydanie = QLineEdit()
        self.wydanie.setPlaceholderText("Opcjonalnie, np. marzec / wersja 2")
        form.addRow("Nazwa cennika *", self.nazwa)
        form.addRow("Rok *", self.rok)
        form.addRow("Wydanie / data", self.wydanie)
        uklad.addWidget(self.metadane)
        uklad.addWidget(importer, 1)
        self.stos.addWidget(self.kreator)
        self.wiersze: QTableWidget
        self.szczegoly = QWidget()
        uklad = QVBoxLayout(self.szczegoly)
        self.naglowek = etykieta("")
        uklad.addWidget(self.naglowek)
        self.metryka = etykieta("Wybierz jeden cennik z listy po lewej.")
        uklad.addWidget(self.metryka)
        top = QHBoxLayout()
        self.status_pozycji = QComboBox()
        self.status_pozycji.setAccessibleName("Filtr statusu pozycji cennika")
        self.status_pozycji.addItems(
            ["Wszystkie pozycje", "Nowy", "W katalogu", "Inna cena", "Do poprawy"]
        )
        self.status_pozycji.currentTextChanged.connect(self._wiersze)
        top.addWidget(self.status_pozycji)
        self.licznik = etykieta("Zaznaczono: 0")
        top.addWidget(self.licznik)
        top.addStretch()
        uklad.addLayout(top)
        self.filtr = QLineEdit()
        self.filtr.setPlaceholderText("Szukaj po SKU lub nazwie…")
        self.filtr.textChanged.connect(self._wiersze)
        uklad.addWidget(self.filtr)
        self.wiersze = TabelaPozycji(
            ["Wiersz", "Nazwa", "SKU", "Cennik", "Bazowa", "Różnica", "Stan", "EAN"],
            self._zaznacz_wszystkie,
            self._odznacz,
        )
        for i, width in enumerate((55, 150, 105, 120, 120, 180, 110)):
            self.wiersze.setColumnWidth(i, width)
        self.wiersze.verticalHeader().hide()
        self.wiersze.setColumnWidth(7, 130)
        header = self.wiersze.horizontalHeader()
        header.moveSection(header.visualIndex(6), 1)
        header.moveSection(header.visualIndex(7), 4)
        self.wiersze.setColumnHidden(7, True)
        self.wiersze.setColumnHidden(0, True)
        self.wiersze.verticalHeader().setDefaultSectionSize(48)
        self.wiersze.setAccessibleName("Pozycje cennika — wybierz i dodaj do katalogu")
        self.wiersze.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.wiersze.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.wiersze.customContextMenuRequested.connect(self._menu_pozycji)
        uklad.addWidget(self.wiersze, 1)
        self.pasek_stron = PasekStron()
        self.pasek_stron.opis.setAccessibleName("Bieżąca strona cennika")
        self.pasek_stron.ile.setAccessibleName("Liczba pozycji cennika na stronie")
        self.pasek_stron.strona.connect(self._zmien_strone)
        self.pasek_stron.rozmiar.connect(self._zmien_rozmiar)
        uklad.addWidget(self.pasek_stron)
        self.podzial.addWidget(self.szczegoly)
        self.podzial.setStretchFactor(0, 1)
        self.podzial.setStretchFactor(1, 3)
        self.podzial.setSizes([390, 900])
        self.wiersze.cellClicked.connect(self.pokaz_problem)
        self.problem_dialog: QMessageBox | None = None
        cast(QTableWidgetItem, self.wiersze.horizontalHeaderItem(4)).setToolTip(
            "Cena z aktualnego cennika producenta. Wybierz cennik i Więcej → Ustaw jako bazowy."
        )
        self.wiersze.itemSelectionChanged.connect(self._stan_akcji)
        self._stan_akcji()
        self.skroty: list[QShortcut] = []
        for t, menu in ((self.tabela, self._menu_cennikow), (self.wiersze, self._menu_pozycji)):
            for key in ("Shift+F10", "Menu"):
                skrot = QShortcut(QKeySequence(key), t)
                skrot.setContext(Qt.ShortcutContext.WidgetShortcut)
                skrot.activated.connect(lambda m=menu: m(QPoint(-1, -1)))
                self.skroty.append(skrot)
        importer.plan_zmieniony.connect(self._plan)
        importer.plik_zmieniony.connect(self._producent_aktualizacji)
        importer.zmieniono.connect(self.zmieniono.emit)

    def _zadanie(self, fn: Callable[[], object], sukces: Callable[[object], None]) -> None:
        if self._trwa or self.importer._trwa:
            return
        self._trwa = True
        self._numer_podgladu += 1
        self.stos.setEnabled(False)
        self.info.setText("Trwa odczyt lub zapis…")

        def ok(w: object) -> None:
            self._trwa = False
            self.stos.setEnabled(True)
            sukces(w)

        def blad(k: str, tekst: str) -> None:
            self._trwa = False
            self.stos.setEnabled(True)
            self.info.setText(tekst)

        self.uruchom(fn, ok, blad)

    def _kolor(self, item: QTableWidgetItem, stan: str) -> None:
        ciemny = self.palette().color(QPalette.ColorRole.Window).lightness() < 128
        kolor = kolor_statusu_cennika(stan, ciemny)
        item.setForeground(QBrush(kolor) if kolor else QBrush())

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.PaletteChange and hasattr(self, "wiersze"):
            for t, col in ((self.tabela, 3), (self.wiersze, 6)):
                for i in range(t.rowCount()):
                    item = t.item(i, col)
                    if item is not None:
                        self._kolor(item, item.text())

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        orientation = Qt.Orientation.Vertical if self.width() < 1100 else Qt.Orientation.Horizontal
        if self.podzial.orientation() != orientation:
            self.podzial.setOrientation(orientation)
            widths = (
                (55, 110, 85, 100, 100, 140, 90)
                if orientation == Qt.Orientation.Vertical
                else (55, 150, 105, 120, 120, 180, 110)
            )
            for i, width in enumerate(widths):
                self.wiersze.setColumnWidth(i, width)
            self.podzial.setSizes(
                [220, 500] if orientation == Qt.Orientation.Vertical else [390, 900]
            )

    def _stan_akcji(self) -> None:
        wybor = self._wybrane()
        jeden = len(wybor) == 1 and wybor[0].producent_id is not None
        self.aktualny_akcja.setEnabled(jeden and not wybor[0].aktualny and not self._trwa)
        self.archiwalny_akcja.setEnabled(jeden and wybor[0].aktualny and not self._trwa)
        self.usun_akcja.setEnabled(bool(wybor) and not self._trwa)
        self.aktualizuj_akcja.setEnabled(len(wybor) == 1 and not self._trwa)
        n = len(self._indeksy_wyboru())
        self.licznik.setText(f"Zaznaczono: {n}")
        self.dodaj_przycisk.setEnabled(
            bool(n)
            and self.cennik is not None
            and not self._trwa
            and not self._podglad_trwa
            and self.wiersze.isEnabled()
        )

    def _pusty_podglad(self, tekst: str) -> None:
        self._numer_podgladu += 1
        self._generacja += 1
        self.cennik = None
        self.indeks = None
        self._wybrane_pozycje.clear()
        self.pasek_stron.setEnabled(False)
        self.pozycje = ()
        self.wiersze.clearContents()
        self.wiersze.setRowCount(0)
        self._budowanie_pozycji = False
        self.naglowek.setText(tekst)
        self.metryka.setText("")
        self._stan_akcji()

    def wroc(self) -> None:
        if self._trwa or self.importer._trwa:
            return
        self._generacja += 1
        self.stos.setCurrentWidget(self.biblioteka)
        self.odswiez()

    def odswiez(self) -> None:
        def gotowe(w: object) -> None:
            self.cenniki = cast(tuple[CennikDTO, ...], w)
            self._lista()

        self._zadanie(self.serwis.lista, gotowe)

    def _lista(self) -> None:
        selected = (
            {self._wybor_po_zapisie} if self._wybor_po_zapisie else {c.id for c in self._wybrane()}
        )
        self._wybor_po_zapisie = None
        self._budowanie_listy = True
        self.tabela.blockSignals(True)
        tekst = self.szukaj.text().strip().casefold()
        rows = [
            c
            for c in self.cenniki
            if tekst in f"{c.nazwa} {c.producent} {c.rok} {c.wydanie}".casefold()
        ]
        self.tabela.clearSelection()
        self.tabela.setRowCount(len(rows))
        for i, c in enumerate(rows):
            for j, value in enumerate(
                (
                    c.nazwa,
                    c.producent or "—",
                    str(c.rok),
                    c.status,
                )
            ):
                item = QTableWidgetItem(value)
                item.setData(Qt.ItemDataRole.UserRole, c)
                item.setToolTip(
                    f"{c.nazwa} • {c.rok} • {c.wydanie or 'Bez wydania'}\n"
                    f"Pozycji: {c.liczba} • Wczytano: {c.wczytano_utc}\nPlik: {c.zrodlo}"
                )
                if j == 3:
                    self._kolor(item, c.status)
                self.tabela.setItem(i, j, item)
            if c.id in selected:
                self.tabela.selectionModel().select(
                    self.tabela.model().index(i, 0),
                    QItemSelectionModel.SelectionFlag.Select
                    | QItemSelectionModel.SelectionFlag.Rows,
                )
        self.info.setText(
            f"Cenniki: {len(rows)}. Wybierz jeden do podglądu; Ctrl+A zaznacza wyniki do usunięcia."
        )

        self.tabela.blockSignals(False)
        self._budowanie_listy = False
        self.otworz()

    def _wybrane(self) -> tuple[CennikDTO, ...]:
        return tuple(
            cast(
                CennikDTO,
                cast(QTableWidgetItem, self.tabela.item(i.row(), 0)).data(Qt.ItemDataRole.UserRole),
            )
            for i in self.tabela.selectionModel().selectedRows()
        )

    def nowy(self) -> None:
        self._aktualizowany = None
        self.importer.producent.setEnabled(True)
        self._pusty_podglad("Nowy cennik")
        self.nazwa.clear()
        self.rok.setValue(0)
        self.wydanie.clear()
        self.importer.wyczysc_import()
        self.raport.clear()
        self.importer.tryb_biblioteki(True)
        self.metadane.show()
        self.zapisz.show()
        self.importer.tabs.setCurrentIndex(0)
        self.importer.odswiez()
        self.stos.setCurrentWidget(self.kreator)
        self.info.setText(
            "Wskaż plik, producenta i kolumny. Sprawdź dane, podaj nazwę oraz rok i zapisz cennik."
        )

    def aktualizuj_cennik(self) -> None:
        wybrane = self._wybrane()
        if len(wybrane) != 1 or self._trwa:
            return
        stary = wybrane[0]
        self.nowy()
        self._aktualizowany = stary
        self.nazwa.setText(stary.nazwa)
        self.rok.setValue(stary.rok)
        self.info.setText(
            "Wybierz nowy plik i sprawdź mapowanie. Poprzednie wydanie "
            "pozostanie w historii; nowe pokaże zmianę ceny względem niego."
        )

    def _producent_aktualizacji(self) -> None:
        stary = self._aktualizowany
        if stary is None:
            return
        pid = str(stary.producent_id) if stary.producent_id else None
        combo = self.importer.producent
        indeks = combo.findData(pid)
        if indeks < 0:
            combo.addItem(stary.producent, pid)
            indeks = combo.count() - 1
        combo.setCurrentIndex(indeks)
        combo.setEnabled(False)

    def _plan(self) -> None:
        self.zapisz.setEnabled(bool(self.importer.oceny))
        if self.importer.oceny and not self.nazwa.text().strip():
            self.nazwa.setText(Path(self.importer.oceny[0].pozycja.zrodlo).stem)

    def zapisz_cennik(self) -> None:
        args = self.nazwa.text(), self.rok.value(), self.wydanie.text(), self.importer.oceny
        poprzedni = self._aktualizowany

        def gotowe(w: object) -> None:
            self._wybor_po_zapisie = cast(UUID, w)
            self._aktualizowany = None
            self.importer.producent.setEnabled(True)
            self.importer.wyczysc_import()
            self.nazwa.clear()
            self.rok.setValue(0)
            self.wydanie.clear()
            self.wroc()

        self._zadanie(lambda: self.serwis.zapisz(*args, poprzedni=poprzedni), gotowe)

    def bezposredni(self) -> None:
        self._aktualizowany = None
        self.importer.producent.setEnabled(True)
        self._pusty_podglad("Import")
        self.metadane.hide()
        self.zapisz.hide()
        self.importer.tryb_biblioteki(False)
        self.importer.tabs.setCurrentIndex(0)
        self.stos.setCurrentWidget(self.kreator)
        self.info.setText(
            "Import bezpośredni: zapis dodaje produkty do katalogu bez zapisywania cennika."
        )

    def korekty(self) -> None:
        self.bezposredni()
        self.importer.tabs.setCurrentIndex(1)
        self.importer.odswiez()

    def otworz(self) -> None:
        if self._budowanie_listy or self._trwa:
            return
        wybrane = self._wybrane()
        if len(wybrane) != 1:
            self._pusty_podglad(
                "Wybierz jeden cennik" if not wybrane else f"Zaznaczono cenniki: {len(wybrane)}"
            )
            return
        self.cennik = wybrane[0]
        self._odczytaj_pozycje()

    def _odczytaj_pozycje(self) -> None:
        self.indeks = None
        self._wybrane_pozycje.clear()
        self._strona = 0
        self._zlec_strone()
        self.naglowek.setText("Ładowanie pozycji…")

    def _indeksy_wyboru(self) -> frozenset[int]:
        if not self._przywracanie and not self._budowanie_pozycji:
            self._wybrane_pozycje.difference_update(p.indeks for p in self.pozycje)
            for i in self.wiersze.selectionModel().selectedRows():
                item = self.wiersze.item(i.row(), 0)
                if item is not None:
                    self._wybrane_pozycje.add(int(item.data(Qt.ItemDataRole.UserRole)))
        return frozenset(self._wybrane_pozycje)

    def _odznacz(self) -> None:
        self._wybrane_pozycje.clear()
        self.wiersze.selectionModel().clearSelection()
        self._stan_akcji()

    def _zaznacz_wszystkie(self) -> None:
        if self.indeks is None or self._podglad_trwa or self._budowanie_pozycji:
            return
        self._wybrane_pozycje = {
            p.indeks for p in self.indeks.pasujace(self.filtr.text(), self._stan_filtra())
        }
        self._przywroc_wybor()
        self._stan_akcji()

    def _przywroc_wybor(self) -> None:
        self._przywracanie = True
        try:
            wybor = QItemSelection()
            model = self.wiersze.model()
            for row, p in enumerate(self.pozycje):
                if p.indeks in self._wybrane_pozycje:
                    wybor.select(model.index(row, 0), model.index(row, model.columnCount() - 1))
            self.wiersze.selectionModel().select(
                wybor,
                QItemSelectionModel.SelectionFlag.ClearAndSelect
                | QItemSelectionModel.SelectionFlag.Rows,
            )
        finally:
            self._przywracanie = False

    def _stan_filtra(self) -> str:
        return self.status_pozycji.currentText() if self.status_pozycji.currentIndex() else ""

    def _zmien_strone(self, numer: int) -> None:
        self._indeksy_wyboru()
        self._strona = max(0, numer)
        self._zlec_strone()

    def _zmien_rozmiar(self, rozmiar: int) -> None:
        self._rozmiar = rozmiar
        self._zmien_strone(0)

    def _wiersze(self) -> None:
        self._wybrane_pozycje.clear()
        self._strona = 0
        self._zlec_strone()

    def _zlec_strone(self) -> None:
        self._numer_podgladu += 1
        self._generacja += 1
        self._budowanie_pozycji = True
        self.wiersze.setEnabled(False)
        self.wiersze.setRowCount(0)
        self.pasek_stron.setEnabled(False)
        self._czytaj_ostatni()

    def _czytaj_ostatni(self) -> None:
        c = self.cennik
        if self._podglad_trwa or c is None or self._trwa:
            self._stan_akcji()
            return
        numer = self._numer_podgladu
        indeks = self.indeks
        fraza, stan = self.filtr.text(), self._stan_filtra()
        strona, rozmiar = self._strona, self._rozmiar
        self._podglad_trwa = True
        self._stan_akcji()

        def odczytaj() -> tuple[IndeksCennika, StronaCennika]:
            gotowy = indeks or self.przeglad.przygotuj(c)
            return gotowy, self.przeglad.strona(c, gotowy, fraza, stan, strona, rozmiar)

        def gotowe(w: object) -> None:
            self._podglad_trwa = False
            nowy_indeks, dane = cast(tuple[IndeksCennika, StronaCennika], w)
            if self.cennik is not None and (self.cennik.id, self.cennik.wersja) == (c.id, c.wersja):
                self.indeks = nowy_indeks
            if numer != self._numer_podgladu:
                self._czytaj_ostatni()
                return
            self.pozycje = dane.pozycje
            self._strona = dane.numer
            cast(QTableWidgetItem, self.wiersze.horizontalHeaderItem(4)).setText("Bazowa")
            self.naglowek.setText(f"{c.nazwa} • {c.rok} • {c.status}")
            self.metryka.setText(
                f"{c.producent or 'Bez producenta'} • {c.wydanie or 'Bez oznaczenia wydania'}\n"
                f"{c.liczba} pozycji • {c.zrodlo} • wczytano {c.wczytano_utc[:16]} UTC"
                + ("\nPorównanie z poprzednim wydaniem." if c.poprzedni_id else "")
            )
            self.pasek_stron.ustaw_zakres(dane.numer, dane.rozmiar, dane.liczba, len(dane.pozycje))
            self._renderuj(dane)

        def blad(k: str, tekst: str) -> None:
            self._podglad_trwa = False
            if numer == self._numer_podgladu:
                self._budowanie_pozycji = False
                self._pusty_podglad(tekst)
            else:
                self._czytaj_ostatni()

        self.uruchom(odczytaj, gotowe, blad)

    def _renderuj(self, dane: StronaCennika) -> None:
        self.wiersze.setColumnHidden(7, not dane.ma_ean)
        if dane.ma_ean and self.podzial.orientation() == Qt.Orientation.Horizontal:
            for i, width in enumerate((55, 120, 100, 110, 110, 160, 95, 130)):
                self.wiersze.setColumnWidth(i, width)
        self._generacja += 1
        generacja = self._generacja
        rows = self.pozycje
        self.wiersze.setEnabled(False)
        self.wiersze.setRowCount(len(rows))

        def part(start: int) -> None:
            if not isValid(self) or generacja != self._generacja:
                return
            for i in range(start, min(start + 100, len(rows))):
                p = rows[i]
                cena = p.pozycja.cena
                wartosci = (
                    str(p.pozycja.wiersz),
                    p.pozycja.dane.nazwa,
                    p.pozycja.dane.sku,
                    f"{cena.tekst.replace('.', ',')} {cena.waluta}\n{cena.rodzaj}"
                    if cena and cena.tekst
                    else "—",
                    p.cena_bazowa.etykieta.rsplit(" ", 1)[0] + "\n" + p.cena_bazowa.rodzaj
                    if p.cena_bazowa
                    else "—",
                    p.roznica.replace(" (", "\n("),
                    p.stan,
                    p.pozycja.dane.ean or "—",
                )
                for j, value in enumerate(wartosci):
                    item = QTableWidgetItem(value)
                    item.setData(Qt.ItemDataRole.UserRole, p.indeks)
                    item.setToolTip(
                        "\n".join(
                            filter(
                                None, (p.cena_bazowa.zrodlo if p.cena_bazowa else "", p.porownanie)
                            )
                        )
                        if j in (4, 5)
                        else p.pozycja.dane.ean or "Brak EAN"
                        if j == 7
                        else p.problem or p.stan
                    )
                    if j == 6:
                        self._kolor(item, p.stan)
                    self.wiersze.setItem(i, j, item)
            if start + 100 < len(rows):
                QTimer.singleShot(0, lambda: part(start + 100))
            else:
                self._przywroc_wybor()
                self._budowanie_pozycji = False
                self.wiersze.setEnabled(True)
                self._stan_akcji()
                self.info.setText(
                    f"Pozycje: {dane.liczba}. Zaznacz wybrane i kliknij prawym "
                    f"przyciskiem → Dodaj do katalogu."
                )

        part(0)

    @staticmethod
    def _wybor_ppm(t: QTableWidget, punkt: QPoint) -> None:
        if punkt.x() < 0:
            return
        indeks = t.indexAt(punkt)
        if indeks.isValid() and not t.selectionModel().isRowSelected(indeks.row(), indeks.parent()):
            t.clearSelection()
            t.selectRow(indeks.row())
        elif not indeks.isValid():
            t.clearSelection()

    def _menu_cennikow(self, punkt: QPoint) -> None:
        self._wybor_ppm(self.tabela, punkt)
        menu = QMenu(self)
        self._stan_akcji()
        menu.addAction(self.aktualizuj_akcja)
        menu.addAction(self.aktualny_akcja)
        menu.addAction(self.archiwalny_akcja)
        menu.addSeparator()
        menu.addAction("Usuń zaznaczone…", self.usun).setEnabled(bool(self._wybrane()))
        menu.aboutToHide.connect(menu.deleteLater)
        menu.popup(
            self.tabela.viewport().mapToGlobal(
                punkt if punkt.x() >= 0 else self.tabela.viewport().rect().center()
            )
        )

    def pokaz_problem(self, row: int, col: int) -> None:
        if col != 6:
            return
        item = self.wiersze.item(row, col)
        if item is None:
            return
        indeks = item.data(Qt.ItemDataRole.UserRole)
        p = next((p for p in self.pozycje if p.indeks == indeks), None)
        if p is None or not p.problem:
            return
        if self.problem_dialog is not None:
            self.problem_dialog.close()
        dialog = QMessageBox(self)
        self.problem_dialog = dialog
        dialog.setWindowTitle("Co trzeba poprawić")
        dialog.setTextFormat(Qt.TextFormat.PlainText)
        tekst = f"SKU: {p.pozycja.dane.sku or 'Brak'}\nWiersz: {p.pozycja.wiersz}\n\n{p.problem}"
        duplikaty = [
            str(x.wiersz)
            for x in (self.indeks.pozycje if self.indeks else ())
            if x.sku.strip().casefold() == p.pozycja.dane.sku.strip().casefold()
        ]
        if p.pozycja.dane.sku.strip() and len(duplikaty) > 1:
            tekst += "\n\nTen SKU występuje w wierszach: " + ", ".join(duplikaty)
            tekst += ". Do dodania pojedynczego produktu możesz wybrać jeden z tych wierszy."
        dialog.setText(tekst)
        dialog.setStandardButtons(QMessageBox.StandardButton.Ok)
        dialog.button(QMessageBox.StandardButton.Ok).setText("Zamknij")
        dialog.setModal(True)

        def zamknieto() -> None:
            if self.problem_dialog is dialog:
                self.problem_dialog = None
            dialog.deleteLater()

        dialog.finished.connect(zamknieto)
        dialog.open()

    def _menu_pozycji(self, punkt: QPoint) -> None:
        indeks = self.wiersze.indexAt(punkt)
        if punkt.x() >= 0 and (
            not indeks.isValid()
            or not self.wiersze.selectionModel().isRowSelected(
                indeks.row(), self.wiersze.rootIndex()
            )
        ):
            self._odznacz()
        self._wybor_ppm(self.wiersze, punkt)
        menu = QMenu(self)
        menu.addAction("Dodaj do katalogu", self.dodaj).setEnabled(
            bool(self._indeksy_wyboru()) and not self._podglad_trwa and self.cennik is not None
        )
        menu.addSeparator()
        menu.addAction("Zaznacz wszystkie", self.wiersze.selectAll)
        menu.aboutToHide.connect(menu.deleteLater)
        menu.popup(
            self.wiersze.viewport().mapToGlobal(
                punkt if punkt.x() >= 0 else self.wiersze.viewport().rect().center()
            )
        )

    def dodaj(self) -> None:
        c = self.cennik
        if c is None or not self.wiersze.isEnabled() or self._podglad_trwa or self._trwa:
            return
        indeksy = self._indeksy_wyboru()
        if not indeksy:
            self.info.setText("Zaznacz pozycje do dodania.")
            return
        odpowiedz = QMessageBox.question(
            self,
            "Dodaj do katalogu",
            f"Sprawdzić i dodać {len(indeksy)} pozycji?\nZnane SKU zostaną "
            f"pominięte, błędne pozycje trafią do Do poprawy.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if odpowiedz != QMessageBox.StandardButton.Yes:
            return

        def gotowe(w: object) -> None:
            wynik = cast(WynikCennika, w)
            self.zmieniono.emit()
            self._odczytaj_pozycje()
            self.raport.setText(
                f"Dodano: {wynik.dodane}, do poprawy: {wynik.odlozone}, "
                f"pominięto: {wynik.pominiete}. Kopia: {wynik.kopia or 'bez zmian'}"
            )

        self._zadanie(lambda: self.serwis.dodaj(c, indeksy), gotowe)

    def ceny(self) -> None:
        c = self.cennik
        if c is not None:
            self._zadanie(
                lambda: self.serwis.importer.zaplanuj_uzupelnienie_cen(
                    self.serwis.importer.ocen(self.serwis.magazyn.pozycje(c.id, c.wersja))
                ),
                self.importer._dialog_cen,
            )

    def oznacz(self, aktualny: bool) -> None:
        wybor = self._wybrane()
        if len(wybor) != 1 or self._trwa:
            return
        c = wybor[0]
        if c.producent_id is None:
            self.info.setText("Cennik bez producenta nie może być oznaczony jako aktualny.")
            return
        snapshot = self.cenniki
        tekst = (
            f"Ustawić „{c.nazwa}” jako bazowy cennik producenta {c.producent}?\n"
            "Jego ceny będą podstawą porównań. Poprzedni bazowy cennik będzie archiwalny."
            if aktualny
            else f"Oznaczyć „{c.nazwa}” jako archiwalny?\n"
            "Żaden inny cennik nie zostanie wybrany automatycznie."
        )
        if (
            QMessageBox.question(
                self,
                "Status cennika",
                tekst + "\nCeny zapisane w katalogu pozostaną. Przed zmianą powstanie kopia bazy.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return

        def gotowe(w: object) -> None:
            self.raport.setText(f"Zmieniono status cennika. Kopia: {w}")
            self.odswiez()

        self._zadanie(lambda: self.serwis.oznacz(c, aktualny, snapshot), gotowe)

    def usun(self) -> None:
        wybrane = self._wybrane()
        if not wybrane:
            self.info.setText("Zaznacz cenniki do usunięcia.")
            return
        if (
            QMessageBox.question(
                self,
                "Usuń cenniki",
                f"Usunąć {len(wybrane)} zaznaczonych cenników?\nProdukty w "
                "katalogu i pliki źródłowe pozostaną. Przed usunięciem powstanie kopia bazy.\n"
                "Jeśli usuniesz poprzednie wydanie, jego porównanie historyczne "
                "nie będzie dostępne.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return

        def gotowe(w: object) -> None:
            self.raport.setText(f"Usunięto cenniki: {len(wybrane)}. Kopia: {w}")
            self.odswiez()

        self._zadanie(lambda: self.serwis.usun(wybrane), gotowe)
