"""Dekodowanie pojedynczej pozycji zachowanego cennika."""

from typing import Any
from uuid import UUID

from vexlab.przypadki_uzycia.importowanie import CenaImportu, PozycjaImportu
from vexlab.przypadki_uzycia.katalog import DaneDopasowania, DaneProduktu


def _tekst(d: dict[str, Any], klucz: str) -> str:
    value = d[klucz]
    if not isinstance(value, str):
        raise ValueError(klucz)
    return value


def _pozycja(d: Any) -> PozycjaImportu:
    if not isinstance(d, dict) or not isinstance(d.get("dane"), dict):
        raise ValueError("Pozycja")
    dane = d["dane"]
    ds = dane.get("dopasowania")
    if ds is not None and (not isinstance(ds, list) or len(ds) > 1000):
        raise ValueError("Dopasowania")
    dopasowania = tuple(
        DaneDopasowania(*(_tekst(x, k) for k in ("marka", "model", "rok_od", "rok_do", "wariant")))
        for x in ds or ()
    )
    ean = dane.get("ean")
    if ean is not None and not isinstance(ean, str):
        raise ValueError("EAN")
    cena = d.get("cena")
    if cena is not None and not isinstance(cena, dict):
        raise ValueError("Cena")
    if type(d.get("wiersz")) is not int or type(d.get("wersja")) is not int:
        raise ValueError("Numer wiersza")
    return PozycjaImportu(
        UUID(_tekst(d, "id")),
        UUID(_tekst(d, "paczka")),
        _tekst(d, "zrodlo"),
        _tekst(d, "arkusz"),
        d["wiersz"],
        DaneProduktu(
            _tekst(dane, "nazwa"),
            _tekst(dane, "sku"),
            _tekst(dane, "opis"),
            UUID(dane["producent_id"]) if dane.get("producent_id") else None,
            dopasowania if ds is not None else None,
            ean,
        ),
        _tekst(d, "powod"),
        d["wersja"],
        CenaImportu(*(_tekst(cena, k) for k in ("tekst", "waluta", "rodzaj"))) if cena else None,
    )
