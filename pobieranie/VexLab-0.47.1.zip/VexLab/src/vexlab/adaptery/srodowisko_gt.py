"""Wyłącznie odczyt metadanych Windows; bez COM, SQL, sieci i poświadczeń."""

import platform
import struct
import sys
from typing import Protocol

from vexlab.przypadki_uzycia.srodowisko_gt import InstalacjaGT, SrodowiskoGT, SterownikSQL

ODINSTALOWANIE = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
STEROWNIKI = r"SOFTWARE\ODBC\ODBCINST.INI\ODBC Drivers"


class CzytnikRejestru(Protocol):
    def podklucze(self, galaz: str, sciezka: str, widok: int) -> tuple[str, ...]: ...
    def wartosc(self, galaz: str, sciezka: str, nazwa: str, widok: int) -> str: ...
    def wartosci(self, galaz: str, sciezka: str, widok: int) -> dict[str, str]: ...


class RejestrWindows:
    @staticmethod
    def _dostep(galaz: str, widok: int) -> tuple[int, int]:
        if sys.platform == "win32":
            import winreg

            root = winreg.HKEY_LOCAL_MACHINE if galaz == "HKLM" else winreg.HKEY_CURRENT_USER
            return root, winreg.KEY_READ | (
                winreg.KEY_WOW64_32KEY if widok == 32 else winreg.KEY_WOW64_64KEY
            )

        raise OSError("Rejestr jest dostępny wyłącznie na Windows.")

    def podklucze(self, galaz: str, sciezka: str, widok: int) -> tuple[str, ...]:
        if sys.platform == "win32":
            import winreg

            root, dostep = self._dostep(galaz, widok)
            try:
                with winreg.OpenKey(root, sciezka, 0, dostep) as key:
                    return tuple(winreg.EnumKey(key, i) for i in range(winreg.QueryInfoKey(key)[0]))
            except FileNotFoundError:
                return ()

        raise OSError("Rejestr jest dostępny wyłącznie na Windows.")

    def wartosc(self, galaz: str, sciezka: str, nazwa: str, widok: int) -> str:
        if sys.platform == "win32":
            import winreg

            root, dostep = self._dostep(galaz, widok)
            try:
                with winreg.OpenKey(root, sciezka, 0, dostep) as key:
                    value, _ = winreg.QueryValueEx(key, nazwa)
                    return value if isinstance(value, str) else ""
            except FileNotFoundError:
                return ""

        raise OSError("Rejestr jest dostępny wyłącznie na Windows.")

    def wartosci(self, galaz: str, sciezka: str, widok: int) -> dict[str, str]:
        if sys.platform == "win32":
            import winreg

            root, dostep = self._dostep(galaz, widok)
            try:
                with winreg.OpenKey(root, sciezka, 0, dostep) as key:
                    values = [winreg.EnumValue(key, i) for i in range(winreg.QueryInfoKey(key)[1])]
                    return {n: v for n, v, _ in values if isinstance(v, str)}
            except FileNotFoundError:
                return {}
        raise OSError("Rejestr jest dostępny wyłącznie na Windows.")


def _tekst(tekst: str) -> str:
    return " ".join("".join(c if c.isprintable() else " " for c in tekst).split())[:160]


class SrodowiskoGTWindows:
    def __init__(self, rejestr: CzytnikRejestru | None = None) -> None:
        self._rejestr = rejestr or RejestrWindows()

    def odczytaj(self) -> SrodowiskoGT:
        system = platform.system()
        bity = struct.calcsize("P") * 8
        if system != "Windows":
            return SrodowiskoGT(system, platform.python_version(), bity, obslugiwany=False)
        instalacje: set[InstalacjaGT] = set()
        sterowniki: set[SterownikSQL] = set()
        uwagi: list[str] = []
        widoki = (32, 64) if bity == 64 or "64" in platform.machine() else (32,)
        for widok in widoki:
            for galaz in ("HKLM", "HKCU"):
                try:
                    keys = self._rejestr.podklucze(galaz, ODINSTALOWANIE, widok)
                except OSError:
                    uwagi.append(f"Nie można odczytać wpisów instalacji {galaz} / {widok}-bit.")
                    continue
                for key in keys:
                    path = ODINSTALOWANIE + "\\" + key
                    try:
                        nazwa = _tekst(self._rejestr.wartosc(galaz, path, "DisplayName", widok))
                        nazwa_klucz = "".join(nazwa.casefold().split())
                        if "insertgt" not in nazwa_klucz and "subiektgt" not in nazwa_klucz:
                            continue
                        wersja = _tekst(self._rejestr.wartosc(galaz, path, "DisplayVersion", widok))
                        instalacje.add(InstalacjaGT(nazwa, wersja, widok))
                    except OSError:
                        uwagi.append(
                            f"Nie można odczytać części wpisów instalacji {galaz} / {widok}-bit."
                        )
            try:
                values = self._rejestr.wartosci("HKLM", STEROWNIKI, widok)
                for name, value in values.items():
                    if "sql server" in name.casefold() and value.casefold() == "installed":
                        sterowniki.add(SterownikSQL(_tekst(name), widok))
            except OSError:
                uwagi.append(f"Nie można odczytać listy sterowników SQL / {widok}-bit.")
        return SrodowiskoGT(
            f"Windows {platform.release()}",
            platform.python_version(),
            bity,
            tuple(
                sorted(instalacje, key=lambda p: (p.nazwa.casefold(), p.wersja, p.widok_rejestru))
            ),
            tuple(sorted(sterowniki, key=lambda p: (p.nazwa.casefold(), p.widok_rejestru))),
            tuple(dict.fromkeys(uwagi)),
        )
