"""Jedna kopia na serię; osobna atomowa transakcja dla każdego produktu."""

from pathlib import Path

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import ProduktDTO
from vexlab.przypadki_uzycia.media import ZdjecieDane


class SesjaZdjecSQLite:
    def __init__(self, repo: KatalogSQLite) -> None:
        self.repo = repo
        self.kopia: Path | None = None

    def zapisz(self, produkt: ProduktDTO, zdjecie: ZdjecieDane) -> bool:
        with self.repo._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT wersja FROM produkty WHERE id=?", (str(produkt.id),)
            ).fetchone()
            if row is None or row[0] != produkt.wersja:
                raise BladScenariuszaKatalogu(
                    "MEDIA_KONFLIKT", "Produkt zmienił się. Odśwież katalog."
                )
            if conn.execute(
                "SELECT 1 FROM zdjecia WHERE produkt_id=?", (str(produkt.id),)
            ).fetchone():
                return False
            if self.kopia is None:
                self.kopia = self.repo._kopia_spojna("kopie_zdjec_seryjnych")
            self.repo._zdjecia(conn, produkt.id, (zdjecie,))
            conn.execute("UPDATE produkty SET wersja=wersja+1 WHERE id=?", (str(produkt.id),))
            return True


class MagazynZdjecSeryjnychSQLite:
    def __init__(self, plik: Path) -> None:
        self.repo = KatalogSQLite(plik)

    def nowa_sesja(self) -> SesjaZdjecSQLite:
        return SesjaZdjecSQLite(self.repo)
