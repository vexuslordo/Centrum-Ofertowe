"""Ograniczony odczyt ZIP bez rozpakowywania oraz pliki profili użytkownika."""

import json
import stat
from dataclasses import asdict, fields
from pathlib import Path, PurePosixPath
from zipfile import BadZipFile, LargeZipFile, ZipFile
from zlib import error as BladKompresji

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.paczki_ofert import (
    PaczkaOfert,
    PlikPaczki,
    ProfilPaczki,
    ProfilWPaczce,
    ZbiorPaczki,
    blad,
)

MAX_PLIK = 32 * 1024 * 1024
MAX_SUMA = 128 * 1024 * 1024
MAX_REKORDY = 20000


def obiekt(pary: list[tuple[str, object]]) -> dict[str, object]:
    wynik = {}
    for klucz, wartosc in pary:
        if klucz in wynik:
            raise ValueError("Powtórzony klucz JSON")
        wynik[klucz] = wartosc
    return wynik


def stala(tekst: str) -> None:
    raise ValueError("Niefinitywna liczba JSON")


class CzytnikZIP:
    def odczytaj(self, plik: Path) -> PaczkaOfert:
        try:
            if plik.stat().st_size > MAX_PLIK:
                raise blad("ZIP przekracza limit 32 MiB. Podziel paczkę.")
            with ZipFile(plik) as z:
                infos = z.infolist()
                if len(infos) > 2000 or sum(i.file_size for i in infos) > MAX_SUMA:
                    raise blad("Paczka przekracza limit 2000 wpisów lub 128 MiB po rozpakowaniu.")
                nazwy = set()
                for i in infos:
                    p = PurePosixPath(i.filename.replace("\\", "/"))
                    klucz = str(p).casefold()
                    if (
                        p.is_absolute()
                        or any(c in ("..", "") or ":" in c for c in p.parts)
                        or not p.parts
                        or klucz in nazwy
                        or stat.S_ISLNK(i.external_attr >> 16)
                    ):
                        raise blad("Archiwum zawiera niebezpieczne lub powtórzone ścieżki.")
                    nazwy.add(klucz)
                    if i.flag_bits & 1:
                        raise blad("Zaszyfrowane paczki nie są obsługiwane.")
                    if i.file_size > MAX_PLIK or i.file_size > max(1, i.compress_size) * 200:
                        raise blad("Plik w ZIP przekracza limit 32 MiB lub kompresji 200:1.")
                pliki = []
                zbiory = []
                profile = []
                bledy_profili = []
                for i in infos:
                    if i.is_dir():
                        continue
                    uwaga = "Plik pomocniczy — bez wykonywania i pobierania zasobów"
                    # Czytanie ograniczone przed parsowaniem; CRC obejmuje każdy wpis.
                    with z.open(i) as wejscie:
                        dane = wejscie.read(MAX_PLIK + 1)
                    if len(dane) > MAX_PLIK:
                        raise blad("Plik w ZIP przekracza limit odczytu.")
                    if PurePosixPath(i.filename).suffix.casefold() == ".json":
                        try:
                            wartosc = json.loads(
                                dane.decode("utf-8-sig"),
                                object_pairs_hook=obiekt,
                                parse_constant=stala,
                            )
                            if (
                                isinstance(wartosc, dict)
                                and "wersja" in wartosc
                                and "ustawienia" in wartosc
                            ):
                                try:
                                    if len(dane) > 65536:
                                        raise ValueError("Profil przekracza 64 KiB")
                                    profil = ProfileJSON.z_obiektu(wartosc)
                                    profile.append(ProfilWPaczce(i.filename, profil))
                                    uwaga = "Profil odczytu paczki: " + profil.nazwa
                                except (ValueError, TypeError, BladScenariuszaKatalogu) as exc:
                                    uwaga = "Nieprawidłowy profil odczytu paczki"
                                    bledy_profili.append(i.filename + ": " + str(exc))
                                pliki.append(PlikPaczki(i.filename, i.file_size, uwaga))
                                continue
                            if not isinstance(wartosc, list) or not all(
                                isinstance(r, dict) for r in wartosc
                            ):
                                raise ValueError("Oczekiwano listy obiektów")
                            if len(wartosc) > MAX_REKORDY:
                                raise blad("Plik danych przekracza limit 20000 rekordów.")
                            klucze = tuple(sorted({k for r in wartosc for k in r}))
                            if len(klucze) > 200:
                                raise blad(
                                    "Plik zawiera więcej niż 200 pól — wybierz prostszy eksport."
                                )
                            zbiory.append(ZbiorPaczki(i.filename, klucze, tuple(wartosc)))
                            uwaga = f"JSON: {len(wartosc)} rekordów"
                        except (ValueError, UnicodeError, RecursionError):
                            uwaga = (
                                "JSON nieobsługiwany lub nieprawidłowy — wybierz inny plik danych"
                            )
                    pliki.append(PlikPaczki(i.filename, i.file_size, uwaga))
                return PaczkaOfert(
                    plik.name, tuple(pliki), tuple(zbiory), tuple(profile), tuple(bledy_profili)
                )
        except (
            OSError,
            BadZipFile,
            LargeZipFile,
            RuntimeError,
            NotImplementedError,
            BladKompresji,
        ) as exc:
            # Błąd scenariusza też dziedziczy RuntimeError; zachowaj jego komunikat.

            if isinstance(exc, BladScenariuszaKatalogu):
                raise
            raise blad(
                "Nie można odczytać ZIP. Sprawdź plik, uprawnienia i integralność paczki."
            ) from exc


class ProfileJSON:
    def odczytaj(self, plik: Path) -> ProfilPaczki:
        try:
            with plik.open("rb") as wejscie:
                dane = wejscie.read(65537)
            if len(dane) > 65536:
                raise ValueError("Za duży profil")
            obj = json.loads(
                dane.decode("utf-8-sig"), object_pairs_hook=obiekt, parse_constant=stala
            )
            return self.z_obiektu(obj)
        except (OSError, ValueError, TypeError, RecursionError) as exc:
            raise blad("Nie można odczytać profilu JSON wersji 1. Sprawdź wybrany plik.") from exc

    @staticmethod
    def z_obiektu(obj: object) -> ProfilPaczki:
        if (
            not isinstance(obj, dict)
            or type(obj.get("wersja")) is not int
            or obj.get("wersja") != 1
        ):
            raise ValueError("Wersja profilu")
        pola = {f.name for f in fields(ProfilPaczki)}
        ustawienia = obj.get("ustawienia")
        if (
            not isinstance(ustawienia, dict)
            or not set(ustawienia) <= pola
            or not all(isinstance(v, str) for v in ustawienia.values())
        ):
            raise ValueError("Struktura profilu")
        profil = ProfilPaczki(**ustawienia)
        profil.sprawdz()
        return profil

    def zapisz(self, plik: Path, profil: ProfilPaczki) -> None:
        profil.sprawdz()
        dane = json.dumps({"wersja": 1, "ustawienia": asdict(profil)}, ensure_ascii=False, indent=2)
        utworzony = False
        try:
            with plik.open("x", encoding="utf-8") as wyjscie:
                utworzony = True
                wyjscie.write(dane)
        except OSError as exc:
            if utworzony:
                plik.unlink(missing_ok=True)
            raise blad(
                "Nie zapisano profilu. Wybierz nową nazwę i folder z prawem zapisu."
            ) from exc
