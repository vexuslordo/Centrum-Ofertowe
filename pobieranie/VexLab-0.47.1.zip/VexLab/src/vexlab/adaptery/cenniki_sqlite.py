"""Trwałe dokumenty cenników i atomowe dodawanie wybranych pozycji."""

import json
from collections.abc import Generator
from dataclasses import asdict, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

from vexlab.adaptery import cenniki_odczyt_sqlite as odczyt
from vexlab.adaptery.format_cennika import _pozycja
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.przypadki_uzycia.cenniki import CennikDTO, WynikCennika
from vexlab.przypadki_uzycia.importowanie import OcenaPozycji, PozycjaImportu, blad
from vexlab.rdzen.kontrakty import BladTechniczny


class CennikiSQLite(ImportSQLite):
    def symbole_cennika(self, id: UUID, wersja: int) -> tuple[str, ...]:
        with self._polaczenie() as conn:
            return odczyt.symbole(conn, id, wersja)

    def iteruj_pozycje(self, id: UUID, wersja: int) -> Generator[PozycjaImportu]:
        with self._polaczenie() as conn:
            yield from odczyt.iteruj(conn, id, wersja)

    def pozycje_wybrane(
        self, id: UUID, wersja: int, indeksy: frozenset[int]
    ) -> dict[int, PozycjaImportu]:
        with self._polaczenie() as conn:
            return odczyt.wybrane(conn, id, wersja, indeksy)

    def zapisz_cennik(
        self,
        nazwa: str,
        rok: int,
        wydanie: str,
        pozycje: tuple[PozycjaImportu, ...],
        *,
        poprzedni: CennikDTO | None = None,
    ) -> UUID:
        if not nazwa.strip() or not 1000 <= rok <= 9999 or not 0 < len(pozycje) <= 20_000:
            raise blad("Nieprawidłowe dane cennika.")
        if len({p.dane.producent_id for p in pozycje}) != 1:
            raise blad("Cennik może wskazywać jednego producenta.")
        dane = json.dumps([asdict(p) for p in pozycje], ensure_ascii=False, default=str)
        if len(dane.encode()) > 64 * 1024 * 1024:
            raise blad("Cennik przekracza limit 64 MiB danych.")
        id = uuid4()
        pid = pozycje[0].dane.producent_id
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            aktywny = False
            if poprzedni is not None:
                self._sprawdz_cennik(conn, poprzedni.id, poprzedni.wersja)
                zapisany = conn.execute(
                    "SELECT producent_id,aktualny FROM cenniki WHERE id=?",
                    (str(poprzedni.id),),
                ).fetchone()
                aktywny = bool(zapisany[1])
                if (str(pid) if pid else None) != zapisany[0]:
                    raise blad("Wybierz tego samego producenta co w poprzednim wydaniu.")
            self._kopia_spojna("kopie_cennikow")
            if poprzedni is not None:
                conn.execute(
                    "UPDATE cenniki SET aktualny=0,archiwalny=1,wersja=wersja+1 WHERE id=?",
                    (str(poprzedni.id),),
                )
            conn.execute(
                "INSERT INTO cenniki (id,nazwa,rok,wydanie,producent_id,zrodlo,arkusz,liczba,"
                "wczytano_utc,dane_json,wersja,aktualny,poprzedni_id) VALUES "
                "(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    str(id),
                    nazwa.strip(),
                    rok,
                    wydanie.strip(),
                    str(pid) if pid else None,
                    pozycje[0].zrodlo,
                    pozycje[0].arkusz,
                    len(pozycje),
                    datetime.now(UTC).isoformat(),
                    dane,
                    1,
                    int(aktywny),
                    str(poprzedni.id) if poprzedni else None,
                ),
            )
        return id

    def lista(self) -> tuple[CennikDTO, ...]:
        with self._polaczenie() as conn:
            rows = conn.execute(
                "SELECT c.id,c.nazwa,c.rok,c.wydanie,coalesce(p.nazwa,''),c.zrodlo,c.arkusz,"
                "c.liczba,c.wczytano_utc,c.wersja,c.producent_id,c.aktualny,"
                "c.archiwalny,c.poprzedni_id "
                "FROM cenniki c "
                "LEFT JOIN producenci p "
                "ON p.id=c.producent_id ORDER BY c.wczytano_utc DESC,c.id"
            ).fetchall()
        return tuple(
            CennikDTO(
                UUID(r[0]),
                r[1],
                r[2],
                r[3],
                r[4],
                r[5],
                r[6],
                r[7],
                r[8],
                r[9],
                UUID(r[10]) if r[10] else None,
                bool(r[11]),
                bool(r[12]),
                UUID(r[13]) if r[13] else None,
            )
            for r in rows
        )

    @staticmethod
    def _sprawdz_cennik(conn: Any, id: UUID, wersja: int, *, z_danymi: bool = False) -> Any:
        if z_danymi:
            row = conn.execute(
                "SELECT dane_json,liczba,wersja FROM cenniki WHERE id=?", (str(id),)
            ).fetchone()
        else:
            row = conn.execute(
                "SELECT NULL,liczba,wersja FROM cenniki WHERE id=?", (str(id),)
            ).fetchone()
        if row is None or row[2] != wersja:
            raise blad("Cennik został usunięty lub zmieniony. Odśwież listę.")
        return row

    def pozycje(self, id: UUID, wersja: int) -> tuple[PozycjaImportu, ...]:
        with self._polaczenie() as conn:
            row = self._sprawdz_cennik(conn, id, wersja, z_danymi=True)
        try:
            if len(row[0]) > 64 * 1024 * 1024:
                raise ValueError("Rozmiar")
            dane = json.loads(row[0])
            if not isinstance(dane, list) or not 0 < len(dane) <= 20_000 or len(dane) != row[1]:
                raise ValueError("Liczba pozycji")
            return tuple(_pozycja(d) for d in dane)
        except (ValueError, KeyError, TypeError, AttributeError, RecursionError) as exc:
            raise BladTechniczny("Nie można odczytać cennika. Zachowaj kopię bazy.") from exc

    def dodaj_pozycje(
        self, cennik: CennikDTO, oceny: tuple[OcenaPozycji, ...], pominiete: int
    ) -> WynikCennika:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            self._sprawdz_cennik(conn, cennik.id, cennik.wersja)
            if not oceny:
                return WynikCennika(0, 0, pominiete, None)
            kopia = self._kopia_spojna("kopie_cennikow")
            pozycje = tuple(replace(o.pozycja, powod=o.problem or "") for o in oceny)
            wynik = self._zapisz_paczke(
                conn, pozycje, frozenset(o.pozycja.id for o in oceny if not o.problem)
            )
            return WynikCennika(wynik.dodane, wynik.odlozone, pominiete, kopia)

    def usun(self, cenniki: tuple[tuple[UUID, int], ...]) -> Path:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            for id, wersja in cenniki:
                self._sprawdz_cennik(conn, id, wersja)
            kopia = self._kopia_spojna("kopie_cennikow")
            conn.executemany("DELETE FROM cenniki WHERE id=?", [(str(id),) for id, _ in cenniki])
        return kopia

    def oznacz(
        self, cennik: CennikDTO, aktualny: bool, oczekiwane: tuple[tuple[UUID, int], ...]
    ) -> Path:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            self._sprawdz_cennik(conn, cennik.id, cennik.wersja)
            row = conn.execute(
                "SELECT producent_id FROM cenniki WHERE id=?", (str(cennik.id),)
            ).fetchone()
            if not row or not row[0] or row[0] != str(cennik.producent_id):
                raise blad("Cennik nie ma potwierdzonego producenta. Odśwież listę.")
            stan = conn.execute(
                "SELECT id,wersja FROM cenniki WHERE producent_id=?", (row[0],)
            ).fetchall()
            if {(r[0], r[1]) for r in stan} != {(str(id), w) for id, w in oczekiwane}:
                raise blad("Zmieniono cenniki producenta. Odśwież listę i ponów wybór.")
            kopia = self._kopia_spojna("kopie_cennikow")
            if aktualny:
                conn.execute(
                    "UPDATE cenniki SET aktualny=0,archiwalny=1,wersja=wersja+1 "
                    "WHERE producent_id=? AND aktualny=1 AND id<>?",
                    (row[0], str(cennik.id)),
                )
            conn.execute(
                "UPDATE cenniki SET aktualny=?,archiwalny=?,wersja=wersja+1 "
                "WHERE id=? AND (aktualny<>? OR archiwalny<>?)",
                (
                    int(aktualny),
                    int(not aktualny),
                    str(cennik.id),
                    int(aktualny),
                    int(not aktualny),
                ),
            )
        return kopia
