"""Modele odczytu z ograniczonym LIMIT, jedna migawka SQLite na stronę."""

import sqlite3
from uuid import UUID

from vexlab.przypadki_uzycia.katalog import (
    CenaSugerowanaDTO,
    DopasowanieDTO,
    ProduktDTO,
    StronaKatalogu,
    ZapytanieKatalogu,
)
from vexlab.przypadki_uzycia.producenci import ProducentDTO


def _dto(conn: sqlite3.Connection, row: sqlite3.Row) -> ProduktDTO:
    dopasowania = tuple(
        DopasowanieDTO(r["marka"], r["model"], r["rok_od"], r["rok_do"], r["wariant"])
        for r in conn.execute(
            "SELECT * FROM dopasowania WHERE produkt_id=? ORDER BY kolejnosc", (row["id"],)
        )
    )
    cena = (
        CenaSugerowanaDTO(row["kwota"], row["waluta"], row["rodzaj"], row["zrodlo"])
        if row["kwota"] is not None
        else None
    )
    return ProduktDTO(
        UUID(row["id"]),
        row["nazwa"],
        row["sku"],
        row["opis"],
        row["wersja"],
        UUID(row["producent_id"]) if row["producent_id"] else None,
        row["producent_nazwa"],
        cena,
        None,
        dopasowania,
        row["ean"],
        bool(row["ma_zdjecia"]),
    )


def odczytaj_strone(
    conn: sqlite3.Connection, q: ZapytanieKatalogu, wybrane: tuple[UUID, ...], wszystkie: bool
) -> StronaKatalogu:
    conn.create_function(
        "vex_fold", 1, lambda tekst: str(tekst or "").casefold(), deterministic=True
    )
    conn.execute("BEGIN")
    parametry: dict[str, str | int | None] = {
        "fraza": q.fraza.strip().casefold(),
        "producent": q.producent,
        "kolumna": q.kolumna,
        "malejaco": int(q.malejaco),
        "zdjecia": int(q.zdjecia) if q.zdjecia is not None else None,
        "cena": int(q.cena) if q.cena is not None else None,
        "ean": int(q.ean) if q.ean is not None else None,
        "opis": int(q.opis) if q.opis is not None else None,
    }
    liczba = conn.execute(
        "SELECT count(*) FROM produkty p WHERE "
        "(instr(vex_fold(p.nazwa),:fraza)>0 OR instr(vex_fold(p.sku),:fraza)>0 "
        "OR instr(vex_fold(p.ean),:fraza)>0) "
        "AND (:producent='wszyscy' OR (:producent='brak' AND p.producent_id IS NULL) "
        "OR p.producent_id=:producent) "
        "AND (:zdjecia IS NULL OR EXISTS(SELECT 1 FROM zdjecia z "
        "WHERE z.produkt_id=p.id AND z.kolejnosc=0)=:zdjecia) "
        "AND (:ean IS NULL OR (p.ean!='')=:ean) "
        "AND (:opis IS NULL OR (trim(p.opis)!='')=:opis) "
        "AND (:cena IS NULL OR EXISTS(SELECT 1 FROM ceny_sugerowane c "
        "WHERE c.produkt_id=p.id)=:cena)",
        parametry,
    ).fetchone()[0]
    wszystkich = conn.execute("SELECT count(*) FROM produkty").fetchone()[0]
    numer = min(q.numer, max(0, (liczba - 1) // q.rozmiar))
    parametry.update(
        limit=-1 if wszystkie else q.rozmiar, offset=0 if wszystkie else numer * q.rozmiar
    )
    rows = conn.execute(
        "WITH klucze AS (SELECT p.id, vex_fold(CASE :kolumna "
        "WHEN 0 THEN CASE WHEN EXISTS(SELECT 1 FROM zdjecia z "
        "WHERE z.produkt_id=p.id AND z.kolejnosc=0) THEN '' ELSE '◇' END "
        "WHEN 1 THEN p.nazwa WHEN 2 THEN p.sku WHEN 3 THEN coalesce(pr.nazwa,'—') "
        "WHEN 4 THEN coalesce(replace(c.kwota,'.',',') || ' ' || c.waluta || ' ' || c.rodzaj,'—') "
        "ELSE '—' END) AS porzadek FROM produkty p "
        "LEFT JOIN producenci pr ON pr.id=p.producent_id "
        "LEFT JOIN ceny_sugerowane c ON c.produkt_id=p.id "
        "WHERE (:fraza='' OR instr(vex_fold(p.nazwa),:fraza)>0 "
        "OR instr(vex_fold(p.sku),:fraza)>0 OR instr(vex_fold(p.ean),:fraza)>0) "
        "AND (:producent='wszyscy' OR (:producent='brak' AND p.producent_id IS NULL) "
        "OR p.producent_id=:producent) "
        "AND (:zdjecia IS NULL OR EXISTS(SELECT 1 FROM zdjecia z "
        "WHERE z.produkt_id=p.id AND z.kolejnosc=0)=:zdjecia) "
        "AND (:ean IS NULL OR (p.ean!='')=:ean) "
        "AND (:opis IS NULL OR (trim(p.opis)!='')=:opis) "
        "AND (:cena IS NULL OR EXISTS(SELECT 1 FROM ceny_sugerowane c "
        "WHERE c.produkt_id=p.id)=:cena)), "
        "strona AS MATERIALIZED (SELECT * FROM klucze ORDER BY "
        "CASE WHEN :malejaco=0 THEN porzadek END ASC, "
        "CASE WHEN :malejaco=1 THEN porzadek END DESC,id ASC LIMIT :limit OFFSET :offset) "
        "SELECT p.*,pr.nazwa AS producent_nazwa,c.kwota,c.waluta,c.rodzaj,c.zrodlo, "
        "EXISTS(SELECT 1 FROM zdjecia z WHERE z.produkt_id=p.id "
        "AND z.kolejnosc=0) AS ma_zdjecia FROM strona s JOIN produkty p ON p.id=s.id "
        "LEFT JOIN producenci pr ON pr.id=p.producent_id "
        "LEFT JOIN ceny_sugerowane c ON c.produkt_id=p.id "
        "ORDER BY CASE WHEN :malejaco=0 THEN s.porzadek END ASC, "
        "CASE WHEN :malejaco=1 THEN s.porzadek END DESC,p.id ASC",
        parametry,
    ).fetchall()
    produkty = tuple(_dto(conn, r) for r in rows)
    aktualne = {p.id: p for p in produkty}
    for pid in wybrane:
        if pid in aktualne:
            continue
        row = conn.execute(
            "SELECT p.*,pr.nazwa AS producent_nazwa,c.kwota,c.waluta,c.rodzaj,c.zrodlo, "
            "EXISTS(SELECT 1 FROM zdjecia z WHERE z.produkt_id=p.id "
            "AND z.kolejnosc=0) AS ma_zdjecia "
            "FROM produkty p LEFT JOIN producenci pr ON pr.id=p.producent_id "
            "LEFT JOIN ceny_sugerowane c ON c.produkt_id=p.id WHERE p.id=?",
            (str(pid),),
        ).fetchone()
        if row is not None:
            p = _dto(conn, row)
            fraza = q.fraza.strip().casefold()
            if (
                (
                    fraza in p.nazwa.casefold()
                    or fraza in p.sku.casefold()
                    or fraza in p.ean.casefold()
                )
                and (
                    q.producent == "wszyscy"
                    or (q.producent == "brak" and p.producent_id is None)
                    or str(p.producent_id) == q.producent
                )
                and (q.zdjecia is None or p.ma_zdjecia == q.zdjecia)
                and (q.cena is None or (p.cena_sugerowana is not None) == q.cena)
                and (q.ean is None or bool(p.ean) == q.ean)
                and (q.opis is None or bool(p.opis.strip()) == q.opis)
            ):
                aktualne[pid] = p
    producenci = tuple(
        ProducentDTO(UUID(r["id"]), r["nazwa"], bool(r["aktywny"]), r["wersja"], r["strona_www"])
        for r in conn.execute("SELECT * FROM producenci ORDER BY nazwa COLLATE NOCASE,id")
    )
    return StronaKatalogu(
        produkty,
        producenci,
        liczba,
        wszystkich,
        numer,
        q.rozmiar,
        tuple(aktualne[pid] for pid in wybrane if pid in aktualne),
    )
