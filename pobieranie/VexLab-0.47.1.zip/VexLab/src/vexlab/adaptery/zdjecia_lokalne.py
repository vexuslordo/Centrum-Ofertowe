"""Ograniczony odczyt lokalnych obrazów; ścieżka użytkownika nie trafia do bazy."""

from pathlib import Path

from vexlab.adaptery.obraz import obraz
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.media import ZdjecieDane


class LokalneZdjecia:
    def odczytaj(self, pliki: tuple[Path, ...]) -> tuple[ZdjecieDane, ...]:
        wynik = []
        for plik in pliki:
            try:
                with plik.open("rb") as wejscie:
                    dane = wejscie.read(8 * 1024 * 1024 + 1)
            except OSError as exc:
                raise BladScenariuszaKatalogu(
                    "MEDIA", "Nie można odczytać wybranego pliku."
                ) from exc
            wynik.append(obraz(dane, f"Plik lokalny: {plik.name}"))
        return tuple(wynik)
