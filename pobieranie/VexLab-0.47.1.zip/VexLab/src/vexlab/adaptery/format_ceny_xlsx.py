"""Zaokrąglenie zapisanej liczby do wspieranych formatów kwotowych Excela."""

import re
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

FORMATY_WBUDOWANE = {
    0: "General",
    1: "0",
    2: "0.00",
    3: "#,##0",
    4: "#,##0.00",
    5: "#,##0",
    6: "#,##0",
    7: "#,##0.00",
    8: "#,##0.00",
    37: "#,##0",
    38: "#,##0",
    39: "#,##0.00",
    40: "#,##0.00",
    41: "#,##0",
    42: "#,##0",
    43: "#,##0.00",
    44: "#,##0.00",
    49: "@",
}


def widoczna_cena(tekst: str, format: str) -> tuple[str | None, str]:
    if not tekst or format.lower() in ("general", "@", ""):
        return None, ""
    # Nie odgaduj skali procentów, dat, ułamków lub warunkowych sekcji.
    if re.search(r"\[[<>=]", format):
        return None, "Warunkowy format ceny wymaga zapisania widocznej kwoty jako tekst."
    czysty = re.sub(r'"[^"\n]*"', "", format.split(";")[0])
    czysty = re.sub(r"\[[^\]]*\]|\\.|_.|\*.", "", czysty).strip()
    if not re.fullmatch(r"[ #0,.]+", czysty) or czysty.endswith(","):
        return None, "Nieobsługiwany format ceny — zapisz widoczną kwotę jako tekst."
    wzor = re.fullmatch(r"[0#]+(?:,[0#]{3})*(?:\.([0#]{1,6}))?", czysty)
    if wzor is None:
        return None, "Nieobsługiwana precyzja ceny — zapisz widoczną kwotę jako tekst."
    miejsca = wzor.group(1) or ""
    try:
        liczba = Decimal(tekst)
        if not liczba.is_finite() or liczba.adjusted() > 11:
            raise InvalidOperation()
        wynik = format_kwoty(
            liczba.quantize(Decimal(1).scaleb(-len(miejsca)), rounding=ROUND_HALF_UP), miejsca
        )
        return wynik, ""
    except InvalidOperation:
        return None, "Nie można odczytać widocznej kwoty ceny."


def format_kwoty(liczba: Decimal, miejsca: str) -> str:
    tekst = format(liczba, "f")
    opcjonalne = len(miejsca) - len(miejsca.rstrip("#"))
    while opcjonalne and tekst.endswith("0"):
        tekst = tekst[:-1]
        opcjonalne -= 1
    return tekst.rstrip(".")
