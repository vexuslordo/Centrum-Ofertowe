"""Trwałe ustawienia rozpoznawania układów w katalogu danych użytkownika."""

import hashlib
import json
import os
from dataclasses import asdict
from pathlib import Path
from tempfile import NamedTemporaryFile

from vexlab.adaptery.paczki_zip import ProfileJSON, obiekt, stala
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.paczki_ofert import ZapamietanyProfil, blad


class PamiecProfiliJSON:
    def __init__(self, katalog: Path) -> None:
        self.katalog = katalog

    @staticmethod
    def klucz(profil: ZapamietanyProfil) -> str:
        dane = asdict(profil)
        dane["profil"].pop("nazwa")
        dane["profil"].pop("plik")
        return hashlib.sha256(
            json.dumps(dane, ensure_ascii=False, sort_keys=True).encode()
        ).hexdigest()

    def _odczytaj(self, plik: Path) -> ZapamietanyProfil:
        if plik.is_symlink():
            raise ValueError("Dowiązanie ustawień")
        with plik.open("rb") as wejscie:
            dane = wejscie.read(65537)
        if len(dane) > 65536:
            raise ValueError("Za duży profil")
        obj = json.loads(dane.decode("utf-8-sig"), object_pairs_hook=obiekt, parse_constant=stala)
        if not isinstance(obj, dict) or type(obj.get("wersja")) is not int or obj["wersja"] != 1:
            raise ValueError("Wersja ustawień")
        profil = ProfileJSON.z_obiektu({"wersja": 1, "ustawienia": obj.get("profil")})
        pola, ksztalt = obj.get("pola"), obj.get("ksztalt_sekcji")
        if (
            not isinstance(pola, list)
            or not all(isinstance(x, str) for x in pola)
            or len(pola) > 200
            or not isinstance(ksztalt, list)
            or not all(isinstance(x, list) and all(isinstance(k, str) for k in x) for x in ksztalt)
        ):
            raise ValueError("Struktura ustawień")
        wynik = ZapamietanyProfil(profil, tuple(pola), tuple(tuple(x) for x in ksztalt))
        if self.klucz(wynik) != plik.stem:
            raise ValueError("Niezgodny identyfikator ustawień")
        return wynik

    def lista(self) -> tuple[ZapamietanyProfil, ...]:
        try:
            if not self.katalog.exists():
                return ()
            if not self.katalog.is_dir():
                raise OSError("Folder ustawień nie jest katalogiem")
            pliki = sorted(self.katalog.glob("*.json"))
            if len(pliki) > 500:
                raise ValueError("Za dużo profili")
            return tuple(self._odczytaj(p) for p in pliki)
        except (OSError, ValueError, TypeError, RecursionError, BladScenariuszaKatalogu) as exc:
            raise blad(
                "Nie można odczytać zapamiętanych układów. "
                "Zachowaj pliki ustawień; nie zostały usunięte."
            ) from exc

    def zapisz(self, profil: ZapamietanyProfil) -> None:
        profil.profil.sprawdz()
        tmp: Path | None = None
        try:
            self.katalog.mkdir(parents=True, exist_ok=True)
            cel = self.katalog / (self.klucz(profil) + ".json")
            if cel.is_symlink():
                raise ValueError("Dowiązanie ustawień")
            if cel.exists():
                self._odczytaj(cel)  # Nie nadpisuj uszkodzonych ustawień ani nazwy znanego układu.
                return
            if len(list(self.katalog.glob("*.json"))) >= 500:
                raise ValueError("Limit profili")
            dane = json.dumps(
                {"wersja": 1, **asdict(profil)}, ensure_ascii=False, indent=2
            ).encode()
            if len(dane) > 65536:
                raise ValueError("Za duży profil")
            with NamedTemporaryFile(
                dir=self.katalog, prefix=".profil-", suffix=".tmp", delete=False
            ) as plik:
                tmp = Path(plik.name)
                plik.write(dane)
                plik.flush()
                os.fsync(plik.fileno())
            os.replace(tmp, cel)
            tmp = None
        except (OSError, ValueError, TypeError, BladScenariuszaKatalogu) as exc:
            raise blad(
                "Nie zapisano układu. Sprawdź dostęp do folderu ustawień użytkownika."
            ) from exc
        finally:
            if tmp is not None:
                tmp.unlink(missing_ok=True)

    def usun(self, profil: ZapamietanyProfil) -> None:
        try:
            plik = self.katalog / (self.klucz(profil) + ".json")
            if plik.is_symlink():
                raise ValueError("Dowiązanie ustawień")
            plik.unlink(missing_ok=True)
        except (OSError, ValueError) as exc:
            raise blad("Nie można usunąć zapamiętanego układu.") from exc
