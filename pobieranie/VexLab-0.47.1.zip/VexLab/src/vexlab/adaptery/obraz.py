"""Wspólne ograniczenia i normalizacja zdjęć lokalnych oraz sieciowych."""

from PySide6.QtCore import QBuffer, QByteArray, QIODevice, Qt
from PySide6.QtGui import QImageReader

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.media import ZdjecieDane


def blad(tekst: str) -> BladScenariuszaKatalogu:
    return BladScenariuszaKatalogu("MEDIA", tekst)


def obraz(dane: bytes, url: str) -> ZdjecieDane:
    if not dane or len(dane) > 8 * 1024 * 1024:
        raise blad("Nieprawidłowy rozmiar obrazu.")
    buf = QBuffer()
    buf.setData(QByteArray(dane))
    buf.open(QIODevice.OpenModeFlag.ReadOnly)
    reader = QImageReader(buf)
    if bytes(reader.format().data()).lower() not in (b"jpeg", b"jpg", b"png", b"webp"):
        raise blad("Obsługiwane zdjęcia: JPEG, PNG, WebP; nie HTML/SVG.")
    size = reader.size()
    if size.width() <= 0 or size.height() <= 0 or size.width() * size.height() > 16000000:
        raise blad("Obraz przekracza limit 16 milionów pikseli lub ma błędny rozmiar.")
    image = reader.read()
    if image.isNull():
        raise blad("Nie można odczytać obrazu ze źródła.")

    def zapisz(limit: int) -> bytes:
        scaled = (
            image
            if max(image.width(), image.height()) <= limit
            else image.scaled(
                limit,
                limit,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )

        out = QBuffer()
        out.open(QIODevice.OpenModeFlag.WriteOnly)
        # PySide6 6.12: runtime wymaga str, stub deklaruje bytes; test dekodowania sprawdza zapis.
        if not scaled.save(out, "JPEG", 85):  # type: ignore[call-overload]
            raise blad("Nie udało się przygotować zdjęcia do zapisu.")
        return bytes(out.data().data())

    return ZdjecieDane(url, zapisz(1600), zapisz(96))
