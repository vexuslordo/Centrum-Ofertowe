"""Trwałe rezerwacje tworzenia: wyłącznie skróty/ID, bez tokenów i treści ofert."""

import json
import os
import re
import tempfile
from dataclasses import asdict
from pathlib import Path

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import ProbaTworzenia


class RejestrTworzeniaJSON:
    def __init__(self, katalog: Path) -> None:
        self.katalog = katalog

    def _plik(self, klucz: str) -> Path:
        if not re.fullmatch(r"[0-9a-f]{64}", klucz):
            raise BladAllegro("REJESTR", "Niepoprawny klucz rejestru tworzenia.")
        return self.katalog / (klucz + ".json")

    def odczytaj(self, klucz: str) -> ProbaTworzenia | None:
        try:
            with self._plik(klucz).open("rb") as f:
                d = json.loads(f.read(4097))
            if (
                not isinstance(d, dict)
                or set(d) != {"zrodlo", "tresc", "status", "ident", "operacja"}
                or any(
                    not isinstance(d[k], str) or not re.fullmatch(r"[0-9a-f]{64}", d[k])
                    for k in ("zrodlo", "tresc")
                )
                or type(d["status"]) is not int
                or d["status"] not in {0, 201, 202}
                or not isinstance(d["ident"], str)
                or not re.fullmatch(r"[0-9]{0,100}", d["ident"])
                or not isinstance(d["operacja"], str)
                or not re.fullmatch(r"[A-Za-z0-9-]{0,100}", d["operacja"])
            ):
                raise ValueError("rejestr")
            return ProbaTworzenia(**d)
        except FileNotFoundError:
            return None
        except (OSError, ValueError, UnicodeError, TypeError):
            raise BladAllegro(
                "REJESTR",
                "Uszkodzony lub niedostępny rejestr tworzenia. Zachowaj pliki; "
                "wysyłka zablokowana.",
            ) from None

    def rozpocznij(self, klucz: str, proba: ProbaTworzenia) -> None:
        try:
            self.katalog.mkdir(parents=True, exist_ok=True)
            with self._plik(klucz).open("xb") as f:
                f.write(json.dumps(asdict(proba)).encode())
                f.flush()
                os.fsync(f.fileno())
        except OSError:
            raise BladAllegro(
                "REJESTR", "Nie można zarezerwować tworzenia. Sprawdź poprzednią próbę."
            ) from None

    def zapisz(self, klucz: str, proba: ProbaTworzenia) -> None:
        plik = self._plik(klucz)
        temp: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(dir=self.katalog, delete=False) as f:
                temp = Path(f.name)
                f.write(json.dumps(asdict(proba)).encode())
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp, plik)
        except OSError:
            raise BladAllegro(
                "REJESTR", "Nie zapisano metadanych tworzenia. Nie ponawiaj wysyłki; sprawdź wynik."
            ) from None
        finally:
            if temp is not None:
                temp.unlink(missing_ok=True)

    def usun(self, klucz: str) -> None:
        try:
            self._plik(klucz).unlink()
        except OSError:
            raise BladAllegro(
                "REJESTR", "Nie zwolniono rezerwacji po odrzuceniu; sprawdź rejestr."
            ) from None
