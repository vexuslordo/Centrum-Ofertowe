"""Ograniczony, bezpieczny odczyt tabel XLSX i CSV; bez wykonywania formuł."""

import csv
import posixpath
from pathlib import Path
from typing import cast

# Tylko typ i wyjątek; każdy odczyt XML wykonuje defusedxml z zakazem DTD/encji.
from xml.etree.ElementTree import Element, ParseError  # nosec B405
from zipfile import BadZipFile, ZipFile

from defusedxml import ElementTree as XML  # type: ignore[import-untyped]
from defusedxml.common import DefusedXmlException  # type: ignore[import-untyped]

from vexlab.adaptery.format_ceny_xlsx import FORMATY_WBUDOWANE, widoczna_cena
from vexlab.przypadki_uzycia.importowanie import Arkusz, Komorka, PlikImportu, blad

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
MAX_PLIK = 20 * 1024 * 1024
MAX_XML = 40 * 1024 * 1024
MAX_WIERSZE = 20000
MAX_KOLUMNY = 256


def kolumna(adres: str) -> int:
    litery = "".join(c for c in adres if c.isalpha())
    if not litery or not litery.isascii() or not litery.isupper():
        raise blad("Nieprawidłowy adres komórki XLSX.")
    indeks = 0
    for znak in litery:
        indeks = indeks * 26 + ord(znak) - ord("A") + 1
    if indeks > MAX_KOLUMNY:
        raise blad("Arkusz przekracza limit 256 kolumn.")
    return indeks - 1


class CzytnikTabel:
    def odczytaj(self, plik: Path) -> PlikImportu:
        try:
            if plik.stat().st_size > MAX_PLIK:
                raise blad("Plik przekracza limit 20 MB.")
            if plik.suffix.lower() == ".xlsx":
                return self._xlsx(plik)
            if plik.suffix.lower() == ".csv":
                return self._csv(plik)
            raise blad("Obsługiwane pliki: XLSX i CSV UTF-8. XLS i PDF nie są obsługiwane.")
        except (
            OSError,
            BadZipFile,
            ParseError,
            DefusedXmlException,
            KeyError,
            ValueError,
            IndexError,
            csv.Error,
            UnicodeError,
        ) as exc:
            raise blad(
                "Nie można odczytać tabeli. Sprawdź format, kodowanie i poprawność pliku."
            ) from exc

    def _csv(self, plik: Path) -> PlikImportu:
        with plik.open(encoding="utf-8-sig", newline="") as f:
            probka = f.read(8192)
            f.seek(0)
            try:
                dialekt = csv.Sniffer().sniff(probka, delimiters=";,\t")
            except csv.Error:
                dialekt = csv.excel
            rows = []
            for i, row in enumerate(csv.reader(f, dialekt), 1):
                if i > MAX_WIERSZE or len(row) > MAX_KOLUMNY:
                    raise blad("Tabela przekracza limit 20000 wierszy lub 256 kolumn.")
                rows.append((i, tuple(Komorka(s) for s in row)))
        return PlikImportu(plik.name, (Arkusz("CSV", tuple(rows)),))

    def _xml(self, z: ZipFile, nazwa: str) -> Element:
        info = z.getinfo(nazwa)
        if info.file_size > MAX_XML:
            raise blad("Element XLSX przekracza limit odczytu.")
        return cast(
            Element,
            XML.fromstring(
                z.read(info), forbid_dtd=True, forbid_entities=True, forbid_external=True
            ),
        )

    def _xlsx(self, plik: Path) -> PlikImportu:
        with ZipFile(plik) as z:
            if len(z.infolist()) > 2000 or sum(i.file_size for i in z.infolist()) > MAX_XML:
                raise blad("Rozpakowany XLSX przekracza limit 40 MB lub 2000 elementów.")
            if len(set(z.namelist())) != len(z.namelist()):
                raise blad("XLSX zawiera powtórzone elementy archiwum.")
            formaty = dict(FORMATY_WBUDOWANE)
            style = [0]
            if "xl/styles.xml" in z.namelist():
                styles = self._xml(z, "xl/styles.xml")
                for e in styles.findall(NS + "numFmts/" + NS + "numFmt"):
                    formaty[int(e.attrib["numFmtId"])] = e.attrib["formatCode"]
                style = [
                    int(e.get("numFmtId", "0")) for e in styles.findall(NS + "cellXfs/" + NS + "xf")
                ] or [0]
            teksty = []
            if "xl/sharedStrings.xml" in z.namelist():
                teksty = [
                    "".join(t.text or "" for t in e.iter(NS + "t"))
                    for e in self._xml(z, "xl/sharedStrings.xml")
                ]
            rel = {e.attrib["Id"]: e for e in self._xml(z, "xl/_rels/workbook.xml.rels")}
            arkusze: list[Arkusz] = []
            ile_komorek = 0
            ile_wierszy = 0
            for sheet in self._xml(z, "xl/workbook.xml").iter(NS + "sheet"):
                if len(arkusze) >= 100:
                    raise blad("Limit 100 arkuszy w pliku.")
                rid = sheet.attrib[
                    "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
                ]
                r = rel[rid]
                if r.get("TargetMode") == "External" or not r.get("Type", "").endswith(
                    "/worksheet"
                ):
                    raise blad("Nieobsługiwany typ arkusza XLSX.")
                target = r.attrib["Target"]
                target = posixpath.normpath(
                    target.lstrip("/") if target.startswith("/") else posixpath.join("xl", target)
                )
                if not target.startswith("xl/worksheets/"):
                    raise blad("Nieprawidłowa ścieżka arkusza XLSX.")
                rows = []
                last = 0
                for row in self._xml(z, target).iter(NS + "row"):
                    ile_wierszy += 1
                    if ile_wierszy > MAX_WIERSZE:
                        raise blad("Limit 20000 wierszy we wszystkich arkuszach.")
                    numer = int(row.attrib["r"])
                    if numer <= last or numer > MAX_WIERSZE:
                        raise blad("Nieprawidłowa kolejność lub limit 20000 wierszy XLSX.")
                    last = numer
                    cells: list[Komorka] = []
                    for c in row.findall(NS + "c"):
                        ile_komorek += 1
                        if ile_komorek > 250000:
                            raise blad("Limit 250000 komórek w pliku.")
                        i = kolumna(c.attrib["r"])
                        if i < len(cells):
                            raise blad("Nieprawidłowa kolejność komórek XLSX.")
                        cells.extend(Komorka() for _ in range(i + 1 - len(cells)))
                        v = c.find(NS + "v")
                        value = v.text or "" if v is not None else ""
                        typ = c.get("t")
                        if typ == "s":
                            indeks = int(value)
                            if indeks < 0:
                                raise blad("Nieprawidłowy indeks tekstu XLSX.")
                            value = teksty[indeks]
                        elif typ == "inlineStr":
                            value = "".join(t.text or "" for t in c.iter(NS + "t"))
                        problem = ""
                        if c.find(NS + "f") is not None:
                            problem = "Formuła w mapowanym polu — wpisz wartość tekstową"
                        elif typ in ("e", "b", "d"):
                            problem = "Nieobsługiwany typ komórki w mapowanym polu"
                        elif typ not in ("s", "inlineStr", "str") and value:
                            problem = (
                                "Komórka liczbowa — potwierdź tekst "
                                "(formatowanie/zera mogą się różnić)"
                            )
                        if len(value) > 32767:
                            raise blad("Komórka przekracza limit 32767 znaków.")
                        cena, problem_formatu = None, ""
                        if typ not in ("s", "inlineStr", "str", "e", "b", "d") and value:
                            styl = int(c.get("s", "0"))
                            if styl < 0 or styl >= len(style):
                                raise blad("Nieprawidłowy styl komórki XLSX.")
                            cena, problem_formatu = widoczna_cena(
                                value, formaty.get(style[styl], "nieznany")
                            )
                        cells[i] = Komorka(value, problem, cena, problem_formatu)
                    rows.append((numer, tuple(cells)))
                arkusze.append(Arkusz(sheet.attrib["name"], tuple(rows)))
        if not arkusze:
            raise blad("Brak arkuszy w pliku.")
        return PlikImportu(plik.name, tuple(arkusze))
