"""Odczyt metadanych bez otwierania pliku bazy i bez uruchamiania Qt."""

import platform
import sqlite3
from datetime import UTC, datetime
from importlib.metadata import PackageNotFoundError, version

from vexlab.przypadki_uzycia.diagnostyka import WersjeSrodowiska
from vexlab.rdzen.kontrakty import BladTechniczny


class ZegarSystemowy:
    def teraz(self) -> datetime:
        return datetime.now(UTC)


class CzytnikWersjiSystemowych:
    def odczytaj(self) -> WersjeSrodowiska:
        try:
            pyside6 = version("PySide6")
        except PackageNotFoundError as blad:
            raise BladTechniczny("Brak wymaganej instalacji PySide6.") from blad
        return WersjeSrodowiska(platform.python_version(), pyside6, sqlite3.sqlite_version)
