"""Magazyn zaszyfrowany Windows DPAPI, związany z bieżącym użytkownikiem."""

import ctypes
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Protocol

from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    BladAllegro,
    KontoAllegro,
    SrodowiskoAllegro,
    ZapamietaneAllegro,
)

LIMIT = 128 * 1024


class Szyfrator(Protocol):
    def zaszyfruj(self, dane: bytes) -> bytes: ...
    def odszyfruj(self, dane: bytes) -> bytes: ...


class Blob(ctypes.Structure):
    _fields_ = [("rozmiar", ctypes.c_uint32), ("dane", ctypes.POINTER(ctypes.c_ubyte))]


class DPAPIWindows:
    def _biblioteki(self) -> tuple[Any, Any]:
        if sys.platform != "win32":
            raise BladAllegro("MAGAZYN", "Zapamiętywanie połączenia wymaga Windows.")
        try:
            return (
                ctypes.WinDLL("crypt32.dll", winmode=0x00000800),
                ctypes.WinDLL("kernel32.dll", winmode=0x00000800),
            )
        except OSError:
            raise BladAllegro("MAGAZYN", "Nie można uruchomić ochrony danych Windows.") from None

    def _wykonaj(self, dane: bytes, szyfruj: bool) -> bytes:
        if not dane or len(dane) > LIMIT:
            raise BladAllegro("MAGAZYN", "Nieprawidłowy rozmiar danych połączenia.")
        crypt, kernel = self._biblioteki()
        fn = crypt.CryptProtectData if szyfruj else crypt.CryptUnprotectData
        fn.argtypes = [
            ctypes.POINTER(Blob),
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_uint32,
            ctypes.POINTER(Blob),
        ]
        fn.restype = ctypes.c_int
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree.restype = ctypes.c_void_p
        buf = ctypes.create_string_buffer(dane)
        wejscie = Blob(len(dane), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte)))
        wynik = Blob()
        try:
            # CRYPTPROTECT_UI_FORBIDDEN; bez LOCAL_MACHINE: zakres bieżącego użytkownika.
            if not fn(ctypes.byref(wejscie), None, None, None, None, 1, ctypes.byref(wynik)):
                raise BladAllegro(
                    "MAGAZYN", "Windows nie może zabezpieczyć lub odczytać połączenia."
                )
            if not wynik.dane or not 0 < wynik.rozmiar <= LIMIT:
                raise BladAllegro("MAGAZYN", "Nieprawidłowy wynik ochrony danych Windows.")
            return ctypes.string_at(wynik.dane, wynik.rozmiar)
        finally:
            ctypes.memset(buf, 0, len(buf))
            if wynik.dane:
                if 0 < wynik.rozmiar <= LIMIT:
                    ctypes.memset(wynik.dane, 0, wynik.rozmiar)
                kernel.LocalFree(ctypes.cast(wynik.dane, ctypes.c_void_p))

    def zaszyfruj(self, dane: bytes) -> bytes:
        return self._wykonaj(dane, True)

    def odszyfruj(self, dane: bytes) -> bytes:
        return self._wykonaj(dane, False)


class SekretyAllegro:
    def __init__(self, plik: Path, szyfrator: Szyfrator) -> None:
        self.plik, self.szyfrator = plik, szyfrator

    def zapisz(self, dane: ZapamietaneAllegro) -> None:
        dane.aplikacja.sprawdz()
        if not dane.odswiezanie or len(dane.odswiezanie) > 16384:
            raise BladAllegro("MAGAZYN", "Brak poprawnego tokenu odnowienia.")
        jawne = json.dumps(
            {
                "wersja": 1,
                "klient": dane.aplikacja.klient,
                "sekret": dane.aplikacja.sekret,
                "srodowisko": dane.aplikacja.srodowisko.name,
                "zapis_szkicow": dane.aplikacja.zapis_szkicow,
                "konto": dane.konto.id,
                "login": dane.konto.login,
                "refresh": dane.odswiezanie,
            },
            ensure_ascii=False,
        ).encode()
        # Żaden plik tymczasowy nie otrzymuje jawnej treści.
        szyfr = self.szyfrator.zaszyfruj(jawne)
        if not szyfr or len(szyfr) > LIMIT:
            raise BladAllegro("MAGAZYN", "Nieprawidłowy rozmiar zabezpieczonego połączenia.")
        tymczasowy: Path | None = None
        try:
            self.plik.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            with tempfile.NamedTemporaryFile(
                dir=self.plik.parent, prefix=".allegro-", delete=False
            ) as f:
                tymczasowy = Path(f.name)
                f.write(szyfr)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tymczasowy, self.plik)
        except OSError:
            raise BladAllegro(
                "MAGAZYN", "Nie udało się zapamiętać połączenia na tym komputerze."
            ) from None
        finally:
            if tymczasowy is not None:
                try:
                    tymczasowy.unlink(missing_ok=True)
                except OSError:
                    raise BladAllegro(
                        "MAGAZYN", "Nie można uporządkować pliku połączenia."
                    ) from None

    def odczytaj(self) -> ZapamietaneAllegro | None:
        try:
            with self.plik.open("rb") as f:
                szyfr = f.read(LIMIT + 1)
        except FileNotFoundError:
            return None
        except OSError:
            raise BladAllegro("MAGAZYN", "Nie można odczytać zapisanego połączenia.") from None
        if not szyfr or len(szyfr) > LIMIT:
            raise BladAllegro(
                "MAGAZYN", "Zapisane połączenie jest nieprawidłowe. Usuń je i połącz ponownie."
            )
        jawne = self.szyfrator.odszyfruj(szyfr)
        if len(jawne) > LIMIT:
            raise BladAllegro("MAGAZYN", "Nieprawidłowy rozmiar odczytanego połączenia.")
        try:
            d = json.loads(jawne)
            if not isinstance(d, dict) or type(d.get("wersja")) is not int or d["wersja"] != 1:
                raise ValueError()
            for pole, limit in (
                ("klient", 512),
                ("sekret", 1024),
                ("konto", 100),
                ("login", 200),
                ("refresh", 16384),
            ):
                if (
                    not isinstance(d.get(pole), str)
                    or not d[pole]
                    or len(d[pole]) > limit
                    or any(ord(c) < 32 for c in d[pole])
                ):
                    raise ValueError()
            if type(d.get("zapis_szkicow", False)) is not bool:
                raise ValueError()
            a = AplikacjaAllegro(
                d["klient"],
                d["sekret"],
                SrodowiskoAllegro[d["srodowisko"]],
                d.get("zapis_szkicow", False),
            )
            a.sprawdz()
            return ZapamietaneAllegro(a, KontoAllegro(d["konto"], d["login"]), d["refresh"])
        except (ValueError, TypeError, KeyError, RecursionError):
            raise BladAllegro(
                "MAGAZYN", "Zapisane połączenie jest nieprawidłowe. Połącz konto ponownie."
            ) from None

    def usun(self) -> None:
        try:
            self.plik.unlink(missing_ok=True)
        except OSError:
            raise BladAllegro(
                "MAGAZYN", "Nie można usunąć zapisanego połączenia. Ponów rozłączenie."
            ) from None
