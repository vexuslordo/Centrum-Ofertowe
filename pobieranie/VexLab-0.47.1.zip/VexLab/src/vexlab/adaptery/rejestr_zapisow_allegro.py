"""Trwały dziennik techniczny: wyłącznie skróty i identyfikator operacji, bez treści/tokenów."""

import json
import os
from pathlib import Path

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import ProbaZapisu


class RejestrZapisowJSON:
    def __init__(self, katalog: Path) -> None:
        self.katalog = katalog

    def _plik(self, klucz: str) -> Path:
        if len(klucz) != 64 or any(c not in "0123456789abcdef" for c in klucz):
            raise BladAllegro("REJESTR", "Nieprawidłowy klucz rejestru zapisów.")
        return self.katalog / (klucz + ".json")

    def odczytaj(self, klucz: str) -> ProbaZapisu | None:
        plik = self._plik(klucz)
        try:
            with plik.open("rb") as f:
                d = json.loads(f.read(4097))
            if (
                not isinstance(d, dict)
                or set(d) != {"cel", "operacja"}
                or not isinstance(d["cel"], str)
                or len(d["cel"]) != 64
                or any(c not in "0123456789abcdef" for c in d["cel"])
                or not isinstance(d["operacja"], str)
                or len(d["operacja"]) > 100
            ):
                raise ValueError("rejestr")
            return ProbaZapisu(d["cel"], d["operacja"])
        except FileNotFoundError:
            return None
        except (OSError, ValueError, UnicodeError):
            raise BladAllegro(
                "REJESTR",
                "Nie można odczytać rejestru. Zapis zablokowany; zachowaj pliki do diagnostyki.",
            ) from None

    def rozpocznij(self, klucz: str, proba: ProbaZapisu) -> None:
        try:
            self.katalog.mkdir(parents=True, exist_ok=True)
            with self._plik(klucz).open("xb") as f:
                f.write(json.dumps({"cel": proba.cel, "operacja": proba.operacja}).encode())
                f.flush()
                os.fsync(f.fileno())
        except OSError:
            raise BladAllegro(
                "REJESTR", "Nie można rozpocząć zapisu. Sprawdź poprzedni wynik i rejestr zapisów."
            ) from None

    def operacja(self, klucz: str, proba: ProbaZapisu) -> None:
        # Nie usuwamy blokady, jeśli zapis metadanych zostanie przerwany.
        try:
            with self._plik(klucz).open("wb") as f:
                f.write(json.dumps({"cel": proba.cel, "operacja": proba.operacja}).encode())
                f.flush()
                os.fsync(f.fileno())
        except OSError:
            raise BladAllegro(
                "REJESTR", "Nie zapisano metadanych operacji. Wynik wymaga sprawdzenia."
            ) from None

    def zakoncz(self, klucz: str) -> None:
        try:
            self._plik(klucz).unlink()
        except OSError:
            raise BladAllegro(
                "REJESTR", "Wynik odczytano, ale nie zwolniono blokady zapisu. Sprawdź rejestr."
            ) from None
