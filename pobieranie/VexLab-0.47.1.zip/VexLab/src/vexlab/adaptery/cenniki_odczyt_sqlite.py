"""Odczyt pojedynczych rekordów JSON przez SQLite, bez pełnego JSON w Pythonie."""

import json
import sqlite3
from collections.abc import Generator
from uuid import UUID

from vexlab.adaptery.format_cennika import _pozycja
from vexlab.przypadki_uzycia.importowanie import PozycjaImportu, blad
from vexlab.rdzen.kontrakty import BladTechniczny


def _dokument(conn: sqlite3.Connection, id: UUID, wersja: int) -> int:
    conn.execute("BEGIN")
    row = conn.execute(
        "SELECT length(CAST(dane_json AS BLOB)),liczba,wersja FROM cenniki WHERE id=?",
        (str(id),),
    ).fetchone()
    if row is None or row[2] != wersja:
        raise blad("Cennik został usunięty lub zmieniony. Odśwież listę.")
    if not isinstance(row[1], int) or row[0] > 64 * 1024 * 1024 or not 0 < row[1] <= 20000:
        raise BladTechniczny("Nie można odczytać cennika. Zachowaj kopię bazy.")
    struktura = conn.execute(
        "SELECT CASE WHEN json_valid(dane_json) THEN json_type(dane_json) ELSE '' END,"
        "CASE WHEN json_valid(dane_json) THEN json_array_length(dane_json) ELSE -1 END "
        "FROM cenniki WHERE id=?",
        (str(id),),
    ).fetchone()
    if struktura[0] != "array" or struktura[1] != row[1]:
        raise BladTechniczny("Nie można odczytać cennika. Zachowaj kopię bazy.")
    return int(row[1])


def _dekoduj(tekst: str) -> PozycjaImportu:
    try:
        return _pozycja(json.loads(tekst))
    except (ValueError, KeyError, TypeError, AttributeError, RecursionError) as exc:
        raise BladTechniczny("Nie można odczytać cennika. Zachowaj kopię bazy.") from exc


def symbole(conn: sqlite3.Connection, id: UUID, wersja: int) -> tuple[str, ...]:
    _dokument(conn, id, wersja)
    wynik = tuple(
        r[0]
        for r in conn.execute(
            "SELECT json_extract(j.value,'$.dane.sku') FROM cenniki c,json_each(c.dane_json) j "
            "WHERE c.id=?",
            (str(id),),
        )
    )
    if not all(isinstance(sku, str) for sku in wynik):
        raise BladTechniczny("Cennik zawiera nieprawidłowe SKU. Zachowaj kopię bazy.")
    return wynik


def iteruj(conn: sqlite3.Connection, id: UUID, wersja: int) -> Generator[PozycjaImportu]:
    _dokument(conn, id, wersja)
    for oczekiwany, row in enumerate(
        conn.execute(
            "SELECT j.key,j.value FROM cenniki c,json_each(c.dane_json) j WHERE c.id=?", (str(id),)
        )
    ):
        if row[0] != oczekiwany:
            raise BladTechniczny("Nieprawidłowa kolejność pozycji cennika.")
        yield _dekoduj(row[1])


def wybrane(
    conn: sqlite3.Connection, id: UUID, wersja: int, indeksy: frozenset[int]
) -> dict[int, PozycjaImportu]:
    liczba = _dokument(conn, id, wersja)
    if not indeksy <= set(range(liczba)):
        raise blad("Nieprawidłowy wybór pozycji cennika.")
    if not indeksy:
        return {}
    return {
        int(row[0]): _dekoduj(row[1])
        for row in conn.execute(
            "SELECT j.key,j.value FROM cenniki c,json_each(c.dane_json) j "
            "WHERE c.id=? AND j.key IN (SELECT value FROM json_each(?))",
            (str(id), json.dumps(sorted(indeksy))),
        )
    }
