"""Implementacje portów infrastrukturalnych; bez reguł domenowych."""
