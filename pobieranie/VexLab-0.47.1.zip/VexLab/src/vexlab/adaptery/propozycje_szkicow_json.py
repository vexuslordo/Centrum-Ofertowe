"""Pliki roboczych propozycji; zamknięty format bez tokenów i surowych odpowiedzi API."""

import json
from dataclasses import asdict
from pathlib import Path

from vexlab.przypadki_uzycia.allegro import SrodowiskoAllegro
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu
from vexlab.przypadki_uzycia.propozycje_szkicow import PropozycjaSzkicu, Sekcje
from vexlab.rdzen.kontrakty import BladTechniczny

LIMIT = 2 * 1024 * 1024


def _obiekt(pary: list[tuple[str, object]]) -> dict[str, object]:
    wynik: dict[str, object] = {}
    for k, v in pary:
        if k in wynik:
            raise ValueError("powtórzone pole")
        wynik[k] = v
    return wynik


def sekcje(dane: object) -> Sekcje:
    if not isinstance(dane, list) or len(dane) > 100:
        raise ValueError("sekcje")
    wynik = []
    for s in dane:
        if not isinstance(s, list) or not 1 <= len(s) <= 2:
            raise ValueError("sekcja")
        elementy = []
        for e in s:
            if (
                not isinstance(e, dict)
                or set(e) != {"typ", "tekst", "adres"}
                or any(not isinstance(v, str) for v in e.values())
            ):
                raise ValueError("element")
            elementy.append(ElementPodgladu(**e))
        wynik.append(tuple(elementy))
    return tuple(wynik)


class PropozycjeJSON:
    def zapisz(self, cel: Path, p: PropozycjaSzkicu) -> None:
        p.sprawdz()
        dane = asdict(p)
        dane["srodowisko"] = p.srodowisko.value
        tekst = json.dumps(
            {"format": "vexlab-propozycja-szkicu-1", "propozycja": dane},
            ensure_ascii=False,
            indent=2,
        ).encode("utf-8")
        if len(tekst) > LIMIT:
            raise BladTechniczny("Propozycja przekracza 2 MiB. Nie zapisano pliku.")
        utworzony = False
        try:
            with cel.open("xb") as plik:
                utworzony = True
                plik.write(tekst)
        except FileExistsError:
            raise BladTechniczny(
                "Plik już istnieje. Wybierz nową nazwę; nie nadpisano danych."
            ) from None
        except OSError:
            if utworzony:
                try:
                    cel.unlink(missing_ok=True)
                except OSError:
                    raise BladTechniczny(
                        "Zapis przerwany. Pozostał niekompletny plik propozycji."
                    ) from None
            raise BladTechniczny("Nie udało się zapisać propozycji. Zachowano formularz.") from None

    def odczytaj(self, zrodlo: Path) -> PropozycjaSzkicu:
        try:
            with zrodlo.open("rb") as plik:
                dane = plik.read(LIMIT + 1)
            if len(dane) > LIMIT:
                raise ValueError("rozmiar")
            obj = json.loads(dane, object_pairs_hook=_obiekt)
            if (
                not isinstance(obj, dict)
                or set(obj) != {"format", "propozycja"}
                or obj["format"] != "vexlab-propozycja-szkicu-1"
            ):
                raise ValueError("format")
            d = obj["propozycja"]
            pola = {
                "srodowisko",
                "konto_id",
                "oferta_id",
                "tytul_bazowy",
                "sekcje_bazowe",
                "tytul",
                "sekcje",
            }
            if not isinstance(d, dict) or set(d) != pola:
                raise ValueError("pola")
            for k in pola - {"sekcje", "sekcje_bazowe"}:
                if not isinstance(d[k], str):
                    raise ValueError("typ")
            wynik = PropozycjaSzkicu(
                SrodowiskoAllegro(d["srodowisko"]),
                d["konto_id"],
                d["oferta_id"],
                d["tytul_bazowy"],
                sekcje(d["sekcje_bazowe"]),
                d["tytul"],
                sekcje(d["sekcje"]),
            )
            wynik.sprawdz()
            return wynik
        except (OSError, ValueError, TypeError, RecursionError, UnicodeError):
            raise BladTechniczny(
                "Nie można odczytać pliku propozycji szkicu. Nie zmieniono formularza."
            ) from None
