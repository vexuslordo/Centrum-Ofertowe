"""Atomowy zapis samodzielnych szkiców; bez tworzenia lub zmiany Produktów."""

import hashlib
import json
from dataclasses import asdict, replace
from pathlib import Path
from uuid import UUID, uuid4

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.domena.oferta import SzkicOferty
from vexlab.przypadki_uzycia.importowanie import blad
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.szkice import PlanSzkicow, SzkicDTO, WynikSzkicow
from vexlab.rdzen.kontrakty import BladTechniczny


def _zapis(oferta: OfertaPodglad) -> str:
    return json.dumps(asdict(oferta), ensure_ascii=False, sort_keys=True)


def _klucz(oferta: OfertaPodglad) -> str:
    dane = asdict(oferta)
    dane.pop("numer")
    dane.pop("problemy")
    dane["sku"] = oferta.sku.strip().casefold()
    return hashlib.sha256(json.dumps(dane, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def _odczyt(tekst: str) -> OfertaPodglad:
    try:
        dane = json.loads(tekst)
        return OfertaPodglad(
            numer=int(dane["numer"]),
            sku=str(dane["sku"]),
            tytul=str(dane["tytul"]),
            opis=str(dane["opis"]),
            ean=str(dane["ean"]),
            cena=str(dane["cena"]),
            dopasowanie_tekst=str(dane["dopasowanie_tekst"]),
            zdjecia=tuple(dane["zdjecia"]),
            sekcje=tuple(tuple(ElementPodgladu(**e) for e in s) for s in dane["sekcje"]),
            problemy=tuple(dane["problemy"]),
        )
    except (ValueError, TypeError, KeyError) as exc:
        raise BladTechniczny("Nie można odczytać treści szkicu. Zachowaj kopię bazy.") from exc


class SzkiceSQLite(KatalogSQLite):
    def zapisz_paczke(self, plan: PlanSzkicow) -> WynikSzkicow:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            kopia = self._kopia_spojna("kopie_szkicow")
            zapisane, pominiete = 0, 0
            for oferta in plan.pozycje:
                klucz = _klucz(oferta)
                if conn.execute("SELECT 1 FROM szkice WHERE klucz=?", (klucz,)).fetchone():
                    pominiete += 1
                    continue
                szkic = SzkicOferty(uuid4(), None, None, oferta.tytul, oferta.opis)
                conn.execute(
                    "INSERT INTO szkice (id,produkt_id,wersja_produktu,tytul,opis,"
                    "tresc_json,zrodlo,klucz,wersja) VALUES (?,?,?,?,?,?,?,?,?)",
                    (
                        str(szkic.id),
                        None,
                        None,
                        szkic.tytul,
                        szkic.opis,
                        _zapis(oferta),
                        plan.zrodlo,
                        klucz,
                        1,
                    ),
                )
                zapisane += 1
        return WynikSzkicow(zapisane, pominiete, kopia)

    def lista(self) -> tuple[SzkicDTO, ...]:
        with self._polaczenie() as conn:
            rows = conn.execute(
                "SELECT s.*, p.wersja AS aktualna FROM szkice s "
                "LEFT JOIN produkty p ON p.id=s.produkt_id ORDER BY s.rowid DESC"
            ).fetchall()
        return tuple(
            SzkicDTO(
                UUID(r["id"]),
                UUID(r["produkt_id"]) if r["produkt_id"] is not None else None,
                r["wersja_produktu"],
                r["wersja"],
                replace(_odczyt(r["tresc_json"]), tytul=r["tytul"], opis=r["opis"]),
                r["zrodlo"],
                r["produkt_id"] is not None and r["aktualna"] != r["wersja_produktu"],
            )
            for r in rows
        )

    def edytuj(self, szkic: SzkicOferty, oferta: OfertaPodglad | None = None) -> None:
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT wersja,tresc_json FROM szkice WHERE id=?", (str(szkic.id),)
            ).fetchone()
            if row is None or row[0] != szkic.wersja - 1:
                raise blad("Szkic zmienił się. Odśwież listę przed edycją.")
            self._kopia_spojna("kopie_szkicow")
            conn.execute(
                "UPDATE szkice SET tytul=?,opis=?,wersja=?,tresc_json=? WHERE id=?",
                (
                    szkic.tytul,
                    szkic.opis,
                    szkic.wersja,
                    _zapis(oferta) if oferta is not None else row["tresc_json"],
                    str(szkic.id),
                ),
            )

    def usun(self, id: UUID, wersja: int) -> Path:
        return self.usun_wiele(((id, wersja),))

    def usun_wiele(self, szkice: tuple[tuple[UUID, int], ...]) -> Path:
        if not szkice or len({s[0] for s in szkice}) != len(szkice):
            raise blad("Nieprawidłowy zakres usuwania szkiców.")
        with self._polaczenie() as conn:
            conn.execute("BEGIN IMMEDIATE")
            for id, wersja in szkice:
                row = conn.execute("SELECT wersja FROM szkice WHERE id=?", (str(id),)).fetchone()
                if row is None or row[0] != wersja:
                    raise blad("Szkice zmieniły się. Odśwież listę przed usunięciem.")
            kopia = self._kopia_spojna("kopie_szkicow")
            conn.executemany("DELETE FROM szkice WHERE id=?", ((str(s[0]),) for s in szkice))
        return kopia
