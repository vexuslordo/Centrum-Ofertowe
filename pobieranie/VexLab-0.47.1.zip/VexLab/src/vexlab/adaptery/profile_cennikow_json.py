"""Ograniczone, atomowo zapisywane profile użytkownika, poza bazą produktów."""

import json
import os
from dataclasses import asdict
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any, cast
from uuid import UUID

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.importowanie import Mapowanie, MapowanieCeny, MapowanieMotocykla
from vexlab.przypadki_uzycia.profile_cennikow import ProfilCennika
from vexlab.rdzen.kontrakty import BladTechniczny


def obiekt(pary: list[tuple[str, Any]]) -> dict[str, Any]:
    wynik: dict[str, Any] = {}
    for k, v in pary:
        if k in wynik:
            raise ValueError("Powtórzony klucz")
        wynik[k] = v
    return wynik


def liczba(d: dict[str, Any], k: str, opcjonalna: bool = False) -> int | None:
    x = d.get(k)
    if opcjonalna and x is None:
        return None
    if type(x) is not int or not 0 <= x <= 20000:
        raise ValueError("Indeks profilu")
    return x


def logiczna(d: dict[str, Any], k: str) -> bool:
    if type(d.get(k)) is not bool:
        raise ValueError("Flaga profilu")
    return bool(d[k])


def dekoduj(d: Any) -> ProfilCennika:
    if not isinstance(d, dict) or type(d.get("wersja")) is not int or d["wersja"] != 1:
        raise ValueError("Wersja profilu")
    mapa = d["mapa"]
    if not isinstance(mapa, dict):
        raise ValueError("Mapowanie")
    cena, moto = mapa.get("cena"), mapa.get("motocykl")
    cena_m = None
    if cena is not None:
        if not isinstance(cena, dict) or not all(
            isinstance(cena.get(k), str) for k in ("waluta", "rodzaj")
        ):
            raise ValueError("Cena")
        cena_m = MapowanieCeny(
            cast(int, liczba(cena, "kolumna")),
            cena["waluta"],
            cena["rodzaj"],
            logiczna(cena, "zapisane_formuly"),
        )
    moto_m = None
    if moto is not None:
        if not isinstance(moto, dict):
            raise ValueError("Dopasowanie")
        moto_m = MapowanieMotocykla(
            cast(int, liczba(moto, "marka")),
            cast(int, liczba(moto, "model")),
            *(liczba(moto, k, True) for k in ("rok_od", "rok_do", "wariant")),
        )
    naglowki = d["naglowki"]
    if not isinstance(naglowki, list) or not all(isinstance(x, str) for x in naglowki):
        raise ValueError("Nagłówki")
    if not isinstance(d.get("nazwa"), str):
        raise ValueError("Nazwa")
    profil = ProfilCennika(
        UUID(d["id"]),
        d["nazwa"],
        tuple(naglowki),
        Mapowanie(
            cast(int, liczba(mapa, "naglowek")),
            cast(int, liczba(mapa, "nazwa")),
            cast(int, liczba(mapa, "sku")),
            liczba(mapa, "opis", True),
            liczba(mapa, "dodatkowy_opis", True),
            logiczna(mapa, "dolacz_nazwe_zrodlowa"),
            cena_m,
            moto_m,
            liczba(mapa, "ean", True),
        ),
        UUID(d["producent_id"]) if d.get("producent_id") is not None else None,
    )
    profil.sprawdz()
    return profil


class ProfileCennikowJSON:
    def __init__(self, katalog: Path) -> None:
        self.katalog = katalog

    def _czytaj(self, plik: Path) -> ProfilCennika:
        if plik.is_symlink():
            raise ValueError("Dowiązanie profilu")
        with plik.open("rb") as f:
            dane = f.read(65537)
        if len(dane) > 65536:
            raise ValueError("Rozmiar profilu")
        p = dekoduj(json.loads(dane, object_pairs_hook=obiekt))
        if str(p.id) != plik.stem:
            raise ValueError("Id profilu")
        return p

    def lista(self) -> tuple[ProfilCennika, ...]:
        try:
            if not self.katalog.exists():
                return ()
            pliki = self._pliki()
            return tuple(self._czytaj(p) for p in pliki)
        except (
            OSError,
            ValueError,
            TypeError,
            KeyError,
            RecursionError,
            BladScenariuszaKatalogu,
        ) as exc:
            raise BladTechniczny(
                "Nie można odczytać profili cenników. Pliki ustawień pozostawiono; "
                "możesz ustawić kolumny ręcznie."
            ) from exc

    def _pliki(self) -> list[Path]:
        if not self.katalog.is_dir() or self.katalog.is_symlink():
            raise ValueError("Folder profili")
        # Ograniczony odczyt katalogu, również przy nieprawidłowej liczbie wpisów.
        pliki = []
        for p in self.katalog.glob("*.json"):
            pliki.append(p)
            if len(pliki) > 500:
                raise ValueError("Limit profili")
        return sorted(pliki)

    def dodaj(self, profil: ProfilCennika) -> None:
        profil.sprawdz()
        tmp = None
        try:
            self.katalog.mkdir(parents=True, exist_ok=True)
            if len(self._pliki()) >= 500:
                raise ValueError("Limit profili")
            cel = self.katalog / f"{profil.id}.json"
            if cel.exists() or cel.is_symlink():
                raise ValueError("Profil już istnieje")
            dane = json.dumps(
                {"wersja": 1, **asdict(profil)}, ensure_ascii=False, default=str
            ).encode()
            if len(dane) > 65536:
                raise ValueError("Rozmiar profilu")
            with NamedTemporaryFile(dir=self.katalog, prefix=".profil-", delete=False) as f:
                tmp = Path(f.name)
                f.write(dane)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, cel)
            tmp = None
        except (OSError, ValueError) as exc:
            raise BladTechniczny("Nie zapisano profilu cennika. Sprawdź folder ustawień.") from exc
        finally:
            if tmp is not None:
                tmp.unlink(missing_ok=True)

    def usun(self, profil: ProfilCennika) -> None:
        try:
            plik = self.katalog / f"{profil.id}.json"
            if self._czytaj(plik) != profil:
                raise ValueError("Profil zmieniony")
            plik.unlink()
        except (
            OSError,
            ValueError,
            TypeError,
            KeyError,
            RecursionError,
            BladScenariuszaKatalogu,
        ) as exc:
            raise BladTechniczny("Nie usunięto profilu. Odśwież plik i listę profili.") from exc
