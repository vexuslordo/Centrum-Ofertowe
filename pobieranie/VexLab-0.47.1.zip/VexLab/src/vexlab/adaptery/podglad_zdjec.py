"""Ograniczony obraz HTTPS; ten sam transport i dekoder co media Produktów."""

from vexlab.adaptery.obraz import obraz
from vexlab.adaptery.zdjecia_shopify import TransportPubliczny
from vexlab.przypadki_uzycia.media import ZdjecieDane


class ObrazHTTPS:
    def __init__(self, transport: TransportPubliczny) -> None:
        self.transport = transport

    def pobierz_obraz(self, url: str) -> ZdjecieDane:
        return obraz(self.transport.odczytaj(url, 8 * 1024 * 1024), url)
