"""Kolory natywnej ramki Windows; podłączenie do Qt wyłącznie w bootstrapie."""

import ctypes
import sys
from collections.abc import Callable
from ctypes import wintypes
from typing import cast

from PySide6.QtCore import QDynamicPropertyChangeEvent, QEvent, QObject, Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication, QWidget

UstawAtrybut = Callable[[int, int, int], int]


def ustaw_kolory(ustaw: UstawAtrybut, hwnd: int, ciemny: bool, tlo: QColor, tekst: QColor) -> None:
    """DWM 20: Win10 2004+, 19: starszy Win10; 35/36: Win11.

    Ujemny HRESULT oznacza brak obsługi. Kolor jest opcjonalny i nie może
    blokować uruchomienia aplikacji na starszym Windows.
    """
    if ustaw(hwnd, 20, int(ciemny)) < 0:
        ustaw(hwnd, 19, int(ciemny))
    for atrybut, kolor in ((35, tlo), (36, tekst)):
        colorref = kolor.red() | (kolor.green() << 8) | (kolor.blue() << 16)
        ustaw(hwnd, atrybut, colorref)


class PasekTytulu(QObject):
    """Filtr nie konsumuje zdarzeń; przyciski i geometria pozostają natywne."""

    def __init__(self, app: QApplication, ustaw: UstawAtrybut) -> None:
        super().__init__(app)
        self.app = app
        self.ustaw = ustaw
        app.installEventFilter(self)

    def eventFilter(self, obiekt: QObject, zdarzenie: QEvent) -> bool:
        if (
            obiekt is self.app
            and zdarzenie.type() == QEvent.Type.DynamicPropertyChange
            and cast(QDynamicPropertyChangeEvent, zdarzenie).propertyName() == b"pasek_tytulu"
        ):
            for okno in self.app.topLevelWidgets():
                self._zastosuj(okno)
        elif isinstance(obiekt, QWidget) and zdarzenie.type() in (
            QEvent.Type.Show,
            QEvent.Type.WinIdChange,
            QEvent.Type.WindowActivate,
        ):
            self._zastosuj(obiekt)
        return False

    def _zastosuj(self, okno: QWidget) -> None:
        if (
            not okno.isWindow()
            or okno.windowType()
            not in (Qt.WindowType.Window, Qt.WindowType.Dialog, Qt.WindowType.Tool)
            or okno.windowHandle() is None
        ):
            return
        kolory = self.app.property("pasek_tytulu")
        if not isinstance(kolory, (list, tuple)) or len(kolory) != 3:
            return
        ciemny, tlo, tekst = kolory
        ustaw_kolory(self.ustaw, int(okno.winId()), bool(ciemny), QColor(tlo), QColor(tekst))


def zainstaluj_pasek_tytulu(app: QApplication) -> PasekTytulu | None:
    if sys.platform != "win32":
        return None
    try:
        # Ładowanie tylko z System32, bez szukania DLL obok paczki użytkownika.
        dwm = ctypes.WinDLL("dwmapi.dll", winmode=0x00000800)
        funkcja = dwm.DwmSetWindowAttribute
    except (OSError, AttributeError):
        return None
    funkcja.argtypes = [wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
    funkcja.restype = ctypes.c_int32

    def ustaw(hwnd: int, atrybut: int, wartosc: int) -> int:
        dane = ctypes.c_uint32(wartosc)
        return int(funkcja(hwnd, atrybut, ctypes.byref(dane), ctypes.sizeof(dane)))

    return PasekTytulu(app, ustaw)
