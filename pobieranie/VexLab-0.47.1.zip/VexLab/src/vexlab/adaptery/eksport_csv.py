"""CSV do arkusza: UTF-8 BOM, średnik i jawna ochrona przed formułami."""

import csv
from pathlib import Path

from vexlab.przypadki_uzycia.eksport import WynikEksportu
from vexlab.przypadki_uzycia.katalog import ProduktDTO
from vexlab.rdzen.kontrakty import BladTechniczny


def _pole(wartosc: str) -> tuple[str, int]:
    indeks = 0
    while indeks < len(wartosc) and (wartosc[indeks].isspace() or wartosc[indeks] == "\ufeff"):
        indeks += 1
    if wartosc[indeks : indeks + 1] in {"=", "+", "-", "@"}:
        return "'" + wartosc, 1
    return wartosc, 0


class EksportCSV:
    def zapisz(self, cel: Path, produkty: tuple[ProduktDTO, ...]) -> WynikEksportu:
        utworzony = False
        zabezpieczone = 0
        try:
            with cel.open("x", encoding="utf-8-sig", newline="") as plik:
                utworzony = True
                writer = csv.writer(
                    plik, delimiter=";", quoting=csv.QUOTE_ALL, lineterminator="\r\n"
                )
                writer.writerow(("Nazwa produktu", "SKU", "Opis", "Producent", "EAN"))
                for produkt in produkty:
                    pola = []
                    for wartosc in (
                        produkt.nazwa,
                        produkt.sku,
                        produkt.opis,
                        produkt.producent_nazwa or "",
                        produkt.ean,
                    ):
                        tekst, zmieniono = _pole(wartosc)
                        pola.append(tekst)
                        zabezpieczone += zmieniono
                    writer.writerow(pola)
        except FileExistsError as blad:
            raise BladTechniczny(
                "Plik już istnieje. Wybierz nową nazwę — nie nadpisano danych."
            ) from blad
        except (OSError, UnicodeError, csv.Error) as blad:
            if utworzony:
                try:
                    cel.unlink(missing_ok=True)
                except OSError as sprzatanie:
                    raise BladTechniczny(
                        "Eksport nie powiódł się. Pozostał niekompletny plik — "
                        "nie używaj go jako gotowego eksportu."
                    ) from sprzatanie
            raise BladTechniczny(
                "Nie udało się zapisać eksportu CSV. Nie potwierdzono eksportu."
            ) from blad
        return WynikEksportu(len(produkty), zabezpieczone)
