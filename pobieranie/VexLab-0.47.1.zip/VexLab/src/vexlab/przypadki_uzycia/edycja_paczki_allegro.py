"""Atomowe przygotowanie zmian roboczych ofert, bez zapisu na koncie lub w ZIP."""

from dataclasses import dataclass, replace
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import UstawieniaSzkicu
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad


@dataclass(frozen=True)
class ZmianyPaczek:
    cena: str = ""  # ustaw / procent / kwota; puste = bez zmiany
    wartosc: str = ""
    ilosc: int | None = None
    tytuly: bool = False
    szukaj: str = ""
    zamien: str = ""
    przed: str = ""
    po: str = ""


def zmien_pozycje(
    pozycje: tuple[tuple[OfertaPodglad, UstawieniaSzkicu], ...], z: ZmianyPaczek
) -> tuple[tuple[OfertaPodglad, UstawieniaSzkicu], ...]:
    if z.ilosc is not None and (type(z.ilosc) is not int or not 0 <= z.ilosc <= 10000000):
        raise BladAllegro("EDYCJA", "Ilość musi wynosić 0–10 000 000.")
    wynik = []
    for o, u in pozycje:
        tytul = o.tytul
        if z.tytuly:
            tytul = z.przed + (tytul.replace(z.szukaj, z.zamien) if z.szukaj else tytul) + z.po
            if not 12 <= len(tytul) <= 75 or len(tytul.split()) < 3:
                raise BladAllegro("EDYCJA", f"{o.sku}: tytuł wymaga 12–75 znaków i min. 3 słów.")
        cena = u.cena
        if z.cena:
            try:
                n = Decimal(z.wartosc.replace(",", "."))
                if not n.is_finite() or abs(n) > Decimal("999999999"):
                    raise ValueError("wartość")
                if z.cena == "ustaw":
                    nowa = n
                else:
                    stara = Decimal((u.cena or o.cena).replace(",", "."))
                    if not stara.is_finite() or not 0 < stara <= Decimal("999999999"):
                        raise ValueError("cena źródłowa")
                    if z.cena == "procent":
                        nowa = stara * (1 + n / 100)
                    elif z.cena == "kwota":
                        nowa = stara + n
                    else:
                        raise ValueError("tryb")
                nowa = nowa.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                if not 0 < nowa <= Decimal("999999999"):
                    raise ValueError("zakres")
                cena = format(nowa, ".2f")
            except (InvalidOperation, ValueError):
                raise BladAllegro(
                    "EDYCJA", f"{o.sku}: niepoprawna cena lub wartość zmiany."
                ) from None
        wynik.append(
            (
                replace(o, tytul=tytul),
                replace(u, cena=cena, ilosc=z.ilosc if z.ilosc is not None else u.ilosc),
            )
        )
    return tuple(wynik)


def zmien_parametry(
    u: UstawieniaSzkicu, wartosci: tuple[tuple[str, str], ...], zrodla: tuple[tuple[str, str], ...]
) -> UstawieniaSzkicu:
    """Zmienia tylko wskazane identyfikatory, także jawne wyczyszczenie wartości."""
    values, sources = dict(u.wartosci), dict(u.zrodla)
    for ident, value in wartosci:
        values[ident] = value
        sources.pop(ident, None)
    sources.update(zrodla)
    return replace(u, wartosci=tuple(values.items()), zrodla=tuple(sources.items()))
