"""Podgląd paczek i profile odczytu użytkownika, bez zapisu modelu Oferty."""

from collections import Counter
from collections.abc import Mapping
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Protocol

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.rdzen.kontrakty import BladTechniczny


def blad(tekst: str) -> BladScenariuszaKatalogu:
    return BladScenariuszaKatalogu("PACZKA", tekst)


@dataclass(frozen=True)
class PlikPaczki:
    nazwa: str
    rozmiar: int
    uwaga: str = ""


@dataclass(frozen=True)
class ZbiorPaczki:
    nazwa: str
    pola: tuple[str, ...]
    rekordy: tuple[Mapping[str, object], ...]


@dataclass(frozen=True)
class ProfilPaczki:
    nazwa: str
    plik: str
    sku: str
    tytul: str
    opis: str = ""
    sekcje: str = ""
    zdjecia: str = ""
    ean: str = ""
    cena: str = ""
    dopasowanie_tekst: str = ""
    lista_elementow: str = ""
    typ_elementu: str = ""
    tresc_elementu: str = ""
    adres_elementu: str = ""
    typ_tekstu: str = ""
    typ_obrazu: str = ""

    def sprawdz(self) -> None:
        if not all(x.strip() for x in (self.nazwa, self.plik, self.sku, self.tytul)):
            raise blad("Wpisz nazwę profilu i wskaż plik oraz pola SKU i tytułu.")
        pola = [
            p
            for p in (
                self.sku,
                self.tytul,
                self.opis,
                self.sekcje,
                self.zdjecia,
                self.ean,
                self.cena,
                self.dopasowanie_tekst,
            )
            if p
        ]
        if len(pola) != len(set(pola)):
            raise blad("Każde mapowane pole danych musi mieć odrębne źródło.")
        if self.sku == self.tytul:
            raise blad("SKU i tytuł muszą wskazywać różne pola.")
        if self.sekcje and not all(
            (
                self.lista_elementow,
                self.typ_elementu,
                self.tresc_elementu,
                self.adres_elementu,
                self.typ_tekstu,
                self.typ_obrazu,
            )
        ):
            raise blad("Uzupełnij mapowanie struktury sekcji albo pomiń pole sekcji.")
        if self.sekcje and self.typ_tekstu == self.typ_obrazu:
            raise blad("Typ tekstu i obrazu muszą być różne.")


@dataclass(frozen=True)
class ProfilWPaczce:
    plik: str
    profil: ProfilPaczki


@dataclass(frozen=True)
class PaczkaOfert:
    nazwa: str
    pliki: tuple[PlikPaczki, ...]
    zbiory: tuple[ZbiorPaczki, ...]
    profile: tuple[ProfilWPaczce, ...] = ()
    bledy_profili: tuple[str, ...] = ()


@dataclass(frozen=True)
class ElementPodgladu:
    typ: str
    tekst: str = ""
    adres: str = ""


@dataclass(frozen=True)
class OfertaPodglad:
    numer: int
    sku: str
    tytul: str
    opis: str
    ean: str
    cena: str
    dopasowanie_tekst: str
    zdjecia: tuple[str, ...]
    sekcje: tuple[tuple[ElementPodgladu, ...], ...]
    problemy: tuple[str, ...]


class CzytnikPaczki(Protocol):
    def odczytaj(self, plik: Path) -> PaczkaOfert: ...


class PlikiProfili(Protocol):
    def odczytaj(self, plik: Path) -> ProfilPaczki: ...
    def zapisz(self, plik: Path, profil: ProfilPaczki) -> None: ...


@dataclass(frozen=True)
class ZapamietanyProfil:
    profil: ProfilPaczki
    pola: tuple[str, ...]
    ksztalt_sekcji: tuple[tuple[str, ...], ...]


class PamiecProfili(Protocol):
    def lista(self) -> tuple[ZapamietanyProfil, ...]: ...
    def zapisz(self, profil: ZapamietanyProfil) -> None: ...
    def usun(self, profil: ZapamietanyProfil) -> None: ...


@dataclass(frozen=True)
class WynikPodgladu:
    oferty: tuple[OfertaPodglad, ...]
    informacja: str = ""


class PodgladPaczek:
    def __init__(
        self, czytnik: CzytnikPaczki, profile: PlikiProfili, pamiec: PamiecProfili | None = None
    ) -> None:
        self.czytnik = czytnik
        self.profile = profile
        self.pamiec = pamiec

    def odczytaj(self, plik: Path) -> PaczkaOfert:
        return self.czytnik.odczytaj(plik)

    def wczytaj_profil(self, plik: Path) -> ProfilPaczki:
        return self.profile.odczytaj(plik)

    def zapisz_profil(self, plik: Path, profil: ProfilPaczki) -> None:
        profil.sprawdz()
        self.profile.zapisz(plik, profil)

    @staticmethod
    def _ksztalt(zbior: ZbiorPaczki, profil: ProfilPaczki) -> tuple[tuple[str, ...], ...] | None:
        if not profil.sekcje:
            return ()
        wynik: set[tuple[str, ...]] = set()
        for rekord in zbior.rekordy:
            sekcje = rekord.get(profil.sekcje, [])
            if not isinstance(sekcje, list):
                return None
            for sekcja in sekcje:
                if not isinstance(sekcja, dict):
                    return None
                wynik.add(("sekcja", *sorted(sekcja)))
                elementy = sekcja.get(profil.lista_elementow)
                if not isinstance(elementy, list):
                    return None
                for element in elementy:
                    if not isinstance(element, dict):
                        return None
                    typ = element.get(profil.typ_elementu)
                    if not isinstance(typ, str) or typ not in (
                        profil.typ_tekstu,
                        profil.typ_obrazu,
                    ):
                        return None
                    wynik.add(("element", *sorted(element)))
                    wynik.add(("typ", typ))
        return tuple(sorted(wynik))

    def rozpoznaj(self, paczka: PaczkaOfert) -> tuple[ProfilPaczki, ...]:
        wynik = []
        if self.pamiec is not None:
            for zapis in self.pamiec.lista():
                for zbior in paczka.zbiory:
                    if zbior.pola != zapis.pola or not zbior.rekordy:
                        continue
                    profil = replace(zapis.profil, plik=zbior.nazwa)
                    if self._ksztalt(zbior, profil) == zapis.ksztalt_sekcji:
                        wynik.append(profil)
        if wynik:
            return tuple(dict.fromkeys(wynik))
        # Jawnie obsługiwany kontrakt gotowych ofert, nie zgadywanie po marce,
        # nazwie pliku, SKU, treści instrukcji ani danych pomocniczych w ZIP.
        wymagane = {"sku", "title", "html", "images", "sections"}
        for zbior in paczka.zbiory:
            if not zbior.rekordy or not wymagane.issubset(zbior.pola):
                continue
            wynik.append(
                ProfilPaczki(
                    nazwa="Gotowe oferty JSON",
                    plik=zbior.nazwa,
                    sku="sku",
                    tytul="title",
                    opis="html",
                    sekcje="sections",
                    zdjecia="images",
                    ean="ean" if "ean" in zbior.pola else "",
                    cena="price" if "price" in zbior.pola else "",
                    dopasowanie_tekst="fit" if "fit" in zbior.pola else "",
                    lista_elementow="items",
                    typ_elementu="type",
                    tresc_elementu="content",
                    adres_elementu="url",
                    typ_tekstu="TEXT",
                    typ_obrazu="IMAGE",
                )
            )
        return tuple(wynik)

    def podglad_z_pamiecia(self, paczka: PaczkaOfert, profil: ProfilPaczki) -> WynikPodgladu:
        oferty = self.przygotuj(paczka, profil)
        if self.pamiec is None:
            return WynikPodgladu(oferty)
        zbior = next(z for z in paczka.zbiory if z.nazwa == profil.plik)
        ksztalt = self._ksztalt(zbior, profil)
        if ksztalt is None or not any(o.sku and o.tytul for o in oferty):
            return WynikPodgladu(
                oferty, "Nie zapamiętano układu: sprawdź strukturę i dane w podglądzie."
            )
        try:
            self.pamiec.zapisz(ZapamietanyProfil(profil, zbior.pola, ksztalt))
        except (BladScenariuszaKatalogu, BladTechniczny) as exc:
            return WynikPodgladu(
                oferty, "Oferty odczytane, ale nie udało się zapamiętać układu: " + str(exc)
            )
        return WynikPodgladu(
            oferty,
            f"Zapamiętany układ: {profil.nazwa}. "
            "Kolejne paczki o tej strukturze nie potrzebują pliku profilu.",
        )

    def zapomnij(self, paczka: PaczkaOfert, profil: ProfilPaczki) -> None:
        if self.pamiec is None:
            raise blad("Pamięć profili nie jest skonfigurowana.")
        zbior = next((z for z in paczka.zbiory if z.nazwa == profil.plik), None)
        if zbior is None:
            raise blad("Nie znaleziono danych tego układu.")
        ksztalt = self._ksztalt(zbior, profil)
        if ksztalt is None:
            raise blad("Struktura paczki nie odpowiada zapamiętanemu układowi.")
        self.pamiec.usun(ZapamietanyProfil(profil, zbior.pola, ksztalt))

    def przygotuj(self, paczka: PaczkaOfert, profil: ProfilPaczki) -> tuple[OfertaPodglad, ...]:
        profil.sprawdz()
        zbior = next((z for z in paczka.zbiory if z.nazwa == profil.plik), None)
        if zbior is None:
            raise blad("Paczka nie zawiera pliku danych wybranego w profilu. Sprawdź konfigurację.")
        pola = (
            profil.sku,
            profil.tytul,
            profil.opis,
            profil.sekcje,
            profil.zdjecia,
            profil.ean,
            profil.cena,
            profil.dopasowanie_tekst,
        )
        if any(p and p not in zbior.pola for p in pola):
            raise blad("Wybrany plik nie zawiera wszystkich pól profilu. Popraw mapowanie.")
        liczby = Counter(str(r.get(profil.sku, "")).strip().casefold() for r in zbior.rekordy)
        wynik = []
        for numer, rekord in enumerate(zbior.rekordy, 1):
            problemy: list[str] = [
                f"Brak pola {p} w rekordzie" for p in pola if p and p not in rekord
            ]

            def tekst(
                klucz: str, wiersz: Mapping[str, object] = rekord, bledy: list[str] = problemy
            ) -> str:
                if not klucz:
                    return ""
                wartosc = wiersz.get(klucz, "")
                if isinstance(wartosc, str):
                    return wartosc
                if klucz == profil.cena and type(wartosc) in (int, float):
                    return str(wartosc)
                if wartosc is None:
                    return ""
                bledy.append(f"Pole {klucz}: oczekiwano tekstu")
                return ""

            sku, tytul = tekst(profil.sku).strip(), tekst(profil.tytul).strip()
            if not sku:
                problemy.append("Brak tekstowego SKU — wymagane rozstrzygnięcie powiązania")
            elif liczby[sku.casefold()] > 1:
                problemy.append("Powtórzone SKU w pliku — nie scalono ofert")
            if not tytul:
                problemy.append("Brak tytułu")
            zdjecia: list[str] = []
            if profil.zdjecia:
                lista = rekord.get(profil.zdjecia, [])
                if not isinstance(lista, list):
                    problemy.append("Galeria nie jest listą adresów")
                else:
                    for adres in lista:
                        if isinstance(adres, str) and adres.startswith("https://"):
                            zdjecia.append(adres)
                        else:
                            problemy.append("Nieobsługiwany adres zdjęcia (wymagane HTTPS)")
            sekcje: list[tuple[ElementPodgladu, ...]] = []
            if profil.sekcje:
                lista = rekord.get(profil.sekcje, [])
                if not isinstance(lista, list):
                    problemy.append("Sekcje nie są listą")
                else:
                    for nr, sekcja in enumerate(lista, 1):
                        elementy: list[ElementPodgladu] = []
                        items = (
                            sekcja.get(profil.lista_elementow) if isinstance(sekcja, dict) else None
                        )
                        if not isinstance(items, list) or not items:
                            problemy.append(f"Sekcja {nr}: brak listy elementów")
                        else:
                            for item in items:
                                if not isinstance(item, dict):
                                    problemy.append(f"Sekcja {nr}: nieprawidłowy element")
                                    continue
                                typ = item.get(profil.typ_elementu)
                                if typ == profil.typ_tekstu and isinstance(
                                    item.get(profil.tresc_elementu), str
                                ):
                                    elementy.append(
                                        ElementPodgladu("tekst", tekst=item[profil.tresc_elementu])
                                    )
                                elif (
                                    typ == profil.typ_obrazu
                                    and isinstance(item.get(profil.adres_elementu), str)
                                    and item[profil.adres_elementu].startswith("https://")
                                ):
                                    elementy.append(
                                        ElementPodgladu("obraz", adres=item[profil.adres_elementu])
                                    )
                                else:
                                    problemy.append(
                                        f"Sekcja {nr}: nieobsługiwany typ lub zawartość elementu"
                                    )
                        sekcje.append(tuple(elementy))
            wynik.append(
                OfertaPodglad(
                    numer,
                    sku,
                    tytul,
                    tekst(profil.opis),
                    tekst(profil.ean),
                    tekst(profil.cena),
                    tekst(profil.dopasowanie_tekst),
                    tuple(zdjecia),
                    tuple(sekcje),
                    tuple(dict.fromkeys(problemy)),
                )
            )
        return tuple(wynik)
