"""Edycja istniejącej galerii, bez zależności od GUI i przechowywania."""

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from uuid import UUID

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.media import ZdjecieDane


@dataclass(frozen=True)
class GaleriaDTO:
    produkt_id: UUID
    wersja: int
    zdjecia: tuple[ZdjecieDane, ...]


class RepozytoriumGalerii(Protocol):
    def odczytaj_galerie(self, produkt_id: UUID) -> GaleriaDTO: ...
    def zapisz_galerie(self, galeria: GaleriaDTO) -> Path: ...


class PlikiZdjec(Protocol):
    def odczytaj(self, pliki: tuple[Path, ...]) -> tuple[ZdjecieDane, ...]: ...


class GaleriaProduktow:
    def __init__(self, repo: RepozytoriumGalerii, pliki: PlikiZdjec) -> None:
        self.repo = repo
        self.pliki = pliki

    def odczytaj(self, produkt_id: UUID) -> GaleriaDTO:
        return self.repo.odczytaj_galerie(produkt_id)

    def wczytaj_pliki(self, pliki: tuple[Path, ...]) -> tuple[ZdjecieDane, ...]:
        if not 1 <= len(pliki) <= 5:
            raise BladScenariuszaKatalogu("MEDIA", "Wybierz od 1 do 5 zdjęć.")
        return self.pliki.odczytaj(pliki)

    def zapisz(self, galeria: GaleriaDTO) -> Path:
        if len(galeria.zdjecia) > 5:
            raise BladScenariuszaKatalogu("MEDIA", "Galeria mieści maksymalnie 5 zdjęć.")
        return self.repo.zapisz_galerie(galeria)
