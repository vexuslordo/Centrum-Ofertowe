"""Orkiestracja i porty; bez zależności od Qt, SQL i implementacji adapterów."""
