"""Potwierdzany częściowy zapis; trwała blokada nieznanego wyniku bez ponowień."""

import json
from dataclasses import dataclass
from hashlib import sha256
from typing import Protocol

from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    CzasMonotoniczny,
    SesjaAllegro,
    SzczegolySzkicuAllegro,
)
from vexlab.przypadki_uzycia.propozycje_szkicow import PropozycjaSzkicu, PropozycjeSzkicow


def pola_zapisu(p: PropozycjaSzkicu) -> dict[str, object]:
    p.sprawdz()
    pola: dict[str, object] = {}
    if p.tytul != p.tytul_bazowy:
        if not 12 <= len(p.tytul) <= 75 or len(p.tytul.split()) < 3:
            raise BladAllegro("TYTUL", "Tytuł Allegro wymaga 12–75 znaków i co najmniej 3 słów.")
        pola["name"] = p.tytul
    if p.sekcje != p.sekcje_bazowe:
        opis = {
            "sections": [
                {
                    "items": [
                        {"type": "TEXT", "content": e.tekst}
                        if e.typ == "tekst"
                        else {"type": "IMAGE", "url": e.adres}
                        for e in sekcja
                    ]
                }
                for sekcja in p.sekcje
            ]
        }
        if len(json.dumps(opis, ensure_ascii=False).encode("utf-8")) > 40000:
            raise BladAllegro("OPIS", "Opis Allegro przekracza limit 40 000 bajtów.")
        pola["description"] = opis
    if not pola:
        raise BladAllegro("BRAK_ZMIAN", "Nie zmieniono tytułu ani opisu.")
    return pola


def klucz(p: PropozycjaSzkicu) -> str:
    return sha256(json.dumps([p.srodowisko.value, p.konto_id, p.oferta_id]).encode()).hexdigest()


def odcisk(tytul: str, sekcje: object) -> str:
    return sha256(repr((tytul, sekcje)).encode()).hexdigest()


@dataclass(frozen=True)
class ProbaZapisu:
    cel: str
    operacja: str = ""


@dataclass(frozen=True)
class PrzyjecieZapisu:
    operacja: str = ""


class RejestrZapisow(Protocol):
    def odczytaj(self, klucz: str) -> ProbaZapisu | None: ...
    def rozpocznij(self, klucz: str, proba: ProbaZapisu) -> None: ...
    def operacja(self, klucz: str, proba: ProbaZapisu) -> None: ...
    def zakoncz(self, klucz: str) -> None: ...


class APIZapisuSzkicu(Protocol):
    def szkic(self, sesja: SesjaAllegro, ident: str) -> SzczegolySzkicuAllegro: ...
    def zmien_szkic(
        self, sesja: SesjaAllegro, ident: str, pola: dict[str, object]
    ) -> PrzyjecieZapisu: ...
    def operacja_szkicu(self, sesja: SesjaAllegro, ident: str, operacja: str) -> bool: ...


class ZapiszSzkicAllegro:
    def __init__(
        self, api: APIZapisuSzkicu, rejestr: RejestrZapisow, czas: CzasMonotoniczny
    ) -> None:
        self.api, self.rejestr, self.czas = api, rejestr, czas

    def _kontekst(self, s: SesjaAllegro, p: PropozycjaSzkicu) -> None:
        p.sprawdz()
        if self.czas.teraz() >= s.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        if (s.konto.id, s.srodowisko) != (p.konto_id, p.srodowisko):
            raise BladAllegro("KONTO", "Połącz właściwe konto i środowisko szkicu.")

    def zapisz(self, s: SesjaAllegro, p: PropozycjaSzkicu) -> SzczegolySzkicuAllegro:
        self._kontekst(s, p)
        if s.aplikacja is not None and not s.aplikacja.zapis_szkicow:
            raise BladAllegro(
                "UPRAWNIENIA",
                "W Ustawieniach Allegro zaznacz zgodę na zapis szkiców i połącz konto ponownie.",
            )
        pola = pola_zapisu(p)
        k = klucz(p)
        if self.rejestr.odczytaj(k) is not None:
            raise BladAllegro(
                "NIEZNANY", "Poprzedni zapis wymaga sprawdzenia wyniku. Nie wysłano ponownie."
            )
        proba = ProbaZapisu(odcisk(p.tytul, p.sekcje))
        # Rezerwacja PRZED preflight: drugi proces musi odczytać świeży stan
        # dopiero po zdobyciu własnej rezerwacji, nigdy wysłać wcześniejszego snapshotu.
        self.rejestr.rozpocznij(k, proba)
        try:
            aktualny = self.api.szkic(s, p.oferta_id)
            PropozycjeSzkicow.sprawdz_aktualnosc(p, aktualny)
            self._kontekst(s, p)
        except BladAllegro:
            # PATCH jeszcze nie wysłano, więc wynik jest jednoznaczny.
            self.rejestr.zakoncz(k)
            raise
        try:
            wynik = self.api.zmien_szkic(s, p.oferta_id, pola)
        except BladAllegro as exc:
            if exc.kod == "ODRZUCONO":
                self.rejestr.zakoncz(k)
            raise
        if wynik.operacja:
            self.rejestr.operacja(k, ProbaZapisu(proba.cel, wynik.operacja))
            raise BladAllegro(
                "PRZETWARZANIE",
                "Allegro przyjęło zapis. Sprawdź wynik później; nie wysyłaj ponownie.",
            )
        return self.sprawdz(s, p)

    def sprawdz(self, s: SesjaAllegro, p: PropozycjaSzkicu) -> SzczegolySzkicuAllegro:
        self._kontekst(s, p)
        k = klucz(p)
        proba = self.rejestr.odczytaj(k)
        if proba is None:
            raise BladAllegro("BRAK_PROBY", "Brak rozpoczętego zapisu do sprawdzenia.")
        if proba.operacja and not self.api.operacja_szkicu(s, p.oferta_id, proba.operacja):
            raise BladAllegro(
                "PRZETWARZANIE", "Allegro nadal przetwarza zapis. Sprawdź wynik później."
            )
        aktualny = self.api.szkic(s, p.oferta_id)
        if odcisk(aktualny.tytul, aktualny.sekcje) != proba.cel:
            raise BladAllegro(
                "NIEZNANY",
                "Odczyt nie potwierdza pełnych zmian. Zachowano blokadę ponownego "
                "zapisu i propozycję.",
            )
        self.rejestr.zakoncz(k)
        return aktualny
