"""Plan i atomowy zapis lokalnych szkiców z paczki; żadnej publikacji."""

import re
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Protocol
from uuid import UUID, uuid4

from vexlab.domena.oferta import SzkicOferty
from vexlab.domena.produkt import BladKatalogu
from vexlab.przypadki_uzycia.importowanie import blad
from vexlab.przypadki_uzycia.katalog import _mapuj_bledy
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad


@dataclass(frozen=True)
class PlanSzkicow:
    zrodlo: str
    pozycje: tuple[OfertaPodglad, ...]
    bledy: tuple[str, ...]


@dataclass(frozen=True)
class SzkicDTO:
    id: UUID
    produkt_id: UUID | None
    wersja_produktu: int | None
    wersja: int
    oferta: OfertaPodglad
    zrodlo: str
    zrodlo_zmienione: bool


@dataclass(frozen=True)
class WynikSzkicow:
    zapisane: int
    pominiete: int
    kopia: Path


class MagazynSzkicow(Protocol):
    def zapisz_paczke(self, plan: PlanSzkicow) -> WynikSzkicow: ...
    def lista(self) -> tuple[SzkicDTO, ...]: ...
    def edytuj(self, szkic: SzkicOferty, oferta: OfertaPodglad | None = None) -> None: ...
    def usun(self, id: UUID, wersja: int) -> Path: ...
    def usun_wiele(self, szkice: tuple[tuple[UUID, int], ...]) -> Path: ...


class SzkiceOfert:
    def __init__(self, magazyn: MagazynSzkicow) -> None:
        self.magazyn = magazyn

    @staticmethod
    def _sprawdz(o: OfertaPodglad) -> None:
        if o.problemy:
            raise ValueError("; ".join(o.problemy))
        if not o.sku.strip():
            raise ValueError("Brak SKU")
        SzkicOferty(uuid4(), None, None, o.tytul, o.opis)

    def zaplanuj(self, oferty: tuple[OfertaPodglad, ...], zrodlo: str) -> PlanSzkicow:
        pozycje, bledy = [], []
        for o in oferty:
            try:
                self._sprawdz(o)
                pozycje.append(o)
            except ValueError as exc:
                bledy.append(f"Wiersz {o.numer}, SKU {o.sku}: {exc}")
        return PlanSzkicow(zrodlo, tuple(pozycje), tuple(bledy))

    def zapisz(self, plan: PlanSzkicow) -> WynikSzkicow:
        if not plan.pozycje:
            raise blad("Brak prawidłowych ofert do zapisania.")
        try:
            for o in plan.pozycje:
                self._sprawdz(o)
        except ValueError as exc:
            raise blad(str(exc)) from exc
        with _mapuj_bledy():
            return self.magazyn.zapisz_paczke(plan)

    def lista(self) -> tuple[SzkicDTO, ...]:
        return self.magazyn.lista()

    def edytuj(
        self,
        dto: SzkicDTO,
        tytul: str,
        opis: str,
        sekcje: tuple[tuple[ElementPodgladu, ...], ...] | None = None,
    ) -> None:
        try:
            s = SzkicOferty(
                dto.id,
                dto.produkt_id,
                dto.wersja_produktu,
                dto.oferta.tytul,
                dto.oferta.opis,
                dto.wersja,
            ).zmien(tytul, opis)
        except (ValueError, BladKatalogu) as exc:
            raise blad(str(exc)) from exc
        nowe_sekcje = dto.oferta.sekcje if sekcje is None else sekcje
        for sekcja in nowe_sekcje:
            if not sekcja:
                raise blad("Sekcja musi zawierać tekst lub zdjęcie.")
            for element in sekcja:
                if element.typ not in {"tekst", "obraz"}:
                    raise blad("Nieobsługiwany rodzaj elementu opisu.")
                if element.typ == "obraz" and (
                    re.fullmatch(r"https://[^/?#@\s\\]+(?:[/?#][^\s\\]*)?", element.adres) is None
                ):
                    raise blad("Podaj pełny adres HTTPS zdjęcia bez loginu i hasła.")
        self.magazyn.edytuj(s, replace(dto.oferta, tytul=s.tytul, opis=s.opis, sekcje=nowe_sekcje))

    def usun(self, dto: SzkicDTO) -> Path:
        return self.magazyn.usun(dto.id, dto.wersja)

    def usun_wiele(self, szkice: tuple[SzkicDTO, ...]) -> Path:
        if not szkice or len({s.id for s in szkice}) != len(szkice):
            raise blad("Zaznacz szkice do usunięcia bez powtarzania wpisów.")
        return self.magazyn.usun_wiele(tuple((s.id, s.wersja) for s in szkice))
