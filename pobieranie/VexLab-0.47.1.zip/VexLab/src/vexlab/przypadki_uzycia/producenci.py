"""Scenariusze lokalnego rejestru Producentów i porty, bez SQL i Qt."""

from dataclasses import dataclass
from typing import Protocol
from uuid import UUID, uuid4

from vexlab.domena.producent import NieprawidlowyProducent, Producent
from vexlab.domena.produkt import KonfliktEdycji
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu


@dataclass(frozen=True)
class ProducentDTO:
    id: UUID
    nazwa: str
    aktywny: bool
    wersja: int
    strona_www: str = ""


@dataclass(frozen=True)
class DaneProducenta:
    nazwa: str
    aktywny: bool = True
    strona_www: str = ""


class RepozytoriumProducentow(Protocol):
    def lista_producentow(self) -> list[Producent]: ...

    def pobierz_producenta(self, id_producenta: UUID) -> Producent | None: ...

    def dodaj_producenta(self, producent: Producent) -> None: ...

    def zapisz_producenta(self, producent: Producent, oczekiwana_wersja: int) -> None: ...


def producent_dto(producent: Producent) -> ProducentDTO:
    return ProducentDTO(
        producent.id, producent.nazwa, producent.aktywny, producent.wersja, producent.strona_www
    )


class RejestrProducentow:
    def __init__(self, repozytorium: RepozytoriumProducentow) -> None:
        self._repozytorium = repozytorium

    def lista(self) -> list[ProducentDTO]:
        return [producent_dto(p) for p in self._repozytorium.lista_producentow()]

    def dodaj(self, dane: DaneProducenta) -> ProducentDTO:
        try:
            producent = Producent(
                uuid4(), dane.nazwa.strip(), dane.aktywny, strona_www=dane.strona_www.strip()
            )
        except NieprawidlowyProducent as blad:
            raise BladScenariuszaKatalogu("WALIDACJA_PRODUCENTA", str(blad)) from blad
        self._repozytorium.dodaj_producenta(producent)
        return producent_dto(producent)

    def edytuj(self, id_producenta: UUID, wersja: int, dane: DaneProducenta) -> ProducentDTO:
        producent = self._repozytorium.pobierz_producenta(id_producenta)
        if producent is None:
            raise BladScenariuszaKatalogu(
                "PRODUCENT_NIE_ISTNIEJE", "Producent nie istnieje. Odśwież listę."
            )
        if producent.wersja != wersja:
            raise BladScenariuszaKatalogu(
                "KONFLIKT_WERSJI", "Producent zmienił się w innym formularzu. Odśwież dane."
            )
        try:
            nowy = producent.zmien(dane.nazwa.strip(), dane.aktywny, dane.strona_www.strip())
            self._repozytorium.zapisz_producenta(nowy, wersja)
        except NieprawidlowyProducent as blad:
            raise BladScenariuszaKatalogu("WALIDACJA_PRODUCENTA", str(blad)) from blad
        except KonfliktEdycji as blad:
            raise BladScenariuszaKatalogu("KONFLIKT_WERSJI", str(blad)) from blad
        return producent_dto(nowy)
