"""Eksport jawnego zestawu danych, niezależny od Qt i formatu pliku."""

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import ProduktDTO


@dataclass(frozen=True)
class WynikEksportu:
    produkty: int
    zabezpieczone_pola: int = 0


class ZapisEksportu(Protocol):
    def zapisz(self, cel: Path, produkty: tuple[ProduktDTO, ...]) -> WynikEksportu: ...


class EksportujKatalog:
    def __init__(self, zapis: ZapisEksportu) -> None:
        self._zapis = zapis

    def wykonaj(self, cel: Path, produkty: tuple[ProduktDTO, ...]) -> WynikEksportu:
        if not produkty:
            raise BladScenariuszaKatalogu("BRAK_DANYCH", "Brak produktów do eksportu.")
        return self._zapis.zapisz(cel, produkty)
