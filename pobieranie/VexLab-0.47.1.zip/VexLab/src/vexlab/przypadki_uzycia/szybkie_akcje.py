"""Dostępne polecenia nawigacji; wybór i kolejność należą do użytkownika."""

from dataclasses import dataclass


@dataclass(frozen=True)
class SzybkaAkcja:
    id: str
    nazwa: str
    cel: str
    dostepna: bool = True


AKCJE = (
    SzybkaAkcja("cenniki", "Cenniki", "Cenniki"),
    SzybkaAkcja("masowa", "Edycja masowa", "Masowa edycja"),
    SzybkaAkcja("ai", "AI — opisy produktów", "Kreator opisów (AI)", False),
    SzybkaAkcja("kopiuj_uklad", "Kopiuj układ ofert", "Szablony układów", False),
    SzybkaAkcja("szablony", "Kreator szablonów", "Szablony układów", False),
    SzybkaAkcja("bledy", "Błędy importu", "korekty"),
    SzybkaAkcja("produkty", "Produkty", "Produkty"),
    SzybkaAkcja("nowe_oferty", "Nowe oferty", "Nowe oferty"),
    SzybkaAkcja("szkice", "Szkice ofert", "Szkice"),
    SzybkaAkcja("media", "Zdjęcia i media", "Zdjęcia i media"),
    SzybkaAkcja("producenci", "Producenci", "Producenci"),
    SzybkaAkcja("ustawienia", "Ustawienia", "Ustawienia"),
)
DOMYSLNE_AKCJE = tuple(a.id for a in AKCJE[:6])


def sprawdz_akcje(akcje: tuple[str, ...]) -> None:
    dozwolone = {a.id for a in AKCJE}
    if len(set(akcje)) != len(akcje) or any(a not in dozwolone for a in akcje):
        raise ValueError("Wybierz różne skróty z dostępnej listy.")
