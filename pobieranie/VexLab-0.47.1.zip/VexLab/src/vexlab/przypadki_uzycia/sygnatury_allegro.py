"""Potwierdzana naprawa wyłącznie sygnatur własnych zarejestrowanych szkiców."""

from dataclasses import replace
from typing import Protocol

from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.nowe_szkice_allegro import (
    NoweSzkiceAllegro,
    ProbaTworzenia,
    WynikTworzenia,
    odcisk_zdalny,
    skrot,
)
from vexlab.przypadki_uzycia.zapis_szkicu_allegro import PrzyjecieZapisu


class APISygnatur(Protocol):
    def zmien_szkic(
        self, sesja: SesjaAllegro, ident: str, pola: dict[str, object]
    ) -> PrzyjecieZapisu: ...


def napraw_sygnature(
    serwis: NoweSzkiceAllegro, api: APISygnatur, s: SesjaAllegro, sku: str
) -> WynikTworzenia:
    serwis._sesja(s)
    if not s.aplikacja or not s.aplikacja.zapis_szkicow:
        raise BladAllegro("UPRAWNIENIA", "Wymagana zgoda na zapis szkiców.")
    if not sku.strip() or len(sku.strip()) > 100:
        raise BladAllegro("SKU", "Niepoprawny SKU do sygnatury.")
    key = serwis.klucz(s, sku)
    record = serwis.rejestr.odczytaj(key)
    if record is None or not record.ident or record.status not in {201, 202}:
        return WynikTworzenia(
            sku, "Pominięto", "Brak potwierdzonego szkicu utworzonego przez VexLab."
        )
    if record.operacja and not serwis.api.operacja_tworzenia(s, record.ident, record.operacja):
        return WynikTworzenia(
            sku, "Przetwarzanie", "Sprawdź po zakończeniu tworzenia.", record.ident
        )
    patchkey = skrot(["sygnatura", key])
    attempt = serwis.rejestr.odczytaj(patchkey)
    if (
        attempt
        and attempt.operacja
        and not serwis.api.operacja_tworzenia(s, record.ident, attempt.operacja)
    ):
        return WynikTworzenia(
            sku, "Przetwarzanie", "Trwa zmiana sygnatury; nie ponawiaj.", record.ident
        )
    d = serwis.api.odczytaj_szkic(s, record.ident)
    publication = d.get("publication")
    if not isinstance(publication, dict) or publication.get("status") != "INACTIVE":
        raise BladAllegro("STAN", "Sygnatury poprawiamy tylko we własnych szkicach INACTIVE.")
    ext = d.get("external")
    external = ext.get("id") if isinstance(ext, dict) else None
    if external not in {"vexlab-" + key, sku.strip()}:
        raise BladAllegro("KONFLIKT", "Szkic ma inną sygnaturę. Nie zmieniono oferty.")
    if attempt:
        if external == sku.strip() and any(
            odcisk_zdalny(d, mode) == attempt.tresc for mode in (False, True)
        ):
            serwis.rejestr.zapisz(key, replace(record, tresc=attempt.tresc))
            return WynikTworzenia(
                sku,
                "Sygnatura poprawiona",
                "Potwierdzono odczytem SKU jako sygnaturę.",
                record.ident,
            )
        return WynikTworzenia(
            sku, "Wynik nieznany", "Nie potwierdzono sygnatury. Nie ponawiaj PATCH.", record.ident
        )
    if external == sku.strip():
        return WynikTworzenia(
            sku, "Sygnatura poprawna", "Sygnatura już jest kodem SKU.", record.ident
        )
    mode = next((m for m in (False, True) if odcisk_zdalny(d, m) == record.tresc), None)
    if mode is None:
        raise BladAllegro(
            "KONFLIKT", "Treść szkicu zmieniła się od tworzenia. Nie zmieniono sygnatury."
        )
    expected = {**d, "external": {"id": sku.strip()}}
    attempt = ProbaTworzenia(record.tresc, odcisk_zdalny(expected, mode), ident=record.ident)
    serwis.rejestr.rozpocznij(patchkey, attempt)
    serwis._sesja(s)
    try:
        response = api.zmien_szkic(s, record.ident, {"external": {"id": sku.strip()}})
    except BladAllegro as exc:
        if exc.kod == "ODRZUCONO":
            serwis.rejestr.usun(patchkey)
        raise
    serwis.rejestr.zapisz(
        patchkey,
        replace(attempt, status=202 if response.operacja else 201, operacja=response.operacja),
    )
    if response.operacja:
        return WynikTworzenia(
            sku,
            "Przetwarzanie",
            "Sprawdź sygnatury ponownie po zakończeniu operacji.",
            record.ident,
        )
    return napraw_sygnature(serwis, api, s, sku)
