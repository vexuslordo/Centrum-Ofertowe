"""Ustawienia odczytu tabel; bez danych produktów, zapisu cennika i I/O w regułach."""

import unicodedata
from dataclasses import dataclass, replace
from typing import Protocol
from uuid import UUID, uuid4

from vexlab.przypadki_uzycia.importowanie import (
    Komorka,
    Mapowanie,
    PlikImportu,
    blad,
    sprawdz_mapowanie,
)
from vexlab.rdzen.kontrakty import BladTechniczny


def normalizuj(tekst: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", tekst).casefold().split())


@dataclass(frozen=True)
class ProfilCennika:
    id: UUID
    nazwa: str
    naglowki: tuple[str, ...]
    mapa: Mapowanie
    producent_id: UUID | None

    def sprawdz(self) -> None:
        if (
            not self.nazwa.strip()
            or len(self.nazwa) > 100
            or not 1 <= len(self.naglowki) <= 256
            or not any(self.naglowki)
            or any(len(x) > 500 or x != normalizuj(x) for x in self.naglowki)
            or not 1 <= self.mapa.naglowek <= 20000
        ):
            raise blad("Nieprawidłowy profil cennika.")
        sprawdz_mapowanie(self.mapa, tuple(Komorka(x) for x in self.naglowki))
        if self.mapa.cena and self.mapa.cena.zapisane_formuly:
            raise blad("Zgoda na zapisane wyniki formuł dotyczy pojedynczego pliku, nie profilu.")


class MagazynProfiliCennikow(Protocol):
    def lista(self) -> tuple[ProfilCennika, ...]: ...
    def dodaj(self, profil: ProfilCennika) -> None: ...
    def usun(self, profil: ProfilCennika) -> None: ...


@dataclass(frozen=True)
class DopasowanieCennika:
    arkusz: int
    mapa: Mapowanie
    profil: ProfilCennika | None = None


@dataclass(frozen=True)
class RozpoznanieCennika:
    zgodne: tuple[DopasowanieCennika, ...] = ()
    propozycja: DopasowanieCennika | None = None
    problem: str = ""


# Wyłącznie ogólne nagłówki, bez producentów i nazw plików.
ALIASY = {
    "nazwa": {"nazwa", "nazwa produktu", "produkt", "title", "product name", "name"},
    "sku": {"sku", "kod", "kod produktu", "symbol", "product code", "part number"},
    "ean": {"ean", "ean13", "ean-13", "ean8", "ean-8", "gtin"},
    "opis": {"opis", "opis produktu", "description"},
}


def propozycja(plik: PlikImportu) -> DopasowanieCennika | None:
    kandydaci = []
    for ai, arkusz in enumerate(plik.arkusze):
        for numer, cells in arkusz.wiersze[:30]:
            naglowki = tuple(normalizuj(c.tekst) for c in cells)
            pola = {}
            for pole, aliasy in ALIASY.items():
                indeksy = [i for i, x in enumerate(naglowki) if x in aliasy]
                pola[pole] = indeksy[0] if len(indeksy) == 1 else None
            if pola["nazwa"] is not None and pola["sku"] is not None:
                mapa = Mapowanie(numer, pola["nazwa"], pola["sku"], pola["opis"], ean=pola["ean"])
                kandydaci.append(DopasowanieCennika(ai, mapa))
    return kandydaci[0] if len(kandydaci) == 1 else None


class ProfileCennikow:
    def __init__(self, magazyn: MagazynProfiliCennikow) -> None:
        self.magazyn = magazyn

    def rozpoznaj(self, plik: PlikImportu) -> RozpoznanieCennika:
        try:
            profile = self.magazyn.lista()
        except BladTechniczny as exc:
            return RozpoznanieCennika(problem=str(exc))
        wzorce: dict[tuple[str, ...], list[ProfilCennika]] = {}
        for p in profile:
            p.sprawdz()
            wzorce.setdefault(p.naglowki, []).append(p)
        zgodne = []
        for ai, arkusz in enumerate(plik.arkusze):
            for numer, cells in arkusz.wiersze:
                naglowki = tuple(normalizuj(c.tekst) for c in cells)
                for p in wzorce.get(naglowki, ()):
                    zgodne.append(DopasowanieCennika(ai, replace(p.mapa, naglowek=numer), p))
                    if len(zgodne) > 200:
                        return RozpoznanieCennika(
                            problem=("Zbyt wiele zgodnych układów. Ustaw arkusz i kolumny ręcznie.")
                        )
        return RozpoznanieCennika(tuple(zgodne), propozycja(plik) if not zgodne else None)

    def zapisz(
        self,
        plik: PlikImportu,
        arkusz: int,
        mapa: Mapowanie,
        producent_id: UUID | None,
        nazwa: str,
    ) -> ProfilCennika:
        if not 0 <= arkusz < len(plik.arkusze):
            raise blad("Wybierz arkusz do zapamiętania.")
        cells = dict(plik.arkusze[arkusz].wiersze).get(mapa.naglowek, ())
        # Zgoda na potencjalnie stare cache Excela musi być ponawiana dla każdego pliku.
        mapa = replace(mapa, cena=replace(mapa.cena, zapisane_formuly=False) if mapa.cena else None)
        p = ProfilCennika(
            uuid4(),
            nazwa.strip(),
            tuple(normalizuj(c.tekst) for c in cells),
            mapa,
            producent_id,
        )
        p.sprawdz()
        for zapisany in self.magazyn.lista():
            if replace(zapisany, id=p.id, mapa=replace(zapisany.mapa, naglowek=mapa.naglowek)) == p:
                return zapisany
        self.magazyn.dodaj(p)
        return p

    def usun(self, profil: ProfilCennika) -> None:
        self.magazyn.usun(profil)
