"""Lokalna diagnostyka instalacji; bez konfiguracji ani połączenia z bazą GT."""

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Protocol

from vexlab.rdzen.kontrakty import BladTechniczny, Zegar


@dataclass(frozen=True)
class InstalacjaGT:
    nazwa: str
    wersja: str
    widok_rejestru: int


@dataclass(frozen=True)
class SterownikSQL:
    nazwa: str
    widok_rejestru: int


@dataclass(frozen=True)
class SrodowiskoGT:
    system: str
    python: str
    bity_pythona: int
    instalacje: tuple[InstalacjaGT, ...] = ()
    sterowniki: tuple[SterownikSQL, ...] = ()
    uwagi: tuple[str, ...] = ()
    obslugiwany: bool = True


class CzytnikSrodowiskaGT(Protocol):
    def odczytaj(self) -> SrodowiskoGT: ...


@dataclass(frozen=True)
class RaportSrodowiskaGT:
    czas: datetime
    srodowisko: SrodowiskoGT

    @property
    def tekst(self) -> str:
        s = self.srodowisko
        lines = [
            "VexLab — środowisko Subiekta GT",
            f"Sprawdzono: {self.czas.astimezone(UTC).isoformat(timespec='seconds')}",
            f"System: {s.system}",
            f"Python: {s.python} ({s.bity_pythona}-bit)",
            "",
            "Zarejestrowane instalacje InsERT GT:",
        ]
        lines.extend(
            f"• {p.nazwa} — {p.wersja or 'wersja niepodana'} (rejestr {p.widok_rejestru}-bit)"
            for p in s.instalacje
        )
        if not s.instalacje:
            lines.append(
                "Nie znaleziono wpisów instalacji."
                if s.obslugiwany
                else "Sprawdzenie dostępne wyłącznie na Windows."
            )
        lines.extend(("", "Zarejestrowane sterowniki SQL Server:"))
        lines.extend(f"• {p.nazwa} (rejestr {p.widok_rejestru}-bit)" for p in s.sterowniki)
        if not s.sterowniki:
            lines.append(
                "Nie znaleziono wpisów sterowników."
                if s.obslugiwany
                else "Nie sprawdzono na tym systemie."
            )
        if s.uwagi:
            lines.extend(("", "Uwagi — odczyt może być niepełny:", *s.uwagi))
        lines.extend(
            (
                "",
                "Połączenie z serwerem: nie było sprawdzane.",
                "Wpis instalacji ani sterownika nie potwierdza połączenia, "
                "uprawnień lub licencji Sfery.",
            )
        )
        return "\n".join(lines)


class SprawdzSrodowiskoGT:
    def __init__(self, czytnik: CzytnikSrodowiskaGT, zegar: Zegar) -> None:
        self._czytnik, self._zegar = czytnik, zegar

    def wykonaj(self) -> RaportSrodowiskaGT:
        srodowisko = self._czytnik.odczytaj()
        czas = self._zegar.teraz()
        if czas.utcoffset() is None:
            raise BladTechniczny("Zegar diagnostyczny zwrócił czas bez strefy.")
        return RaportSrodowiskaGT(czas, srodowisko)
