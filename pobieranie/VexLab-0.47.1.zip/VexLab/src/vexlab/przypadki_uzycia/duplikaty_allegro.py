"""Odczyt istniejących ofert konta przed nowym POST, bez zmiany ofert."""

import unicodedata
from dataclasses import dataclass
from typing import Protocol

from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad


@dataclass(frozen=True)
class IstniejacaOferta:
    ident: str
    tytul: str
    sku: str
    status: str
    powod: str = "SKU / sygnatura"


class APIDuplikatow(Protocol):
    def kandydaci_duplikatow(
        self, sesja: SesjaAllegro, pole: str, fraza: str
    ) -> tuple[IstniejacaOferta, ...]: ...
    def ean_duplikatu(self, sesja: SesjaAllegro, ident: str) -> tuple[str, ...]: ...


def nazwa(tekst: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", tekst).casefold().split())


class SprawdzDuplikatyAllegro:
    def __init__(self, api: APIDuplikatow) -> None:
        self.api = api

    def sprawdz(
        self, s: SesjaAllegro, oferty: tuple[OfertaPodglad, ...]
    ) -> tuple[tuple[IstniejacaOferta, ...], ...]:
        wynik = []
        cache: dict[tuple[str, str], tuple[IstniejacaOferta, ...]] = {}
        eans: dict[str, tuple[str, ...]] = {}
        for o in oferty:
            if not o.sku.strip() or not o.tytul.strip():
                raise BladAllegro("DUPLIKATY", "Do sprawdzenia wymagane są SKU i tytuł.")
            found = []
            for pole, fraza in (("external.id", o.sku.strip()), ("name", o.tytul.strip())):
                key = (pole, fraza)
                if key not in cache:
                    cache[key] = self.api.kandydaci_duplikatow(s, pole, fraza)
                for item in cache[key]:
                    if pole == "external.id":
                        if nazwa(item.sku) == nazwa(o.sku):
                            found.append(item)
                    elif nazwa(item.tytul) == nazwa(o.tytul):
                        if item.ident not in eans:
                            eans[item.ident] = self.api.ean_duplikatu(s, item.ident)
                        if o.ean and eans[item.ident] and o.ean not in eans[item.ident]:
                            continue
                        powod = (
                            "Tytuł i EAN"
                            if o.ean and o.ean in eans[item.ident]
                            else ("Taki sam tytuł — wymaga porównania")
                        )
                        found.append(
                            IstniejacaOferta(item.ident, item.tytul, item.sku, item.status, powod)
                        )
                if pole == "external.id" and found:
                    break
            wynik.append(tuple({item.ident: item for item in found}.values()))
        return tuple(wynik)


def opis_duplikatow(items: tuple[IstniejacaOferta, ...]) -> str:
    statuses = {
        "ACTIVE": "Aktywna",
        "INACTIVE": "Szkic",
        "ENDED": "Zakończona",
        "ACTIVATING": "Aktywowana",
    }
    return "; ".join(
        f"ID {p.ident} • {statuses.get(p.status, p.status)} • {p.powod} • {p.tytul}" for p in items
    )
