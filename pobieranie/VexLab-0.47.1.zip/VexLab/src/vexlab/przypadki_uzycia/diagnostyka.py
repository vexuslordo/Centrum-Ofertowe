"""Izolowany przepływ techniczny; nie sprawdza gotowości funkcji biznesowych."""

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from vexlab.rdzen.kontrakty import BladTechniczny, IdKorelacji, Zegar


@dataclass(frozen=True)
class WersjeSrodowiska:
    python: str
    pyside6: str
    sqlite: str


class CzytnikWersji(Protocol):
    def odczytaj(self) -> WersjeSrodowiska: ...


@dataclass(frozen=True)
class RaportDiagnostyczny:
    id_korelacji: IdKorelacji
    czas: datetime
    wersje: WersjeSrodowiska


class DiagnozujSrodowisko:
    def __init__(self, zegar: Zegar, czytnik: CzytnikWersji) -> None:
        self._zegar = zegar
        self._czytnik = czytnik

    def wykonaj(self, id_korelacji: IdKorelacji) -> RaportDiagnostyczny:
        czas = self._zegar.teraz()
        if czas.utcoffset() is None:
            raise BladTechniczny("Zegar diagnostyczny zwrócił czas bez strefy.")
        return RaportDiagnostyczny(id_korelacji, czas, self._czytnik.odczytaj())
