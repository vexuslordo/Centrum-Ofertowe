"""Pobranie kandydatów zdjęć za portem; zapis dopiero po akceptacji użytkownika."""

import ipaddress
from dataclasses import dataclass
from typing import Protocol
from urllib.parse import urlsplit

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu


@dataclass(frozen=True)
class ZdjecieDane:
    zrodlo: str
    dane: bytes
    miniatura: bytes


@dataclass(frozen=True)
class KandydaciZdjec:
    strona_produktu: str
    tytul: str
    sku: str
    zdjecia: tuple[ZdjecieDane, ...]


class ZrodloZdjec(Protocol):
    def pobierz(self, strona: str, sku: str, limit: int = 5) -> KandydaciZdjec: ...


class PobierzZdjecia:
    def __init__(self, zrodlo: ZrodloZdjec) -> None:
        self.zrodlo = zrodlo

    def wykonaj(self, strona: str, sku: str) -> KandydaciZdjec:
        if not strona.strip() or not sku.strip():
            raise BladScenariuszaKatalogu("MEDIA", "Wpisz adres HTTPS producenta i SKU.")
        return self.zrodlo.pobierz(strona.strip(), sku.strip())

    def wykonaj_pierwsze(self, strona: str, sku: str) -> KandydaciZdjec:
        return self.zrodlo.pobierz(strona_zdjec(strona), sku.strip(), limit=1)


def adres_https(url: str) -> str:
    try:
        if len(url) > 4096:
            raise ValueError()
        u = urlsplit(url)
        if (
            u.scheme != "https"
            or not u.hostname
            or u.username
            or u.password
            or u.port not in (None, 443)
        ):
            raise ValueError()
        host = u.hostname.lower()
        if host == "localhost" or host.endswith((".localhost", ".local")):
            raise ValueError()
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            if "." not in host:
                raise ValueError() from None
        else:
            if not ip.is_global or ip.is_multicast:
                raise ValueError()
    except ValueError as exc:
        raise BladScenariuszaKatalogu(
            "MEDIA", "Dozwolony jest publiczny adres HTTPS bez danych logowania."
        ) from exc
    return url


def strona_zdjec(url: str) -> str:
    url = adres_https(url.strip())
    u = urlsplit(url)
    if u.query or u.fragment:
        raise BladScenariuszaKatalogu("MEDIA", "Podaj adres strony producenta bez parametrów.")
    return url
