"""Jawne stawki VAT według kraju, walidowane z metadanymi kategorii Allegro."""

import re
from dataclasses import dataclass
from decimal import Decimal

from vexlab.przypadki_uzycia.allegro import BladAllegro


@dataclass(frozen=True)
class OpcjaVAT:
    wartosc: str
    etykieta: str
    wymaga_zwolnienia: bool = False


@dataclass(frozen=True)
class VATKategorii:
    kategoria: str
    kraje: tuple[tuple[str, tuple[OpcjaVAT, ...]], ...]
    przedmioty: tuple[tuple[str, str], ...] = ()
    zwolnienia: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class StawkaVAT:
    kraj: str
    wartosc: str
    etykieta: str = ""


@dataclass(frozen=True)
class UstawieniaVAT:
    stawki: tuple[StawkaVAT, ...]
    przedmiot: str = ""
    zwolnienie: str = ""


def normalizuj_vat(tekst: str) -> str:
    value = tekst.strip().removesuffix("%").strip().replace(",", ".")
    if not re.fullmatch(r"[0-9]{1,3}(?:\.[0-9]{1,2})?", value) or Decimal(value) > 100:
        raise BladAllegro(
            "VAT", "Stawka VAT wymaga liczby od 0 do 100, do dwóch miejsc po przecinku."
        )
    return format(Decimal(value), ".2f")


def sprawdz_vat(
    u: UstawieniaVAT, meta: VATKategorii | None = None, wymagaj_wyboru: bool = True
) -> None:
    if not u.stawki or len(u.stawki) > 32 or len({r.kraj for r in u.stawki}) != len(u.stawki):
        raise BladAllegro("VAT", "Zaznacz kraje i podaj jedną stawkę dla każdego kraju.")
    for rate in u.stawki:
        if not re.fullmatch(r"[A-Z]{2}", rate.kraj):
            raise BladAllegro("VAT", "Niepoprawny kod kraju VAT.")
        try:
            normalizuj_vat(rate.wartosc)
        except BladAllegro as exc:
            raise BladAllegro("VAT", rate.kraj + ": " + str(exc)) from None
    if meta is None:
        return
    if wymagaj_wyboru and meta.przedmioty and u.przedmiot not in dict(meta.przedmioty):
        raise BladAllegro("VAT", "Wybierz rodzaj sprzedaży z listy Allegro.")
    if u.przedmiot and u.przedmiot not in dict(meta.przedmioty):
        raise BladAllegro("VAT", "Rodzaj sprzedaży nie jest dostępny w tej kategorii.")
    if u.zwolnienie and u.zwolnienie not in dict(meta.zwolnienia):
        raise BladAllegro("VAT", "Zwolnienie nie jest dostępne w tej kategorii.")
    for rate in u.stawki:
        options = dict(meta.kraje).get(rate.kraj, ())
        matches = [
            o
            for o in options
            if normalizuj_vat(o.wartosc) == normalizuj_vat(rate.wartosc)
            and (not rate.etykieta or o.etykieta == rate.etykieta)
        ]
        if not matches:
            raise BladAllegro(
                "VAT", f"{rate.kraj}: wybrana stawka nie jest dostępna w tej kategorii Allegro."
            )
        if wymagaj_wyboru and len({o.wymaga_zwolnienia for o in matches}) > 1:
            raise BladAllegro(
                "VAT",
                f"{rate.kraj}: wybierz konkretną pozycję z listy stawek, "
                "zamiast wpisywać samą liczbę.",
            )
        if wymagaj_wyboru and matches[0].wymaga_zwolnienia and not u.zwolnienie:
            raise BladAllegro(
                "VAT", f"{rate.kraj}: ta opcja wymaga wybrania zwolnienia z listy Allegro."
            )


def pola_vat(u: UstawieniaVAT) -> dict[str, object]:
    sprawdz_vat(u)
    fields: dict[str, object] = {
        "rates": [{"countryCode": r.kraj, "rate": normalizuj_vat(r.wartosc)} for r in u.stawki]
    }
    if u.przedmiot:
        fields["subject"] = u.przedmiot
    if u.zwolnienie:
        fields["exemption"] = u.zwolnienie
    return fields


def odczytaj_vat(d: dict[str, object]) -> UstawieniaVAT:
    raw = d.get("taxSettings")
    if not isinstance(raw, dict) or not isinstance(raw.get("rates"), list):
        raise BladAllegro("VAT", "Oferta nie ma zapisanych stawek VAT według krajów.")
    try:
        rates = tuple(StawkaVAT(r["countryCode"], normalizuj_vat(r["rate"])) for r in raw["rates"])
        subject, exemption = raw.get("subject") or "", raw.get("exemption") or ""
        if not isinstance(subject, str) or not isinstance(exemption, str):
            raise ValueError("typ")
        result = UstawieniaVAT(rates, subject, exemption)
        sprawdz_vat(result)
        return result
    except (KeyError, TypeError, AttributeError, ValueError):
        raise BladAllegro("VAT", "Niepoprawne dane VAT w odpowiedzi Allegro.") from None


def potwierdz_vat(d: dict[str, object], u: UstawieniaVAT) -> bool:
    try:
        actual = odczytaj_vat(d)
    except BladAllegro:
        return False
    rates = {r.kraj: normalizuj_vat(r.wartosc) for r in actual.stawki}
    return (
        all(rates.get(r.kraj) == normalizuj_vat(r.wartosc) for r in u.stawki)
        and (not u.przedmiot or actual.przedmiot == u.przedmiot)
        and actual.zwolnienie == u.zwolnienie
    )
