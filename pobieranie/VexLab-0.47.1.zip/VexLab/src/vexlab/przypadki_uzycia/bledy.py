"""Stabilny błąd scenariusza katalogu, bez zależności GUI od domeny."""


class BladScenariuszaKatalogu(RuntimeError):
    def __init__(self, kod: str, komunikat: str) -> None:
        super().__init__(komunikat)
        self.kod = kod
