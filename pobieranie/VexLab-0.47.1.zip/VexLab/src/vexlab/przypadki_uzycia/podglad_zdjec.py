"""Pojedynczy obraz podglądu za portem; nie zmienia szkicu ani galerii Produktu."""

from typing import Protocol

from vexlab.przypadki_uzycia.media import ZdjecieDane


class ZrodloObrazu(Protocol):
    def pobierz_obraz(self, url: str) -> ZdjecieDane: ...


class PodgladZdjec:
    def __init__(self, zrodlo: ZrodloObrazu) -> None:
        self.zrodlo = zrodlo

    def pobierz(self, url: str) -> ZdjecieDane:
        return self.zrodlo.pobierz_obraz(url.strip())
