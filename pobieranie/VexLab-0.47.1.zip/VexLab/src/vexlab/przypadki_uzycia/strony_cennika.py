"""Lekki indeks porównań całego dokumentu i pełne dane wybranej strony."""

from collections import Counter
from contextlib import closing
from dataclasses import dataclass
from uuid import UUID

from vexlab.przypadki_uzycia.cenniki import (
    BibliotekaCennikow,
    CennikDTO,
    PozycjaCennika,
    porownaj_ocene,
)
from vexlab.przypadki_uzycia.importowanie import blad
from vexlab.przypadki_uzycia.katalog import CenaSugerowanaDTO


@dataclass(frozen=True)
class SkrotPozycji:
    indeks: int
    nazwa: str
    sku: str
    wiersz: int
    ma_ean: bool
    stan: str
    w_katalogu: bool
    cena_bazowa: CenaSugerowanaDTO | None
    roznica: str
    porownanie: str
    problem: str


@dataclass(frozen=True)
class IndeksCennika:
    id: UUID
    wersja: int
    pozycje: tuple[SkrotPozycji, ...]

    def pasujace(self, fraza: str = "", stan: str = "") -> tuple[SkrotPozycji, ...]:
        fraza = fraza.strip().casefold()
        return tuple(
            p
            for p in self.pozycje
            if fraza in f"{p.nazwa} {p.sku}".casefold() and (not stan or stan == p.stan)
        )


@dataclass(frozen=True)
class StronaCennika:
    pozycje: tuple[PozycjaCennika, ...]
    liczba: int
    numer: int
    rozmiar: int
    ma_ean: bool


class PrzegladCennika:
    def __init__(self, biblioteka: BibliotekaCennikow) -> None:
        self.biblioteka = biblioteka

    def przygotuj(self, c: CennikDTO) -> IndeksCennika:
        b = self.biblioteka
        liczby = Counter(
            sku.strip().casefold() for sku in b.magazyn.symbole_cennika(c.id, c.wersja)
        )
        znane = b.importer.katalog.producenci_sku(tuple(liczby))
        ceny, braki = b._ceny_bazowe(c)
        wynik = []
        with closing(b.magazyn.iteruj_pozycje(c.id, c.wersja)) as rows:
            for i, row in enumerate(rows):
                ocena = b.importer.ocen((row,), uwzglednij_katalog=False, liczby_sku=liczby)[0]
                p = porownaj_ocene(i, ocena, znane, ceny, braki)
                wynik.append(
                    SkrotPozycji(
                        i,
                        row.dane.nazwa,
                        row.dane.sku,
                        row.wiersz,
                        bool(row.dane.ean),
                        p.stan,
                        p.w_katalogu,
                        p.cena_bazowa,
                        p.roznica,
                        p.porownanie,
                        p.problem,
                    )
                )
        return IndeksCennika(c.id, c.wersja, tuple(wynik))

    def strona(
        self,
        c: CennikDTO,
        indeks: IndeksCennika,
        fraza: str = "",
        stan: str = "",
        numer: int = 0,
        rozmiar: int = 100,
    ) -> StronaCennika:
        if (
            (c.id, c.wersja) != (indeks.id, indeks.wersja)
            or numer < 0
            or rozmiar not in (100, 250, 500)
        ):
            raise blad("Nieprawidłowa strona cennika. Odśwież podgląd.")
        pasujace = indeks.pasujace(fraza, stan)
        numer = min(numer, max(0, (len(pasujace) - 1) // rozmiar))
        strona = pasujace[numer * rozmiar : (numer + 1) * rozmiar]
        wybrane = frozenset(p.indeks for p in strona)
        rows = self.biblioteka.magazyn.pozycje_wybrane(c.id, c.wersja, wybrane)
        if set(rows) != wybrane:
            raise blad("Nie odczytano wszystkich pozycji strony. Odśwież podgląd.")
        return StronaCennika(
            tuple(
                PozycjaCennika(
                    p.indeks,
                    rows[p.indeks],
                    p.stan,
                    p.w_katalogu,
                    p.cena_bazowa,
                    p.roznica,
                    p.porownanie,
                    p.problem,
                )
                for p in strona
            ),
            len(pasujace),
            numer,
            rozmiar,
            any(p.ma_ean for p in indeks.pozycje),
        )
