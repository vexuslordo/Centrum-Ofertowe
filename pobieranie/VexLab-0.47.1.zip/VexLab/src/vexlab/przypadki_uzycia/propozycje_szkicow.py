"""Propozycja tytułu/opisu zdalnego szkicu; plik roboczy nie jest zapisem API."""

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Protocol
from urllib.parse import urlsplit

from vexlab.przypadki_uzycia.allegro import (
    BladAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StatusOfertyAllegro,
    SzczegolySzkicuAllegro,
)
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu

Sekcje = tuple[tuple[ElementPodgladu, ...], ...]


@dataclass(frozen=True)
class PropozycjaSzkicu:
    srodowisko: SrodowiskoAllegro
    konto_id: str
    oferta_id: str
    tytul_bazowy: str
    sekcje_bazowe: Sekcje
    tytul: str
    sekcje: Sekcje

    def sprawdz(self) -> None:
        if (
            not isinstance(self.srodowisko, SrodowiskoAllegro)
            or not self.konto_id
            or len(self.konto_id) > 100
            or any(ord(c) < 32 for c in self.konto_id)
            or not self.oferta_id.isascii()
            or not self.oferta_id.isdigit()
            or len(self.oferta_id) > 100
        ):
            raise BladAllegro("PROPOZYCJA", "Nieprawidłowy kontekst propozycji szkicu.")
        for t in (self.tytul_bazowy, self.tytul):
            if not t.strip() or len(t) > 1000 or any(ord(c) < 32 for c in t):
                raise BladAllegro(
                    "PROPOZYCJA", "Wpisz tytuł, do 1000 znaków bez znaków sterujących."
                )
        for sekcje in (self.sekcje_bazowe, self.sekcje):
            if len(sekcje) > 100:
                raise BladAllegro("PROPOZYCJA", "Propozycja może zawierać do 100 sekcji.")
            for sekcja in sekcje:
                if not 1 <= len(sekcja) <= 2:
                    raise BladAllegro("PROPOZYCJA", "Sekcja musi mieć jeden lub dwa elementy.")
                for e in sekcja:
                    if e.typ not in {"tekst", "obraz"} or len(e.tekst) > 100000:
                        raise BladAllegro("PROPOZYCJA", "Nieprawidłowy element opisu.")
                    if e.typ == "obraz":
                        try:
                            u = urlsplit(e.adres)
                            poprawny = (
                                u.scheme == "https"
                                and u.hostname
                                and not u.username
                                and not u.password
                                and not u.fragment
                                and u.port != 0
                                and "\\" not in e.adres
                                and len(e.adres) <= 4096
                                and not any(ord(c) <= 32 for c in e.adres)
                            )
                        except ValueError:
                            poprawny = False
                        if not poprawny:
                            raise BladAllegro("PROPOZYCJA", "Wpisz pełny adres HTTPS zdjęcia.")


class PlikiPropozycji(Protocol):
    def zapisz(self, cel: Path, propozycja: PropozycjaSzkicu) -> None: ...
    def odczytaj(self, zrodlo: Path) -> PropozycjaSzkicu: ...


class PropozycjeSzkicow:
    def __init__(self, pliki: PlikiPropozycji) -> None:
        self._pliki = pliki

    @staticmethod
    def rozpocznij(sesja: SesjaAllegro, szkic: SzczegolySzkicuAllegro) -> PropozycjaSzkicu:
        if szkic.status != StatusOfertyAllegro.SZKIC:
            raise BladAllegro(
                "STAN", "Propozycję edycji można przygotować tylko dla szkicu INACTIVE."
            )
        wynik = PropozycjaSzkicu(
            sesja.srodowisko,
            sesja.konto.id,
            szkic.id,
            szkic.tytul,
            szkic.sekcje,
            szkic.tytul,
            szkic.sekcje,
        )
        wynik.sprawdz()
        return wynik

    @staticmethod
    def zmien(baza: PropozycjaSzkicu, tytul: str, sekcje: Sekcje) -> PropozycjaSzkicu:
        wynik = replace(baza, tytul=tytul, sekcje=sekcje)
        wynik.sprawdz()
        return wynik

    @staticmethod
    def sprawdz_aktualnosc(p: PropozycjaSzkicu, aktualny: SzczegolySzkicuAllegro) -> None:
        if aktualny.id != p.oferta_id or aktualny.status != StatusOfertyAllegro.SZKIC:
            raise BladAllegro(
                "STAN", "Oferta nie jest już tym samym szkicem INACTIVE. Zachowano propozycję."
            )
        if aktualny.tytul != p.tytul_bazowy or aktualny.sekcje != p.sekcje_bazowe:
            raise BladAllegro(
                "KONFLIKT", "Treść szkicu zmieniła się w Allegro. Zachowano Twoją propozycję."
            )

    def zapisz(self, cel: Path, p: PropozycjaSzkicu) -> None:
        p.sprawdz()
        self._pliki.zapisz(cel, p)

    def wczytaj(self, zrodlo: Path, baza: PropozycjaSzkicu) -> PropozycjaSzkicu:
        p = self._pliki.odczytaj(zrodlo)
        p.sprawdz()
        if (p.srodowisko, p.konto_id, p.oferta_id) != (
            baza.srodowisko,
            baza.konto_id,
            baza.oferta_id,
        ):
            raise BladAllegro("KONTO", "Propozycja dotyczy innego konta, środowiska lub szkicu.")
        if (p.tytul_bazowy, p.sekcje_bazowe) != (baza.tytul_bazowy, baza.sekcje_bazowe):
            raise BladAllegro(
                "KONFLIKT", "Propozycja powstała dla innej treści szkicu. Nie zastąpiono edycji."
            )
        return p
