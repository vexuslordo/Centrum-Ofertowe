"""Ograniczony model odczytu Dashboardu; bez encji kanałów i fikcyjnych metryk."""

from dataclasses import dataclass
from threading import Lock
from time import monotonic
from typing import Protocol

SEKCJE_DASHBOARDU = (
    "kpi",
    "sprzedaz",
    "integracje",
    "alerty",
    "top",
    "zamowienia",
    "system",
    "magazyn",
    "aktywnosc",
    "ai",
    "akcje",
)


def sprawdz_sekcje(kolejnosc: tuple[str, ...], ukryte: tuple[str, ...]) -> None:
    if (
        len(kolejnosc) != len(SEKCJE_DASHBOARDU)
        or set(kolejnosc) != set(SEKCJE_DASHBOARDU)
        or len(set(ukryte)) != len(ukryte)
        or not set(ukryte) <= set(SEKCJE_DASHBOARDU)
    ):
        raise ValueError("Nieprawidłowy układ Dashboardu.")


@dataclass(frozen=True)
class StanDashboardu:
    produkty: int
    bez_zdjec: int
    bez_ean: int
    bez_producenta: int
    bez_opisu: int
    do_poprawy: int


class OdczytDashboardu(Protocol):
    def stan_dashboardu(self) -> StanDashboardu: ...


class Dashboard:
    """Jeden snapshot, TTL 30 s; odczyt wywoływany przez zadanie w tle."""

    def __init__(self, odczyt: OdczytDashboardu) -> None:
        self._odczyt = odczyt
        self._stan: StanDashboardu | None = None
        self._czas = 0.0
        self._blokada = Lock()

    def odczytaj(self, *, odswiez: bool = False) -> StanDashboardu:
        with self._blokada:
            if odswiez or self._stan is None or monotonic() - self._czas >= 30:
                self._stan = self._odczyt.stan_dashboardu()
                self._czas = monotonic()
            return self._stan
