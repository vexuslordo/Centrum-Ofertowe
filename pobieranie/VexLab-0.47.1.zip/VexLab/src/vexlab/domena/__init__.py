"""Minimalny lokalny Produkt; pozostały model pozostaje do uzgodnienia."""
