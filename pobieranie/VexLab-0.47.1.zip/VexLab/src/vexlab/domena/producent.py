"""Producent jest odrębnym rejestrem, nie Dostawcą ani PodmiotemGPSR."""

import re
from dataclasses import dataclass, replace
from typing import Self
from uuid import UUID

from vexlab.domena.produkt import BladKatalogu


class NieprawidlowyProducent(BladKatalogu):
    pass


class ProducentNieIstnieje(BladKatalogu):
    pass


class ProducentNieaktywny(BladKatalogu):
    pass


@dataclass(frozen=True)
class Producent:
    id: UUID
    nazwa: str
    aktywny: bool = True
    wersja: int = 1
    strona_www: str = ""

    def __post_init__(self) -> None:
        if not self.nazwa.strip() or self.nazwa != self.nazwa.strip():
            raise NieprawidlowyProducent("Podaj niepustą nazwę producenta bez skrajnych odstępów.")
        if self.strona_www and (
            len(self.strona_www) > 2048
            or not re.fullmatch(
                r"https://(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+"
                r"[A-Za-z]{2,63}(?::443)?(?:/[^\s?#@]*)?",
                self.strona_www,
            )
        ):
            raise NieprawidlowyProducent(
                "Wpisz adres HTTPS strony producenta bez danych logowania i parametrów."
            )
        if self.wersja < 1:
            raise NieprawidlowyProducent("Nieprawidłowa wersja producenta.")

    def zmien(self, nazwa: str, aktywny: bool, strona_www: str | None = None) -> Self:
        return replace(
            self,
            nazwa=nazwa,
            aktywny=aktywny,
            wersja=self.wersja + 1,
            strona_www=self.strona_www if strona_www is None else strona_www,
        )
