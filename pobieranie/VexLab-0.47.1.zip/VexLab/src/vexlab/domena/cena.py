"""Wartość źródłowej sugerowanej ceny sprzedaży; bez reguł Oferty i kursów."""

import re
from dataclasses import dataclass
from decimal import Decimal

WALUTY = ("PLN", "EUR", "GBP", "USD", "CHF", "CZK", "SEK", "NOK", "DKK")


@dataclass(frozen=True)
class CenaSugerowana:
    kwota: Decimal
    waluta: str
    rodzaj: str

    def __post_init__(self) -> None:
        if not self.kwota.is_finite() or self.kwota < 0:
            raise ValueError("Cena musi być nieujemną, skończoną kwotą.")
        if self.waluta not in WALUTY or self.rodzaj not in ("netto", "brutto"):
            raise ValueError("Wybierz walutę i oznaczenie netto/brutto ceny sugerowanej.")

    @classmethod
    def z_tekstu(cls, tekst: str, waluta: str, rodzaj: str) -> "CenaSugerowana":
        tekst = tekst.strip().replace(" ", "").replace("\u00a0", "")
        if not re.fullmatch(r"\d{1,12}(?:[.,]\d{1,6})?", tekst):
            raise ValueError(
                "Nieprawidłowa cena: wpisz kwotę bez symbolu waluty i separatora tysięcy."
            )
        return cls(Decimal(tekst.replace(",", ".")), waluta.upper(), rodzaj)
