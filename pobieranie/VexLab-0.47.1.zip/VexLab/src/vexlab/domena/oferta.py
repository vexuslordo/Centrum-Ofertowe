"""Lokalny szkic prezentacji; powiązanie z dawnym Produktem jest opcjonalne."""

from dataclasses import dataclass, replace
from uuid import UUID


@dataclass(frozen=True)
class SzkicOferty:
    id: UUID
    produkt_id: UUID | None
    wersja_produktu: int | None
    tytul: str
    opis: str
    wersja: int = 1

    def __post_init__(self) -> None:
        if not self.tytul.strip():
            raise ValueError("Tytuł szkicu jest wymagany.")
        if (self.produkt_id is None) != (self.wersja_produktu is None):
            raise ValueError("Powiązanie Produktu wymaga ID i wersji albo obu pustych pól.")
        if self.wersja < 1 or (self.wersja_produktu is not None and self.wersja_produktu < 1):
            raise ValueError("Nieprawidłowa wersja szkicu lub Produktu.")

    def zmien(self, tytul: str, opis: str) -> "SzkicOferty":
        return replace(self, tytul=tytul.strip(), opis=opis, wersja=self.wersja + 1)
