"""VexLab — pakiet bez efektów ubocznych podczas importu."""
