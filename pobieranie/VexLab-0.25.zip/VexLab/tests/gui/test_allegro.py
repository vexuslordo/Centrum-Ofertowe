from PySide6.QtWidgets import QLineEdit

from vexlab.gui.allegro import StronaAllegro
from vexlab.przypadki_uzycia.allegro import (
    KodUrzadzenia,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StronaSzkicowAllegro,
    SzkicAllegro,
)


class Serwis:
    czas = 100

    def teraz(self):
        return self.czas


def panel(qtbot):
    jobs = []
    w = StronaAllegro(Serwis(), lambda *a: jobs.append(a))
    qtbot.addWidget(w)
    w.klient.setText("test-client")
    w.sekret.setText("test-secret")
    return w, jobs


def kod():
    return KodUrzadzenia("test-device", "TEST-CODE", "https://allegro.pl/potwierdz", 600, 5)


def sesja():
    return SesjaAllegro(
        KontoAllegro("123", "testowy"), SrodowiskoAllegro.PRODUKCJA, "test-access", 3700
    )


def test_brak_sukcesu_przed_me_oraz_token_i_sekret_nie_sa_tekstami_gui(qtbot):
    w, jobs = panel(qtbot)
    stany = []
    w.stan.connect(stany.append)
    assert w.sekret.echoMode() == QLineEdit.EchoMode.Password
    w.rozpocznij()
    w.rozpocznij()
    assert len(jobs) == 1 and not w.sekret.text() and not w.odswiez.isEnabled()
    jobs[-1][1](kod())
    assert not stany and w.timer.isActive() and w.timer.interval() == 5000
    w.timer.stop()
    w._sprawdz()
    assert not stany
    jobs[-1][1](sesja())
    assert stany == ["Allegro: testowy"] and w.aplikacja is None and w.kod is None
    assert "test-secret" not in w.info.text() and "test-access" not in w.info.text()
    assert not w.otworz.isEnabled() and w.trwa
    jobs[-1][1](StronaSzkicowAllegro((SzkicAllegro("1", "Test"),), 51, 0, 50))
    assert w.tabela.rowCount() == 1 and w.nastepna.isEnabled() and "51" in w.zakres.text()
    w.anuluj()
    assert w.sesja is None and not w.wygasanie.isActive() and w.tabela.rowCount() == 0


def test_pending_slow_down_i_odmowa(qtbot):
    w, jobs = panel(qtbot)
    w.rozpocznij()
    jobs[-1][1](kod())
    w.timer.stop()
    w._sprawdz()
    jobs[-1][2]("OCZEKIWANIE", "Oczekiwanie")
    assert w.timer.interval() == 5000 and w.aplikacja is not None
    w.timer.stop()
    w._sprawdz()
    jobs[-1][2]("WOLNIEJ", "Wolniej")
    assert w.timer.interval() == 10000
    w.timer.stop()
    w._sprawdz()
    jobs[-1][2]("ODMOWA", "Odmówiono zgody")
    assert w.aplikacja is None and not w.timer.isActive() and w.polacz.isEnabled()
    assert w.info.text() == "Odmówiono zgody"


def test_anulowanie_ignoruje_spozniona_autoryzacje_i_nie_otwiera_przegladarki(qtbot, monkeypatch):
    from vexlab.gui import allegro as m

    monkeypatch.setattr(
        m.QDesktopServices, "openUrl", lambda *a: (_ for _ in ()).throw(AssertionError())
    )
    w, jobs = panel(qtbot)
    w.rozpocznij()
    jobs[-1][1](kod())
    w.timer.stop()
    w._sprawdz()
    w.anuluj()
    jobs[-1][1](sesja())
    assert w.sesja is None and w.polacz.isEnabled() and not w.odswiez.isEnabled()
    assert w.tabela.rowCount() == 0


def test_wygasniecie_kodu_lub_sesji_czysci_stan(qtbot):
    w, jobs = panel(qtbot)
    w.rozpocznij()
    jobs[-1][1](kod())
    w.serwis.czas = 701
    w.timer.stop()
    w._sprawdz()
    assert w.aplikacja is None and len(jobs) == 1 and "wygasł" in w.info.text()
    w.sesja = sesja()
    w.serwis.czas = 4000
    w._waznosc()
    assert w.sesja is None and "wygasła" in w.info.text()


def test_blad_odczytu_nie_pozostawia_starej_listy(qtbot):
    w, jobs = panel(qtbot)
    w.sesja = sesja()
    w._przyciski()
    w.pobierz()
    jobs[-1][1](StronaSzkicowAllegro((SzkicAllegro("1", "T"),), 1, 0, 50))
    assert w.tabela.rowCount() == 1
    w.pobierz()
    jobs[-1][2]("SIEC", "Brak odpowiedzi")
    assert w.tabela.rowCount() == 0 and "Nie pobrano" in w.zakres.text()
    assert w.odswiez.isEnabled() and w.sesja is not None
    w.anuluj()


def test_worker_zachowuje_rodzaj_pending_bez_sekretow(qtbot):
    from vexlab.gui.zadania import Zadanie
    from vexlab.przypadki_uzycia.allegro import BladAllegro

    def pending():
        raise BladAllegro("OCZEKIWANIE", "Oczekiwanie na zgodę")

    z = Zadanie(pending)
    wyniki = []
    z.sygnaly.blad.connect(lambda *a: wyniki.append(a))
    z.run()
    assert wyniki == [("OCZEKIWANIE", "Oczekiwanie na zgodę")]
