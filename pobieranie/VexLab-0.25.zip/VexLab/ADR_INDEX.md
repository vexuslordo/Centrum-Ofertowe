# VexLab — rejestr decyzji architektonicznych

Wersja 0.3 • 2026-11-02 • nowy rejestr decyzji samodzielnego projektu.

## 1. Zasady nowego rejestru

VexLab jest projektowane od zera. Ten rejestr nie dziedziczy dawnej numeracji i nie wymaga wyszukiwania ani uzupełniania wcześniejszych decyzji. Wymagania technologiczne i zakres domenowy wynikają z bieżącego zamówienia dokumentacji.

Nowe decyzje mają identyfikatory ADR-001 i kolejne. Propozycje P-xx, pytania Q-xx oraz konflikty K-xx pomagają przygotować decyzje; nie są automatycznie zaakceptowanymi ADR.

## 2. Początkowy rejestr nowych decyzji

| ID | Temat | Proponowane rozstrzygnięcie | Status |
|---|---|---|---|
| ADR-001 | Granice sześciu warstw | Graf importów z konstytucji i zewnętrzny bootstrap bez reguł biznesowych | Wdrożona decyzja techniczna etapu 2; [ADR-001](docs/adr/ADR-001-granice-warstw.md) |
| ADR-002 | Model domenowy | 16 bytów, konteksty i granice agregatów opisane w DOMAIN_MODEL | Proponowany; szczegóły P-02 |
| ADR-003 | Własność danych | Jawna macierz właścicieli pól i konfliktów synchronizacji | Proponowany; szczegóły P-03 |
| ADR-004 | Trwałość i migracje | Lokalna SQLite, jawne transakcje, wersjonowane migracje i odtwarzalne kopie | Proponowany; szczegóły P-04 |
| ADR-005 | Fluent UI | Wspólne tokeny i komponenty PySide6; QFluentWidgets warunkowo po ocenie licencji i zgodności | Proponowany; szczegóły P-05 |
| ADR-006 | Długotrwałe wykonanie | Trwałe Operacje, deduplikacja, uzgadnianie wyniku i outbox dla potrzebnych scenariuszy | Proponowany; szczegóły P-06 |
| ADR-007 | Sekrety | Magazyn Windows za portem; bez jawnych tokenów w bazie | Proponowany; szczegóły P-07 |
| ADR-008 | Typy podstawowe | Jawne ID, czas, pieniądze z walutą i wersja współbieżnej edycji | Proponowany; szczegóły P-08 |
| ADR-009 | Dystrybucja | Odtwarzalny pakiet Windows, kontrolowana aktualizacja i zachowanie danych | Proponowany; szczegóły P-09 |
| ADR-010 | Komunikacja | Wątek i Wiadomość z odrębnymi granicami zapisu po ocenie scenariuszy | Proponowany; szczegóły P-10 |
| ADR-011 | Środowisko | Wspierana wersja Pythona i przypięty, odtwarzalny zestaw zależności | Wdrożona decyzja developerska; [ADR-011](docs/adr/ADR-011-srodowisko.md) |

Każda pozycja ma temat, proponowany kierunek i powiązanie ze szczegółami poniżej. Status „proponowany” oznacza nową decyzję do przeglądu, nie brak dawnego dokumentu. Zatwierdzenie zapisać wraz z osobą, datą, uzasadnieniem i dowodami.
## 3. Wymagania potwierdzone w rozmowie

| ID robocze | Wymaganie | Miejsce rozwinięcia |
|---|---|---|
| W-01 | Windows, Python, PySide6, SQLite | Konstytucja, README |
| W-02 | Clean Architecture, DDD i sześć wskazanych warstw | Konstytucja |
| W-03 | Najpierw model; 16 głównych bytów | Model domenowy |
| W-04 | Produkt niezależny od platform; Oferta jest prezentacją | Model domenowy |
| W-05 | Rozdzielenie ról producent/dostawca/GPSR, kanał/konto/przewoźnik | Model domenowy |
| W-06 | Wspólny Fluent Design System, motywy, DPI, dostępność | System UI |
| W-07 | pytest, ruff, mypy, import-linter, bandit, pip-audit | AGENTS, konstytucja |
| W-08 | Brak danych biznesowych na nowej instalacji | Wszystkie moduły i roadmapa |
| W-09 | Bez implementacji funkcjonalności w tym zadaniu | AGENTS, README |
| W-10 | Nie nadpisywać zatwierdzonych dokumentów bez analizy; ZIP poza repo | README |

To śledzenie wymagań wejściowych; konkretne rozwiązania opisują nowe ADR powyżej.

## 4. Propozycje do decyzji

Właściciel decyzji we wszystkich wierszach: właściciel projektu — osoba nieustalona. Dla propozycji technicznych daty decyzji i odnośniki zatwierdzenia: brak. Wyjątek stanowi bezpośrednie wymaganie użytkownika dotyczące wyglądu UI-REF-01 i widocznych opcji, odnotowane w sekcji 9.

| ID | Temat i rekomendacja robocza | Alternatywy / konsekwencje | Bramka |
|---|---|---|---|
| P-01 | Graf importów i zewnętrzny bootstrap z konstytucji | Bootstrap w wyjątku warstwy; ryzyko zależności zwrotnych | Przed fundamentem |
| P-02 | Konteksty, agregaty i referencje z modelu | Inne granice po warsztacie; wpływ na transakcje | Przed schematem |
| P-03 | Macierz własności pól i konfliktów synchronizacji | Ręczne uzgadnianie lub jawne reguły per pole | Przed importem |
| P-04 | SQLite: lokalny plik, polityka zapisów, migracje i kopie | Dostęp bezpośredni lub biblioteka; WAL do pomiaru | Przed bazą |
| P-05 | UI: tokeny i komponenty, QFluentWidgets warunkowo | Własne komponenty PySide6 | Przed wyborem biblioteki |
| P-06 | Trwałe Operacje, outbox, deduplikacja i wznowienie | Prostsze wykonanie tylko dla lokalnych atomowych prac | Przed skutkami zewnętrznymi |
| P-07 | Magazyn sekretów Windows za portem | Inny zatwierdzony mechanizm; bez jawnych sekretów | Przed kontami |
| P-08 | Format ID, czasu, pieniędzy i wersji | Uzgodnić precyzję, strefy, jednostki i migracje | Przed utrwalaniem |
| P-09 | Pakowanie, aktualizacje i podpisywanie Windows | Narzędzia nieustalone; testy aktualizacji obowiązkowe | Przed dystrybucją |
| P-10 | Wątek i Wiadomość jako osobne granice zapisu | Jedna granica; koszt ładowania i blokad | Przed komunikacją |
| P-11 | Wersja Pythona i przypięty zestaw zależności | Wybrać na podstawie zgodności i cyklu wsparcia | Etap 1 |

## 5. Pytania otwarte

| ID | Pytanie | Ryzyko pozostawienia bez decyzji |
|---|---|---|
| Q-01 | Gdzie utworzyć repozytorium nowego projektu? | Brak wspólnego miejsca na kod i dokumentację |
| Q-02 | Jaki jest model licencji i dystrybucji aplikacji? | Nieuzgodnione warunki bibliotek i zasobów |
| Q-03 | Jaki zakres pierwszego przyrostu nowej aplikacji zatwierdzamy? | Rozbudowa wielu modułów przed ukończeniem podstawowego scenariusza |
| Q-04 | Które pola są własnością ERP, aplikacji i platform? | Ciche nadpisania danych |
| Q-05 | Warianty, zestawy, magazyn, płatności, zwroty — jaki zakres? | Ukryte rozszerzenie modelu |
| Q-06 | Jakie rodzaje Dokumentów i kto je wystawia? | Błędna numeracja i utrata historii |
| Q-07 | Jakie role GPSR, wymagane dane i odpowiedzialność weryfikacji? | Fałszywe zapewnienia zgodności |
| Q-08 | Jakie retencje, uprawnienia i zasady anonimizacji? | Niekontrolowane przechowywanie/usuwanie |
| Q-09 | Jedna instalacja czy wiele stanowisk/profili? | Nieodpowiednia topologia SQLite |
| Q-10 | Jaki sprzęt, wolumeny, wspierane wersje Windows i cele wydajności? | Niemożliwe do oceny kryteria odbioru |
| Q-11 | W jakiej kolejności wdrożyć wymagane Allegro i PrestaShop oraz jakie środowiska testowe wybrać? | Optymalizacja modelu pod przypadkowy konektor |

Pytania nie blokują przygotowania dokumentacji, lecz blokują zależne decyzje implementacyjne. Nie należy wypełniać ich losowymi danymi.

## 6. Konflikty i napięcia do rozstrzygnięcia

Poniższe pozycje to napięcia w nowym projekcie wymagające świadomego rozstrzygnięcia. Nie wynikają z wcześniejszej dokumentacji.

| ID | Strony zagadnienia | Propozycja rozstrzygnięcia | Status |
|---|---|---|---|
| K-01 | Sześć warstw i konieczność składania | Zewnętrzny bootstrap, bez reguł biznesowych | Wdrożone technicznie; ADR-001 |
| K-02 | Etap 6: moduły biznesowe przed etapem 7: przypadki użycia vs zakaz logiki w GUI | Etap 6 tylko układy i kontrakty; realizacja operacji dopiero przez etap 7; iteracja 6↔7 | Do zatwierdzenia |
| K-03 | Pusta instalacja vs chęć gotowego wyboru kanału | Techniczne konektory mogą istnieć w kodzie; rekordy biznesowe tworzy użytkownik | Do zatwierdzenia |
| K-04 | Szybka budowa Fluent UI vs nieustalone warunki QFluentWidgets | Prototyp za fasadą i decyzja licencyjna przed adopcją; alternatywa PySide6 | Do zatwierdzenia |
| K-05 | Prezentacja Produktu przez Ofertę vs konieczność historii transakcji | Referencja do Produktu w Ofercie; kontrolowany zapis historyczny w Zamówieniu nie jest konkurencyjną kartoteką | Do zatwierdzenia |

## 7. Weryfikacja QFluentWidgets

Stan sprawdzenia: 2026-11-01. [LICENSE gałęzi PySide6](https://raw.githubusercontent.com/zhiyiYo/PyQt-Fluent-Widgets/PySide6/LICENSE) zawiera GPL v3. [Producent](https://qfluentwidgets.com/pages/about/) i [oferta Pro](https://qfluentwidgets.com/pages/pro/) opisują wariant komercyjny. Nie ustalono umowy, kosztów, wersji docelowej i zgodności z planowaną dystrybucją. Decyzja P-05 pozostaje otwarta. Pełna bramka techniczno-licencyjna jest w [systemie UI](UI_UX_DESIGN_SYSTEM.md).

## 8. Cykl życia i szablon ADR

PROPOZYCJA statusów: proponowany → w przeglądzie → zaakceptowany / odrzucony; zaakceptowany może zostać zastąpiony lub wycofany z jawnym odnośnikiem.

Nowe pozycje ADR-012–ADR-016 opisano w sekcji 9. ADR-017 i ADR-018 dodano w sekcji 11. ADR-019–021 dodano w sekcji 12. ADR-022 dodano w sekcji 13. Kolejny wolny identyfikator to ADR-023. Numerów nie używać ponownie. Zaakceptowaną decyzję zmieniać przez nowy ADR z odnośnikiem do zastępowanej pozycji; zachować historię decyzji podejmowanych w tym projekcie.

```markdown
# [uzgodniony identyfikator] — [tytuł]

Status: proponowany
Data propozycji: [data]
Właściciel: [osoba/rola]
Źródła i wymagania: [odnośniki]

## Kontekst i problem
[konkretny scenariusz, ograniczenia i ryzyko]

## Rozważone warianty
[warianty z kosztami i konsekwencjami]

## Proponowana decyzja
[zakres, odpowiedzialności, wyjątki]

## Dowody i kryteria weryfikacji
[test, prototyp, pomiar lub dokument licencyjny]

## Migracja i odwracalność
[wpływ na dane, kompatybilność i powrót]

## Zatwierdzenie
[osoba, data i odnośnik; puste do decyzji]

## Powiązania
[zastępuje / zastąpiony przez / zależy od]
```

Przed zatwierdzeniem sprawdzić zgodność z modelem, grafem zależności, UI, migracjami i roadmapą. Po zatwierdzeniu uaktualnić dokumenty zależne i pozostawić ślad zmiany statusu.

## 9. Decyzje i zakres po przekazaniu wzorca UI-REF-01

Źródło: polecenie użytkownika „Zaktualizuj mi całość o wygląd i opcje które są na tem screenie. Program ma wyglądać tak” oraz [obraz referencyjny](assets/UI_REFERENCE.png). Nie poszukujemy dawnych decyzji. Wymagania wyglądu i widocznych funkcji są przyjęte bezpośrednio z tego polecenia; szczegółowe rozwiązania niewidoczne na obrazie pozostają propozycjami.

### ADR-012 — wygląd i mapa opcji UI-REF-01

**Status:** wymaganie użytkownika przyjęte do dokumentacji. **Źródło decyzji:** właściciel projektu w bieżącym poleceniu. **Zakres:** ciemny granatowy dashboard, menu, cztery KPI, pięć głównych akcji, tabela, ostatnie operacje, wykres, sześć szybkich akcji, integracje Allegro/PrestaShop i pasek stanu. Nie oznacza zatwierdzenia ceny, magazynu, dostawcy AI ani wersji środowiska ze zrzutu.

**Decyzja:** implementacja ma wiernie odtwarzać charakter i kompozycję referencji w PySide6. Zastępuje wcześniejszą dowolność układu i ogólną paletę UI. ADR-005 pozostaje propozycją technicznego sposobu realizacji, w szczególności wyboru QFluentWidgets; nie może podważać wymaganego wyglądu.

**Konsekwencje:** dodatkowe modele odczytu, komponenty i funkcje Cenników, mediów, AI, układów, edycji masowej, walidacji i kolejki; weryfikacja licencji zasobów; dane demonstracyjne nie trafiają do produkcji. **Dowód odbioru:** system UI, sekcja 23; porównanie przy 1536×1024 i testy interakcji. **Odwracalność:** zmiana kierunku wizualnego wymaga nowej instrukcji użytkownika, a nie lokalnej decyzji implementatora.

### ADR-013 — ceny, cenniki i dostępność

**Status:** proponowany. **Cel wymagany:** Cenniki, import, zmiana i synchronizacja cen oraz kolumna i masowa zmiana stanu. **Problem:** obraz nie definiuje właściciela danych, netto/brutto, walut ani źródła ilości.

**Propozycja:** macierz źródeł per pole i konto; cennik jako jawnie wersjonowane źródło po decyzji o agregacie; import → podgląd → akceptacja; tabela korzysta z projekcji określonego kontekstu. **Alternatywa:** cena wyłącznie na Ofercie, bez lokalnych Cenników — nie pokrywa pełnego wymaganego importu i wymaga uzasadnionego modelu cenników zewnętrznych. **Otwarte:** relacje Cennika, podatki, reguły marży i zaokrągleń, rezerwacje i magazyn. **Dowody:** model sekcja 9, testy duplikatów, konfliktu i walut. **Bramka:** przed utrwaleniem rozszerzeń cen/ilości.

### ADR-014 — media i wersjonowane układy ofert

**Status:** proponowany. **Cel wymagany:** galeria, miniatury, kreator, szablony i kopiowanie układu. **Propozycja:** referencje zasobów oddzielone od pliku; ograniczona struktura układu, wersja i podgląd; wspólny edytor dla wszystkich wejść. **Alternatywa:** dokument HTML jako układ — trudniejsza walidacja i izolacja niebezpiecznych treści; wymaga ograniczenia i sanitacji.

**Otwarte:** nowe agregaty zasobów/szablonów, przechowywanie, usuwanie nieużywanych plików, snapshot czy referencja wersji, ograniczenia platform. **Dowody:** kopiowanie bez ID/ceny/konta; zmiana szablonu nie aktualizuje bez ostrzeżenia aktywnych Ofert; test uszkodzonego pliku i niebezpiecznej treści. **Bramka:** przed migracją i edytorem układów.

### ADR-015 — opisy AI jako propozycja do akceptacji

**Status:** proponowany sposób realizacji wymaganej funkcji AI. **Propozycja:** port aplikacyjny i adapter dostawcy; wybrane fakty Produktu → propozycja tekstu → porównanie i akceptacja → aktualizacja wskazanego opisu. Bez bezpośredniej publikacji i bez sekretów w promptach. **Alternatywy:** model lokalny albo zewnętrzny; nie wybrano dostawcy.

**Otwarte:** model, koszty, limity, warunki przekazywania danych, retencja i możliwość działania offline. **Dowody:** odrzucenie nie zmienia domeny; brak AI daje czytelny stan konfiguracji; treść produktu udająca polecenie nie uruchamia narzędzi i publikacji; test niepotwierdzonych twierdzeń. **Bramka:** przed podłączeniem dostawcy i przesyłaniem danych.

### ADR-016 — dashboard jako spójne projekcje danych

**Status:** proponowany. **Cel wymagany:** KPI, wykres, ostatnie Produkty/Operacje i stany integracji. **Propozycja:** niezależne modele odczytu za portami przypadków użycia, z zakresem i czasem aktualizacji. Wielokontowy status Ofert jest projekcją, nie flagą Produktu. **Alternatywa:** jeden duży synchroniczny odczyt — zwiększa sprzężenie i ryzyko blokowania panelu.

**Otwarte:** metryka osi Y, zakres dat, znaczenie zmian procentowych, częstotliwość odświeżania i deduplikacja błędów. **Dowody:** brak danych nie udaje zera sprzedaży; brak mianownika nie daje procentu; awaria jednej platformy nie daje globalnego „Połączono”; nie mieszać walut; dostępna tabela pod wykresem. **Bramka:** przed funkcjonalnym odbiorem dashboardu i analityki.

## 10. Nowe napięcia i wymagania

| ID | Zagadnienie | Rozstrzygnięcie / dalszy krok |
|---|---|---|
| W-11 | Wygląd i opcje UI-REF-01 | Wymagane przez użytkownika; specyfikacja UI sekcje 15–23 |
| W-12 | Allegro i PrestaShop na ekranie | Obie integracje są w zakresie; kolejność wdrożenia nadal otwarta |
| K-06 | Pusta instalacja vs zapełniony dashboard wzorca | W produkcji pusto, test wizualny na izolowanych danych; układ pozostaje taki sam |
| K-07 | 16 bytów vs nowe pojęcia Cennika/mediów/szablonu | Zachować 16 głównych bytów; kandydatury nowych agregatów jawne w ADR-013/014 |
| K-08 | Dokładne menu wzorca vs dostęp do pozostałych bytów | Wymagane menu główne; proponowane zakładki drugiego poziomu, bez usuwania obszarów |
| K-09 | Etykiety 5.0, Python 3.10.12, 2 req/s i VexLabs vs realne metadane | Wzorzec położenia i stylu; wartości pochodzą z faktycznej konfiguracji, nie seedów |
| K-10 | Zielone kropki platform vs wiele kont i nieznany stan | Status zbiorczy z jawnymi szczegółami, stanem mieszanym/nieznanym |

K-06 i K-09 rozstrzygnięto dokumentacyjnie bez zmiany pustej instalacji i bez przejmowania danych z obrazu. Szczegółowy model K-07/08/10 jest propozycją powiązaną z odpowiednimi ADR. Brak tych rozstrzygnięć technicznych nie jest powodem do zastąpienia wymaganego wyglądu innym projektem.

## 11. Decyzje bieżącego przyrostu — 2026-11-02

| ID | Status i zakres | Pełna treść |
|---|---|---|
| ADR-001 / P-01 / K-01 | Odwracalna decyzja techniczna Codex na podstawie delegacji użytkownika; graf sześciu warstw i zewnętrzny bootstrap | [Granice](docs/adr/ADR-001-granice-warstw.md) |
| ADR-011 / P-11 | Lokalnie zweryfikowano 3.12.14/uv 0.12.23; rekomendacja dalsza: szereg 3.13, dokładny pin i Windows nadal otwarte | [Środowisko](docs/adr/ADR-011-srodowisko.md) |
| ADR-017 | Bezpośrednie polecenie właściciela: etapy 1–2, zastępujące dokumentacyjny zakres W-09 | [Zakres](docs/adr/ADR-017-zakres-pracy.md) |
| ADR-018 | Bezpośrednie polecenie właściciela: marka VexLab i nazwa użytkownika w profilu | [Nazwa](docs/adr/ADR-018-nazwa-i-uzytkownik.md) |

Q-01 jest spełnione przez istniejące repozytorium. Pozostałe modelowe P/Q/K
zachowują status propozycji; wdrożenie fundamentu nie stanowi ich akceptacji.
Nie wybrano właściciela cen, modelu magazynu, AI, zasad retencji ani licencji
produktu. Windows 11 x64 jest rekomendacją developerską; docelowa macierz
użytkowników wymaga uzgodnienia przed dystrybucją.

## 12. Przyrost lokalnego katalogu i GUI — 2026-11-02

| ID | Status i zakres | Treść |
|---|---|---|
| ADR-019 | Rozpatrzona konkretna propozycja pierwszego katalogu | [Scenariusz](docs/adr/ADR-019-pierwszy-katalog-propozycja.md) |
| ADR-020 | Wdrożony katalog; decyzje właściciela: SKU obowiązkowe, unikalne, ignoruje wielkość liter | [Katalog i SQLite](docs/adr/ADR-020-lokalny-katalog-i-sqlite.md) |
| ADR-021 | Wdrożona powłoka i odwracalne decyzje GUI; pełny odbiór UI otwarty | [Powłoka](docs/adr/ADR-021-powloka-vexlab.md) |

ADR-011 uaktualniono po rzeczywistej instalacji i testach Pythona 3.13.18,
PySide6 6.12.0 i uv 0.13.6. Odbiór na Windows pozostaje niewykonany.
P-04/P-08 są rozstrzygnięte technicznie tylko dla opisanego pierwszego
lokalnego Produktu i schematu 1; inne agregaty i relacje nie są zatwierdzone.

## 13. Producenci i opcjonalne przypisanie — 2026-11-02

[ADR-022](docs/adr/ADR-022-producenci-propozycja.md): właściciel wybrał
zero lub jednego producenta na Produkt. Wdrożono lokalny rejestr, edycję,
dezaktywację bez usuwania powiązań, wybór w Produkcie i migrację 1→2
z kopią. Nazwy nie stanowią globalnego klucza organizacji. Pozostałe relacje
Produktu i role Dostawca/GPSR nadal nie są rozstrzygnięte.

## 14. Kontynuacja 0.4 — 2026-11-02

- [ADR-023](docs/adr/ADR-023-przyszle-integracje.md): odłożone integracje, wspólny katalog i przyszłe przenoszenie Allegro → PrestaShop; kurierzy pozostają osobnym obszarem.
- [ADR-024](docs/adr/ADR-024-przeglad-i-eksport-katalogu.md): odwracalne decyzje techniczne przeglądu i CSV, bez nowych reguł modelu.

## 15. Przyszłe przekazywanie dokumentów — 2026-11-02

[ADR-025](docs/adr/ADR-025-dokumenty-subiekt-allegro.md): wymaganie właściciela
dotyczące łącznika Subiekt → Allegro po wydruku faktury/paragonu, bez trwałego
archiwum dokumentów. Wdrożenie odłożone; mechanizm wydruku, możliwości API
i zasady stanu technicznego wymagają weryfikacji przed realizacją.

## 16. Import paczki Produktów — 2026-11-02

[ADR-026](docs/adr/ADR-026-import-paczki-produktow-propozycja.md): właściciel
chce import wielu Produktów np. z cennika producenta, z wyborem Producenta.
Przygotowano konkretną propozycję procesu i bezpiecznego pierwszego zakresu;
przykładowy XLSX przeanalizowano, a właściciel zaakceptował jawne wykluczanie
konfliktów w podglądzie. Potwierdzono także uniwersalny zakres asortymentu;
dane cenowe i model dopasowań do pojazdów pozostają otwarte.
Minimalny zakres importu wdrożono w 0.5 zgodnie z ADR-027.

Właściciel uzupełnił ADR-026 o osobną listę „Do poprawy”: wykluczone wiersze
pozostają dostępne do późniejszej korekty i przypisania, także po restarcie.
Jest to etap importu, bez automatycznego nadpisywania gotowych Produktów.

Następny wolny numer: ADR-041.

Uzupełnienie ADR-023/026, 2026-11-02: właściciel wymaga przekazywania
lokalnych dopasowań do motocykli do PrestaShop i Allegro. Model szczegółowy
i mapowania pozostają do zaprojektowania; wymaganie nie oznacza wdrożenia.

Uzupełnienie ADR-023, 2026-11-02: właściciel zaakceptował pobieranie kategorii
z docelowego sklepu PrestaShop przy wysyłaniu ofert oraz rozdzielenie
kategorii sklepu i wspólnych dopasowań do motocykli. Funkcja niewdrożona.

## 17. Wdrożony import lokalny — 2026-11-02

[ADR-027](docs/adr/ADR-027-import-xlsx-i-bufor-korekt.md): przyrost 0.5,
XLSX/CSV, mapowanie kolumn, wybór producenta, atomowy zapis paczki, trwała
lista Do poprawy i jawne powiązanie zgodnego SKU bez nadpisywania Produktu.
Schemat 3 z kopią przed migracją. Nie wdraża cen ani dopasowań do pojazdów.

## 18. Katalogi partnerów przez API — 2026-11-02

[ADR-028](docs/adr/ADR-028-katalogi-api-dostawcow-i-producentow.md): wymaganie
właściciela pobierania baz produktów dostawców i producentów przez API.
Wdrożenie wymaga wskazania pierwszego partnera i jego kontraktu API;
nie rozszerza automatycznie zakresu o ceny i synchronizację magazynów.

## 19. Opisy, wielowalutowe ceny sugerowane i tłumaczenia — 2026-11-02

[ADR-029](docs/adr/ADR-029-opis-waluty-i-tlumaczenie.md): w 0.5.2 wdrożono
łączenie źródeł opisu i pełny podgląd. Właściciel potwierdził sugerowane
ceny sprzedaży oraz wskazał OpenAI API; koszt nie został zaakceptowany,
więc podłączenie płatnego API jest wstrzymane. Ceny nadal nie są importowane.

## 20. Przyrost 0.6 — 2026-11-02

- [ADR-030](docs/adr/ADR-030-ceny-sugerowane-i-czyszczenie.md): sugerowane ceny źródłowe,
  uzupełnianie braków po SKU, czyszczenie migawki z kopią i transakcją.
- [ADR-031](docs/adr/ADR-031-zdjecia-strony-producenta.md): adres jako dane użytkownika,
  kandydaci zdjęć po dokładnym SKU przez publiczny katalog Shopify, bez zaszytej domeny.
- Wielokrotny wybór i pierwsza masowa edycja producenta/opisu, z kopią i kontrolą wersji.

0.6 obejmuje również poprawkę opisu przygotowaną roboczo jako 0.5.2;
nie wydano jej osobno. AI nadal wstrzymane bez uzgodnionego kosztu.

## 21. Lokalna galeria — 2026-11-03

[ADR-032](docs/adr/ADR-032-lokalna-galeria-produktu.md): lokalne pliki,
podgląd, kolejność i usuwanie, z kopią oraz kontrolą wersji. Schemat 4 bez zmian.


## 22. Dopasowania do motocykli — zaakceptowane 2026-11-03

[ADR-033](docs/adr/ADR-033-dopasowania-motocykli-propozycja.md): opcjonalna
lista zero–wiele przy Produkcie, marka/model, roczniki i wariant.
Właściciel zaakceptował model odpowiedzią „tak” w rozmowie.
Wdrożenie 0.8: typ wartości Produktu, edytor, podgląd i migracja 4→5 z kopią.


## 23. Import dopasowań — 2026-11-03

[ADR-034](docs/adr/ADR-034-import-dopasowan.md): jawne mapowanie kolumn
modelu zatwierdzonego w ADR-033, podgląd i surowe dane w Do poprawy.
Schemat 6, bez nowych relacji modelowych lub automatycznego scalania SKU.


## 24. Lokalne szkice — propozycja

[ADR-035](docs/adr/ADR-035-lokalne-szkice-ofert-propozycja.md): konkretna
propozycja pierwszego zakresu Oferty, do decyzji właściciela. Bez zapisu
niezatwierdzonego modelu. Wymagany audyt 1.0 opisuje odrębny plan w roadmapie.


## 25. Gotowe oferty w ZIP — wymaganie właściciela

[ADR-036](docs/adr/ADR-036-paczki-gotowych-ofert-zip.md): osobny import
paczek gotowych ofert, format ZIP potwierdzony 2026-11-03. Struktura wewnętrzna
wymaga przykładu; funkcja niewdrożona. Nie utożsamiać z importem cennika.


## 26. Podgląd ZIP i profil użytkownika — 0.10

[ADR-037](docs/adr/ADR-037-podglad-zip-profile-i-logo.md): działający odczyt
i podgląd mapowanego JSON w ZIP, pliki profili użytkownika, bez migracji
i publikacji. Logo i paleta na jawne polecenie właściciela.
Docelowa wysyłka z ustawieniami wymaganymi przez API Allegro pozostaje
wymaganiem całego procesu (uzupełnienie ADR-036), nie wykonaniem tego wydania.


## 27. Zapamiętywanie układów — 0.11

[ADR-038](docs/adr/ADR-038-zapamietywanie-ukladow-paczek.md): uzgodnione
profile jako ustawienia użytkownika, rozpoznawanie po restarcie i uproszczony UI.
Bez zmiany schematu 6.

## 28. Cena odniesienia i kanały — wymagania 2026-11-04

[ADR-039](docs/adr/ADR-039-ceny-bazowe-i-kanalow.md): źródło bazowe wybrane
przez właściciela — aktualny cennik producenta. Ceny Allegro/PrestaShop
z API, kolory i różnice względem bazowej. Integracje nadal niewdrożone;
nie dodano pozornych odczytów lub cen.


## 29. Lokalna Oferta — zatwierdzenie 2026-11-05

[ADR-035](docs/adr/ADR-035-lokalne-szkice-ofert-propozycja.md) zatwierdzone
przez właściciela w zakresie 0.12 ZIP → trwałe szkice; relacja jeden
Produkt na szkic, wiele szkiców Produktu. Docelowo wysyłka do szkiców
Allegro, publikacja osobną akcją; integracja nadal przyszła.


## 30. Wizualny opis i sekcje — 0.13

[ADR-040](docs/adr/ADR-040-wizualny-edytor-opisu.md): polecenie właściciela
2026-11-05, opis z formatowaniem i edycja przez przeciąganie. Zapis w
istniejącym szkicu bez migracji schematu 7 i bez nadpisania Produktu.

- [ADR-041 — biblioteka cenników](docs/adr/ADR-041-biblioteka-cennikow.md).
- [ADR-042 — zdjęcia i podgląd oferty](docs/adr/ADR-042-podglad-oferty.md).

- [ADR-043 — porównanie i aktualność cenników](docs/adr/ADR-043-porownanie-i-status-cennikow.md).

- [ADR-044 — usuwanie Produktów ze szkicami](docs/adr/ADR-044-usuwanie-produktow-ze-szkicami.md).

- [ADR-045 — EAN w cenniku](docs/adr/ADR-045-ean-w-cenniku.md).

- [ADR-046 — aktualizacje cenników i preferencje](docs/adr/ADR-046-aktualizacje-cennikow-i-preferencje.md).

- [ADR-047 — profile układów cenników](docs/adr/ADR-047-profile-cennikow.md).

- [ADR-048 — szkice bez zakładania Produktów](docs/adr/ADR-048-szkice-bez-zakladania-produktow.md).

- [ADR-049 — miniatury katalogu na żądanie](docs/adr/ADR-049-miniatury-na-zadanie.md).

- [ADR-050 — stronicowany odczyt katalogu](docs/adr/ADR-050-strony-katalogu.md).

- [ADR-051 — strony pozycji Cennika](docs/adr/ADR-051-strony-cennika.md).

- [ADR-052 — przygotowanie odczytu GT](docs/adr/ADR-052-przygotowanie-odczytu-gt.md).

- [ADR-053 — sesja Allegro](docs/adr/ADR-053-sesja-allegro.md).
