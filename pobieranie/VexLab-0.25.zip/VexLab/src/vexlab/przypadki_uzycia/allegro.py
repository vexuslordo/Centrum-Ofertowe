"""Sesja Allegro w pamięci: autoryzacja urządzenia i odczyt szkiców."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol

from vexlab.rdzen.kontrakty import BladTechniczny


class SrodowiskoAllegro(Enum):
    PRODUKCJA = "Allegro"
    SANDBOX = "Allegro Sandbox"


class BladAllegro(BladTechniczny):
    def __init__(self, kod: str, komunikat: str) -> None:
        super().__init__(komunikat)
        self.kod = kod


@dataclass(frozen=True)
class AplikacjaAllegro:
    klient: str
    sekret: str = field(repr=False)
    srodowisko: SrodowiskoAllegro = SrodowiskoAllegro.PRODUKCJA

    def sprawdz(self) -> None:
        if not self.klient or not self.sekret or len(self.klient) > 512 or len(self.sekret) > 1024:
            raise BladAllegro("KONFIGURACJA", "Podaj Client ID i Client Secret aplikacji Allegro.")
        if any(ord(c) < 33 for c in self.klient + self.sekret) or ":" in self.klient:
            raise BladAllegro("KONFIGURACJA", "Dane aplikacji zawierają niedozwolone znaki.")


@dataclass(frozen=True)
class KodUrzadzenia:
    kod: str = field(repr=False)
    kod_uzytkownika: str = field(repr=False)
    adres: str = field(repr=False)
    waznosc: int
    odstep: int


@dataclass(frozen=True)
class TokenAllegro:
    wartosc: str = field(repr=False)
    waznosc: int


@dataclass(frozen=True)
class KontoAllegro:
    id: str
    login: str


@dataclass(frozen=True)
class SesjaAllegro:
    konto: KontoAllegro
    srodowisko: SrodowiskoAllegro
    token: str = field(repr=False)
    wygasa: float


@dataclass(frozen=True)
class SzkicAllegro:
    id: str
    tytul: str


@dataclass(frozen=True)
class StronaSzkicowAllegro:
    szkice: tuple[SzkicAllegro, ...]
    lacznie: int
    offset: int
    limit: int


class APISesjiAllegro(Protocol):
    def rozpocznij(self, aplikacja: AplikacjaAllegro) -> KodUrzadzenia: ...
    def token(self, aplikacja: AplikacjaAllegro, kod: str) -> TokenAllegro: ...
    def konto(self, srodowisko: SrodowiskoAllegro, token: str) -> KontoAllegro: ...
    def szkice(self, sesja: SesjaAllegro, offset: int, limit: int) -> StronaSzkicowAllegro: ...


class CzasMonotoniczny(Protocol):
    def teraz(self) -> float: ...


class PolaczAllegro:
    def __init__(self, api: APISesjiAllegro, czas: CzasMonotoniczny) -> None:
        self._api, self._czas = api, czas

    def teraz(self) -> float:
        return self._czas.teraz()

    def rozpocznij(self, aplikacja: AplikacjaAllegro) -> KodUrzadzenia:
        aplikacja.sprawdz()
        return self._api.rozpocznij(aplikacja)

    def sprawdz(self, aplikacja: AplikacjaAllegro, kod: str) -> SesjaAllegro:
        aplikacja.sprawdz()
        token = self._api.token(aplikacja, kod)
        wygasa = self.teraz() + token.waznosc
        konto = self._api.konto(aplikacja.srodowisko, token.wartosc)
        if self.teraz() >= wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        return SesjaAllegro(konto, aplikacja.srodowisko, token.wartosc, wygasa)

    def szkice(self, sesja: SesjaAllegro, offset: int = 0, limit: int = 50) -> StronaSzkicowAllegro:
        if self.teraz() >= sesja.wygasa:
            raise BladAllegro("WYGASLA", "Sesja wygasła. Połącz konto ponownie.")
        if limit != 50 or offset < 0 or offset > 9950 or offset % limit:
            raise BladAllegro("STRONA", "Nieprawidłowa strona szkiców Allegro.")
        return self._api.szkice(sesja, offset, limit)


@dataclass(frozen=True)
class OdpowiedzAllegro:
    status: int
    dane: bytes = field(repr=False)


class TransportAllegro(Protocol):
    def wyslij(
        self, metoda: str, url: str, naglowki: dict[str, str], dane: bytes | None
    ) -> OdpowiedzAllegro: ...
