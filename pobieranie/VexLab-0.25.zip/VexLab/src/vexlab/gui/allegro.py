"""Połączenie konta na bieżącą sesję i stronicowany odczyt szkiców Allegro."""

from typing import cast

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KodUrzadzenia,
    PolaczAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StronaSzkicowAllegro,
)


class StronaAllegro(QWidget):
    stan = Signal(str)

    def __init__(self, serwis: PolaczAllegro, uruchom: Uruchom) -> None:
        super().__init__()
        self.serwis, self.uruchom = serwis, uruchom
        self.aplikacja: AplikacjaAllegro | None = None
        self.kod: KodUrzadzenia | None = None
        self.sesja: SesjaAllegro | None = None
        self.generacja = 0
        self.trwa = False
        self.koniec = 0.0
        self.odstep = 5
        self.offset = 0
        self.lacznie = 0
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self._sprawdz)
        self.wygasanie = QTimer(self)
        self.wygasanie.setInterval(1000)
        self.wygasanie.timeout.connect(self._waznosc)
        layout = QVBoxLayout(self)
        tytul = QLabel("Allegro")
        tytul.setObjectName("marka")
        layout.addWidget(tytul)
        opis = QLabel(
            "Połącz konto i pobierz szkice. Dane aplikacji i token pozostają tylko "
            "w pamięci do rozłączenia lub zamknięcia programu."
        )
        opis.setWordWrap(True)
        layout.addWidget(opis)
        form = QFormLayout()
        self.srodowisko = QComboBox()
        for s in SrodowiskoAllegro:
            self.srodowisko.addItem(s.value, s)
        form.addRow("Środowisko", self.srodowisko)
        self.klient = QLineEdit()
        self.klient.setMaxLength(512)
        self.klient.setAccessibleName("Client ID aplikacji Allegro")
        form.addRow("Client ID", self.klient)
        self.sekret = QLineEdit()
        self.sekret.setMaxLength(1024)
        self.sekret.setEchoMode(QLineEdit.EchoMode.Password)
        self.sekret.setAccessibleName("Client Secret aplikacji Allegro")
        form.addRow("Client Secret", self.sekret)
        layout.addLayout(form)
        self.podpowiedz = QLabel(
            "Aplikacja Allegro musi obsługiwać Device Flow (aplikacja bez dostępu do "
            "przeglądarki). Do tej wersji potrzebne są uprawnienia odczytu profilu "
            "i ofert: allegro:api:profile:read oraz allegro:api:sale:offers:read."
        )
        self.podpowiedz.setWordWrap(True)
        layout.addWidget(self.podpowiedz)
        buttons = QHBoxLayout()
        self.polacz = QPushButton("Połącz konto")
        self.polacz.clicked.connect(self.rozpocznij)
        self.otworz = QPushButton("Otwórz zgodę w Allegro")
        self.otworz.clicked.connect(self._otworz)
        self.otworz.setEnabled(False)
        self.rozlacz = QPushButton("Anuluj / rozłącz")
        self.rozlacz.clicked.connect(self.anuluj)
        self.rozlacz.setEnabled(False)
        for b in (self.polacz, self.otworz, self.rozlacz):
            buttons.addWidget(b)
        layout.addLayout(buttons)
        self.info = QLabel("Konto niepołączone.")
        self.info.setTextFormat(Qt.TextFormat.PlainText)
        self.info.setWordWrap(True)
        self.info.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.info)
        actions = QHBoxLayout()
        self.odswiez = QPushButton("Pobierz szkice")
        self.odswiez.clicked.connect(lambda: self.pobierz(0))
        self.poprzednia = QPushButton("Poprzednia")
        self.poprzednia.clicked.connect(lambda: self.pobierz(self.offset - 50))
        self.nastepna = QPushButton("Następna")
        self.nastepna.clicked.connect(lambda: self.pobierz(self.offset + 50))
        for b in (self.odswiez, self.poprzednia, self.nastepna):
            actions.addWidget(b)
        self.zakres = QLabel("Nie pobrano szkiców.")
        self.zakres.setWordWrap(True)
        actions.addWidget(self.zakres, 1)
        layout.addLayout(actions)
        self.tabela = QTableWidget(0, 2)
        self.tabela.setHorizontalHeaderLabels(["ID Allegro", "Tytuł szkicu"])
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setAccessibleName("Szkice na połączonym koncie Allegro")
        layout.addWidget(self.tabela, 1)
        footer = QLabel(
            "Lista z Allegro jest oddzielna od lokalnych szkiców. Ten etap odczytuje "
            "oferty INACTIVE (do 10 000 wyników); edycja i zapis zdalnych szkiców "
            "będą kolejnym krokiem."
        )
        footer.setWordWrap(True)
        layout.addWidget(footer)
        self._przyciski()

    def _przyciski(self) -> None:
        self.polacz.setEnabled(not self.trwa and self.aplikacja is None and self.sesja is None)
        self.odswiez.setEnabled(self.sesja is not None and not self.trwa)
        self.poprzednia.setEnabled(self.odswiez.isEnabled() and self.offset > 0)
        self.nastepna.setEnabled(
            self.odswiez.isEnabled() and self.offset + 50 < self.lacznie and self.offset < 9950
        )
        editable = self.aplikacja is None and self.sesja is None and not self.trwa
        for w in (self.klient, self.sekret, self.srodowisko):
            w.setEnabled(editable)

    def rozpocznij(self) -> None:
        if not self.polacz.isEnabled():
            return
        a = AplikacjaAllegro(
            self.klient.text().strip(),
            self.sekret.text(),
            cast(SrodowiskoAllegro, self.srodowisko.currentData()),
        )
        self.sekret.clear()
        self.aplikacja = a
        self.generacja += 1
        gen = self.generacja
        self.trwa = True
        self.rozlacz.setEnabled(True)
        self.info.setText("Pobieranie kodu zgody z Allegro…")
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            self.trwa = False
            self.kod = cast(KodUrzadzenia, wynik)
            self.koniec = self.serwis.teraz() + self.kod.waznosc
            self.odstep = self.kod.odstep
            self.otworz.setEnabled(True)
            self.info.setText(
                f"Otwórz zgodę w Allegro i zatwierdź konto. Kod: {self.kod.kod_uzytkownika}"
            )
            self.timer.start(self.odstep * 1000)
            self._przyciski()

        self.uruchom(lambda: self.serwis.rozpocznij(a), gotowe, lambda k, m: self._blad(gen, k, m))

    def _otworz(self) -> None:
        if (
            self.kod is not None
            and self.otworz.isEnabled()
            and not QDesktopServices.openUrl(QUrl(self.kod.adres))
        ):
            self.info.setText("Nie można otworzyć przeglądarki. Spróbuj ponownie.")

    def _sprawdz(self) -> None:
        a, kod, gen = self.aplikacja, self.kod, self.generacja
        if a is None or kod is None or self.trwa:
            return
        if self.serwis.teraz() >= self.koniec:
            self._blad(gen, "WYGASLA", "Kod zgody wygasł. Połącz konto ponownie.")
            return
        self.trwa = True

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            self.sesja = cast(SesjaAllegro, wynik)
            self.aplikacja, self.kod = None, None
            self.trwa = False
            self.otworz.setEnabled(False)
            self.info.setText(
                f"Połączono: {self.sesja.konto.login} • {self.sesja.srodowisko.value}. "
                "Sesja zostanie zakończona po zamknięciu programu."
            )
            self.stan.emit(f"Allegro: {self.sesja.konto.login}")
            self.wygasanie.start()
            self._przyciski()
            self.pobierz(0)

        self.uruchom(
            lambda: self.serwis.sprawdz(a, kod.kod), gotowe, lambda k, m: self._blad(gen, k, m)
        )

    def _blad(self, gen: int, kod: str, komunikat: str) -> None:
        if gen != self.generacja:
            return
        self.trwa = False
        if self.aplikacja is not None and kod in {"OCZEKIWANIE", "WOLNIEJ"}:
            if kod == "WOLNIEJ":
                self.odstep = min(3600, self.odstep + 5)
            self.timer.start(self.odstep * 1000)
            return
        if self.aplikacja is not None or kod in {"WYGASLA", "AUTORYZACJA"}:
            self.anuluj()
        self.info.setText(komunikat)
        self._przyciski()

    def pobierz(self, offset: int = 0) -> None:
        sesja, gen = self.sesja, self.generacja
        if sesja is None or self.trwa:
            return
        self.trwa = True
        # Poprzednia strona nie udaje aktualnego wyniku po nieudanym odczycie.
        self.tabela.setRowCount(0)
        self.lacznie = 0
        self.zakres.setText("Pobieranie szkiców…")
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            strona = cast(StronaSzkicowAllegro, wynik)
            self.trwa = False
            self.offset, self.lacznie = strona.offset, strona.lacznie
            self.tabela.setRowCount(len(strona.szkice))
            for row, p in enumerate(strona.szkice):
                self.tabela.setItem(row, 0, QTableWidgetItem(p.id))
                self.tabela.setItem(row, 1, QTableWidgetItem(p.tytul))
            self.zakres.setText(
                f"{strona.offset + 1}–{strona.offset + len(strona.szkice)} z {strona.lacznie}"
                if strona.szkice
                else "Brak szkiców na tej stronie."
            )
            self._przyciski()

        def blad(kod: str, komunikat: str) -> None:
            if gen == self.generacja:
                self.zakres.setText("Nie pobrano szkiców. Ponów odczyt.")
            self._blad(gen, kod, komunikat)

        self.uruchom(lambda: self.serwis.szkice(sesja, offset), gotowe, blad)

    def _waznosc(self) -> None:
        if self.sesja is not None and self.serwis.teraz() >= self.sesja.wygasa:
            self.anuluj()
            self.info.setText("Sesja wygasła. Połącz konto ponownie.")

    def anuluj(self) -> None:
        self.generacja += 1
        self.timer.stop()
        self.wygasanie.stop()
        self.aplikacja, self.kod, self.sesja = None, None, None
        self.sekret.clear()
        self.trwa = False
        self.otworz.setEnabled(False)
        self.rozlacz.setEnabled(False)
        self.tabela.setRowCount(0)
        self.offset, self.lacznie = 0, 0
        self.zakres.setText("Nie pobrano szkiców.")
        self.info.setText("Konto niepołączone. Lokalną sesję usunięto z pamięci aplikacji.")
        self.stan.emit("Allegro: niepołączone")
        self._przyciski()
