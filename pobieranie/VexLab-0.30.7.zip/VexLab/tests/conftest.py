"""Wspólne izolowane fixture'y; nigdy nie są ładowane przez aplikację."""

import pytest

from vexlab.przypadki_uzycia.katalog import DaneProduktu


@pytest.fixture
def stare_powiazania():
    """Odtwarza relacje istniejące przed 0.20, do testów ich dalszej ochrony."""

    def powiaz(serwis, katalog, repo):
        for d in serwis.lista():
            if d.produkt_id is not None:
                continue
            produkt = next(
                (p for p in katalog.wyszukaj() if p.sku.casefold() == d.oferta.sku.casefold()), None
            )
            if produkt is None:
                produkt = katalog.dodaj(DaneProduktu(d.oferta.tytul, d.oferta.sku))
            with repo._polaczenie() as conn:
                conn.execute(
                    "UPDATE szkice SET produkt_id=?,wersja_produktu=? WHERE id=?",
                    (str(produkt.id), produkt.wersja, str(d.id)),
                )

    return powiaz
