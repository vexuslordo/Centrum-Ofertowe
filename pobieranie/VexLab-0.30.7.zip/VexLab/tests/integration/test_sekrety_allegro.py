import ctypes
import json
from dataclasses import replace

import pytest

from vexlab.adaptery import sekrety_allegro as m
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    BladAllegro,
    KontoAllegro,
    SrodowiskoAllegro,
    ZapamietaneAllegro,
)


class SzyfratorTestowy:
    """Wyłącznie fixture transportu: nie jest implementacją ochrony danych."""

    def zaszyfruj(self, b):
        return b"fixture:" + bytes(x ^ 0xAA for x in b)

    def odszyfruj(self, b):
        assert b.startswith(b"fixture:")
        return bytes(x ^ 0xAA for x in b[8:])


def dane():
    return ZapamietaneAllegro(
        AplikacjaAllegro("test-client", "test-secret", SrodowiskoAllegro.SANDBOX),
        KontoAllegro("123", "testowy"),
        "test-refresh",
    )


def test_odczyt_zapis_usuwa_tylko_polaczenie_i_nie_pisze_jawnych_danych(tmp_path):
    p = tmp_path / "polaczenia" / "allegro.dpapi"
    magazyn = m.SekretyAllegro(p, SzyfratorTestowy())
    assert magazyn.odczytaj() is None
    magazyn.zapisz(dane())
    assert magazyn.odczytaj() == dane()
    assert all(x not in p.read_bytes() for x in (b"test-secret", b"test-refresh", b"test-client"))
    assert list(p.parent.iterdir()) == [p]
    magazyn.usun()
    magazyn.usun()
    assert magazyn.odczytaj() is None


def test_nieudane_szyfrowanie_nie_tworzy_pliku(tmp_path):
    class Odmowa(SzyfratorTestowy):
        def zaszyfruj(self, b):
            raise BladAllegro("MAGAZYN", "Odmowa Windows")

    p = tmp_path / "allegro.dpapi"
    with pytest.raises(BladAllegro):
        m.SekretyAllegro(p, Odmowa()).zapisz(dane())
    assert not list(tmp_path.iterdir())


def test_awaria_atomowego_zapisu_zachowuje_poprzedni_i_czysci_temp(tmp_path, monkeypatch):
    p = tmp_path / "allegro.dpapi"
    magazyn = m.SekretyAllegro(p, SzyfratorTestowy())
    magazyn.zapisz(dane())
    before = p.read_bytes()

    def odmowa(*a):
        raise PermissionError("PRYWATNE")

    monkeypatch.setattr(m.os, "replace", odmowa)
    with pytest.raises(BladAllegro) as e:
        magazyn.zapisz(replace(dane(), odswiezanie="nowy"))
    assert "PRYWATNE" not in str(e.value)
    assert p.read_bytes() == before and list(tmp_path.iterdir()) == [p]


@pytest.mark.parametrize(
    "payload", [{}, {"wersja": True}, {"wersja": 2}, {"wersja": 1, "sekret": "PRYWATNE"}]
)
def test_uszkodzony_dokument_bez_udawania_polaczenia(tmp_path, payload):
    p = tmp_path / "allegro.dpapi"
    szyfr = SzyfratorTestowy()
    p.write_bytes(szyfr.zaszyfruj(json.dumps(payload).encode()))
    with pytest.raises(BladAllegro) as e:
        m.SekretyAllegro(p, szyfr).odczytaj()
    assert "PRYWATNE" not in str(e.value)


def test_odmowa_odszyfrowania_nie_ma_plaintext_fallback(tmp_path):
    class Odmowa(SzyfratorTestowy):
        def odszyfruj(self, b):
            raise BladAllegro("MAGAZYN", "Inny użytkownik")

    p = tmp_path / "allegro.dpapi"
    p.write_text('{"wersja":1,"sekret":"PRYWATNE"}')
    with pytest.raises(BladAllegro):
        m.SekretyAllegro(p, Odmowa()).odczytaj()
    assert p.exists()


def test_limit_odczytu_i_blad_usuwania(tmp_path, monkeypatch):
    p = tmp_path / "allegro.dpapi"
    p.write_bytes(b"x" * (m.LIMIT + 1))
    magazyn = m.SekretyAllegro(p, SzyfratorTestowy())
    with pytest.raises(BladAllegro):
        magazyn.odczytaj()

    def odmowa(*a, **k):
        raise PermissionError("PRYWATNE")

    monkeypatch.setattr(type(p), "unlink", odmowa)
    with pytest.raises(BladAllegro) as e:
        magazyn.usun()
    assert "PRYWATNE" not in str(e.value)


def test_dpapi_flaga_zakres_uzytkownika_typy_i_zwolnienie_bufora(monkeypatch):
    bufor = ctypes.create_string_buffer(b"wynik")
    calls = []

    class Fn:
        def __call__(self, inp, desc, entropy, res, prompt, flags, out):
            assert flags == 1 and entropy is None and prompt is None
            b = ctypes.cast(inp, ctypes.POINTER(m.Blob)).contents
            assert ctypes.string_at(b.dane, b.rozmiar) == b"wejscie"
            result = ctypes.cast(out, ctypes.POINTER(m.Blob)).contents
            result.rozmiar = 5
            result.dane = ctypes.cast(bufor, ctypes.POINTER(ctypes.c_ubyte))
            return 1

    class Free:
        def __call__(self, p):
            calls.append(True)

    class Crypt:
        CryptProtectData = Fn()
        CryptUnprotectData = Fn()

    class Kernel:
        LocalFree = Free()

    d = m.DPAPIWindows()
    monkeypatch.setattr(d, "_biblioteki", lambda: (Crypt(), Kernel()))
    assert d.zaszyfruj(b"wejscie") == b"wynik"
    assert calls == [True] and bufor.raw[:5] == b"\x00" * 5
    assert m.Blob.dane.offset in (4, 8)


def test_dpapi_odmowa_bez_fallback_i_zwalnia_ewentualny_bufor(monkeypatch):
    freed = []

    class Fn:
        def __call__(self, *a):
            return 0

    class Free:
        def __call__(self, *a):
            freed.append(True)

    class Crypt:
        CryptUnprotectData = Fn()

    class Kernel:
        LocalFree = Free()

    d = m.DPAPIWindows()
    monkeypatch.setattr(d, "_biblioteki", lambda: (Crypt(), Kernel()))
    with pytest.raises(BladAllegro, match="Windows"):
        d.odszyfruj(b"szyfr")
    assert freed == []


@pytest.mark.skipif(m.sys.platform != "win32", reason="Natywne DPAPI wymaga Windows")
def test_natywne_dpapi_odczyt_po_ponownym_utworzeniu_magazynu(tmp_path):
    p = tmp_path / "allegro.dpapi"
    m.SekretyAllegro(p, m.DPAPIWindows()).zapisz(dane())
    assert b"test-secret" not in p.read_bytes()
    assert m.SekretyAllegro(p, m.DPAPIWindows()).odczytaj() == dane()
