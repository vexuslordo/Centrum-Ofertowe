import sqlite3
from contextlib import closing
from dataclasses import replace
from uuid import UUID, uuid4

import pytest

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import KatalogProduktow, ZapytanieKatalogu


@pytest.fixture
def dane(tmp_path):
    repo = KatalogSQLite(tmp_path / "test.sqlite3")
    repo.wyszukaj("")
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.executemany(
            "INSERT INTO produkty(id,nazwa,sku,sku_klucz,opis,wersja) VALUES(?,?,?,?,?,1)",
            [
                (
                    str(UUID(int=i + 1)),
                    f"Produkt {i:04}",
                    f"SKU-{i:04}",
                    f"sku-{i:04}",
                    "opis" * 1000,
                )
                for i in range(350)
            ],
        )
    return repo, KatalogProduktow(repo, repo)


def test_strony_sa_rozlaczne_i_sortowane_globalnie_bez_starego_pelnego_odczytu(dane, monkeypatch):
    repo, case = dane
    monkeypatch.setattr(repo, "wyszukaj", lambda *a: pytest.fail("Pełny odczyt katalogu"))
    monkeypatch.setattr(repo, "miniatury", lambda: pytest.fail("Pełny odczyt obrazów"))
    strony = [case.strona(ZapytanieKatalogu(numer=n)) for n in range(4)]
    assert [len(s.produkty) for s in strony] == [100, 100, 100, 50]
    ids = [p.id for s in strony for p in s.produkty]
    assert len(ids) == len(set(ids)) == 350
    assert all(s.liczba == s.wszystkich == 350 for s in strony)
    assert strony[-1].produkty[-1].sku == "SKU-0349"
    odwrotnie = case.strona(ZapytanieKatalogu(malejaco=True))
    assert odwrotnie.produkty[0].sku == "SKU-0349"
    assert all(p.miniatura is None for s in strony for p in s.produkty)


def test_filtr_szukania_obejmuje_niewczytane_strony_i_traktuje_znaki_doslownie(dane):
    repo, case = dane
    assert case.strona(ZapytanieKatalogu(fraza="sku-0349")).produkty[0].sku == "SKU-0349"
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute("UPDATE produkty SET nazwa=? WHERE sku=?", ("ŻÓŁĆ %_ ' OR 1=1", "SKU-0349"))
    q = ZapytanieKatalogu(fraza="żółć %_ ' or 1=1", numer=999)
    strona = case.strona(q)
    assert strona.liczba == 1 and strona.numer == 0 and strona.wszystkich == 350
    assert len(case.wszystkie_wyniki(q)) == 1
    assert case.strona(replace(q, fraza="nie ma")).produkty == ()


def test_ostatnia_strona_koryguje_numer_a_wybor_odswieza_wersje_poza_strona(dane):
    repo, case = dane
    wybrany = UUID(int=350)
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute("UPDATE produkty SET wersja=2 WHERE id=?", (str(wybrany),))
    strona = case.strona(ZapytanieKatalogu(), (wybrany, uuid4()))
    assert len(strona.produkty) == 100
    assert len(strona.wybrane) == 1 and strona.wybrane[0].wersja == 2
    assert case.strona(ZapytanieKatalogu(numer=999)).numer == 3
    assert len(case.strona(ZapytanieKatalogu(rozmiar=250)).produkty) == 250


def test_filtry_zdjec_ceny_i_ean_obejmuja_caly_katalog_i_wybor(dane):
    repo, case = dane
    ident = UUID(int=350)
    with closing(sqlite3.connect(repo.plik)) as conn, conn:
        conn.execute("UPDATE produkty SET ean=? WHERE id=?", ("5901234123457", str(ident)))
        conn.execute(
            "INSERT INTO ceny_sugerowane VALUES(?,?,?,?,?)",
            (str(ident), "12.50", "PLN", "brutto", "test"),
        )
        conn.execute(
            "INSERT INTO zdjecia VALUES(?,?,?,?,?,?)",
            (
                str(uuid4()),
                str(ident),
                "test",
                b"foto",
                b"mini",
                0,
            ),
        )
    query = ZapytanieKatalogu(zdjecia=True, cena=True)
    strona = case.strona(query)
    assert strona.liczba == 1 and strona.produkty[0].id == ident
    assert len(case.wszystkie_wyniki(query)) == 1
    bez = case.strona(ZapytanieKatalogu(zdjecia=False, cena=False), (ident,))
    assert bez.liczba == 349 and bez.wybrane == ()
    assert case.strona(ZapytanieKatalogu(fraza="5901234123457")).produkty[0].id == ident


@pytest.mark.parametrize(
    "q",
    [
        ZapytanieKatalogu(numer=-1),
        ZapytanieKatalogu(rozmiar=999),
        ZapytanieKatalogu(producent="x"),
        ZapytanieKatalogu(kolumna=8),
    ],
)
def test_nieprawidlowe_zapytanie_nie_otwiera_bazy(tmp_path, q):
    repo = KatalogSQLite(tmp_path / "brak.sqlite3")
    with pytest.raises(BladScenariuszaKatalogu):
        KatalogProduktow(repo, repo).strona(q)
    assert not repo.plik.exists()
