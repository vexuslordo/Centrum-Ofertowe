"""Rozwijana grupa nawigacji; widoczność nie zmienia aktywnej strony."""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QSizePolicy, QToolButton, QVBoxLayout


class SekcjaMenu(QFrame):
    def __init__(self, nazwa: str) -> None:
        super().__init__()
        self.nazwa = nazwa.capitalize()
        self.setObjectName("sekcjaMenu")
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        self.uklad = layout
        self.belka = QToolButton()
        self.belka.setObjectName("grupaMenu")
        self.belka.setProperty("grupa", nazwa)
        self.belka.setText(self.nazwa)
        self.belka.setCheckable(True)
        self.belka.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.belka.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        layout.addWidget(self.belka)
        self.pozycje = QFrame()
        self.pozycje.setObjectName("pozycjeMenu")
        self.lista = QVBoxLayout(self.pozycje)
        self.lista.setContentsMargins(10, 0, 0, 12)
        self.lista.setSpacing(2)
        layout.addWidget(self.pozycje)

    def ustaw(self, rozwinieta: bool, kompakt: bool) -> None:
        self.belka.setChecked(rozwinieta)
        self.belka.setArrowType(Qt.ArrowType.DownArrow if rozwinieta else Qt.ArrowType.RightArrow)
        akcja = "Zwiń" if rozwinieta else "Rozwiń"
        self.belka.setAccessibleName(f"{akcja} grupę {self.nazwa}")
        self.belka.setToolTip(self.belka.accessibleName())
        self.belka.setVisible(not kompakt)
        self.pozycje.setVisible(kompakt or rozwinieta)
        self.uklad.setContentsMargins(0, 0, 0, 0 if kompakt else 2)
        self.lista.setContentsMargins(0 if kompakt else 10, 0, 0, 0 if kompakt else 12)
