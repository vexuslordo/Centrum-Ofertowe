# Znaki marek w menu VexLab

Źródło wektorów: Simple Icons, pobrane 2026-11-05.

- Allegro: https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/allegro.svg
  Adaptacja: pomarańczowy monogram „a” wyświetlany przez zawężenie pola
  widzenia logotypu. Nie jest przedstawiany jako osobny oficjalny favicon.
- PrestaShop: https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/prestashop.svg
  Adaptacja: kolor #DF0067, zachowana geometria znaku.

Repozytorium Simple Icons udostępnia wektory na CC0 1.0 Universal.
Pełny tekst: SIMPLE_ICONS_LICENSE.txt w tym katalogu. Nazwy i znaki marek
pozostają znakami ich właścicieli. Znaki służą oznaczeniu pozycji menu;
nie oznaczają aktywnej integracji lub partnerstwa.

Zasoby są lokalne i nie są pobierane przy uruchamianiu programu.
Pozostałe symbole menu są własnymi ścieżkami SVG VexLab, bez fontu ikon
lub dodatkowej biblioteki. Palety jasna i ciemna w design_system.py.
