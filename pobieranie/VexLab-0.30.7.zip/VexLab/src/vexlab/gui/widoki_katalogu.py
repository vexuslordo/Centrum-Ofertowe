"""Lista i kafelki współdzielą paginację, model oraz wybór tabeli źródłowej."""

from collections.abc import Callable

from PySide6.QtCore import (
    QEvent,
    QItemSelectionModel,
    QModelIndex,
    QPoint,
    QRect,
    QSize,
    Qt,
    Signal,
)
from PySide6.QtGui import QColor, QFont, QKeyEvent, QMouseEvent, QPainter, QPalette
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QHeaderView,
    QListView,
    QStackedWidget,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionButton,
    QStyleOptionViewItem,
    QTableView,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.katalog import INDEKS
from vexlab.gui.wybor_tabeli import wybor_klawiatura


class NaglowekWyboru(QHeaderView):
    def __init__(
        self, tabela: QTableView, wszystkie: Callable[[], None], odznacz: Callable[[], None]
    ) -> None:
        super().__init__(Qt.Orientation.Horizontal, tabela)
        self.wszystkie, self.odznacz = wszystkie, odznacz
        self.wybrano, self.wynikow = 0, 0
        self.setSectionsClickable(True)
        self.setAccessibleName("Nagłówki katalogu; Ctrl+A zaznacza wszystkie wyniki")

    def ustaw(self, wybrano: int, wynikow: int) -> None:
        self.wybrano, self.wynikow = wybrano, wynikow
        self.viewport().update()

    def paintSection(self, painter: QPainter, rect: QRect, logicalIndex: int) -> None:
        super().paintSection(painter, rect, logicalIndex)
        if logicalIndex == 9:
            o = QStyleOptionButton()
            o.rect = QRect(rect.center().x() - 8, rect.center().y() - 8, 16, 16)
            o.state = QStyle.StateFlag.State_Enabled
            o.state |= (
                QStyle.StateFlag.State_On
                if self.wynikow and self.wybrano == self.wynikow
                else QStyle.StateFlag.State_NoChange
                if self.wybrano
                else QStyle.StateFlag.State_Off
            )
            self.style().drawControl(QStyle.ControlElement.CE_CheckBox, o, painter, self)

    def mousePressEvent(self, event: QMouseEvent) -> None:
        column = self.logicalIndexAt(event.position().toPoint())
        if event.button() == Qt.MouseButton.LeftButton and column in (8, 9):
            if column == 9:
                if self.wynikow and self.wybrano == self.wynikow:
                    self.odznacz()
                else:
                    self.wszystkie()
            event.accept()
            return
        super().mousePressEvent(event)


def _checkbox(painter: QPainter, rect: QRect, checked: bool, enabled: bool) -> None:
    o = QStyleOptionButton()
    o.rect = rect
    o.state = QStyle.StateFlag.State_On if checked else QStyle.StateFlag.State_Off
    if enabled:
        o.state |= QStyle.StateFlag.State_Enabled
    QApplication.style().drawControl(QStyle.ControlElement.CE_CheckBox, o, painter)


def prostokaty_akcji(rect: QRect) -> tuple[QRect, QRect]:
    return (
        QRect(rect.left() + 6, rect.center().y() - 14, 28, 28),
        QRect(rect.left() + 40, rect.center().y() - 14, 28, 28),
    )


class RysowanieKatalogu(QStyledItemDelegate):
    edytuj = Signal(QModelIndex)
    menu = Signal(QModelIndex, QPoint)

    def __init__(self, view: QAbstractItemView, dostepne: Callable[[], bool]) -> None:
        super().__init__(view)
        self.view, self.dostepne = view, dostepne
        self.ikony = {
            dark: {
                n: ikona(n, "#C1D0E5" if dark else "#34516F") for n in ("edytuj", "wiecej", "media")
            }
            for dark in (True, False)
        }

    def _akcje(self, p: QPainter, rect: QRect, option: QStyleOptionViewItem) -> None:
        dark = option.palette.color(QPalette.ColorRole.Window).lightness() < 128
        for r, symbol in zip(prostokaty_akcji(rect), ("edytuj", "wiecej"), strict=True):
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(option.palette.color(QPalette.ColorRole.Button))
            p.drawRoundedRect(r, 6, 6)
            mode = (
                self.ikony[dark][symbol].Mode.Normal
                if self.dostepne()
                else self.ikony[dark][symbol].Mode.Disabled
            )
            self.ikony[dark][symbol].paint(
                p, r.adjusted(5, 5, -5, -5), Qt.AlignmentFlag.AlignCenter, mode
            )

    def _zdjecie(
        self, p: QPainter, rect: QRect, index: INDEKS, option: QStyleOptionViewItem
    ) -> None:
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(Qt.GlobalColor.white)
        p.drawRoundedRect(rect, 5, 5)
        icon = self.view.model().index(index.row(), 0).data(Qt.ItemDataRole.DecorationRole)
        if icon is None:
            dark = option.palette.color(QPalette.ColorRole.Window).lightness() < 128
            icon = self.ikony[dark]["media"]
        icon.paint(p, rect.adjusted(3, 3, -3, -3), Qt.AlignmentFlag.AlignCenter)

    def _wywolaj(self, index: INDEKS, pos: QPoint, rect: QRect) -> bool:
        if not self.dostepne():
            return False
        edit, menu = prostokaty_akcji(rect)
        if edit.contains(pos):
            self.edytuj.emit(self.view.model().index(index.row(), index.column()))
            return True
        if menu.contains(pos):
            self.menu.emit(
                self.view.model().index(index.row(), index.column()),
                self.view.viewport().mapToGlobal(pos),
            )
            return True
        return False

    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index: INDEKS) -> None:
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        opt.text = ""
        opt.features &= ~QStyleOptionViewItem.ViewItemFeature.HasDecoration
        self.view.style().drawControl(
            QStyle.ControlElement.CE_ItemViewItem, opt, painter, self.view
        )
        painter.save()
        if index.column() == 8:
            self._akcje(painter, option.rect, option)
        elif index.column() == 9:
            _checkbox(
                painter,
                QRect(option.rect.center().x() - 8, option.rect.center().y() - 8, 16, 16),
                bool(option.state & QStyle.StateFlag.State_Selected),
                self.view.isEnabled(),
            )
        elif index.column() == 0:
            rect = QRect(option.rect.center().x() - 20, option.rect.center().y() - 20, 40, 40)
            self._zdjecie(painter, rect, index, option)
        elif index.column() in (6, 7):
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(option.palette.color(QPalette.ColorRole.PlaceholderText))
            painter.drawEllipse(option.rect.center(), 5, 5)
        painter.restore()

    def editorEvent(
        self, event: QEvent, model: object, option: QStyleOptionViewItem, index: INDEKS
    ) -> bool:
        if (
            index.column() == 8
            and isinstance(event, QMouseEvent)
            and event.type() == QEvent.Type.MouseButtonRelease
            and event.button() == Qt.MouseButton.LeftButton
        ):
            return self._wywolaj(index, event.position().toPoint(), option.rect)
        return False


class RysowanieKafelkow(RysowanieKatalogu):
    def sizeHint(self, option: QStyleOptionViewItem, index: INDEKS) -> QSize:
        return QSize(232, 294)

    @staticmethod
    def obszar_akcji(rect: QRect) -> QRect:
        return QRect(rect.right() - 78, rect.bottom() - 40, 74, 30)

    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index: INDEKS) -> None:
        p = painter
        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = option.rect.adjusted(4, 4, -4, -4)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        dark = option.palette.color(QPalette.ColorRole.Window).lightness() < 128
        p.setPen(
            option.palette.color(QPalette.ColorRole.Highlight)
            if selected
            else QColor("#32465E" if dark else "#CFD9E5")
        )
        p.setBrush(
            option.palette.color(QPalette.ColorRole.Highlight)
            if selected
            else QColor("#1B293A" if dark else "#FFFFFF")
        )
        p.drawRoundedRect(rect, 10, 10)
        photo = QRect(rect.left() + 12, rect.top() + 12, rect.width() - 24, 112)
        self._zdjecie(p, photo, index, option)
        _checkbox(
            p, QRect(rect.left() + 14, rect.top() + 14, 18, 18), selected, self.view.isEnabled()
        )
        font = QFont(option.font)
        font.setBold(True)
        p.setFont(font)
        p.setPen(option.palette.color(QPalette.ColorRole.Text))
        title = QRect(rect.left() + 12, rect.top() + 134, rect.width() - 24, 34)
        p.drawText(
            title, Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap, str(index.data() or "")
        )
        font.setBold(False)
        p.setFont(font)
        for col, y in ((2, 174), (3, 193), (4, 214)):
            area = QRect(rect.left() + 12, rect.top() + y, rect.width() - 24, 18)
            text = str(self.view.model().index(index.row(), col).data() or "—")
            p.drawText(
                area,
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                p.fontMetrics().elidedText(text, Qt.TextElideMode.ElideRight, area.width()),
            )
        self._akcje(p, self.obszar_akcji(option.rect), option)
        p.restore()

    def editorEvent(
        self, event: QEvent, model: object, option: QStyleOptionViewItem, index: INDEKS
    ) -> bool:
        if (
            isinstance(event, QMouseEvent)
            and event.type() == QEvent.Type.MouseButtonRelease
            and event.button() == Qt.MouseButton.LeftButton
        ):
            return self._wywolaj(index, event.position().toPoint(), self.obszar_akcji(option.rect))
        return False


class KafelkiKatalogu(QListView):
    szczegoly = Signal(QModelIndex)

    def __init__(
        self, tabela: QTableView, wszystkie: Callable[[], None], odznacz: Callable[[], None]
    ) -> None:
        super().__init__()
        self.tabela, self.wszystkie, self.odznacz = tabela, wszystkie, odznacz
        self.setModel(tabela.model())
        self.setModelColumn(1)
        self.setSelectionModel(tabela.selectionModel())
        self.setViewMode(QListView.ViewMode.IconMode)
        self.setResizeMode(QListView.ResizeMode.Adjust)
        self.setMovement(QListView.Movement.Static)
        self.setUniformItemSizes(True)
        self.setGridSize(QSize(244, 306))
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setAccessibleName("Produkty — widok kafelków")
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.model().dataChanged.connect(lambda *_: self.viewport().update())

    def selectionCommand(
        self, index: INDEKS, event: QEvent | None = None
    ) -> QItemSelectionModel.SelectionFlag:
        return super().selectionCommand(index, event) | QItemSelectionModel.SelectionFlag.Rows

    def selectAll(self) -> None:
        self.wszystkie()

    def clearSelection(self) -> None:
        self.odznacz()

    def _w_checkbox(self, event: QMouseEvent) -> bool:
        index = self.indexAt(event.position().toPoint())
        if not index.isValid():
            return False
        rect = self.visualRect(index)
        return QRect(rect.left() + 18, rect.top() + 18, 18, 18).contains(event.position().toPoint())

    def mousePressEvent(self, event: QMouseEvent) -> None:
        index = self.indexAt(event.position().toPoint())
        if event.button() == Qt.MouseButton.LeftButton and self._w_checkbox(event):
            self.selectionModel().select(
                index,
                QItemSelectionModel.SelectionFlag.Toggle | QItemSelectionModel.SelectionFlag.Rows,
            )
            self.selectionModel().setCurrentIndex(index, QItemSelectionModel.SelectionFlag.NoUpdate)
            event.accept()
            return
        if not event.modifiers() & (
            Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier
        ) and (
            event.button() == Qt.MouseButton.LeftButton
            or (
                event.button() == Qt.MouseButton.RightButton
                and not self.selectionModel().isRowSelected(index.row(), QModelIndex())
            )
        ):
            self.odznacz()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton and self._w_checkbox(event):
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.szczegoly.emit(self.currentIndex())
            return
        if event.key() == Qt.Key.Key_Space and self.currentIndex().isValid():
            self.selectionModel().select(
                self.currentIndex(),
                QItemSelectionModel.SelectionFlag.Toggle | QItemSelectionModel.SelectionFlag.Rows,
            )
            return
        if not wybor_klawiatura(event, self.odznacz):
            super().keyPressEvent(event)


class WidokiKatalogu(QStackedWidget):
    def __init__(
        self, tabela: QTableView, wszystkie: Callable[[], None], odznacz: Callable[[], None]
    ) -> None:
        super().__init__()
        self.tabela = tabela
        self.kafelki = KafelkiKatalogu(tabela, wszystkie, odznacz)
        self.addWidget(tabela)
        self.addWidget(self.kafelki)

    def ustaw_tryb(self, tryb: str) -> None:
        self.setCurrentIndex(1 if tryb == "kafelki" else 0)
