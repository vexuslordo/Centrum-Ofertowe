"""Przestrzeń pracy Allegro i odrębny panel konfiguracji połączenia."""

from typing import cast

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.gui.ustawienia import SekcjaRozwijana
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KodUrzadzenia,
    PolaczAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
    StronaSzkicowAllegro,
)


class StronaAllegro(QWidget):
    stan = Signal(str)
    ustawienia_zadane = Signal()

    def __init__(self, serwis: PolaczAllegro, uruchom: Uruchom) -> None:
        super().__init__()
        self.serwis, self.uruchom = serwis, uruchom
        self.aplikacja: AplikacjaAllegro | None = None
        self.kod: KodUrzadzenia | None = None
        self.sesja: SesjaAllegro | None = None
        self.generacja = 0
        self.trwa = False
        self.dysk_trwa = False
        self.zapamietane = False
        self.koniec = 0.0
        self.odstep = 5
        self.offset = 0
        self.lacznie = 0
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self._sprawdz)
        self.wygasanie = QTimer(self)
        self.wygasanie.setInterval(1000)
        self.wygasanie.timeout.connect(self._waznosc)
        layout = QVBoxLayout(self)
        tytul = QLabel("Allegro")
        tytul.setObjectName("marka")
        layout.addWidget(tytul)
        opis = QLabel("Twoje konto Allegro — szkice, oferty i obsługa sprzedaży.")
        opis.setWordWrap(True)
        layout.addWidget(opis)
        self.status_konta = QLabel("Konto niepołączone. Połącz je w Ustawieniach.")
        self.status_konta.setTextFormat(Qt.TextFormat.PlainText)
        self.status_konta.setWordWrap(True)
        layout.addWidget(self.status_konta)
        ustawienia = QPushButton("Ustawienia połączenia")
        ustawienia.clicked.connect(self.ustawienia_zadane.emit)
        layout.addWidget(ustawienia, 0, Qt.AlignmentFlag.AlignLeft)
        self.panel_polaczenia = QWidget()
        auth = QVBoxLayout(self.panel_polaczenia)
        auth.setContentsMargins(0, 0, 0, 0)
        naglowek = QLabel("Allegro — połączenie konta")
        naglowek.setObjectName("tytul")
        naglowek.setWordWrap(True)
        auth.addWidget(naglowek)
        self.info = QLabel("Konto niepołączone.")
        self.info.setTextFormat(Qt.TextFormat.PlainText)
        self.info.setWordWrap(True)
        self.info.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        auth.addWidget(self.info)
        self.dane_aplikacji = SekcjaRozwijana("Dane aplikacji")
        auth.addWidget(self.dane_aplikacji)
        form = QFormLayout()
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.srodowisko = QComboBox()
        for s in SrodowiskoAllegro:
            self.srodowisko.addItem(s.value, s)
        form.addRow("Środowisko", self.srodowisko)
        self.klient = QLineEdit()
        self.klient.setMaxLength(512)
        self.klient.setAccessibleName("Client ID aplikacji Allegro")
        form.addRow("Client ID", self.klient)
        self.sekret = QLineEdit()
        self.sekret.setMaxLength(1024)
        self.sekret.setEchoMode(QLineEdit.EchoMode.Password)
        self.sekret.setAccessibleName("Client Secret aplikacji Allegro")
        form.addRow("Client Secret", self.sekret)
        self.dane_aplikacji.wnetrze.addLayout(form)
        self.podpowiedz = QLabel(
            "Aplikacja Allegro musi obsługiwać Device Flow (aplikacja bez dostępu do "
            "przeglądarki). Do tej wersji potrzebne są uprawnienia odczytu profilu "
            "i ofert: allegro:api:profile:read oraz allegro:api:sale:offers:read."
        )
        self.podpowiedz.setWordWrap(True)
        self.dane_aplikacji.wnetrze.addWidget(self.podpowiedz)
        self.zapamietaj = QCheckBox("Zapamiętaj połączenie")
        self.zapamietaj.setAccessibleName("Zapamiętaj połączenie na tym komputerze")
        self.zapamietaj.setChecked(serwis.mozna_zapamietac)
        self.zapamietaj.setEnabled(serwis.mozna_zapamietac)
        auth.addWidget(self.zapamietaj)
        self.ochrona = QLabel(
            "Windows zabezpieczy dane połączenia dla Twojego użytkownika systemu."
            if serwis.mozna_zapamietac
            else "Zapamiętywanie jest dostępne na Windows. "
            "Tutaj połączenie trwa do zamknięcia programu."
        )
        self.ochrona.setWordWrap(True)
        auth.addWidget(self.ochrona)
        self.ponow = QPushButton("Wznów zapisane połączenie")
        self.ponow.clicked.connect(self.przywroc)
        auth.addWidget(self.ponow, 0, Qt.AlignmentFlag.AlignLeft)
        buttons = QVBoxLayout()
        self.polacz = QPushButton("Połącz konto")
        self.polacz.setObjectName("primary")
        self.polacz.clicked.connect(self.rozpocznij)
        self.otworz = QPushButton("Otwórz zgodę w Allegro")
        self.otworz.setObjectName("primary")
        self.otworz.clicked.connect(self._otworz)
        self.otworz.setEnabled(False)
        self.rozlacz = QPushButton("Rozłącz i zapomnij")
        self.rozlacz.clicked.connect(self.rozlacz_i_zapomnij)
        self.rozlacz.setEnabled(False)
        for b in (self.polacz, self.otworz, self.rozlacz):
            buttons.addWidget(b, 0, Qt.AlignmentFlag.AlignLeft)
        auth.addLayout(buttons)
        actions = QHBoxLayout()
        self.odswiez = QPushButton("Pobierz szkice")
        self.odswiez.clicked.connect(lambda: self.pobierz(0))
        self.poprzednia = QPushButton("Poprzednia")
        self.poprzednia.clicked.connect(lambda: self.pobierz(self.offset - 50))
        self.nastepna = QPushButton("Następna")
        self.nastepna.clicked.connect(lambda: self.pobierz(self.offset + 50))
        for b in (self.odswiez, self.poprzednia, self.nastepna):
            actions.addWidget(b)
        self.zakres = QLabel("Nie pobrano szkiców.")
        self.zakres.setWordWrap(True)
        actions.addWidget(self.zakres, 1)
        layout.addLayout(actions)
        self.tabela = QTableWidget(0, 2)
        self.tabela.setHorizontalHeaderLabels(["ID Allegro", "Tytuł szkicu"])
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setAccessibleName("Szkice na połączonym koncie Allegro")
        layout.addWidget(self.tabela, 1)
        footer = QLabel(
            "Lista z Allegro jest oddzielna od lokalnych szkiców. Ten etap odczytuje "
            "oferty INACTIVE (do 10 000 wyników); edycja i zapis zdalnych szkiców "
            "będą kolejnym krokiem."
        )
        footer.setWordWrap(True)
        layout.addWidget(footer)
        self._przyciski()

    def _komunikat(self, tekst: str) -> None:
        self.info.setText(tekst)
        self.status_konta.setText(tekst)

    def _przyciski(self) -> None:
        self.polacz.setEnabled(
            not self.trwa and self.aplikacja is None and self.sesja is None and not self.zapamietane
        )
        self.odswiez.setEnabled(self.sesja is not None and not self.trwa)
        self.poprzednia.setEnabled(self.odswiez.isEnabled() and self.offset > 0)
        self.nastepna.setEnabled(
            self.odswiez.isEnabled() and self.offset + 50 < self.lacznie and self.offset < 9950
        )
        editable = self.aplikacja is None and self.sesja is None and not self.trwa
        for w in (self.klient, self.sekret, self.srodowisko):
            w.setEnabled(editable and not self.zapamietane)
        self.zapamietaj.setEnabled(
            editable and not self.zapamietane and self.serwis.mozna_zapamietac
        )
        self.ponow.setEnabled(editable and self.serwis.mozna_zapamietac)
        self.rozlacz.setEnabled(
            not self.dysk_trwa
            and (self.aplikacja is not None or self.sesja is not None or self.zapamietane)
        )

        self.polacz.setVisible(
            self.aplikacja is None and self.sesja is None and not self.zapamietane
        )
        self.otworz.setVisible(self.kod is not None)
        self.ponow.setVisible(self.zapamietane and self.sesja is None and self.aplikacja is None)
        self.rozlacz.setVisible(
            self.aplikacja is not None or self.sesja is not None or self.zapamietane
        )
        self.rozlacz.setText(
            "Anuluj"
            if self.aplikacja is not None
            else ("Rozłącz i zapomnij" if self.zapamietane else "Rozłącz")
        )
        self.zapamietaj.setVisible(self.sesja is None and not self.zapamietane)
        self.ochrona.setVisible(self.sesja is None and not self.zapamietane)

    def rozpocznij(self) -> None:
        if not self.polacz.isEnabled():
            return
        if not self.klient.text().strip() or not self.sekret.text():
            self.dane_aplikacji.ustaw_otwarte(True)
            self._komunikat("Uzupełnij dane aplikacji, aby połączyć konto.")
            (self.klient if not self.klient.text().strip() else self.sekret).setFocus()
            return
        a = AplikacjaAllegro(
            self.klient.text().strip(),
            self.sekret.text(),
            cast(SrodowiskoAllegro, self.srodowisko.currentData()),
        )
        self.sekret.clear()
        self.aplikacja = a
        self.generacja += 1
        gen = self.generacja
        self.trwa = True
        self.rozlacz.setEnabled(True)
        self._komunikat("Pobieranie kodu zgody z Allegro…")
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            self.trwa = False
            self.kod = cast(KodUrzadzenia, wynik)
            self.koniec = self.serwis.teraz() + self.kod.waznosc
            self.odstep = self.kod.odstep
            self.otworz.setEnabled(True)
            self._komunikat(
                f"Otwórz zgodę w Allegro i zatwierdź konto. Kod: {self.kod.kod_uzytkownika}"
            )
            self.timer.start(self.odstep * 1000)
            self._przyciski()

        self.uruchom(lambda: self.serwis.rozpocznij(a), gotowe, lambda k, m: self._blad(gen, k, m))

    def _otworz(self) -> None:
        if (
            self.kod is not None
            and self.otworz.isEnabled()
            and not QDesktopServices.openUrl(QUrl(self.kod.adres))
        ):
            self._komunikat("Nie można otworzyć przeglądarki. Spróbuj ponownie.")

    def _sprawdz(self) -> None:
        a, kod, gen = self.aplikacja, self.kod, self.generacja
        if a is None or kod is None or self.trwa:
            return
        if self.serwis.teraz() >= self.koniec:
            self._blad(gen, "WYGASLA", "Kod zgody wygasł. Połącz konto ponownie.")
            return
        self.trwa = True

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            sesja = cast(SesjaAllegro, wynik)
            self.aplikacja, self.kod = None, None
            self.otworz.setEnabled(False)
            if not self.zapamietaj.isChecked():
                self._polaczono(sesja, False)
                return
            self.dysk_trwa = True
            self._komunikat("Zapamiętywanie połączenia…")
            self._przyciski()

            def zapisano(_: object) -> None:
                if gen == self.generacja:
                    self.dysk_trwa = False
                    self._polaczono(sesja, True)

            def blad_zapisu(k: str, m: str) -> None:
                if gen == self.generacja:
                    self.dysk_trwa = False
                    self._polaczono(sesja, False)
                    self._komunikat("Połączono tylko do zamknięcia programu. " + m)

            self.uruchom(lambda: self.serwis.zapamietaj(sesja), zapisano, blad_zapisu)

        self.uruchom(
            lambda: self.serwis.sprawdz(a, kod.kod), gotowe, lambda k, m: self._blad(gen, k, m)
        )

    def _polaczono(self, sesja: SesjaAllegro, zapisano: bool) -> None:
        self.sesja = sesja
        self.dane_aplikacji.ustaw_otwarte(False)
        self.trwa = False
        self.zapamietane = zapisano
        self._komunikat(
            f"Połączono: {sesja.konto.login} • {sesja.srodowisko.value}. "
            + (
                "Połączenie zapamiętane."
                if zapisano
                else "Połączenie tylko do zamknięcia programu."
            )
        )
        self.stan.emit(f"Allegro: {sesja.konto.login}")
        self.wygasanie.start()
        self._przyciski()
        self.pobierz(0)

    def przywroc(self) -> None:
        if self.trwa or not self.serwis.mozna_zapamietac:
            return
        self.generacja += 1
        gen = self.generacja
        self.trwa, self.dysk_trwa = True, True
        self.sesja = None
        self.tabela.setRowCount(0)
        self.wygasanie.stop()
        self.stan.emit("Allegro: sprawdzanie połączenia")
        self._komunikat("Wznawianie zapisanego połączenia…")
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            self.trwa, self.dysk_trwa = False, False
            sesja = cast(SesjaAllegro | None, wynik)
            if sesja is None:
                self.zapamietane = False
                self.anuluj()
                return
            if sesja.aplikacja is not None:
                self.klient.setText(sesja.aplikacja.klient)
            self.srodowisko.setCurrentIndex(self.srodowisko.findData(sesja.srodowisko))
            self._polaczono(sesja, True)

        def blad(kod: str, komunikat: str) -> None:
            if gen != self.generacja:
                return
            self.trwa, self.dysk_trwa = False, False
            self.zapamietane = True  # Także uszkodzony zapis można jawnie usunąć.
            self.anuluj()
            self._komunikat(
                "Nie udało się wznowić połączenia. "
                + komunikat
                + " Ponów próbę lub wybierz Rozłącz i zapomnij."
            )

        self.uruchom(self.serwis.przywroc, gotowe, blad)

    def rozlacz_i_zapomnij(self) -> None:
        if self.dysk_trwa:
            return
        if not self.zapamietane:
            self.anuluj()
            return
        self.anuluj()
        self.trwa, self.dysk_trwa = True, True
        self._komunikat("Usuwanie zapisanego połączenia…")
        self._przyciski()
        gen = self.generacja

        def gotowe(_: object) -> None:
            if gen == self.generacja:
                self.trwa, self.dysk_trwa, self.zapamietane = False, False, False
                self._komunikat("Rozłączono. Zapisane połączenie zostało usunięte.")
                self._przyciski()

        def blad(k: str, m: str) -> None:
            if gen == self.generacja:
                self.trwa, self.dysk_trwa = False, False
                self._komunikat(m)
                self._przyciski()

        self.uruchom(self.serwis.zapomnij, gotowe, blad)

    def _blad(self, gen: int, kod: str, komunikat: str) -> None:
        if gen != self.generacja:
            return
        self.trwa = False
        if self.aplikacja is not None and kod in {"OCZEKIWANIE", "WOLNIEJ"}:
            if kod == "WOLNIEJ":
                self.odstep = min(3600, self.odstep + 5)
            self.timer.start(self.odstep * 1000)
            return
        if self.aplikacja is None and self.zapamietane and kod in {"WYGASLA", "AUTORYZACJA"}:
            self.przywroc()
            return
        if self.aplikacja is not None or kod in {"WYGASLA", "AUTORYZACJA"}:
            self.anuluj()
        self._komunikat(komunikat)
        if kod in {"KONFIGURACJA", "APLIKACJA"}:
            self.dane_aplikacji.ustaw_otwarte(True)
        self._przyciski()

    def pobierz(self, offset: int = 0) -> None:
        sesja, gen = self.sesja, self.generacja
        if sesja is None or self.trwa:
            return
        self.trwa = True
        # Poprzednia strona nie udaje aktualnego wyniku po nieudanym odczycie.
        self.tabela.setRowCount(0)
        self.lacznie = 0
        self.zakres.setText("Pobieranie szkiców…")
        self._przyciski()

        def gotowe(wynik: object) -> None:
            if gen != self.generacja:
                return
            strona = cast(StronaSzkicowAllegro, wynik)
            self.trwa = False
            self.offset, self.lacznie = strona.offset, strona.lacznie
            self.tabela.setRowCount(len(strona.szkice))
            for row, p in enumerate(strona.szkice):
                self.tabela.setItem(row, 0, QTableWidgetItem(p.id))
                self.tabela.setItem(row, 1, QTableWidgetItem(p.tytul))
            self.zakres.setText(
                f"{strona.offset + 1}–{strona.offset + len(strona.szkice)} z {strona.lacznie}"
                if strona.szkice
                else "Brak szkiców na tej stronie."
            )
            self._przyciski()

        def blad(kod: str, komunikat: str) -> None:
            if gen == self.generacja:
                self.zakres.setText("Nie pobrano szkiców. Ponów odczyt.")
            self._blad(gen, kod, komunikat)

        self.uruchom(lambda: self.serwis.szkice(sesja, offset), gotowe, blad)

    def _waznosc(self) -> None:
        if self.sesja is not None and self.serwis.teraz() >= self.sesja.wygasa and not self.trwa:
            if self.zapamietane:
                self.przywroc()
                return
            self.anuluj()
            self._komunikat("Sesja wygasła. Połącz konto ponownie.")

    def anuluj(self) -> None:
        self.generacja += 1
        self.timer.stop()
        self.wygasanie.stop()
        self.aplikacja, self.kod, self.sesja = None, None, None
        self.sekret.clear()
        self.trwa = False
        self.otworz.setEnabled(False)
        self.rozlacz.setEnabled(False)
        self.tabela.setRowCount(0)
        self.offset, self.lacznie = 0, 0
        self.zakres.setText("Nie pobrano szkiców.")
        self._komunikat("Konto niepołączone. Połącz je w Ustawieniach.")
        self.stan.emit("Allegro: niepołączone")
        self._przyciski()
