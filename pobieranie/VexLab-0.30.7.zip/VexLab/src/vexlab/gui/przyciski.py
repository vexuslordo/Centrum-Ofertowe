"""Przyciski akcji: wspólne ikony i karty skrótów według wzoru właściciela."""

from PySide6.QtCore import QEvent, QSize, Qt
from PySide6.QtGui import QIcon, QPaintEvent, QPalette
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QStyle,
    QStyleOptionButton,
    QStylePainter,
    QVBoxLayout,
)

from vexlab.gui.design_system import ikona

IKONY_PRZYCISKOW = {
    "Dodaj produkt": "dodaj",
    "Odśwież": "synchronizacja",
    "Edytuj": "edytuj",
    "Wyczyść filtry": "filtr",
    "Ustawienia": "ustawienia",
    "Utwórz kopię katalogu…": "kopiuj",
    "← Cenniki": "powrot",
}

# Wyłącznie prezentacja istniejących skrótów. Dostępność i cele pozostają w przypadkach użycia.
KARTY_AKCJI = {
    "cenniki": ("cennik", "Przeglądaj i porównuj ceny"),
    "masowa": ("edytuj", "Zmień dane zaznaczonych produktów"),
    "ai": ("ai", "W przygotowaniu"),
    "kopiuj_uklad": ("kopiuj", "W przygotowaniu"),
    "szablony": ("szablon", "W przygotowaniu"),
    "bledy": ("blad", "Sprawdź pozycje do poprawy"),
    "produkty": ("produkt", "Otwórz katalog produktów"),
    "nowe_oferty": ("dodaj", "Wczytaj paczkę ofert"),
    "szkice": ("szkic", "Przejrzyj lokalne szkice"),
    "media": ("media", "Przeglądaj galerie produktów"),
    "producenci": ("producent", "Zarządzaj producentami"),
    "ustawienia": ("ustawienia", "Dostosuj program i integracje"),
}


def kolor_ikony(glowny: bool = False, ostrzezenie: bool = False) -> str:
    if glowny:
        return "#FFFFFF"
    ciemny = QApplication.palette().color(QPalette.ColorRole.Window).lightness() < 128
    if ostrzezenie:
        return "#FF8793" if ciemny else "#B6364A"
    return "#59AEFF" if ciemny else "#176CC1"


class PrzyciskAkcji(QPushButton):
    def __init__(self, tekst: str, symbol: str = "") -> None:
        super().__init__(tekst)
        self.symbol = symbol
        self.setAccessibleName(tekst)
        self.setIconSize(QSize(20, 20))
        self.objectNameChanged.connect(self._odswiez_ikone)
        self._odswiez_ikone()

    def _odswiez_ikone(self) -> None:
        if self.symbol:
            self.setIcon(ikona(self.symbol, kolor_ikony(self.objectName() == "primary")))

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() in (
            QEvent.Type.PaletteChange,
            QEvent.Type.ApplicationPaletteChange,
        ) and hasattr(self, "symbol"):
            self._odswiez_ikone()


class KartaAkcji(QPushButton):
    """Natywna semantyka przycisku; dwa wiersze tekstu nie przechwytują myszy."""

    def __init__(self, tekst: str, symbol: str, opis: str) -> None:
        super().__init__(tekst)
        self.symbol = symbol
        self.setObjectName("kartaAkcji")
        self.setAccessibleName(tekst)
        self.setAccessibleDescription(opis)
        policy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        policy.setHeightForWidth(True)
        self.setSizePolicy(policy)
        self.setMinimumWidth(0)
        self.setMinimumHeight(56)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(12)
        self.obraz = QLabel()
        self.obraz.setFixedSize(26, 26)
        layout.addWidget(self.obraz)
        teksty = QVBoxLayout()
        teksty.setSpacing(3)
        for nazwa, tresc in (("tytulAkcji", tekst), ("opisAkcji", opis)):
            label = QLabel(tresc)
            label.setObjectName(nazwa)
            label.setWordWrap(True)
            label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
            teksty.addWidget(label)
        layout.addLayout(teksty, 1)
        self.obraz.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._odswiez_ikone()

    def minimumSizeHint(self) -> QSize:
        return QSize(90, 56)

    def sizeHint(self) -> QSize:
        return QSize(260, 60)

    def heightForWidth(self, width: int) -> int:
        layout = self.layout()
        return max(56, layout.heightForWidth(width)) if layout is not None else 56

    def _odswiez_ikone(self) -> None:
        kolor = kolor_ikony(ostrzezenie=self.symbol == "blad") if self.isEnabled() else "#7C8DA4"
        self.obraz.setPixmap(ikona(self.symbol, kolor).pixmap(26, 26))

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() in (
            QEvent.Type.PaletteChange,
            QEvent.Type.ApplicationPaletteChange,
            QEvent.Type.EnabledChange,
        ) and hasattr(self, "obraz"):
            self._odswiez_ikone()

    def paintEvent(self, event: QPaintEvent) -> None:
        option = QStyleOptionButton()
        self.initStyleOption(option)
        option.text, option.icon = "", QIcon()
        painter = QStylePainter(self)
        painter.drawControl(QStyle.ControlElement.CE_PushButton, option)
