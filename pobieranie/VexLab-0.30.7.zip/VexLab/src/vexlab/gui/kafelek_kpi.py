"""Kafelki Dashboardu według wzoru: pełna ikona, jasny gradient i biała typografia."""

from pathlib import Path

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import (
    QColor,
    QIcon,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPaintEvent,
    QPen,
    QRadialGradient,
)
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout

from vexlab.gui.design_system import PALETA_KPI


class KafelekKPI(QFrame):
    def __init__(self, tytul: str, wariant: str, podpis: str) -> None:
        super().__init__()
        self.wariant = wariant
        self.setProperty("wariant_kpi", wariant)
        self.setFixedHeight(120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 18, 16, 16)
        layout.setSpacing(22)
        obraz = QLabel()
        obraz.setFixedSize(56, 56)
        obraz.setAccessibleName(f"Ikona: {tytul}")
        plik = Path(__file__).with_name("zasoby") / "kpi" / f"{wariant}.svg"
        pixmap = QIcon(str(plik)).pixmap(112, 112)
        pixmap.setDevicePixelRatio(2)
        obraz.setPixmap(pixmap)
        layout.addWidget(obraz, 0, Qt.AlignmentFlag.AlignTop)
        tekst = QVBoxLayout()
        tekst.setContentsMargins(0, 3, 0, 0)
        tekst.setSpacing(4)
        self.tytul = QLabel(tytul)
        self.tytul.setObjectName("kpiTytul")
        self.liczba = QLabel("—")
        self.liczba.setObjectName("kpiLiczba")
        self.liczba.setAccessibleDescription(f"Liczba: {tytul}")
        self.podpis = QLabel(podpis)
        self.podpis.setObjectName("kpiPodpis")
        for label in (self.tytul, self.liczba, self.podpis):
            label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            tekst.addWidget(label)
        layout.addLayout(tekst, 1)

    def paintEvent(self, event: QPaintEvent) -> None:
        gora, srodek, dol, poswiata, obrys = PALETA_KPI[self.wariant]
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath()
        path.addRoundedRect(rect, 12, 12)
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        for stop, color in ((0.0, gora), (0.55, srodek), (1.0, dol)):
            gradient.setColorAt(stop, QColor(color))
        painter.fillPath(path, gradient)
        glow = QRadialGradient(self.width() * 0.18, self.height() * 0.05, self.width() * 0.85)
        kolor = QColor(poswiata)
        kolor.setAlpha(28)
        glow.setColorAt(0, kolor)
        kolor.setAlpha(0)
        glow.setColorAt(1, kolor)
        painter.fillPath(path, glow)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        kolor_obrysu = QColor(obrys)
        kolor_obrysu.setAlpha(110)
        painter.setPen(QPen(kolor_obrysu, 1))
        painter.drawPath(path)
