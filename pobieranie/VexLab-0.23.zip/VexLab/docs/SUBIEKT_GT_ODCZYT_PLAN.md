# Subiekt GT — kierunek integracji odczytu katalogu

2026-11-06: właściciel potwierdził Subiekt GT. Wymaganie: tylko odczyt
katalogu; paczki ofert nie tworzą ani nie modyfikują kartotek w GT.
Stan bieżący: rozdzielenie lokalnych szkiców od tworzenia Produktów w 0.20.
Nie ma połączenia z GT, konfiguracji konta ani sprawdzonego odczytu na żywo.

## Kolejny etap do przygotowania

Port odczytu katalogu, filtr i stronicowanie. Odczytane dane muszą zachować
zewnętrzne ID z zakresem właściwej bazy/podmiotu. SKU służy do wyszukania,
a nie do zgadywania jednego Produktu przy kilku trafieniach. Szkic jest
prezentacją oferty, nie zakłada kartoteki przy braku dopasowania.

Źródło prawdy pól kartoteki należy do GT; opis/układ przygotowanej oferty
do użytkownika. Program musi rozróżniać odczyt bieżący, niedostępny i dane
pobrane wcześniej. Nie pokazywać „Połączono” bez rzeczywistego sprawdzenia.
Nie kopiować całego katalogu i obrazów do lokalnej bazy przy każdym starcie.

Przed wyborem adaptera sprawdzić aktualną dokumentację InsERT, możliwości
instalacji właściciela i wymagania licencyjne. Dostęp przez wspierany
mechanizm GT/Sferę oraz odczyt SQL są alternatywami wymagającymi oceny;
nie wybrano jednej z nich na podstawie samej nazwy produktu. Konfiguracja
instancji/bazy i dane uwierzytelnienia należą do użytkownika, poza kodem.
Magazyn sekretów za portem (P-07), bez hasła w zwykłym pliku ustawień.

Odbiór ma wykazać: konto/uprawnienia tylko do odczytu, brak INSERT/UPDATE/
DELETE i poleceń zmieniających GT, stronicowanie, błędy autoryzacji/sieci,
zmianę danych podczas przeglądania, niejednoznaczne SKU oraz brak publikacji
ofert jako skutku samego odczytu. Test na rzeczywistej instalacji wymagany
przed deklaracją działającego konektora.

Przygotowanie 0.22: lokalny katalog używa zapytania stronicowanego
z globalnym filtrem/sortowaniem, licznikiem i ID/wersją wybranych rekordów.
Nie jest to implementacja adaptera GT ani wybór transportu. Przy składaniu
GT trzeba wydzielić port samego odczytu i wyłączyć lokalne komendy edycji
dla jego kartotek; obecny zapis pozostaje przeznaczony dla lokalnej bazy.

## Potwierdzone środowisko właściciela — 2026-11-07

Baza danych działa na serwerze, klient Subiekta GT jest zainstalowany na
laptopie. Nie ustalono jeszcze nazwy/wersji instancji, modelu autoryzacji,
licencji Sfery, sposobu połączenia laptopa z serwerem ani uprawnień konta.
Sama instalacja klienta nie potwierdza tych możliwości. Przygotowanie
konektora ma bazować na tej topologii i wyłącznie odczytywać dane.
Nie wpisywać danych serwera ani poświadczeń jako domyślnych w kodzie.
