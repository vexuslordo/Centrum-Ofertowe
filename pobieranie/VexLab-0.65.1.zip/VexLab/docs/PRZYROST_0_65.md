# VexLab 0.65 — aktualizacja cen Allegro z cennika

1. Wejdź w Oferty → Zmiana cen i porównaj cennik z Allegro.
2. Zaznacz pojedynczą ofertę lub wiele wierszy (Ctrl/Shift). Przycisk
   „Zaznacz różnice z widocznych (do 500)” uwzględnia aktualny filtr.
3. Kliknij „Przygotuj zmianę zaznaczonych cen…”. Program ponownie sprawdzi dane.
4. Przejrzyj ceny przed/po, konto i środowisko. Dopiero „Zapisz ceny w Allegro”
   rozpoczyna aktualizację. Anulowanie podglądu niczego nie wysyła.
5. Zobacz liczniki i wyniki per SKU. Ponownie porównaj cennik, aby odświeżyć tabelę.

Zmienia się wyłącznie cena brutto rynku głównego istniejącej aktywnej oferty.
Reguły kursowe Allegro mogą odpowiednio przeliczyć ceny rynków dodatkowych.
Wymagana zgoda na zapis ofert w integracji i ponowne połączenie konta.
Oferty z automatyzacją ceny głównej wymagają osobnej decyzji w Allegro;
program nie usuwa ich reguł. Nie aktualizuje aukcji ani niejednoznacznych SKU.

Podczas pracy można używać innych zakładek; Zatrzymaj zatrzymuje kolejne
żądania, ale nie cofa już wysłanego. Po wyniku „Do sprawdzenia” otwórz
„Historia i wyniki cen…” i kliknij „Sprawdź oczekujące wyniki”. To tylko
odczyt. Historia jest zachowana po ponownym uruchomieniu, osobno dla konta
oraz środowiska. „Gotowe” oznacza potwierdzoną cenę; błędy mają opis przyczyny.
Nie ma automatycznego powtórzenia niepewnego zapisu.

Dziennik: podfolder ceny_allegro w danych użytkownika, bez sekretów.
PrestaShop i Subiekt nadal odłożone. Testy nie zmieniają rzeczywistych ofert;
kontrole GUI wykonano w Linux offscreen, bez natywnego uruchomienia Windows.
