# VexLab 0.62 — przelicznik cen Allegro

W Przygotuj oferty Allegro → Ustawienia Allegro → Przelicznik cen →
Ustaw dla nowych szkiców wybierz Włącz, regułę konta i rynki CZ/SK/HU.
Zastosuj do zaznaczonych lub, bez zaznaczenia, wszystkich widocznych pozycji.
Każda oferta zachowuje swoją bazową cenę PLN. Kursy i późniejsze aktualizacje
cen obsługuje Allegro, również przy zamkniętym VexLab. VAT pozostaje osobny.

Utwórz szkice zgodnie z dotychczasowym procesem. Po zakończeniu serii program
zleca przypięcie reguły do potwierdzonych ofert. Jeśli Allegro nadal przetwarza
utworzenie: Sprawdź wyniki wysyłki, a następnie Przelicznik cen → Dokończ
przypinanie do utworzonych. Szczegóły wysyłki zawierają wynik i powód błędu.
Przypięcie reguły nie publikuje oferty i nie włącza rynku sprzedaży.

Po timeout lub odrzuceniu polecenie pozostaje zablokowane przed ponownym
zleceniem. Dokończ odczytuje już istniejącą próbę. Jeżeli Allegro ostatecznie
odrzuciło regułę, popraw jej przypisanie w istniejącej ofercie Allegro,
a potem ponów sprawdzenie wyniku w VexLab. Nie twórz oferty drugi raz.

To ustawienia nowych szkiców z tej paczki. Nie zmieniają automatycznie
istniejących aktywnych ofert, polskich cen, katalogu ani cenników użytkownika.
Brak zmian SQLite i utraty danych. [Decyzja](adr/ADR-086-przelicznik-cen-rynkow-allegro.md).
