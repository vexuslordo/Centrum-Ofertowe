# VexLab 0.63

## Zielona kropka w Produktach

Po połączeniu konta program odczytuje w tle pełną listę ofert Allegro.
Zielona kropka oznacza co najmniej jedną ACTIVE o tym samym pełnym SKU.
Najedź na kropkę, aby zobaczyć konto, czas odczytu i ID/statusy. Szara oznacza
brak potwierdzonej aktywnej oferty, nie brak produktu w asortymencie.
Więcej akcji → Sprawdź Allegro odświeża odczyt; podczas pracy ta akcja zatrzymuje odczyt.
Odśwież katalogu odczytuje także Allegro. Odczyt ponawiany co5 minut.
Brak powiązania z lokalnego importu nie przeszkadza w dopasowaniu po SKU.
Ręczna Dostępność i filtry zapisanych powiązań pozostają osobne.
Wyrównano checkboxy i nagłówek tabeli, usunięto zbędną ramkę zaznaczenia.

## Gdy szkicu nie ma, a inna wersja danych blokuje SKU

Zaznacz jedną zablokowaną pozycję. Więcej działań → Sprawdź blokadę i ponów.
Ta sama akcja jest w Szczegółach wysyłki. Program odczyta konto oraz stare ID.
Jeśli nie znajdzie oferty, pokaże wynik i pytanie o nową próbę. Sprawdź też
panel Allegro: nieznany wynik i opóźnione wyszukiwanie nadal mogą dać duplikat.
Bez Twojego jawnego potwierdzenia blokada nie znika. Domyślnie Nie.

Po zgodzie następuje ponowny odczyt i archiwizacja starej próby. Dopiero
potem wrócisz do walidacji i osobnego wysłania szkicu. Wykryta oferta, trwająca
operacja, niejednoznaczność lub błąd API blokują odblokowanie. Program nie
usuwa i nie publikuje ofert automatycznie.

Bez migracji SQLite i zmian Twoich zapisanych produktów. PrestaShop odłożony.
Testy izolowane od rzeczywistych kont; odbiór Windows wymaga komputera Windows.
