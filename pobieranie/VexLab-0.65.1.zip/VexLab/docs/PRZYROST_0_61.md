# Poprawianie odrzuconych ofert — 0.61

W oknie przygotowania paczki wybierz filtr Odrzucone lub Do poprawy.
Zaznacz jedną ofertę lub Zaznacz widoczne, potem Popraw wybrane.
Zobaczysz pełne przyczyny i wskazówki oraz wybór: parametry produktu,
tytuł/cena/ilość, GPSR/dostawa/warunki albo VAT. Po zaakceptowaniu poprawki
pozycje przechodzą walidację i zostają ponownie zaznaczone. Dopiero Wyślij
poprawione szkice i osobne potwierdzenie wysyłają wskazane pozycje.
Anulowanie nie zmienia danych. Niepoprawione odrzucenia zachowują powód
oraz nie są ponownie wysyłane przez samo Sprawdź paczkę.

Przykład konfliktu numeru katalogowego: gdy Allegro wymaga innej wartości,
w Parametrach produktu wybierz ręczne źródło numeru katalogowego części
i wpisz wartość wskazaną w komunikacie, po porównaniu produktu katalogowego.
SKU i EAN paczki nie są automatycznie zmieniane. Wspólna zmiana parametru
jest jawna; różne wartości dla ofert poprawiaj osobno lub w zgodnych grupach.

Dodatkowe filtry: Niewysłane, Do sprawdzenia, Utworzone — do uzupełnienia,
Utworzone. Utworzone i niepewne pozycje nie mogą być lokalnie zmienione
w celu ponownego tworzenia. Dla niepewnych użyj Sprawdź wyniki wysyłki;
dla istniejących edycji w zakładce Allegro. Ich ID, wyniki i oryginalne
plany pozostają zachowane podczas poprawiania pozostałych wierszy,
także po zmianie globalnej domyślnej ilości lub waluty.

Ukryte wiersze nie są wysyłane. Dziennik prób jest zachowany i nadal blokuje
ponowny POST po nieznanym wyniku. Schemat 12 bez zmian; stan poprawiania
jest w obrębie otwartego okna paczki. Testy wyłącznie na syntetycznym API,
bez rzeczywistych zapisów Allegro i bez odbioru natywnego Windows.
