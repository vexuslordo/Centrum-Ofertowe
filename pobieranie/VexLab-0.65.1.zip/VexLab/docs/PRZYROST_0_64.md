# VexLab 0.64 — porównanie cen i opisy dostępności

## Cennik i Allegro

Otwórz Oferty → Zmiana cen, wybierz cennik i kliknij Porównaj z Allegro.
Możesz też zaznaczyć jeden cennik w Cennikach i wybrać Więcej → Porównaj ceny
z Allegro. Cennik bazowy nie jest wybierany za Ciebie. Wybierasz źródło.

Tabela pokazuje SKU, produkt, ID/status oferty, docelowe brutto i netto,
aktualne brutto Allegro, różnicę kwotową i procentową oraz wynik.
Reguła: pełne brutto bez groszy, VAT23%, zgodnie z ustawieniami właściciela.
Kwoty istniejącego cennika i ofert pozostają bez zmian. Tylko podgląd,
bez zapisu cen i bez publikowania lub kończenia ofert.

Filtruj Różnica, Bez zmian, Brak oferty, Wiele ofert, Nieaktywna, Inna waluta
lub Do sprawdzenia. Szukaj SKU, nazwy lub ID. Wskaż wiersz, aby przeczytać
powód. Raport CSV zawiera wszystkie widoczne wyniki filtra i kontekst konta,
cennika oraz daty odczytu. Program nie nadpisuje istniejącego CSV.
Zatrzymaj przerywa porównanie; po zmianie konta wykonaj nowy odczyt.
Kolejny krok roadmapy: zatwierdzana aktualizacja cen na podstawie raportu.

## Dostępność w Produktach

Na polecenie właściciela tekst w kolumnie Dostępność odpowiada kropce Allegro:
zielona → Dostępny, szara → Sprawdź, czerwona → Wycofano. Czerwona dotyczy
ręcznie wycofanego produktu lub potwierdzonego odczytu wyłącznie zakończonych
ofert tego SKU. ACTIVE ma pierwszeństwo przed ENDED z innych dopasowanych
ofert, chyba że produkt ręcznie oznaczono jako wycofany. Mieszanka szkiców
lub brak potwierdzenia nie jest traktowana jak wycofanie.

Ręcznie wycofany produkt nie kończy automatycznie aktywnej oferty Allegro:
podpowiedź kropki wskazuje konieczność osobnego sprawdzenia. Dostępność
magazynowa nie jest wyliczana. Wewnętrzne ręczne oznaczenia katalogu zachowane;
filtr ręcznej dostępności jest tak nazwany. Przy braku odczytu szara kropka
zawsze znaczy Sprawdź; brak oferty nie jest dowodem wycofania asortymentu.

Bez zmian schematu SQLite, cen lub opublikowanych ofert. PrestaShop odłożony.
Testy i zrzuty wykorzystują dane syntetyczne, bez prawdziwego konta. Windows
nie był dostępny do natywnego odbioru.
