"""Karty kanałów i pasek statusu pokazują wyłącznie potwierdzony stan połączenia."""

from pathlib import Path

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona_menu


def tekst(value: str, nazwa: str = "") -> QLabel:
    label = QLabel(value)
    label.setTextFormat(Qt.TextFormat.PlainText)
    label.setObjectName(nazwa)
    label.setMinimumWidth(0)
    return label


def logo(nazwa: str) -> QWidget:
    host = QWidget()
    row = QHBoxLayout(host)
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(5)
    znak = QLabel()
    if nazwa == "Allegro":
        plik = Path(__file__).with_name("zasoby") / "allegro-wordmark.svg"
        znak.setPixmap(QIcon(str(plik)).pixmap(98, 40))
    else:
        znak.setPixmap(ikona_menu("PrestaShop", True).pixmap(28, 28))
    row.addWidget(znak)
    if nazwa != "Allegro":
        napis = QLabel('Presta<span style="color:#DF0067">Shop</span>')
        napis.setObjectName("nazwaPrestaShop")
        row.addWidget(napis)
    row.addStretch()
    host.setAccessibleName(nazwa)
    host.setFixedHeight(42)
    return host


class KartaKanalu(QFrame):
    def __init__(self, nazwa: str) -> None:
        super().__init__()
        self.setObjectName("kartaKanalu")
        self.setMinimumWidth(0)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(14)
        layout.addWidget(logo(nazwa))
        self.status = tekst("●  Niepołączono", "statusKanalu")
        layout.addWidget(self.status)
        form = QGridLayout()
        form.setHorizontalSpacing(6)
        form.setVerticalSpacing(9)
        self.wartosci: list[QLabel] = []
        pola = (
            ("Konto:", "Oferty:", "Limit:")
            if nazwa == "Allegro"
            else ("Sklep:", "Produkty:", "Wersja:")
        )
        for i, pole in enumerate(pola):
            form.addWidget(tekst(pole, "opis"), i, 0)
            value = tekst("—")
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.wartosci.append(value)
            form.addWidget(value, i, 1)
        form.setColumnStretch(1, 1)
        layout.addLayout(form)
        layout.addStretch()
        self.ustaw(None)

    def ustaw(self, konto: str | None) -> None:
        self.status.setText("●  Połączono" if konto is not None else "●  Niepołączono")
        self.status.setProperty("polaczono", konto is not None)
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)
        self.wartosci[0].setText(konto if konto is not None else "—")
        self.wartosci[0].setToolTip(konto or "Brak połączonego konta")
        self.wartosci[1].setToolTip("Nie pobrano łącznej liczby ofert/produktów tego kanału.")
        self.wartosci[2].setToolTip("Informacja nie została udostępniona przez integrację.")


class PanelIntegracji(QFrame):
    zarzadzaj = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("karta")
        self.setProperty("panelIntegracji", True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 14, 15, 14)
        layout.setSpacing(12)
        header = QHBoxLayout()
        header.addWidget(tekst("Integracje", "tytul"))
        header.addStretch()
        self.zarzadzaj_przycisk = QPushButton("Zarządzaj")
        self.zarzadzaj_przycisk.setObjectName("zarzadzajIntegracjami")
        self.zarzadzaj_przycisk.clicked.connect(self.zarzadzaj.emit)
        header.addWidget(self.zarzadzaj_przycisk)
        layout.addLayout(header)
        cards = QHBoxLayout()
        cards.setSpacing(12)
        self.allegro = KartaKanalu("Allegro")
        self.presta = KartaKanalu("PrestaShop")
        self.presta.setToolTip("Integracja PrestaShop jest w przygotowaniu.")
        cards.addWidget(self.allegro, 1)
        cards.addWidget(self.presta, 1)
        layout.addLayout(cards, 1)


class PasekIntegracji(QWidget):
    allegro = Signal()
    presta = Signal()

    def __init__(self, dostepne: bool) -> None:
        super().__init__()
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(14)
        self.status = tekst(
            "Niepołączono" if dostepne else "Integracje niewdrożone", "statusNaglowka"
        )
        row.addWidget(self.status)
        for nazwa, signal in (("Allegro", self.allegro), ("PrestaShop", self.presta)):
            b = QToolButton()
            b.setObjectName("kanalNaglowka")
            b.setText(nazwa)
            b.setAccessibleName(f"Otwórz {nazwa}")
            b.setToolTip(f"Otwórz {nazwa}")
            b.setIcon(ikona_menu(nazwa, True))
            b.setIconSize(QSize(22, 22))
            b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
            b.clicked.connect(signal.emit)
            row.addWidget(b)
        self.ustaw(None, dostepne)

    def ustaw(self, konto: str | None, dostepne: bool = True) -> None:
        self.status.setText(
            f"●  Połączono: {konto}"
            if konto is not None
            else ("●  Niepołączono" if dostepne else "Integracje niewdrożone")
        )
        self.status.setToolTip(
            (f"Allegro: {konto}" if konto is not None else "Allegro: niepołączone")
            + " • PrestaShop: integracja w przygotowaniu"
        )
        self.status.setProperty("polaczono", konto is not None)
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)
