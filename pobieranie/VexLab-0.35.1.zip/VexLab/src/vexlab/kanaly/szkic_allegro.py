"""Jawne mapowanie odczytu /sale/product-offers/{id}, bez utrwalania odpowiedzi API."""

from decimal import Decimal, InvalidOperation
from typing import Any
from urllib.parse import urlsplit

from vexlab.przypadki_uzycia.allegro import BladAllegro, SzczegolySzkicuAllegro, SzkicAllegro
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu


def pole(d: dict[str, Any], key: str, limit: int = 1000) -> str:
    value = d.get(key, "")
    if value is None:
        value = ""
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 for c in value):
        raise ValueError(key)
    return value


def adres(value: object) -> str:
    if not isinstance(value, str) or len(value) > 4096:
        raise ValueError("url")
    url = urlsplit(value)
    if url.scheme != "https" or not url.hostname or url.username or url.password or url.fragment:
        raise ValueError("url")
    if any(ord(c) <= 32 for c in value):
        raise ValueError("url")
    return value


def mapuj_szkic(d: dict[str, Any], ident: str) -> SzczegolySzkicuAllegro:
    try:
        if pole(d, "id", 100) != ident or not pole(d, "name"):
            raise ValueError("id")
        if d.get("publication", {}).get("status") != "INACTIVE":
            raise BladAllegro("STAN", "Oferta nie jest już szkicem INACTIVE. Odśwież listę.")
        images = d.get("images") or []
        if not isinstance(images, list) or len(images) > 32:
            raise ValueError("images")
        zdjecia = tuple(adres(x) for x in images)
        sections = (d.get("description") or {}).get("sections") or []
        if not isinstance(sections, list) or len(sections) > 100:
            raise ValueError("sections")
        wynik = []
        for section in sections:
            items = section["items"]
            if not isinstance(items, list) or not 1 <= len(items) <= 2:
                raise ValueError("items")
            elementy = []
            for item in items:
                if item["type"] == "TEXT":
                    content = item["content"]
                    if not isinstance(content, str) or len(content) > 100000:
                        raise ValueError("content")
                    elementy.append(ElementPodgladu("tekst", tekst=content))
                elif item["type"] == "IMAGE":
                    elementy.append(ElementPodgladu("obraz", adres=adres(item["url"])))
                else:
                    raise ValueError("type")
            wynik.append(tuple(elementy))
        price = (d.get("sellingMode") or {}).get("price") or {}
        amount, currency = pole(price, "amount", 50), pole(price, "currency", 3)
        if amount or currency:
            value = Decimal(amount)
            if not value.is_finite() or value < 0 or len(currency) != 3 or not currency.isalpha():
                raise ValueError("price")
        stock = (d.get("stock") or {}).get("available")
        if stock is not None and (type(stock) is not int or stock < 0):
            raise ValueError("stock")
        return SzczegolySzkicuAllegro(
            ident,
            pole(d, "name"),
            pole(d.get("external") or {}, "id"),
            amount,
            currency,
            stock,
            pole(d.get("category") or {}, "id", 100),
            zdjecia,
            tuple(wynik),
        )
    except (ValueError, TypeError, AttributeError, KeyError, InvalidOperation):
        raise BladAllegro("ODPOWIEDZ", "Nieprawidłowe szczegóły szkicu Allegro.") from None


def mapuj_pozycje(d: dict[str, Any]) -> SzkicAllegro:
    """Dodatkowe pola z już pobieranej listy; nie wyliczamy metryk sprzedaży."""
    ident, tytul = pole(d, "id", 100), pole(d, "name")
    if not ident or not tytul:
        raise ValueError("id/name")
    price = (d.get("sellingMode") or {}).get("price") or {}
    amount, currency = pole(price, "amount", 50), pole(price, "currency", 3)
    if amount or currency:
        try:
            number = Decimal(amount)
        except InvalidOperation:
            raise ValueError("price") from None
        if (
            not number.is_finite()
            or number < 0
            or len(currency) != 3
            or not currency.isascii()
            or not currency.isalpha()
        ):
            raise ValueError("price")
    stock = (d.get("stock") or {}).get("available")
    if stock is not None and (type(stock) is not int or stock < 0):
        raise ValueError("stock")
    image = (d.get("primaryImage") or {}).get("url")
    return SzkicAllegro(
        ident,
        tytul,
        pole(d.get("external") or {}, "id"),
        amount,
        currency,
        stock,
        adres(image) if image else "",
    )
