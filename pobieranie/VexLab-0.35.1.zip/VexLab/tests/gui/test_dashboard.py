import pytest
from PySide6.QtCore import Qt

from vexlab.gui.dashboard import DashboardView, EdytorDashboardu
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.przypadki_uzycia.dashboard import StanDashboardu
from vexlab.przypadki_uzycia.powloka import Motyw, PreferencjePowloki


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_rzeczywiste_alerty_brak_fikcyjnych_statystyk_i_responsywnosc(qtbot, qapp, motyw):
    zastosuj_motyw(qapp, motyw)
    view = DashboardView(PreferencjePowloki())
    qtbot.addWidget(view)
    view.resize(1320, 900)
    view.show()
    view.ustaw_stan(StanDashboardu(120, 5, 7, 2, 3, 1))
    assert view.karty["produkty"].liczba.text() == "120"
    assert all(view.karty[k].liczba.text() == "—" for k in view.karty if k != "produkty")
    with qtbot.waitSignal(view.alert) as signal:
        view.alerty["ean"].click()
    assert signal.args == ["ean"]
    assert view.ai_wartosci["bez_opisu"].text() == "3"
    assert view.wykres.chart().series()[0].count() == 0
    view.ustaw_allegro("konto_testowe")
    assert "konto_testowe" in view.statusy["Allegro"].text()
    view.ustaw_allegro(None)
    assert "Niepołączono" in view.statusy["Allegro"].text()
    view.resize(600, 700)
    qtbot.waitUntil(lambda: not view._szeroki)
    qtbot.waitUntil(lambda: view.horizontalScrollBar().maximum() == 0)


def test_konfigurator_emituje_zmiane_i_zachowuje_ukryta_sekcje(qtbot):
    view = DashboardView(PreferencjePowloki())
    qtbot.addWidget(view)
    edytor = EdytorDashboardu(PreferencjePowloki(), view)
    qtbot.addWidget(edytor)
    with qtbot.waitSignal(edytor.zmiana) as wynik:
        edytor.lista.item(0).setCheckState(Qt.CheckState.Unchecked)
    assert wynik.args[1] == ("kpi",)
    view.ukryte = ("kpi",)
    view.rozmiesc(True, wymus=True)
    assert view.sekcje["kpi"].isHidden()
