from dataclasses import replace

from PySide6.QtCore import QBuffer, QIODevice, Qt
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QLineEdit

from vexlab.gui.edytor_opisu import EdytorOpisu
from vexlab.gui.podglad_oferty import ObrazPodgladu, TekstSekcji
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec


def png():
    image = QImage(100, 50, QImage.Format.Format_RGB32)
    image.fill(Qt.GlobalColor.blue)
    out = QBuffer()
    out.open(QIODevice.OpenModeFlag.WriteOnly)
    assert image.save(out, "PNG")
    return bytes(out.data())


def oferta():
    return OfertaPodglad(
        1,
        "SKU",
        "Tytuł",
        "<p>Opis</p>",
        "",
        "",
        "",
        ("https://example.test/a.png",),
        (
            (
                ElementPodgladu("obraz", adres="https://example.test/a.png"),
                ElementPodgladu("tekst", "<h2>Opis sekcji</h2><p>Treść</p>"),
            ),
        ),
        (),
    )


def test_zdjecia_w_edytorze_i_pelny_uklad_bez_zmiany_szkicu(qtbot):
    wywolania = []

    class Zrodlo:
        def pobierz_obraz(self, url):
            wywolania.append(url)
            return ZdjecieDane(url, png(), png())

    def uruchom(fn, ok, blad):
        ok(fn())

    d = oferta()
    e = EdytorOpisu(d, zdjecia=PodgladZdjec(Zrodlo()), uruchom=uruchom)
    qtbot.addWidget(e)
    e.resize(1100, 700)
    e.show()
    qtbot.waitUntil(lambda: len(wywolania) == 1)
    assert not e.findChild(ObrazPodgladu).obraz.isNull()
    e.tabs.setCurrentIndex(2)
    qtbot.waitUntil(lambda: not e.obrazy.trwa)
    assert len(wywolania) == 1
    assert all(not img.obraz.isNull() for img in e.pelna_oferta.findChildren(ObrazPodgladu))
    assert "Opis sekcji" in e.pelna_oferta.findChild(TekstSekcji).toPlainText()
    assert e.opis() == d.opis and e.wynik_sekcji() == d.sekcje and not e.zmieniony
    e.findChild(QLineEdit).setText("https://example.test/b.png")
    e.findChild(QLineEdit).editingFinished.emit()
    qtbot.waitUntil(lambda: len(wywolania) == 2)


def test_blad_pobierania_i_zamkniecie_podczas_odczytu(qtbot):
    zadania = []

    def uruchom(fn, ok, blad):
        zadania.append((fn, ok, blad))

    class Zrodlo:
        def pobierz_obraz(self, url):
            return ZdjecieDane(url, png(), png())

    e = EdytorOpisu(oferta(), zdjecia=PodgladZdjec(Zrodlo()), uruchom=uruchom)
    qtbot.addWidget(e)
    e.show()
    qtbot.waitUntil(lambda: bool(zadania))
    zadania[0][2]("MEDIA", "Brak sieci")
    assert "Nie udało" in e.findChild(ObrazPodgladu).text()
    assert not e.zmieniony
    f = EdytorOpisu(replace(oferta(), zdjecia=()), zdjecia=PodgladZdjec(Zrodlo()), uruchom=uruchom)
    f.show()
    qtbot.waitUntil(lambda: len(zadania) == 2)
    f.deleteLater()
    qtbot.wait(10)
    zadania[1][1](ZdjecieDane("url", png(), png()))


def test_podglad_paczki_pokazuje_zdjecia_w_galerii_i_sekcjach(qtbot):
    from PySide6.QtWidgets import QPlainTextEdit, QWidget

    from vexlab.gui.paczki_ofert import SzczegolyPaczki

    parent = QWidget()
    qtbot.addWidget(parent)
    wywolania = []
    dane = png()

    class Zrodlo:
        def pobierz_obraz(self, url):
            wywolania.append(url)
            return ZdjecieDane(url, dane, dane)

    def uruchom(fn, ok, blad):
        ok(fn())

    d = SzczegolyPaczki(oferta(), parent, PodgladZdjec(Zrodlo()), uruchom)
    d.show()
    qtbot.waitUntil(lambda: len(wywolania) == 1 and not d.obrazy.trwa)
    obrazy = d.findChildren(ObrazPodgladu)
    assert len(obrazy) == 3 and all(not img.obraz.isNull() for img in obrazy)
    d.tabs.setCurrentIndex(3)
    assert "Opis sekcji" in d.tabs.widget(3).findChild(TekstSekcji).toPlainText()
    assert not any(
        "https://" in p.toPlainText() for p in d.tabs.widget(0).findChildren(QPlainTextEdit)
    )
    assert oferta().sekcje[0][0].adres == "https://example.test/a.png"
    d.reject()
    assert not d.obrazy.aktywne


def test_podglad_paczki_blad_i_zamkniecie_przed_wynikiem(qtbot):
    from PySide6.QtWidgets import QWidget

    from vexlab.gui.paczki_ofert import SzczegolyPaczki

    parent = QWidget()
    qtbot.addWidget(parent)
    zadania = []

    def uruchom(fn, ok, blad):
        zadania.append((fn, ok, blad))

    class Zrodlo:
        def pobierz_obraz(self, url):
            return ZdjecieDane(url, png(), png())

    serwis = PodgladZdjec(Zrodlo())
    d = SzczegolyPaczki(oferta(), parent, serwis, uruchom)
    d.show()
    qtbot.waitUntil(lambda: len(zadania) == 1)
    zadania[0][2]("MEDIA", "Brak sieci")
    assert all("Nie udało" in img.text() for img in d.findChildren(ObrazPodgladu))
    d.reject()
    e = SzczegolyPaczki(oferta(), parent, serwis, uruchom)
    e.show()
    qtbot.waitUntil(lambda: len(zadania) == 2)
    e.reject()
    e.deleteLater()
    qtbot.wait(10)
    zadania[1][1](ZdjecieDane("https://example.test/a.png", png(), png()))


def test_tabela_przechowuje_miniature_zamiast_pelnego_obrazu(qtbot):
    from PySide6.QtWidgets import QWidget

    from vexlab.gui.podglad_oferty import ObrazyOferty

    mini = png()

    class Zrodlo:
        def pobierz_obraz(self, url):
            return ZdjecieDane(url, b"pelne-dane-nie-sa-ladowane-przez-tabele", mini)

    parent = QWidget()
    qtbot.addWidget(parent)
    manager = ObrazyOferty(
        parent, PodgladZdjec(Zrodlo()), lambda fn, ok, blad: ok(fn()), miniatury=True
    )
    label = manager.obraz("https://example.test/mini.png")
    qtbot.waitUntil(lambda: not label.obraz.isNull())
    assert label.obraz.width() == 100 and label.obraz.height() == 50
    assert manager.cache["https://example.test/mini.png"] == mini
    manager.zamknij()
