from collections.abc import Iterator
from pathlib import Path
from threading import Event, get_ident

import pytest
from PySide6.QtCore import QSettings, Qt, QTimer
from PySide6.QtWidgets import QApplication, QLabel
from pytestqt.qtbot import QtBot

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.okno import MENU, OknoVexLab
from vexlab.przypadki_uzycia.dashboard import Dashboard
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow
from vexlab.rdzen.kontrakty import BladTechniczny


@pytest.fixture
def okno(qtbot: QtBot, tmp_path: Path) -> Iterator[OknoVexLab]:
    ustawienia = QSettings(str(tmp_path / "preferencje.ini"), QSettings.Format.IniFormat)
    powloka = PowlokaAplikacji(PreferencjeQt(ustawienia), "uzytkownik_testowy", "test")
    repo = KatalogSQLite(tmp_path / "katalog.sqlite3")
    widget = OknoVexLab(
        powloka,
        KatalogProduktow(repo, repo),
        RejestrProducentow(repo),
        EksportujKatalog(EksportCSV()),
        ImportujProdukty(CzytnikTabel(), ImportSQLite(repo.plik), repo),
        dashboard=Dashboard(repo),
    )
    qtbot.addWidget(widget, before_close_func=lambda w: qtbot.waitUntil(lambda: not w._zadania))
    widget.show()
    qtbot.waitUntil(
        lambda: widget.status.text() == "Gotowy • lokalny katalog" and not widget._zadania
    )
    yield widget
    qtbot.waitUntil(lambda: not widget._zadania)
    widget.close()


def zapisz_produkt(qtbot: QtBot, okno: OknoVexLab, nazwa: str, sku: str) -> None:
    okno.dodaj_produkt()
    qtbot.waitUntil(lambda: okno.formularz is not None)
    dialog = okno.formularz
    assert dialog is not None
    dialog.nazwa.setText(nazwa)
    dialog.sku.setText(sku)
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)


def test_pusta_baza_bez_demonstracyjnych_rekordow(okno: OknoVexLab) -> None:
    assert okno.model.rowCount() == 0
    assert okno.liczba_produktow.text() == "0"
    assert "pusty" in okno.dashboard_info.text()
    assert okno.powloka.nazwa_uzytkownika == "uzytkownik_testowy"
    assert not any("Połączono" in label.text() for label in okno.findChildren(QLabel))
    assert len(okno.dashboard.karty) == 7
    assert okno.dashboard.karty["obrot"].liczba.text() == "—"
    assert not okno.dashboard.przyciski_akcji[4].isEnabled()


def test_sprawdzenie_gt_dziala_w_tle_i_nie_zmienia_stanu_integracji(qtbot, okno):
    from datetime import UTC, datetime

    from vexlab.przypadki_uzycia.srodowisko_gt import SprawdzSrodowiskoGT, SrodowiskoGT

    watki = []

    class Czytnik:
        def odczytaj(self):
            watki.append(get_ident())
            return SrodowiskoGT("Windows testowy", "3.13", 64)

    class Zegar:
        def teraz(self):
            return datetime(2026, 11, 7, 12, tzinfo=UTC)

    okno.panel_gt.serwis = SprawdzSrodowiskoGT(Czytnik(), Zegar())
    okno.przejdz("Ustawienia")
    okno.ustawienia_zakladki.setCurrentIndex(1)
    okno.integracje.setCurrentWidget(okno.panel_gt)
    okno.panel_gt.wykonaj()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert watki and all(w != get_ident() for w in watki)
    assert "Połączenie z serwerem: nie było sprawdzane" in okno.panel_gt.raport.toPlainText()
    assert "niewdrożone" in okno.stan_integracji.text()


def test_nawigacja_ma_kolejnosc_z_referencji_i_jawne_stany(okno: OknoVexLab) -> None:
    nazwy = [nazwa for grupa, pozycje in MENU for nazwa, symbol in pozycje]
    assert list(okno.przyciski_menu) == nazwy
    for nazwa in nazwy:
        okno.przejdz(nazwa)
        assert okno.stos.currentWidget() is okno.strony[nazwa]
        assert okno.przyciski_menu[nazwa].isChecked()
    okno.przejdz("Allegro")
    assert any(
        "W przygotowaniu" in label.text() for label in okno.strony["Allegro"].findChildren(QLabel)
    )


def test_dodanie_wyszukiwanie_ctrl_k_i_edycja(qtbot: QtBot, okno: OknoVexLab) -> None:
    zapisz_produkt(qtbot, okno, "Żółty produkt testowy", "TEST-A")
    assert okno.model.rowCount() == 1
    assert okno.liczba_produktow.text() == "1"
    okno.activateWindow()
    qtbot.keyClick(okno, Qt.Key.Key_K, Qt.KeyboardModifier.ControlModifier)
    qtbot.waitUntil(okno.szukaj.hasFocus)
    okno.szukaj.setText("żÓŁTY")
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.stos.currentWidget() is okno.strony["Produkty"]
    assert okno.filtr.rowCount() == 1
    okno.szukaj.setText("nieistniejący")
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.filtr.rowCount() == 0
    assert "Brak wyników" in okno.info_produktow.text()
    okno.szukaj.clear()
    qtbot.waitUntil(lambda: not okno._zadania)
    okno.edytuj_indeks(okno.filtr.index(0, 1))
    qtbot.waitUntil(lambda: okno.formularz is not None)
    dialog = okno.formularz
    assert dialog is not None
    dialog.nazwa.setText("Zmieniona nazwa")
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.model.produkty[0].nazwa == "Zmieniona nazwa"
    assert okno.model.produkty[0].wersja == 2


def test_duplikat_sku_zachowuje_formularz_i_nie_dodaje_wiersza(
    qtbot: QtBot, okno: OknoVexLab
) -> None:
    zapisz_produkt(qtbot, okno, "Pierwszy", "TEST-A")
    zapisz_produkt(qtbot, okno, "Drugi", "TEST-A")
    dialog = okno.formularz
    assert dialog is not None and dialog.isVisible()
    assert "SKU" in dialog.blad.text()
    assert dialog.nazwa.text() == "Drugi"
    assert dialog.sku.text() == "TEST-A"
    assert dialog.zapisz.isEnabled()
    assert okno.model.rowCount() == 1
    dialog.sku.setText("TEST-B")
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.model.rowCount() == 2


def test_konflikt_zapisu_w_gui_zachowuje_wpisana_tresc(qtbot: QtBot, okno: OknoVexLab) -> None:
    zapisz_produkt(qtbot, okno, "Pierwszy", "TEST-A")
    produkt = okno.model.produkty[0]
    okno.edytuj_indeks(okno.filtr.index(0, 1))
    qtbot.waitUntil(lambda: okno.formularz is not None)
    dialog = okno.formularz
    assert dialog is not None
    dialog.nazwa.setText("Moja edycja")
    okno.katalog.edytuj(produkt.id, produkt.wersja, DaneProduktu("Inny formularz", produkt.sku))
    qtbot.mouseClick(dialog.zapisz, Qt.MouseButton.LeftButton)
    qtbot.waitUntil(lambda: not okno._zadania)
    assert dialog.isVisible()
    assert "innym formularzu" in dialog.blad.text()
    assert dialog.nazwa.text() == "Moja edycja"
    assert okno.katalog.wyszukaj()[0].nazwa == "Inny formularz"


def test_motyw_i_menu_zachowywane_w_preferencjach(okno: OknoVexLab, qapp: QApplication) -> None:
    okno.zmien_menu()
    assert okno.menu.width() == 64
    assert all(button.accessibleName() for button in okno.przyciski_menu.values())
    okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.JASNY))
    assert qapp.property("motyw_ciemny") is False
    zapisane = okno.powloka._magazyn.odczytaj()
    assert zapisane.motyw == Motyw.JASNY
    assert zapisane.menu_zwiniete is True
    okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(Motyw.CIEMNY))
    assert qapp.property("motyw_ciemny") is True


@pytest.mark.parametrize("szerokosc", [800, 1100, 1536])
def test_okno_reaguje_na_rozne_szerokosci(qtbot: QtBot, okno: OknoVexLab, szerokosc: int) -> None:
    okno.resize(szerokosc, 900)
    qtbot.waitUntil(lambda: okno._kolumny == (4 if szerokosc >= 1250 else 2))
    assert not okno.grab().isNull()
    assert okno.szukaj.isVisible()


def test_wynik_starego_odczytu_nie_zastepuje_nowszego(okno: OknoVexLab) -> None:
    okno._numer_odczytu = 2
    okno._wczytano(1, [])
    assert okno.status.text() == "Gotowy • lokalny katalog"


def test_io_poza_watkiem_gui_i_wynik_wraca_do_gui(qtbot: QtBot, okno: OknoVexLab) -> None:
    glowny = get_ident()
    zwolnij = Event()
    rozpoczeto = Event()
    wyniki = []
    zdarzenia = []

    def praca() -> int:
        rozpoczeto.set()
        if not zwolnij.wait(5):
            raise RuntimeError("Przekroczono czas testu")
        return get_ident()

    def wynik(watek: object) -> None:
        wyniki.append((watek, get_ident()))

    try:
        okno._uruchom(praca, wynik)
        qtbot.waitUntil(rozpoczeto.is_set)
        QTimer.singleShot(0, lambda: zdarzenia.append("GUI żyje"))
        qtbot.waitUntil(lambda: bool(zdarzenia))
        assert not wyniki
    finally:
        zwolnij.set()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert wyniki[0][0] != glowny
    assert wyniki[0][1] == glowny


def test_blad_odczytu_nie_udaje_pustego_katalogu(
    qtbot: QtBot, okno: OknoVexLab, monkeypatch: pytest.MonkeyPatch
) -> None:
    zapisz_produkt(qtbot, okno, "Istniejący", "TEST-A")

    def awaria(zapytanie: object, wybrane: tuple = ()) -> list:
        raise BladTechniczny("Błąd odczytu katalogu")

    monkeypatch.setattr(okno.odczyt_katalogu, "strona", awaria)
    okno.odswiez()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.model.rowCount() == 1
    assert "poprzedni odczyt" in okno.info_produktow.text()
    assert okno.liczba_produktow.text() == "—"
    okno.szukaj.setText("abc")
    qtbot.waitUntil(lambda: not okno._zadania)
    assert "Błąd odczytu" in okno.info_produktow.text()


def test_zamkniecie_podczas_zadania_nie_przerywa_zapisu(qtbot: QtBot, okno: OknoVexLab) -> None:
    zwolnij = Event()
    okno._uruchom(lambda: zwolnij.wait(5), lambda wynik: None)
    try:
        assert okno.close() is False
        assert okno.isVisible()
    finally:
        zwolnij.set()
    qtbot.waitUntil(lambda: not okno._zadania)


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_belka_rozwija_tylko_swoje_pozycje_i_nie_nawiguje(qtbot, okno, motyw):
    okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(motyw))
    przed = okno.stos.currentWidget()
    sprzedaz = okno.sekcje_menu["SPRZEDAŻ"]
    assert not okno.przyciski_menu["Allegro"].isVisible()
    qtbot.mouseClick(sprzedaz.belka, Qt.MouseButton.LeftButton)
    assert okno.przyciski_menu["Allegro"].isVisible()
    assert okno.przyciski_menu["PrestaShop"].isVisible()
    assert not okno.przyciski_menu["Produkty"].isVisible()
    assert okno.stos.currentWidget() is przed
    qtbot.mouseClick(sprzedaz.belka, Qt.MouseButton.LeftButton)
    assert not okno.przyciski_menu["Allegro"].isVisible()
    assert okno.stos.currentWidget() is przed


def test_belki_klawiatura_zapis_i_otwarcie_aktywnej_zakladki(qtbot, okno):
    belka = okno.sekcje_menu["SPRZEDAŻ"].belka
    belka.setFocus()
    qtbot.keyClick(belka, Qt.Key.Key_Space)
    assert belka.isChecked() and "Zwiń" in belka.accessibleName()
    assert okno.powloka._magazyn.odczytaj().rozwiniete_grupy == ("SPRZEDAŻ",)
    okno.przejdz("Aktywne oferty")
    assert okno.przyciski_menu["Aktywne oferty"].isVisible()
    assert okno.przyciski_menu["Aktywne oferty"].isChecked()
    assert okno.sekcje_menu["OFERTY"].belka.isChecked()


def test_globalne_zwiniecie_zachowuje_stan_belkek(okno):
    okno.zmien_grupe("SPRZEDAŻ", True)
    okno.zmien_menu()
    assert all(s.belka.isHidden() for s in okno.sekcje_menu.values())
    assert all(b.isVisible() for b in okno.przyciski_menu.values())
    okno.zmien_menu()
    assert okno.przyciski_menu["Allegro"].isVisible()
    assert not okno.przyciski_menu["Produkty"].isVisible()


def test_awaria_zapisu_grupy_przywraca_stan_widoku(qtbot, okno, monkeypatch):
    from vexlab.rdzen.kontrakty import BladTechniczny

    def blad(*args):
        raise BladTechniczny("Nie można zapisać ustawień")

    komunikaty = []
    monkeypatch.setattr(okno.powloka._magazyn, "zapisz", blad)
    monkeypatch.setattr(okno, "_blad", komunikaty.append)
    qtbot.mouseClick(okno.sekcje_menu["SPRZEDAŻ"].belka, Qt.MouseButton.LeftButton)
    assert not okno.przyciski_menu["Allegro"].isVisible()
    assert not okno.sekcje_menu["SPRZEDAŻ"].belka.isChecked()
    assert okno.powloka.preferencje.rozwiniete_grupy == ()
    assert komunikaty


@pytest.mark.parametrize("motyw", [Motyw.CIEMNY, Motyw.JASNY])
def test_belki_i_zakladki_mieszcza_sie_w_obszarze_menu(qtbot, okno, motyw):
    from PySide6.QtCore import QPoint
    from PySide6.QtWidgets import QScrollArea

    okno.wybor_motywu.setCurrentIndex(okno.wybor_motywu.findData(motyw))
    okno.resize(800, 700)
    for grupa in okno.sekcje_menu:
        okno.zmien_grupe(grupa, True)
    scroll = okno.menu.findChild(QScrollArea)
    przyciski = [s.belka for s in okno.sekcje_menu.values()] + list(okno.przyciski_menu.values())

    def mieszcza_sie():
        szerokosc = scroll.viewport().width()
        return scroll.horizontalScrollBar().maximum() == 0 and all(
            b.mapTo(scroll.viewport(), QPoint(0, 0)).x() >= 0
            and b.mapTo(scroll.viewport(), QPoint(0, 0)).x() + b.width() <= szerokosc
            for b in przyciski
        )

    qtbot.waitUntil(mieszcza_sie)
    scroll.ensureWidgetVisible(okno.przyciski_menu["Szablony układów"])
    okno.przyciski_menu["Szablony układów"].setFocus()
    qtbot.waitUntil(mieszcza_sie)
    assert scroll.horizontalScrollBar().value() == 0


def test_allegro_konfiguracja_w_ustawieniach_odczyt_w_tle_i_restart(qtbot, okno):
    from vexlab.przypadki_uzycia.allegro import (
        AplikacjaAllegro,
        KontoAllegro,
        PolaczAllegro,
        StronaSzkicowAllegro,
        TokenAllegro,
        ZapamietaneAllegro,
    )

    watki = []

    class Magazyn:
        zapis = ZapamietaneAllegro(
            AplikacjaAllegro("test-client", "test-secret"),
            KontoAllegro("123", "testowy"),
            "old-refresh",
        )

        def odczytaj(self):
            watki.append(get_ident())
            return self.zapis

        def zapisz(self, d):
            self.zapis = d

        def usun(self):
            self.zapis = None

    class API:
        def odnow(self, *a):
            return TokenAllegro("access", 3600, "rotated")

        def konto(self, *a):
            return KontoAllegro("123", "testowy")

        def szkice(self, *a):
            return StronaSzkicowAllegro((), 0, 0, 50)

    class Czas:
        def teraz(self):
            return 100

    m = Magazyn()
    c = PolaczAllegro(API(), Czas(), m)

    def utworz():
        w = OknoVexLab(
            okno.powloka, okno.katalog, okno.producenci, okno.eksport, okno.importer, allegro=c
        )
        qtbot.addWidget(w, before_close_func=lambda w: qtbot.waitUntil(lambda: not w._zadania))
        w.show()
        qtbot.waitUntil(lambda: not w._zadania and w.strona_allegro.sesja is not None)
        return w

    w = utworz()
    assert [w.ustawienia_zakladki.tabText(i) for i in range(4)] == [
        "Ogólne",
        "Integracje",
        "Dane i kopie",
        "O programie",
    ]
    w.przejdz("Ustawienia")
    w.ustawienia_zakladki.setCurrentIndex(2)
    assert w.lokalizacja_danych.isVisible() and w.lokalizacja_danych.isReadOnly()
    w.ustawienia_zakladki.setCurrentIndex(3)
    assert w.informacje_programu.isVisible()
    w.przejdz("Allegro")
    assert not w.strona_allegro.klient.isVisible()
    w.integracje.setCurrentWidget(w.panel_gt)
    w.strona_allegro.ustawienia_zadane.emit()
    assert w.integracje.currentWidget() is w.strona_allegro.panel_polaczenia
    assert w.stos.currentWidget() is w.strony["Ustawienia"]
    assert w.ustawienia_zakladki.currentIndex() == 1
    assert not w.strona_allegro.klient.isVisible()
    w.strona_allegro.dane_aplikacji.ustaw_otwarte(True)
    assert w.strona_allegro.klient.isVisible()
    assert not w.strona_allegro.sekret.text()
    assert "testowy" in w.stan_integracji.text()
    assert watki and all(t != get_ident() for t in watki)
    w.close()
    assert m.zapis is not None
    ponownie = utworz()
    assert ponownie.strona_allegro.zapamietane
    ponownie.close()


def test_dashboard_zarzadzaj_integracjami_otwiera_wlasciwa_zakladke(okno):
    okno.przejdz("Dashboard")
    okno.dashboard.zarzadzaj_przycisk.click()
    assert okno.stos.currentWidget() is okno.strony["Ustawienia"]
    assert okno.ustawienia_zakladki.currentIndex() == 1


def test_dashboard_odswieza_licznik_po_dodaniu_i_otwiera_globalny_alert(qtbot, okno):
    zapisz_produkt(qtbot, okno, "Produkt bez EAN", "BEZ-EAN")
    assert okno.liczba_produktow.text() == "1"
    assert okno.dashboard.ai_wartosci["bez_zdjec"].text() == "1"
    okno.dashboard.alerty["ean"].click()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.stos.currentWidget() is okno.strony["Produkty"]
    assert okno.filtr.ean is False
    assert okno._liczba_wynikow == 1
    okno.wyczysc_filtry()
    qtbot.waitUntil(lambda: not okno._zadania)
    assert okno.filtr.ean is None
