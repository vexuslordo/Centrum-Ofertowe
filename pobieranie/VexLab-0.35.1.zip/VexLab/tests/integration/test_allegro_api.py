import base64
import json
from urllib.parse import parse_qs, urlsplit

import pytest

from vexlab.kanaly.allegro import AllegroAPI
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    BladAllegro,
    KontoAllegro,
    OdpowiedzAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)


class Transport:
    def __init__(self, *odpowiedzi):
        self.odpowiedzi = list(odpowiedzi)
        self.wywolania = []

    def wyslij(self, *args):
        self.wywolania.append(args)
        status, dane = self.odpowiedzi.pop(0)
        return OdpowiedzAllegro(status, json.dumps(dane).encode())


def device(**zmiany):
    return dict(
        device_code="test-device",
        user_code="TEST-CODE",
        verification_uri_complete="https://allegro.pl/uzytkownik/potwierdz?code=TEST-CODE",
        interval=5,
        expires_in=600,
        **zmiany,
    )


def test_device_i_token_przez_formularz_oraz_basic_bez_sekretow_w_url():
    t = Transport(
        (200, device()),
        (
            200,
            dict(
                access_token="test-access",
                token_type="bearer",
                expires_in=3600,
                refresh_token="ignorowany",
            ),
        ),
    )
    api = AllegroAPI(t)
    a = AplikacjaAllegro("test-client", "test-secret")
    kod = api.rozpocznij(a)
    token = api.token(a, kod.kod)
    assert token.wartosc == "test-access"
    for metoda, url, headers, _body in t.wywolania:
        assert metoda == "POST" and urlsplit(url).hostname == "allegro.pl"
        assert not urlsplit(url).query
        assert "test-secret" not in url
        assert base64.b64decode(headers["Authorization"].split()[1]) == b"test-client:test-secret"
        assert headers["Content-Type"] == "application/x-www-form-urlencoded"
    assert parse_qs(t.wywolania[0][3].decode())["client_id"] == ["test-client"]
    assert parse_qs(t.wywolania[1][3].decode())["grant_type"] == [
        "urn:ietf:params:oauth:grant-type:device_code"
    ]
    assert all(
        v not in repr(obj)
        for obj, v in [
            (a, "test-secret"),
            (kod, "test-device"),
            (kod, "TEST-CODE"),
            (token, "test-access"),
        ]
    )


@pytest.mark.parametrize(
    "status,error,kod",
    [
        (400, "authorization_pending", "OCZEKIWANIE"),
        (400, "slow_down", "WOLNIEJ"),
        (400, "access_denied", "ODMOWA"),
        (400, "expired_token", "WYGASLA"),
        (401, "invalid_client", "APLIKACJA"),
        (403, "other", "UPRAWNIENIA"),
        (429, "other", "LIMIT"),
        (503, "other", "HTTP"),
    ],
)
def test_klasyfikacja_bledow_bez_surowej_odpowiedzi(status, error, kod):
    api = AllegroAPI(Transport((status, {"error": error, "error_description": "PRYWATNE"})))
    with pytest.raises(BladAllegro) as e:
        api.token(AplikacjaAllegro("c", "s"), "device")
    assert e.value.kod == kod and "PRYWATNE" not in str(e.value)


@pytest.mark.parametrize(
    "adres",
    [
        "http://allegro.pl/test",
        "https://evil.invalid/test",
        "https://allegro.pl.evil.invalid/",
        "https://user@allegro.pl/",
        "https://allegro.pl:444/",
        "https://allegro.pl/#bad",
    ],
)
def test_adres_zgody_nie_moze_wyjsc_poza_wlasciwe_allegro(adres):
    d = device()
    d["verification_uri_complete"] = adres
    with pytest.raises(BladAllegro):
        AllegroAPI(Transport((200, d))).rozpocznij(AplikacjaAllegro("c", "s"))


def test_sandbox_nie_wysyla_danych_do_produkcji():
    d = device()
    d["verification_uri_complete"] = "https://allegro.pl.allegrosandbox.pl/potwierdz"
    t = Transport((200, d), (200, {"id": "123", "login": "testowy"}))
    api = AllegroAPI(t)
    api.rozpocznij(AplikacjaAllegro("c", "s", SrodowiskoAllegro.SANDBOX))
    api.konto(SrodowiskoAllegro.SANDBOX, "test-token")
    assert [urlsplit(c[1]).hostname for c in t.wywolania] == [
        "allegro.pl.allegrosandbox.pl",
        "api.allegro.pl.allegrosandbox.pl",
    ]


def test_szkice_tylko_inactive_strona_i_konto_z_bearer():
    t = Transport(
        (
            200,
            {
                "offers": [{"id": "1", "name": "Test", "publication": {"status": "INACTIVE"}}],
                "totalCount": 51,
            },
        )
    )
    s = SesjaAllegro(
        KontoAllegro("123", "testowy"), SrodowiskoAllegro.PRODUKCJA, "test-access", 500
    )
    r = AllegroAPI(t).szkice(s, 50, 50)
    assert r.offset == 50 and r.lacznie == 51 and r.szkice[0].id == "1"
    metoda, url, headers, body = t.wywolania[0]
    assert metoda == "GET" and body is None
    assert parse_qs(urlsplit(url).query) == {
        "publication.status": ["INACTIVE"],
        "offset": ["50"],
        "limit": ["50"],
    }
    assert headers["Authorization"] == "Bearer test-access"
    assert "test-access" not in repr(s)


@pytest.mark.parametrize(
    "value",
    [
        [],
        {"totalCount": True, "offers": []},
        {
            "totalCount": 1,
            "offers": [{"id": "1", "name": "T", "publication": {"status": "ACTIVE"}}],
        },
        {"totalCount": 1, "offers": [{"id": "1", "name": "T", "publication": None}]},
        {
            "totalCount": 2,
            "offers": [{"id": "1", "name": "T", "publication": {"status": "INACTIVE"}}] * 2,
        },
    ],
)
def test_nieprawidlowa_odpowiedz_nie_udaje_pustej_listy(value):
    s = SesjaAllegro(
        KontoAllegro("123", "testowy"), SrodowiskoAllegro.PRODUKCJA, "test-access", 500
    )
    with pytest.raises(BladAllegro):
        AllegroAPI(Transport((200, value))).szkice(s, 0, 50)


def test_odnowienie_uzywa_refresh_i_przekazuje_obrocony_token_bez_query():
    t = Transport(
        (
            200,
            {
                "access_token": "new-access",
                "refresh_token": "new-refresh",
                "token_type": "bearer",
                "expires_in": 3600,
            },
        )
    )
    r = AllegroAPI(t).odnow(AplikacjaAllegro("test-client", "test-secret"), "old-refresh")
    assert r.odswiezanie == "new-refresh" and "new-refresh" not in repr(r)
    metoda, url, headers, body = t.wywolania[0]
    assert metoda == "POST" and not urlsplit(url).query
    assert parse_qs(body.decode()) == {
        "grant_type": ["refresh_token"],
        "refresh_token": ["old-refresh"],
    }


def szczegoly_szkicu():
    return {
        "id": "123",
        "name": "Testowy szkic",
        "publication": {"status": "INACTIVE"},
        "external": {"id": "SKU-1"},
        "category": {"id": "456"},
        "sellingMode": {"price": {"amount": "12.50", "currency": "PLN"}},
        "stock": {"available": 2},
        "images": ["https://a.allegroimg.com/test.jpg"],
        "description": {
            "sections": [
                {
                    "items": [
                        {"type": "TEXT", "content": "<h1>Opis</h1><p>Treść</p>"},
                        {"type": "IMAGE", "url": "https://a.allegroimg.com/test.jpg"},
                    ]
                }
            ]
        },
    }


def test_szczegoly_szkicu_sa_odczytem_wskazanego_id_i_zachowuja_uklad():
    transport = Transport((200, szczegoly_szkicu()))
    s = SesjaAllegro(KontoAllegro("1", "test"), SrodowiskoAllegro.PRODUKCJA, "test-access", 999)
    wynik = AllegroAPI(transport).szkic(s, "123")
    assert (wynik.id, wynik.sku, wynik.cena, wynik.waluta, wynik.stan) == (
        "123",
        "SKU-1",
        "12.50",
        "PLN",
        2,
    )
    assert [e.typ for e in wynik.sekcje[0]] == ["tekst", "obraz"]
    assert wynik.zdjecia == ("https://a.allegroimg.com/test.jpg",)
    assert transport.wywolania[0][0:2] == ("GET", "https://api.allegro.pl/sale/product-offers/123")
    assert transport.wywolania[0][3] is None


@pytest.mark.parametrize(
    "zmiana",
    [
        {"id": "999"},
        {"publication": {"status": "ACTIVE"}},
        {"images": ["file:///tmp/foto"]},
        {"stock": {"available": True}},
        {"sellingMode": {"price": {"amount": "NaN", "currency": "PLN"}}},
        {"description": {"sections": [{"items": [{"type": "UNKNOWN"}]}]}},
    ],
)
def test_niespojny_lub_nieobslugiwany_szkic_nie_udaje_podgladu(zmiana):
    payload = szczegoly_szkicu() | zmiana
    transport = Transport((200, payload))
    s = SesjaAllegro(KontoAllegro("1", "test"), SrodowiskoAllegro.PRODUKCJA, "test-access", 999)
    with pytest.raises(BladAllegro):
        AllegroAPI(transport).szkic(s, "123")


@pytest.mark.parametrize("ident", ["", "../me", "123?other=1", "１２３"])
def test_id_szkicu_nie_moze_zmienic_sciezki_api(ident):
    transport = Transport()
    s = SesjaAllegro(KontoAllegro("1", "test"), SrodowiskoAllegro.PRODUKCJA, "test-access", 999)
    with pytest.raises(BladAllegro):
        AllegroAPI(transport).szkic(s, ident)
    assert transport.wywolania == []


def test_nieuzupelniony_szkic_pokazuje_braki_zamiast_wymyslac_dane():
    transport = Transport(
        (
            200,
            {
                "id": "123",
                "name": "Nieuzupełniony",
                "publication": {"status": "INACTIVE"},
                "external": {"id": None},
                "description": None,
                "images": None,
                "sellingMode": {"price": None},
                "stock": None,
                "category": None,
            },
        )
    )
    s = SesjaAllegro(KontoAllegro("1", "test"), SrodowiskoAllegro.PRODUKCJA, "test-access", 999)
    wynik = AllegroAPI(transport).szkic(s, "123")
    assert wynik.sku == wynik.cena == wynik.waluta == wynik.kategoria == ""
    assert wynik.stan is None and wynik.zdjecia == wynik.sekcje == ()


def test_device_jawnie_prosi_tylko_o_odczyt_profilu_i_ofert():
    t = Transport((200, device()))
    AllegroAPI(t).rozpocznij(AplikacjaAllegro("test-client", "test-secret"))
    scope = parse_qs(t.wywolania[0][3].decode())["scope"][0].split()
    assert scope == ["allegro:api:profile:read", "allegro:api:sale:offers:read"]


@pytest.mark.parametrize(
    "zasob,scope", [("profil", "profile:read"), ("oferty", "sale:offers:read")]
)
def test_odmowa_wskazuje_konkretny_zasob_i_wymagane_uprawnienie(zasob, scope):
    api = AllegroAPI(Transport((403, {"errors": [{"message": "tajna treść"}]})))
    s = SesjaAllegro(KontoAllegro("1", "test"), SrodowiskoAllegro.PRODUKCJA, "test-access", 999)
    with pytest.raises(BladAllegro) as exc:
        if zasob == "profil":
            api.konto(s.srodowisko, s.token)
        else:
            api.szkice(s, 0, 50)
    assert exc.value.kod == "UPRAWNIENIA"
    assert scope in str(exc.value) and "HTTP 403" in str(exc.value)
    assert "tajna treść" not in str(exc.value) and s.token not in str(exc.value)


def test_lista_szkicow_mapuje_cene_sku_stan_i_miniature_bez_dodatkowych_zadan():
    data = szczegoly_szkicu()
    data["primaryImage"] = {"url": "https://a.allegroimg.com/test.jpg"}
    t = Transport((200, {"offers": [data], "totalCount": 1}))
    s = SesjaAllegro(KontoAllegro("1", "test"), SrodowiskoAllegro.PRODUKCJA, "test-access", 999)
    wynik = AllegroAPI(t).szkice(s, 0, 50).szkice[0]
    assert (wynik.sku, wynik.cena, wynik.waluta, wynik.stan) == ("SKU-1", "12.50", "PLN", 2)
    assert wynik.zdjecie == "https://a.allegroimg.com/test.jpg"
    assert len(t.wywolania) == 1


@pytest.mark.parametrize(
    "zmiana",
    [
        {"primaryImage": {"url": "file:///tmp/foto"}},
        {"sellingMode": {"price": {"amount": "NaN", "currency": "PLN"}}},
        {"stock": {"available": True}},
    ],
)
def test_nieprawidlowe_dodatkowe_pola_listy_nie_udaja_poprawnej_ceny(zmiana):
    t = Transport((200, {"offers": [szczegoly_szkicu() | zmiana], "totalCount": 1}))
    s = SesjaAllegro(KontoAllegro("1", "test"), SrodowiskoAllegro.PRODUKCJA, "test-access", 999)
    with pytest.raises(BladAllegro):
        AllegroAPI(t).szkice(s, 0, 50)
