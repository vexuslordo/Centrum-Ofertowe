"""Zwarty panel danych produktu, rzeczywiste kontrole i akcje wybranej pozycji."""

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QStackedWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.elementy_paneli_ofert import odznaka, separator
from vexlab.gui.statusy_zamowien import kolory_odznaki
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.gui.walidacja_paczki_ui import NAZWY_KONTROLI, OznaczenieOferty
from vexlab.przypadki_uzycia.paczki_ofert import OfertaPodglad

KODY_TONOW = {
    "zielony": "NEW",
    "niebieski": "PROCESSING",
    "czerwony": "CANCELLED",
    "zloty": "SUSPENDED",
    "szary": "",
}


def kolor_opisu(label: QLabel, ton: str) -> None:
    dark = label.palette().color(label.palette().ColorRole.Window).lightness() < 128
    _, color, _ = kolory_odznaki(KODY_TONOW[ton], dark)
    label.setStyleSheet(f"color:{color};background:transparent;border:0;font-size:11px;")


def dane_cen(oferta: OfertaPodglad, stan: OznaczenieOferty) -> tuple[str, str, str]:
    """Netto jest podglądem tylko przy jawnej stawce PL. Nie zmienia danych oferty."""
    gross = oferta.cena or "—"
    if stan.plan is None:
        return gross + " · waluta nieustalona", "—", "—"
    u = stan.plan.ustawienia
    gross = u.cena or oferta.cena or "—"
    rate = next((r.wartosc for r in u.vat.stawki if r.kraj == "PL"), "") if u.vat else ""
    net = "—"
    if rate:
        try:
            price = Decimal(gross.replace(" ", "").replace(",", "."))
            vat = Decimal(rate.replace(",", ".").removesuffix("%"))
            if price.is_finite() and vat.is_finite() and price >= 0 and 0 <= vat <= 100:
                net = (
                    str((price / (1 + vat / 100)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
                    + " "
                    + u.waluta
                )
        except InvalidOperation:
            pass
    return gross + " " + u.waluta, net, (rate + "% (PL)" if rate else "—")


class PanelWalidacjiOferty(QFrame):
    problem = Signal(str)
    podglad = Signal()
    przygotowanie = Signal()
    edycja = Signal()
    historia = Signal()
    producent = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("panelWalidacjiPaczki")
        self._osadzony = False
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(7)
        header = etykieta("Szczegóły produktu")
        header.setObjectName("tytulSekcjiAllegro")
        layout.addWidget(header)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        body = QWidget()
        body.setObjectName("trescWalidacjiOferty")
        box = QVBoxLayout(body)
        box.setContentsMargins(0, 4, 14, 10)
        box.setSpacing(5)
        self.foto = QLabel("Wybierz ofertę")
        self.foto.setObjectName("zdjeciePaneluOfert")
        self.foto.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.foto.setFixedHeight(155)
        self.foto.setWordWrap(True)
        self.foto.setAccessibleName("Zdjęcie wybranej oferty")
        box.addWidget(self.foto)
        self.nazwa = etykieta("")
        self.nazwa.setObjectName("tytulSekcjiAllegro")
        box.addWidget(self.nazwa)
        self.status = etykieta("")
        box.addWidget(self.status, 0, Qt.AlignmentFlag.AlignLeft)
        grid = QGridLayout()
        grid.setContentsMargins(0, 5, 0, 5)
        grid.setVerticalSpacing(7)
        grid.setHorizontalSpacing(12)
        grid.setColumnStretch(1, 1)
        self.pola: dict[str, QLabel] = {}
        for row, name in enumerate(
            ("SKU", "EAN", "Cena brutto", "Cena netto", "VAT", "Ilość", "ID Allegro")
        ):
            caption = etykieta(name)
            caption.setObjectName("opis")
            caption.setStyleSheet("font-size:11px;")
            grid.addWidget(caption, row, 0)
            value = etykieta("—")
            value.setMinimumWidth(0)
            value.setStyleSheet("font-size:11px;")
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            value.setAccessibleName(name + " wybranej oferty")
            grid.addWidget(value, row, 1)
            self.pola[name] = value
        self.pola["Cena"] = self.pola["Cena brutto"]  # Dotychczasowi odbiorcy panelu.
        box.addLayout(grid)
        separator(box)
        title = etykieta("Walidacja danych")
        title.setObjectName("tytulSekcjiAllegro")
        box.addWidget(title)
        checks = QGridLayout()
        checks.setContentsMargins(4, 8, 4, 10)
        checks.setHorizontalSpacing(8)
        checks.setVerticalSpacing(6)
        checks.setColumnStretch(1, 1)
        self.kontrole: dict[str, QLabel] = {}
        self.symbole: dict[str, QLabel] = {}
        for row, name in enumerate(NAZWY_KONTROLI):
            symbol = etykieta("—")
            symbol.setFixedWidth(16)
            caption = etykieta(name)
            caption.setStyleSheet("font-size:11px;")
            result = etykieta("—")
            result.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            result.setContentsMargins(0, 2, 4, 2)
            result.setMinimumWidth(0)
            result.setAccessibleName("Weryfikacja: " + name)
            checks.addWidget(symbol, row, 0)
            checks.addWidget(caption, row, 1)
            checks.addWidget(result, row, 2)
            self.symbole[name] = symbol
            self.kontrole[name] = result
        box.addLayout(checks)
        self.tytul_problemow = etykieta("Problemy")
        self.tytul_problemow.setObjectName("tytulSekcjiAllegro")
        box.addWidget(self.tytul_problemow)
        self.problemy = etykieta("")
        self.problemy.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        box.addWidget(self.problemy)
        self.linki: dict[str, QPushButton] = {}
        for key, name in (
            ("gpsr", "GPSR, dostawa i warunki…"),
            ("parametry", "Parametry produktu…"),
            ("produkt", "Produkt Allegro / kategoria…"),
            ("ean", "Sprawdź EAN…"),
            ("vat", "VAT…"),
            ("producent", "Producent lokalny…"),
            ("zrodlo", "Zdjęcia, opis i sekcje…"),
            ("bledy", "Powód i poprawki…"),
        ):
            button = QPushButton(name)
            button.clicked.connect(lambda _=False, key=key: self.problem.emit(key))
            box.addWidget(button)
            self.linki[key] = button
        box.addStretch()
        scroll.setWidget(body)
        body.setAutoFillBackground(False)
        scroll.viewport().setAutoFillBackground(False)
        self.stos = QStackedWidget()
        self.stos.addWidget(scroll)
        self.historia_tekst = QTextBrowser()
        self.historia_tekst.setAccessibleName("Historia wyników bieżącej pozycji")
        self.stos.addWidget(self.historia_tekst)
        layout.addWidget(self.stos, 1)
        self.przygotuj = QPushButton("Przygotuj szkice…")
        self.przygotuj.clicked.connect(self.przygotowanie)
        layout.addWidget(self.przygotuj)
        actions = QGridLayout()
        actions.setContentsMargins(0, 0, 0, 0)
        actions.setSpacing(5)
        self.edytuj_przycisk = QPushButton("Edytuj produkt")
        self.edytuj_przycisk.setObjectName("primary")
        self.podglad_przycisk = QPushButton("Podgląd Allegro")
        self.historia_przycisk = QPushButton("Historia zmian")
        self.producent_przycisk = QPushButton("Otwórz producenta")
        self.edytuj_przycisk.clicked.connect(self.edycja)
        self.podglad_przycisk.clicked.connect(self.podglad)
        self.historia_przycisk.clicked.connect(self.historia)
        self.producent_przycisk.clicked.connect(self.producent)
        self.edytuj_przycisk.setToolTip("Edytuj dane tej pozycji paczki.")
        self.podglad_przycisk.setToolTip(
            "Podgląd treści przygotowywanej oferty, bez publikacji i otwierania linku."
        )
        self.historia_przycisk.setToolTip(
            "Poprzedni i aktualny wynik tej pozycji w bieżącej sesji."
        )
        for i, button in enumerate(
            (
                self.edytuj_przycisk,
                self.podglad_przycisk,
                self.historia_przycisk,
                self.producent_przycisk,
            )
        ):
            button.setMinimumWidth(0)
            button.setStyleSheet("font-size:11px;padding:5px 3px;")
            button.setFixedHeight(30)
            actions.addWidget(button, i // 2, i % 2)
        layout.addLayout(actions)
        self.wyczysc()

    def tryb_przygotowania(self, aktywny: bool) -> None:
        self._osadzony = aktywny
        self.tytul_problemow.setVisible(not aktywny)
        self.problemy.setVisible(not aktywny)
        self.przygotuj.setVisible(not aktywny)
        for button in self.linki.values():
            button.hide()

    def pokaz_historie(self, tekst: str) -> None:
        self.historia_tekst.setPlainText(tekst)
        self.stos.setCurrentIndex(0 if self.stos.currentIndex() == 1 else 1)

    def ustaw_akcje(self, edycja: bool, historia: bool, producent: bool) -> None:
        self.edytuj_przycisk.setEnabled(edycja)
        self.historia_przycisk.setEnabled(historia)
        self.producent_przycisk.setEnabled(producent)

    def wyczysc(self) -> None:
        self.stos.setCurrentIndex(0)
        self.historia_tekst.clear()
        self.ustaw_akcje(False, False, False)
        self.podglad_przycisk.setEnabled(False)
        self.foto.clear()
        self.foto.setText("Wybierz ofertę z tabeli")
        self.nazwa.clear()
        self.status.clear()
        for label in self.pola.values():
            label.setText("—")
        for name, label in self.kontrole.items():
            label.setText("—")
            self.symbole[name].setText("—")
            kolor_opisu(label, "szary")
        for button in self.linki.values():
            button.hide()
        self.problemy.setText("Wybierz wiersz, aby zobaczyć dostępne wyniki.")

    def pokaz(
        self, oferta: OfertaPodglad, stan: OznaczenieOferty, obraz: bytes = b"", *, ident: str = ""
    ) -> None:
        self.stos.setCurrentIndex(0)
        self.podglad_przycisk.setEnabled(True)
        self.nazwa.setText(oferta.tytul)
        odznaka(self.status, "✓ " + stan.status if stan.gotowa else "● " + stan.status, stan.ton)
        self.pola["SKU"].setText(oferta.sku or "—")
        self.pola["EAN"].setText(oferta.ean or "—")
        self.pola["ID Allegro"].setText(ident or "—")
        gross, net, vat = dane_cen(oferta, stan)
        self.pola["Cena brutto"].setText(gross)
        self.pola["Cena netto"].setText(net)
        self.pola["VAT"].setText(vat)
        self.pola["Ilość"].setText(str(stan.plan.ustawienia.ilosc) if stan.plan else "—")
        for name, text, tone in stan.kontrole:
            label = self.kontrole[name]
            label.setText(
                "OK"
                if tone == "zielony"
                else "Sprawdź"
                if tone == "czerwony"
                else "Nie dotyczy"
                if text.startswith("Nie dotyczy")
                else "Nie sprawdzono"
            )
            label.setToolTip(text if text != label.text() else "")
            self.symbole[name].setText(
                "✓" if tone == "zielony" else "!" if tone == "czerwony" else "○"
            )
            kolor_opisu(label, tone)
            kolor_opisu(self.symbole[name], tone)
        self.problemy.setText("\n\n".join(stan.problemy) or "Brak zgłoszonych problemów.")
        for key, button in self.linki.items():
            button.setVisible(
                not self._osadzony
                and (key in stan.grupy or key == "zrodlo" and bool(oferta.problemy))
            )
        pix = QPixmap()
        self.foto.clear()
        if obraz and pix.loadFromData(obraz):
            self.foto.setPixmap(
                pix.scaled(
                    max(160, self.width() - 30),
                    147,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
        else:
            self.foto.setText(
                "Podgląd zdjęcia z paczki" if oferta.zdjecia else "Brak zdjęcia w paczce"
            )
