"""Import do Produktów: lista, edytowalne SKU, podgląd i jawny zapis lokalny."""

from collections.abc import Callable
from dataclasses import replace
from threading import Event
from typing import cast

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QDialog,
    QHBoxLayout,
    QHeaderView,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.przypadki_uzycia.allegro import SesjaAllegro
from vexlab.przypadki_uzycia.katalog_allegro import (
    KatalogZAllegro,
    OfertaKatalogu,
    PlanImportu,
    PowiazanaOferta,
)

STATUSY = {
    "ACTIVE": "Aktywna",
    "INACTIVE": "Szkic",
    "ACTIVATING": "Aktywowana",
    "ENDED": "Zakończona",
}


class ImportKataloguAllegro(QDialog):
    postep = Signal(int, int)

    def __init__(
        self,
        parent: QWidget,
        serwis: KatalogZAllegro,
        sesja: SesjaAllegro,
        uruchom: Uruchom,
        aktualne: Callable[[], bool],
    ) -> None:
        super().__init__(parent)
        self.serwis, self.sesja, self.uruchom, self.aktualne = serwis, sesja, uruchom, aktualne
        self.oferty: tuple[OfertaKatalogu, ...] = ()
        self.plan: PlanImportu | None = None
        self.rows: tuple[int, ...] = ()
        self.trwa = False
        self.zapisano = False
        self._zapisane_ids: set[str] = set()
        self.stop = Event()
        self.setWindowTitle("Produkty z Twoich ofert Allegro")
        self.resize(1180, 760)
        self.setMinimumSize(760, 520)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        title = etykieta("Pobierz produkty z Allegro")
        title.setObjectName("tytulStronyAllegro")
        layout.addWidget(title)
        layout.addWidget(
            etykieta(
                f"Konto: {sesja.konto.login} • {sesja.srodowisko.value}. Zapis "
                f"wyłącznie w lokalnym katalogu."
            )
        )
        layout.addWidget(
            etykieta(
                "1. Pobierz listę. 2. Zaznacz do 500 ofert i popraw brakujące SKU. "
                "3. Sprawdź podgląd producentów i dopasowań. 4. Zapisz. Istniejące "
                "pola pozostają zachowane."
            )
        )
        tools = QHBoxLayout()
        self.pobierz = QPushButton("Pobierz / odśwież listę konta")
        self.partia = QPushButton("Zaznacz kolejną partię (do 500)")
        self.sprawdz = QPushButton("Przygotuj podgląd zaznaczonych")
        for b in (self.pobierz, self.partia, self.sprawdz):
            tools.addWidget(b)
        layout.addLayout(tools)
        self.tabela = QTableWidget(0, 6)
        self.tabela.setHorizontalHeaderLabels(
            (
                "ID Allegro",
                "Nazwa produktu",
                "SKU (edytuj)",
                "Status",
                "Producent z Allegro",
                "Plan / uwagi",
            )
        )
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tabela.verticalHeader().hide()
        self.tabela.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.tabela.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.tabela.setColumnWidth(2, 180)
        self.tabela.setColumnWidth(4, 180)
        layout.addWidget(self.tabela, 1)
        self.zdjecia = QCheckBox(
            "Pobierz zdjęcia do pustej galerii produktu (maks. 64 MiB na partię)"
        )
        self.zdjecia.setChecked(True)
        layout.addWidget(self.zdjecia)
        self.info = etykieta(
            "Pobranie listy nie zmienia bazy ani ofert Allegro. Producent pochodzi z "
            "parametru produktu, nie GPSR."
        )
        layout.addWidget(self.info)
        bottom = QHBoxLayout()
        bottom.addStretch()
        self.zapisz = QPushButton("Zapisz poprawne pozycje w Produktach")
        self.zapisz.setObjectName("primary")
        self.zapisz.setEnabled(False)
        self.anuluj = QPushButton("Zamknij")
        bottom.addWidget(self.zapisz)
        bottom.addWidget(self.anuluj)
        layout.addLayout(bottom)
        self.pobierz.clicked.connect(self.lista)
        self.partia.clicked.connect(self.zaznacz)
        self.sprawdz.clicked.connect(self.przygotuj)
        self.zapisz.clicked.connect(self.zapis)
        self.anuluj.clicked.connect(self.reject)
        self.tabela.itemChanged.connect(self.uniewaznij)
        self.tabela.itemSelectionChanged.connect(self.uniewaznij)
        self.postep.connect(
            lambda i, n: self.info.setText(
                f"Przetwarzanie {i}/{n}. Możesz zatrzymać przed zapisem."
            )
        )

    def uniewaznij(self) -> None:
        self.plan = None
        self.zapisz.setEnabled(False)

    def _zadanie(
        self, fn: Callable[[], object], ok: Callable[[object], None], zapis: bool = False
    ) -> None:
        if self.trwa or not self.aktualne():
            return
        self.trwa = True
        self.stop.clear()
        self.zapisz.setEnabled(False)
        for b in (self.pobierz, self.partia, self.sprawdz, self.tabela):
            b.setEnabled(False)
        self.anuluj.setText("Zatrzymaj")

        def koniec() -> None:
            self.trwa = False
            for b in (self.pobierz, self.partia, self.sprawdz, self.tabela):
                b.setEnabled(self.aktualne())
            self.anuluj.setText("Zamknij")

        def sukces(w: object) -> None:
            koniec()
            if self.aktualne():
                ok(w)
            else:
                if zapis:
                    self.zapisano = True
                    self.info.setText(
                        "Zapisano lokalnie dane poprzedniego konta. Zamknij okno i odśwież katalog."
                    )
                else:
                    self.info.setText("Konto zmieniło się. Zamknij import i otwórz go ponownie.")

        def blad(k: str, opis: str) -> None:
            koniec()
            self.info.setText(opis)

        self.uruchom(fn, sukces, blad)

    def lista(self) -> None:
        self.uniewaznij()

        def ok(w: object) -> None:
            self.oferty = cast(tuple[OfertaKatalogu, ...], w)
            self._zapisane_ids.clear()
            self.tabela.blockSignals(True)
            self.tabela.setRowCount(len(self.oferty))
            for i, o in enumerate(self.oferty):
                for j, text in enumerate(
                    (
                        o.ident,
                        o.nazwa,
                        "" if o.sku.startswith("vexlab-") else o.sku,
                        STATUSY.get(o.status, o.status),
                        "Do odczytu",
                        "Nie sprawdzono",
                    )
                ):
                    item = QTableWidgetItem(text)
                    item.setToolTip(text)
                    if j != 2:
                        from PySide6.QtCore import Qt

                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    self.tabela.setItem(i, j, item)
            self.tabela.blockSignals(False)
            self.info.setText(
                f"Pobrano {len(self.oferty)} ofert. Wybierz partię i przygotuj podgląd."
            )

        self._zadanie(lambda: self.serwis.lista(self.sesja, self.stop.is_set), ok)

    def zaznacz(self) -> None:
        from PySide6.QtCore import QItemSelectionModel

        self.tabela.clearSelection()
        remaining = [i for i, o in enumerate(self.oferty) if o.ident not in self._zapisane_ids]
        if not remaining:
            self.info.setText(
                "Zapisano wszystkie pozycje tej listy. Odśwież listę, aby ponowić odczyt konta."
            )
        for i in remaining[:500]:
            self.tabela.selectionModel().select(
                self.tabela.model().index(i, 0),
                QItemSelectionModel.SelectionFlag.Select | QItemSelectionModel.SelectionFlag.Rows,
            )

    def przygotuj(self) -> None:
        self.rows = tuple(sorted(i.row() for i in self.tabela.selectionModel().selectedRows()))
        oferty = tuple(
            replace(
                self.oferty[i], sku=cast(QTableWidgetItem, self.tabela.item(i, 2)).text().strip()
            )
            for i in self.rows
        )

        def ok(w: object) -> None:
            self.plan = cast(PlanImportu, w)
            self.tabela.blockSignals(True)
            for row, p in zip(self.rows, self.plan.pozycje, strict=True):
                cast(QTableWidgetItem, self.tabela.item(row, 2)).setText(p.oferta.sku)
                cast(QTableWidgetItem, self.tabela.item(row, 4)).setText(
                    p.oferta.producent or "Brak w ofercie"
                )
                cast(QTableWidgetItem, self.tabela.item(row, 5)).setText(p.blad or p.wynik)
                cast(QTableWidgetItem, self.tabela.item(row, 5)).setToolTip(p.blad or p.wynik)
                cast(QTableWidgetItem, self.tabela.item(row, 4)).setToolTip(p.oferta.producent)
            self.tabela.blockSignals(False)
            count = sum(not p.blad for p in self.plan.pozycje)
            self.zapisz.setEnabled(count > 0)
            self.info.setText(
                f"Do zapisania: {count}. Sprawdź SKU i producentów. Lokalne treści i "
                f"przypisania nie zostaną nadpisane."
            )

        self._zadanie(
            lambda: self.serwis.przygotuj(self.sesja, oferty, self.stop.is_set, self.postep.emit),
            ok,
        )

    def zapis(self) -> None:
        plan = self.plan
        if plan is None:
            return
        images = self.zdjecia.isChecked()

        def ok(w: object) -> None:
            self.zapisano = True
            self._zapisane_ids.update(p.oferta.ident for p in plan.pozycje if not p.blad)
            self.info.setText(str(w))
            self.plan = None

        self._zadanie(
            lambda: self.serwis.zapisz(
                self.sesja,
                plan,
                images,
                lambda: self.stop.is_set() or not self.aktualne(),
                self.postep.emit,
            ),
            ok,
            zapis=True,
        )

    def reject(self) -> None:
        if self.trwa:
            self.stop.set()
            self.info.setText("Zatrzymywanie. Rozpoczęty zapis lokalny jest atomowy.")
            return
        super().reject()


class OfertyProduktowAllegro(QDialog):
    def __init__(
        self,
        parent: QWidget,
        serwis: KatalogZAllegro,
        sesja: SesjaAllegro,
        oferty: tuple[PowiazanaOferta, ...],
        uruchom: Uruchom,
        aktualne: Callable[[], bool],
    ) -> None:
        super().__init__(parent)
        self.serwis, self.sesja, self.oferty, self.uruchom, self.aktualne = (
            serwis,
            sesja,
            oferty,
            uruchom,
            aktualne,
        )
        self.stop = Event()
        self.trwa = False
        self.setWindowTitle("Powiązane oferty Allegro")
        self.resize(1050, 650)
        layout = QVBoxLayout(self)
        layout.addWidget(
            etykieta(
                f"Konto: {sesja.konto.login} • {sesja.srodowisko.value}. Zakończenie "
                f"usuwa ofertę z aktywnej sprzedaży."
            )
        )
        self.tabela = QTableWidget(len(oferty), 4)
        self.tabela.setHorizontalHeaderLabels(("ID Allegro", "Tytuł", "Ostatni status", "Wynik"))
        self.tabela.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabela.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tabela.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        for i, o in enumerate(oferty):
            for j, text in enumerate(
                (
                    o.ident,
                    o.nazwa,
                    STATUSY.get(o.status, o.status),
                    "Wymaga odczytu" if o.oczekuje else "",
                )
            ):
                self.tabela.setItem(i, j, QTableWidgetItem(text))
        layout.addWidget(self.tabela)
        self.info = etykieta(
            "Zaznacz oferty. Najpierw sprawdzimy ich stan w Allegro. Szkice nie zostaną zmienione."
        )
        layout.addWidget(self.info)
        self.zakoncz = QPushButton("Zakończ zaznaczone / sprawdź wynik…")
        self.zakoncz.clicked.connect(self.wyslij)
        layout.addWidget(self.zakoncz)
        close = QPushButton("Zamknij")
        close.clicked.connect(self.reject)
        layout.addWidget(close)

    def wyslij(self) -> None:
        from PySide6.QtWidgets import QMessageBox

        rows = tuple(sorted(i.row() for i in self.tabela.selectionModel().selectedRows()))
        if not rows or self.trwa or not self.aktualne():
            return
        if (
            QMessageBox.question(
                self,
                "Zakończ oferty Allegro",
                f"Konto: {self.sesja.konto.login}. Zakończyć aktywną sprzedaż dla "
                f"{len(rows)} zaznaczonych ofert? "
                "Produkty i pozostałe kanały pozostaną bez zmian. Nieznane wyniki tylko odczytamy.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        self.trwa = True
        self.stop.clear()
        self.zakoncz.setEnabled(False)

        def ok(w: object) -> None:
            self.trwa = False
            self.zakoncz.setEnabled(self.aktualne())
            wyniki = dict(cast(tuple[tuple[str, str], ...], w))
            for i, o in enumerate(self.oferty):
                if o.ident in wyniki:
                    cast(QTableWidgetItem, self.tabela.item(i, 3)).setText(wyniki[o.ident])
            self.info.setText(
                "Sprawdź wyniki przy każdej ofercie. Niepotwierdzone zakończenie wymaga odczytu."
            )

        def blad(k: str, tekst: str) -> None:
            self.trwa = False
            self.zakoncz.setEnabled(self.aktualne())
            self.info.setText(tekst)

        self.uruchom(
            lambda: self.serwis.zakoncz(
                self.sesja,
                tuple(self.oferty[i] for i in rows),
                lambda: self.stop.is_set() or not self.aktualne(),
            ),
            ok,
            blad,
        )

    def reject(self) -> None:
        if self.trwa:
            self.stop.set()
            self.info.setText("Zatrzymywanie po bieżącej operacji. Zaczekaj na wynik.")
            return
        super().reject()
