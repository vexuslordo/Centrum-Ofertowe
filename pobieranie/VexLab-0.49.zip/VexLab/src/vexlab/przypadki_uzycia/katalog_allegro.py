"""Jawny import własnych ofert do katalogu i odrębne kończenie publikacji."""

from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol
from uuid import UUID

from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec

DOSTEPNOSC = {
    "nieustalona": "Nieustalona",
    "dostepny": "Dostępny",
    "niedostepny": "Niedostępny",
    "wycofany": "Wycofany",
}


@dataclass(frozen=True)
class OfertaKatalogu:
    ident: str
    nazwa: str
    sku: str
    status: str
    ean: str = ""
    producent: str = ""
    opis: str = ""
    zdjecia: tuple[str, ...] = ()
    sku_zrodlowe: str | None = None


@dataclass(frozen=True)
class PozycjaImportu:
    oferta: OfertaKatalogu
    produkt: UUID | None
    wersja: int
    wynik: str
    blad: str = ""
    potrzebuje_zdjecia: bool = True


@dataclass(frozen=True)
class PlanImportu:
    konto: str
    srodowisko: str
    pozycje: tuple[PozycjaImportu, ...]


@dataclass(frozen=True)
class PowiazanaOferta:
    produkt: UUID
    ident: str
    nazwa: str
    status: str
    oczekuje: bool = False


class APIKatalogu(Protocol):
    def lista_katalogu(
        self, s: SesjaAllegro, stop: Callable[[], bool]
    ) -> tuple[OfertaKatalogu, ...]: ...
    def szczegoly_katalogu(self, s: SesjaAllegro, oferta: OfertaKatalogu) -> OfertaKatalogu: ...
    def status_katalogu(self, s: SesjaAllegro, ident: str) -> str: ...
    def zakoncz_oferte(self, s: SesjaAllegro, ident: str) -> None: ...


class RepoKataloguAllegro(Protocol):
    def plan_katalogu_allegro(
        self, s: SesjaAllegro, oferty: tuple[OfertaKatalogu, ...]
    ) -> PlanImportu: ...
    def zapisz_katalog_allegro(self, plan: PlanImportu, zdjecia: dict[str, ZdjecieDane]) -> str: ...
    def ustaw_dostepnosc(self, produkty: tuple[UUID, ...], stan: str) -> None: ...
    def powiazane_oferty(
        self, s: SesjaAllegro, produkty: tuple[UUID, ...]
    ) -> tuple[PowiazanaOferta, ...]: ...
    def stan_powiazania(self, s: SesjaAllegro, ident: str, status: str, oczekuje: bool) -> None: ...


class KatalogZAllegro:
    def __init__(self, api: APIKatalogu, repo: RepoKataloguAllegro, zdjecia: PodgladZdjec) -> None:
        self.api, self.repo, self.zdjecia = api, repo, zdjecia

    def lista(self, s: SesjaAllegro, stop: Callable[[], bool]) -> tuple[OfertaKatalogu, ...]:
        return self.api.lista_katalogu(s, stop)

    def przygotuj(
        self,
        s: SesjaAllegro,
        oferty: tuple[OfertaKatalogu, ...],
        stop: Callable[[], bool],
        postep: Callable[[int, int], None],
    ) -> PlanImportu:
        if not oferty or len(oferty) > 500:
            raise BladAllegro("IMPORT", "Wybierz od 1 do 500 ofert na jedną partię importu.")
        details = []
        for i, o in enumerate(oferty):
            if stop():
                raise BladAllegro("ANULOWANO", "Anulowano. Nie zapisano katalogu.")
            details.append(self.api.szczegoly_katalogu(s, o))
            postep(i + 1, len(oferty))
        return self.repo.plan_katalogu_allegro(s, tuple(details))

    def zapisz(
        self,
        s: SesjaAllegro,
        plan: PlanImportu,
        fotografie: bool,
        stop: Callable[[], bool],
        postep: Callable[[int, int], None],
    ) -> str:
        if (s.konto.id, s.srodowisko.value) != (plan.konto, plan.srodowisko):
            raise BladAllegro("KONTO", "Konto zmieniło się. Otwórz import ponownie.")
        obrazy: dict[str, ZdjecieDane] = {}
        koszt = 0
        for i, p in enumerate(plan.pozycje):
            if stop():
                raise BladAllegro("ANULOWANO", "Anulowano. Nie zapisano katalogu.")
            if fotografie and p.potrzebuje_zdjecia and not p.blad and p.oferta.zdjecia:
                for url in p.oferta.zdjecia:
                    if stop():
                        raise BladAllegro("ANULOWANO", "Anulowano. Nie zapisano katalogu.")
                    if url not in obrazy:
                        z = self.zdjecia.pobierz(url)
                        koszt += len(z.dane) + len(z.miniatura)
                        if koszt > 64 * 1024 * 1024:
                            raise BladAllegro(
                                "IMPORT",
                                "Zdjęcia przekraczają 64 MiB. Zmniejsz partię lub wyłącz zdjęcia.",
                            )
                        obrazy[url] = z
            postep(i + 1, len(plan.pozycje))
        if stop():
            raise BladAllegro("ANULOWANO", "Anulowano. Nie zapisano katalogu.")
        return self.repo.zapisz_katalog_allegro(plan, obrazy)

    def dostepnosc(self, produkty: tuple[UUID, ...], stan: str) -> None:
        if stan not in DOSTEPNOSC or not produkty:
            raise BladAllegro("WALIDACJA", "Wybierz produkty i prawidłową dostępność.")
        self.repo.ustaw_dostepnosc(produkty, stan)

    def powiazania(
        self, s: SesjaAllegro, produkty: tuple[UUID, ...]
    ) -> tuple[PowiazanaOferta, ...]:
        return self.repo.powiazane_oferty(s, produkty)

    def zakoncz(
        self, s: SesjaAllegro, oferty: tuple[PowiazanaOferta, ...], stop: Callable[[], bool]
    ) -> tuple[tuple[str, str], ...]:
        uprawnione = {o.ident: o for o in self.powiazania(s, tuple(o.produkt for o in oferty))}
        wyniki = []
        for o in {o.ident: o for o in oferty}.values():
            if o.ident not in uprawnione:
                raise BladAllegro("KONTO", "Oferta nie jest powiązana z tym kontem i produktem.")
            if stop():
                break
            status = o.status
            wyslano = False
            try:
                status = self.api.status_katalogu(s, o.ident)
                if status == "ENDED":
                    self.repo.stan_powiazania(s, o.ident, status, False)
                    wyniki.append((o.ident, "Już zakończona"))
                    continue
                if uprawnione[o.ident].oczekuje:
                    wyniki.append((o.ident, "Wymaga dalszego odczytu; nie ponowiono zapisu"))
                    continue
                if status != "ACTIVE":
                    wyniki.append((o.ident, "Pominięto — oferta nie jest aktywna"))
                    continue
                if s.aplikacja is None or not s.aplikacja.zapis_szkicow:
                    raise BladAllegro("UPRAWNIENIA", "Wymagana zgoda na zapis ofert Allegro.")
                self.repo.stan_powiazania(s, o.ident, status, True)
                wyslano = True
                self.api.zakoncz_oferte(s, o.ident)
                status = self.api.status_katalogu(s, o.ident)
                self.repo.stan_powiazania(s, o.ident, status, status != "ENDED")
                wyniki.append(
                    (
                        o.ident,
                        "Zakończona" if status == "ENDED" else "Przetwarzanie — sprawdź ponownie",
                    )
                )
            except BladAllegro as exc:
                if exc.kod == "ODRZUCONO" and wyslano:
                    self.repo.stan_powiazania(s, o.ident, status, False)
                wyniki.append((o.ident, str(exc)))
        return tuple(wyniki)
