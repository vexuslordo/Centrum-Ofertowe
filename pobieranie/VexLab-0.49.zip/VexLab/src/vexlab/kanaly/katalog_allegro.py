"""Mapowanie własnych ofert do importu katalogu; brak publikacji ACTIVE."""

import json
import time
from collections.abc import Callable
from dataclasses import replace
from urllib.parse import urlencode

from vexlab.kanaly.allegro import hosty, tekst
from vexlab.kanaly.nowe_szkice_allegro import NoweSzkiceAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.katalog_allegro import OfertaKatalogu


class KatalogAllegroAPI(NoweSzkiceAPI):
    def lista_katalogu(
        self, s: SesjaAllegro, stop: Callable[[], bool]
    ) -> tuple[OfertaKatalogu, ...]:
        result = {}
        offset, expected = 0, None
        while True:
            if stop():
                raise BladAllegro("ANULOWANO", "Anulowano pobieranie konta.")
            d = self._get(
                s.srodowisko,
                s.token,
                "/sale/offers?" + urlencode({"limit": 1000, "offset": offset}),
            )
            try:
                rows, total = d["offers"], d["totalCount"]
                if not isinstance(rows, list) or type(total) is not int or not 0 <= total <= 100000:
                    raise ValueError("lista")
                if expected is not None and expected != total:
                    raise ValueError("zmieniona lista")
                expected = total
                for row in rows:
                    ident = tekst(row, "id", 100)
                    if not ident.isdigit() or ident in result:
                        raise ValueError("id")
                    external = row.get("external") or {}
                    sku = external.get("id") or ""
                    if not isinstance(sku, str) or len(sku) > 100:
                        raise ValueError("sku")
                    result[ident] = OfertaKatalogu(
                        ident,
                        tekst(row, "name"),
                        sku,
                        tekst(row["publication"], "status", 32),
                        sku_zrodlowe=sku,
                    )
                offset += len(rows)
                if offset == total:
                    return tuple(result.values())
                if not rows or len(rows) > 1000 or offset > total:
                    raise ValueError("niepełna lista")
            except (KeyError, ValueError, TypeError, AttributeError):
                raise BladAllegro(
                    "IMPORT",
                    "Lista konta zmieniła się, jest niepełna lub przekracza 100 000 "
                    "ofert. Pobierz ponownie.",
                ) from None

    def szczegoly_katalogu(self, s: SesjaAllegro, oferta: OfertaKatalogu) -> OfertaKatalogu:
        d = self._get(s.srodowisko, s.token, self._sciezka(oferta.ident))
        try:
            category = tekst(d["category"], "id", 100)
            if len(d.get("productSet", [])) > 1:
                raise BladAllegro(
                    "IMPORT",
                    "Oferta zestawowa wymaga ręcznego rozdzielenia produktów: " + oferta.ident,
                )
            params = []
            for part in d.get("productSet", []):
                params.extend(part["product"].get("parameters", []))
            params.extend(d.get("parameters", []))
            # Wartości słownikowe (Producent/Marka) zwracane są zwykle jako valuesIds.
            metadata = self.nowy_produkt(s, category)

            def value(names: tuple[str, ...]) -> str:
                for name in names:
                    definitions = [
                        p for p in metadata.parametry if p.nazwa.strip().casefold() == name
                    ]
                    for definition in definitions:
                        row = next((p for p in params if p.get("id") == definition.id), None)
                        if not row:
                            continue
                        values = row.get("values") or []
                        if values:
                            if (
                                not isinstance(values, list)
                                or len(values) != 1
                                or any(not isinstance(v, str) for v in values)
                            ):
                                raise ValueError("wartości")
                            return str(values[0]).strip()
                        ids = row.get("valuesIds") or []
                        dictionary = dict(definition.slownik)
                        if ids:
                            if len(ids) != 1 or ids[0] not in dictionary:
                                raise ValueError("nierozpoznany producent")
                            return dictionary[ids[0]].strip()
                return ""

            producent = value(("producent", "marka"))
            ean = value(("ean (gtin)", "ean", "gtin"))
            texts = []
            for section in (d.get("description") or {}).get("sections", []):
                for item in section["items"]:
                    if item.get("type") == "TEXT":
                        texts.append(tekst(item, "content", 100000))
            images = tuple(tekst(image, "url", 4096) for image in d.get("images", []))
            if any(not url.startswith("https://") for url in images):
                raise ValueError("zdjęcia")
            return replace(
                oferta,
                nazwa=tekst(d, "name"),
                status=tekst(d["publication"], "status"),
                ean=ean,
                producent=producent,
                opis="\n".join(texts),
                zdjecia=images[:16],
            )
        except (KeyError, ValueError, TypeError, AttributeError):
            raise BladAllegro(
                "IMPORT",
                "Nie udało się rozpoznać danych produktu/producenta oferty " + oferta.ident,
            ) from None

    def status_katalogu(self, s: SesjaAllegro, ident: str) -> str:
        d = self._get(s.srodowisko, s.token, self._sciezka(ident))
        try:
            return tekst(d["publication"], "status", 32)
        except (KeyError, ValueError, TypeError):
            raise BladAllegro("IMPORT", "Nie udało się odczytać statusu oferty.") from None

    def zakoncz_oferte(self, s: SesjaAllegro, ident: str) -> None:
        if time.monotonic() < self.odczekaj.get((s.srodowisko.value, ident), 0):
            raise BladAllegro(
                "ODRZUCONO", "Odczekaj przed ponownym zakończeniem zgodnie z limitem Allegro."
            )
        _, host = hosty(s.srodowisko)
        r = self.transport_zapisu.wyslij(
            "PATCH",
            host + self._sciezka(ident),
            self._naglowki(s),
            json.dumps({"publication": {"status": "ENDED"}}).encode(),
        )
        if r.status == 429:
            self.odczekaj[(s.srodowisko.value, ident)] = time.monotonic() + max(1, r.odstep)
        if r.status not in (200, 202):
            raise BladAllegro(
                "ODRZUCONO" if r.status in (400, 401, 403, 404, 409, 422, 429) else "ZAKONCZENIE",
                f"Nie potwierdzono zakończenia (HTTP {r.status}). Sprawdź wynik odczytem.",
            )
