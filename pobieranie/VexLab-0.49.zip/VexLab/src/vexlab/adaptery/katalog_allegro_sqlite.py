"""Atomowy import do istniejącego katalogu, osobne powiązania kont Allegro."""

import sqlite3
from dataclasses import replace
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.domena.producent import Producent
from vexlab.domena.produkt import NieprawidlowyProdukt, Produkt
from vexlab.przypadki_uzycia.allegro import BladAllegro, SesjaAllegro
from vexlab.przypadki_uzycia.katalog_allegro import (
    DOSTEPNOSC,
    OfertaKatalogu,
    PlanImportu,
    PowiazanaOferta,
    PozycjaImportu,
)
from vexlab.przypadki_uzycia.media import ZdjecieDane


class KatalogAllegroSQLite(KatalogSQLite):
    def plan_katalogu_allegro(
        self, s: SesjaAllegro, oferty: tuple[OfertaKatalogu, ...]
    ) -> PlanImportu:
        with self._polaczenie() as c:
            produkty = {r["sku_klucz"]: r for r in c.execute("SELECT * FROM produkty")}
            przypisane = {
                r["oferta_id"]: r["produkt_id"]
                for r in c.execute(
                    "SELECT * FROM oferty_produktow_allegro WHERE srodowisko=? AND konto=?",
                    (s.srodowisko.value, s.konto.id),
                )
            }
            po_id = {r["id"]: r for r in produkty.values()}
            ze_zdjeciami = {r[0] for r in c.execute("SELECT DISTINCT produkt_id FROM zdjecia")}
            nowe: dict[str, UUID] = {}
            wynik = []
            eany: dict[str, str] = {}
            producenci = self._producenci(c)
            for o in oferty:
                old = po_id.get(przypisane.get(o.ident, "")) or produkty.get(
                    o.sku.strip().casefold()
                )
                if (
                    old is not None
                    and o.ident in przypisane
                    and (not o.sku.strip() or o.sku.startswith("vexlab-"))
                ):
                    o = replace(o, sku=old["sku"])
                pid = (
                    UUID(old["id"])
                    if old is not None
                    else nowe.setdefault(o.sku.strip().casefold(), uuid4())
                )
                blad = ""
                try:
                    if not o.sku.strip() or o.sku.startswith("vexlab-"):
                        raise ValueError(
                            "Podaj własne SKU zamiast pustej lub technicznej sygnatury."
                        )
                    Produkt(pid, o.nazwa.strip(), o.sku.strip(), o.opis, ean=o.ean)
                    if old is not None and old["ean"] and o.ean and old["ean"] != o.ean:
                        raise ValueError(
                            "SKU jest zajęte przez produkt z innym EAN. Porównaj dane."
                        )
                    previous_ean = eany.get(str(pid), "")
                    if o.ean and not previous_ean:
                        eany[str(pid)] = o.ean
                    if previous_ean and o.ean and previous_ean != o.ean:
                        raise ValueError("To samo SKU w partii ma różne EAN. Porównaj oferty.")
                    matches = producenci.get(o.producent.strip().casefold(), [])
                    if (old is None or old["producent_id"] is None) and (
                        len(matches) > 1 or (matches and not matches[0]["aktywny"])
                    ):
                        raise ValueError(
                            "Producent niejednoznaczny lub nieaktywny w lokalnej bazie."
                        )
                except (ValueError, NieprawidlowyProdukt) as exc:
                    blad = str(exc)
                wynik.append(
                    PozycjaImportu(
                        o,
                        pid,
                        old["wersja"] if old else 0,
                        (
                            f"Powiąż: {old['sku']} — {old['nazwa']}; uzupełnij braki"
                            if old
                            else "Dodaj produkt"
                        ),
                        blad,
                        str(pid) not in ze_zdjeciami,
                    )
                )
        return PlanImportu(s.konto.id, s.srodowisko.value, tuple(wynik))

    @staticmethod
    def _producenci(c: sqlite3.Connection) -> dict[str, list[dict[str, Any]]]:
        wynik: dict[str, list[dict[str, Any]]] = {}
        for r in c.execute("SELECT * FROM producenci"):
            wynik.setdefault(r["nazwa"].strip().casefold(), []).append(dict(r))
        return wynik

    def zapisz_katalog_allegro(self, plan: PlanImportu, zdjecia: dict[str, ZdjecieDane]) -> str:
        pozycje = tuple(p for p in plan.pozycje if not p.blad)
        if not pozycje:
            raise BladAllegro("IMPORT", "Brak poprawnych pozycji do zapisania.")
        # Kopia spójna przed transakcją. Nie trzymamy blokady podczas odczytów HTTP.
        with self._polaczenie():
            pass
        self._kopia_spojna("kopie_importu_allegro")
        with self._polaczenie() as c:
            c.execute("BEGIN IMMEDIATE")
            for expected_pid, wersja in {(p.produkt, p.wersja) for p in pozycje}:
                r = c.execute(
                    "SELECT wersja FROM produkty WHERE id=?", (str(expected_pid),)
                ).fetchone()
                if (r is None and wersja != 0) or (r is not None and r[0] != wersja):
                    raise BladAllegro(
                        "KONFLIKT", "Katalog zmienił się. Przygotuj podgląd ponownie."
                    )
            producenci = self._producenci(c)
            zapisane = set()
            nowe = 0
            for p in pozycje:
                o, pid = p.oferta, str(p.produkt)
                bound = c.execute(
                    "SELECT produkt_id FROM oferty_produktow_allegro "
                    "WHERE srodowisko=? AND konto=? AND oferta_id=?",
                    (plan.srodowisko, plan.konto, o.ident),
                ).fetchone()
                if bound is not None and bound[0] != pid:
                    raise BladAllegro(
                        "KONFLIKT", "Powiązanie oferty zmieniło się. Otwórz podgląd ponownie."
                    )
                if pid not in zapisane:
                    sources = [x.oferta for x in pozycje if str(x.produkt) == pid]
                    dane = replace(
                        o,
                        producent=next((x.producent for x in sources if x.producent), ""),
                        opis=next((x.opis for x in sources if x.opis), ""),
                        ean=next((x.ean for x in sources if x.ean), ""),
                        zdjecia=next((x.zdjecia for x in sources if x.zdjecia), ()),
                    )
                    old = c.execute("SELECT * FROM produkty WHERE id=?", (pid,)).fetchone()
                    producent_id = old["producent_id"] if old else None
                    if producent_id is None and dane.producent.strip():
                        key = dane.producent.strip().casefold()
                        matches = producenci.get(key, [])
                        if len(matches) > 1 or (matches and not matches[0]["aktywny"]):
                            raise BladAllegro(
                                "PRODUCENT", "Producent zmienił się lub jest nieaktywny."
                            )
                        if matches:
                            producent_id = matches[0]["id"]
                        else:
                            pr = Producent(uuid4(), dane.producent.strip())
                            producent_id = str(pr.id)
                            c.execute(
                                "INSERT INTO "
                                "producenci(id,nazwa,aktywny,wersja,strona_www) VALUES "
                                "(?,?,1,1,'')",
                                (producent_id, pr.nazwa),
                            )
                            producenci[key] = [{"id": producent_id, "aktywny": 1}]
                    image = tuple(zdjecia[url] for url in dane.zdjecia if url in zdjecia)
                    ma = c.execute(
                        "SELECT 1 FROM zdjecia WHERE produkt_id=? LIMIT 1", (pid,)
                    ).fetchone()
                    if old is None:
                        produkt = Produkt(
                            UUID(pid),
                            o.nazwa.strip(),
                            o.sku.strip(),
                            dane.opis,
                            producent_id=UUID(producent_id) if producent_id else None,
                            ean=dane.ean,
                        )
                        c.execute(
                            "INSERT INTO "
                            "produkty(id,nazwa,sku,sku_klucz,opis,wersja,producent_id,ean) "
                            "VALUES (?,?,?,?,?,1,?,?)",
                            (
                                pid,
                                produkt.nazwa,
                                produkt.sku,
                                produkt.klucz_sku,
                                produkt.opis,
                                producent_id,
                                produkt.ean,
                            ),
                        )
                        nowe += 1
                    else:
                        # Uzupełniamy puste pola; lokalne dane zachowane.
                        opis, ean = old["opis"] or dane.opis, old["ean"] or dane.ean
                        Produkt(
                            UUID(pid),
                            old["nazwa"],
                            old["sku"],
                            opis,
                            producent_id=UUID(producent_id) if producent_id else None,
                            ean=ean,
                        )
                        if (opis, ean, producent_id) != (
                            old["opis"],
                            old["ean"],
                            old["producent_id"],
                        ) or (image and not ma):
                            c.execute(
                                "UPDATE produkty SET "
                                "opis=?,ean=?,producent_id=?,wersja=wersja+1 WHERE id=?",
                                (opis, ean, producent_id, pid),
                            )
                    if image and not ma:
                        self._zdjecia(c, UUID(pid), image)
                    zapisane.add(pid)
                c.execute(
                    "INSERT INTO oferty_produktow_allegro(srodowisko,konto,oferta_id,produkt_id,"
                    "status,tytul,sku,producent,ean,odczytano) VALUES (?,?,?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(srodowisko,konto,oferta_id) DO UPDATE SET status=excluded.status,"
                    "tytul=excluded.tytul,sku=excluded.sku,producent=excluded.producent,ean=excluded.ean,"
                    "odczytano=excluded.odczytano,oczekuje=CASE WHEN "
                    "excluded.status='ENDED' THEN 0 ELSE oczekuje END",
                    (
                        plan.srodowisko,
                        plan.konto,
                        o.ident,
                        pid,
                        o.status,
                        o.nazwa,
                        o.sku_zrodlowe if o.sku_zrodlowe is not None else o.sku,
                        o.producent,
                        o.ean,
                        datetime.now(UTC).isoformat(),
                    ),
                )
        return (
            f"Dodano produktów: {nowe}. Zapisano powiązań Allegro: {len(pozycje)}. "
            f"Pominięto błędne: {len(plan.pozycje) - len(pozycje)}."
        )

    def ustaw_dostepnosc(self, produkty: tuple[UUID, ...], stan: str) -> None:
        if stan not in DOSTEPNOSC:
            raise BladAllegro("WALIDACJA", "Nieprawidłowa dostępność.")
        with self._polaczenie() as c:
            c.execute("BEGIN IMMEDIATE")
            for pid in produkty:
                if c.execute("SELECT 1 FROM produkty WHERE id=?", (str(pid),)).fetchone() is None:
                    raise BladAllegro("KONFLIKT", "Produkt został usunięty. Odśwież katalog.")
                c.execute(
                    "INSERT INTO dostepnosc_produktow VALUES (?,?) ON "
                    "CONFLICT(produkt_id) DO UPDATE SET stan=excluded.stan",
                    (str(pid), stan),
                )

    def powiazane_oferty(
        self, s: SesjaAllegro, produkty: tuple[UUID, ...]
    ) -> tuple[PowiazanaOferta, ...]:
        wynik = []
        with self._polaczenie() as c:
            for pid in dict.fromkeys(produkty):
                for r in c.execute(
                    "SELECT * FROM oferty_produktow_allegro WHERE produkt_id=? AND "
                    "srodowisko=? AND konto=?",
                    (str(pid), s.srodowisko.value, s.konto.id),
                ):
                    wynik.append(
                        PowiazanaOferta(
                            pid, r["oferta_id"], r["tytul"], r["status"], bool(r["oczekuje"])
                        )
                    )
        return tuple(wynik)

    def stan_powiazania(self, s: SesjaAllegro, ident: str, status: str, oczekuje: bool) -> None:
        with self._polaczenie() as c:
            c.execute(
                "UPDATE oferty_produktow_allegro SET status=?,oczekuje=?,odczytano=? "
                "WHERE srodowisko=? AND konto=? AND oferta_id=?",
                (
                    status,
                    int(oczekuje),
                    datetime.now(UTC).isoformat(),
                    s.srodowisko.value,
                    s.konto.id,
                    ident,
                ),
            )
