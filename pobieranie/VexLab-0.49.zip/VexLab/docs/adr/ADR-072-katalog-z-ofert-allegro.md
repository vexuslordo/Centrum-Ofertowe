# ADR-072 — uzupełnianie Produktów z własnych ofert Allegro

Właściciel zaakceptował import do istniejącego katalogu Produktów, powiązania
z ofertami, ręczną dostępność i potwierdzane kończenie powiązanych ofert.
Dodatkowo wymaga odczytu nazwy Producenta oraz trwałego zapisu i przypisania.
Produkt pozostaje niezależny od kanału. Producent GPSR nie jest Producentem
katalogowym. Subiekt i publikacja PrestaShop są kolejnymi, odłożonymi etapami.

Import tylko z własnego konta: lista wszystkich stron API, wybór pozycji,
odczyt szczegółów, podgląd lokalnych dopasowań i jawny zapis. Tożsamość
powiązania: środowisko + konto + ID oferty. SKU wymagane i bez rozróżniania
wielkości liter; brak lub stara techniczna sygnatura wymaga ręcznego SKU.
Wiele ofert może wskazywać jeden Produkt. Sam EAN nie łączy Produktów.
Niejednoznaczności EAN/producenta stają się błędami podglądu.

Nowy Produkt otrzymuje nazwę, opis, EAN, Producenta z parametru kategorii
(wartość słownikowa rozwiązywana po ID) i wybrane zdjęcia. Producent jest
wyszukiwany po znormalizowanej nazwie; brak tworzy rzeczywisty wpis, bez seedów.
Istniejące lokalne pola nie są nadpisywane. Jawny import uzupełnia tylko braki;
obserwację kanału aktualizuje w powiązaniu. Cena Allegro nie staje się cennikiem,
a ilość oferty nie jest lokalnym stanem magazynowym.

Dostępność jest ręczna (nieustalona/dostępny/niedostępny/wycofany), niezależna
od statusu publikacji. Brak oferty w odczycie nie oznacza wycofania Produktu.
Filtry katalogu uwzględniają dostępność i powiązania Allegro.

Zakończenie: podgląd ID/statusów bieżącego konta, domyślnie odmowna zgoda,
GET własnej oferty przed PATCH publication.status=ENDED, potwierdzenie GET.
Tylko zakończenie, nigdy ACTIVE. Nieznany wynik wymaga odczytu, bez kolejnego
PATCH. Trwały znacznik próby w powiązaniu zapisany przed żądaniem. Błędy jednej
pozycji raportowane osobno; brak automatycznych zmian dostępności/publikacji.

Migracja 11→12 dodaje tylko dwie tabele powiązań i dostępności, bez zmiany
kolumn Produktu lub starych migracji. Spójna kopia przed migracją istniejącej
bazy, transakcja, kontrola FK i zapis sumy. Przerwanie wycofuje całą migrację.
Stara aplikacja odrzuca schemat12; powrót wymaga zamknięcia programu i kopii
sprzed migracji, zachowując nową bazę osobno. Nie migrować bazy użytkownika
w testach. Import lokalny atomowy z kopią, kontrolą wersji i bez częściowego
zapisania producentów/produktów/powiązań/zdjęć.
