# VexLab 0.49 — Produkty z ofert Allegro i nazwy producentów

## Import do istniejącej zakładki Produkty

1. Połącz swoje konto Allegro. Do samego importu wystarcza odczyt ofert.
2. Otwórz **Produkty → Pobierz z Allegro… → Pobierz / odśwież listę konta**.
   Lista obejmuje aktywne, szkice i zakończone oferty, wszystkie strony API
   (nie tylko widoczne 50). Bezpieczny limit odczytu to 100 000 ofert.
3. Zaznacz pozycje ręcznie (Ctrl/Shift) albo **Zaznacz kolejną partię (do 500)**.
   Import szczegółów i zapis są wykonywane w partiach maksymalnie 500 ofert.
   Po zapisaniu kolejna partia pomija pozycje zapisane w tym przebiegu.
4. Popraw brakujące SKU w tabeli. Puste i dawne techniczne sygnatury
   `vexlab-…` wymagają własnego SKU; nie tworzymy fikcyjnych kodów produktów.
5. **Przygotuj podgląd zaznaczonych**. Zobaczysz nazwę producenta, lokalne
   dopasowanie oraz ewentualne błędy. Wartości producenta są odczytywane
   z parametru produktu „Producent”, następnie „Marka”; ID słownikowe są
   rozwiązywane do nazw z parametrów kategorii. Nie używamy danych GPSR.
6. **Zapisz poprawne pozycje w Produktach**. Opcja zdjęć pobiera galerię
   (do 16 zdjęć) tylko do pustej lokalnej galerii. Powtarzające się adresy
   w partii pobierane są raz. Limit zdjęć to 64 MiB na partię; po jego
   przekroczeniu zmniejsz zaznaczenie lub wyłącz zdjęcia. Baza nie zostaje
   wtedy częściowo zapisana. Nie pobieramy ponownie pełnych lokalnych galerii.

Nowy producent jest zapisany w istniejącym rejestrze **Producenci** i
przypisany do produktu. Istniejący jest rozpoznawany po nazwie bez rozróżniania
wielkości liter. Niejednoznaczny lub nieaktywny wpis wymaga sprawdzenia;
nie tworzymy ukradkiem kolejnego wpisu ani nie aktywujemy go automatycznie.
Brak producenta w ofercie pozostaje jawnym brakiem, bez wymyślania nazwy.

Ponowny import używa powiązania **środowisko + konto + ID oferty**, potem SKU.
Wiele ofert może wskazywać jeden produkt. Sam EAN nie scala produktów.
Różne EAN pod jednym SKU, nieobsługiwany EAN i oferty zestawowe wymagają
porównania zamiast automatycznego scalenia. Podgląd pokazuje błędy.

Lokalne nazwy, SKU, opisy, EAN, przypisania producenta i zdjęcia nie są
nadpisywane. Import uzupełnia wyłącznie puste pola i aktualizuje obserwacje
powiązanych ofert. Zmieniona lokalna wersja po podglądzie blokuje zapis.
Zapis producentów, produktów, galerii i powiązań jest jedną transakcją
z poprzedzającą spójną kopią w `kopie_importu_allegro`.
Cena Allegro nie jest kopiowana do cenników. Ilość oferty nie staje się
stanem magazynowym Produktu. Stany docelowo mogą pochodzić z Subiekta.

## Dostępność i powiązane oferty

W Produktach pojawia się ręczna **Dostępność** i informacja o powiązaniach
**Allegro**. Producent ma własną kolumnę i dotychczasowy filtr.
Dostępne są filtry: nieustalona/dostępny/niedostępny/wycofany oraz powiązane,
bez powiązania, z aktywną lub zakończoną ofertą Allegro.
Statusy są obserwacją z ostatniego importu lub sprawdzenia, nie ciągłą synchronizacją.
Podpowiedź powiązań pokazuje konto, środowisko, ID i statusy.

**Więcej akcji → Dostępność zaznaczonych…** zmienia wyłącznie lokalną
informację. Nie ustala się jej na podstawie braku oferty w odczycie,
zerowej ilości Allegro lub zakończenia pojedynczej publikacji.

**Więcej akcji → Powiązane oferty Allegro / zakończ…** pokazuje oferty
zaznaczonych produktów z bieżącego konta. Wybierz ID i potwierdź zakończenie
sprzedaży (domyślna odpowiedź: Nie). Program najpierw odczytuje stan,
kończy wyłącznie aktywne oferty i potwierdza rezultat GET. Nie modyfikuje
szkiców, innych kont, produktów ani innych kanałów. Ta operacja wymaga
zgody na zapis ofert. Odczyt już zakończonej/niepotwierdzonej operacji
nie wymaga zgody na nowy zapis.

Próba zakończenia jest oznaczana w bazie przed żądaniem. Timeout/nieznany
wynik pozostawia blokadę ponownego PATCH: ten sam przycisk później tylko
odczyta wynik. Potwierdzona odmowa API pozwala na nową jawną próbę;
limit 429 uwzględnia czas oczekiwania. Wynik widać przy każdym ID.
Nie publikujemy ofert ACTIVE i nie uruchamiamy automatycznych wyłączeń.

## Baza i zachowanie danych

Pierwszy odczyt katalogu uaktualnia schemat **11 → 12**. Dodane są wyłącznie
tabele powiązań i ręcznej dostępności. Istniejące dane i pliki pozostają.
Przed migracją istniejącej bazy program tworzy spójną kopię w folderze danych
`kopie_migracji`; nowa pusta baza nie wymaga takiej kopii. Błąd migracji
wycofuje transakcję. Import lokalny ma dodatkową kopię przed zapisem.

Stara wersja programu nie obsługuje schematu 12. Aby wrócić: zamknij VexLab,
zachowaj obecną bazę osobno i przywróć kopię sprzed migracji. W nowej bazie
mogą być już nowe dane; nie usuwaj jej. Kopia przywraca stan z momentu wykonania.
Nie ma automatycznej migracji w dół.

## Zakres i weryfikacja

Produkty są wspólną kartoteką, a sekcja Oferty pozostaje miejscem pracy nad
szkicami i publikacjami. Przyszłe wysyłanie zmian do Allegro i PrestaShop
z tego samego miejsca ma zachować osobny wynik i ponawianie per kanał.
Publikacja PrestaShop i integracja z Subiektem nie są częścią tej wersji.

Podglądy wyłącznie na danych syntetycznych:
[katalog ciemny](screenshots/vexlab-produkty-049-dark.png),
[jasny](screenshots/vexlab-produkty-049-light.png),
[import ciemny](screenshots/vexlab-import-049-dark.png),
[jasny](screenshots/vexlab-import-049-light.png).
Reprodukcja: `python scripts/capture_produkty_allegro_049.py`.

Testy obejmują producenta słownikowego zamiast GPSR, odczyt 13 182 ofert,
idempotencję, wiele ofert na produkt, zachowanie ręcznych danych, galerie,
konflikty EAN/wersji/konta, przerwanie, migracje/kopię/odtworzenie, filtrację,
potwierdzanie zakończenia i brak powtórnego PATCH po nieznanym wyniku.
Dołączono też odpinanie filtrów miniatur przy zamykaniu widoków Qt.
Testy i podglądy działają na Linuksie z kontrolowanym API, bez odczytu
prywatnego konta użytkownika i bez rzeczywistego kończenia jego ofert.

Lokalne SKU wybrane podczas importu jest oddzielone od zaobserwowanej sygnatury Allegro. Przy kolejnym imporcie powiązanie po ID oferty zachowuje przypisanie produktu także wtedy, gdy sygnatura źródłowa jest pusta.
