"""Podglądy na tymczasowej bazie i sztucznym API; bez sieci i kont użytkownika."""

import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from capture_przygotowanie_048 import ObrazTestowy
from PySide6.QtCore import QSettings, QTimer
from PySide6.QtWidgets import QApplication

from vexlab.adaptery.czytnik_importu import CzytnikTabel
from vexlab.adaptery.eksport_csv import EksportCSV
from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.adaptery.katalog_allegro_sqlite import KatalogAllegroSQLite
from vexlab.adaptery.preferencje import PreferencjeQt
from vexlab.gui.design_system import zastosuj_motyw
from vexlab.gui.import_katalogu_allegro import ImportKataloguAllegro
from vexlab.gui.okno import OknoVexLab
from vexlab.przypadki_uzycia.allegro import (
    AplikacjaAllegro,
    KontoAllegro,
    SesjaAllegro,
    SrodowiskoAllegro,
)
from vexlab.przypadki_uzycia.eksport import EksportujKatalog
from vexlab.przypadki_uzycia.importowanie import ImportujProdukty
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.przypadki_uzycia.katalog_allegro import KatalogZAllegro, OfertaKatalogu
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.przypadki_uzycia.powloka import Motyw, PowlokaAplikacji
from vexlab.przypadki_uzycia.producenci import RejestrProducentow


class API:
    def __init__(self) -> None:
        self.oferty = (
            OfertaKatalogu(
                "10001",
                "Osłona testowa — model A",
                "SKU-DEMO-001",
                "ACTIVE",
                "5901234123457",
                "Producent testowy",
                "Opis produktu testowego",
                ("https://images.example.org/demo.png",),
            ),
            OfertaKatalogu(
                "10002",
                "Osłona testowa — model B",
                "SKU-DEMO-002",
                "ENDED",
                "4006381333931",
                "Producent testowy",
                "Drugi produkt demonstracyjny",
                ("https://images.example.org/demo.png",),
            ),
        )

    def lista_katalogu(self, s, stop):
        return self.oferty

    def szczegoly_katalogu(self, s, oferta):
        return oferta


def main() -> int:
    app = QApplication(sys.argv)
    out = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
    result = []
    with TemporaryDirectory(prefix="vexlab-import-demo-") as folder:
        base = Path(folder)
        repo = KatalogAllegroSQLite(base / "katalog.sqlite3")
        api = API()
        service = KatalogZAllegro(api, repo, PodgladZdjec(ObrazTestowy()))
        s = SesjaAllegro(
            KontoAllegro("test", "konto_testowe"),
            SrodowiskoAllegro.SANDBOX,
            "fixture",
            999999,
            aplikacja=AplikacjaAllegro("fixture", "fixture", zapis_szkicow=True),
        )
        plan = service.przygotuj(s, api.oferty, lambda: False, lambda i, n: None)
        service.zapisz(s, plan, True, lambda: False, lambda i, n: None)
        service.dostepnosc((plan.pozycje[0].produkt,), "niedostepny")
        service.dostepnosc((plan.pozycje[1].produkt,), "wycofany")
        w = OknoVexLab(
            PowlokaAplikacji(
                PreferencjeQt(QSettings(str(base / "prefs.ini"), QSettings.Format.IniFormat)),
                "Dane testowe",
                "0.49.dev0",
            ),
            KatalogProduktow(repo, repo),
            RejestrProducentow(repo),
            EksportujKatalog(EksportCSV()),
            ImportujProdukty(CzytnikTabel(), ImportSQLite(repo.plik), repo),
            katalog_allegro=service,
        )
        w.resize(1536, 1000)
        w.show()
        w.przejdz("Produkty")
        attempts = 0

        def ready():
            nonlocal attempts
            attempts += 1
            if w._zadania or not w._katalog_wczytany:
                if attempts > 200:
                    app.exit(1)
                    return
                QTimer.singleShot(50, ready)
                return
            for motif, name in ((Motyw.CIEMNY, "dark"), (Motyw.JASNY, "light")):
                zastosuj_motyw(app, motif)
                app.processEvents()
                result.append(w.grab().save(str(out / f"vexlab-produkty-049-{name}.png")))

                def run(fn, ok, err):
                    ok(fn())

                d = ImportKataloguAllegro(w, service, s, run, lambda: True)
                d.show()
                d.lista()
                d.zaznacz()
                d.przygotuj()
                app.processEvents()
                result.append(d.grab().save(str(out / f"vexlab-import-049-{name}.png")))
                d.reject()

            def close():
                if w._zadania:
                    QTimer.singleShot(50, close)
                else:
                    w.close()
                    app.quit()

            QTimer.singleShot(50, close)

        QTimer.singleShot(150, ready)
        rc = app.exec()
    return rc or int(not all(result))


if __name__ == "__main__":
    raise SystemExit(main())
