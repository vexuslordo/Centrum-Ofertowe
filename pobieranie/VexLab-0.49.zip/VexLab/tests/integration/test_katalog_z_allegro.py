import sqlite3
from contextlib import contextmanager
from dataclasses import replace
from uuid import uuid4

import pytest

from vexlab.adaptery.katalog_allegro_sqlite import KatalogAllegroSQLite
from vexlab.domena.produkt import Produkt
from vexlab.przypadki_uzycia.allegro import BladAllegro
from vexlab.przypadki_uzycia.katalog import KatalogProduktow, ZapytanieKatalogu
from vexlab.przypadki_uzycia.katalog_allegro import KatalogZAllegro, OfertaKatalogu
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec
from vexlab.rdzen.kontrakty import BladTechniczny


@contextmanager
def db(path):
    c = sqlite3.connect(path)
    try:
        with c:
            yield c
    finally:
        c.close()


def row(ident="1", sku="SKU-1", **kw):
    return OfertaKatalogu(
        ident, "Produkt testowy", sku, "ACTIVE", ean="5901234123457", producent="Evotech", **kw
    )


@pytest.fixture
def baza(tmp_path, nowe_szkice_fixture):
    return KatalogAllegroSQLite(tmp_path / "k.sqlite3"), nowe_szkice_fixture[3]


def test_import_producenta_idempotencja_i_wiele_ofert_jeden_produkt(baza):
    repo, s = baza
    p = repo.plan_katalogu_allegro(s, (row(), row("2")))
    assert p.pozycje[0].produkt == p.pozycje[1].produkt
    repo.zapisz_katalog_allegro(p, {})
    repo.zapisz_katalog_allegro(repo.plan_katalogu_allegro(s, (row(), row("2"))), {})
    kat = KatalogProduktow(repo, repo)
    products = kat.strona(ZapytanieKatalogu()).produkty
    assert len(products) == 1 and products[0].producent_nazwa == "Evotech"
    assert products[0].ean == "5901234123457"
    assert products[0].allegro == "2 aktywnych / 2 ofert"
    assert len(repo.lista_producentow()) == 1
    assert len(repo.powiazane_oferty(s, (products[0].id,))) == 2


def test_lokalna_edycja_zachowana_a_puste_pola_uzupelnione(baza):
    repo, s = baza
    produkt = Produkt(uuid4(), "Ręczna nazwa", "SKU-1", "Ręczny opis")
    repo.dodaj(produkt)
    repo.zapisz_katalog_allegro(repo.plan_katalogu_allegro(s, (row(opis="Opis Allegro"),)), {})
    p = KatalogProduktow(repo, repo).strona(ZapytanieKatalogu()).produkty[0]
    assert p.nazwa == "Ręczna nazwa" and p.opis == "Ręczny opis"
    assert p.producent_nazwa == "Evotech" and p.ean == "5901234123457"
    # Powiązanie ID pozostaje stabilne mimo zmienionej sygnatury kanału.
    repo.zapisz_katalog_allegro(repo.plan_katalogu_allegro(s, (row(sku="NOWE-SKU"),)), {})
    assert len(repo.wyszukaj("")) == 1 and repo.wyszukaj("")[0].sku == "SKU-1"


def test_konflikt_wersji_wycofuje_caly_import(baza):
    repo, s = baza
    p = Produkt(uuid4(), "Ręczny", "SKU-1")
    repo.dodaj(p)
    plan = repo.plan_katalogu_allegro(s, (row(), row("2", "NOWY")))
    with repo._polaczenie() as c:
        c.execute("UPDATE produkty SET wersja=wersja+1 WHERE id=?", (str(p.id),))
    with pytest.raises(BladAllegro, match="zmienił"):
        repo.zapisz_katalog_allegro(plan, {})
    assert len(repo.wyszukaj("")) == 1 and not repo.lista_producentow()
    assert not repo.powiazane_oferty(s, (p.id,))


def test_blad_zdjecia_wycofuje_produkt_producenta_i_powiazanie(baza):
    repo, s = baza
    o = row(zdjecia=("https://images.example.org/a.jpg",))
    p = repo.plan_katalogu_allegro(s, (o,))
    with pytest.raises(BladTechniczny, match="zdjęcia"):
        repo.zapisz_katalog_allegro(p, {o.zdjecia[0]: ZdjecieDane(o.zdjecia[0], b"", b"")})
    assert not repo.wyszukaj("") and not repo.lista_producentow()


def test_filtry_dostepnosci_allegro_i_zaznaczenie_poza_strona(baza):
    repo, s = baza
    plan = repo.plan_katalogu_allegro(s, (row(),))
    repo.zapisz_katalog_allegro(plan, {})
    pid = plan.pozycje[0].produkt
    repo.ustaw_dostepnosc((pid,), "wycofany")
    kat = KatalogProduktow(repo, repo)
    assert kat.strona(ZapytanieKatalogu(dostepnosc="wycofany", allegro="aktywne")).liczba == 1
    assert kat.strona(ZapytanieKatalogu(dostepnosc="dostepny")).liczba == 0
    assert kat.strona(ZapytanieKatalogu(allegro="nie")).liczba == 0
    assert not kat.strona(ZapytanieKatalogu(allegro="zakonczone"), (pid,)).wybrane
    repo.stan_powiazania(s, "1", "ENDED", False)
    assert kat.strona(ZapytanieKatalogu(allegro="zakonczone")).liczba == 1


def test_konta_odrebne_i_brak_znikania_nie_wycofuje(baza):
    repo, s = baza
    plan = repo.plan_katalogu_allegro(s, (row(),))
    repo.zapisz_katalog_allegro(plan, {})
    pid = plan.pozycje[0].produkt
    inne = replace(s, konto=replace(s.konto, id="inne"))
    assert not repo.powiazane_oferty(inne, (pid,))
    assert (
        KatalogProduktow(repo, repo).strona(ZapytanieKatalogu()).produkty[0].dostepnosc
        == "nieustalona"
    )


@pytest.mark.parametrize("sku", ["", "vexlab-stara-sygnatura"])
def test_brak_prawidlowego_sku_wymaga_recznego_uzupelnienia(baza, sku):
    repo, s = baza
    plan = repo.plan_katalogu_allegro(s, (row(sku=sku),))
    assert plan.pozycje[0].blad
    assert not repo.wyszukaj("")


def test_inny_ean_nie_laczy_produktow(baza):
    repo, s = baza
    repo.dodaj(Produkt(uuid4(), "Inny", "SKU-1", ean="4006381333931"))
    assert "innym EAN" in repo.plan_katalogu_allegro(s, (row(),)).pozycje[0].blad


def test_zakonczenie_potwierdzane_i_unknown_bez_powtornego_patch(baza):
    repo, s = baza
    plan = repo.plan_katalogu_allegro(s, (row(),))
    repo.zapisz_katalog_allegro(plan, {})

    class API:
        patches = 0
        state = "ACTIVE"

        def status_katalogu(self, s, ident):
            return self.state

        def zakoncz_oferte(self, s, ident):
            self.patches += 1
            raise BladAllegro("NIEZNANY", "Timeout")

    api = API()
    service = KatalogZAllegro(api, repo, None)
    offers = service.powiazania(s, (plan.pozycje[0].produkt,))
    service.zakoncz(s, offers, lambda: False)
    service.zakoncz(s, offers, lambda: False)
    assert api.patches == 1
    api.state = "ENDED"
    assert service.zakoncz(s, offers, lambda: False)[0][1] == "Już zakończona"
    assert not service.powiazania(s, (plan.pozycje[0].produkt,))[0].oczekuje


def test_migracja_11_do_12_kopia_i_odtworzenie(tmp_path):
    path = tmp_path / "k.sqlite3"
    repo = KatalogAllegroSQLite(path)
    produkt = Produkt(uuid4(), "Zachowany", "SKU")
    repo.dodaj(produkt)
    with db(path) as c:
        c.execute("DROP TABLE oferty_produktow_allegro")
        c.execute("DROP TABLE dostepnosc_produktow")
        c.execute("DELETE FROM migracje WHERE wersja=12")
        c.execute("PRAGMA user_version=11")
    assert repo.wyszukaj("")[0] == produkt
    backups = list((tmp_path / "kopie_migracji").glob("*.sqlite3"))
    assert len(backups) == 1
    with db(backups[0]) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 11
        assert c.execute("SELECT sku FROM produkty").fetchone()[0] == "SKU"
    restored = tmp_path / "przywrocona.sqlite3"
    restored.write_bytes(backups[0].read_bytes())
    assert KatalogAllegroSQLite(restored).wyszukaj("")[0] == produkt


def test_przerwana_migracja_pozostawia_wersje11(tmp_path, monkeypatch):
    from vexlab.adaptery import katalog_sqlite

    path = tmp_path / "k.sqlite3"
    repo = KatalogAllegroSQLite(path)
    repo.wyszukaj("")
    with db(path) as c:
        c.execute("DROP TABLE oferty_produktow_allegro")
        c.execute("DROP TABLE dostepnosc_produktow")
        c.execute("DELETE FROM migracje WHERE wersja=12")
        c.execute("PRAGMA user_version=11")
    monkeypatch.setattr(katalog_sqlite, "MIGRACJA_12", (*katalog_sqlite.MIGRACJA_12, "INVALID SQL"))
    with pytest.raises(BladTechniczny):
        repo.wyszukaj("")
    with db(path) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 11
        assert not c.execute(
            "SELECT name FROM sqlite_master WHERE name='dostepnosc_produktow'"
        ).fetchall()


def test_producent_z_drugiej_oferty_tego_samego_sku_uzupelnia_pusta_kartoteke(baza):
    repo, s = baza
    pierwszy = replace(row(), producent="")
    repo.zapisz_katalog_allegro(repo.plan_katalogu_allegro(s, (pierwszy, row("2"))), {})
    assert (
        KatalogProduktow(repo, repo).strona(ZapytanieKatalogu()).produkty[0].producent_nazwa
        == "Evotech"
    )


def test_zdjecia_galerii_pobrane_raz_i_zachowane_przy_ponownym_imporcie(baza):
    repo, s = baza
    calls = []

    class Source:
        def pobierz_obraz(self, url):
            calls.append(url)
            return ZdjecieDane(url, b"obraz", b"miniatura")

    service = KatalogZAllegro(None, repo, PodgladZdjec(Source()))
    o = row(zdjecia=("https://images.example.org/a.jpg", "https://images.example.org/b.jpg"))
    plan = repo.plan_katalogu_allegro(s, (o, replace(o, ident="2")))
    service.zapisz(s, plan, True, lambda: False, lambda i, n: None)
    with repo._polaczenie() as c:
        assert c.execute("SELECT count(*) FROM zdjecia").fetchone()[0] == 2
    assert len(calls) == 2
    plan = repo.plan_katalogu_allegro(s, (o,))
    assert not plan.pozycje[0].potrzebuje_zdjecia
    service.zapisz(s, plan, True, lambda: False, lambda i, n: None)
    assert len(calls) == 2


def test_zmiana_konta_i_anulowanie_nie_zapisuja(baza):
    repo, s = baza
    plan = repo.plan_katalogu_allegro(s, (row(),))
    service = KatalogZAllegro(None, repo, None)
    with pytest.raises(BladAllegro, match="Konto"):
        service.zapisz(
            replace(s, konto=replace(s.konto, id="inne")),
            plan,
            False,
            lambda: False,
            lambda i, n: None,
        )
    with pytest.raises(BladAllegro, match="Anulowano"):
        service.zapisz(s, plan, False, lambda: True, lambda i, n: None)
    assert not repo.wyszukaj("") and not repo.lista_producentow()


def test_blad_portu_przy_przygotowaniu_nie_tworzy_produktow(baza):
    repo, s = baza

    class API:
        def szczegoly_katalogu(self, *args):
            raise BladAllegro("AUTORYZACJA", "Brak uprawnień")

    service = KatalogZAllegro(API(), repo, None)
    with pytest.raises(BladAllegro, match="uprawnień"):
        service.przygotuj(s, (row(),), lambda: False, lambda i, n: None)
    assert not repo.wyszukaj("")


def test_zgodne_sku_z_roznymi_ean_w_partii_wymaga_porownania(baza):
    repo, s = baza
    plan = repo.plan_katalogu_allegro(s, (row(), replace(row("2"), ean="4006381333931")))
    assert not plan.pozycje[0].blad and "różne EAN" in plan.pozycje[1].blad


def test_niezgodna_suma_migracji12_nie_zmienia_danych(baza):
    repo, _ = baza
    repo.dodaj(Produkt(uuid4(), "Nazwa", "SKU"))
    with db(repo.plik) as c:
        c.execute("UPDATE migracje SET suma_sha256='zla' WHERE wersja=12")
    with pytest.raises(BladTechniczny, match="wersji schematu"):
        repo.wyszukaj("")
    with db(repo.plik) as c:
        assert c.execute("SELECT sku FROM produkty").fetchone()[0] == "SKU"


def test_pusty_ean_pierwszej_oferty_nie_ukrywa_konfliktu_w_grupie(baza):
    repo, s = baza
    plan = repo.plan_katalogu_allegro(
        s, (replace(row(), ean=""), row("2"), replace(row("3"), ean="4006381333931"))
    )
    assert not plan.pozycje[1].blad and "różne EAN" in plan.pozycje[2].blad


def test_odczyt_zakonczenia_dziala_bez_zgody_na_nowy_zapis(baza):
    repo, s = baza
    plan = repo.plan_katalogu_allegro(s, (row(),))
    repo.zapisz_katalog_allegro(plan, {})

    class API:
        def status_katalogu(self, s, ident):
            return "ENDED"

        def zakoncz_oferte(self, *args):
            raise AssertionError("Nie wolno wysyłać PATCH")

    service = KatalogZAllegro(API(), repo, None)
    readonly = replace(s, aplikacja=replace(s.aplikacja, zapis_szkicow=False))
    offers = service.powiazania(readonly, (plan.pozycje[0].produkt,))
    assert service.zakoncz(readonly, offers, lambda: False)[0][1] == "Już zakończona"


def test_reczny_sku_nie_nadpisuje_obserwacji_i_powiazanie_uzupelnia_go_przy_odczycie(baza):
    repo, s = baza
    imported = replace(row(), sku="LOKALNY", sku_zrodlowe="")
    plan = repo.plan_katalogu_allegro(s, (imported,))
    repo.zapisz_katalog_allegro(plan, {})
    with repo._polaczenie() as c:
        assert c.execute("SELECT sku FROM oferty_produktow_allegro").fetchone()[0] == ""
    refreshed = repo.plan_katalogu_allegro(s, (replace(row(), sku="", sku_zrodlowe=""),))
    assert not refreshed.pozycje[0].blad
    assert refreshed.pozycje[0].oferta.sku == "LOKALNY"
    assert refreshed.pozycje[0].produkt == plan.pozycje[0].produkt
