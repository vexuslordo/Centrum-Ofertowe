from urllib.parse import parse_qs, urlsplit

import pytest

from vexlab.kanaly.katalog_allegro import KatalogAllegroAPI
from vexlab.przypadki_uzycia.allegro import BladAllegro, OdpowiedzAllegro
from vexlab.przypadki_uzycia.katalog_allegro import OfertaKatalogu
from vexlab.przypadki_uzycia.nowe_szkice_allegro import ParametrSzkicu, ProduktSzkicu


def test_producent_slownikowy_z_kategorii_nie_gpsr(nowe_szkice_fixture, monkeypatch):
    s = nowe_szkice_fixture[3]
    api = KatalogAllegroAPI(None)
    d = {
        "name": "Nazwa oferty",
        "category": {"id": "123"},
        "publication": {"status": "ACTIVE"},
        "productSet": [
            {
                "product": {
                    "parameters": [
                        {"id": "maker", "valuesIds": ["mk1"]},
                        {"id": "225693", "values": ["5901234123457"]},
                    ]
                },
                "responsibleProducer": {"name": "TO NIE PRODUCENT KATALOGOWY"},
            }
        ],
        "description": {"sections": [{"items": [{"type": "TEXT", "content": "<p>Opis</p>"}]}]},
        "images": [{"url": "https://images.example.org/a.jpg"}],
    }
    monkeypatch.setattr(api, "_get", lambda *args: d)
    monkeypatch.setattr(
        api,
        "nowy_produkt",
        lambda *args: ProduktSzkicu(
            "",
            "",
            "123",
            (
                ParametrSzkicu(
                    "maker", "Producent", "dictionary", True, (("mk1", "Evotech performance"),)
                ),
                ParametrSzkicu("225693", "EAN (GTIN)", "string", False),
            ),
        ),
    )
    o = api.szczegoly_katalogu(s, OfertaKatalogu("1", "", "SKU", "ACTIVE"))
    assert o.producent == "Evotech performance" and o.ean == "5901234123457"
    assert o.opis == "<p>Opis</p>" and len(o.zdjecia) == 1
    d["productSet"][0]["product"]["parameters"][0]["valuesIds"] = ["nieznany"]
    with pytest.raises(BladAllegro, match="rozpoznać"):
        api.szczegoly_katalogu(s, OfertaKatalogu("1", "", "SKU", "ACTIVE"))


def test_pobranie_wszystkich_stron_ponad_limit_starego_widoku(nowe_szkice_fixture, monkeypatch):
    api = KatalogAllegroAPI(None)
    calls = []

    def get(env, token, url):
        q = parse_qs(urlsplit(url).query)
        offset = int(q["offset"][0])
        calls.append(offset)
        return {
            "offers": [
                {
                    "id": str(i + 1),
                    "name": "Produkt",
                    "external": {"id": "SKU" + str(i)},
                    "publication": {"status": "ACTIVE"},
                }
                for i in range(offset, min(offset + 1000, 13182))
            ],
            "totalCount": 13182,
        }

    monkeypatch.setattr(api, "_get", get)
    result = api.lista_katalogu(nowe_szkice_fixture[3], lambda: False)
    assert len(result) == 13182 and len(calls) == 14 and calls[-1] == 13000


def test_zmieniona_lista_nie_oddaje_czesciowych_wynikow(nowe_szkice_fixture, monkeypatch):
    api = KatalogAllegroAPI(None)

    def get(env, token, url):
        offset = int(parse_qs(urlsplit(url).query)["offset"][0])
        return {
            "offers": [
                {
                    "id": str(offset + 1),
                    "name": "P",
                    "external": None,
                    "publication": {"status": "ACTIVE"},
                }
            ],
            "totalCount": 2 if offset == 0 else 3,
        }

    monkeypatch.setattr(api, "_get", get)
    with pytest.raises(BladAllegro):
        api.lista_katalogu(nowe_szkice_fixture[3], lambda: False)


def test_api_zakonczenia_wysyla_wylacznie_ended(nowe_szkice_fixture):
    calls = []

    class Transport:
        def wyslij(self, metoda, url, headers, data):
            calls.append((metoda, url, data))
            return OdpowiedzAllegro(202, b"{}")

    api = KatalogAllegroAPI(Transport())
    api.zakoncz_oferte(nowe_szkice_fixture[3], "123")
    assert calls[0][0] == "PATCH" and calls[0][2] == b'{"publication": {"status": "ENDED"}}'


def test_anulowanie_odczytu_nie_zwraca_paczki(nowe_szkice_fixture):
    with pytest.raises(BladAllegro, match="Anulowano"):
        KatalogAllegroAPI(None).lista_katalogu(nowe_szkice_fixture[3], lambda: True)
