import sqlite3
from contextlib import closing
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.przypadki_uzycia.katalog import KatalogProduktow
from vexlab.rdzen.kontrakty import BladTechniczny

FIXTURE = Path(__file__).resolve().parents[1] / "fixtures" / "schemat_3.sql"


def stara(plik):
    pid, paczka, roboczy = [str(uuid4()) for _ in range(3)]
    with closing(sqlite3.connect(plik)) as c, c:
        c.executescript(FIXTURE.read_text())
        c.execute("INSERT INTO produkty VALUES (?, 'Stary', 'SKU', 'sku', 'Opis', 7, NULL)", (pid,))
        c.execute("INSERT INTO importy VALUES (?, 'test.xlsx', 'Arkusz', 0, 1)", (paczka,))
        c.execute(
            "INSERT INTO import_robocze VALUES (?, ?, 9, 'Do poprawy', '', 'Opis', "
            "NULL, 'Brak SKU', 3)",
            (roboczy, paczka),
        )
    return pid, roboczy


def test_migracja3_do4_zachowuje_produkty_bufor_i_tworz_kopie(tmp_path):
    plik = tmp_path / "test.sqlite3"
    pid, roboczy = stara(plik)
    repo = KatalogSQLite(plik)
    p = KatalogProduktow(repo, repo).wyszukaj()[0]
    assert str(p.id) == pid and p.wersja == 7 and p.opis == "Opis"
    assert p.cena_sugerowana is None and p.miniatura is None
    kopie = list((tmp_path / "kopie_migracji").glob("*.sqlite3"))
    assert len(kopie) == 1
    with closing(sqlite3.connect(kopie[0])) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 3
        assert c.execute("SELECT id FROM import_robocze").fetchone()[0] == roboczy
    with closing(sqlite3.connect(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 12
        assert c.execute(
            "SELECT cena_tekst,cena_waluta,cena_rodzaj FROM import_robocze"
        ).fetchone() == ("", "", "")
        assert c.execute("SELECT count(*) FROM zdjecia").fetchone()[0] == 0
        assert c.execute("PRAGMA foreign_key_check").fetchall() == []


def test_przerwana_migracja4_wycofuje_dane_i_ma_kopie(tmp_path, monkeypatch):
    plik = tmp_path / "test.sqlite3"
    pid, _ = stara(plik)
    orig = sqlite3.connect

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("ALTER TABLE import_robocze ADD COLUMN cena_waluta"):
                raise sqlite3.OperationalError("Przerwanie migracji")
            return super().execute(sql, parameters)

    with monkeypatch.context() as m:
        m.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
        with pytest.raises(BladTechniczny):
            KatalogSQLite(plik).wyszukaj("")
    with closing(orig(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 3
        assert c.execute("SELECT id FROM produkty").fetchone()[0] == pid
        assert (
            c.execute("SELECT name FROM sqlite_master WHERE name='ceny_sugerowane'").fetchall()
            == []
        )
    assert len(list((tmp_path / "kopie_migracji").glob("*.sqlite3"))) == 1


def test_brak_kopii_blokuje_migracje4(tmp_path):
    plik = tmp_path / "test.sqlite3"
    stara(plik)
    (tmp_path / "kopie_migracji").write_text("blokada")
    with pytest.raises(BladTechniczny):
        KatalogSQLite(plik).wyszukaj("")
    with closing(sqlite3.connect(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 3


def test_niezgodny_checksum4_odrzucany_bez_resetu(tmp_path):
    plik = tmp_path / "test.sqlite3"
    repo = KatalogSQLite(plik)
    assert repo.wyszukaj("") == []
    with closing(sqlite3.connect(plik)) as c, c:
        c.execute("UPDATE migracje SET suma_sha256='zle' WHERE wersja=4")
    with pytest.raises(BladTechniczny):
        repo.wyszukaj("")
