import shutil
import sqlite3
from contextlib import closing
from pathlib import Path
from uuid import uuid4

import pytest

from vexlab.adaptery.import_sqlite import ImportSQLite
from vexlab.rdzen.kontrakty import BladTechniczny

FIXTURE = Path(__file__).resolve().parents[1] / "fixtures" / "schemat_5.sql"


def stara(plik):
    pid, paczka, roboczy = [str(uuid4()) for _ in range(3)]
    with closing(sqlite3.connect(plik)) as c, c:
        c.executescript(FIXTURE.read_text())
        c.execute("INSERT INTO produkty VALUES (?, 'Stary', 'SKU', 'sku', 'Opis', 8, NULL)", (pid,))
        c.execute(
            "INSERT INTO dopasowania VALUES (?, 0, 'Marka', 'Model', 2018, 2020, 'S')", (pid,)
        )
        c.execute("INSERT INTO importy VALUES (?, 'test.csv', 'A', 0, 1)", (paczka,))
        c.execute(
            "INSERT INTO import_robocze VALUES (?, ?, 3, 'Roboczy', '', '', "
            "NULL, 'Brak SKU', 1, '', '', '')",
            (roboczy, paczka),
        )
    return pid


def test_migracja6_kopia_stare_dopasowania_bufor_i_odtworzenie(tmp_path):
    plik = tmp_path / "k.sqlite3"
    pid = stara(plik)
    repo = ImportSQLite(plik)
    p = repo.wyszukaj("")[0]
    assert str(p.id) == pid and p.dopasowania[0].rok_do == 2020 and p.wersja == 8
    assert repo.oczekujace()[0].dane.dopasowania == ()
    (kopia,) = (tmp_path / "kopie_migracji").glob("*.sqlite3")
    with closing(sqlite3.connect(kopia)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 5
        assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    odtworzona = tmp_path / "odtworzona.sqlite3"
    shutil.copyfile(kopia, odtworzona)
    assert ImportSQLite(odtworzona).wyszukaj("")[0] == p
    with closing(sqlite3.connect(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 12
        assert c.execute("SELECT dopasowania_json FROM import_robocze").fetchone()[0] == "[]"
        assert not c.execute("PRAGMA foreign_key_check").fetchall()


def test_przerwanie6_i_brak_kopii_blokuja_migracje(tmp_path, monkeypatch):
    plik = tmp_path / "k.sqlite3"
    stara(plik)
    orig = sqlite3.connect

    class Awaria(sqlite3.Connection):
        def execute(self, sql, parameters=()):
            if sql.startswith("INSERT INTO migracje VALUES (6"):
                raise sqlite3.OperationalError("awaria")
            return super().execute(sql, parameters)

    with monkeypatch.context() as m:
        m.setattr(sqlite3, "connect", lambda *a, **kw: orig(*a, **kw, factory=Awaria))
        with pytest.raises(BladTechniczny):
            ImportSQLite(plik).wyszukaj("")
    with closing(orig(plik)) as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == 5
        assert "dopasowania_json" not in [
            r[1] for r in c.execute("PRAGMA table_info(import_robocze)")
        ]
    drugi = tmp_path / "drugi"
    drugi.mkdir()
    stara(drugi / "k.sqlite3")
    (drugi / "kopie_migracji").write_text("blokada")
    with pytest.raises(BladTechniczny):
        ImportSQLite(drugi / "k.sqlite3").wyszukaj("")


def test_checksum6_chroni_przed_otwarciem_niezgodnej_bazy(tmp_path):
    plik = tmp_path / "k.sqlite3"
    repo = ImportSQLite(plik)
    repo.wyszukaj("")
    with closing(sqlite3.connect(plik)) as c, c:
        c.execute("UPDATE migracje SET suma_sha256='niezgodne' WHERE wersja=6")
    with pytest.raises(BladTechniczny):
        repo.wyszukaj("")
