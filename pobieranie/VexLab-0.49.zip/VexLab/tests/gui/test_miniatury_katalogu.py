from dataclasses import replace
from uuid import uuid4

import pytest
from PySide6.QtCore import QBuffer, QIODevice, QSortFilterProxyModel, Qt
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QHeaderView, QTableView

from vexlab.gui.katalog import ModelProduktow
from vexlab.gui.miniatury_katalogu import MiniaturyKatalogu
from vexlab.przypadki_uzycia.katalog import ProduktDTO


@pytest.fixture
def widok(qtbot):
    image = QImage(16, 16, QImage.Format.Format_RGB32)
    image.fill(0x00FF00)
    buf = QBuffer()
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    assert image.save(buf, "PNG")
    png = bytes(buf.data())
    tabela = QTableView()
    tabela.resize(800, 300)
    qtbot.addWidget(tabela)
    model = ModelProduktow(tabela)
    proxy = QSortFilterProxyModel(tabela)
    proxy.setSourceModel(model)
    tabela.setModel(proxy)
    tabela.setSortingEnabled(True)
    tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
    zadania = []
    odczyty = []

    class Katalog:
        def pobierz_miniatury(self, partia):
            odczyty.append(partia)
            return {pid: png for pid, _ in partia}

    miniatury = MiniaturyKatalogu(
        tabela, model, [tabela], Katalog(), lambda *args: zadania.append(args)
    )
    model.ustaw(
        [
            ProduktDTO(uuid4(), f"Produkt {i:04d}", f"SKU-{i}", "", 1, ma_zdjecia=True)
            for i in range(1000)
        ]
    )
    tabela.show()
    yield tabela, model, proxy, miniatury, zadania, odczyty, png
    miniatury.zamknij()


def zakoncz(zadanie):
    fn, ok, err = zadanie
    ok(fn())


def test_widoczne_miniatury_bez_skanu_blobow_i_bez_io_w_data(qtbot, widok):
    tabela, model, proxy, miniatury, zadania, odczyty, png = widok
    qtbot.waitUntil(lambda: bool(zadania))
    assert odczyty == []
    # Pomiar kolumn może pytać o dekorację wszystkich 1000 wierszy.
    for row in range(model.rowCount()):
        model.index(row, 0).data(Qt.ItemDataRole.DecorationRole)
    assert len(zadania) == 1 and not odczyty
    zakoncz(zadania.pop())
    assert 0 < len(odczyty[0]) < 32
    assert set(odczyty[0]) == set(miniatury.widoczne())
    assert model.index(0, 0).data(Qt.ItemDataRole.DecorationRole) is not None
    assert all(p.miniatura is None for p in model.produkty)
    tabela.selectAll()
    assert len(tabela.selectionModel().selectedRows()) == 1000
    miniatury._odczytaj()
    assert zadania == []
    tabela.scrollToBottom()
    qtbot.waitUntil(lambda: bool(zadania))
    zakoncz(zadania.pop())
    assert len(odczyty) == 2
    assert set(odczyty[0]).isdisjoint(odczyty[1])
    assert len(miniatury.cache) < 64


def test_sortowanie_podczas_odczytu_zachowuje_tozsamosc_zdjecia(qtbot, widok):
    tabela, model, proxy, miniatury, zadania, odczyty, png = widok
    qtbot.waitUntil(lambda: bool(zadania))
    stare = zadania.pop()
    proxy.sort(1, Qt.SortOrder.DescendingOrder)
    zakoncz(stare)
    assert proxy.index(0, 0).data(Qt.ItemDataRole.DecorationRole) is None
    qtbot.waitUntil(lambda: bool(zadania))
    zakoncz(zadania.pop())
    assert proxy.index(0, 0).data(Qt.ItemDataRole.DecorationRole) is not None
    assert (model.produkty[-1].id, 1) in odczyty[-1]


def test_stary_wynik_po_odswiezeniu_i_zamknieciu_jest_ignorowany(qtbot, widok):
    tabela, model, proxy, miniatury, zadania, odczyty, png = widok
    qtbot.waitUntil(lambda: bool(zadania))
    stare = zadania.pop()
    model.ustaw([replace(p, wersja=2) for p in model.produkty])
    zakoncz(stare)
    assert not miniatury.cache
    qtbot.waitUntil(lambda: bool(zadania))
    nowe = zadania.pop()
    miniatury.zamknij()
    zakoncz(nowe)
    assert not miniatury.cache and miniatury.bajty == 0


def test_blad_nie_powoduje_petli_ponowien_a_cache_ma_limit(qtbot, widok):
    tabela, model, proxy, miniatury, zadania, odczyty, png = widok
    qtbot.waitUntil(lambda: bool(zadania))
    fn, ok, err = zadania.pop()
    err("TECHNICZNY", "Brak dostępu")
    assert "Odśwież" in miniatury.opis(model.produkty[0])
    miniatury._odczytaj()
    assert zadania == []
    miniatury.LIMIT_WPISOW = 10
    for produkt in model.produkty[:50]:
        miniatury._dodaj((produkt.id, 1), png, "")
    assert len(miniatury.cache) == 10
    miniatury.LIMIT_BAJTOW = 80000
    for produkt in model.produkty[:50]:
        miniatury._dodaj((produkt.id, 1), png, "")
    assert len(miniatury.cache) <= 10 and miniatury.bajty <= 80000
    assert (model.produkty[49].id, 1) in miniatury.cache
    miniatury._dodaj((model.produkty[50].id, 1), b"uszkodzony obraz", "")
    assert "Nieprawidłowa" in miniatury.opis(model.produkty[50])


def test_zamkniecie_odpina_filtry_przed_zwalnianiem_widokow(qtbot):
    class Licznik(MiniaturyKatalogu):
        events = 0

        def eventFilter(self, obj, event):
            self.events += 1
            return super().eventFilter(obj, event)

    tabela = QTableView()
    qtbot.addWidget(tabela)
    model = ModelProduktow(tabela)
    tabela.setModel(model)
    mini = Licznik(tabela, model, [tabela], None, lambda *args: None)
    tabela.show()
    qtbot.wait(10)
    assert mini.events > 0
    mini.zamknij()
    before = mini.events
    tabela.resize(900, 400)
    tabela.viewport().update()
    qtbot.wait(20)
    assert mini.events == before and not mini.timer.isActive()
