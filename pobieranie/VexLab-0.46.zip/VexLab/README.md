# VexLab

Natywna aplikacja Windows w Pythonie, PySide6 i SQLite, rozwijana zgodnie
z Clean Architecture i DDD. Przyrost **0.46.dev0** zawiera lokalny katalog Produktów, rejestr Producentów,
nowy Dashboard oraz odczyt list i szczegółów ofert Allegro według stanów.
To wersja developerska, bez instalatora i odbioru na Windows.

## Co działa

- 0.46: miniatury 64×64 po lewej, kolory paneli Dashboardu, znak gotowości
  i potwierdzenie wysyłki szkiców. [Instrukcja](docs/PRZYROST_0_46.md).

- 0.45.1: okno GPSR/dostawy otwiera się w czytelnym rozmiarze i nie daje
  się ścisnąć do wąskiego paska. [Poprawka](docs/POPRAWKA_0_45_1.md).

- 0.45: prostsze okno przygotowania ofert zgodne z Dashboardem, mniej
  przycisków, czytelne sekcje i naprawiony odczyt VAT.
  [Instrukcja i podglądy](docs/PRZYROST_0_45.md).

- Poprawka VAT (w paczce 0.45): poprawiony odczyt VAT — puste opcje „Wybierz” i „Poza VAT / NP”
  nie blokują listy stawek. [Poprawka](docs/POPRAWKA_0_44_1.md).

- 0.44: VAT osobno dla wybranych krajów, stawki z API lub ręcznie,
  pobranie VAT z własnej oferty. [Instrukcja](docs/PRZYROST_0_44.md).
- 0.43.2: lokalizacja nadania domyślnie z konta Allegro, bez ręcznego
  wpisywania adresu. Własny adres tylko przez opcjonalną zmianę.
  Widoczny wybór numeru katalogowego: ręcznie lub SKU każdej pozycji paczki.
  [Poprawka](docs/POPRAWKA_0_43_2.md).

- 0.43.1: okno GPSR/dostawy otwiera się od razu; odczyt list w tle,
  widoczny błąd konkretnej listy i ponowienie bez utraty wpisanego tekstu.
  [Poprawka](docs/POPRAWKA_0_43_1.md).

- 0.43: GPSR, dostawa, lokalizacja i warunki sprzedaży dla zaznaczonych
  nowych szkiców. Sygnatura = SKU, osobna naprawa starych sygnatur.
  Parametry Wymagane/Dodatkowe, źródła w opcji zaawansowanej.
  [Instrukcja, nowa zgoda i zakres](docs/PRZYROST_0_43.md).

- 0.42: zaznaczanie wielu ofert, masowe tytuły/ceny/ilości z podglądem,
  wspólne parametry wybranych pozycji, automatyczne SKU/EAN per produkt.
  Allegro: wyszukiwanie całego konta przez API i tryb listy Wszystkie.
  [Instrukcja i zakres](docs/PRZYROST_0_42.md).

- 0.41: nowy produkt nieobecny w Katalogu Allegro — wybór kategorii,
  parametry produktu i oferty, jawne wspólne ustawienia oraz źródła SKU/EAN
  dla paczki. Potwierdzane zgłoszenie definicji produktu razem ze szkicem
  INACTIVE; bez uruchamiania sprzedaży. [Instrukcja](docs/PRZYROST_0_41.md).

- 0.40.2: domyślny pełny podgląd oferty — galeria, zdjęcia i wszystkie sekcje,
  od razu z ZIP-a, bez zapisywania szkicu lokalnie.
  [Opis](docs/POPRAWKA_0_40_2.md).

- 0.40.1: automatyczne otwieranie gotowych ofert JSON bez osobnego profilu,
  również na nowej instalacji. Zachowane HTML, zdjęcia, sekcje i ceny;
  kilka pasujących plików wymaga wyboru. [Poprawka i sprawdzenia](docs/POPRAWKA_0_40_1.md).

- ZIP → nowe szkice Allegro: plan, dopasowanie istniejącego produktu, parametry
  kategorii, upload zdjęć HTTPS, jawne tworzenie INACTIVE i raport CSV.
  Nowe oferty → paczka ZIP → Przygotuj szkice w Allegro. Waluta/ilość jawne,
  nieznane wyniki blokują ponowienie, publikacja osobno i nadal niewdrożona.
  [Instrukcja i ograniczenia](docs/PRZYROST_0_40.md).

- Poprawka 0.39.1: KPI Allegro w kolorystyce Dashboardu oraz statusy
  Aktywna — zielony, Zakończona — czerwony, Szkic — żółty w obu motywach,
  także w zaznaczonym wierszu. [Opis](docs/POPRAWKA_0_39_1.md).

- Allegro 0.39: spokojny ekran wzorcowy w obu motywach, jednolite miniatury
  i zmiana zgody na zapis bez rozłączania konta. Ustawienia → Integracje →
  Allegro → zaznacz/odznacz zgodę → Zmień uprawnienia → potwierdź w Allegro.
  Pozostałe ekrany czekają na ocenę wzorca. [Opis i podglądy](docs/PRZYROST_0_39.md).

- Edycja i potwierdzany zapis tytułu/opisu zdalnego szkicu INACTIVE,
  lokalna propozycja JSON, kontrola konfliktu i odczyt wyniku.
  Obsługa 202 oraz trwała blokada ponowienia nieznanego zapisu.
  Zgoda na zapis opcjonalna; wymaga offers:write i ponownej autoryzacji.
  Bez publikacji. [Instrukcja i ograniczenia 0.38](docs/PRZYROST_0_38.md).

- Allegro: Wszystkie / Aktywne / Szkice / Aktywowanie / Zakończone,
  szczegóły ofert i licznik aktywnych ofert także na Dashboardzie.
  Strony po 50, przeglądanie pierwszych 10 000 wyników; licznik całego wyniku
  API, cache 30 s i kontrola sesji. Zapis szkiców opisano powyżej; bez publikacji.
  [Przyrost 0.36](docs/PRZYROST_0_36.md).

- Dashboard: siedem KPI, lokalne alerty jakości, konfigurator sekcji,
  AI Center według nowego wzoru i transparentne logo VEX.
  Liczby wyłącznie z istniejących odczytów; brakujące integracje/statystyki —.
  [Przyrost 0.35](docs/PRZYROST_0_35.md), [AI Center 0.35.1](docs/POPRAWKA_0_35_1.md).

- Ustawienia podzielone na Ogólne, Integracje, Dane i kopie oraz O programie.
  Integracje: lista usług ze stanem po lewej, konfiguracja po prawej.
  Dane aplikacji Allegro rozwijane, po połączeniu widoczny przede wszystkim
  stan konta. Raport techniczny dostępny w O programie.
  [Przyrost 0.28](docs/PRZYROST_0_28.md).

- Przyciski według nowego wzoru: niebieska główna akcja, ciemne przyciski
  pomocnicze, ikony i karty szybkich akcji z opisem. Stany dostępności,
  motywy i własna lista skrótów zachowane. [Przyrost 0.27](docs/PRZYROST_0_27.md).

- Ustawienia → Integracje: wspólne zakładki Allegro i Subiekt GT. Kolejne
  integracje będą dodawane w tym miejscu. Diagnostyka GT zachowana,
  sam konektor nadal odłożony. [Poprawka 0.26.1](docs/POPRAWKA_0_26_1.md).

- Łączenie Allegro przeniesione do Ustawienia → Integracje → Allegro.
  Na Windows połączenie można zapamiętać: dane chroni DPAPI bieżącego
  użytkownika, sesja jest wznawiana po restarcie i odnawiana po wygaśnięciu.
  Rozłącz i zapomnij usuwa lokalny zapis. Zakładka Allegro pozostaje miejscem
  pracy z kanałem. [Przyrost 0.26](docs/PRZYROST_0_26.md).

- Allegro: logowanie Device Flow, potwierdzenie konta przez `/me`, lista
  ofert (od 0.36 wszystkie obsługiwane stany) po 50, anulowanie/rozłączenie
  i wygaśnięcie sesji.
  Edycja i zapis tytułu/opisu zdalnych szkiców dostępne od 0.38. Ograniczenie do sesji
  w pamięci z 0.25 zastępuje opcjonalne zapamiętywanie opisane powyżej. [Obsługa i ograniczenia 0.25](docs/PRZYROST_0_25.md).

- Ustawienia: ręczne sprawdzenie lokalnego środowiska Subiekta GT i kopiowanie
  raportu wersji InsERT, Pythona i rejestracji sterowników SQL. Bez połączenia
  z serwerem. [Przyrost 0.24](docs/PRZYROST_0_24.md).

- Strony pozycji Cenników po 100/250/500. Globalne filtrowanie i wybór,
  duplikaty SKU rozpoznawane w całym dokumencie, porównania cen zachowane.
  Pełne dane pobierane dla strony lub jawnego wyboru, z lekkim indeksem
  podglądu. [Przyrost 0.23](docs/PRZYROST_0_23.md).

- Strony katalogu po 100, 250 lub 500 produktów. Odczyt w tle z SQLite,
  globalne wyszukiwanie/sortowanie, liczniki całego zakresu i wybór między
  stronami. Zaznacz wszystkie, eksport i usuwanie wyników obejmują pełny filtr.
  [Przyrost 0.22](docs/PRZYROST_0_22.md).

- Miniatury katalogu są wczytywane w tle tylko dla widocznych wierszy.
  Ograniczony cache w pamięci, brak pobierania wszystkich obrazów przy
  odświeżeniu. Zaznaczanie i operacje masowe zachowane.
  [Przyrost 0.21](docs/PRZYROST_0_21.md).

- Natywny pasek tytułu dopasowany do motywu: kolor nagłówka na Windows 11,
  ciemny wariant systemowy na obsługiwanych Windows 10. Standardowe przyciski
  i zachowanie okna zachowane. [Poprawka 0.20.4](docs/POPRAWKA_0_20_4.md).

- Dopracowane menu: subtelniejsze zwinięte belki, mocniejszy akcent po
  rozwinięciu, większe odstępy i wyrównane marginesy bez przesuwania w poziomie.
  [Poprawka 0.20.3](docs/POPRAWKA_0_20_3.md).

- Kolorowe belki bocznego menu i bardziej zaokrąglone rogi w obu motywach,
  z zachowaniem rozwijania i zapamiętywania grup.
  [Wygląd menu 0.20.2](docs/POPRAWKA_0_20_2.md).

- Podgląd paczki i zapisanego szkicu pokazuje zdjęcia galerii oraz obrazy
  w sekcjach zamiast samych adresów. Pobieranie HTTPS w tle, bez zapisu zdjęć
  do katalogu; wspólny mechanizm z wizualnym edytorem.

- Rozwijane belki bocznego menu: Produkty, Oferty, Sprzedaż, Analityka
  i Narzędzia. Kliknięcie pokazuje zakładki; ręczny wybór grup jest zapamiętywany.
  Nazwy, ikony i kolejność zachowane. [Poprawka 0.20.1](docs/POPRAWKA_0_20_1.md).

- ZIP gotowych ofert zapisuje samodzielne lokalne szkice, bez zakładania
  Produktów. Zachowane HTML, sekcje, galeria adresów, SKU i dane źródłowe.
  Dawne szkice i ich powiązania pozostają. Schemat 11 z kopią.
  [Instrukcja 0.20](docs/PRZYROST_0_20.md). Docelowo katalog Subiekt GT
  tylko do odczytu; sam konektor nie jest jeszcze wdrożony.

- Rozpoznawanie układów cenników i własne profile mapowania: po jednorazowym
  ustawieniu i podglądzie wybierz Profil → Zapamiętaj układ. Kolejne zgodne
  pliki otwierają podgląd automatycznie; kilka dopasowań wymaga wyboru.
  Ustawienia importu i próbka są rozwijane, producent pozostaje widoczny.
  Profile można usuwać; są danymi użytkownika, nie kodem. Bez płatnego AI.
  [Instrukcja i ograniczenia 0.19](docs/PRZYROST_0_19.md).

- Opcjonalny EAN-8/EAN-13: mapowanie kolumny w cenniku, podgląd, trwały zapis,
  korekta błędnego kodu, pole w formularzu i szczegółach Produktu oraz eksport CSV.
  Tekst zachowuje zera wiodące; kontrola długości i cyfry kontrolnej. Brak EAN
  nie blokuje importu; nie generujemy kodów ani nie zastępujemy nimi SKU.

- Biblioteka cenników z nazwą, producentem, rokiem i opcjonalnym wydaniem.
  Cenniki → Dodaj cennik → plik i mapowanie → Sprawdź i pokaż podgląd → Zapisz cennik.
  Kliknięcie pokazuje pozycje obok listy; zaznacz je i wybierz PPM → Dodaj do katalogu.
  Statusy Nowy / W katalogu / Inna cena / Do poprawy oraz porównanie ceny z bazową.
  Więcej → Ustaw jako aktualny / Archiwizuj — ustawienie per producent, bez nadpisywania cen.
  Zapis cennika nie dodaje automatycznie produktów. Znane SKU pomijane.
  Usuń zaznaczone usuwa wyłącznie cenniki, po potwierdzeniu i kopii bazy.
- Edytor szkicu pokazuje zdjęcia HTTPS i zakładkę „Cała oferta ze zdjęciami”
  z układem sekcji. Obrazy pobierane w tle; podgląd nie zmienia zapisanego szkicu.
  Jest to przybliżenie, nie oficjalny podgląd ani walidacja Allegro.

- Dodanie Produktu z nazwą, obowiązkowym SKU i opcjonalnym opisem.
- Opcjonalne dopasowania do wielu motocykli: marka/model, roczniki, wariant.
  Dodaj/edytuj Produkt → Pasuje do motocykli… → Zastosuj w formularzu → Zapisz lokalnie.
- Edycja z zachowaniem ID i kontrolą równoczesnej zmiany.
- Unikalność SKU bez rozróżniania wielkości liter, także polskich znaków;
  wpisana pisownia symbolu pozostaje zachowana.
- Wyszukiwanie nazw/SKU przez Ctrl+K, sortowanie listy i trwałość po restarcie.
- Rejestr producentów: dodawanie, edycja nazwy, dezaktywacja i wyszukiwanie.
- Opcjonalny jeden producent na Produkt; jego nazwa jest widoczna w tabeli.
- Filtr producenta (także nieaktywny lub brak), łączony z wyszukiwaniem.
- Szczegóły Produktu z pełnym opisem: przycisk lub Enter na zaznaczonym wierszu.
- Eksport widocznych, posortowanych wyników do CSV bez nadpisywania plików.
- Import XLSX/CSV: wybór arkusza, nagłówków, kolumn i producenta, podgląd przed zapisem.
- Opcjonalne mapowanie marki/modelu/roczników/wariantu w imporcie, z podglądem
  i zachowaniem niepoprawnych wartości do późniejszej korekty.
- Trwała lista Do poprawy: korekta i jawne przypisanie do istniejącego Produktu.
- Sugerowana cena źródłowa: kwota, waluta, netto/brutto, import i uzupełnienie braków po SKU.
- Wielokrotny wybór i zaznaczanie wszystkich wyników; masowa zmiana producenta/opisu.
- Usuwanie zaznaczonych lub wyników filtra z kopią i potwierdzeniem.
- Opcjonalny adres producenta i pobranie kandydatów zdjęć po SKU w formularzu pojedynczego Produktu
  (publiczny katalog Shopify, domena użytkownika; odbiór konkretnej witryny online otwarty).
- Lokalna galeria: dodawanie JPG/PNG/WebP, podgląd, kolejność, usuwanie i miniatura.
  Produkty → zaznacz jeden wiersz → Galeria zaznaczonego produktu…
- Podgląd ofert z ZIP: mapowanie pliku JSON, zachowanie sekcji i zewnętrzne profile użytkownika.
  Zapis lokalnych szkiców z pełnym opisem, układem sekcji i linkami zdjęć.
- Osobny widok Szkice: trwałość po restarcie, wyszukiwanie, podgląd, edycja
  tytułu/HTML, usuwanie z kopią. W 0.40 wysyłka do nowych szkiców Allegro
  ma osobny proces z podglądu paczki ZIP opisany powyżej.
- Kopia katalogu SQLite z kontrolą integralności, bez nadpisywania plików.
- Nawigacja, zwijanie menu, motywy ciemny/jasny/systemowy i zapis preferencji.
- Nazwa użytkownika systemu w nagłówku; nie jest to konto sprzedażowe ani logowanie.

Pozostałe moduły są jawnie oznaczone jako niewdrożone. Nie działają jeszcze
Publikacja ofert, synchronizacja cen, magazyn, AI, importy platform, Allegro, PrestaShop, kolejka,
historia i analityka. Przyciski nie udają wykonania tych operacji.
Nowa baza ma **zero Produktów**, bez seedów i danych ze screena.

## Dokumentacja

Kolejność analizy: [AGENTS](AGENTS.md), README,
[konstytucja](ARCHITECTURE_CONSTITUTION.md), [model](DOMAIN_MODEL.md),
[ADR_INDEX](ADR_INDEX.md), [system UI](UI_UX_DESIGN_SYSTEM.md),
[roadmapa](ROADMAP.md).

WYMAGANIA są obowiązujące, PROPOZYCJE nie są automatycznie zatwierdzonym modelem.
Właściciel wybrał obowiązkowe i unikalne SKU ignorujące wielkość liter;
[ADR-020](docs/adr/ADR-020-lokalny-katalog-i-sqlite.md) opisuje ten przyrost,
a [ADR-021](docs/adr/ADR-021-powloka-vexlab.md) — powłokę.
Pozostałe relacje i znaczenie 16 głównych bytów nie zostały zmienione.

[Raport 0.6](docs/RAPORT_PRZYROST_0_6.md) opisuje bieżący przyrost.
[Instrukcja 0.6](docs/PRACA_Z_KATALOGIEM_0_6.md): ceny istniejących Produktów, usuwanie, masowa edycja i zdjęcia.
[Raport 0.5](docs/RAPORT_PRZYROST_0_5.md) opisuje poprzedni zakres.
[Raport 0.4](docs/RAPORT_PRZYROST_0_4.md) opisuje poprzedni zakres.
[Raport 0.3](docs/RAPORT_PRZYROST_0_3.md) opisuje poprzedni zakres.
[Raport 0.2](docs/RAPORT_PRZYROST_0_2.md) opisuje poprzedni zakres.
[Raport etapów 1–2](docs/RAPORT_ETAPY_1_2.md) jest historycznym zapisem
poprzedniego środowiska 3.12.14, nie aktualnym stanem.

## Uruchomienie Windows

Jeśli masz działającą wersję 0.2–0.8: zamknij ją, rozpakuj nowy ZIP do osobnego
folderu i kliknij **Uruchom VexLab.cmd**. Program użyje dotychczasowego katalogu
danych. Wersja 0.9 aktualizuje bazę do schematu 6, z kopią przed zmianą. Krótkie kroki są w `JAK_URUCHOMIC.txt`.
Nie trzeba ponownie wpisywać komendy w PowerShellu.

Potrzebny jest Python z szeregu 3.13 do instalacji uv; uv pobierze dokładny
interpreter projektu **3.13.18**. W PowerShell, w katalogu checkoutu:

```powershell
py -3.13 -m pip install uv==0.13.6
py -3.13 -m uv sync --frozen
py -3.13 -m uv run --frozen python -m vexlab
```

Nie trzeba aktywować `.venv` ani zmieniać polityki PowerShell.
Alternatywny punkt wejścia GUI: `uv run --frozen vexlab-gui`.
Bezokienkowa diagnostyka: `uv run --frozen python -m vexlab --diagnostyka`.
Nie przygotowano pliku instalacyjnego EXE/MSI. Instrukcje Windows i CI są
przygotowane; ich rzeczywisty odbiór na Windows pozostaje do wykonania.

## Uruchomienie Linux / chmura

Pracuj w katalogu `VexLab` rozpakowanej, potwierdzonej paczki.
Baza tego przyrostu: `/workspace/VexLab-0.38/VexLab`; main nie jest źródłem aktualnej wersji.

```bash
export UV_CACHE_DIR=/tmp/vexlab-uv-cache
export UV_PYTHON_INSTALL_DIR=/workspace/.runtimes/vexlab/python
export UV_SYSTEM_CERTS=1
.venv/bin/uv sync --frozen
.venv/bin/uv run --frozen python scripts/check.py
.venv/bin/uv run --frozen python -m vexlab --diagnostyka
```

Przy dostępnym ekranie: `.venv/bin/uv run --frozen python -m vexlab`.
W chmurze bez ekranu testy ustawiają `QT_QPA_PLATFORM=offscreen`.
Nie udostępniamy przeglądarkowego preview aplikacji desktopowej.
Używaj istniejącego checkoutu; zadania chmurowe są izolowane, więc nie twórz
worktree bez wyraźnego polecenia. Zachowaj wstrzyknięte proxy i CA, nie wyłączaj
TLS. Instalacja wymaga PyPI/files.pythonhosted.org, a pobranie Pythona — GitHub.
Jeżeli `.venv` jeszcze nie istnieje, zainstaluj uv 0.13.6 zgodnie z ADR-011.

## Wersje

| Składnik | Bieżąca wersja |
|---|---|
| CPython | 3.13.18; zakres >=3.13,<3.14 |
| PySide6 / Qt | 6.12.0 |
| uv | 0.13.6, również w grupie dev |
| SQLite | standardowy moduł sqlite3; aktualny Linux: 3.53.1 |
| pytest / pytest-qt | 9.2.0 / 4.5.0 |
| ruff / mypy | 0.17.3 / 2.4.1 |
| import-linter | 2.15 |
| bandit / pip-audit | 1.9.4 / 2.10.1 |

`pyproject.toml` przypina zależności bezpośrednie, `uv.lock` pełny graf,
markery platform i sumy artefaktów. `uv sync --frozen` nie zmienia blokady;
`uv lock --check` sprawdza zgodność. Dokładne wersje, przejście z poprzedniego
środowiska i niezamknięty odbiór Windows: [ADR-011](docs/adr/ADR-011-srodowisko.md).

## Dane i kopie

Domyślny katalog danych pochodzi z Qt `AppLocalDataLocation` dla VexLab,
poza repozytorium. Zawiera `katalog.sqlite3` i `preferencje.ini`.
Możesz wskazać osobny katalog, np.:

```powershell
uv run --frozen python -m vexlab --katalog-danych "C:\Dane\VexLab"
```

Ustawienia → Utwórz kopię katalogu zapisuje nowy plik przez SQLite backup API.
Błędy bazy nie powodują automatycznego resetu. Wersje nieobsługiwane i obce
schematy są odrzucane bez usuwania danych. Odtworzenie wymaga zamknięcia aplikacji
oraz nowego katalogu: [procedura danych i kopii](docs/DANE_I_KOPIE.md).

## Sprawdzenia i budowanie

```powershell
uv run --frozen python scripts/check.py
uv run --frozen python scripts/audit.py
uv build
```

`check.py` zachowuje kod wyjścia błędu: ruff check/format, mypy strict,
import-linter, bandit, pytest i diagnostyka. Testy używają tylko tymczasowych
baz i ustawień. Obejmują reguły, zapis, rollback, konflikty, kopię, GUI,
brak seedów i wykonywanie I/O poza głównym wątkiem.
`audit.py` oddzielnie audytuje pełny graf runtime oraz dev z blokady.
Brak sieci jest błędem audytu. Budowanie tworzy wheel i sdist, nie instalator.

[CI](.github/workflows/quality.yml) ma macierz Ubuntu/Windows, odtwarza dokładny
pin Pythona przez uv i wykonuje te kontrole. Zapis workflow nie oznacza
wykonania CI. Linux/offscreen nie zastępuje Narratora, DPI i testu Windows.

## Architektura i interfejs

Sześć warstw: `rdzen`, `domena`, `przypadki_uzycia`, `adaptery`, `kanaly`, `gui`.
Zewnętrzny `bootstrap.py` składa implementacje portów. GUI nie wykonuje SQL
ani nie importuje domeny/adapterów; wymienia DTO z przypadkami użycia.
Domena nie importuje Qt, SQLite lub HTTP. Kontrakty: [ADR-001](docs/adr/ADR-001-granice-warstw.md).

Obowiązuje [oryginalny wzorzec](assets/UI_REFERENCE.png). Nowa marka to VexLab,
a nagłówek pokazuje nazwę użytkownika, bez kopiowania profilu i wersji ze screena.
Zrzuty aktualnej powłoki, na pustej bazie i z testową tożsamością:
[ciemny](docs/screenshots/vexlab-dashboard-dark.png),
[jasny](docs/screenshots/vexlab-dashboard-light.png).
Nie są pełnym odbiorem referencji. Niewdrożone dane są oznaczone; nie pokazujemy
fikcyjnego połączenia, sprzedaży ani sukcesu publikacji.

Nie dodano QFluentWidgets ani QtCharts. Nie nadano licencji projektowi;
warunki dystrybucji bibliotek, zasobów i samego produktu pozostają do przeglądu.

## Historia aktualizacji i odbioru

[ADR-022](docs/adr/ADR-022-producenci-propozycja.md) dokumentuje wybraną przez
właściciela relację: zero lub jeden producent. Istniejące Produkty są zachowane
po migracji schematu 1→2, bez wymyślonych producentów; kopia sprzed zmiany jest
w `kopie_migracji` obok bazy. Starszy program 0.2 nie otworzy schematu 2.
[Procedura kopii/odtworzenia](docs/DANE_I_KOPIE.md).

Właściciel potwierdził na zrzutach Windows uruchomienie 0.2, dodanie Produktu
oraz zachowanie go po ponownym starcie. Zrzuty właściciela potwierdziły również uruchomienie i import w 0.5.
Nie jest to odbiór 0.6, DPI lub Narratora.
Zrzut nowego ekranu w izolowanym teście Linux: [Producenci](docs/screenshots/vexlab-producenci-dark.png).
Źródłowy ZIP do przekazania można utworzyć poleceniem:
`uv run --frozen python scripts/package_source.py --output VexLab-0.23.zip`.

## Przegląd i CSV — 0.4

Na ekranach Dashboard i Produkty filtr producenta jest wspólny. Opcja „Wyczyść
filtry” usuwa również wyszukiwanie. Dwuklik nadal edytuje Produkt; Enter otwiera
szczegóły. Eksport na ekranie Produkty zapisuje migawkę widocznych wyników
z chwili wybrania akcji, w aktualnej kolejności sortowania.

CSV zawiera tylko nazwę, SKU, opis i producenta, w UTF-8 z BOM, ze średnikiem
i cytowaniem pól. Wartości przypominające formuły arkusza są poprzedzane
apostrofem; komunikat podaje liczbę zabezpieczonych pól. To eksport do arkusza,
nie kopia bazy ani format importu. Istniejący plik nie jest nadpisywany.
[Decyzja techniczna ADR-024](docs/adr/ADR-024-przeglad-i-eksport-katalogu.md).

Import z Allegro/PrestaShop, przenoszenie Allegro → PrestaShop z profilem
ustawień oraz kurierzy pozostają przyszłym zakresem. Kierunek architektury
opisuje [ADR-023](docs/adr/ADR-023-przyszle-integracje.md). W 0.25 wdrożono
pierwszy odczyt Allegro: sesję Device Flow i listę szkiców, bez przenoszenia
ofert, edycji ani publikacji.

## Historyczny przyrost importu — 0.5

Działa lokalny import XLSX/CSV z mapowaniem kolumn i producentem, bez
cen, EAN i dopasowań do motocykli. Wykluczone wiersze zapisanej paczki
pozostają na liście Do poprawy po restarcie.
[Instrukcja i mapowanie przykładu Evotech](docs/IMPORT_PRODUKTOW.md).
[Decyzja techniczna i limity](docs/adr/ADR-027-import-xlsx-i-bufor-korekt.md).

Pierwszy start 0.5 tworzy kopię starszego schematu przed migracją do 3.
Wersje 0.3/0.4 nie otworzą zaktualizowanej bazy; powrót wymaga osobnego
katalogu ze starszą kopią. [Procedura danych](docs/DANE_I_KOPIE.md).

Przyszłe pobieranie katalogów dostawców i producentów przez API jest zapisane
w [ADR-028](docs/adr/ADR-028-katalogi-api-dostawcow-i-producentow.md).
Właściciel odłożył podłączenie do czasu wyboru partnera; nie wdrożono
uniwersalnego pustego konektora ani synchronizacji cen/stanów.

## Poprawka uruchamiania 0.5.1

Plik CMD najpierw wykonuje uv sync --frozen --no-dev, a potem wywołuje
bezpośrednio .venv\Scripts\python.exe -m vexlab. Nie polega na rozwiązywaniu
nazwy polecenia python przez PATH Windows. Sprawdza kompletność katalogu
i rozdziela błąd instalacji zależności od błędu startu aplikacji.
Zgłoszony komunikat systemowego Pythona „No module named vexlab” wskazywał
na uruchomienie interpretera bez zainstalowanego pakietu; dokładnego mechanizmu
wyboru interpretera na komputerze właściciela nie odtworzono na Linux.
Poprawka nie zmienia schematu 3 ani funkcji importu.

## Pełniejszy opis 0.5.2

Import łączy opis z dodatkową kolumną i opcjonalnie pełną nazwą źródłową,
aby zachować podane w niej modele/roczniki. Wynik można obejrzeć przed
zapisem przez dwuklik na podglądzie. Nie zmienia wcześniej dodanych danych.
[Raport 0.5.2](docs/POPRAWKA_OPISU_0_5_2.md).
Waluty/ceny sugerowane i tłumaczenie nazw opisuje ADR-029. OpenAI API
nie jest bezpłatne; podłączenie wstrzymano do ustalenia kosztu.

## Przyrost 0.6

[Instrukcja](docs/PRACA_Z_KATALOGIEM_0_6.md) opisuje rzeczywisty zakres.
Ceny sugerowane są niezależne od cen Oferty; brak automatycznego przeliczania
walut/VAT. Możesz uzupełnić brakujące ceny istniejących Produktów po SKU
bez usuwania katalogu i nadpisania opisów. Nowe pola ceny i źródłowe media
są zapisywane dopiero po podglądzie/akceptacji. Nowa instalacja bez źródeł
i mediów. Masowe pobieranie zdjęć oraz płatne tłumaczenie niewdrożone.
Schemat 4 z kopią przed migracją. Starszy program wymaga starszej kopii
w osobnym katalogu danych, nie nadpisania aktywnej bazy.

## Poprawka responsywności 0.6.1

Po edycji masowej zaznaczenie wierszy jest odtwarzane zbiorczo. Usunięto
ponawiane skanowanie całego wyboru po każdym przywracanym Produkcie, które
blokowało GUI przy dużym katalogu. Formularz pokazuje stan zapisywania.
Schemat 4 i reguły danych pozostają bez zmian.
[Raport poprawki](docs/POPRAWKA_RESPONSYWNOSCI_0_6_1.md).


## Galeria 0.7

Wybierz jeden Produkt, następnie „Galeria zaznaczonego produktu…”. Dodaj zdjęcia
z dysku (do 5), ustaw kolejność i zapisz. Pierwsze zdjęcie jest miniaturą.
Usuwanie działa roboczo do zapisu; wyczyszczenie całej galerii wymaga potwierdzenia.
Przed zapisem powstaje kopia w `kopie_zdjec`
w katalogu danych aplikacji. Anulowanie pozostawia poprzednie zdjęcia.
Zapis chroni przed równoczesną edycją Produktu. Nie zmienia schematu 4.

[Opis i weryfikacja przyrostu](docs/PRZYROST_0_7.md).
Właściciel potwierdził działanie 0.6.1 na Windows 2026-11-03;
nie jest to pełny odbiór interfejsu ani nowych funkcji 0.7.


## Poprawka nawigacji 0.7.1

„Zdjęcia i media” ma osobny widok z miniaturami, wyborem jednego produktu
i otwieraniem galerii. Nie dubluje zakładki Produkty. Enter i dwuklik
otwierają galerię. Wyszukiwanie pozostaje w widoku mediów.
Opis: [poprawka 0.7.1](docs/POPRAWKA_0_7_1.md).


## Dopasowania 0.8

W formularzu Produktu wybierz „Pasuje do motocykli…”. Każdy wiersz wymaga
marki i modelu, opcjonalnie roczników i wariantu. Dodaj kilka wierszy lub
pozostaw listę pustą. „Zastosuj w formularzu” przenosi zmiany robocze;
„Zapisz lokalnie” zapisuje cały Produkt. Anulowanie formularza odrzuca zmiany.
Szczegóły Produktu pokazują pełną listę. Nie odgadujemy jej z nazwy.
Puste roczniki oznaczają brak danych; sam rok od — niepodany koniec.
Pusta lista dopasowań nie jest oznaczeniem produktu uniwersalnego.

Baza aktualizuje się do schematu 5, ze spójną kopią w `kopie_migracji`
w katalogu danych. Zachowuje wcześniejsze Produkty, Producentów, ceny,
zdjęcia i pozycje Do poprawy. Starsza aplikacja 0.7.1 nie otworzy schematu 5.
Aby wrócić do 0.7.1, zamknij aplikację, zachowaj aktualną bazę osobno i użyj
kopii schematu 4; późniejsze zmiany z 0.8 nie znajdą się w tej kopii.

Allegro i PrestaShop nadal nie wykonują publikacji. Dopasowania są zapisane
strukturalnie jako podstawa przyszłych mapowań, bez gwarancji zgodności
z jeszcze niesprawdzonym API lub konfiguracją sklepu.
[Raport przyrostu](docs/PRZYROST_0_8.md).


## Import dopasowań 0.9

Cenniki → włącz „Importuj dopasowanie do motocykla (opcjonalne)” → wskaż
kolumny marki i modelu, opcjonalnie roczników/wariantu → sprawdź podgląd.
Puste pola nie tworzą dopasowania, błędne trafiają do Do poprawy.
Jeden wiersz zawiera jedno dopasowanie; nie odgadujemy go z nazwy i nie
scalamy SKU. W korekcie można zmienić listę, zachować szkic i później dodać
Produkt. Powiązanie z istniejącym SKU nie nadpisuje jego danych.

Baza aktualizuje się do schematu 6, z kopią. Powrót do 0.8 wymaga
przywrócenia kopii schematu 5 po zabezpieczeniu bieżącej bazy;
zmiany po aktualizacji nie znajdują się w starszej kopii.
[Instrukcja i raport 0.9](docs/PRZYROST_0_9.md).


## Punkt kontrolny 1.0

Na polecenie właściciela przy wersji 1.0 odbędą się szczegółowy audyt
techniczny i audyt użyteczności, w tym obserwacja rzeczywistych zadań
użytkownika. [Plan i wymagane dowody](docs/AUDYT_1_0_PLAN.md).
Audyt jest zaplanowany; nie został jeszcze przeprowadzony.


## Poprawka 0.9.1 — osobna Masowa edycja

„Masowa edycja” otwiera własną stronę: filtry, wybór wielu produktów,
licznik zaznaczenia i ustawienie wspólnej zmiany producenta/opisu.
Nie jest przekierowaniem do Produkty i nie otwiera edytora automatycznie.
Wybierz wiersze → „Ustaw zmianę zaznaczonych…” → wskaż pola → zapisz.
Skrót w Produkty nadal korzysta z tego samego procesu, dla wyboru w Produkty.
Zaznaczenia obu stron są osobne; dane i filtry pochodzą ze wspólnego katalogu.
Wyszukiwanie w Masowej edycji pozostaje na tej stronie. Bez zmiany schematu 6.
[Raport poprawki](docs/POPRAWKA_0_9_1.md).


## Podgląd paczek i logo 0.10

Nowe oferty → Wybierz ZIP → Wczytaj profil lub wskaż plik JSON i pola →
Sprawdź i pokaż oferty. Podgląd zachowuje opisy oraz kolejność sekcji;
obrazy są pokazywane jako adresy, bez pobierania. Profile odczytu zapisujesz
w osobnych plikach użytkownika. Nie ma wbudowanego układu producenta.
[Instrukcja i ograniczenia](docs/PRZYROST_0_10.md).

To pierwszy etap docelowej wysyłki ZIP → Allegro. Nie zapisuje Ofert do bazy,
nie pobiera ustawień konta i nie publikuje. Cena/EAN pozostają danymi
źródłowymi do dalszej weryfikacji. Schemat 6 bez zmian.
Logo użytkownika ma przezroczyste tło, motywy używają granatu/turkusu/fioletu
ze złotymi akcentami. Układ ekranów i dotychczasowy katalog danych zachowane.


## Gotowe ZIP-y i produkty lokalne 0.10.1

Wybierz ZIP zawierający profil odczytu użytkownika. Program sam wybierze
plik danych i otworzy oferty; nie mapujesz ręcznie pól. Starsze paczki
bez profilu nadal mogą użyć zewnętrznego profilu. Konfiguracja zaawansowana
pozostaje schowana. Nie ma zaszytych układów producentów.

Dawny przyrost 0.10.1 udostępniał dodawanie Produktów z ZIP. Ta ścieżka
została wycofana w 0.20: paczka zapisuje samodzielne szkice, bez tworzenia
lub modyfikacji kartotek. Dawne dane zachowano. Publikacja na Allegro
pozostaje niewdrożona.
[Instrukcja i raport 0.10.1](docs/POPRAWKA_0_10_1.md).


## Zapamiętane układy i odświeżony wygląd 0.11

Pierwszy raz otwórz ZIP z profilem lub wczytaj własny profil. Program
zapamięta strukturę. Kolejne paczki tego samego formatu nie muszą zawierać
profilu, również po restarcie i ze zmienioną nazwą pliku danych.
Niejednoznaczność wymaga tylko wyboru z listy. Nowy format — jednorazowego
profilu. Ustawienia są w profile_paczek obok bazy, bez wbudowanych producentów.
Edytor mapowania jest osobnym oknem zaawansowanym.

Wygląd odświeżony przy zachowaniu układu, menu i palety logo. Schemat 6
bez zmian. [Instrukcja i raport](docs/PRZYROST_0_11.md).
Ceny kanałów z API i ich kolorowe porównania nadal do wdrożenia;
uzgodniono, że bazą będzie cena z aktualnego cennika producenta (ADR-039).

W Cenniki → Do poprawy można usuwać zaznaczone wpisy lub wyczyścić odczytaną listę. Wymagane jest potwierdzenie; aplikacja tworzy kopię bazy w `kopie_importow`. Usuwanie nie dotyczy produktów w katalogu ani plików cenników.


Od 0.20: Nowe oferty → wybierz ZIP → Oferty z paczki → Zapisz oferty jako
lokalne szkice… → sprawdź podsumowanie → zatwierdź. Produkty nie powstają.
Identyczne oferty są pomijane. Zakładka Szkice zachowuje treść po restarcie.
Dawne powiązania z Produktami pozostają i nadal chronią przed przypadkowym
usunięciem Produktu. Poniższa instrukcja dotyczy historycznej migracji 0.12.

Aktualizacja bazy 6→7 tworzy kopię w kopie_migracji. Nie otwieraj bazy 7
starszą wersją programu. Aby wrócić do 0.11, zamknij VexLab i odtwórz
sprzed migracji plik katalog.sqlite3 z kopii; dane dodane po tej kopii
nie znajdą się w odtworzonej bazie. Zachowaj bieżącą bazę osobno.


0.13: Szkice → Edytuj tytuł i opis… otwiera wizualny edytor zamiast kodu
HTML. Przeciąganie sekcji, formatowanie tekstu, układy tekst/zdjęcie,
przeciąganie adresów zdjęć z galerii i podgląd całości. Zapis aktualizuje
układ i opis jednego szkicu, bez zmiany Produktu. Schemat 7 bez migracji.
Zdjęcia są adresami HTTPS z paczki lub wpisanymi przez użytkownika;
miniatury nie są pobierane w tym edytorze. [Opis](docs/PRZYROST_0_13.md).


0.13.1: Szkice → Ctrl/Shift lub Zaznacz wszystkie wyniki → Usuń zaznaczone
szkice… Alternatywnie Usuń wszystkie wyniki… czyści bieżące wyniki filtra;
bez wyszukiwania obejmuje całą lokalną listę. Potwierdzenie, kopia w
kopie_szkicow i atomowy zapis; Produkty pozostają w katalogu.
[Raport](docs/POPRAWKA_0_13_1.md).


0.14: wygląd inspirowany Windows 11 — lżejsza nawigacja, nowa paleta
warstw, zaokrąglone panele, przyciski, pola, tabele i motywy. Logo,
kolorystyka marki, układ menu oraz wszystkie funkcje pozostają zachowane.
Schemat bazy 7 bez migracji. [Raport](docs/PRZYROST_0_14.md).


0.14.1: kolorowe symbole funkcji w menu oraz osobne znaki Allegro i
PrestaShop. Czytelne w obu motywach i przy zwiniętym menu. Zasoby lokalne,
bez zmiany funkcji lub danych. [Raport](docs/POPRAWKA_0_14_1.md).


0.15: Produkty mają krótszy pasek: Dodaj, Importuj, Odśwież i Więcej akcji.
Szczegóły, edycja, galeria, wspólna zmiana, zaznaczanie, eksport i usuwanie
są dostępne w rozwijanym menu oraz pod prawym przyciskiem w tabeli.
Shift+F10/Menu otwiera menu z klawiatury. Wszystkie procesy i zabezpieczenia
pozostają zachowane. Schemat 7 bez migracji. [Raport](docs/PRZYROST_0_15.md).


0.15.1: krótsze nazwy w menu Produktów: Szczegóły, Edytuj, Galeria,
Masowa edycja, Importuj, Do poprawy i Eksportuj CSV. Rozróżnienie usuwania
zaznaczonych i wszystkich wyników zachowane. [Raport](docs/POPRAWKA_0_15_1.md).


0.16: biblioteka cenników z rokiem, wyborem pozycji i usuwaniem (ADR-041),
zdjęcia i pełny układ szkicu w edytorze (ADR-042), usunięty mylący przycisk
importu z Produktów. Schemat 8 z kopią; stare migracje niezmienione.
[Raport i instrukcja](docs/PRZYROST_0_16.md).


0.17: podgląd obok listy cenników, statusy pozycji i porównanie kwotowe oraz
procentowe z zapisaną ceną bazową. Aktualny/Archiwalny per producent jako
dana użytkownika, krótszy pasek i menu PPM. Schemat 9 z kopią, migracje 1–8
bez zmian. [Raport](docs/PRZYROST_0_17.md), [ADR-043](docs/adr/ADR-043-porownanie-i-status-cennikow.md).


0.17.1: usuwanie Produktów ze szkicami ma osobne potwierdzenie liczby
powiązanych lokalnych szkiców; wspólna transakcja i kopia. Błędy są
widoczne w oknie. [Raport](docs/POPRAWKA_0_17_1.md), [ADR-044](docs/adr/ADR-044-usuwanie-produktow-ze-szkicami.md).


0.18: opcjonalne EAN w cennikach i Produktach, z walidacją i trwałą korektą
importu. Schemat 10 z kopią, starsze migracje 1–9 niezmienione. Profile
automatyzujące różne formaty cenników są osobną propozycją.
[Raport](docs/PRZYROST_0_18.md), [ADR-045](docs/adr/ADR-045-ean-w-cenniku.md).

### Dodatkowe zmiany 0.18

Cenniki: wybór bazowego dokumentu producenta, aktualizacja nowym wydaniem
z zachowaniem historii i różnicy kwotowej/procentowej, status Nowy oraz
przyczyna po kliknięciu Do poprawy. Po zapisie kreator czyści plik i podgląd.
Wspierane formaty kwot XLSX uwzględniają widoczną precyzję (bez obliczania formuł).
Dashboard → Szybkie akcje → Edytuj zapisuje wybór i kolejność użytkownika.
Produkty → zaznaczenie → PPM / Więcej → Pobierz zdjęcia… pobiera pierwsze
zdjęcie po SKU z publicznego katalogu Shopify pod własnym adresem producenta;
postęp, zatrzymanie, limit nowych danych, bez zastępowania galerii.
Jedna dodatkowa kopia bazy na serię; zgodność strony Evotech wymaga odbioru na żywo.
[Scenariusze i ograniczenia](docs/PRZYROST_0_18.md),
[audyt techniczny](docs/AUDYT_TECHNICZNY_0_18.md).

Aktualizacja 0.30: dynamiczne przyciski producentów, wyszukiwanie i filtry oraz lista/kafelki katalogu. [Opis](docs/PRZYROST_0_30.md).

Poprawka 0.30.1: wyrównanie lupy i przycisku czyszczenia w polach wyszukiwania. [Opis](docs/POPRAWKA_0_30_1.md).

Poprawka 0.30.2: kompaktowa wyszukiwarka w rzędzie producentów. [Opis](docs/POPRAWKA_0_30_2.md).

Poprawka 0.30.3: wyszukiwarka i narzędzia po prawej. [Opis](docs/POPRAWKA_0_30_3.md).

Poprawka 0.30.4: producenci bez przewijania i ucinania, nadmiar w menu Więcej. [Opis](docs/POPRAWKA_0_30_4.md).

Poprawka 0.30.5: wyrównanie rozmiaru Więcej do producentów. [Opis](docs/POPRAWKA_0_30_5.md).

Poprawka 0.30.6: kwadratowe przyciski filtra i widoków. [Opis](docs/POPRAWKA_0_30_6.md).

Poprawka 0.30.7: sekcje menu w kolorach kafelków KPI. [Opis](docs/POPRAWKA_0_30_7.md).

Poprawka 0.30.8: ciemniejsze kolory kafelków i sekcji menu. [Opis](docs/POPRAWKA_0_30_8.md).

Poprawka 0.30.9: mocniej przyciemniona paleta menu i kafelków. [Opis](docs/POPRAWKA_0_30_9.md).

Poprawka 0.30.10: przyciemnienie palety o 43% względem 0.30.7. [Opis](docs/POPRAWKA_0_30_10.md).


Przyrost 0.31: podgląd rzeczywistego szkicu Allegro (tytuł, cena, galeria, opis) z listy INACTIVE. Bez zapisu i publikacji; edycja pozostaje kolejnym etapem. Schemat 11 bez zmian. [Raport](docs/PRZYROST_0_31.md), [ADR-055](docs/adr/ADR-055-podglad-szkicu-allegro.md).

Poprawka 0.31.1: spokojniejsze boczne menu z jednym niebieskim wyróżnieniem aktywnej zakładki. [Opis](docs/POPRAWKA_0_31_1.md).

Poprawka 0.31.2: jawne zakresy odczytu Allegro i dokładniejsze komunikaty odmowy dostępu. [Instrukcja](docs/POPRAWKA_0_31_2.md).


Przyrost 0.32: karta Integracje z dwiema kartami kanałów, logotypami i Zarządzaj oraz górny pasek z kanałami, statusem, ustawieniami i profilem według nowej referencji właściciela. Tylko potwierdzone dane sesji; brakujące liczniki/limit/wersja oznaczone —, PrestaShop nadal w przygotowaniu. [Opis](docs/PRZYROST_0_32.md).


Przyrost 0.33: ekran Allegro według referencji 2026-11-09 — nagłówek, KPI, zakładki, filtry, tabela i panel szczegółów. Odczyt INACTIVE działa; pozostałe stany, metryki i polecenia zapisu są jawnie niedostępne, bez danych demo. [Opis](docs/PRZYROST_0_33.md), [ADR-056](docs/adr/ADR-056-przestrzen-allegro.md).

Poprawka 0.33.1: pełne kolorowe tła kafelków podsumowań Allegro. [Opis](docs/POPRAWKA_0_33_1.md).


Przyrost 0.34 — właściciel 2026-11-09: płaskie, kompaktowe przyciski w całym programie według wzoru, cienka ramka i promień 6 px. Nowy biało-srebrny znak VEX w nagłówku i ikonie programu zastępuje herb; nazwa VexLab bez zmian. Dane i działania bez zmian. [Opis](docs/PRZYROST_0_34.md).

### Dashboard 0.35

Nowy układ głównego panelu według referencji: siedem KPI, sprzedaż, integracje,
alerty jakości katalogu, zamówienia/rankingi, magazyn, aktywność i AI Center.
Koło zębate przy okresach otwiera konfigurator widoczności/kolejności sekcji.
Agregaty lokalne działają; niewdrożone źródła kanałów pokazują brak danych.
[Zakres, ograniczenia i weryfikacja](docs/PRZYROST_0_35.md).

Poprawka 0.35.1: AI Center z ciemnymi kafelkami i ikonami według nowego
wycinka referencyjnego oraz transparentne logo VEX bez czarnej płytki.
[Opis i zakres](docs/POPRAWKA_0_35_1.md).

### Allegro 0.36

Zakładki Wszystkie / Aktywne / Szkice / Aktywowanie / Zakończone pobierają
rzeczywiste listy i szczegóły ofert. Licznik aktywnych ofert zasila także
Dashboard. Dane pochodzą z potwierdzonego konta, odczyt w tle i cache 30 s.
Do 50 ofert na stronę, przeglądanie pierwszych 10 000 wyników; licznik całego
wyniku API może być większy. Wyszukiwanie nadal obejmuje bieżącą stronę.
Zapis, publikacja oraz statystyki zamówień/sprzedaży pozostają w przygotowaniu.
[Zakres, ograniczenia i testy](docs/PRZYROST_0_36.md).

Poprawka 0.36.1: miniatury Allegro mają większe, jednakowe pola 64×64 px,
z zachowaniem proporcji zdjęcia. [Opis](docs/POPRAWKA_0_36_1.md).

Poprawka 0.36.2: kolory kafelków Allegro dopasowane do Dashboardu —
ciemne tła, subtelne kolorowe poświaty i kolorowe pola ikon.
[Opis](docs/POPRAWKA_0_36_2.md).

Poprawka 0.36.3: przywrócone pionowe karty integracji z logotypami,
statusem i informacjami o koncie/sklepie. [Opis](docs/POPRAWKA_0_36_3.md).

### Przygotowanie edycji szkiców 0.37 (stan historyczny)

Szkic Allegro INACTIVE → Przygotuj edycję szkicu: tytuł, sekcje opisu,
podgląd, zapis/wczytanie lokalnej propozycji JSON i sprawdzenie aktualności.
**Zapis zmian w Allegro pozostaje niedostępny** do potwierdzenia aktualnego
kontraktu API; nie dodano uprawnień ani mutacji. Nie ma publikacji.
[Zakres, ograniczenie dostępu i sprawdzenia](docs/PRZYROST_0_37.md).

### Zapis szkiców 0.38

Przesłana specyfikacja potwierdziła kontrakt zapisu. Udostępniono potwierdzany PATCH
tytułu/opisu oraz kontrolę wyniku, bez publikacji. [Instrukcja](docs/PRZYROST_0_38.md),
[decyzja techniczna i ograniczenia współbieżności](docs/adr/ADR-060-zapis-szkicu-allegro.md).
