"""Układ przestrzeni Allegro według referencji; dostępne działania są tylko odczytem."""

from functools import partial

from PySide6.QtCore import QDateTime, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QGuiApplication, QResizeEvent, QShowEvent
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMenu,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.design_system import ikona, ikona_menu
from vexlab.gui.podglad_oferty import ObrazyOferty
from vexlab.gui.producenci import Uruchom
from vexlab.gui.tekst_podgladu import etykieta
from vexlab.gui.widoki_katalogu import NaglowekWyboru
from vexlab.przypadki_uzycia.allegro import StronaSzkicowAllegro, SzczegolySzkicuAllegro
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec

OPIS_ODCZYTU = (
    "Dostępny jest odczyt szkiców INACTIVE. "
    "Statystyki sprzedaży i operacje zapisu są w przygotowaniu."
)


def przycisk(nazwa: str, symbol: str = "", dostepny: bool = True) -> QPushButton:
    b = QPushButton(nazwa)
    b.setProperty("akcjaAllegro", True)
    if symbol:
        b.setIcon(ikona(symbol, "#96B9DB"))
        b.setIconSize(QSize(16, 16))
    b.setEnabled(dostepny)
    b.setAccessibleName(nazwa)
    if not dostepny:
        b.setToolTip("Działanie będzie dostępne po wdrożeniu odpowiedniej operacji Allegro API.")
    return b


class ObszarAllegro(QWidget):
    ustawienia = Signal()
    nowa = Signal()
    szczegoly = Signal()
    pomoc = Signal()

    def __init__(
        self,
        tabela: QTableWidget,
        status: QLabel,
        odswiez: QPushButton,
        podglad: QPushButton,
        poprzednia: QPushButton,
        nastepna: QPushButton,
        zakres: QLabel,
        zdjecia: PodgladZdjec | None,
        uruchom: Uruchom,
    ) -> None:
        super().__init__()
        self.tabela, self.zdjecia, self.uruchom = tabela, zdjecia, uruchom
        self.obrazy = ObrazyOferty(self, zdjecia, uruchom)
        self.obrazy_tabeli = ObrazyOferty(self, zdjecia, uruchom, miniatury=True)
        self._zdjecia_wierszy: dict[str, str] = {}
        self._miniatury: set[str] = set()
        self._opcje_filtrow: list[QWidget] = []
        self._statystyki: list[QWidget] = []
        self._tryby: list[QWidget] = []
        self.timer_miniatur = QTimer(self)
        self.timer_miniatur.setSingleShot(True)
        self.timer_miniatur.timeout.connect(self._miniatury_widoczne)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        layout.addLayout(self._naglowek(status))
        layout.addLayout(self._metryki())
        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.addWidget(self._lista(odswiez, poprzednia, nastepna, zakres))
        self.splitter.addWidget(self._panel_szczegolow(podglad))
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setSizes([850, 280])
        layout.addWidget(self.splitter, 1)

    def _naglowek(self, status: QLabel) -> QHBoxLayout:
        head = QHBoxLayout()
        znak = QLabel()
        znak.setPixmap(ikona_menu("Allegro", True).pixmap(42, 42))
        head.addWidget(znak)
        opis = QVBoxLayout()
        top = QHBoxLayout()
        title = etykieta("Allegro")
        title.setObjectName("marka")
        top.addWidget(title)
        self._opis_naglowka = QLabel("Zarządzaj ofertami i monitoruj sprzedaż.")
        self._opis_naglowka.setObjectName("opisAllegro")
        top.addWidget(self._opis_naglowka)
        top.addStretch()
        opis.addLayout(top)
        info = QHBoxLayout()
        self.konto = etykieta("Konto: —")
        info.addWidget(self.konto)
        info.addWidget(status, 1)
        self.ostatni = etykieta("Ostatni odczyt: —")
        self.ostatni.setObjectName("opisAllegro")
        self.ostatni.setWordWrap(False)
        info.addWidget(self.ostatni)
        opis.addLayout(info)
        head.addLayout(opis, 1)
        config = przycisk("Ustawienia połączenia", "ustawienia")
        config.clicked.connect(self.ustawienia.emit)
        head.addWidget(config)
        self._pomoc = przycisk("Pomoc Allegro", "pomoc")
        self._pomoc.clicked.connect(self.pomoc.emit)
        head.addWidget(self._pomoc)
        return head

    def _metryki(self) -> QHBoxLayout:
        metrics = QHBoxLayout()
        metrics.setSpacing(12)
        self.liczniki: dict[str, QLabel] = {}
        for nazwa, symbol, wariant, podpis in (
            ("Aktywne oferty", "oferta", "zielony", "Brak danych API"),
            ("Szkice", "plik", "niebieski", "Oczekują na publikację"),
            ("Błędy", "blad", "czerwony", "Brak danych API"),
            ("Sprzedano (30 dni)", "koszyk", "fioletowy", "sztuk"),
            ("Obrót (30 dni)", "monety", "zloty", "Brak danych API"),
        ):
            card = QFrame()
            card.setObjectName("kpiAllegro")
            box = QHBoxLayout(card)
            box.setContentsMargins(12, 10, 12, 10)
            badge = QLabel()
            badge.setProperty("wariantAllegro", wariant)
            badge.setPixmap(ikona(symbol, "#FFFFFF").pixmap(23, 23))
            badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            badge.setFixedSize(38, 38)
            box.addWidget(badge, 0, Qt.AlignmentFlag.AlignTop)
            labels = QVBoxLayout()
            labels.setSpacing(3)
            heading = etykieta(nazwa)
            heading.setObjectName("opisAllegro")
            labels.addWidget(heading)
            value = etykieta("—")
            value.setObjectName("licznikAllegro")
            labels.addWidget(value)
            desc = etykieta(podpis)
            desc.setObjectName("podpisAllegro")
            labels.addWidget(desc)
            self.liczniki[nazwa] = value
            box.addLayout(labels, 1)
            metrics.addWidget(card, 1)
            if nazwa in {"Sprzedano (30 dni)", "Obrót (30 dni)"}:
                self._statystyki.append(card)
        return metrics

    def _lista(
        self, odswiez: QPushButton, poprzednia: QPushButton, nastepna: QPushButton, zakres: QLabel
    ) -> QFrame:
        tabela = self.tabela
        left = QFrame()
        left.setObjectName("obszarOfertAllegro")
        body = QVBoxLayout(left)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(8)
        tabs = QHBoxLayout()
        self.tab_szkice = przycisk("Szkice (—)")
        self.tab_szkice.setObjectName("primary")
        for nazwa in ("Wszystkie (—)", "Aktywne (—)"):
            tabs.addWidget(przycisk(nazwa, dostepny=False))
        tabs.addWidget(self.tab_szkice)
        self.tab_szkice.clicked.connect(odswiez.click)
        for nazwa in ("Ukryte (—)", "Błędy (—)", "Zakończone (—)"):
            tabs.addWidget(przycisk(nazwa, dostepny=False))
        tabs.addStretch()
        body.addLayout(tabs)
        filters = QHBoxLayout()
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj na stronie…")
        self.szukaj.setAccessibleName("Szukaj w pobranej stronie szkiców Allegro")
        self.szukaj.setToolTip("Filtr obejmuje tylko bieżącą stronę pobraną z Allegro.")
        self.szukaj.addAction(ikona("szukaj"), QLineEdit.ActionPosition.LeadingPosition)
        self.szukaj.setClearButtonEnabled(True)
        self.szukaj.setMinimumWidth(140)
        self.szukaj.setMaximumWidth(260)
        self.szukaj.textChanged.connect(self._filtruj)
        filters.addWidget(self.szukaj, 2)
        for nazwa in ("Kategoria:", "Producent:"):
            label = QLabel(nazwa)
            label.setObjectName("opisAllegro")
            filters.addWidget(label)
            self._opcje_filtrow.append(label)
            combo = QComboBox()
            combo.setObjectName("filtrAllegro")
            combo.setFixedWidth(110)
            combo.addItem("Wszystkie")
            combo.setEnabled(False)
            combo.setToolTip("Filtr będzie dostępny po wdrożeniu mapowania danych kanału.")
            filters.addWidget(combo, 1)
            self._opcje_filtrow.append(combo)
        filters.addStretch(1)
        filters.addWidget(przycisk("Więcej filtrów", "filtr", False))
        clear = przycisk("Wyczyść")
        clear.clicked.connect(self.szukaj.clear)
        filters.addWidget(clear)
        body.addLayout(filters)
        actions = QHBoxLayout()
        new = przycisk("Nowa oferta", "dodaj")
        new.setObjectName("primary")
        new.clicked.connect(self.nowa.emit)
        new.setToolTip("Przejdź do przygotowania lokalnej paczki nowych ofert.")
        actions.addWidget(new)
        imp = przycisk("Importuj", "pobierz")
        imp.clicked.connect(self.nowa.emit)
        imp.setToolTip("Wczytaj lokalną paczkę ZIP nowych ofert.")
        actions.addWidget(imp)
        actions.addWidget(przycisk("Publikuj", "pobierz", False))
        odswiez.setText("Odśwież")
        odswiez.setProperty("akcjaAllegro", True)
        odswiez.setIcon(ikona("synchronizacja"))
        actions.addWidget(odswiez)
        actions.addWidget(przycisk("Masowa edycja", "edytuj", False))
        actions.addStretch()
        for nazwa in ("Tabela", "Kafelki", "Kanban"):
            b = przycisk(nazwa, dostepny=nazwa == "Tabela")
            if nazwa == "Tabela":
                b.setCheckable(True)
                b.setChecked(True)
            actions.addWidget(b)
            if nazwa != "Tabela":
                self._tryby.append(b)
        body.addLayout(actions)
        tabela.setObjectName("tabelaAllegro")
        tabela.setColumnCount(10)
        tabela.setHorizontalHeaderLabels(
            [
                "ID Allegro",
                "Tytuł oferty",
                "Zdjęcie",
                "SKU / EAN",
                "Cena",
                "Stan",
                "Sprzedano",
                "Status",
                "Akcje",
                "",
            ]
        )
        self.naglowek = NaglowekWyboru(
            tabela, lambda: self._zaznacz(True), lambda: self._zaznacz(False)
        )
        self.naglowek.setAccessibleName("Zaznacz wszystkie szkice pobrane na bieżącej stronie")
        tabela.setHorizontalHeader(self.naglowek)
        tabela.setColumnHidden(0, True)
        header = tabela.horizontalHeader()
        for visual, logical in enumerate((9, 2, 1, 3, 4, 5, 6, 7, 8)):
            header.moveSection(header.visualIndex(logical), visual)
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for col, width in (
            (9, 30),
            (2, 56),
            (3, 110),
            (4, 100),
            (5, 48),
            (6, 66),
            (7, 86),
            (8, 74),
        ):
            tabela.setColumnWidth(col, width)
        tabela.verticalHeader().hide()
        tabela.verticalHeader().setDefaultSectionSize(48)
        tabela.verticalScrollBar().valueChanged.connect(lambda *_: self.timer_miniatur.start(50))
        tabela.itemSelectionChanged.connect(self._zaznaczenie)
        tabela.itemChanged.connect(lambda *_: self._zaznaczenie())
        body.addWidget(tabela, 1)
        bulk = QHBoxLayout()
        self.zaznaczenie = etykieta("Zaznaczono: 0")
        bulk.addWidget(self.zaznaczenie)
        for nazwa in ("Edytuj", "Duplikuj", "Zmień cenę", "Zmień stan", "Zakończ", "Usuń"):
            bulk.addWidget(przycisk(nazwa, dostepny=False))
        body.addLayout(bulk)
        pages = QHBoxLayout()
        pages.addWidget(zakres, 1)
        pages.addWidget(poprzednia)
        pages.addWidget(nastepna)
        pages.addWidget(QLabel("50 na stronę"))
        body.addLayout(pages)
        return left

    def _panel_szczegolow(self, podglad: QPushButton) -> QFrame:
        self.panel = QFrame()
        self.panel.setObjectName("szczegolyAllegro")
        right = QVBoxLayout(self.panel)
        right.setContentsMargins(12, 12, 12, 12)
        right.addWidget(QLabel("Szczegóły oferty"))
        self.photo = QVBoxLayout()
        right.addLayout(self.photo)
        self.tytul = etykieta("Wybierz szkic z listy")
        self.tytul.setObjectName("tytulOfertyAllegro")
        right.addWidget(self.tytul)
        self.id = etykieta("ID Allegro: —")
        self.id.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        right.addWidget(self.id)
        self.pola: dict[str, QLabel] = {}
        form = QGridLayout()
        for i, nazwa in enumerate(
            (
                "Cena",
                "Stan magazynowy",
                "Sprzedano",
                "Wyświetlenia",
                "Obserwujący",
                "Kategoria",
                "SKU / EAN",
            )
        ):
            label = QLabel(nazwa)
            label.setObjectName("opisAllegro")
            form.addWidget(label, i, 0)
            value = etykieta("—")
            self.pola[nazwa] = value
            form.addWidget(value, i, 1)
        right.addLayout(form)
        right.addWidget(podglad)
        for nazwa, symbol in (
            ("Edytuj ofertę", "edytuj"),
            ("Duplikuj", "kopiuj"),
            ("Zakończ", "blad"),
            ("Otwórz na Allegro", "oferta"),
            ("Historia zmian", "historia"),
            ("Statystyki", "wykres"),
        ):
            right.addWidget(przycisk(nazwa, symbol, False))
        self.uwaga = etykieta(OPIS_ODCZYTU)
        self.uwaga.setObjectName("podpisAllegro")
        right.addWidget(self.uwaga)
        right.addStretch()
        self.panel.setMinimumWidth(240)
        self.panel.setMaximumWidth(300)
        return self.panel

    def ustaw_strone(self, strona: StronaSzkicowAllegro) -> None:
        self.liczniki["Szkice"].setText(str(strona.lacznie))
        self.tab_szkice.setText(f"Szkice ({strona.lacznie})")
        self.ostatni.setText(
            "Ostatni odczyt: " + QDateTime.currentDateTime().toString("dd.MM.yyyy HH:mm")
        )
        self._zdjecia_wierszy.clear()
        self._miniatury.clear()
        for row, p in enumerate(strona.szkice):
            for col, value in (
                (2, "—"),
                (3, p.sku or "—"),
                (4, f"{p.cena.replace('.', ',')} {p.waluta}" if p.cena else "—"),
                (5, str(p.stan) if p.stan is not None else "—"),
                (6, "—"),
                (7, "● Szkic"),
            ):
                self.tabela.setItem(row, col, QTableWidgetItem(value))
            checkbox = QTableWidgetItem()
            checkbox.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            checkbox.setCheckState(Qt.CheckState.Unchecked)
            self.tabela.setItem(row, 9, checkbox)
            host = QWidget()
            buttons = QHBoxLayout(host)
            buttons.setContentsMargins(4, 0, 4, 0)
            buttons.setSpacing(4)
            edit = QToolButton()
            edit.setObjectName("akcjaWierszaAllegro")
            edit.setIcon(ikona("edytuj"))
            edit.setEnabled(False)
            edit.setToolTip("Edycja zdalnej oferty jest w przygotowaniu.")
            buttons.addWidget(edit)
            b = QToolButton()
            b.setObjectName("akcjaWierszaAllegro")
            b.setIcon(ikona("wiecej"))
            b.setAccessibleName(f"Akcje szkicu {p.id}")
            menu = QMenu(b)
            menu.addAction("Podgląd szkicu", self.szczegoly.emit)
            menu.addAction("Kopiuj ID Allegro", partial(QGuiApplication.clipboard().setText, p.id))
            b.setMenu(menu)
            b.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            b.pressed.connect(lambda r=row: self.tabela.selectRow(r))
            buttons.addWidget(b)
            self.tabela.setCellWidget(row, 8, host)
            if p.zdjecie:
                self._zdjecia_wierszy[p.id] = p.zdjecie
        self._filtruj()
        self.timer_miniatur.start(0)

    def _filtruj(self) -> None:
        fraza = self.szukaj.text().casefold().strip()
        for row in range(self.tabela.rowCount()):
            title, sku = self.tabela.item(row, 1), self.tabela.item(row, 3)
            self.tabela.setRowHidden(
                row,
                bool(fraza)
                and fraza
                not in (
                    (title.text() if title else "") + " " + (sku.text() if sku else "")
                ).casefold(),
            )
        row = self.tabela.currentRow()
        if row >= 0 and self.tabela.isRowHidden(row):
            self.tabela.setCurrentCell(-1, -1)
            self.tabela.clearSelection()
            self._wyczysc_panel()
        self.timer_miniatur.start(0)

    def _zaznaczenie(self) -> None:
        count = 0
        for r in range(self.tabela.rowCount()):
            item = self.tabela.item(r, 9)
            if item is not None and item.checkState() == Qt.CheckState.Checked:
                count += 1
        self.zaznaczenie.setText(f"Zaznaczono: {count}")
        self.naglowek.ustaw(count, self.tabela.rowCount())
        row = self.tabela.currentRow()
        title, ident = self.tabela.item(row, 1), self.tabela.item(row, 0)
        if title is not None and ident is not None:
            if self.id.text() != "ID Allegro: " + ident.text():
                self.uwaga.setText(OPIS_ODCZYTU)
                self._wyczysc_zdjecie()
                for pole in self.pola.values():
                    pole.setText("—")
                for key, col in (("Cena", 4), ("Stan magazynowy", 5), ("SKU / EAN", 3)):
                    cell = self.tabela.item(row, col)
                    self.pola[key].setText(cell.text() if cell else "—")
            self.tytul.setText(title.text())
            self.id.setText("ID Allegro: " + ident.text())

    def _miniatury_widoczne(self) -> None:
        if not self.tabela.isVisible():
            return
        for row in range(self.tabela.rowCount()):
            index = self.tabela.model().index(row, 2)
            if not self.tabela.isRowHidden(row) and self.tabela.visualRect(index).intersects(
                self.tabela.viewport().rect()
            ):
                item = self.tabela.item(row, 0)
                if item is None or item.text() in self._miniatury:
                    continue
                url = self._zdjecia_wierszy.get(item.text())
                if url:
                    image = self.obrazy_tabeli.obraz(url)
                    image.setFixedSize(48, 36)
                    image.setText("")
                    self.tabela.setCellWidget(row, 2, image)
                    self._miniatury.add(item.text())

    def pokaz_szczegoly(self, d: SzczegolySzkicuAllegro) -> None:
        ident = self.tabela.item(self.tabela.currentRow(), 0)
        if (
            ident is None
            or ident.text() != d.id
            or self.tabela.isRowHidden(self.tabela.currentRow())
        ):
            return
        self.uwaga.setText(OPIS_ODCZYTU)
        self.tytul.setText(d.tytul)
        self.id.setText("ID Allegro: " + d.id)
        for key, value in (
            ("Cena", f"{d.cena.replace('.', ',')} {d.waluta}" if d.cena else "—"),
            ("Stan magazynowy", str(d.stan) if d.stan is not None else "—"),
            ("Kategoria", d.kategoria or "—"),
            ("SKU / EAN", d.sku or "—"),
        ):
            self.pola[key].setText(value)
        self._wyczysc_zdjecie()
        if d.zdjecia:
            image = self.obrazy.obraz(d.zdjecia[0])
            image.setMinimumHeight(120)
            image.setMaximumHeight(170)
            self.photo.addWidget(image)

    def wyczysc(self) -> None:
        self.naglowek.ustaw(0, 0)
        self.zaznaczenie.setText("Zaznaczono: 0")
        self.timer_miniatur.stop()
        self.obrazy.zamknij()
        self.obrazy_tabeli.zamknij()
        self.obrazy = ObrazyOferty(self, self.zdjecia, self.uruchom)
        self.obrazy_tabeli = ObrazyOferty(self, self.zdjecia, self.uruchom, miniatury=True)
        self._zdjecia_wierszy.clear()
        self._miniatury.clear()
        self.liczniki["Szkice"].setText("—")
        self.tab_szkice.setText("Szkice (—)")
        self.ostatni.setText("Ostatni odczyt: —")
        self._wyczysc_panel()

    def _wyczysc_zdjecie(self) -> None:
        while self.photo.count():
            item = self.photo.takeAt(0)
            widget = item.widget() if item is not None else None
            if widget is not None:
                widget.hide()
                widget.deleteLater()

    def _wyczysc_panel(self) -> None:
        self.tytul.setText("Wybierz szkic z listy")
        self.id.setText("ID Allegro: —")
        self.uwaga.setText(OPIS_ODCZYTU)
        for pole in self.pola.values():
            pole.setText("—")
        self._wyczysc_zdjecie()

    def ustaw_konto(self, login: str | None) -> None:
        self.konto.setText("Konto: " + (login or "—"))

    def _zaznacz(self, zaznacz: bool) -> None:
        poprzedni = self.tabela.blockSignals(True)
        try:
            for row in range(self.tabela.rowCount()):
                item = self.tabela.item(row, 9)
                if item is not None:
                    item.setCheckState(
                        Qt.CheckState.Checked if zaznacz else Qt.CheckState.Unchecked
                    )
        finally:
            self.tabela.blockSignals(poprzedni)
        self._zaznaczenie()

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        if not hasattr(self, "panel"):
            return
        szeroki = self.width() >= 950
        self.panel.setVisible(szeroki)
        self._pomoc.setVisible(szeroki)
        self._opis_naglowka.setVisible(szeroki)
        for w in self._statystyki:
            w.setVisible(szeroki)
        for w in self._opcje_filtrow + self._tryby:
            w.setVisible(self.width() >= 1100)
        self.timer_miniatur.start(0)

    def showEvent(self, event: QShowEvent) -> None:
        super().showEvent(event)
        self.timer_miniatur.start(0)
