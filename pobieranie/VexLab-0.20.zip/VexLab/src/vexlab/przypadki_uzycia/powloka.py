"""Preferencje techniczne powłoki; bez encji i reguł sprzedaży."""

from dataclasses import dataclass, replace
from enum import StrEnum
from typing import Protocol

from vexlab.przypadki_uzycia.media import strona_zdjec
from vexlab.przypadki_uzycia.szybkie_akcje import sprawdz_akcje


class Motyw(StrEnum):
    CIEMNY = "ciemny"
    JASNY = "jasny"
    SYSTEMOWY = "systemowy"


@dataclass(frozen=True)
class PreferencjePowloki:
    motyw: Motyw = Motyw.CIEMNY
    menu_zwiniete: bool = False
    szybkie_akcje: tuple[str, ...] | None = None
    strona_zdjec: str = ""
    limit_zdjec_mb: int = 256


class MagazynPreferencji(Protocol):
    def odczytaj(self) -> PreferencjePowloki: ...

    def zapisz(self, preferencje: PreferencjePowloki) -> None: ...


class PowlokaAplikacji:
    def __init__(self, magazyn: MagazynPreferencji, nazwa_uzytkownika: str, wersja: str) -> None:
        self._magazyn = magazyn
        self.preferencje = magazyn.odczytaj()
        self.nazwa_uzytkownika = nazwa_uzytkownika
        self.wersja = wersja

    def ustaw_motyw(self, motyw: Motyw) -> None:
        nowe = replace(self.preferencje, motyw=motyw)
        self._magazyn.zapisz(nowe)
        self.preferencje = nowe

    def ustaw_menu(self, zwiniete: bool) -> None:
        nowe = replace(self.preferencje, menu_zwiniete=zwiniete)
        self._magazyn.zapisz(nowe)
        self.preferencje = nowe

    def ustaw_szybkie_akcje(self, akcje: tuple[str, ...]) -> None:
        sprawdz_akcje(akcje)
        nowe = replace(self.preferencje, szybkie_akcje=akcje)
        self._magazyn.zapisz(nowe)
        self.preferencje = nowe

    def ustaw_zrodlo_zdjec(self, strona: str, limit_mb: int) -> None:
        strona = strona_zdjec(strona)
        if not 1 <= limit_mb <= 4096:
            raise ValueError("Wybierz limit 1–4096 MB.")
        nowe = replace(self.preferencje, strona_zdjec=strona, limit_zdjec_mb=limit_mb)
        self._magazyn.zapisz(nowe)
        self.preferencje = nowe
