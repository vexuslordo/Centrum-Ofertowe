"""Biblioteka źródeł importu, niezależna od katalogu Produktów."""

from dataclasses import dataclass, replace
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path
from typing import Protocol
from uuid import UUID, uuid4

from vexlab.przypadki_uzycia.importowanie import (
    ImportujProdukty,
    OcenaPozycji,
    PozycjaImportu,
    blad,
)
from vexlab.przypadki_uzycia.katalog import CenaSugerowanaDTO, _mapuj_bledy


@dataclass(frozen=True)
class CennikDTO:
    id: UUID
    nazwa: str
    rok: int
    wydanie: str
    producent: str
    zrodlo: str
    arkusz: str
    liczba: int
    wczytano_utc: str
    wersja: int
    producent_id: UUID | None = None
    aktualny: bool = False
    archiwalny: bool = False
    poprzedni_id: UUID | None = None

    @property
    def status(self) -> str:
        return "Aktualny / bazowy" if self.aktualny else "Archiwalny" if self.archiwalny else "Nowy"


@dataclass(frozen=True)
class PozycjaCennika:
    indeks: int
    pozycja: PozycjaImportu
    stan: str
    w_katalogu: bool
    cena_bazowa: CenaSugerowanaDTO | None = None
    roznica: str = "—"
    porownanie: str = ""
    problem: str = ""


@dataclass(frozen=True)
class WynikCennika:
    dodane: int
    odlozone: int
    pominiete: int
    kopia: Path | None


class MagazynCennikow(Protocol):
    def zapisz_cennik(
        self,
        nazwa: str,
        rok: int,
        wydanie: str,
        pozycje: tuple[PozycjaImportu, ...],
        *,
        poprzedni: CennikDTO | None = None,
    ) -> UUID: ...
    def lista(self) -> tuple[CennikDTO, ...]: ...
    def pozycje(self, id: UUID, wersja: int) -> tuple[PozycjaImportu, ...]: ...
    def dodaj_pozycje(
        self, cennik: CennikDTO, oceny: tuple[OcenaPozycji, ...], pominiete: int
    ) -> WynikCennika: ...
    def usun(self, cenniki: tuple[tuple[UUID, int], ...]) -> Path: ...
    def oznacz(
        self, cennik: CennikDTO, aktualny: bool, oczekiwane: tuple[tuple[UUID, int], ...]
    ) -> Path: ...


class BibliotekaCennikow:
    def __init__(self, magazyn: MagazynCennikow, importer: ImportujProdukty) -> None:
        self.magazyn, self.importer = magazyn, importer

    def zapisz(
        self,
        nazwa: str,
        rok: int,
        wydanie: str,
        oceny: tuple[OcenaPozycji, ...],
        *,
        poprzedni: CennikDTO | None = None,
    ) -> UUID:
        if not nazwa.strip() or not 1000 <= rok <= 9999 or not oceny:
            raise blad("Podaj nazwę, rok cennika oraz sprawdź dane pliku.")
        if len({o.pozycja.dane.producent_id for o in oceny}) != 1:
            raise blad("Wybierz jednego producenta cennika lub brak producenta.")
        if poprzedni is not None and any(
            o.pozycja.dane.producent_id != poprzedni.producent_id for o in oceny
        ):
            raise blad("Nowe wydanie musi mieć tego samego producenta co poprzedni cennik.")
        return self.magazyn.zapisz_cennik(
            nazwa.strip(),
            rok,
            wydanie.strip(),
            tuple(o.pozycja for o in oceny),
            poprzedni=poprzedni,
        )

    def lista(self) -> tuple[CennikDTO, ...]:
        return self.magazyn.lista()

    def pozycje(self, cennik: CennikDTO) -> tuple[PozycjaCennika, ...]:
        rows = self.magazyn.pozycje(cennik.id, cennik.wersja)
        znane = {p.klucz_sku: p for p in self.importer.katalog.wyszukaj("")}
        ceny, braki = self._ceny_bazowe(cennik)
        wynik = []
        for i, o in enumerate(self.importer.ocen(rows, uwzglednij_katalog=False)):
            produkt = znane.get(o.pozycja.dane.sku.strip().casefold())
            sku = o.pozycja.dane.sku.strip().casefold()
            bazowa = ceny.get(sku)
            problem = o.problem
            inny_producent = bool(
                produkt
                and produkt.producent_id
                and o.pozycja.dane.producent_id
                and produkt.producent_id != o.pozycja.dane.producent_id
            )
            if inny_producent:
                problem = "; ".join(filter(None, (problem, "SKU ma innego producenta w katalogu")))
            roznica, uwaga, zmiana = porownaj(o.pozycja, bazowa)
            if bazowa is None:
                uwaga = braki.get(sku, braki.get("", "Brak SKU w aktualnym cenniku producenta"))
            if problem:
                roznica, uwaga, zmiana = "—", problem, False
            stan = (
                "Do poprawy"
                if problem
                else "Inna cena"
                if zmiana
                else "Nowy"
                if produkt is None
                else "W katalogu"
            )
            wynik.append(
                PozycjaCennika(
                    i, o.pozycja, stan, produkt is not None, bazowa, roznica, uwaga, problem
                )
            )
        return tuple(wynik)

    def _ceny_bazowe(
        self, cennik: CennikDTO
    ) -> tuple[dict[str, CenaSugerowanaDTO], dict[str, str]]:
        if cennik.poprzedni_id is not None:
            aktualny = next((c for c in self.lista() if c.id == cennik.poprzedni_id), None)
            if aktualny is None:
                return {}, {
                    "": "Poprzednie wydanie cennika zostało usunięte — brak "
                    "porównania historycznego"
                }
        else:
            if cennik.producent_id is None:
                return {}, {"": "Cennik nie ma przypisanego producenta"}
            aktualny = next(
                (c for c in self.lista() if c.producent_id == cennik.producent_id and c.aktualny),
                None,
            )
            if aktualny is None:
                return {}, {
                    "": "Nie wybrano bazowego cennika. Wybierz cennik i Więcej → Ustaw jako bazowy."
                }
        grupy: dict[str, set[tuple[Decimal, str, str]]] = {}
        braki: dict[str, str] = {}
        for p in self.magazyn.pozycje(aktualny.id, aktualny.wersja):
            sku = p.dane.sku.strip().casefold()
            if not sku:
                continue
            try:
                cena = p.cena.sprawdz() if p.cena else None
            except ValueError:
                cena = None
            if cena is None or p.powod:
                braki[sku] = "Brak poprawnej ceny bazowej w aktualnym cenniku"
            else:
                grupy.setdefault(sku, set()).add((cena.kwota, cena.waluta, cena.rodzaj))
        ceny = {}
        for sku, wartosci in grupy.items():
            if len(wartosci) != 1:
                braki[sku] = (
                    "Niejednoznaczna cena bazowa: różne kwoty dla tego SKU w aktualnym cenniku"
                )
            if sku not in braki:
                kwota, waluta, rodzaj = next(iter(wartosci))
                ceny[sku] = CenaSugerowanaDTO(
                    format(kwota, "f"),
                    waluta,
                    rodzaj,
                    f"{aktualny.nazwa} • {aktualny.rok} • {aktualny.wydanie}",
                )
        return ceny, braki

    def oznacz(self, cennik: CennikDTO, aktualny: bool, oczekiwane: tuple[CennikDTO, ...]) -> Path:
        if cennik.producent_id is None:
            raise blad(
                "Przypisz producenta podczas dodawania cennika, aby oznaczyć go jako aktualny."
            )
        zakres = tuple(
            (c.id, c.wersja) for c in oczekiwane if c.producent_id == cennik.producent_id
        )
        if (cennik.id, cennik.wersja) not in zakres:
            raise blad("Odśwież listę cenników przed zmianą statusu.")
        return self.magazyn.oznacz(cennik, aktualny, zakres)

    def dodaj(self, cennik: CennikDTO, indeksy: frozenset[int]) -> WynikCennika:
        rows = self.magazyn.pozycje(cennik.id, cennik.wersja)
        if not indeksy or not indeksy <= set(range(len(rows))):
            raise blad("Zaznacz pozycje cennika do dodania.")
        znane = {p.klucz_sku for p in self.importer.katalog.wyszukaj("")}
        pominiete = sum(rows[i].dane.sku.strip().casefold() in znane for i in indeksy)
        paczka = uuid4()
        nowe = tuple(
            replace(
                rows[i],
                id=uuid4(),
                paczka=paczka,
                zrodlo=f"{cennik.nazwa} ({cennik.rok}) • {cennik.zrodlo}",
            )
            for i in sorted(indeksy)
            if rows[i].dane.sku.strip().casefold() not in znane
        )
        oceny = self.importer.ocen(nowe)
        with _mapuj_bledy():
            return self.magazyn.dodaj_pozycje(cennik, oceny, pominiete)

    def usun(self, cenniki: tuple[CennikDTO, ...]) -> Path:
        if not cenniki or len({c.id for c in cenniki}) != len(cenniki):
            raise blad("Zaznacz cenniki do usunięcia.")
        return self.magazyn.usun(tuple((c.id, c.wersja) for c in cenniki))


def _kwota(kwota: Decimal, *, znak: bool = False) -> str:
    tekst = format(kwota, "f")
    if "." in tekst:
        a, b = tekst.split(".")
        tekst = a + "." + b.rstrip("0").ljust(2, "0")
    else:
        tekst += ".00"
    return (("+" if znak and kwota > 0 else "") + tekst).replace(".", ",")


def porownaj(pozycja: PozycjaImportu, bazowa: CenaSugerowanaDTO | None) -> tuple[str, str, bool]:
    if pozycja.cena is None or not pozycja.cena.tekst.strip():
        return "—", "Brak ceny w cenniku", False
    try:
        cena = pozycja.cena.sprawdz()
    except ValueError:
        return "—", "Nieprawidłowa cena cennika", False
    if cena is None or bazowa is None:
        return "—", "Brak ceny bazowej w katalogu", False
    if cena.waluta != bazowa.waluta:
        return "—", "Różne waluty — bez przeliczania", False
    if cena.rodzaj != bazowa.rodzaj:
        return "—", "Różne netto/brutto — bez przeliczania", False
    baza = Decimal(bazowa.kwota)
    delta = cena.kwota - baza
    procent = (
        _kwota((delta / baza * 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), znak=True)
        + "%"
        if baza
        else "procent nieokreślony — bazowa 0"
    )
    return (
        f"{_kwota(delta, znak=True)} {cena.waluta} ({procent})",
        "Cena cennika minus zapisana cena bazowa",
        delta != 0,
    )
