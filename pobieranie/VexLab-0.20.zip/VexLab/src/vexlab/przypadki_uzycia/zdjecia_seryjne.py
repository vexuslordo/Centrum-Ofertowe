"""Zdjęcie po SKU, jeden produkt naraz, z limitem danych i anulowaniem."""

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import ProduktDTO
from vexlab.przypadki_uzycia.media import PobierzZdjecia, ZdjecieDane, strona_zdjec
from vexlab.rdzen.kontrakty import BladTechniczny


class SesjaZdjec(Protocol):
    kopia: Path | None

    def zapisz(self, produkt: ProduktDTO, zdjecie: ZdjecieDane) -> bool: ...


class MagazynZdjecSeryjnych(Protocol):
    def nowa_sesja(self) -> SesjaZdjec: ...


@dataclass(frozen=True)
class WynikZdjecSeryjnych:
    zapisane: int
    pominiete: int
    nieudane: int
    bledy: tuple[tuple[str, str], ...]
    bajty: int
    powod_zatrzymania: str
    kopia: Path | None


class PobierzZdjeciaSeryjnie:
    def __init__(self, media: PobierzZdjecia, magazyn: MagazynZdjecSeryjnych) -> None:
        self.media, self.magazyn = media, magazyn

    def wykonaj(
        self,
        produkty: tuple[ProduktDTO, ...],
        strona: str,
        limit_mb: int,
        anulowano: Callable[[], bool],
        postep: Callable[[int, int, str], None],
    ) -> WynikZdjecSeryjnych:
        strona = strona_zdjec(strona)
        if (
            not produkty
            or len({p.id for p in produkty}) != len(produkty)
            or not 1 <= limit_mb <= 4096
        ):
            raise BladScenariuszaKatalogu(
                "MEDIA", "Wybierz produkty i limit nowych danych zdjęć (1–4096 MB)."
            )
        sesja = self.magazyn.nowa_sesja()
        zapisane = pominiete = nieudane = bajty = seria_bledow = 0
        bledy: list[tuple[str, str]] = []
        powod = ""
        for i, p in enumerate(produkty, 1):
            if anulowano():
                powod = "Anulowano. Zakończone zapisy pozostają."
                break
            if p.miniatura:
                pominiete += 1
                postep(i, len(produkty), f"{p.sku}: już ma zdjęcie")
                continue
            try:
                wynik = self.media.wykonaj_pierwsze(strona, p.sku)
                if anulowano():
                    powod = "Anulowano. Zakończone zapisy pozostają."
                    break
                if not wynik.zdjecia:
                    raise BladScenariuszaKatalogu("MEDIA", "Źródło nie udostępniło zdjęcia.")
                zdjecie = wynik.zdjecia[0]
                rozmiar = len(zdjecie.dane) + len(zdjecie.miniatura)
                if bajty + rozmiar > limit_mb * 1024 * 1024:
                    powod = "Osiągnięto limit nowych danych zdjęć. Zakończone zapisy pozostają."
                    break
                if sesja.zapisz(p, zdjecie):
                    zapisane += 1
                    bajty += rozmiar
                else:
                    pominiete += 1
                seria_bledow = 0
                postep(i, len(produkty), f"{p.sku}: gotowe")
            except (BladScenariuszaKatalogu, BladTechniczny) as exc:
                nieudane += 1
                seria_bledow += 1
                if len(bledy) < 10:
                    bledy.append((p.sku, str(exc)))
                postep(i, len(produkty), f"{p.sku}: nie udało się pobrać lub zapisać")
                if seria_bledow >= 3:
                    powod = (
                        "Przerwano po 3 kolejnych błędach. Sprawdź źródło i SKU przed ponowieniem."
                    )
                    break
        return WynikZdjecSeryjnych(
            zapisane, pominiete, nieudane, tuple(bledy), bajty, powod, sesja.kopia
        )
