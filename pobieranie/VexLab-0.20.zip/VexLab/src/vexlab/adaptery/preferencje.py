"""Techniczne ustawienia Qt poza repozytorium; żadnych danych biznesowych."""

import getpass
import json

from PySide6.QtCore import QSettings

from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.media import strona_zdjec
from vexlab.przypadki_uzycia.powloka import Motyw, PreferencjePowloki
from vexlab.przypadki_uzycia.szybkie_akcje import sprawdz_akcje
from vexlab.rdzen.kontrakty import BladTechniczny


class PreferencjeQt:
    def __init__(self, ustawienia: QSettings) -> None:
        self._ustawienia = ustawienia

    def odczytaj(self) -> PreferencjePowloki:
        self._ustawienia.sync()
        self._sprawdz_status()
        try:
            motyw = Motyw(str(self._ustawienia.value("wyglad/motyw", Motyw.CIEMNY.value)))
        except ValueError:
            motyw = Motyw.CIEMNY
        zwiniete = bool(self._ustawienia.value("wyglad/menu_zwiniete", False, type=bool))
        akcje = None
        tekst = self._ustawienia.value("dashboard/szybkie_akcje", None)
        if isinstance(tekst, str) and len(tekst) <= 4096:
            try:
                wartosci = json.loads(tekst)
                if not isinstance(wartosci, list) or any(not isinstance(x, str) for x in wartosci):
                    raise ValueError("Format")
                sprawdz_akcje(tuple(wartosci))
                akcje = tuple(wartosci)
            except (ValueError, TypeError):
                akcje = None
        strona = str(self._ustawienia.value("media/strona", ""))
        try:
            strona = strona_zdjec(strona) if strona else ""
            limit = int(str(self._ustawienia.value("media/limit_mb", 256)))
            if not 1 <= limit <= 4096:
                raise ValueError("Limit")
        except (ValueError, BladScenariuszaKatalogu):
            strona, limit = "", 256
        return PreferencjePowloki(motyw, zwiniete, akcje, strona, limit)

    def zapisz(self, preferencje: PreferencjePowloki) -> None:
        if preferencje.szybkie_akcje is not None:
            sprawdz_akcje(preferencje.szybkie_akcje)
        self._ustawienia.setValue("media/strona", preferencje.strona_zdjec)
        self._ustawienia.setValue("media/limit_mb", preferencje.limit_zdjec_mb)
        self._ustawienia.setValue("wyglad/motyw", preferencje.motyw.value)
        self._ustawienia.setValue("wyglad/menu_zwiniete", preferencje.menu_zwiniete)
        if preferencje.szybkie_akcje is None:
            self._ustawienia.remove("dashboard/szybkie_akcje")
        else:
            sprawdz_akcje(preferencje.szybkie_akcje)
            self._ustawienia.setValue(
                "dashboard/szybkie_akcje", json.dumps(preferencje.szybkie_akcje)
            )
        self._ustawienia.sync()
        self._sprawdz_status()

    def _sprawdz_status(self) -> None:
        if self._ustawienia.status() != QSettings.Status.NoError:
            raise BladTechniczny("Nie można odczytać lub zapisać ustawień wyglądu.")


def nazwa_uzytkownika_systemu() -> str:
    try:
        return getpass.getuser()
    except (OSError, KeyError) as blad:
        raise BladTechniczny("Nie można odczytać nazwy użytkownika systemu.") from blad
