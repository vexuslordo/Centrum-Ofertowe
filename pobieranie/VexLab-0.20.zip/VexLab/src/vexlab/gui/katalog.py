"""Tabela i formularz lokalnego Produktu; GUI korzysta wyłącznie z DTO."""

from collections import Counter
from uuid import UUID

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QPersistentModelIndex, Qt, Signal
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from vexlab.gui.dopasowania import EdytorDopasowan
from vexlab.przypadki_uzycia.katalog import DaneDopasowania, DaneProduktu, ProduktDTO
from vexlab.przypadki_uzycia.media import KandydaciZdjec, ZdjecieDane
from vexlab.przypadki_uzycia.producenci import ProducentDTO

INDEKS = QModelIndex | QPersistentModelIndex


def nazwa_wyboru_producenta(producent: ProducentDTO, nazwy: Counter[str]) -> str:
    if nazwy[producent.nazwa.casefold()] > 1:
        return f"{producent.nazwa} • {producent.id}"
    return producent.nazwa


class ModelProduktow(QAbstractTableModel):
    NAGLOWKI = (
        "Zdjęcie",
        "Nazwa produktu",
        "SKU",
        "Producent",
        "Cena",
        "Stan",
        "Allegro",
        "PrestaShop",
    )

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.produkty: list[ProduktDTO] = []

    def ustaw(self, produkty: list[ProduktDTO]) -> None:
        self.beginResetModel()
        self.produkty = produkty
        self.endResetModel()

    def rowCount(self, parent: INDEKS | None = None) -> int:
        return 0 if parent is not None and parent.isValid() else len(self.produkty)

    def columnCount(self, parent: INDEKS | None = None) -> int:
        return 0 if parent is not None and parent.isValid() else len(self.NAGLOWKI)

    def data(self, index: INDEKS, role: int = Qt.ItemDataRole.DisplayRole) -> object:
        if not index.isValid() or not 0 <= index.row() < len(self.produkty):
            return None
        produkt = self.produkty[index.row()]
        if role == Qt.ItemDataRole.DecorationRole and index.column() == 0 and produkt.miniatura:
            pixmap = QPixmap()
            if pixmap.loadFromData(produkt.miniatura):
                return QIcon(pixmap)
        if role == Qt.ItemDataRole.DisplayRole:
            return (
                "" if produkt.miniatura else "◇",
                produkt.nazwa,
                produkt.sku,
                produkt.producent_nazwa or "—",
                produkt.cena_sugerowana.etykieta if produkt.cena_sugerowana else "—",
                "—",
                "—",
                "—",
            )[index.column()]
        if role in (Qt.ItemDataRole.ToolTipRole, Qt.ItemDataRole.AccessibleTextRole):
            if index.column() == 3:
                return produkt.producent_nazwa or "Nie przypisano producenta."
            if index.column() == 4:
                cena = produkt.cena_sugerowana
                return (
                    f"Cena odniesienia z wczytanego cennika: {cena.etykieta}. Źródło: {cena.zrodlo}"
                    if cena
                    else "Brak ceny sugerowanej z cennika. "
                    "Cena gotowej oferty z ZIP nie jest kopiowana do tej kolumny."
                )
            if index.column() > 4:
                return "Funkcja niewdrożona. Brak odczytu tych danych."
            return f"{produkt.nazwa}, SKU {produkt.sku}"
        return None

    def headerData(
        self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole
    ) -> object:
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return self.NAGLOWKI[section]
        return None


class FormularzProduktu(QDialog):
    def __init__(
        self,
        producenci: list[ProducentDTO],
        produkt: ProduktDTO | None = None,
        parent: QWidget | None = None,
        obsluga_zdjec: bool = False,
    ) -> None:
        super().__init__(parent)
        self.produkt = produkt
        self.dopasowania = (
            tuple(
                DaneDopasowania(
                    d.marka,
                    d.model,
                    str(d.rok_od) if d.rok_od is not None else "",
                    str(d.rok_do) if d.rok_do is not None else "",
                    d.wariant,
                )
                for d in produkt.dopasowania
            )
            if produkt
            else ()
        )
        self.fotografie: tuple[ZdjecieDane, ...] = ()
        self.wybory_zdjec: list[QCheckBox] = []
        self.setWindowTitle("Edytuj produkt" if produkt else "Dodaj produkt")
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        opis = QLabel("Lokalny katalog • bez publikacji; ceny źródłowe wybierasz w imporcie")
        opis.setObjectName("opis")
        layout.addWidget(opis)
        pola = QFormLayout()
        self.nazwa = QLineEdit(produkt.nazwa if produkt else "")
        self.nazwa.setAccessibleName("Nazwa produktu, wymagane")
        self.sku = QLineEdit(produkt.sku if produkt else "")
        self.sku.setAccessibleName("SKU, wymagane i unikalne")
        self.ean = QLineEdit(produkt.ean if produkt else "")
        self.ean.setAccessibleName("EAN, opcjonalny")
        self.ean.setPlaceholderText("EAN-8 lub EAN-13; pozostaw puste, jeśli brak")
        self.opis = QPlainTextEdit(produkt.opis if produkt else "")
        self.opis.setAccessibleName("Opis katalogowy, opcjonalne")
        self.producent = QComboBox()
        self.producent.setAccessibleName("Producent, opcjonalny")
        self.producent.setSizeAdjustPolicy(
            QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
        )
        self.producent.setMinimumContentsLength(24)
        self.producent.addItem("Brak producenta", None)
        nazwy = Counter(p.nazwa.casefold() for p in producenci)
        for p in producenci:
            if not p.aktywny and (produkt is None or produkt.producent_id != p.id):
                continue
            nazwa = nazwa_wyboru_producenta(p, nazwy)
            if not p.aktywny:
                nazwa += " (nieaktywny — obecne przypisanie)"
            self.producent.addItem(nazwa, str(p.id))
        if produkt is not None and produkt.producent_id is not None:
            indeks = self.producent.findData(str(produkt.producent_id))
            if indeks < 0:
                self.producent.addItem(
                    "Nieodnaleziony producent — odśwież dane", str(produkt.producent_id)
                )
                indeks = self.producent.count() - 1
            self.producent.setCurrentIndex(indeks)
        pola.addRow("Nazwa *", self.nazwa)
        pola.addRow("SKU *", self.sku)
        pola.addRow("EAN", self.ean)
        pola.addRow("Producent", self.producent)
        pola.addRow("Opis", self.opis)
        layout.addLayout(pola)
        self.dopasowania_przycisk = QPushButton("Pasuje do motocykli… (opcjonalne)")
        self.dopasowania_przycisk.clicked.connect(self.edytuj_dopasowania)
        layout.addWidget(self.dopasowania_przycisk)
        self.info_dopasowan = QLabel()
        self.info_dopasowan.setWordWrap(True)
        layout.addWidget(self.info_dopasowan)
        self._opis_dopasowan()
        if obsluga_zdjec:
            self.strona_www = QLineEdit()
            self.strona_www.setPlaceholderText("Adres HTTPS producenta — publiczny katalog Shopify")
            self.strona_www.setAccessibleName("Adres źródła zdjęć wpisywany przez użytkownika")
            self.pobierz_zdjecia = QPushButton("Pobierz kandydatów zdjęć po SKU")
            self.info_zdjec = QLabel(
                "Pobranie nie zapisuje zdjęć. Nowy wybór zastąpi obecne zdjęcia; "
                "brak wyboru je zachowa."
            )
            self.info_zdjec.setTextFormat(Qt.TextFormat.PlainText)
            self.info_zdjec.setWordWrap(True)
            layout.addWidget(self.strona_www)
            layout.addWidget(self.pobierz_zdjecia)
            layout.addWidget(self.info_zdjec)
            self.obszar_zdjec = QWidget()
            self.lista_zdjec = QVBoxLayout(self.obszar_zdjec)
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setMaximumHeight(160)
            scroll.setMinimumHeight(70)
            scroll.setWidget(self.obszar_zdjec)
            layout.addWidget(scroll)
            adresy = {str(p.id): p.strona_www for p in producenci}

            def adres_producenta() -> None:
                self.strona_www.setText(adresy.get(str(self.producent.currentData()), ""))

            self.producent.currentIndexChanged.connect(adres_producenta)
            adres_producenta()
            self.sku.textChanged.connect(self._uniewaznij_zdjecia)
            self.strona_www.textChanged.connect(self._uniewaznij_zdjecia)
        self.blad = QLabel()
        self.blad.setObjectName("ostrzezenie")
        self.blad.setWordWrap(True)
        self.blad.setAccessibleName("Błąd zapisu produktu")
        layout.addWidget(self.blad)
        self.przyciski = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        self.zapisz = self.przyciski.button(QDialogButtonBox.StandardButton.Save)
        self.zapisz.setText("Zapisz lokalnie")
        self.zapisz.setObjectName("primary")
        self.przyciski.button(QDialogButtonBox.StandardButton.Cancel).setText("Anuluj")
        self.przyciski.rejected.connect(self.reject)
        layout.addWidget(self.przyciski)
        self.nazwa.setFocus()

    def edytuj_dopasowania(self) -> None:
        dialog = EdytorDopasowan(self.dopasowania, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.dopasowania = dialog.dane()
            self._opis_dopasowan()

    def _opis_dopasowan(self) -> None:
        ile = sum(
            bool(
                d.marka.strip()
                or d.model.strip()
                or d.rok_od.strip()
                or d.rok_do.strip()
                or d.wariant.strip()
            )
            for d in self.dopasowania
        )
        self.info_dopasowan.setText(
            f"Dopasowania w formularzu: {ile}. Zapisz Produkt, aby je zachować."
            if ile
            else "Brak zapisanych dopasowań — nie oznacza uniwersalności produktu."
        )

    def dane(self) -> DaneProduktu:
        producent = self.producent.currentData()
        return DaneProduktu(
            self.nazwa.text(),
            self.sku.text(),
            self.opis.toPlainText(),
            UUID(producent) if producent else None,
            self.dopasowania,
            self.ean.text().strip(),
        )

    def ustaw_zapis(self, trwa: bool) -> None:
        self.dopasowania_przycisk.setEnabled(not trwa)
        self.nazwa.setEnabled(not trwa)
        self.sku.setEnabled(not trwa)
        self.ean.setEnabled(not trwa)
        self.opis.setEnabled(not trwa)
        self.producent.setEnabled(not trwa)
        self.przyciski.setEnabled(not trwa)
        if hasattr(self, "strona_www"):
            self.strona_www.setEnabled(not trwa)
            self.pobierz_zdjecia.setEnabled(not trwa)
            self.obszar_zdjec.setEnabled(not trwa)
        self.zapisz.setText("Zapisywanie…" if trwa else "Zapisz lokalnie")

    def pokaz_blad(self, kod: str, komunikat: str) -> None:
        self.ustaw_zapis(False)
        self.blad.setText(komunikat)
        if kod == "WALIDACJA_DOPASOWANIA":
            self.dopasowania_przycisk.setFocus()
        elif kod == "WALIDACJA_EAN":
            self.ean.setFocus()
        elif kod in {"SKU_ZAJETE", "WALIDACJA_SKU"}:
            self.sku.setFocus()
        elif kod in {"PRODUCENT_NIE_ISTNIEJE", "PRODUCENT_NIEAKTYWNY"}:
            self.producent.setFocus()
        else:
            self.nazwa.setFocus()

    def reject(self) -> None:
        if self.zapisz.isEnabled():
            super().reject()

    def _uniewaznij_zdjecia(self) -> None:
        self.fotografie = ()
        self.wybory_zdjec = []
        while self.lista_zdjec.count():
            item = self.lista_zdjec.takeAt(0)
            widget = item.widget() if item is not None else None
            if widget is not None:
                widget.deleteLater()
        self.info_zdjec.setText("SKU lub źródło zmienione. Pobierz kandydatów zdjęć ponownie.")

    def ustaw_zdjecia(self, wynik: KandydaciZdjec) -> None:
        self.fotografie = wynik.zdjecia
        while self.lista_zdjec.count():
            item = self.lista_zdjec.takeAt(0)
            widget = item.widget() if item is not None else None
            if widget is not None:
                widget.deleteLater()
        self.wybory_zdjec = []
        for i, z in enumerate(wynik.zdjecia):
            w = QWidget()
            row = QHBoxLayout(w)
            wybor = QCheckBox(f"Zapisz zdjęcie {i + 1}")
            wybor.setAccessibleName(f"Wybierz zdjęcie {i + 1} ze źródła")
            img = QLabel()
            pix = QPixmap()
            pix.loadFromData(z.miniatura)
            img.setPixmap(pix)
            row.addWidget(wybor)
            row.addWidget(img)
            row.addStretch()
            self.lista_zdjec.addWidget(w)
            self.wybory_zdjec.append(wybor)
        self.info_zdjec.setText(
            f"SKU: {wynik.sku}. {wynik.tytul}\n{wynik.strona_produktu}\n"
            "Sprawdź wariant i zaznacz właściwe zdjęcia. "
            "Nowy wybór zastąpi obecne zdjęcia przy zapisie."
        )

    def wybrane_zdjecia(self) -> tuple[ZdjecieDane, ...]:
        return tuple(
            z for z, w in zip(self.fotografie, self.wybory_zdjec, strict=True) if w.isChecked()
        )


class SzczegolyProduktu(QDialog):
    edytuj = Signal(object)

    def __init__(self, produkt: ProduktDTO, parent: QWidget) -> None:
        super().__init__(parent)
        self.produkt = produkt
        self.setWindowTitle("Szczegóły produktu")
        self.setMinimumWidth(520)
        layout = QVBoxLayout(self)
        informacja = QLabel("Podgląd ostatniego odczytu katalogu. Dane nie są tutaj zmieniane.")
        informacja.setObjectName("opis")
        informacja.setWordWrap(True)
        layout.addWidget(informacja)
        pola = QFormLayout()
        self.nazwa = QLineEdit(produkt.nazwa)
        self.sku = QLineEdit(produkt.sku)
        self.ean = QLineEdit(produkt.ean)
        self.producent = QLineEdit(produkt.producent_nazwa or "Nie przypisano")
        for pole, nazwa in (
            (self.nazwa, "Nazwa produktu"),
            (self.sku, "SKU produktu"),
            (self.ean, "EAN produktu"),
            (self.producent, "Producent produktu"),
        ):
            pole.setReadOnly(True)
            pole.setAccessibleName(nazwa)
        self.opis = QPlainTextEdit(produkt.opis)
        self.opis.setReadOnly(True)
        self.opis.setAccessibleName("Pełny opis katalogowy")
        if produkt.miniatura:
            img = QLabel()
            pix = QPixmap()
            if pix.loadFromData(produkt.miniatura):
                img.setPixmap(pix)
                layout.addWidget(img)
        pola.addRow("Nazwa", self.nazwa)
        pola.addRow("SKU", self.sku)
        pola.addRow("EAN", self.ean)
        pola.addRow("Producent", self.producent)
        pola.addRow("Opis", self.opis)
        cena = produkt.cena_sugerowana
        self.cena = QLineEdit(cena.etykieta if cena else "Brak ceny źródłowej")
        self.cena.setReadOnly(True)
        self.cena.setAccessibleName("Sugerowana cena sprzedaży z walutą i netto/brutto")
        self.dopasowania_podglad = QPlainTextEdit(
            "\n".join(d.etykieta for d in produkt.dopasowania)
            or "Brak zapisanych dopasowań (nie oznacza uniwersalności)."
        )
        self.dopasowania_podglad.setReadOnly(True)
        self.dopasowania_podglad.setMaximumHeight(120)
        self.dopasowania_podglad.setAccessibleName("Dopasowania do motocykli")
        pola.addRow("Pasuje do motocykli", self.dopasowania_podglad)
        pola.addRow("Cena sugerowana", self.cena)
        self.zrodlo_ceny = QLineEdit(cena.zrodlo if cena else "")
        self.zrodlo_ceny.setReadOnly(True)
        pola.addRow("Źródło ceny", self.zrodlo_ceny)
        layout.addLayout(pola)
        self.przyciski = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        self.przyciski.button(QDialogButtonBox.StandardButton.Close).setText("Zamknij")
        self.przyciski.rejected.connect(self.reject)
        self.przycisk_edycji = QPushButton("Edytuj produkt…")
        self.przyciski.addButton(self.przycisk_edycji, QDialogButtonBox.ButtonRole.ActionRole)
        self.przycisk_edycji.clicked.connect(self._edytuj)
        layout.addWidget(self.przyciski)

    def _edytuj(self) -> None:
        self.accept()
        self.edytuj.emit(self.produkt)
