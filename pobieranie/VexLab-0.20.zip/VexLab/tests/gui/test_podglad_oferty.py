from dataclasses import replace

from PySide6.QtCore import QBuffer, QIODevice, Qt
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QLineEdit

from vexlab.gui.edytor_opisu import EdytorOpisu
from vexlab.gui.podglad_oferty import ObrazPodgladu, TekstSekcji
from vexlab.przypadki_uzycia.media import ZdjecieDane
from vexlab.przypadki_uzycia.paczki_ofert import ElementPodgladu, OfertaPodglad
from vexlab.przypadki_uzycia.podglad_zdjec import PodgladZdjec


def png():
    image = QImage(100, 50, QImage.Format.Format_RGB32)
    image.fill(Qt.GlobalColor.blue)
    out = QBuffer()
    out.open(QIODevice.OpenModeFlag.WriteOnly)
    assert image.save(out, "PNG")
    return bytes(out.data())


def oferta():
    return OfertaPodglad(
        1,
        "SKU",
        "Tytuł",
        "<p>Opis</p>",
        "",
        "",
        "",
        ("https://example.test/a.png",),
        (
            (
                ElementPodgladu("obraz", adres="https://example.test/a.png"),
                ElementPodgladu("tekst", "<h2>Opis sekcji</h2><p>Treść</p>"),
            ),
        ),
        (),
    )


def test_zdjecia_w_edytorze_i_pelny_uklad_bez_zmiany_szkicu(qtbot):
    wywolania = []

    class Zrodlo:
        def pobierz_obraz(self, url):
            wywolania.append(url)
            return ZdjecieDane(url, png(), png())

    def uruchom(fn, ok, blad):
        ok(fn())

    d = oferta()
    e = EdytorOpisu(d, zdjecia=PodgladZdjec(Zrodlo()), uruchom=uruchom)
    qtbot.addWidget(e)
    e.resize(1100, 700)
    e.show()
    qtbot.waitUntil(lambda: len(wywolania) == 1)
    assert not e.findChild(ObrazPodgladu).obraz.isNull()
    e.tabs.setCurrentIndex(2)
    qtbot.waitUntil(lambda: not e.obrazy.trwa)
    assert len(wywolania) == 1
    assert all(not img.obraz.isNull() for img in e.pelna_oferta.findChildren(ObrazPodgladu))
    assert "Opis sekcji" in e.pelna_oferta.findChild(TekstSekcji).toPlainText()
    assert e.opis() == d.opis and e.wynik_sekcji() == d.sekcje and not e.zmieniony
    e.findChild(QLineEdit).setText("https://example.test/b.png")
    e.findChild(QLineEdit).editingFinished.emit()
    qtbot.waitUntil(lambda: len(wywolania) == 2)


def test_blad_pobierania_i_zamkniecie_podczas_odczytu(qtbot):
    zadania = []

    def uruchom(fn, ok, blad):
        zadania.append((fn, ok, blad))

    class Zrodlo:
        def pobierz_obraz(self, url):
            return ZdjecieDane(url, png(), png())

    e = EdytorOpisu(oferta(), zdjecia=PodgladZdjec(Zrodlo()), uruchom=uruchom)
    qtbot.addWidget(e)
    e.show()
    qtbot.waitUntil(lambda: bool(zadania))
    zadania[0][2]("MEDIA", "Brak sieci")
    assert "Nie udało" in e.findChild(ObrazPodgladu).text()
    assert not e.zmieniony
    f = EdytorOpisu(replace(oferta(), zdjecia=()), zdjecia=PodgladZdjec(Zrodlo()), uruchom=uruchom)
    f.show()
    qtbot.waitUntil(lambda: len(zadania) == 2)
    f.deleteLater()
    qtbot.wait(10)
    zadania[1][1](ZdjecieDane("url", png(), png()))
