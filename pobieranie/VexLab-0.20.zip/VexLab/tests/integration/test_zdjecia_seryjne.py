import shutil
from threading import Event

import pytest

from vexlab.adaptery.katalog_sqlite import KatalogSQLite
from vexlab.adaptery.zdjecia_seryjne_sqlite import MagazynZdjecSeryjnychSQLite
from vexlab.przypadki_uzycia.bledy import BladScenariuszaKatalogu
from vexlab.przypadki_uzycia.katalog import DaneProduktu, KatalogProduktow
from vexlab.przypadki_uzycia.media import KandydaciZdjec, PobierzZdjecia, ZdjecieDane
from vexlab.przypadki_uzycia.zdjecia_seryjne import PobierzZdjeciaSeryjnie


class Zrodlo:
    def __init__(self, rozmiar=100):
        self.wywolania = []
        self.rozmiar = rozmiar
        self.blad = False

    def pobierz(self, strona, sku, limit=5):
        self.wywolania.append((strona, sku, limit))
        if self.blad:
            raise BladScenariuszaKatalogu("MEDIA", "Brak odpowiedzi źródła")
        return KandydaciZdjec(
            strona, "Nazwa", sku, (ZdjecieDane(strona + "/" + sku, b"x" * self.rozmiar, b"thumb"),)
        )


@pytest.fixture
def uslugi(tmp_path):
    repo = KatalogSQLite(tmp_path / "test.sqlite3")
    kat = KatalogProduktow(repo, repo)
    for sku in ("A", "B", "C", "D"):
        kat.dodaj(DaneProduktu(sku, sku))
    z = Zrodlo()
    s = PobierzZdjeciaSeryjnie(PobierzZdjecia(z), MagazynZdjecSeryjnychSQLite(repo.plik))
    return kat, repo, z, s


def test_jedno_zdjecie_jedna_kopia_bez_nadpisania_i_odtworzenie(uslugi, tmp_path):
    kat, repo, z, s = uslugi
    p = kat.wyszukaj()[-1]
    kat.edytuj(
        p.id,
        p.wersja,
        DaneProduktu(p.nazwa, p.sku),
        (ZdjecieDane("https://example.test/old", b"old", b"oldthumb"),),
    )
    before = kat.wyszukaj()
    w = s.wykonaj(tuple(before), "https://example.test", 1, lambda: False, lambda *a: None)
    assert (w.zapisane, w.pominiete, w.nieudane) == (3, 1, 0)
    assert len(z.wywolania) == 3 and all(x[2] == 1 for x in z.wywolania)
    assert len(list((tmp_path / "kopie_zdjec_seryjnych").glob("*.sqlite3"))) == 1
    assert repo.odczytaj_galerie(p.id).zdjecia[0].dane == b"old"
    restore = tmp_path / "restore.sqlite3"
    shutil.copyfile(w.kopia, restore)
    r = KatalogSQLite(restore)
    assert sum(bool(p.miniatura) for p in KatalogProduktow(r, r).wyszukaj()) == 1


def test_limit_danych_i_anulowanie_sa_respektowane(uslugi):
    kat, repo, z, s = uslugi
    z.rozmiar = 600_000
    w = s.wykonaj(tuple(kat.wyszukaj()), "https://example.test", 1, lambda: False, lambda *a: None)
    assert w.zapisane == 1 and "limit" in w.powod_zatrzymania
    assert len(z.wywolania) == 2
    stop = Event()
    z.wywolania.clear()
    z.rozmiar = 100

    def postep(i, total, tekst):
        if "gotowe" in tekst:
            stop.set()

    w = s.wykonaj(tuple(kat.wyszukaj()), "https://example.test", 1, stop.is_set, postep)
    assert w.zapisane == 1 and "Anulowano" in w.powod_zatrzymania
    assert len(z.wywolania) == 1


def test_trzy_bledy_zatrzymuja_serie_bez_zmian(uslugi):
    kat, repo, z, s = uslugi
    z.blad = True
    w = s.wykonaj(tuple(kat.wyszukaj()), "https://example.test", 1, lambda: False, lambda *a: None)
    assert w.nieudane == 3 and not w.kopia and w.zapisane == 0
    assert len(z.wywolania) == 3 and "3 kolejnych" in w.powod_zatrzymania
    assert not any(p.miniatura for p in kat.wyszukaj())


def test_konflikt_i_brak_kopii_nie_nadpisuja_produktu(uslugi, tmp_path):
    kat, repo, z, s = uslugi
    snapshot = tuple(kat.wyszukaj())
    kat.edytuj(snapshot[0].id, snapshot[0].wersja, DaneProduktu("Zmieniony", snapshot[0].sku))
    w = s.wykonaj(snapshot[:1], "https://example.test", 1, lambda: False, lambda *a: None)
    assert w.nieudane == 1 and w.kopia is None
    (tmp_path / "kopie_zdjec_seryjnych").write_text("blokada")
    w = s.wykonaj(tuple(kat.wyszukaj()), "https://example.test", 1, lambda: False, lambda *a: None)
    assert w.nieudane == 3 and not any(p.miniatura for p in kat.wyszukaj())


@pytest.mark.parametrize(
    "url",
    [
        "file:///test",
        "http://example.test",
        "https://127.0.0.1",
        "https://user:pass@example.test",
        "https://example.test/?token=x",
    ],
)
def test_niepoprawne_zrodla_odrzucone_przed_zapytaniami(uslugi, url):
    kat, repo, z, s = uslugi
    with pytest.raises(BladScenariuszaKatalogu):
        s.wykonaj(tuple(kat.wyszukaj()), url, 1, lambda: False, lambda *a: None)
    assert not z.wywolania
