"""Skróty producentów, wyszukiwanie i jawne filtry wspólnego katalogu."""

from collections import Counter

from PySide6.QtCore import QEvent, QSize, Qt, Signal
from PySide6.QtGui import QPalette, QResizeEvent
from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QComboBox,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QLayout,
    QLineEdit,
    QMenu,
    QPushButton,
    QScrollArea,
    QToolButton,
    QVBoxLayout,
    QWidget,
    QWidgetAction,
)

from vexlab.gui.design_system import ikona
from vexlab.gui.katalog import nazwa_wyboru_producenta
from vexlab.przypadki_uzycia.producenci import ProducentDTO


class FiltryKatalogu(QWidget):
    producent = Signal(str)
    fraza = Signal(str)
    filtry = Signal(object, object)
    reset = Signal()
    tryb = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self.wariant_ukladu = -1
        self.producenci: tuple[ProducentDTO, ...] = ()
        self.uklad = QGridLayout(self)
        self.uklad.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.uklad.setContentsMargins(0, 0, 0, 0)
        self.uklad.setSpacing(8)
        self.producenci_scroll = QScrollArea()
        self.producenci_scroll.setObjectName("przewijanieProducentow")
        self.producenci_scroll.setWidgetResizable(True)
        self.producenci_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.producenci_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.producenci_scroll.setFixedHeight(44)
        brands = QWidget()
        brands.setObjectName("filtryProducentow")
        chips = QHBoxLayout(brands)
        chips.setContentsMargins(0, 0, 0, 0)
        chips.setSpacing(6)
        self.grupa = QButtonGroup(self)
        self.przyciski: dict[str, QPushButton] = {}
        self.chips = chips
        wszystkie = QPushButton("Wszystkie")
        wszystkie.setProperty("chipProducenta", True)
        wszystkie.setCheckable(True)
        wszystkie.setAccessibleName("Wszyscy producenci")
        self.grupa.addButton(wszystkie)
        self.przyciski["wszyscy"] = wszystkie
        chips.addWidget(wszystkie)
        wszystkie.clicked.connect(lambda: self.producent.emit("wszyscy"))
        self.wiecej = QToolButton()
        self.wiecej.setObjectName("menuAkcji")
        self.wiecej.setText("Więcej")
        self.wiecej.setAccessibleName("Pozostali producenci")
        self.wiecej.setCheckable(True)
        self.wiecej.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.menu_producentow = QMenu(self.wiecej)
        self.wiecej.setMenu(self.menu_producentow)
        chips.addWidget(self.wiecej)
        chips.addStretch()
        self.producenci_scroll.setWidget(brands)
        self.narzedzia = QWidget()
        tools = QHBoxLayout(self.narzedzia)
        tools.setContentsMargins(0, 0, 0, 0)
        tools.setSpacing(6)
        self.szukaj = QLineEdit()
        self.szukaj.setPlaceholderText("Szukaj…")
        self.szukaj.setAccessibleName("Szukaj produktów po nazwie, SKU lub EAN")
        self.szukaj.setClearButtonEnabled(True)
        self.szukaj.setFixedSize(186, 36)
        self.szukaj.textChanged.connect(self.fraza.emit)
        tools.addWidget(self.szukaj, 1)
        self.przycisk_filtrow = QToolButton()
        self.przycisk_filtrow.setCheckable(True)
        self.przycisk_filtrow.setAccessibleName("Dodatkowe filtry katalogu")
        self.przycisk_filtrow.setToolTip("Filtruj po zdjęciu i cenie")
        self.przycisk_filtrow.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.menu_filtrow = QMenu(self.przycisk_filtrow)
        self.przycisk_filtrow.setMenu(self.menu_filtrow)
        form_widget = QWidget()
        form_layout = QVBoxLayout(form_widget)
        form = QFormLayout()
        self.zdjecia = QComboBox()
        self.cena = QComboBox()
        for combo, opis in ((self.zdjecia, "zdjęcia"), (self.cena, "ceny")):
            for text, value in (("Wszystkie", None), (f"Z {opis}", True), (f"Bez {opis}", False)):
                combo.addItem(text, value)
        self.zdjecia.setItemText(1, "Ze zdjęciem")
        self.zdjecia.setItemText(2, "Bez zdjęcia")
        self.cena.setItemText(1, "Z ceną")
        self.cena.setItemText(2, "Bez ceny")
        form.addRow("Zdjęcia", self.zdjecia)
        form.addRow("Cena", self.cena)
        form_layout.addLayout(form)
        apply = QPushButton("Zastosuj")
        apply.setObjectName("primary")
        apply.clicked.connect(self._zastosuj)
        form_layout.addWidget(apply)
        a = QWidgetAction(self.menu_filtrow)
        a.setDefaultWidget(form_widget)
        self.menu_filtrow.addAction(a)
        self.menu_filtrow.addAction("Wyczyść wszystkie filtry", self.reset.emit)
        tools.addWidget(self.przycisk_filtrow)
        self.przycisk_filtrow.setFixedSize(36, 36)
        self.tryby = QButtonGroup(self)
        self.kafelki = QToolButton()
        self.lista = QToolButton()
        for przelacznik, nazwa in ((self.kafelki, "kafelki"), (self.lista, "lista")):
            przelacznik.setCheckable(True)
            przelacznik.setFixedSize(36, 36)
            przelacznik.setAccessibleName(f"Widok: {nazwa}")
            przelacznik.setToolTip(f"Widok: {nazwa}")
            self.tryby.addButton(przelacznik)
            przelacznik.clicked.connect(lambda checked=False, n=nazwa: self.tryb.emit(n))
            tools.addWidget(przelacznik)
        self.lista.setChecked(True)
        self._ikony()
        self.ustaw((), "wszyscy", "", None, None)
        self._rozmiesc()

    def _ikony(self) -> None:
        dark = QApplication.palette().color(QPalette.ColorRole.Window).lightness() < 128
        kolor = "#B7C9E0" if dark else "#355273"
        for b, n in (
            (self.przycisk_filtrow, "filtr"),
            (self.kafelki, "widok_kafelki"),
            (self.lista, "widok_lista"),
        ):
            b.setIcon(ikona(n, kolor))
            b.setIconSize(QSize(18, 18))
        if not hasattr(self, "ikona_szukania"):
            self.ikona_szukania = self.szukaj.addAction(
                ikona("szukaj", kolor), QLineEdit.ActionPosition.LeadingPosition
            )
        else:
            self.ikona_szukania.setIcon(ikona("szukaj", kolor))

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() in (
            QEvent.Type.PaletteChange,
            QEvent.Type.ApplicationPaletteChange,
        ) and hasattr(self, "lista"):
            self._ikony()

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        self._rozmiesc()

    def _rozmiesc(self) -> None:
        wariant = int(self.width() >= 500)
        miejsce = self.width() - self.narzedzia.sizeHint().width() - 8 if wariant else self.width()
        self.producenci_scroll.setFixedWidth(max(100, min(self.chips.sizeHint().width(), miejsce)))
        if wariant == self.wariant_ukladu:
            return
        self.wariant_ukladu = wariant
        self.uklad.removeWidget(self.producenci_scroll)
        self.uklad.removeWidget(self.narzedzia)
        if wariant:
            self.uklad.addWidget(self.producenci_scroll, 0, 0, Qt.AlignmentFlag.AlignVCenter)
            self.uklad.addWidget(self.narzedzia, 0, 1, Qt.AlignmentFlag.AlignLeft)
        else:
            self.uklad.addWidget(self.producenci_scroll, 0, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
            self.uklad.addWidget(self.narzedzia, 1, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        self.uklad.setColumnStretch(0, 0)
        self.uklad.setColumnStretch(1, 0)
        self.uklad.setColumnStretch(2, 1)

    def _zastosuj(self) -> None:
        self.filtry.emit(self.zdjecia.currentData(), self.cena.currentData())
        self.menu_filtrow.hide()

    def ustaw(
        self,
        producenci: tuple[ProducentDTO, ...],
        wybor: str,
        fraza: str,
        zdjecia: bool | None,
        cena: bool | None,
    ) -> None:
        nazwy = Counter(p.nazwa.casefold() for p in producenci)
        if self.producenci != producenci:
            for ident, b in tuple(self.przyciski.items()):
                if ident != "wszyscy":
                    self.grupa.removeButton(b)
                    self.chips.removeWidget(b)
                    b.deleteLater()
                    del self.przyciski[ident]
            for i, producent in enumerate(producenci[:5]):
                ident = str(producent.id)
                b = QPushButton(nazwa_wyboru_producenta(producent, nazwy))
                b.setProperty("chipProducenta", True)
                b.setCheckable(True)
                b.setAccessibleName(f"Producent: {producent.nazwa}")
                b.setToolTip(producent.nazwa + (" (nieaktywny)" if not producent.aktywny else ""))
                b.clicked.connect(lambda checked=False, pid=ident: self.producent.emit(pid))
                self.grupa.addButton(b)
                self.przyciski[ident] = b
                self.chips.insertWidget(i + 1, b)
            self.producenci = producenci
        self.grupa.setExclusive(False)
        for ident, b in self.przyciski.items():
            b.setChecked(ident == wybor)
        self.grupa.setExclusive(True)
        self.wiecej.setChecked(wybor not in self.przyciski)
        self.menu_producentow.clear()
        for tekst, ident in (
            ("Wszyscy producenci", "wszyscy"),
            ("Bez producenta", "brak"),
            *((nazwa_wyboru_producenta(p, nazwy), str(p.id)) for p in producenci[5:]),
        ):
            a = self.menu_producentow.addAction(tekst)
            a.setCheckable(True)
            a.setChecked(ident == wybor)
            a.triggered.connect(lambda checked=False, pid=ident: self.producent.emit(pid))
        self.szukaj.blockSignals(True)
        self.szukaj.setText(fraza)
        self.szukaj.blockSignals(False)
        for combo, value in ((self.zdjecia, zdjecia), (self.cena, cena)):
            combo.setCurrentIndex(combo.findData(value))
        self.przycisk_filtrow.setChecked(zdjecia is not None or cena is not None)
        self._rozmiesc()
